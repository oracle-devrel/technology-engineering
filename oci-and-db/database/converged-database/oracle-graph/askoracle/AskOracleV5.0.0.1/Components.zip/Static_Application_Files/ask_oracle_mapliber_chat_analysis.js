/* AskOracle simple local drawing questions v1.0.1-simple.
 * Load AFTER the working runtime, map, drawing and analysis v1.1.0-simple.
 * No Ajax callback, LLM router, profiles, storage, comparison or drag-and-drop.
 * Supported patterns: Which districts contain my drawings/points?
 *                     Which districts intersect my lines?
 * All completed drawings of the requested type on the chosen OPEN map are used.
 * Uses the last map interacted with; otherwise the most recently opened map.
 * No map-choice buttons. Hidden/removed maps are never analyzed.
 * Only loaded district polygons are analyzed. Results replace the latest analysis
 * table BELOW that same map. Two independent table toggles belong to analysis.js.
 * Neither map visibility/zoom nor original data is changed. Questions/results
 * are temporary browser UI, not saved to database conversation history.
 * Ordinary questions pass through the original chat handlers untouched.
 * Removing this File URL and reloading disables this optional bridge.
 */
(function () {
  'use strict';
  if (window.askOracleMapChatAnalysis) return;
  const controller = new AbortController();
  let stopped = false, busy = false, notice = null, generation = 0;
  const observedMaps = new Map();
  let activeMap = null, pendingMapId = null, openSequence = 0, contextKey = null, contextHost = null;
  const examples = 'Try: "Which districts contain my points?" or "Which districts intersect my lines?"';
  const node = (tag, text) => { const el = document.createElement(tag); if (text !== undefined) el.textContent = text; return el; };
  const listen = (el, type, fn, options = {}) => el.addEventListener(type, fn, { ...options, signal: controller.signal });
  function parse(text) {
    const q = String(text || '').trim().toLowerCase().replace(/[?.!]+$/, '').replace(/\s+/g, ' ');
    const m = q.match(/^(?:please )?(?:(?:show|tell) me )?(?:which|what) districts? (contain|contains|intersect|intersects)(?: with)? (?:all )?my (?:(?:loaded|drawn) )?(drawings?|points?|lines?|polygons?)(?: (?:now|on (?:this|the) map))?$/);
    if (m) {
      const kind = m[2].replace(/s$/, '');
      const types = { point: ['Point','MultiPoint'], line: ['LineString','MultiLineString'], polygon: ['Polygon','MultiPolygon'] }[kind];
      return { relation: m[1].startsWith('contain') ? 'Within' : 'Intersects', types };
    }
    // Fail closed for unsupported questions explicitly about local drawings:
    // the database chatbot cannot see those geometries. No broad chat takeover.
    if (/\bdistricts?\b/.test(q) && /\bmy\s+(?:(?:selected|loaded|drawn|all)\s+)*(?:drawings?|points?|lines?|polygons?)\b/.test(q))
      return { error: 'This simple version analyzes all loaded drawings of a type, not selected/named drawings or individual district tests. ' + examples };
    return null;
  }
  function conversation() {
    try { return String(window.apex?.item('P1_CONV_ID')?.getValue() || ''); }
    catch (_) { return document.getElementById('P1_CONV_ID')?.value || ''; }
  }
  function parent() { return document.querySelector('#PROMPTS .prompt-list') || document.getElementById('PROMPTS'); }
  function openMaps() {
    const key = conversation(), host = parent();
    if (key !== contextKey || host !== contextHost) {
      observedMaps.clear(); activeMap = null; pendingMapId = null;
      contextKey = key; contextHost = host;
    }
    const maps = (window.askOracleMapAnalysis?.getOpenMaps?.() || []).map(info => {
      const map = window.askOracleMap?.getMap(info.id);
      if (!map) return null;
      if (!observedMaps.has(map)) observedMaps.set(map, ++openSequence);
      return { ...info, map, opened: observedMaps.get(map) };
    }).filter(Boolean);
    const live = new Set(maps.map(m => m.map));
    observedMaps.forEach((_, map) => { if (!live.has(map)) observedMaps.delete(map); });
    if (!live.has(activeMap)) activeMap = null;
    if (pendingMapId != null) {
      const opened = maps.find(m => String(m.id) === pendingMapId);
      if (opened) { activeMap = opened.map; pendingMapId = null; }
    }
    return maps;
  }
  function rememberMap(event) {
    const block = event.target.closest?.('.ask-oracle-map-block');
    const opener = event.type === 'click' && event.target.closest?.('.llm-conv-show-map-btn[data-id]');
    if (!block && !opener) return;
    const maps = openMaps();
    if (opener) { pendingMapId = String(opener.dataset.id); return; }
    const used = maps.find(m => m.map.getContainer().closest('.ask-oracle-map-block') === block);
    if (used) { activeMap = used.map; pendingMapId = null; }
  }
  function clearNotice() { notice?.remove(); notice = null; }
  function message(text) {
    clearNotice(); const host = parent(); if (!host) return null;
    const box = node('section'); box.className = 'aosc-notice';
    box.setAttribute('role', 'status'); box.appendChild(node('p', text));
    host.appendChild(box); notice = box; return box;
  }
  async function run(mapId, intent, question, ticket, host, conv) {
    if (stopped || busy || ticket !== generation || host !== parent() || conv !== conversation()) return;
    busy = true; clearNotice();
    try {
      await window.askOracleMapAnalysis.runDrawings(mapId, { ...intent, question });
    } catch (error) {
      if (!stopped && ticket === generation && host === parent() && conv === conversation()) message(error.message);
    } finally { busy = false; }
  }
  function submit(text) {
    const intent = parse(text);
    if (!intent || stopped) return false;
    // No duplicate request, card or table while the local engine is running.
    if (busy) return true;
    const ticket = ++generation, host = parent(), conv = conversation();
    if (intent.error) { message(intent.error); return true; }
    window.askOracleMapDrawing?.refresh();
    const api = window.askOracleMapAnalysis;
    if (!api?.getOpenMaps || !api?.runDrawings) {
      message('Load ask_oracle_mapliber_analysis.js v1.1.0-simple before this chat module, then reload.'); return true;
    }
    const maps = openMaps();
    if (!maps.length) { message('Open a district map and finish or load your drawings first.'); return true; }
    const chosen = maps.find(m => m.map === activeMap) || maps.reduce((latest, m) => m.opened > latest.opened ? m : latest);
    void run(chosen.id, intent, text, ticket, host, conv);
    return true;
  }
  function intercept(event) {
    const input = document.getElementById('P1_PROMPT1');
    if (!input || stopped) return;
    if (event.type === 'click') {
      if (!event.target.closest?.('#runPrompt')) return;
    } else if (event.target !== input || event.key !== 'Enter' || event.shiftKey || event.ctrlKey || event.altKey || event.metaKey || event.isComposing) return;
    // Preserve the original Stop action during a normal chat request.
    if (window.isPromptRequestRunning?.()) return;
    const text = input.value.trim();
    if (!parse(text)) { ++generation; clearNotice(); return; }
    event.preventDefault(); event.stopImmediatePropagation();
    if (busy) return; // Keep any new composer text until the current run ends.
    try {
      window.stopPromptMicrophoneCapture?.();
      if (submit(text)) { input.value = ''; input.dispatchEvent(new Event('input', { bubbles: true })); }
    } catch (error) { message('Local analysis could not start: ' + error.message); }
  }
  const style = node('style');
  style.textContent = '.aosc-notice{margin:12px 0;padding:12px;border:1px solid #b9c8d3;border-radius:6px;background:#f7fafc;color:#172b3a}.aosc-notice button{margin:4px;padding:7px 10px;border:1px solid #b9c8d3;border-radius:5px;background:white;color:#172b3a}.aosc-notice :focus-visible{outline:2px solid #007d9a;outline-offset:2px}';
  document.head.appendChild(style);
  ['pointerdown', 'click', 'focusin', 'wheel'].forEach(type => listen(window, type, rememberMap, { capture: true, passive: true }));
  // Observe opening/reopening without reacting to automatic drawing restores or
  // result/highlight source updates. No map or source data is changed here.
  const mapTimer = setInterval(() => { if (!stopped) openMaps(); }, 500);
  openMaps();
  listen(window, 'click', intercept, { capture: true });
  listen(window, 'keydown', intercept, { capture: true });
  window.askOracleMapChatAnalysis = {
    version: '1.0.1-simple', parse, submit,
    destroy: () => { stopped = true; ++generation; clearInterval(mapTimer); observedMaps.clear(); activeMap = null; pendingMapId = null; controller.abort(); clearNotice(); style.remove(); delete window.askOracleMapChatAnalysis; }
  };
})();
