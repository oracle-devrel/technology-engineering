/*
 * Ask Oracle map integration, v1.2.1. Filename intentionally: mapliber.
 * Show Map is always available on supported answer action bars, including answers
 * without structured geometry. Such answers display the basemap and an explicit
 * no-geometry message; no coordinates are extracted from narrative text.
 * Upload to Shared Components > Static Application Files.
 * Page JavaScript File URLs, AFTER the existing Ask Oracle scripts:
 *   #APP_FILES#maplibre-gl.js
 *   #APP_FILES#ask_oracle_mapliber.js
 * Page CSS File URLs:
 *   #APP_FILES#maplibre-gl.css
 * Upload matching MapLibre GL JS JS/CSS files separately and retain its licence.
 * This integration does not download executable libraries from a public CDN.
 *
 * Basemap: OpenFreeMap Positron (external requests ONLY on Show Map).
 * Before loading this script, set window.askOracleMapConfig = { style: ... }
 * to use a company-approved MapLibre style URL or style object. Attribution is
 * retained. A tile service sees the requested map area/IP, not feature attributes.
 * Set style: null for a blank, offline background. No telemetry is added here.
 *
 * INPUT CONTRACT (trusted, executed query results, NOT LLM prose):
 * - GeoJSON FeatureCollection / Feature / geometry, or
 * - row objects with GEOJSON / GEOMETRY / GEOM / *_GEOJSON columns containing
 *   GeoJSON objects or JSON strings. Other returned scalar columns are attributes.
 * Coordinates MUST be WGS84 longitude, latitude (RFC 7946). Never guess a CRS.
 * Raw SDO_GEOMETRY, ST_Geometry, WKT, addresses and file imports need backend
 * conversion first. This script does not geocode or change the database.
 *
 * Existing integration: captures successful apex.server.process GET_SQL_RESULTS
 * calls, watches __askOracleNl2SqlChartRows and completed jQuery requests.
 * Reads rendered result tables, not narrative/code. Does not execute extra SQL.
 * Agent narrative-only responses need their backend to supply executed rows via
 * setResults/the results event below; coordinates in prose are not query results.
 * Preferred explicit integration after the backend returns results:
 *   window.askOracleMap.setResults(promptId, data.results);
 * Or dispatch CustomEvent('ask-oracle-map-results', {detail:{id, results}}).
 * Works identically for table, RDF and property-graph query results once converted.
 * No background SQL calls, vector-tile endpoint, live-stream polling, or PDF hook.
 *
 * First-version safety limits: 5,000 geometries / 100,000 positions / 5 MiB JSON
 * string per cell. Limits and rejected geometry are disclosed, never silently
 * presented as the complete answer. Limit does not limit server response size.
 */
(function installAskOracleMap() {
  "use strict";
  if (window.askOracleMap) return;

  const config = Object.assign({
    style: "https://tiles.openfreemap.org/styles/positron",
    maxFeatures: 5000, maxPositions: 100000, maxJsonChars: 5 * 1024 * 1024
  }, window.askOracleMapConfig || {});
  ["maxFeatures", "maxPositions", "maxJsonChars"].forEach(function (key) {
    if (!Number.isSafeInteger(config[key]) || config[key] < 1) throw new Error("Invalid map limit: " + key);
  });
  const states = new Map();
  const geometryTypes = new Set(["Point", "MultiPoint", "LineString", "MultiLineString", "Polygon", "MultiPolygon", "GeometryCollection"]);
  const anchorSelector = ".llm-conv-show-graph-btn[data-id], .llm-conv-show-sql-btn[data-id], .llm-conv-show-charts-btn[data-id], .speech-controls[data-id]";
  let serial = 0, pending = false, stopped = false, observer, timer, ajaxAttached = false;
  let processOwner, originalProcess, wrappedProcess;

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function parse(value) {
    if (typeof value !== "string") return value;
    if (value.length > config.maxJsonChars || !/^\s*\{/.test(value)) return null;
    try { return JSON.parse(value); } catch (_) { return null; }
  }

  function scalarProperties(input) {
    const result = Object.create(null);
    if (!input || typeof input !== "object" || Array.isArray(input)) return result;
    Object.keys(input).slice(0, 100).forEach(function (key) {
      const value = input[key];
      if (key === "__proto__" || key === "constructor" || key === "prototype") return;
      if (value === null || typeof value === "boolean" || (typeof value === "number" && Number.isFinite(value))) result[key] = value;
      else if (typeof value === "string" && !/^\s*\{/.test(value)) result[key] = value.slice(0, 2000);
    });
    return result;
  }

  // Validate structure/ranges, not topology. Polygon self-intersection, source CRS,
  // curves and precision must be validated upstream. Do not repair coordinates here.
  function validateGeometry(g, budget) {
    if (!g || !geometryTypes.has(g.type) || g.crs) return false;
    function point(p) {
      if (++budget.positions > config.maxPositions) { budget.exceeded = true; return false; }
      return Array.isArray(p) && (p.length === 2 || p.length === 3) &&
        p.every(function (n) { return typeof n === "number" && Number.isFinite(n); }) &&
        p[0] >= -180 && p[0] <= 180 && p[1] >= -90 && p[1] <= 90;
    }
    function list(a, check, minimum) { return Array.isArray(a) && a.length >= minimum && a.every(check); }
    function line(a) { return list(a, point, 2); }
    function ring(a) {
      return list(a, point, 4) && a[0].length === a[a.length - 1].length &&
        a[0].every(function (n, i) { return n === a[a.length - 1][i]; });
    }
    function polygon(a) { return list(a, ring, 1); }
    switch (g.type) {
      case "Point": return point(g.coordinates);
      case "MultiPoint": return list(g.coordinates, point, 1);
      case "LineString": return line(g.coordinates);
      case "MultiLineString": return list(g.coordinates, line, 1);
      case "Polygon": return polygon(g.coordinates);
      case "MultiPolygon": return list(g.coordinates, polygon, 1);
      default: return false; // Collections are flattened with bounded recursion below.
    }
  }

  function normalize(input) {
    const output = { type: "FeatureCollection", features: [] };
    const report = { invalid: 0, missing: 0, limited: false, bounds: null };
    const budget = { positions: 0, exceeded: false };
    let visits = 0;
    function bounds(coords) {
      if (typeof coords[0] === "number") {
        if (!report.bounds) report.bounds = [coords[0], coords[1], coords[0], coords[1]];
        else {
          report.bounds[0] = Math.min(report.bounds[0], coords[0]);
          report.bounds[1] = Math.min(report.bounds[1], coords[1]);
          report.bounds[2] = Math.max(report.bounds[2], coords[0]);
          report.bounds[3] = Math.max(report.bounds[3], coords[1]);
        }
      } else coords.forEach(bounds);
    }
    function add(raw, properties, rowIndex, depth) {
      if (output.features.length >= config.maxFeatures || budget.exceeded || ++visits > config.maxFeatures * 20) { report.limited = true; return; }
      if (raw == null || raw === "") { report.missing++; return; }
      const value = parse(raw);
      if (!value || depth > 8 || value.crs) { report.invalid++; return; }
      if (value.type === "FeatureCollection" && Array.isArray(value.features)) {
        for (const feature of value.features) {
          add(feature, properties, rowIndex, depth + 1);
          if (report.limited) break;
        }
      } else if (value.type === "Feature") {
        add(value.geometry, Object.assign(Object.create(null), properties, scalarProperties(value.properties)), rowIndex, depth + 1);
      } else if (value.type === "GeometryCollection" && Array.isArray(value.geometries)) {
        for (const geometry of value.geometries) {
          add(geometry, properties, rowIndex, depth + 1);
          if (report.limited) break;
        }
      } else if (validateGeometry(value, budget)) {
        // Strip foreign members; only geometry and returned scalar attributes travel
        // to the rendering worker. Details are inserted using textContent, never HTML.
        const geometry = { type: value.type, coordinates: value.coordinates };
        output.features.push({ type: "Feature", id: output.features.length, geometry: geometry, properties: properties });
        bounds(geometry.coordinates);
      } else if (budget.exceeded) report.limited = true;
      else report.invalid++;
    }
    const payload = parse(input);
    if (payload && (geometryTypes.has(payload.type) || payload.type === "Feature" || payload.type === "FeatureCollection")) add(payload, {}, 0, 0);
    else {
      const rows = Array.isArray(payload) ? payload : payload && payload.results;
      if (Array.isArray(rows)) {
        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          if (!row || typeof row !== "object") continue;
          if (geometryTypes.has(row.type) || row.type === "Feature" || row.type === "FeatureCollection") add(row, {}, i, 0);
          else {
            const keys = Object.keys(row);
            const geoKeys = keys.filter(function (key) {
              if (/^(GEOJSON|GEOMETRY|GEOM)$|_GEOJSON$/i.test(key)) return true;
              const value = row[key];
              return value && typeof value === "object" && (geometryTypes.has(value.type) || value.type === "Feature" || value.type === "FeatureCollection");
            });
            const props = scalarProperties(row);
            geoKeys.forEach(function (key) { delete props[key]; });
            for (const key of geoKeys) {
              add(row[key], props, i, 0);
              if (report.limited) break;
            }
          }
          if (report.limited) break;
          if (i >= 50000) { report.limited = true; break; }
        }
      }
    }
    return { geojson: output, report: report };
  }

  function summary(state) {
    const r = state.data.report;
    if (!state.data.geojson.features.length) {
      return (state.input === undefined
        ? "No structured query results reached the map. Coordinates mentioned in an answer are not plotted. Only the background map is displayed. "
        : "The received query results contain no usable geometry. Only the background map is displayed. ") +
        (r.invalid ? r.invalid + " invalid or unsupported geometries omitted. " : "") +
        (r.missing ? r.missing + " NULL/empty geometries omitted. " : "") +
        (r.limited ? "The geometry processing limit was reached. Filter the question further." : "");
    }
    return state.data.geojson.features.length.toLocaleString() + " geometries from returned results. " +
      "Blue: points / areas; orange: lines. " +
      (r.invalid ? r.invalid + " invalid or unsupported geometries omitted. " : "") +
      (r.missing ? r.missing + " NULL/empty geometries omitted. " : "") +
      (r.limited ? "DISPLAY LIMIT REACHED: only part of the returned results is mapped. Filter the question further. " : "") +
      "This map does not establish that all database rows were returned.";
  }

  function release(state) {
    if (state.resizeObserver) state.resizeObserver.disconnect();
    if (state.map) state.map.remove();
    if (state.block) state.block.remove();
    state.map = null; state.block = null; state.resizeObserver = null;
  }

  function setResults(id, payload) {
    id = String(id || "");
    if (!id || stopped) return;
    let state = states.get(id);
    if (!state) { state = { id: id, token: ++serial }; states.set(id, state); }
    const reopen = !!state.block && !state.block.hidden;
    release(state);
    state.input = payload;
    const cached = (window.__askOracleNl2SqlChartRows || {})[id];
    state.cacheRef = cached; state.cacheLength = Array.isArray(cached) ? cached.length : 0;
    state.data = normalize(payload);
    if (state.button) {
      state.button.hidden = false;
      state.button.textContent = "Show Map";
      state.button.setAttribute("aria-expanded", "false");
      if (reopen) open(state);
    }
    schedule();
    return { featureCount: state.data.geojson.features.length, report: state.data.report };
  }

  function fit(state) {
    const b = state.data.report.bounds;
    if (b && state.map) state.map.fitBounds([[b[0], b[1]], [b[2], b[3]]], { padding: 45, maxZoom: 14, duration: 0 });
  }

  function showDetails(state, feature) {
    state.details.replaceChildren();
    state.details.appendChild(element("strong", "", "Selected location"));
    const table = element("table", "ask-oracle-map-attributes");
    const properties = scalarProperties(feature.properties);
    Object.keys(properties).forEach(function (key) {
      const row = element("tr");
      const heading = element("th", "", key); heading.scope = "row";
      row.append(heading, element("td", "", properties[key] === null ? "NULL" : String(properties[key])));
      table.appendChild(row);
    });
    state.details.appendChild(Object.keys(properties).length ? table : element("p", "", "No attributes returned for this location."));
  }

  function open(state) {
    if (state.block) {
      state.block.hidden = !state.block.hidden;
      state.button.textContent = state.block.hidden ? "Show Map" : "Hide Map";
      state.button.setAttribute("aria-expanded", String(!state.block.hidden));
      if (!state.block.hidden && state.map) state.map.resize();
      return;
    }
    if (!window.maplibregl || typeof window.maplibregl.Map !== "function") {
      const message = "MapLibre is not loaded. Add maplibre-gl.js and its matching CSS before ask_oracle_mapliber.js in the page settings.";
      if (window.apex && window.apex.message) window.apex.message.alert(message);
      else window.alert(message);
      return;
    }
    const response = document.getElementById("response-" + state.id);
    if (!response || !response.parentNode) return;
    const block = element("section", "ask-oracle-map-block");
    block.id = "ask-oracle-map-" + state.token;
    block.setAttribute("aria-label", "Map of query results");
    const toolbar = element("div", "ask-oracle-map-toolbar");
    const fitButton = element("button", "t-Button t-Button--small", "Fit results"); fitButton.type = "button";
    fitButton.disabled = !state.data.geojson.features.length;
    const closeButton = element("button", "t-Button t-Button--small", "Hide Map"); closeButton.type = "button";
    toolbar.append(fitButton, closeButton);
    const status = element("p", "ask-oracle-map-status", summary(state)); status.setAttribute("role", "status");
    const errors = element("p", "ask-oracle-map-error"); errors.setAttribute("role", "status"); errors.hidden = true;
    const canvas = element("div", "ask-oracle-map-canvas");
    state.details = element("div", "ask-oracle-map-details", "Select a location to see its returned attributes here. No popups.");
    state.details.hidden = !state.data.geojson.features.length;
    block.append(toolbar, status, errors, canvas, state.details);
    response.insertAdjacentElement("afterend", block);
    state.block = block;
    state.button.setAttribute("aria-controls", block.id);
    state.button.setAttribute("aria-expanded", "true"); state.button.textContent = "Hide Map";
    closeButton.addEventListener("click", function () { open(state); state.button.focus(); });
    fitButton.addEventListener("click", function () { fit(state); });
    try {
      const map = new window.maplibregl.Map({
        container: canvas,
        style: config.style || { version: 8, sources: {}, layers: [{ id: "blank", type: "background", paint: { "background-color": "#eff3f5" } }] },
        center: [0, 20], zoom: 1, attributionControl: true, renderWorldCopies: false
      });
      state.map = map;
      map.addControl(new window.maplibregl.NavigationControl(), "top-right");
      map.on("error", function () {
        errors.hidden = false;
        errors.textContent = "A map resource could not load. Check the basemap connection, MapLibre CSS and the application's Content Security Policy. Hide and reopen after resolving the issue.";
      });
      map.on("load", function () {
        if (state.map !== map) return;
        const source = "ask-oracle-results";
        // Attribute dictionaries deliberately have no prototype inside this script.
        // MapLibre 5.24's worker serializer requires ordinary JSON objects (it
        // reads constructor._classRegistryKey). Copy at the library boundary;
        // preserve geometry and attributes without changing the safe internal data.
        const sourceData = JSON.parse(JSON.stringify(state.data.geojson));
        map.addSource(source, { type: "geojson", data: sourceData });
        map.addLayer({ id: "ao-areas", type: "fill", source: source, filter: ["==", ["geometry-type"], "Polygon"], paint: { "fill-color": "#176b94", "fill-opacity": 0.3, "fill-outline-color": "#104963" } });
        map.addLayer({ id: "ao-lines", type: "line", source: source, filter: ["==", ["geometry-type"], "LineString"], paint: { "line-color": "#b44b12", "line-width": 3 } });
        map.addLayer({ id: "ao-points", type: "circle", source: source, filter: ["==", ["geometry-type"], "Point"], paint: { "circle-color": "#176b94", "circle-radius": 7, "circle-stroke-width": 2, "circle-stroke-color": "#fff" } });
        fit(state);
        ["ao-points", "ao-lines", "ao-areas"].forEach(function (layer) {
          map.on("mouseenter", layer, function () { map.getCanvas().style.cursor = "pointer"; });
          map.on("mouseleave", layer, function () { map.getCanvas().style.cursor = ""; });
        });
        map.on("click", function (event) {
          const hits = map.queryRenderedFeatures(event.point, { layers: ["ao-points", "ao-lines", "ao-areas"] });
          if (hits.length) showDetails(state, hits[0]);
        });
      });
      if (window.ResizeObserver) {
        state.resizeObserver = new window.ResizeObserver(function () { if (!block.hidden) map.resize(); });
        state.resizeObserver.observe(canvas);
      }
    } catch (_) {
      release(state);
      state.button.textContent = "Show Map"; state.button.setAttribute("aria-expanded", "false");
      const message = "The map could not start. Check that this browser supports WebGL and MapLibre's library and CSS are loaded.";
      if (window.apex && window.apex.message) window.apex.message.alert(message); else window.alert(message);
    }
  }

  function scan() {
    pending = false;
    if (stopped || !document.body) return;
    attachProcess();
    attachAjax();
    const anchors = new Map();
    document.querySelectorAll(anchorSelector).forEach(function (anchor) {
      const id = String(anchor.getAttribute("data-id") || "");
      if (!anchors.has(id)) anchors.set(id, anchor);
    });
    anchors.forEach(function (anchor, id) {
      const response = document.getElementById("response-" + id);
      if (!response) return;
      const cache = window.__askOracleNl2SqlChartRows || {};
      let state = states.get(id);
      if (Array.isArray(cache[id]) && (!state || (state.cacheRef !== cache[id]) || state.cacheLength !== cache[id].length)) {
        setResults(id, cache[id]); state = states.get(id); state.cacheRef = cache[id]; state.cacheLength = cache[id].length;
      }
      // Fallback: executed result tables with an explicit GeoJSON column. Never
      // parse prose or code blocks, where the LLM may show invented examples.
      if (!state || state.input === undefined) {
        for (const table of response.querySelectorAll("table")) {
          const headers = Array.from(table.querySelectorAll("thead th")).map(function (th) { return th.textContent.trim(); });
          if (!headers.some(function (h) { return /^GEOJSON$|_GEOJSON$/i.test(h); })) continue;
          const rows = Array.from(table.querySelectorAll("tbody tr")).slice(0, config.maxFeatures + 1).map(function (tr) {
            const row = Object.create(null);
            Array.from(tr.cells).forEach(function (td, i) { if (headers[i]) row[headers[i]] = td.textContent.trim(); });
            return row;
          });
          // Require explicit result-table marker, not an arbitrary Markdown table.
          if (table.matches(".llm-sql-table, .sql-result-table, .sql-results-table, [data-query-results]")) { setResults(id, rows); state = states.get(id); break; }
        }
      }
      // Keep a placeholder even for narrative-only answers. Do not call setResults
      // here: repeated empty scans must not close an already opened background map.
      if (!state) {
        state = { id: id, token: ++serial, data: normalize([]) };
        states.set(id, state);
      }
      if (state.button && state.button.isConnected) return;
      const parent = anchor.classList.contains("speech-controls") ? anchor.querySelector("div") || anchor : anchor.parentNode;
      if (!parent) return;
      const expanded = !!state.block && !state.block.hidden;
      const button = element("button", "t-Button t-Button--small llm-conv-show-map-btn", expanded ? "Hide Map" : "Show Map");
      button.type = "button"; button.setAttribute("data-id", id); button.setAttribute("aria-expanded", String(expanded));
      if (state.block) button.setAttribute("aria-controls", state.block.id);
      button.addEventListener("click", function (event) { event.preventDefault(); event.stopPropagation(); open(state); });
      parent.appendChild(button); state.button = button;
    });
    states.forEach(function (state, id) {
      if (state.button && !document.getElementById("response-" + id)) { release(state); state.button.remove(); states.delete(id); }
    });
  }

  function schedule() {
    if (!pending && !stopped) { pending = true; window.setTimeout(scan, 100); }
  }

  // Observe an existing, successful SQL-results request. Never run a second query
  // or pass narrative text to GET_SQL_RESULTS. Keep the caller's arguments,
  // callback context, return value and error behavior intact.
  function captureResults(id, data) {
    if (stopped || !id || !data || !Array.isArray(data.results)) return;
    id = String(id);
    const state = states.get(id);
    if (state && state.input === data.results) return;
    window.__askOracleNl2SqlChartRows = window.__askOracleNl2SqlChartRows || {};
    window.__askOracleNl2SqlChartRows[id] = data.results;
    setResults(id, data.results);
  }

  function attachProcess() {
    const server = window.apex && window.apex.server;
    if (wrappedProcess || !server || typeof server.process !== "function") return;
    processOwner = server;
    originalProcess = server.process;
    wrappedProcess = function (name, data, options) {
      if (stopped || name !== "GET_SQL_RESULTS") return originalProcess.apply(this, arguments);
      const id = data && data.x01;
      const args = Array.from(arguments);
      const nextOptions = Object.assign({}, options || {});
      const success = nextOptions.success;
      nextOptions.success = function (result) {
        // A map error must never prevent the existing response renderer running.
        try { captureResults(id, result); } catch (_) { /* existing UI continues */ }
        if (typeof success === "function") return success.apply(this, arguments);
      };
      args[2] = nextOptions;
      return originalProcess.apply(this, args);
    };
    server.process = wrappedProcess;
  }

  function attachAjax() {
    const jq = window.apex && window.apex.jQuery;
    if (ajaxAttached || !jq) return;
    ajaxAttached = true;
    jq(document).on("ajaxSuccess.askOracleMap", function (_, xhr, settings) {
      const raw = settings && settings.data;
      const params = typeof raw === "string" ? new URLSearchParams(raw) : null;
      const request = params ? params.get("p_request") : raw && raw.p_request;
      if (!/^(APPLICATION_PROCESS=)?GET_SQL_RESULTS$/i.test(request || "")) return;
      let data = xhr.responseJSON;
      if (!data) { try { data = JSON.parse(xhr.responseText); } catch (_) { return; } }
      let id = params ? params.get("x01") : raw && raw.x01;
      if (!id) {
        const packed = parse(params ? params.get("p_json") : raw && raw.p_json);
        id = packed && packed.x01;
      }
      if (!id && data) id = data.id;
      try { captureResults(id, data); } catch (_) { /* do not disrupt other listeners */ }
    });
  }

  function resultsEvent(event) { const d = event.detail || {}; setResults(d.id, d.results); }
  function install() {
    const style = element("style"); style.id = "ask-oracle-map-css";
    style.textContent = ".ask-oracle-map-block{margin:16px 0;border:1px solid #bac7d2;border-radius:8px;background:#fff;color:#172b3a;overflow:hidden}.ask-oracle-map-block[hidden],.llm-conv-show-map-btn[hidden]{display:none!important}.ask-oracle-map-toolbar{display:flex;gap:8px;padding:10px}.ask-oracle-map-canvas{width:100%;height:480px;min-height:300px}.ask-oracle-map-status,.ask-oracle-map-error{padding:0 12px;font-size:14px;line-height:1.5}.ask-oracle-map-error{color:#a32418;font-weight:700}.ask-oracle-map-details{padding:14px;font-size:15px;line-height:1.5;max-height:260px;overflow:auto}.ask-oracle-map-attributes{width:100%;border-collapse:collapse}.ask-oracle-map-attributes th,.ask-oracle-map-attributes td{padding:6px 10px;border-bottom:1px solid #dbe2e8;text-align:left;overflow-wrap:anywhere}.llm-conv-show-map-btn{min-height:32px!important;padding:4px 9px!important;font-size:12px!important}.ask-oracle-map-block button:focus-visible,.llm-conv-show-map-btn:focus-visible{outline:3px solid #226ea0;outline-offset:2px}@media(max-width:600px){.ask-oracle-map-canvas{height:340px}}";
    document.head.appendChild(style);
    observer = new MutationObserver(function (records) {
      if (records.some(function (r) { return !(r.target.closest && r.target.closest(".ask-oracle-map-block")); })) schedule();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    document.addEventListener("ask-oracle-map-results", resultsEvent);
    // Cache inspection only, not network or database polling. Handles cache writes
    // after an answer finishes without generating DOM mutations.
    timer = window.setInterval(function () { if (!document.hidden) schedule(); }, 1500);
    scan();
  }

  window.askOracleMap = {
    version: "1.2.1", setResults: setResults, normalize: normalize, refresh: schedule,
    getMap: function (id) { const s = states.get(String(id)); return s && s.map || null; },
    destroy: function () {
      stopped = true;
      document.removeEventListener("DOMContentLoaded", install);
      if (observer) observer.disconnect(); window.clearInterval(timer);
      states.forEach(function (s) { release(s); if (s.button) s.button.remove(); }); states.clear();
      document.removeEventListener("ask-oracle-map-results", resultsEvent);
      if (ajaxAttached) window.apex.jQuery(document).off(".askOracleMap");
      if (processOwner && processOwner.process === wrappedProcess) processOwner.process = originalProcess;
      const css = document.getElementById("ask-oracle-map-css"); if (css) css.remove();
      delete window.askOracleMap;
    }
  };
  attachProcess();
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", install, { once: true }); else install();
})();
