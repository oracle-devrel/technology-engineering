-- SETTINGS_BOOTSTRAP
declare
  l_theme_name varchar2(200);

  function get_cfg(p_key varchar2, p_default varchar2) return varchar2 is
    l_val app_config.config_value%type;
  begin
    select config_value into l_val from app_config where config_key = p_key;
    return nvl(l_val, p_default);
  exception
    when no_data_found then
      return p_default;
    when others then
      return p_default;
  end;

  function get_zoom_pct return varchar2 is
    l_pref varchar2(4000);
  begin
    l_pref := apex_util.get_preference('APP_ZOOM_PCT', :APP_USER);
    if l_pref is not null then
      return l_pref;
    end if;
    return get_cfg('APP_ZOOM_PCT', '100');
  exception
    when others then
      return get_cfg('APP_ZOOM_PCT', '100');
  end;

  function get_schema_owner return varchar2 is
  begin
    return upper(trim(nvl(v('APP_SCHEMA'), user)));
  exception
    when others then
      return upper(user);
  end;

  function get_admin_owner return varchar2 is
    l_owner varchar2(255) := get_schema_owner;
  begin
    l_owner := upper(trim(get_cfg('ADMIN_OWNER_APP_USER', l_owner)));
    if l_owner is null then
      l_owner := get_schema_owner;
    end if;
    return l_owner;
  exception
    when others then
      return get_schema_owner;
  end;

  function is_admin_user return boolean is
  begin
    return upper(trim(nvl(:APP_USER, ''))) = get_admin_owner;
  end;
begin
  apex_json.open_object;

  apex_json.open_array('nl2sql_profiles');
  for r in (
    select u.profile_name d, u.profile_name r
      from user_cloud_ai_profiles u
      left join user_cloud_ai_profile_attributes p
        on p.profile_name = u.profile_name
       and p.attribute_name = 'vector_index_name'
     where u.profile_name not like 'AGENT$%'
       and p.profile_name is null
     order by 1
  ) loop
    apex_json.open_object;
    apex_json.write('d', r.d);
    apex_json.write('r', r.r);
    apex_json.close_object;
  end loop;
  apex_json.close_array;

  apex_json.open_array('rag_profiles');
  for r in (
    select u.profile_name d, u.profile_name r
      from user_cloud_ai_profiles u
      left join user_cloud_ai_profile_attributes p
        on p.profile_name = u.profile_name
       and p.attribute_name = 'vector_index_name'
     where u.profile_name not like 'AGENT$%'
       and p.profile_name is not null
     order by 1
  ) loop
    apex_json.open_object;
    apex_json.write('d', r.d);
    apex_json.write('r', r.r);
    apex_json.close_object;
  end loop;
  apex_json.close_array;

  apex_json.open_array('agent_teams');
  for r in (
    select agent_team_name d, agent_team_name r
      from user_ai_agent_teams
     where agent_team_name not like '%_DSAGENT_TEAM'
     order by 1
  ) loop
    apex_json.open_object;
    apex_json.write('d', r.d);
    apex_json.write('r', r.r);
    apex_json.close_object;
  end loop;
  apex_json.close_array;

  apex_json.open_array('agents');
  begin
    for r in (
      select a.agent_name d,
             a.agent_name r,
             max(case when lower(attr.attribute_name) = 'profile_name' then dbms_lob.substr(attr.attribute_value, 4000, 1) end) profile_name
        from user_ai_agents a
        left join user_ai_agent_attributes attr
          on upper(attr.agent_name) = upper(a.agent_name)
         and lower(attr.attribute_name) = 'profile_name'
       group by a.agent_name
       order by a.agent_name
    ) loop
      apex_json.open_object;
      apex_json.write('d', r.d);
      apex_json.write('r', r.r);
      apex_json.write('profile_name', r.profile_name);
      apex_json.close_object;
    end loop;
  exception
    when others then
      null;
  end;
  apex_json.close_array;

  apex_json.open_array('agent_tasks');
  begin
    for r in (
      select task_name d, task_name r
        from user_ai_agent_tasks
       order by task_name
    ) loop
      apex_json.open_object;
      apex_json.write('d', r.d);
      apex_json.write('r', r.r);
      apex_json.close_object;
    end loop;
  exception
    when others then
      null;
  end;
  apex_json.close_array;

  apex_json.open_array('agent_tools');
  begin
    for r in (
      select tool_name d, tool_name r
        from user_ai_agent_tools
       order by tool_name
    ) loop
      apex_json.open_object;
      apex_json.write('d', r.d);
      apex_json.write('r', r.r);
      apex_json.close_object;
    end loop;
  exception
    when others then
      null;
  end;
  apex_json.close_array;

  apex_json.open_array('backend_callables');
  begin
    for r in (
      select display_name d,
             callable_name r
        from (
          select case
                   when procedure_name is null then object_type || ' - ' || user || '.' || object_name
                   else object_type || ' - ' || user || '.' || object_name || '.' || procedure_name
                 end display_name,
                 case
                   when procedure_name is null then user || '.' || object_name
                   else user || '.' || object_name || '.' || procedure_name
                 end callable_name,
                 object_name,
                 procedure_name
            from user_procedures
           where object_type in ('FUNCTION', 'PROCEDURE', 'PACKAGE')
             and object_name not like 'SETTINGS\_%' escape '\'
             and object_name not like 'ASK\_ORACLE\_%' escape '\'
        )
       where callable_name is not null
       order by object_name, procedure_name nulls first
    ) loop
      apex_json.open_object;
      apex_json.write('d', r.d);
      apex_json.write('r', r.r);
      apex_json.close_object;
    end loop;
  exception
    when others then
      null;
  end;
  apex_json.close_array;

  apex_json.open_array('credentials');
  begin
    for r in (
      select credential_name d, credential_name r
        from user_credentials
       order by credential_name
    ) loop
      apex_json.open_object;
      apex_json.write('d', r.d);
      apex_json.write('r', r.r);
      apex_json.close_object;
    end loop;
  exception
    when others then
      null;
  end;
  apex_json.close_array;

  apex_json.open_array('vector_indexes');
  begin
    for r in (
      select index_name d, index_name r
        from user_indexes
       where index_type like 'VECTOR'
       order by index_name
    ) loop
      apex_json.open_object;
      apex_json.write('d', r.d);
      apex_json.write('r', r.r);
      apex_json.close_object;
    end loop;
  exception
    when others then
      null;
  end;
  apex_json.close_array;

  apex_json.write('current_nl2sql', nvl(:P20000_SERVICE, apex_util.get_preference('CLOUD_AI_PROFILE1', :APP_USER)));
  apex_json.write('current_rag', nvl(:P20000_RAGSERVICE, apex_util.get_preference('CLOUD_AI_RAG_PROFILE1', :APP_USER)));
  apex_json.write('current_agent_team', nvl(:P20000_AGENT_SERVICE, apex_util.get_preference('CLOUD_AGENT_PROFILE1', :APP_USER)));
  apex_json.write('current_credential', apex_util.get_preference('CLOUD_AI_CREDENTIAL', :APP_USER));
  apex_json.write('is_admin', case when is_admin_user then 'Y' else 'N' end);

  apex_json.write('show_open_in_editor', get_cfg('SHOW_OPEN_IN_EDITOR', 'Y'));
  apex_json.write('show_agent_thoughts', get_cfg('SHOW_AGENT_THOUGHTS', 'Y'));
  apex_json.write('show_export_pdf', get_cfg('SHOW_EXPORT_PDF', 'Y'));
  apex_json.write('show_export_excel', get_cfg('SHOW_EXPORT_EXCEL', 'Y'));
  apex_json.write('show_conversation_timer', get_cfg('SHOW_CONVERSATION_TIMER', 'Y'));
  apex_json.write('show_delete_prompt', get_cfg('SHOW_DELETE_PROMPT', 'Y'));
  apex_json.write('enable_end_user_switch_conv_style', get_cfg('ENABLE_END_USER_SWITCH_CONV_STYLE', 'Y'));
  apex_json.write('enable_end_user_switch_profiles_agents', get_cfg('ENABLE_END_USER_SWITCH_PROFILES_AGENTS', 'Y'));
  apex_json.write('enable_end_user_switch_nl2sql_profile', get_cfg('ENABLE_END_USER_SWITCH_NL2SQL_PROFILE', 'Y'));
  apex_json.write('enable_end_user_switch_rag_profile', get_cfg('ENABLE_END_USER_SWITCH_RAG_PROFILE', 'Y'));
  apex_json.write('app_display_name', get_cfg('APP_DISPLAY_NAME', 'Oracle Select AI'));
  apex_json.write('prompt_bar_title', get_cfg('PROMPT_BAR_TITLE', 'Ask Oracle'));
  apex_json.write('prompt_placeholder', get_cfg('PROMPT_PLACEHOLDER', 'Ask Question'));
  apex_json.write('app_zoom_pct', get_zoom_pct);
  apex_json.write('retention_days', get_cfg('RETENTION_DAYS', '7'));
  apex_json.write(
    'current_conv_mode',
    get_cfg(
      'DEFAULT_CONVERSATION_MODE',
      nvl(apex_util.get_preference('CONVERSATION_TYPE', :APP_USER), 'CHAT_WITH_DB')
    )
  );

  l_theme_name := nvl(apex_util.get_preference('APP_THEME_STYLE', :APP_USER), 'Vita_Light');
  apex_json.write('current_theme', l_theme_name);

  apex_json.close_object;
end;

-- SETTINGS_DROP_AGENT_TEAM
declare
  l_team_name varchar2(261) := trim(apex_application.g_x01);

  function is_admin_user return boolean is
    l_schema_owner varchar2(255);
    l_admin_owner  varchar2(255);
  begin
    l_schema_owner := upper(trim(nvl(v('APP_SCHEMA'), user)));
    l_admin_owner := l_schema_owner;

    begin
      select upper(trim(config_value))
        into l_admin_owner
        from app_config
       where config_key = 'ADMIN_OWNER_APP_USER'
         and trim(config_value) is not null;
    exception
      when no_data_found then
        null;
      when others then
        null;
    end;

    return upper(trim(nvl(:APP_USER, ''))) = nvl(l_admin_owner, l_schema_owner);
  end;
begin
  if not is_admin_user then
    raise_application_error(-20040, 'Not authorized.');
  end if;

  if l_team_name is null then
    raise_application_error(-20110, 'Agent team name is required.');
  end if;

  dbms_cloud_ai_agent.drop_team(
    team_name => l_team_name,
    force     => true
  );

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.write('team_name', l_team_name);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.close_object;
end;

-- SETTINGS_SAVE_CONV_MODE
declare
  l_mode varchar2(100) := upper(trim(nvl(apex_application.g_x01, :P20000_CONV_TYPE)));
  l_saved varchar2(100);

  function is_admin_user return boolean is
    l_schema_owner varchar2(255);
    l_admin_owner  varchar2(255);
  begin
    l_schema_owner := upper(trim(nvl(v('APP_SCHEMA'), user)));
    l_admin_owner := l_schema_owner;

    begin
      select upper(trim(config_value))
        into l_admin_owner
        from app_config
       where config_key = 'ADMIN_OWNER_APP_USER'
         and trim(config_value) is not null;
    exception
      when no_data_found then
        null;
      when others then
        null;
    end;

    return upper(trim(nvl(:APP_USER, ''))) = nvl(l_admin_owner, l_schema_owner);
  end;
begin
  if l_mode not in ('CHAT_WITH_DB', 'RAG_PROFILES', 'USER_AGENTS') then
    raise_application_error(-20061, 'Invalid conversation mode.');
  end if;

  if not is_admin_user then
    raise_application_error(-20060, 'Not authorized.');
  end if;

  merge into app_config t
  using (
    select 'DEFAULT_CONVERSATION_MODE' as config_key, l_mode as config_value from dual
  ) s
     on (t.config_key = s.config_key)
  when matched then
    update set t.config_value = s.config_value,
               t.updated_by   = :APP_USER,
               t.updated_on   = systimestamp
  when not matched then
    insert (config_key, config_value, updated_by, updated_on)
    values (s.config_key, s.config_value, :APP_USER, systimestamp);

  select config_value
    into l_saved
    from app_config
   where config_key = 'DEFAULT_CONVERSATION_MODE';

  apex_util.set_preference(
    p_preference => 'CONVERSATION_TYPE',
    p_value      => l_saved,
    p_user       => :APP_USER
  );

  commit;

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.write('conversation_mode', l_saved);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    if sqlcode = -942 then
      apex_json.write('message', 'APP_CONFIG table not found in parsing schema.');
    else
      apex_json.write('message', sqlerrm);
    end if;
    apex_json.close_object;
end;

-- SETTINGS_GET_PROFILE_ATTRS
declare
  l_profile_name varchar2(261);
begin
  l_profile_name := trim(apex_application.g_x02);

  if l_profile_name is null then
    l_profile_name := case upper(apex_application.g_x01)
      when 'NL2SQL' then :P20000_SERVICE
      when 'RAG' then :P20000_RAGSERVICE
      else null
    end;
  end if;

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.write('profile_name', l_profile_name);
  apex_json.open_array('attributes');

  if l_profile_name is not null then
    for r in (
      SELECT
        ATTRIBUTE_NAME,
        CASE
          WHEN ATTRIBUTE_NAME = 'object_list' THEN (
            SELECT LISTAGG(owner || '.' || name, CHR(10)) WITHIN GROUP (ORDER BY owner, name)
              FROM JSON_TABLE(
                TO_CHAR(SUBSTR(ATTRIBUTE_VALUE, 1, 4000)),
                '$[*]'
                COLUMNS (
                  owner VARCHAR2(128) PATH '$.owner',
                  name  VARCHAR2(128) PATH '$.name'
                )
              )
          )
          ELSE TO_CHAR(ATTRIBUTE_VALUE)
        END AS ATTRIBUTE_VALUE
      FROM USER_CLOUD_AI_PROFILE_ATTRIBUTES
      WHERE PROFILE_NAME = l_profile_name
      ORDER BY
        CASE LOWER(ATTRIBUTE_NAME)
          WHEN 'provider' THEN 1
          WHEN 'credential_name' THEN 2
          WHEN 'model' THEN 3
          WHEN 'object_list' THEN 4
          WHEN 'oci_compartment_id' THEN 5
          ELSE 999
        END,
        ATTRIBUTE_NAME
    ) loop
      apex_json.open_object;
      apex_json.write('attribute_name', r.attribute_name);
      apex_json.write('attribute_value', r.attribute_value);
      apex_json.close_object;
    end loop;
  end if;

  apex_json.close_array;
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.close_object;
end;

-- SETTINGS_SAVE_PROFILE_ATTRS
declare
  l_profile_name varchar2(261);
  l_json         clob := apex_application.g_clob_01;
begin
  l_profile_name := trim(apex_application.g_x02);

  if l_profile_name is null then
    l_profile_name := case upper(apex_application.g_x01)
      when 'NL2SQL' then :P20000_SERVICE
      when 'RAG' then :P20000_RAGSERVICE
      else null
    end;
  end if;

  if l_profile_name is null then
    raise_application_error(-20011, 'Profile not selected.');
  end if;

  if l_json is null then
    raise_application_error(-20012, 'Attributes JSON is required.');
  end if;

  dbms_cloud_ai.set_attributes(
    profile_name => l_profile_name,
    attributes   => l_json
  );

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.close_object;
end;

-- SETTINGS_CREATE_PROFILE
declare
  l_profile_name varchar2(261) := trim(apex_application.g_x01);
  l_description  clob          := apex_application.g_x02;
  l_attrs_json   clob          := apex_application.g_clob_01;
  l_exists       number := 0;

  function is_admin_user return boolean is
    l_schema_owner varchar2(255);
    l_admin_owner  varchar2(255);
  begin
    l_schema_owner := upper(trim(nvl(v('APP_SCHEMA'), user)));
    l_admin_owner := l_schema_owner;

    begin
      select upper(trim(config_value))
        into l_admin_owner
        from app_config
       where config_key = 'ADMIN_OWNER_APP_USER'
         and trim(config_value) is not null;
    exception
      when no_data_found then
        null;
      when others then
        null;
    end;

    return upper(trim(nvl(:APP_USER, ''))) = nvl(l_admin_owner, l_schema_owner);
  end;
begin
  if not is_admin_user then
    raise_application_error(-20040, 'Not authorized.');
  end if;

  if l_profile_name is null then
    raise_application_error(-20031, 'Profile name is required.');
  end if;

  if l_attrs_json is null then
    raise_application_error(-20032, 'Attributes JSON is required.');
  end if;

  select count(*)
    into l_exists
    from user_cloud_ai_profiles
   where upper(profile_name) = upper(l_profile_name);

  if l_exists > 0 then
    raise_application_error(-20033, 'Profile name already exists.');
  end if;

  dbms_cloud_ai.create_profile(
    profile_name => l_profile_name,
    attributes   => l_attrs_json,
    description  => l_description
  );

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    if instr(upper(sqlerrm), 'DBMS_CLOUD_PIPELINE') > 0 then
      apex_json.write(
        'message',
        'Missing EXECUTE privilege on DBMS_CLOUD_PIPELINE. Ask DBA to grant EXECUTE on DBMS_CLOUD_PIPELINE to your APEX parsing schema.'
      );
    else
      apex_json.write('message', sqlerrm);
    end if;
    apex_json.close_object;
end;

-- SETTINGS_DROP_PROFILE
declare
  l_profile_name varchar2(261) := trim(apex_application.g_x01);

  function is_admin_user return boolean is
    l_schema_owner varchar2(255);
    l_admin_owner  varchar2(255);
  begin
    l_schema_owner := upper(trim(nvl(v('APP_SCHEMA'), user)));
    l_admin_owner := l_schema_owner;

    begin
      select upper(trim(config_value))
        into l_admin_owner
        from app_config
       where config_key = 'ADMIN_OWNER_APP_USER'
         and trim(config_value) is not null;
    exception
      when no_data_found then
        null;
      when others then
        null;
    end;

    return upper(trim(nvl(:APP_USER, ''))) = nvl(l_admin_owner, l_schema_owner);
  end;
begin
  if not is_admin_user then
    raise_application_error(-20040, 'Not authorized.');
  end if;

  if l_profile_name is null then
    raise_application_error(-20035, 'Profile name is required.');
  end if;

  dbms_cloud_ai.drop_profile(
    profile_name => l_profile_name
  );

  -- Clear saved preference if dropped profile was selected for current user.
  if apex_util.get_preference('CLOUD_AI_PROFILE1', :APP_USER) = l_profile_name then
    apex_util.set_preference(
      p_preference => 'CLOUD_AI_PROFILE1',
      p_value      => null,
      p_user       => :APP_USER
    );
  end if;

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.close_object;
end;

-- SETTINGS_CREATE_RAG_VECTOR_INDEX
declare
  l_index_name       varchar2(125) := trim(apex_application.g_x01);
  l_profile_name     varchar2(261) := trim(apex_application.g_x02);
  l_vector_provider  varchar2(200) := trim(apex_application.g_x03);
  l_credential_name  varchar2(261) := trim(apex_application.g_x04);
  l_location         varchar2(4000) := trim(apex_application.g_x05);
  l_status           varchar2(30) := trim(apex_application.g_x06);
  l_description      clob := apex_application.g_x07;
  l_wait_flag_raw    varchar2(10) := trim(apex_application.g_x08);
  l_extra_attrs      clob := apex_application.g_clob_01;
  l_attrs_json       clob;
  l_extra_trim       clob;
  l_extra_body       clob;
  l_base_prefix      clob;
  l_extra_len        number;
  l_wait_for_completion boolean := false;

  function is_admin_user return boolean is
    l_schema_owner varchar2(255);
    l_admin_owner  varchar2(255);
  begin
    l_schema_owner := upper(trim(nvl(v('APP_SCHEMA'), user)));
    l_admin_owner := l_schema_owner;

    begin
      select upper(trim(config_value))
        into l_admin_owner
        from app_config
       where config_key = 'ADMIN_OWNER_APP_USER'
         and trim(config_value) is not null;
    exception
      when no_data_found then
        null;
      when others then
        null;
    end;

    return upper(trim(nvl(:APP_USER, ''))) = nvl(l_admin_owner, l_schema_owner);
  end;

  function escape_json_text(p_text varchar2) return varchar2 is
    l_text varchar2(32767) := nvl(p_text, '');
  begin
    l_text := replace(l_text, '\', '\\');
    l_text := replace(l_text, '"', '\"');
    l_text := replace(l_text, chr(10), '\n');
    l_text := replace(l_text, chr(13), '\r');
    l_text := replace(l_text, chr(9), '\t');
    return l_text;
  end;
begin
  if not is_admin_user then
    raise_application_error(-20040, 'Not authorized.');
  end if;

  if l_index_name is null then
    raise_application_error(-20070, 'Vector index name is required.');
  end if;
  if l_profile_name is null then
    raise_application_error(-20071, 'Embedding profile name is required.');
  end if;
  if l_credential_name is null then
    raise_application_error(-20072, 'Object storage credential name is required.');
  end if;
  if l_location is null then
    raise_application_error(-20073, 'Location is required.');
  end if;

  if l_vector_provider is null then
    l_vector_provider := 'oracle';
  end if;

  l_attrs_json :=
      to_clob('{')
   || '"vector_db_provider":"' || escape_json_text(l_vector_provider) || '",'
   || '"object_storage_credential_name":"' || escape_json_text(l_credential_name) || '",'
   || '"profile_name":"' || escape_json_text(l_profile_name) || '",'
   || '"location":"' || escape_json_text(l_location) || '"'
   || '}';

  if l_extra_attrs is not null then
    l_extra_trim := trim(l_extra_attrs);
    if l_extra_trim is not null then
      l_extra_len := dbms_lob.getlength(l_extra_trim);
      if l_extra_len < 2
         or dbms_lob.substr(l_extra_trim, 1, 1) <> '{'
         or dbms_lob.substr(l_extra_trim, 1, l_extra_len) <> '}' then
        raise_application_error(-20074, 'Additional attributes must be a JSON object.');
      end if;

      l_extra_body := null;
      if l_extra_len > 2 then
        l_extra_body := trim(dbms_lob.substr(l_extra_trim, l_extra_len - 2, 2));
      end if;
      if l_extra_body is not null and l_extra_body <> '' then
        l_base_prefix := dbms_lob.substr(l_attrs_json, dbms_lob.getlength(l_attrs_json) - 1, 1);
        l_attrs_json := l_base_prefix || ',' || l_extra_body || '}';
      end if;
    end if;
  end if;

  if upper(nvl(l_wait_flag_raw, 'N')) in ('Y', 'YES', 'TRUE', '1') then
    l_wait_for_completion := true;
  end if;

  if l_status is not null then
    l_status := initcap(lower(l_status));
    if l_status not in ('Enabled', 'Disabled') then
      raise_application_error(-20076, 'Status must be Enabled or Disabled.');
    end if;
  end if;

  dbms_cloud_ai.create_vector_index(
    index_name          => l_index_name,
    attributes          => l_attrs_json,
    status              => l_status,
    description         => l_description,
    wait_for_completion => l_wait_for_completion
  );

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.close_object;
end;
-- SETTINGS_GET_AGENT_TEAM_DESC
declare
  l_team_name        varchar2(261) := trim(apex_application.g_x01);
  l_team_description varchar2(4000) := '';

  type t_str_tab is table of varchar2(4000);
  l_tasks t_str_tab := t_str_tab();
  l_tools t_str_tab := t_str_tab();

  type t_agent_pair_rec is record(
    agent_name varchar2(4000),
    task_name  varchar2(4000)
  );
  type t_agent_pair_tab is table of t_agent_pair_rec index by pls_integer;
  l_agent_pairs t_agent_pair_tab;
  l_agent_pair_count pls_integer := 0;

  type t_seen_set is table of pls_integer index by varchar2(5000);
  l_seen_pairs t_seen_set;
  l_seen_tasks t_seen_set;
  l_seen_tools t_seen_set;

  function normalize_key(p_value varchar2) return varchar2 is
  begin
    return upper(trim(nvl(p_value, '')));
  end;

  function clob_has_text(p_value clob) return boolean is
    l_text varchar2(4000);
  begin
    if p_value is null then
      return false;
    end if;
    l_text := trim(dbms_lob.substr(p_value, 4000, 1));
    return l_text is not null;
  exception
    when others then
      return false;
  end;

  procedure add_unique(
    p_list in out nocopy t_str_tab,
    p_seen in out nocopy t_seen_set,
    p_value in varchar2
  ) is
    l_value varchar2(4000) := trim(nvl(p_value, ''));
    l_key   varchar2(5000) := normalize_key(l_value);
  begin
    if l_value is null then
      return;
    end if;
    if p_seen.exists(l_key) then
      return;
    end if;
    p_seen(l_key) := 1;
    p_list.extend;
    p_list(p_list.count) := l_value;
  end;

  function get_agent_attr(p_agent_name varchar2, p_attr_name varchar2) return clob is
    l_val clob;
  begin
    select attribute_value
      into l_val
      from user_ai_agent_attributes
     where upper(agent_name) = upper(trim(p_agent_name))
       and lower(attribute_name) = lower(trim(p_attr_name))
       and rownum = 1;
    return l_val;
  exception
    when others then
      return null;
  end;

  function get_task_attr(p_task_name varchar2, p_attr_name varchar2) return clob is
    l_val clob;
  begin
    select attribute_value
      into l_val
      from user_ai_agent_task_attributes
     where upper(task_name) = upper(trim(p_task_name))
       and lower(attribute_name) = lower(trim(p_attr_name))
       and rownum = 1;
    return l_val;
  exception
    when others then
      return null;
  end;

  function get_tool_attr(p_tool_name varchar2, p_attr_name varchar2) return clob is
    l_val clob;
  begin
    select attribute_value
      into l_val
      from user_ai_agent_tool_attributes
     where upper(tool_name) = upper(trim(p_tool_name))
       and lower(attribute_name) = lower(trim(p_attr_name))
       and rownum = 1;
    return l_val;
  exception
    when others then
      return null;
  end;

  function get_agent_description(p_agent_name varchar2) return varchar2 is
    l_val varchar2(4000);
  begin
    select nvl(max(substr(to_char(description), 1, 4000)), '')
      into l_val
      from user_ai_agents
     where upper(agent_name) = upper(trim(p_agent_name));
    return l_val;
  exception
    when others then
      return '';
  end;

  function get_task_description(p_task_name varchar2) return varchar2 is
    l_val varchar2(4000);
  begin
    select nvl(max(substr(to_char(description), 1, 4000)), '')
      into l_val
      from user_ai_agent_tasks
     where upper(task_name) = upper(trim(p_task_name));
    return l_val;
  exception
    when others then
      return '';
  end;

  function get_tool_description(p_tool_name varchar2) return varchar2 is
    l_val varchar2(4000);
  begin
    select nvl(max(substr(to_char(description), 1, 4000)), '')
      into l_val
      from user_ai_agent_tools
     where upper(tool_name) = upper(trim(p_tool_name));
    return l_val;
  exception
    when others then
      return '';
  end;

  procedure write_attr_row(
    p_entity_key varchar2,
    p_entity_value varchar2,
    p_attr_name varchar2,
    p_attr_value clob
  ) is
  begin
    if not clob_has_text(p_attr_value) then
      return;
    end if;
    apex_json.open_object;
    apex_json.write(p_entity_key, p_entity_value);
    apex_json.write('attribute_name', p_attr_name);
    apex_json.write('attribute_value', p_attr_value);
    apex_json.close_object;
  end;

  procedure write_meta_row(
    p_entity_key varchar2,
    p_entity_value varchar2,
    p_description varchar2
  ) is
  begin
    if trim(nvl(p_entity_value, '')) is null then
      return;
    end if;
    apex_json.open_object;
    apex_json.write(p_entity_key, p_entity_value);
    apex_json.write('description', nvl(p_description, ''));
    apex_json.close_object;
  end;

begin
  if l_team_name is null then
    l_team_name := trim(:P20000_AGENT_SERVICE);
  end if;

  if l_team_name is not null then
    begin
      select nvl(max(substr(to_char(description), 1, 4000)), '')
        into l_team_description
        from user_ai_agent_teams
       where upper(agent_team_name) = upper(l_team_name);
    exception
      when others then
        l_team_description := '';
    end;

    begin
      for r in (
        select jt.agent_name,
               jt.task_name
          from user_ai_agent_team_attributes ta,
               json_table(
                 ta.attribute_value,
                 '$[*]' columns (
                   agent_name varchar2(4000) path '$.name',
                   task_name  varchar2(4000) path '$.task'
                 )
               ) jt
         where upper(ta.agent_team_name) = upper(l_team_name)
           and lower(ta.attribute_name) = 'agents'
      ) loop
        declare
          l_agent_name varchar2(4000) := trim(nvl(r.agent_name, ''));
          l_task_name  varchar2(4000) := trim(nvl(r.task_name, ''));
          l_pair_key   varchar2(5000) := normalize_key(r.agent_name) || '|' || normalize_key(r.task_name);
        begin
          if l_agent_name is null then
            null;
          elsif not l_seen_pairs.exists(l_pair_key) then
            l_seen_pairs(l_pair_key) := 1;
            l_agent_pair_count := l_agent_pair_count + 1;
            l_agent_pairs(l_agent_pair_count).agent_name := l_agent_name;
            l_agent_pairs(l_agent_pair_count).task_name := l_task_name;
          end if;
          add_unique(l_tasks, l_seen_tasks, l_task_name);
        end;
      end loop;
    exception
      when others then
        null;
    end;

    for i in 1 .. l_tasks.count loop
      begin
        for t in (
          select jt.tool_name
            from user_ai_agent_task_attributes ta,
                 json_table(
                   ta.attribute_value,
                   '$[*]' columns (
                     tool_name varchar2(4000) path '$'
                   )
                 ) jt
           where upper(ta.task_name) = upper(l_tasks(i))
             and lower(ta.attribute_name) = 'tools'
        ) loop
          add_unique(l_tools, l_seen_tools, t.tool_name);
        end loop;
      exception
        when others then
          null;
      end;
    end loop;
  end if;

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.write('team_description', l_team_description);

  apex_json.open_array('agents_json');
  for i in 1 .. l_agent_pair_count loop
    apex_json.open_object;
    apex_json.write('agent_name', l_agent_pairs(i).agent_name);
    apex_json.write('task_name', l_agent_pairs(i).task_name);
    apex_json.close_object;
  end loop;
  apex_json.close_array;

  apex_json.open_array('tasks_json');
  for i in 1 .. l_tasks.count loop
    apex_json.open_object;
    apex_json.write('task_name', l_tasks(i));
    apex_json.close_object;
  end loop;
  apex_json.close_array;

  apex_json.open_array('tools_json');
  for i in 1 .. l_tools.count loop
    apex_json.open_object;
    apex_json.write('tool_name', l_tools(i));
    apex_json.close_object;
  end loop;
  apex_json.close_array;

  apex_json.open_array('team_attributes_json');
  if l_team_name is not null then
    for r in (
      select attribute_name,
             attribute_value
        from user_ai_agent_team_attributes
       where upper(agent_team_name) = upper(l_team_name)
         and lower(attribute_name) in ('agents', 'process')
       order by case lower(attribute_name)
                  when 'agents' then 1
                  when 'process' then 2
                  else 99
                end,
                attribute_name
    ) loop
      apex_json.open_object;
      apex_json.write('attribute_name', r.attribute_name);
      apex_json.write('attribute_value', r.attribute_value);
      apex_json.close_object;
    end loop;
  end if;
  apex_json.close_array;

  apex_json.open_array('agent_attributes_json');
  for i in 1 .. l_agent_pair_count loop
    write_attr_row('agent_name', l_agent_pairs(i).agent_name, 'profile_name', get_agent_attr(l_agent_pairs(i).agent_name, 'profile_name'));
    write_attr_row('agent_name', l_agent_pairs(i).agent_name, 'role', get_agent_attr(l_agent_pairs(i).agent_name, 'role'));
    write_attr_row('agent_name', l_agent_pairs(i).agent_name, 'enable_human_tool', get_agent_attr(l_agent_pairs(i).agent_name, 'enable_human_tool'));
  end loop;
  apex_json.close_array;

  apex_json.open_array('task_attributes_json');
  for i in 1 .. l_tasks.count loop
    write_attr_row('task_name', l_tasks(i), 'instruction', get_task_attr(l_tasks(i), 'instruction'));
    write_attr_row('task_name', l_tasks(i), 'tools', get_task_attr(l_tasks(i), 'tools'));
    write_attr_row('task_name', l_tasks(i), 'input', get_task_attr(l_tasks(i), 'input'));
    write_attr_row('task_name', l_tasks(i), 'enable_human_tool', get_task_attr(l_tasks(i), 'enable_human_tool'));
  end loop;
  apex_json.close_array;

  apex_json.open_array('tool_attributes_json');
  for i in 1 .. l_tools.count loop
    write_attr_row('tool_name', l_tools(i), 'instruction', get_tool_attr(l_tools(i), 'instruction'));
    write_attr_row('tool_name', l_tools(i), 'function', get_tool_attr(l_tools(i), 'function'));
    write_attr_row('tool_name', l_tools(i), 'tool_type', get_tool_attr(l_tools(i), 'tool_type'));
    write_attr_row('tool_name', l_tools(i), 'tool_params', get_tool_attr(l_tools(i), 'tool_params'));
    write_attr_row('tool_name', l_tools(i), 'tool_inputs', get_tool_attr(l_tools(i), 'tool_inputs'));
  end loop;
  apex_json.close_array;

  apex_json.open_array('team_meta_json');
  if l_team_name is not null then
    write_meta_row('agent_team_name', l_team_name, l_team_description);
  end if;
  apex_json.close_array;

  apex_json.open_array('agent_meta_json');
  for i in 1 .. l_agent_pair_count loop
    write_meta_row('agent_name', l_agent_pairs(i).agent_name, get_agent_description(l_agent_pairs(i).agent_name));
  end loop;
  apex_json.close_array;

  apex_json.open_array('task_meta_json');
  for i in 1 .. l_tasks.count loop
    write_meta_row('task_name', l_tasks(i), get_task_description(l_tasks(i)));
  end loop;
  apex_json.close_array;

  apex_json.open_array('tool_meta_json');
  for i in 1 .. l_tools.count loop
    write_meta_row('tool_name', l_tools(i), get_tool_description(l_tools(i)));
  end loop;
  apex_json.close_array;

  apex_json.open_array('attributes_json');
  apex_json.close_array;

  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.write('team_description', '');

    apex_json.open_array('agents_json'); apex_json.close_array;
    apex_json.open_array('tasks_json'); apex_json.close_array;
    apex_json.open_array('tools_json'); apex_json.close_array;
    apex_json.open_array('team_attributes_json'); apex_json.close_array;
    apex_json.open_array('agent_attributes_json'); apex_json.close_array;
    apex_json.open_array('task_attributes_json'); apex_json.close_array;
    apex_json.open_array('tool_attributes_json'); apex_json.close_array;
    apex_json.open_array('team_meta_json'); apex_json.close_array;
    apex_json.open_array('agent_meta_json'); apex_json.close_array;
    apex_json.open_array('task_meta_json'); apex_json.close_array;
    apex_json.open_array('tool_meta_json'); apex_json.close_array;
    apex_json.open_array('attributes_json'); apex_json.close_array;

    apex_json.close_object;
end;
-- SETTINGS_SAVE_ADMIN_CONFIG
declare
  l_key     varchar2(100) := upper(trim(apex_application.g_x01));
  l_raw     varchar2(4000) := trim(apex_application.g_x02);
  l_value   varchar2(4000);
  l_saved   varchar2(4000);
  l_zoom_no number;
  l_retention_days number;

  function is_admin_user return boolean is
    l_schema_owner varchar2(255);
    l_admin_owner  varchar2(255);
  begin
    l_schema_owner := upper(trim(nvl(v('APP_SCHEMA'), user)));
    l_admin_owner := l_schema_owner;

    begin
      select upper(trim(config_value))
        into l_admin_owner
        from app_config
       where config_key = 'ADMIN_OWNER_APP_USER'
         and trim(config_value) is not null;
    exception
      when no_data_found then
        null;
      when others then
        null;
    end;

    return upper(trim(nvl(:APP_USER, ''))) = nvl(l_admin_owner, l_schema_owner);
  end;
begin
  if l_key not in (
    'SHOW_OPEN_IN_EDITOR',
    'SHOW_AGENT_THOUGHTS',
    'SHOW_EXPORT_PDF',
    'SHOW_EXPORT_EXCEL',
    'SHOW_CONVERSATION_TIMER',
    'SHOW_DELETE_PROMPT',
    'ENABLE_END_USER_SWITCH_CONV_STYLE',
    'ENABLE_END_USER_SWITCH_PROFILES_AGENTS',
    'ENABLE_END_USER_SWITCH_NL2SQL_PROFILE',
    'ENABLE_END_USER_SWITCH_RAG_PROFILE',
    'APP_DISPLAY_NAME',
    'PROMPT_BAR_TITLE',
    'PROMPT_PLACEHOLDER',
    'RETENTION_DAYS',
    'APP_ZOOM_PCT'
  ) then
    raise_application_error(-20041, 'Invalid config key.');
  end if;

  if l_key <> 'APP_ZOOM_PCT' and not is_admin_user then
    raise_application_error(-20040, 'Not authorized.');
  end if;

  if l_key = 'APP_ZOOM_PCT' then
    begin
      l_zoom_no := nvl(to_number(l_raw), 100);
    exception
      when others then
        l_zoom_no := 100;
    end;
    l_zoom_no := round(l_zoom_no / 5) * 5;
    l_zoom_no := greatest(80, least(200, l_zoom_no));
    l_value := to_char(l_zoom_no);

    apex_util.set_preference(
      p_preference => 'APP_ZOOM_PCT',
      p_value      => l_value,
      p_user       => :APP_USER
    );

    l_saved := nvl(apex_util.get_preference('APP_ZOOM_PCT', :APP_USER), l_value);
    commit;

    apex_json.open_object;
    apex_json.write('success', true);
    apex_json.write('config_key', l_key);
    apex_json.write('config_value', l_saved);
    apex_json.close_object;
  elsif l_key = 'RETENTION_DAYS' then
    begin
      l_retention_days := nvl(to_number(l_raw), 7);
    exception
      when others then
        l_retention_days := 7;
    end;
    l_retention_days := greatest(1, least(3650, trunc(l_retention_days)));
    l_value := to_char(l_retention_days);

    merge into app_config t
    using (select l_key as config_key, l_value as config_value from dual) s
       on (t.config_key = s.config_key)
    when matched then
      update set t.config_value = s.config_value,
                 t.updated_by   = :APP_USER,
                 t.updated_on   = systimestamp
    when not matched then
      insert (config_key, config_value, updated_by, updated_on)
      values (s.config_key, s.config_value, :APP_USER, systimestamp);

    select config_value
      into l_saved
      from app_config
     where config_key = l_key;

    commit;

    apex_json.open_object;
    apex_json.write('success', true);
    apex_json.write('config_key', l_key);
    apex_json.write('config_value', l_saved);
    apex_json.close_object;
  elsif l_key in ('APP_DISPLAY_NAME', 'PROMPT_BAR_TITLE', 'PROMPT_PLACEHOLDER') then
    l_value := trim(l_raw);
    if l_key = 'APP_DISPLAY_NAME' then
      l_value := substr(nvl(l_value, 'Oracle Select AI'), 1, 200);
      if trim(l_value) is null then
        l_value := 'Oracle Select AI';
      end if;
    elsif l_key = 'PROMPT_BAR_TITLE' then
      l_value := substr(nvl(l_value, 'Ask Oracle'), 1, 120);
      if trim(l_value) is null then
        l_value := 'Ask Oracle';
      end if;
    else
      l_value := substr(nvl(l_value, 'Ask Question'), 1, 160);
      if trim(l_value) is null then
        l_value := 'Ask Question';
      end if;
    end if;

    merge into app_config t
    using (select l_key as config_key, l_value as config_value from dual) s
       on (t.config_key = s.config_key)
    when matched then
      update set t.config_value = s.config_value,
                 t.updated_by   = :APP_USER,
                 t.updated_on   = systimestamp
    when not matched then
      insert (config_key, config_value, updated_by, updated_on)
      values (s.config_key, s.config_value, :APP_USER, systimestamp);

    select config_value
      into l_saved
      from app_config
     where config_key = l_key;

    commit;

    apex_json.open_object;
    apex_json.write('success', true);
    apex_json.write('config_key', l_key);
    apex_json.write('config_value', l_saved);
    apex_json.close_object;
  else
    l_value := case upper(l_raw) when 'Y' then 'Y' else 'N' end;
    merge into app_config t
    using (select l_key as config_key, l_value as config_value from dual) s
       on (t.config_key = s.config_key)
    when matched then
      update set t.config_value = s.config_value,
                 t.updated_by   = :APP_USER,
                 t.updated_on   = systimestamp
    when not matched then
      insert (config_key, config_value, updated_by, updated_on)
      values (s.config_key, s.config_value, :APP_USER, systimestamp);

    select config_value
      into l_saved
      from app_config
     where config_key = l_key;

    commit;

    apex_json.open_object;
    apex_json.write('success', true);
    apex_json.write('config_key', l_key);
    apex_json.write('config_value', l_saved);
    apex_json.close_object;
  end if;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    if sqlcode = -942 then
      apex_json.write('message', 'APP_CONFIG table not found in parsing schema.');
    else
      apex_json.write('message', sqlerrm);
    end if;
    apex_json.close_object;
end;

-- SETTINGS_SET_THEME
declare
  l_theme_name varchar2(100) := trim(apex_application.g_x01);
begin
  if l_theme_name not in ('Vita_Light', 'Vita_Dark_Insight') then
    raise_application_error(-20050, 'Invalid theme.');
  end if;

  apex_theme.clear_all_users_style(
    p_application_id => :APP_ID,
    p_theme_number   => 42
  );

  set_theme_style_for_app(
    p_app_id           => :APP_ID,
    p_user             => :APP_USER,
    p_theme_style_name => l_theme_name
  );

  apex_util.set_preference(
    p_preference => 'APP_THEME_STYLE',
    p_value      => l_theme_name,
    p_user       => :APP_USER
  );

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.close_object;
end;

-- SETTINGS_DROP_RAG_VECTOR_INDEX
declare
  l_index_name varchar2(261) := trim(apex_application.g_x01);

  function is_admin_user return boolean is
    l_schema_owner varchar2(255);
    l_admin_owner  varchar2(255);
  begin
    l_schema_owner := upper(trim(nvl(v('APP_SCHEMA'), user)));
    l_admin_owner := l_schema_owner;

    begin
      select upper(trim(config_value))
        into l_admin_owner
        from app_config
       where config_key = 'ADMIN_OWNER_APP_USER'
         and trim(config_value) is not null;
    exception
      when no_data_found then
        null;
      when others then
        null;
    end;

    return upper(trim(nvl(:APP_USER, ''))) = nvl(l_admin_owner, l_schema_owner);
  end;
begin
  if not is_admin_user then
    raise_application_error(-20040, 'Not authorized.');
  end if;

  if l_index_name is null then
    raise_application_error(-20075, 'Vector index name is required.');
  end if;

  dbms_cloud_ai.drop_vector_index(
    index_name => l_index_name
  );

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.close_object;
end;
-- SETTINGS_SAVE_AGENT_ENTITY
declare
  l_entity_type varchar2(30) := upper(trim(apex_application.g_x01));
  l_entity_name varchar2(261) := trim(apex_application.g_x02);
  l_description clob := apex_application.g_x03;
  l_attrs_json  clob := apex_application.g_clob_01;

  function is_admin_user return boolean is
    l_schema_owner varchar2(255);
    l_admin_owner  varchar2(255);
  begin
    l_schema_owner := upper(trim(nvl(v('APP_SCHEMA'), user)));
    l_admin_owner := l_schema_owner;

    begin
      select upper(trim(config_value))
        into l_admin_owner
        from app_config
       where config_key = 'ADMIN_OWNER_APP_USER'
         and trim(config_value) is not null;
    exception
      when no_data_found then
        null;
      when others then
        null;
    end;

    return upper(trim(nvl(:APP_USER, ''))) = nvl(l_admin_owner, l_schema_owner);
  end;
begin
  if not is_admin_user then
    raise_application_error(-20040, 'Not authorized.');
  end if;

  if l_entity_type not in ('TEAM', 'AGENT', 'TASK', 'TOOL') then
    raise_application_error(-20100, 'Unsupported entity type.');
  end if;

  if l_entity_name is null then
    raise_application_error(-20101, 'Entity name is required.');
  end if;

  if l_attrs_json is null then
    raise_application_error(-20102, 'Attributes JSON is required.');
  end if;

  case l_entity_type
    when 'TEAM' then
      begin
        dbms_cloud_ai_agent.drop_team(
          team_name => l_entity_name,
          force     => true
        );
      exception
        when others then
          null;
      end;

      dbms_cloud_ai_agent.create_team(
        team_name   => l_entity_name,
        attributes  => l_attrs_json,
        description => l_description
      );

    when 'AGENT' then
      begin
        dbms_cloud_ai_agent.drop_agent(
          agent_name => l_entity_name,
          force      => true
        );
      exception
        when others then
          null;
      end;

      dbms_cloud_ai_agent.create_agent(
        agent_name   => l_entity_name,
        attributes   => l_attrs_json,
        description  => l_description
      );

    when 'TASK' then
      begin
        dbms_cloud_ai_agent.drop_task(
          task_name => l_entity_name,
          force     => true
        );
      exception
        when others then
          null;
      end;

      dbms_cloud_ai_agent.create_task(
        task_name    => l_entity_name,
        attributes   => l_attrs_json,
        description  => l_description
      );

    when 'TOOL' then
      begin
        dbms_cloud_ai_agent.drop_tool(
          tool_name => l_entity_name,
          force     => true
        );
      exception
        when others then
          null;
      end;

      dbms_cloud_ai_agent.create_tool(
        tool_name    => l_entity_name,
        attributes   => l_attrs_json,
        description  => l_description
      );
  end case;

  apex_json.open_object;
  apex_json.write('success', true);
  apex_json.close_object;
exception
  when others then
    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('message', sqlerrm);
    apex_json.close_object;
end;
