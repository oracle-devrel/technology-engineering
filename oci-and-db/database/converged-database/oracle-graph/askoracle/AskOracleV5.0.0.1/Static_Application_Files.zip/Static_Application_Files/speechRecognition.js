if ("webkitSpeechRecognition" in window) {
  const micBtn = document.querySelector(".llm-recording");
  let speechRecognition = new webkitSpeechRecognition();
  let recording = false;
  let final_transcript = "";
  let baseText = "";

  // Configure recognition
  speechRecognition.continuous = true;
  speechRecognition.interimResults = true;
  speechRecognition.lang = "en-US";

  speechRecognition.onstart = () => {
    const el = document.getElementById("P1_PROMPT1");
    // Capture whatever is already typed to append to it
    baseText = (el?.value || "").replace(/\s+$/,"");
    final_transcript = ""; // reset for new session
    console.log("Speech recognition started");

    var btn = document.getElementById("runPrompt");
    btn.disabled = true;
    btn.style.backgroundColor = "#555";  // gray look
    btn.style.cursor = "not-allowed";

  };

  speechRecognition.onerror = (event) => {
    console.error("Speech recognition error:", event.error);
  };

  speechRecognition.onend = () => {
    recording = false;
    if (micBtn) {
      $(micBtn).removeClass("fa-stop-circle fa-anim-flash").addClass("fa-microphone");
    }

      var btn = document.getElementById("runPrompt");
      btn.disabled = false;
      btn.style.backgroundColor = "#121313"; 
      btn.style.cursor = "pointer";

    console.log("Speech recognition stopped");
  };

  speechRecognition.onresult = (event) => {
    let interim_transcript = "";

    for (let i = event.resultIndex; i < event.results.length; ++i) {
      const chunk = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        final_transcript += chunk;
      } else {
        interim_transcript += chunk;
      }
    }

    const el = document.getElementById("P1_PROMPT1");
    if (!el) return;

    // Rebuild value each time: base (captured at start) + final + interim
    const prefix = baseText ? baseText + " " : "";
    el.value = (prefix + (final_transcript + interim_transcript).trimStart());

    // Keep cursor at end
    el.selectionStart = el.selectionEnd = el.value.length;
  };

  // 🎤 Mic toggle
  document.querySelector(".llm-recording").onclick = function () {
    if (recording) {
      speechRecognition.stop(); // onend will handle UI reset
    } else {
      recording = true;
      $(this).removeClass("fa-microphone").addClass("fa-stop-circle fa-anim-flash");
      speechRecognition.start();
    }
  };
} else {
  console.log("Speech Recognition Not Available");
}
