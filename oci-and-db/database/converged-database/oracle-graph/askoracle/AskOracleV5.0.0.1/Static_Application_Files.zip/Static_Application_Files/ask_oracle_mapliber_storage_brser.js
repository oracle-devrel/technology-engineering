/* Ask Oracle browser drawing storage v1.1.0.
 * Load AFTER ask_oracle_mapliber_drawing.js v1.2.0.
 * PART 1: browser storage only. No Oracle writes, network calls or analysis.
 * IndexedDB stores named drawing sets and up to 100 Undo/Redo steps per set.
 * Completed draws/deletions/clears/undo/redo are autosaved; previews are excluded.
 * Save drawings names/checkpoints the current set; Load drawings replaces only
 * the current map's annotations, never its district/results source or selection.
 * Save optionally edits per-feature names and scalar custom attributes.
 * Delete saved set / Clear all saved drawings require confirmation and delete
 * only this app/account scope, including history. Visible map drawings remain;
 * affected maps pause autosave until explicit Save drawings or Load drawings.
 * Data belongs to this browser/origin. Site-data clearing/private mode/browser
 * eviction may remove it. This is local recovery, not a secure backup service.
 */
(function () {
  'use strict';
  if (window.askOracleMapBrowserStorage) return;
  const DB = 'ask-oracle-drawing-storage', STORE = 'drawingSets', LIMIT = 101;
  const copy = value => JSON.parse(JSON.stringify(value));
  const ports = new Set();
  let opening, connectedApi, stopped = false, maintenance = false;
  const channel = window.BroadcastChannel ? new window.BroadcastChannel(DB + '-changes') : null;
  function notifyDeleted(message) {
    ports.forEach(session => session.deleted(message));
  }
  if (channel) channel.onmessage = event => {
    const message = event.data;
    if (message?.type === 'deleted' && typeof message.scope === 'string' && Array.isArray(message.keys)) notifyDeleted(message);
  };
  // Scope is stable across APEX sessions. Never use response IDs or session IDs
  // as the storage key: both can change after a page refresh.
  function scope() {
    const env = window.apex?.env || {};
    return JSON.stringify([env.APP_ID || window.location.pathname, env.APP_USER || 'browser-local']);
  }
  function key() { return window.crypto.randomUUID(); }
  function openDB() {
    if (opening) return opening;
    opening = new Promise((resolve, reject) => {
      if (!window.indexedDB) { reject(new Error('IndexedDB is unavailable in this browser.')); return; }
      let settled = false;
      const request = window.indexedDB.open(DB, 1);
      const fail = error => { if (!settled) { settled = true; reject(error); } };
      request.onupgradeneeded = () => {
        const db = request.result;
        const store = db.createObjectStore(STORE, { keyPath: 'key' });
        store.createIndex('scope', 'scope', { unique: false });
      };
      request.onerror = () => fail(request.error || new Error('Cannot open browser storage.'));
      request.onblocked = () => fail(new Error('Browser storage is blocked by another tab. Close that tab and retry Save drawings.'));
      request.onsuccess = () => {
        if (settled || stopped) { request.result.close(); fail(new Error('Storage was closed.')); return; }
        settled = true; const db = request.result;
        db.onversionchange = () => { db.close(); opening = null; };
        resolve(db);
      };
    }).catch(error => { opening = null; throw error; });
    return opening;
  }
  async function read(action) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const request = action(tx.objectStore(STORE));
      tx.oncomplete = () => resolve(request.result);
      tx.onabort = tx.onerror = () => reject(tx.error || request.error || new Error('Cannot read browser storage.'));
    });
  }
  async function write(record, expectedRevision) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite'), store = tx.objectStore(STORE);
      let error;
      const request = store.get(record.key);
      request.onsuccess = () => {
        if ((request.result?.revision || 0) !== expectedRevision) {
          error = new Error('This set changed in another map or tab. Choose Save drawings to save your work as a separate copy.');
          error.conflict = true; tx.abort(); return;
        }
        store.put({ ...record, revision: expectedRevision + 1 });
      };
      tx.oncomplete = () => resolve(expectedRevision + 1);
      tx.onabort = tx.onerror = () => reject(error || tx.error || new Error('Browser save failed. Storage may be full or blocked.'));
    });
  }
  async function removeSaved(savedScope, selectedKey) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite'), store = tx.objectStore(STORE), keys = [];
      const request = store.index('scope').openCursor(savedScope);
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) return;
        if (!selectedKey || cursor.value.key === selectedKey) { keys.push(cursor.value.key); cursor.delete(); }
        cursor.continue();
      };
      tx.oncomplete = () => resolve(keys);
      tx.onabort = tx.onerror = () => reject(tx.error || new Error('Could not delete saved drawings.'));
    });
  }
  function validate(record, expectedScope) {
    if (!record || record.version !== 1 || record.scope !== expectedScope || !Number.isSafeInteger(record.revision) || record.revision < 1 || !Array.isArray(record.history) || !record.history.length || record.history.length > LIMIT || !Number.isInteger(record.cursor) || record.cursor < 0 || record.cursor >= record.history.length) throw new Error('The saved drawing history is invalid.');
    const point = p => Array.isArray(p) && p.length === 2 && p.every(Number.isFinite) && Math.abs(p[1]) <= 90;
    record.history.forEach(features => {
      if (!Array.isArray(features)) throw new Error('Invalid saved drawing list.');
      const ids = new Set();
      features.forEach(f => {
        if (f?.type !== 'Feature' || !Number.isSafeInteger(f.id) || f.id < 1 || ids.has(f.id)) throw new Error('Invalid or duplicate drawing ID.');
        ids.add(f.id); const g = f.geometry, c = g?.coordinates;
        const valid = g?.type === 'Point' ? point(c) : g?.type === 'LineString' ? Array.isArray(c) && c.length >= 2 && c.every(point) : g?.type === 'Polygon' ? Array.isArray(c) && c.length > 0 && c.every(r => Array.isArray(r) && r.length >= 4 && r.every(point) && r[0][0] === r[r.length - 1][0] && r[0][1] === r[r.length - 1][1]) : false;
        if (!valid) throw new Error('Invalid saved geometry.');
      });
    });
    return copy(record);
  }
  function loadCursor(record) {
    if (record.history?.[record.cursor]?.length) return record.cursor;
    // Clear/Delete autosaves an empty state. Loading explicitly recovers the
    // latest non-empty snapshot still retained, without rewriting stored data
    // or changing the Save/Delete/Clear/Undo/Redo handlers.
    for (let i = (record.history?.length || 0) - 1; i >= 0; i--) {
      if (record.history[i]?.length) return i;
    }
    return record.cursor;
  }
  function choose(records, onDialog, deleting = false) {
    return new Promise(resolve => {
      const dialog = document.createElement('dialog');
      dialog.style.cssText = 'max-width:560px;width:90%;padding:20px;border:1px solid #bac6d2;border-radius:8px;background:white;color:#172b3a;';
      dialog.setAttribute('aria-label', deleting ? 'Delete saved set' : 'Load saved drawings');
      const heading = document.createElement('h3'); heading.textContent = deleting ? 'Delete saved set' : 'Load drawings';
      const note = document.createElement('p'); note.textContent = deleting ? 'Choose one saved set. Deletion removes its browser data and saved Undo/Redo history, not district data.' : 'Replace this map\'s drawings with a saved set. Districts are unchanged. Other saved sets are kept.';
      const label = document.createElement('label'); label.textContent = 'Saved drawing set: ';
      const select = document.createElement('select'); select.style.cssText = 'display:block;width:100%;margin:12px 0;padding:6px;';
      records.forEach(record => {
        const option = document.createElement('option'); option.value = record.key;
        const count = record.history?.[loadCursor(record)]?.length || 0;
        option.textContent = record.title + ' - ' + count + ' drawings - ' + new Date(record.updatedAt).toLocaleString();
        select.appendChild(option);
      });
      label.appendChild(select);
      const load = document.createElement('button'), cancel = document.createElement('button');
      load.type = cancel.type = 'button'; load.textContent = deleting ? 'Choose set' : 'Load'; cancel.textContent = 'Cancel';
      load.className = cancel.className = 't-Button t-Button--small'; cancel.style.marginLeft = '8px';
      let done = false;
      const finish = value => { if (done) return; done = true; dialog.close(); dialog.remove(); onDialog(null); resolve(value); };
      load.addEventListener('click', () => finish(select.value)); cancel.addEventListener('click', () => finish(null));
      dialog.addEventListener('cancel', e => { e.preventDefault(); finish(null); });
      dialog.append(heading, note, label, load, cancel); document.body.appendChild(dialog);
      onDialog(() => finish(null)); dialog.showModal(); select.focus();
    });
  }
  function editAttributes(features, onDialog) {
    const draft = copy(features);
    return new Promise(resolve => {
      const make = (tag, text) => { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; return node; };
      const dialog = make('dialog');
      dialog.style.cssText = 'width:90%;max-width:640px;max-height:85vh;overflow:auto;padding:20px;border:1px solid #bac6d2;border-radius:8px;background:white;color:#172b3a;';
      dialog.setAttribute('aria-label', 'Optional feature attributes');
      const featureSelect = make('select'), name = make('input'), fields = make('div'), error = make('p');
      error.setAttribute('role', 'alert'); error.style.color = '#b42318'; name.type = 'text'; name.maxLength = 160;
      const label = (text, control) => { const node = make('label', text); control.style.cssText = 'display:block;width:100%;padding:6px;margin:6px 0 12px;box-sizing:border-box;'; node.appendChild(control); return node; };
      const caption = f => f.properties?.name || (f.geometry.type === 'LineString' ? 'Line' : f.geometry.type) + ' ' + f.id;
      draft.forEach((f, i) => { const option = make('option', caption(f)); option.value = String(i); featureSelect.appendChild(option); });
      let current = 0, rows = [], done = false;
      const reserved = new Set(['name', 'drawing', '__proto__', 'prototype', 'constructor']);
      const scalar = v => ['string', 'number', 'boolean'].includes(typeof v);
      function addField(key = '', value = '') {
        const row = make('div'); row.style.cssText = 'display:flex;gap:6px;align-items:center;margin:8px 0;';
        const field = make('input'), input = make('input'), type = make('select'), remove = make('button', 'Remove');
        field.value = key; field.placeholder = 'Attribute name'; field.maxLength = 80; field.setAttribute('aria-label', 'Attribute name');
        input.value = String(value); input.placeholder = 'Value'; input.maxLength = 4000; input.setAttribute('aria-label', 'Attribute value');
        field.style.width = input.style.width = '30%';
        ['text', 'number', 'boolean'].forEach(t => { const option = make('option', t); option.value = t; type.appendChild(option); });
        type.value = typeof value === 'number' ? 'number' : typeof value === 'boolean' ? 'boolean' : 'text'; type.setAttribute('aria-label', 'Attribute type');
        const entry = { row, field, input, type }; rows.push(entry);
        remove.type = 'button'; remove.addEventListener('click', () => { rows = rows.filter(r => r !== entry); row.remove(); });
        row.append(field, type, input, remove); fields.appendChild(row);
      }
      function display() {
        const p = draft[current].properties || {}; name.value = typeof p.name === 'string' ? p.name : '';
        fields.replaceChildren(); rows = []; error.textContent = '';
        Object.keys(p).forEach(k => { if (!reserved.has(k) && scalar(p[k])) addField(k, p[k]); });
      }
      function capture() {
        const old = draft[current].properties || {}, p = copy(old), seen = new Set();
        Object.keys(p).forEach(k => { if (!reserved.has(k) && scalar(p[k])) delete p[k]; });
        if (name.value.trim()) p.name = name.value.trim(); else delete p.name;
        for (const entry of rows) {
          const k = entry.field.value.trim(), raw = entry.input.value;
          if (!k && !raw) continue;
          if (!k || reserved.has(k) || seen.has(k)) { error.textContent = 'Use unique attribute names. name, drawing, constructor, prototype and __proto__ are reserved.'; return false; }
          seen.add(k); let value = raw;
          if (entry.type.value === 'number') { value = Number(raw); if (!raw.trim() || !Number.isFinite(value)) { error.textContent = 'Enter a valid number for ' + k; return false; } }
          if (entry.type.value === 'boolean') { if (!/^(true|false)$/i.test(raw.trim())) { error.textContent = 'Use true or false for ' + k; return false; } value = raw.trim().toLowerCase() === 'true'; }
          p[k] = value;
        }
        draft[current].properties = p; featureSelect.options[current].textContent = caption(draft[current]); return true;
      }
      featureSelect.addEventListener('change', () => {
        if (!capture()) { featureSelect.value = String(current); return; }
        current = Number(featureSelect.value); display();
      });
      const add = make('button', 'Add attribute'), apply = make('button', 'Use attributes and save'), cancel = make('button', 'Cancel');
      [add, apply, cancel].forEach(b => { b.type = 'button'; b.className = 't-Button t-Button--small'; });
      const finish = result => { if (done) return; done = true; dialog.close(); dialog.remove(); onDialog(null); resolve(result); };
      add.addEventListener('click', () => addField()); apply.addEventListener('click', () => { if (capture()) finish(draft); }); cancel.addEventListener('click', () => finish(null));
      dialog.addEventListener('cancel', e => { e.preventDefault(); finish(null); });
      dialog.append(make('h3', 'Optional feature names and attributes'), make('p', 'Choose a feature to edit. All fields are optional. Unnamed features use labels such as Point 1. Switch features to edit more than one.'), label('Feature', featureSelect), label('Feature name (optional)', name), fields, add, error, apply, cancel);
      document.body.appendChild(dialog); display(); onDialog(() => finish(null)); dialog.showModal(); featureSelect.focus();
    });
  }
  function attach(port) {
    const initial = port.getDrawings();
    let record = { version: 1, key: key(), scope: scope(), title: 'Drawings ' + new Date().toLocaleString(), history: initial.length ? [[], initial] : [[]], cursor: initial.length ? 1 : 0 };
    let revision = 0, sequence = 0, queue = Promise.resolve(), busy = false, disposed = false, conflict = false, closeDialog, autosavePaused = false;
    const actions = [];
    const status = message => { if (!disposed && port.isAlive()) port.setStatus(message); };
    const action = (name, handler) => {
      const item = port.addAction(name, () => { if (!busy && !maintenance) Promise.resolve().then(handler).catch(error => status('Browser storage: ' + error.message)); });
      actions.push(item); return item;
    };
    function controls() {
      port.setBusy(busy || maintenance);
      actions.forEach(a => a.setDisabled(busy || maintenance));
      undo.setDisabled(busy || maintenance || record.cursor === 0);
      redo.setDisabled(busy || maintenance || record.cursor === record.history.length - 1);
    }
    function persist() {
      if (autosavePaused) { status('Saved data was deleted. Current map drawings are unsaved; choose Save drawings to store them again.'); return Promise.resolve(); }
      record.updatedAt = new Date().toISOString();
      const snapshot = copy(record), ticket = ++sequence;
      status('Saving drawings in this browser...');
      queue = queue.catch(() => {}).then(async () => {
        try {
          revision = await write(snapshot, revision); conflict = false;
          if (ticket === sequence) status('Saved in this browser: ' + snapshot.title + '. Undo/Redo history retained (up to 100 steps).');
        } catch (error) {
          conflict = !!error.conflict;
          status('NOT saved in browser: ' + error.message + ' Current drawings remain on the map.');
          throw error;
        }
      });
      // Every save error is visible, but must not become an unhandled rejection.
      queue.catch(() => {}); return queue;
    }
    function changed() {
      const features = port.getDrawings();
      if (JSON.stringify(features) === JSON.stringify(record.history[record.cursor])) return;
      record.history = record.history.slice(0, record.cursor + 1); record.history.push(features);
      if (record.history.length > LIMIT) record.history.shift();
      record.cursor = record.history.length - 1; controls(); persist();
    }
    async function save() {
      const name = window.prompt('Name this drawing set (saved only in this browser):', record.title);
      if (name === null) return;
      busy = true; controls();
      try {
        await queue.catch(() => {});
        if (disposed || !port.isAlive()) return;
        let features = port.getDrawings();
        if (features.length && window.confirm('Would you like to add or edit optional feature names and attributes?\nOK = Yes. Cancel = No, save without adding attributes. Existing attributes are kept.')) {
          features = await editAttributes(features, closer => { closeDialog = closer; });
          if (!features || disposed || !port.isAlive()) return;
        }
        if (conflict) { record.key = key(); revision = 0; conflict = false; }
        record.title = name.trim().slice(0, 160) || record.title;
        autosavePaused = false;
        if (JSON.stringify(features) !== JSON.stringify(port.getDrawings())) {
          port.replaceDrawings(features); changed();
        }
        await persist();
      } finally { busy = false; controls(); }
    }
    async function load() {
      busy = true; controls(); const generation = sequence;
      try {
        // Do not replace unsaved work if the preceding autosave failed.
        await queue;
        const records = await read(store => store.index('scope').getAll(record.scope));
        records.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
        if (disposed) return;
        if (!records.length) { status('No drawings have been saved in this browser yet.'); return; }
        const selected = await choose(records, closer => { closeDialog = closer; });
        if (!selected || disposed) return;
        const loaded = validate(await read(store => store.get(selected)), record.scope);
        if (disposed || !port.isAlive()) return;
        if (sequence !== generation) throw new Error('Drawings changed while loading. Please choose Load drawings again.');
        const storedCursor = loaded.cursor;
        loaded.cursor = loadCursor(loaded);
        if (!loaded.history[loaded.cursor].length) {
          status('No drawings remain in this saved set or its retained history. Current map drawings were kept.');
          return;
        }
        port.replaceDrawings(loaded.history[loaded.cursor]);
        record = loaded; revision = loaded.revision; conflict = false; autosavePaused = false;
        status('Loaded: ' + loaded.title + ' (' + loaded.history[loaded.cursor].length + ' drawings).' +
          (loaded.cursor !== storedCursor ? ' Recovered the latest non-empty state before clearing/deletion.' : '') + ' Undo/Redo history restored.');
      } finally { busy = false; controls(); }
    }
    async function deleteSaved(all) {
      if (Array.from(ports).some(p => p !== session && p.isBusy())) throw new Error('Finish the open drawing dialog in another map first.');
      maintenance = true; ports.forEach(p => p.refreshControls());
      try {
        await Promise.all(Array.from(ports, p => p.settled()));
        const savedScope = record.scope;
        const records = await read(store => store.index('scope').getAll(savedScope));
        if (disposed) return;
        if (!records.length) { status('No saved drawings to delete for this app/browser account.'); return; }
        let selected = null;
        if (!all) {
          records.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
          selected = await choose(records, closer => { closeDialog = closer; }, true);
          if (!selected || disposed) return;
        }
        const title = records.find(r => r.key === selected)?.title;
        const question = all ? 'Permanently delete ALL saved drawing sets and their Undo/Redo history for this app/browser account?' : 'Permanently delete the saved set "' + title + '" and its Undo/Redo history?';
        if (!window.confirm(question + '\nThis cannot be undone. Current map features and Oracle data are not deleted.')) return;
        const keys = await removeSaved(savedScope, selected);
        const message = { type: 'deleted', scope: savedScope, keys, all };
        notifyDeleted(message); if (channel) channel.postMessage(message);
        status('Deleted ' + keys.length + ' saved set(s) and their history from this browser. Current map drawings remain. Deleted data cannot be undone; Save drawings stores the visible drawings again.');
      } finally { maintenance = false; ports.forEach(p => p.refreshControls()); }
    }
    action('Save drawings', save); action('Load drawings', load);
    action('Delete saved set', () => deleteSaved(false));
    action('Clear all saved drawings', () => deleteSaved(true));
    const undo = action('Undo', () => {
      if (!record.cursor) return;
      record.cursor--; port.replaceDrawings(record.history[record.cursor]); controls(); persist();
    });
    const redo = action('Redo', () => {
      if (record.cursor >= record.history.length - 1) return;
      record.cursor++; port.replaceDrawings(record.history[record.cursor]); controls(); persist();
    });
    controls(); status('Browser autosave enabled. Load drawings restores a saved set. Clearing site data removes saved drawings.');
    if (initial.length) persist();
    const session = { changed,
      isBusy: () => busy,
      refreshControls: controls,
      settled: () => queue.catch(() => {}),
      deleted: message => {
        if (record.scope !== message.scope || (!message.all && !message.keys.includes(record.key))) return;
        if (closeDialog) closeDialog();
        // Purge in-memory undo history as well; do not silently recreate a
        // deleted set through autosave from a still-open map.
        record = { version: 1, key: key(), scope: record.scope, title: record.title, history: [port.getDrawings()], cursor: 0 };
        revision = 0; sequence++; conflict = false; autosavePaused = true;
        controls(); status('Saved drawing data and history deleted. Visible drawings remain unsaved. Choose Save drawings only if you want to store them again.');
      },
      dispose: () => {
      disposed = true; if (closeDialog) closeDialog(); port.setBusy(false); actions.forEach(a => a.remove()); ports.delete(session);
    } };
    ports.add(session); return session;
  }
  const adapter = { attach };
  function connect() {
    if (stopped) return;
    const api = window.askOracleMapDrawing;
    if (api?.registerStorage && connectedApi !== api) { api.registerStorage(adapter); connectedApi = api; }
  }
  const timer = window.setInterval(connect, 500); connect();
  window.askOracleMapBrowserStorage = { version: '1.1.0', destroy: () => {
    stopped = true; window.clearInterval(timer);
    if (connectedApi) connectedApi.registerStorage(null);
    ports.forEach(s => s.dispose());
    if (channel) channel.close();
    if (opening) opening.then(db => db.close()).catch(() => {});
    delete window.askOracleMapBrowserStorage;
  } };
})();
