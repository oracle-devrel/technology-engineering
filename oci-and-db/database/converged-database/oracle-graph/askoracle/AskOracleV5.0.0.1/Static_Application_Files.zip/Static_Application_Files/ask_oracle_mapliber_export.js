/* Ask Oracle map PDF export v1.1.0. Load after map + interactions + drawing.
 * Intercepts PDF clicks ONLY for an open, populated map. Other exports unchanged.
 * Captures current viewport (including normal/selected features and drawings),
 * visible chart, and all mapped attribute rows in their current sorted order.
 * Uses the application's existing jsPDF loader. No raw geometry in the PDF.
 */
(function () {
  'use strict';
  if (window.askOracleMapExport) return;
  const pending = new Set();
  const normalize = id => String(id || '').trim().replace(/^response-/, '');
  const geometryColumn = key => /^(GEOJSON|GEOMETRY|GEOM)$|_GEOJSON$/i.test(key.trim());
  let originalExport, exportWrapper;
  function snapshotFor(id, map) {
    const current = window.askOracleMapInteractions?.getSnapshot(id);
    if (current) return current;
    // The PDF can be clicked before the interaction table's discovery timer.
    const features = map.getStyle()?.sources?.['ask-oracle-results']?.data?.features;
    if (!Array.isArray(features)) return null;
    const columns = [...new Set(features.flatMap(f => Object.keys(f.properties || {})))].filter(key => !geometryColumn(key) && features.every(f => f.properties?.[key] == null || ['string', 'number', 'boolean'].includes(typeof f.properties[key])));
    return { columns: columns.length ? columns : ['Feature'], rows: features.map((f, i) => ({ id: f.id, selected: !!map.getFeatureState({ source: 'ask-oracle-results', id: f.id }).aoInteractionSelected, values: columns.length ? columns.map(key => f.properties?.[key]) : [i + 1] })) };
  }
  function context(id) {
    id = normalize(id);
    const map = window.askOracleMap?.getMap(id);
    const block = map?.getContainer().closest('.ask-oracle-map-block');
    const snapshot = map && snapshotFor(id, map);
    return map && block && !block.hidden && snapshot?.rows.length ? { map, block, snapshot } : null;
  }
  function buttonId(button) {
    for (let node = button; node && node !== document.body; node = node.parentElement) {
      const id = normalize(node.getAttribute('data-response-id') || node.getAttribute('data-id'));
      if (id) return id;
      if (node.id?.startsWith('response-')) return normalize(node.id);
    }
    return '';
  }
  function hasGeometry(id) {
    const response = document.getElementById('response-' + normalize(id));
    return !!response && Array.from(response.querySelectorAll('thead th')).some(th => geometryColumn(th.textContent));
  }
  function unavailable() {
    const message = 'Open Show Map and wait for the districts to load before exporting. Raw GeoJSON will not be exported.';
    if (window.apex?.message?.alert) window.apex.message.alert(message); else window.alert(message);
  }
  function installExportRoute() {
    const fn = window.exportConversationToPdf;
    if (typeof fn !== 'function' || fn === exportWrapper) return;
    originalExport = fn;
    exportWrapper = function (id) {
      id = normalize(id);
      if (context(id)) return exportMap(id).catch(() => {});
      if (hasGeometry(id)) { unavailable(); return Promise.resolve(); }
      return fn.apply(this, arguments);
    };
    window.exportConversationToPdf = exportWrapper;
  }
  function captureMap(map) {
    // Read inside a render callback: main map need not preserve its WebGL buffer.
    return new Promise((resolve, reject) => {
      let timer;
      const cleanup = () => { clearTimeout(timer); map.off('render', frame); map.off('remove', removed); };
      const removed = () => { cleanup(); reject(new Error('The map was closed or replaced during export.')); };
      function frame() {
        if (!map.loaded() || !map.areTilesLoaded() || map.isMoving()) return;
        try {
          const canvas = map.getCanvas();
          if (!canvas.width || !canvas.height) throw new Error('Map canvas is empty.');
          const result = { url: canvas.toDataURL('image/png'), width: canvas.width, height: canvas.height };
          if (result.url === 'data:,') throw new Error('Map image could not be captured.');
          cleanup(); resolve(result);
        } catch (error) { cleanup(); reject(error); }
      }
      timer = setTimeout(() => { cleanup(); reject(new Error('Map tiles are not ready. Wait until the background finishes loading, then export again.')); }, 15000);
      map.on('render', frame); map.on('remove', removed); map.triggerRepaint();
    });
  }
  function captureChart(id) {
    const block = document.getElementById('chart-block-' + id);
    if (!block || block.hidden || !block.getClientRects().length || getComputedStyle(block).display === 'none') return null;
    const canvas = block.querySelector('canvas'); if (!canvas?.width || !canvas.height) return null;
    const chart = canvas.__askOracleNl2SqlChart || window.Chart?.getChart?.(canvas);
    if (chart) { chart.stop(); chart.update('none'); }
    return { url: canvas.toDataURL('image/png'), width: canvas.width, height: canvas.height };
  }
  async function exportMap(id) {
    id = normalize(id);
    if (pending.has(id)) return;
    const c = context(id); if (!c) throw new Error('Open the populated map before exporting it.');
    pending.add(id);
    const buttons = Array.from(document.querySelectorAll('.export-pdf-response-btn')).filter(b => buttonId(b) === id);
    const old = buttons.map(b => b.disabled); buttons.forEach(b => { b.disabled = true; b.setAttribute('aria-busy', 'true'); });
    let message = c.block.querySelector('.aoe-status');
    if (!message) { message = document.createElement('p'); message.className = 'aoe-status'; message.setAttribute('role', 'status'); c.block.appendChild(message); }
    message.textContent = 'Preparing PDF with map, chart and attributes...';
    try {
      const libs = window.jspdf?.jsPDF ? { jsPDF: window.jspdf.jsPDF } : await window.ensurePdfExportLibrariesLoaded?.();
      if (!libs?.jsPDF) throw new Error('The application PDF library is unavailable.');
      const picture = await captureMap(c.map);
      // Refresh selections after asynchronous loading to match the captured map.
      const snapshot = snapshotFor(id, c.map);
      if (!snapshot || window.askOracleMap.getMap(id) !== c.map) throw new Error('Results changed during export. Please retry.');
      const chart = captureChart(id);
      const pdf = new libs.jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
      const width = pdf.internal.pageSize.getWidth(), height = pdf.internal.pageSize.getHeight();
      const margin = 12, usable = width - margin * 2, bottom = height - 15;
      let y = margin;
      function page() { pdf.addPage(); y = margin; }
      function text(value, size, bold) {
        pdf.setFont('helvetica', bold ? 'bold' : 'normal'); pdf.setFontSize(size); pdf.setTextColor(25, 43, 58);
        const lines = pdf.splitTextToSize(String(value), usable);
        const step = size * 0.45;
        lines.forEach(line => { if (y + step > bottom) page(); pdf.text(line, margin, y + step); y += step; }); y += 3;
      }
      function image(picture, maxHeight) {
        let w = usable, h = w * picture.height / picture.width;
        if (h > maxHeight) { h = maxHeight; w = h * picture.width / picture.height; }
        if (y + h > bottom) page();
        pdf.addImage(picture.url, 'PNG', margin + (usable - w) / 2, y, w, h); y += h + 4;
      }
      text('Map results', 16, true);
      text('Response ' + id + ' | ' + new Date().toLocaleString(), 9, false);
      image(picture, 132);
      const attribution = c.block.querySelector('.maplibregl-ctrl-attrib-inner')?.textContent?.trim();
      text(attribution || 'MapLibre | OpenFreeMap | OpenMapTiles | OpenStreetMap contributors', 8, false);
      text('Current map view. Yellow: selected districts/features. Blue/orange: unselected results. Purple: temporary drawings.', 9, false);
      if (chart) { page(); text('Chart', 16, true); image(chart, 157); }
      page(); text('Returned map attributes', 16, true);
      text(snapshot.rows.length + ' mapped features; ' + snapshot.rows.filter(r => r.selected).length + ' selected (yellow rows). Geometry is omitted.', 9, false);
      // Column groups prevent squeezing many attributes into unreadable cells.
      const groups = [];
      for (let i = 0; i < snapshot.columns.length; i += 5) groups.push(snapshot.columns.slice(i, i + 5).map((label, offset) => ({ label, index: i + offset })));
      groups.forEach((columns, groupIndex) => {
        if (groupIndex) { page(); text('Attributes - columns ' + (groupIndex * 5 + 1) + ' onwards', 14, true); }
        const widths = [14, ...columns.map(() => (usable - 14) / columns.length)];
        function row(values, selected, header) {
          pdf.setFont('helvetica', header ? 'bold' : 'normal'); pdf.setFontSize(9);
          const cells = values.map((v, i) => pdf.splitTextToSize(v == null ? 'NULL' : String(v), widths[i] - 4));
          let offset = 0; const count = Math.max(...cells.map(lines => lines.length));
          while (offset < count) {
            if (y + 9 > bottom) { page(); if (!header) heading(); }
            const lines = Math.min(count - offset, Math.max(1, Math.floor((bottom - y - 4) / 4)));
            const h = lines * 4 + 4; let x = margin;
            pdf.setFont('helvetica', header ? 'bold' : 'normal'); pdf.setFontSize(9);
            cells.forEach((cell, i) => {
              const color = header ? [232, 239, 245] : selected ? [255, 241, 118] : [255, 255, 255];
              pdf.setFillColor(...color); pdf.setDrawColor(205, 215, 223); pdf.rect(x, y, widths[i], h, 'FD');
              pdf.setTextColor(25, 43, 58);
              cell.slice(offset, offset + lines).forEach((line, j) => pdf.text(line, x + 2, y + 5 + j * 4));
              x += widths[i];
            });
            y += h; offset += lines;
          }
        }
        function heading() { row(['Row', ...columns.map(c => c.label)], false, true); }
        heading(); snapshot.rows.forEach((r, index) => row([index + 1, ...columns.map(c => r.values[c.index])], r.selected, false));
      });
      const pages = pdf.getNumberOfPages();
      for (let i = 1; i <= pages; i++) { pdf.setPage(i); pdf.setFont('helvetica', 'normal'); pdf.setFontSize(8); pdf.setTextColor(90); pdf.text(i + ' / ' + pages, width - margin, height - 6, { align: 'right' }); }
      pdf.save('map-response-' + id.replace(/[^a-z0-9_-]/gi, '_') + '-' + new Date().toISOString().replace(/[:.]/g, '-') + '.pdf');
      message.textContent = 'PDF exported with the map, visible chart and attributes.';
    } catch (error) {
      message.textContent = 'PDF not exported: ' + error.message;
      console.error('Ask Oracle map PDF:', error); throw error;
    } finally {
      pending.delete(id); buttons.forEach((b, i) => { b.disabled = old[i]; b.removeAttribute('aria-busy'); });
    }
  }
  function click(event) {
    const button = event.target.closest?.('.export-pdf-response-btn');
    const id = button && buttonId(button);
    if (!id || (!context(id) && !hasGeometry(id))) return;
    event.preventDefault(); event.stopImmediatePropagation();
    if (!context(id)) { unavailable(); return; }
    exportMap(id).catch(() => { /* visible error is shown in the map */ });
  }
  window.addEventListener('click', click, true);
  const routeTimer = window.setInterval(installExportRoute, 1000);
  installExportRoute();
  window.askOracleMapExport = { version: '1.1.0', export: exportMap, destroy: () => {
    window.clearInterval(routeTimer);
    if (window.exportConversationToPdf === exportWrapper) window.exportConversationToPdf = originalExport;
    window.removeEventListener('click', click, true); delete window.askOracleMapExport;
  } };
})();
