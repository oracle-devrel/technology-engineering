const textarea = document.getElementById('P1_PROMPT1');
const TYPEWRITER_DELAY = 2;



function scrollToBottom() {
    window.scrollTo({
        top: document.body.scrollHeight,
        behavior: 'smooth'  // use 'auto' if you don’t want smooth scroll
    });
}

//Text to Speech

// ================== VOICE LOADING ==================
let voices = [];
let selectedVoice = null;

function loadVoices() {
  voices = speechSynthesis.getVoices();
  // Pick a male voice if available
  selectedVoice = voices.find(v =>
    v.name === "Google UK English Male" ||
    v.name.includes("Microsoft David") ||
    v.name.includes("Alex") ||
    v.name.toLowerCase().includes("male")
  ) || voices.find(v => v.lang.startsWith("en")); // fallback English voice
}
speechSynthesis.onvoiceschanged = loadVoices;
loadVoices();

// ================== SPEECH STATE ==================
const speechState = {}; 
let currentSpeakingId = null; 

function splitSentences(text) {
  return text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
}

// ================== COPY FUNCTION ==================
function copyResponse(id) {
  const text = document.getElementById(`response-${id}`)?.textContent?.trim();
  if (!text) return;
  navigator.clipboard.writeText(text).then(() => {
    alert("Copied to clipboard!");
  }).catch(err => {
    console.error("Copy failed:", err);
  });
}

// ================== SPEECH FUNCTIONS ==================
function toggleSpeech(id, button) {
  // Stop other active speech
  if (currentSpeakingId && currentSpeakingId !== id) {
    const oldState = speechState[currentSpeakingId];
    if (oldState) {
      stopSpeech(oldState);
      updatePlayIcon(oldState.button, "play");
    }
  }

  let state = speechState[id] || { sentences: [], index: 0, isSpeaking: false, isPaused: false };
  const responseText = document.getElementById(`response-${id}`)?.textContent?.trim();
  if (!responseText) return;

  // Resume if paused
  if (state.isPaused) {
    window.speechSynthesis.resume();
    state.isPaused = false;
    updatePlayIcon(button, "pause");
    currentSpeakingId = id;
    return;
  }

  // Pause if speaking
  if (state.isSpeaking) {
    window.speechSynthesis.pause();
    state.isPaused = true;
    updatePlayIcon(button, "resume");
    return;
  }

  // New speech
  state.sentences = splitSentences(responseText);
  state.index = 0;
  state.button = button;
  state.id = id;
  state.isPaused = false;
  speechState[id] = state;

  currentSpeakingId = id;
  speakSentence(state);
  updatePlayIcon(button, "pause");
}

function speakSentence(state) {
  if (state.index >= state.sentences.length) {
    stopSpeech(state);
    updatePlayIcon(state.button, "play");
    return;
  }

  const utterance = new SpeechSynthesisUtterance(state.sentences[state.index]);

  if (selectedVoice) utterance.voice = selectedVoice;

  utterance.onend = () => {
    if (!state.isPaused) {
      state.index++;
      speakSentence(state);
    }
  };

  state.isSpeaking = true;
  window.speechSynthesis.speak(utterance);
}

function skipSentence(direction, id) {
  const state = speechState[id];
  if (!state) return;

  window.speechSynthesis.cancel();
  state.isPaused = false;
  state.index += direction;

  if (state.index < 0) state.index = 0;
  if (state.index >= state.sentences.length) {
    stopSpeech(state);
    updatePlayIcon(state.button, "play");
    return;
  }

  currentSpeakingId = id;
  speakSentence(state);
  updatePlayIcon(state.button, "pause");
}

function stopSpeech(state) {
  window.speechSynthesis.cancel();
  state.isSpeaking = false;
  state.isPaused = false;
  state.index = 0;
}

function updatePlayIcon(button, mode) {
  const icon = button.querySelector("i");
  if (!icon) return;
  switch (mode) {
    case "play":   icon.className = "fas fa-play"; break;
    case "pause":  icon.className = "fas fa-pause"; break;
    case "resume": icon.className = "fas fa-play-circle"; break;
  }
}

// ================== ERROR HANDLER ==================
function myCustomErrorHandler(errorData) {
//   console.log("Custom handler called:", errorData);
  alert("Custom Error: " + errorData.responseText);
}

apex.jQuery(document).on("apexafterajaxerror", function(event, data) {
  event.preventDefault();
  if (data && data.ajaxIdentifier && data.ajaxIdentifier.indexOf("ProcessPrompt") > -1) {
    myCustomErrorHandler(data);
  }
});


//Prompt

const promptInput = document.querySelector("#P1_PROMPT1"); // Replace with your actual item
const runButton = document.querySelector("#RUN"); // Button or enter key

function showLoadingUI() {
  document.querySelector("#LOADER_REGION").style.display = "block";
  promptInput.disabled = true;
  runButton.disabled = true;
  document.querySelector("#loading-indicator").style.display = "flex";
}

function hideLoadingUI() {
  console.log('Hiding the spinner');
  promptInput.disabled = false;
  runButton.disabled = false;
  document.querySelector("#loading-indicator").style.display = "none";
  document.querySelector("#LOADER_REGION").style.display = "none";
}


document.getElementById("runPrompt").addEventListener("click", function (e) {
    console.log("🔹 runPrompt button clicked");
    e.preventDefault(); // stop form submit
    const btn = document.getElementById("runPrompt");

    // Disable + style change
    btn.disabled = true;
    btn.style.backgroundColor = "#555";  // gray look
    btn.style.cursor = "not-allowed";
    //btn.querySelector("i").classList.add("fa-spin"); // optional loading spin on icon
    apex.item('P1_PROMPT').setValue(apex.item('P1_PROMPT1').getValue());
    apex.item('P1_PROMPT1').setValue("");
    // console.log("Prompt value:", document.getElementById("P1_PROMPT").value);
    // appendUserPrompt();
    //showLoadingUI();

    const { promptId, loaderId } = appendUserPrompt();

    apex.item("P1_LATEST_PROMPT_ID").setValue(promptId);
    apex.item("P1_LATEST_LOADER_ID").setValue(loaderId);


    console.log("Triggering custom event: da-run-prompt");
    apex.event.trigger(document, "da-run-prompt");
});




// Find the nearest scrollable ancestor (falls back to window)
function getScrollParent(el) {
  let p = el && el.parentElement;
  while (p) {
    const style = getComputedStyle(p);
    const canScroll = /(auto|scroll)/.test(style.overflowY) && p.scrollHeight > p.clientHeight;
    if (canScroll) return p;
    p = p.parentElement;
  }
  return window;
}

// Scroll the correct scroller to bottom after layout settles
function scrollToEndFor(el, { smooth = true, offset = 0 } = {}) {
  if (!el) return;
  const scroller = getScrollParent(el);

  // wait for layout/paint so heights are correct
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      if (scroller === window) {
        const h = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
        window.scrollTo({ top: h - offset, behavior: smooth ? "smooth" : "auto" });
      } else {
        scroller.scrollTo({ top: scroller.scrollHeight - offset, behavior: smooth ? "smooth" : "auto" });
      }
    });
  });
}



// Unified getter for your chat container
function getChatContainer() {
  return document.querySelector("#PROMPTS .prompt-list") || document.getElementById("PROMPTS");
}



// Helper to escape HTML special chars
function escapeHtml(text) {
  if (!text) return "";
  return text.replace(/[&<>"']/g, function(m) {
    return ({
      '&': "&amp;",
      '<': "&lt;",
      '>': "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[m];
  });
}



// Global map to track prompt texts by their temporary frontend IDs
window.pendingPrompts = window.pendingPrompts || {};

// Helper: Normalize prompt text by trimming and collapsing whitespace (incl newlines)
function normalizePromptText(text) {
  return text
    .trim()
    .replace(/\s+/g, ' ')  // Replace all whitespace sequences with a single space
    .toLowerCase();        // Optional: lowercase for case-insensitive matching
}

//Show loader by ID or default region
function showLoadingUI(loaderId) {
  promptInput.disabled = true;
  runButton.disabled = true;

  if (loaderId) {
    const el = document.getElementById(loaderId);
    if (el) el.style.display = "flex";
  } else {
    document.querySelector("#LOADER_REGION").style.display = "block";
    document.querySelector("#loading-indicator").style.display = "flex";
  }
}


// Hide loader by ID or default region
function hideLoadingUI(loaderId) {
  promptInput.disabled = false;
  runButton.disabled = false;

  if (loaderId) {
    const el = document.getElementById(loaderId);
    if (el) el.style.display = "none";
  } else {
    document.querySelector("#loading-indicator").style.display = "none";
    document.querySelector("#LOADER_REGION").style.display = "none";
  }
}


// Use event delegation for dynamically added buttons
document.addEventListener("click", function(e) {
  const btn = e.target.closest(".copy-btn");
  if (!btn) return;

  e.preventDefault(); // prevent form submit

  // find the message bubble relative to the clicked button
  const bubble = btn.parentElement.querySelector(".message-bubble");
  if (!bubble) return;

  const text = bubble.textContent || bubble.innerText;

  navigator.clipboard.writeText(text).then(() => {
    const icon = btn.querySelector("i");
    icon.classList.remove("fa-copy");
    icon.classList.add("fa-check");
    setTimeout(() => {
      icon.classList.remove("fa-check");
      icon.classList.add("fa-copy");
    }, 1500);
  }).catch(err => {
    console.error("Copy failed:", err);
  });
});





function appendUserPrompt() {
  let promptText = apex.item("P1_PROMPT").getValue().trim();
  if (!promptText) return;

  // ✅ Generate a unique prompt ID
  let promptId = "prompt-local-" + Date.now();

  // ✅ Store prompt text in pendingPrompts
  window.pendingPrompts[promptId] = normalizePromptText(promptText);

  // ✅ Escape HTML and replace newlines with <br>
  const safePromptText = escapeHtml(promptText).replace(/\n/g, "<br>");

    const template = `
    <div style="height:9px; width:100%;" aria-hidden="true"></div>
    <div class="chat-message user-message" id="${promptId}" style="padding-top: 16px; position: relative;">
        <div class="message-bubble">${safePromptText}</div>
        <button type="button" class="copy-btn">
        <i class="fa fa-copy"></i>
        </button>
    </div>
    `;

  let loaderId = null;

  // ✅ Find container to insert the prompt
  const container =
    document.querySelector("#PROMPTS .prompt-list") ||
    document.getElementById("PROMPTS");

  if (container) {
    container.insertAdjacentHTML("beforeend", template);

    // ✅ Add loader after the prompt
    const promptEl = document.getElementById(promptId);
    if (promptEl) {
      const loaderRegion = document.getElementById("loading-indicator");
      if (loaderRegion) {
        const loaderClone = loaderRegion.cloneNode(true);
        loaderClone.style.display = "flex";
        loaderId = "loading-indicator-" + promptId;
        loaderClone.id = loaderId;
        promptEl.insertAdjacentElement("afterend", loaderClone);
        showLoadingUI(loaderId);
      }
    }

    // ✅ Auto-scroll to the bottom
    const scrollContainer =
      document
        .querySelector("#PROMPTS")
        ?.closest(".t-Region-body, .t-Body-contentInner, .prompt-list") ||
      container;

    requestAnimationFrame(() => {
      scrollContainer.scrollTo({
        top: scrollContainer.scrollHeight,
        behavior: "smooth",
      });
    });
  }

  // ✅ Store prompt in localStorage
  let existingPrompts = JSON.parse(localStorage.getItem("chat_prompts") || "[]");
  existingPrompts.push({ id: promptId, text: promptText });
  localStorage.setItem("chat_prompts", JSON.stringify(existingPrompts));

  return { promptId, loaderId };
}




var cnt = 0;

function scrollToLast(){
    if ($(".prompt-box").length > 0 && cnt == $(".prompt-box").length){
         $([document.documentElement, document.body]).animate({
        scrollTop: $('.prompt-box').last().offset().top-120
    }, 2000);
    }
}

//To print the data in table format.
function convertMarkdownTableToHTML(md) {
  const lines = md.split('\n');
  let tableStarted = false;
  let html = '';

  lines.forEach((line) => {
    if (line.trim().startsWith('|')) {
      const cells = line.split('|').slice(1, -1).map(c => c.trim());
      
      if (!tableStarted) {
        html += '<table style="border-collapse: collapse; width: 100%; margin: 0.5rem 0;">';
        html += '<thead><tr>';
        cells.forEach(cell => {
          html += `<th style="border: 1px solid #ddd; padding: 6px; text-align: left;">${cell}</th>`;
        });
        html += '</tr></thead><tbody>';
        tableStarted = true;
      } else if (!line.includes('---')) {
        html += '<tr>';
        cells.forEach(cell => {
          html += `<td style="border: 1px solid #ddd; padding: 6px;">${cell}</td>`;
        });
        html += '</tr>';
      }
    } else if (tableStarted) {
      html += '</tbody></table>';
      tableStarted = false;
      html += line + '\n'; // append the normal text after table
    } else {
      html += line + '\n';
    }
  });

  if (tableStarted) html += '</tbody></table>'; // close table if last line
  return html;
}


function renderLLMResponseWithHTML(el, htmlContent, onComplete) {
    // Clear existing content
    el.innerHTML = "";

    // Create a temporary container to parse HTML
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = htmlContent;

    // Move all non-script nodes into the actual container
    Array.from(tempDiv.childNodes).forEach(node => {
        if (node.tagName !== "SCRIPT") {
            el.appendChild(node);
        }
    });

    // Execute all scripts
    Array.from(tempDiv.querySelectorAll("script")).forEach(oldScript => {
        const newScript = document.createElement("script");
        if (oldScript.src) {
            newScript.src = oldScript.src; // external script
        } else {
            newScript.textContent = oldScript.textContent; // inline script
        }
        document.body.appendChild(newScript);
        // Optional: remove script after execution to clean DOM
        setTimeout(() => document.body.removeChild(newScript), 0);
    });

    if (onComplete) onComplete();
}

  // Markdown Table → HTML (unchanged)
  function convertMarkdownTableToHTML(md) {
    const lines = md.split('\n');
    let tableStarted = false;
    let html = '';

    lines.forEach((line) => {
      if (line.trim().startsWith('|')) {
        const cells = line.split('|').slice(1, -1).map(c => c.trim());

        if (!tableStarted) {
          html += '<table style="border-collapse: collapse; width: 100%; margin: 0.5rem 0;">';
          html += '<thead><tr>';
          cells.forEach(cell => {
            html += `<th style="border: 1px solid #ddd; padding: 6px; text-align: left;">${cell}</th>`;
          });
          html += '</tr></thead><tbody>';
          tableStarted = true;
        } else if (!line.includes('---')) {
          html += '<tr>';
          cells.forEach(cell => {
            html += `<td style="border: 1px solid #ddd; padding: 6px;">${cell}</td>`;
          });
          html += '</tr>';
        }
      } else if (tableStarted) {
        html += '</tbody></table>';
        tableStarted = false;
        html += line + '\n';
      } else {
        html += line + '\n';
      }
    });

    if (tableStarted) html += '</tbody></table>';
    return html;
  }



//   function typeWriterSmart(el, html, speed, onComplete) {
//     let parser = new DOMParser();
//     let doc = parser.parseFromString(html, "text/html");
//     let nodes = Array.from(doc.body.childNodes);
//     let index = 0;

//     function scrollToBottom() {
//       el.scrollTop = el.scrollHeight;
//     }


//     function typeNode(node, container, callback) {
//       if (node.nodeType === Node.TEXT_NODE) {
//         let text = node.nodeValue;
//         let i = 0;
//         let textNode = document.createTextNode('');
//         container.appendChild(textNode);

//         function typeText() {
//           if (i < text.length) {
//             textNode.nodeValue += text.charAt(i);
//             scrollToBottom();
//             i++;
//             setTimeout(typeText, speed);
//           } else callback();
//         }
//         typeText();
//       } else if (node.nodeType === Node.ELEMENT_NODE) {
//         let tag = document.createElement(node.nodeName.toLowerCase());
//         for (let attr of node.attributes) tag.setAttribute(attr.name, attr.value);
//         container.appendChild(tag);

//         let childNodes = Array.from(node.childNodes);
//         let childIndex = 0;
//         function nextChild() {
//           if (childIndex < childNodes.length) {
//             typeNode(childNodes[childIndex], tag, () => {
//               childIndex++;
//               nextChild();
//             });
//           } else callback();
//         }
//         nextChild();
//       } else callback();
//     }

//     function nextNode() {
//       if (index < nodes.length) {
//         typeNode(nodes[index], el, () => {
//           index++;
//           nextNode();
//         });
//       } else if (onComplete) onComplete();
//     }

//     nextNode();
// }


function typeWriterSmart(el, html, speed = 10, onComplete) {
  // Parse the HTML into a DOM tree
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  // Recursive typing for any DOM node
  function typeNode(node, container, done) {
    if (node.nodeType === Node.TEXT_NODE) {
      // Typing text nodes character-by-character
      const text = node.nodeValue || "";
      const textNode = document.createTextNode("");
      container.appendChild(textNode);

      let i = 0;
      function typeChar() {
        if (i < text.length) {
          textNode.nodeValue += text.charAt(i);
          container.scrollTop = container.scrollHeight; // auto-scroll
          i++;
          setTimeout(typeChar, speed);
        } else {
          done && done();
        }
      }
      typeChar();

    } else if (node.nodeType === Node.ELEMENT_NODE) {
      // Create element and type its children
      const newEl = document.createElement(node.nodeName.toLowerCase());
      for (let attr of node.attributes) newEl.setAttribute(attr.name, attr.value);
      container.appendChild(newEl);

      const children = Array.from(node.childNodes);
      typeChildren(children, newEl, done);

    } else {
      done && done();
    }
  }

  // Recursive traversal through a list of nodes
  function typeChildren(nodes, container, done) {
    let index = 0;
    function next() {
      if (index < nodes.length) {
        typeNode(nodes[index], container, () => {
          index++;
          next();
        });
      } else {
        done && done();
      }
    }
    next();
  }

  // Start typing everything in <body>
  const bodyNodes = Array.from(doc.body.childNodes);
  el.innerHTML = ""; // clear previous content
  typeChildren(bodyNodes, el, onComplete);
}


// ---------------------------
// Global sanitizeJsonLikeString helper
// ---------------------------
function sanitizeJsonLikeString(s) {
  if (!s || typeof s !== "string") return s;
  let t = s.trim();

  // Remove any leading code fence like ```chartjs
  t = t.replace(/^```(?:chartjs|json)?\s*/i, '').replace(/```$/i, '');

  // Strip anything before first {
  const first = t.indexOf("{");
  if (first > 0) t = t.substring(first);

  // Remove trailing commas before } or ]
  t = t.replace(/,\s*(?=[}\]])/g, '');

  // Balance braces and brackets
  const opensBrace = (t.match(/{/g) || []).length;
  const closesBrace = (t.match(/}/g) || []).length;
  const opensSq = (t.match(/\[/g) || []).length;
  const closesSq = (t.match(/]/g) || []).length;

  if (closesBrace < opensBrace) {
    t = t + "}".repeat(opensBrace - closesBrace);
    console.log(`sanitizeJsonLikeString: added ${opensBrace - closesBrace} missing '}'`);
  }
  if (closesSq < opensSq) {
    t = t + "]".repeat(opensSq - closesSq);
    console.log(`sanitizeJsonLikeString: added ${opensSq - closesSq} missing ']'`);
  }

  return t;
}


function tryParseJsonRobust(raw) {
    if (!raw) throw new Error("No JSON content provided to parser");

    // 1. raw attempt
    try { return JSON.parse(raw); } catch (e1) {}

    // 2. sanitized attempt
    let sanitized = sanitizeJsonLikeString(raw);
    try { return JSON.parse(sanitized); } catch (e2) {}

    // 3. cut at last } then parse
    const lastCloseBrace = sanitized.lastIndexOf("}");
    if (lastCloseBrace !== -1) {
    const cut = sanitized.substring(0, lastCloseBrace + 1);
    try { return JSON.parse(cut); } catch (e3) {}
    }

    // 4. final attempts
    sanitized = sanitized.replace(/,\s*(?=[}\]])/g, '');
    const opensBrace = (sanitized.match(/{/g) || []).length;
    const closesBrace = (sanitized.match(/}/g) || []).length;
    if (closesBrace < opensBrace) sanitized += "}".repeat(opensBrace - closesBrace);
    try { return JSON.parse(sanitized); } catch (finalErr) {
    finalErr.message = finalErr.message + " | attempted sanitized JSON preview: " + (sanitized.length > 1000 ? sanitized.slice(0,1000) + "..." : sanitized);
    throw finalErr;
    }
}


// -------------------------
// reviveFunctions: convert stringified function bodies into real JS functions
// -------------------------
function reviveFunctions(obj) {
    const fnRegex = /^\s*function\s*\(([^)]*)\)\s*\{([\s\S]*)\}\s*$/m;
    const arrowBlockRegex = /^\s*\(?([^)]*)\)?\s*=>\s*\{([\s\S]*)\}\s*$/m;
    const arrowExprRegex = /^\s*\(?([^)]*)\)?\s*=>\s*([^{};]+)\s*$/m;

    function revive(value) {
    if (typeof value === 'string') {
        let m;
        if ((m = value.match(fnRegex))) {
        const args = m[1].trim();
        const body = m[2];
        try {
            const argList = args ? args.split(',').map(a => a.trim()) : [];
            return Function(...argList.concat([body]));
        } catch (e) {
            console.warn("reviveFunctions: failed to revive function string (fn):", e, value);
            return value;
        }
        }
        if ((m = value.match(arrowBlockRegex))) {
        const args = m[1].trim();
        const body = m[2];
        try {
            const argList = args ? args.split(',').map(a => a.trim()) : [];
            return Function(...argList.concat([body]));
        } catch (e) {
            console.warn("reviveFunctions: failed to revive arrow-block fn:", e, value);
            return value;
        }
        }
        if ((m = value.match(arrowExprRegex))) {
        const args = m[1].trim();
        const expr = m[2];
        try {
            const argList = args ? args.split(',').map(a => a.trim()) : [];
            return Function(...argList.concat([ 'return (' + expr + ');' ]));
        } catch (e) {
            console.warn("reviveFunctions: failed to revive arrow-expr fn:", e, value);
            return value;
        }
        }
        return value;
    } else if (Array.isArray(value)) {
        return value.map(revive);
    } else if (value && typeof value === 'object') {
        const out = Array.isArray(value) ? [] : {};
        for (const k of Object.keys(value)) {
        out[k] = revive(value[k]);
        }
        return out;
    } else {
        return value;
    }
    }

    return revive(obj);
}

// helper to escape HTML for UI messages
function escapeHtml(str) {
    if (!str) return "";
    return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}


function postProcessResponse(el) {
  let html = el.innerText;

  // Bold
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  // Links
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, `<a href="$2" target="_blank">$1</a>`);
  html = html.replace(/(^|[^"'>])(https?:\/\/[^\s<]+)/g, '$1<a href="$2" target="_blank" rel="noopener noreferrer">$2</a>');

  // Convert Markdown tables → HTML
  html = convertMarkdownTableToHTML(html);

  el.innerHTML = html;
}


function renderAllCharts(chartBlocks, id) {
  if (!chartBlocks || chartBlocks.length === 0) {
    console.log("📊 No charts found.");
    return;
  }

  const chartContainer = document.getElementById(`chart-container-${id}`);
  if (!chartContainer) {
    console.error("Chart container not found:", `chart-container-${id}`);
    return;
  }

  chartContainer.innerHTML = "";
  chartContainer.style.display = "block";

  chartBlocks.forEach((block, index) => {
    const canvasId = `chart-canvas-${id}-${index}`;
    chartContainer.insertAdjacentHTML(
      "beforeend",
      `<div style="margin-top:20px;"><canvas id="${canvasId}" style="max-height:400px;"></canvas></div>`
    );

    try {
      let cfg = tryParseJsonRobust(block);
      if (Array.isArray(cfg)) cfg = cfg[0];
      cfg = reviveFunctions(cfg);

      const ctx = document.getElementById(canvasId).getContext("2d");
      new Chart(ctx, cfg);
      console.log(`✅ Chart ${index + 1} rendered successfully`);
    } catch (e) {
      console.error(`❌ Failed to render chart ${index + 1}:`, e);
      chartContainer.insertAdjacentHTML(
        "beforeend",
        `<pre style="color:darkred;">⚠️ Chart render failed: ${escapeHtml(e.message || String(e))}</pre>`
      );
    }
  });
}



function initSingleLLMResponse(id, onComplete) {
  const el = document.getElementById("response-" + id);
  if (!el) {
    if (onComplete) onComplete();
    return;
  }

  const type = el.getAttribute("data-type");
  console.log("Printing the type of", type);

  if (type === "response") {
    apex.server.process("GET_RESPONSE", { x01: id }, {
      dataType: "json",
      success: function (pData) {
        let response = pData.response || "";

        // 1️⃣ Auto-close ```chartjs if unclosed
        if (response.includes("```chartjs") && !response.includes("```", response.indexOf("```chartjs") + 9)) {
          response += "\n```";
        }

        // ---------------------------
        // Extract ALL chart JSON blocks (support multiple charts)
        // ---------------------------
        const chartBlocks = [];
        const chartRegex = /```(?:chartjs|json)\s*([\s\S]*?)(?:```|$)/gi;
        let match;
        while ((match = chartRegex.exec(response)) !== null) {
          chartBlocks.push(match[1].trim());
        }

        // 2️⃣ Remove chart JSON from main text
        let textOnlyResponse = response
          .replace(/```(chartjs|json)\s*[\s\S]*?```/gi, '')
          .replace(/```(chartjs|json)\s*[\s\S]*$/gi, '')
          .trim();

        // 3️⃣ Typewriter will type ONLY raw text (markdown-like)
        el.innerHTML = "";
        typeWriterSmart(el, textOnlyResponse, 3, () => {
          console.log("✅ Typewriter finished typing text");

          // After typing → Post-process text: convert markdown to HTML
          postProcessResponse(el);

          // Then → Render all charts
          renderAllCharts(chartBlocks, id);

          // 🕐 Update conversation time tooltip
          let conversationTime = pData.conversation_time || "0 Min 0 Sec";
          $("#response-" + pData.id)
            .nextAll("div")
            .find(".conversation-time-btn")
            .first()
            .attr("data-tooltip", conversationTime)
            .attr("data-time", conversationTime)
            .attr("title", conversationTime);

          if (onComplete) onComplete();
        });
      }
    });
  }
 else if (type === "sql") {
        apex.server.process("GET_SQL_RESULTS", { x01: id }, {
            dataType: "json",
            success: function(pData) {
                el.innerHTML = "";
                let promptText = $("#prompt-" + pData.id).text() || "";
                let chartType = null;

                if (promptText.toLowerCase().includes("pie chart")) chartType = "pie";
                else if (promptText.toLowerCase().includes("bar chart")) chartType = "bar";
                else if (promptText.toLowerCase().includes("line chart")) chartType = "line";
                else if (promptText.toLowerCase().includes("area chart")) chartType = "area";
                else if (promptText.toLowerCase().includes("donut chart")) chartType = "donut";
                else if (promptText.toLowerCase().includes("funnel chart")) chartType = "funnel";

                if (chartType) renderChart(pData.results, "response-" + pData.id, chartType);
                else convert(pData.results, "response-" + pData.id);

                cnt++;
                scrollToLast();

                if (pData.totalRowCount > 10) $(".llm-more-rows-" + id).show();
                $(".llm-load-message-" + pData.id).hide();
                scrollToLast();

                // Inject profile label
                let profileLabel = pData.profile_name || "Default";
                $("#response-" + pData.id)
                    .nextAll("div")
                    .find(".profile-label")
                    .first()
                    .text(profileLabel);

                // Inject conversation time
                let conversationTime = pData.conversation_time || "0 Min 0 Sec";
                $("#response-" + pData.id)
                    .nextAll("div")
                    .find(".conversation-time-btn")
                    .first()
                    .attr("data-time", conversationTime)
                    .attr("title", conversationTime);

                // Inject SQL code if available
                if (pData.sql) {
                    const sqlBlock = document.querySelector("#sql-block-" + pData.id + " code");
                    if (sqlBlock) {
                        sqlBlock.textContent = pData.sql;
                        Prism.highlightElement(sqlBlock);
                    }
                }

                if (onComplete) onComplete();
            }
        });
    } else {
        if (onComplete) onComplete();
    }
}
















// function initSingleLLMResponse(id, onComplete) {
// //   console.log('Data from initSingleLLMResponse', id);

//   const el = document.getElementById("response-" + id);
//   if (!el) {
//     if (onComplete) onComplete();
//     return;
//   }

//   const type = el.getAttribute("data-type");

//   function typeWriterSmart(el, html, speed, onComplete) {
//     let parser = new DOMParser();
//     let doc = parser.parseFromString(html, "text/html");
//     let nodes = Array.from(doc.body.childNodes);
//     let index = 0;

//     function scrollToBottom() {
//       el.scrollTop = el.scrollHeight;
//     }

//     function typeNode(node, container, callback) {
//       if (node.nodeType === Node.TEXT_NODE) {
//         let text = node.nodeValue;
//         let i = 0;
//         let textNode = document.createTextNode('');
//         container.appendChild(textNode);

//         function typeText() {
//           if (i < text.length) {
//             textNode.nodeValue += text.charAt(i);
//             scrollToBottom();
//             i++;
//             setTimeout(typeText, speed);
//           } else callback();
//         }
//         typeText();
//       } else if (node.nodeType === Node.ELEMENT_NODE) {
//         let tag = document.createElement(node.nodeName.toLowerCase());
//         for (let attr of node.attributes) tag.setAttribute(attr.name, attr.value);
//         container.appendChild(tag);

//         let childNodes = Array.from(node.childNodes);
//         let childIndex = 0;
//         function nextChild() {
//           if (childIndex < childNodes.length) {
//             typeNode(childNodes[childIndex], tag, () => {
//               childIndex++;
//               nextChild();
//             });
//           } else callback();
//         }
//         nextChild();
//       } else callback();
//     }

//     function nextNode() {
//       if (index < nodes.length) {
//         typeNode(nodes[index], el, () => {
//           index++;
//           nextNode();
//         });
//       } else if (onComplete) onComplete();
//     }

//     nextNode();
//   }


//   // fetch server response
//   if (type === "response") {
//     apex.server.process("GET_RESPONSE", { x01: id }, {
//       dataType: "json",
//       success: function (pData) {
//         // console.log("Data is", pData);

//         let response = pData.response || "";

//         // Auto-close any unclosed ```chartjs blocks
//         if (response.includes("```chartjs") && !response.includes("```", response.indexOf("```chartjs") + 9)) {
//           response += "\n```";
//         }

//         // ---------------------------
//         // Robust chart extraction helpers
//         // ---------------------------
//         function sanitizeJsonLikeString(s) {
//           if (!s || typeof s !== "string") return s;
//           let t = s.trim();

//           // Remove any leading code fence like ```chartjs
//           t = t.replace(/^```(?:chartjs|json)?\s*/i, '').replace(/```$/i, '');

//           // Strip anything before first {
//           const first = t.indexOf("{");
//           if (first > 0) t = t.substring(first);

//           // Remove trailing commas before } or ]
//           t = t.replace(/,\s*(?=[}\]])/g, '');

//           // Balance braces and brackets
//           const opensBrace = (t.match(/{/g) || []).length;
//           const closesBrace = (t.match(/}/g) || []).length;
//           const opensSq = (t.match(/\[/g) || []).length;
//           const closesSq = (t.match(/\]/g) || []).length;

//           if (closesBrace < opensBrace) {
//             t = t + "}".repeat(opensBrace - closesBrace);
//             console.log(`sanitizeJsonLikeString: added ${opensBrace - closesBrace} missing '}'`);
//           }
//           if (closesSq < opensSq) {
//             t = t + "]".repeat(opensSq - closesSq);
//             console.log(`sanitizeJsonLikeString: added ${opensSq - closesSq} missing ']'`);
//           }
//           return t;
//         }

//         function tryParseJsonRobust(raw) {
//           if (!raw) throw new Error("No JSON content provided to parser");

//           // 1. raw attempt
//           try { return JSON.parse(raw); } catch (e1) {}

//           // 2. sanitized attempt
//           let sanitized = sanitizeJsonLikeString(raw);
//           try { return JSON.parse(sanitized); } catch (e2) {}

//           // 3. cut at last } then parse
//           const lastCloseBrace = sanitized.lastIndexOf("}");
//           if (lastCloseBrace !== -1) {
//             const cut = sanitized.substring(0, lastCloseBrace + 1);
//             try { return JSON.parse(cut); } catch (e3) {}
//           }

//           // 4. final attempts
//           sanitized = sanitized.replace(/,\s*(?=[}\]])/g, '');
//           const opensBrace = (sanitized.match(/{/g) || []).length;
//           const closesBrace = (sanitized.match(/}/g) || []).length;
//           if (closesBrace < opensBrace) sanitized += "}".repeat(opensBrace - closesBrace);
//           try { return JSON.parse(sanitized); } catch (finalErr) {
//             finalErr.message = finalErr.message + " | attempted sanitized JSON preview: " + (sanitized.length > 1000 ? sanitized.slice(0,1000) + "..." : sanitized);
//             throw finalErr;
//           }
//         }

//         // ---------------------------
//         // Extract raw chart JSON text (fenced or fallback)
//         // ---------------------------
//         let rawChartText = null;
//         const fenceMatch = response.match(/```(chartjs|json)\s*([\s\S]*?)(?:```|$)/i);
//         if (fenceMatch && fenceMatch[2]) {
//           rawChartText = fenceMatch[2].trim();
//         //   console.log("Found fenced chart block (maybe missing closing ```):", rawChartText.slice(0,300));
//         } else {
//           const firstBrace = response.indexOf("{");
//           if (firstBrace !== -1) {
//             rawChartText = response.substring(firstBrace).trim();
//             console.log("No fence found — extracted from first '{':", rawChartText.slice(0,300));
//           } else {
//             console.log("No JSON-like content found in response");
//           }
//         }

//         // ---------------------------
//         // Parse chartConfig if present
//         // ---------------------------
//         let chartConfig = null;
//         if (rawChartText) {
//           try {
//             chartConfig = tryParseJsonRobust(rawChartText);
//             console.log("Parsed chartConfig:", chartConfig);
//           } catch (err) {
//             console.error("JSON parse error after attempts:", err);
//             // render a helpful inline message and continue (do not duplicate text)
//             el.insertAdjacentHTML("beforeend",
//               `<pre style="color:darkorange;">⚠️ Chart JSON parse failed. See console. Sanitized preview:\n${escapeHtml(sanitizeJsonLikeString(rawChartText)).slice(0,2000)}</pre>`
//             );
//             // keep going — we'll still render the text portion below
//             chartConfig = null;
//           }
//         }

//         // ---------------------------
//         // Remove chart block from response and clean markdown → html (only once)
//         // ---------------------------
//         let cleanedResponse = response
//           // remove fenced chart blocks (whole fence if present)
//           .replace(/```(chartjs|json)\s*[\s\S]*?```/gi, '')
//           // or, if fence wasn't closed, remove from opening fence to end-of-string
//           .replace(/```(chartjs|json)\s*[\s\S]*$/gi, '')
//           .replace(/#{2,}\s*/g, '')
//           .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
//           .replace(/^- /gm, '• ')
//           .replace(/\[([^\]]+)\]\(([^)]+)\)/g, `<a href="$2" target="_blank">$1</a>`)
//           // plain urls not already in href (compatible regex)
//           .replace(/(^|[^"'>])(https?:\/\/[^\s<]+)/g, '$1<a href="$2" target="_blank" rel="noopener noreferrer">$2</a>')
//           .trim();

//         cleanedResponse = convertMarkdownTableToHTML(cleanedResponse);

//         // ---------------------------
//         // Render text content ONCE
//         // ---------------------------
//         el.innerHTML = cleanedResponse;
        
// // ---------------------------
// // Render chart (if parsed successfully)
// // ---------------------------
// if (chartConfig) {
//   const chartContainer = document.getElementById(`chart-container-${id}`);
// //   console.log("Chart container ID:", `chart-container-${id}`);
//   if (!chartContainer) {
//     console.error("Chart container not found:", `chart-container-${id}`);
//   } else if (typeof Chart === 'undefined') {
//     console.error("Chart.js is not loaded");
//   } else {
//     chartContainer.style.display = "block";
//     chartContainer.innerHTML = `<canvas id="chart-canvas-${id}" style="max-height:400px;"></canvas>`;
//     const ctx = document.getElementById(`chart-canvas-${id}`).getContext("2d");

//     // Defensive: if incoming config is an array, use first element
//     if (Array.isArray(chartConfig)) {
//       console.warn("Chart config is an array — using first item for rendering.");
//       chartConfig = chartConfig[0];
//     }

//     // -------------------------
//     // reviveFunctions: convert stringified function bodies into real JS functions
//     // -------------------------
//     function reviveFunctions(obj) {
//       const fnRegex = /^\s*function\s*\(([^)]*)\)\s*\{([\s\S]*)\}\s*$/m;
//       const arrowBlockRegex = /^\s*\(?([^)]*)\)?\s*=>\s*\{([\s\S]*)\}\s*$/m;
//       const arrowExprRegex = /^\s*\(?([^)]*)\)?\s*=>\s*([^{};]+)\s*$/m;

//       function revive(value) {
//         if (typeof value === 'string') {
//           let m;
//           if ((m = value.match(fnRegex))) {
//             const args = m[1].trim();
//             const body = m[2];
//             try {
//               const argList = args ? args.split(',').map(a => a.trim()) : [];
//               return Function(...argList.concat([body]));
//             } catch (e) {
//               console.warn("reviveFunctions: failed to revive function string (fn):", e, value);
//               return value;
//             }
//           }
//           if ((m = value.match(arrowBlockRegex))) {
//             const args = m[1].trim();
//             const body = m[2];
//             try {
//               const argList = args ? args.split(',').map(a => a.trim()) : [];
//               return Function(...argList.concat([body]));
//             } catch (e) {
//               console.warn("reviveFunctions: failed to revive arrow-block fn:", e, value);
//               return value;
//             }
//           }
//           if ((m = value.match(arrowExprRegex))) {
//             const args = m[1].trim();
//             const expr = m[2];
//             try {
//               const argList = args ? args.split(',').map(a => a.trim()) : [];
//               return Function(...argList.concat([ 'return (' + expr + ');' ]));
//             } catch (e) {
//               console.warn("reviveFunctions: failed to revive arrow-expr fn:", e, value);
//               return value;
//             }
//           }
//           return value;
//         } else if (Array.isArray(value)) {
//           return value.map(revive);
//         } else if (value && typeof value === 'object') {
//           const out = Array.isArray(value) ? [] : {};
//           for (const k of Object.keys(value)) {
//             out[k] = revive(value[k]);
//           }
//           return out;
//         } else {
//           return value;
//         }
//       }

//       return revive(obj);
//     }

//     // -------------------------
//     // Convert any stringified functions inside chartConfig to real functions
//     // -------------------------
//     try {
//       chartConfig = reviveFunctions(chartConfig);
//     //   console.log("revived chartConfig (functions converted):", chartConfig);
//     } catch (revErr) {
//       console.warn("reviveFunctions failed:", revErr);
//     }

//     // -------------------------
//     // Ensure datalabels plugin presence (safe fallback)
//     // If the config includes options.plugins.datalabels but plugin not available,
//     // remove datalabels entry to avoid Chart.js errors.
//     // -------------------------
//     try {
//       const hasDatalabelsConfig = chartConfig && chartConfig.options && chartConfig.options.plugins && chartConfig.options.plugins.datalabels;
//       const datalabelsAvailable = !!(window && window.ChartDataLabels) || (typeof Chart !== 'undefined' && Chart && Chart._plugins && Chart._plugins.get && Chart._plugins.get('datalabels'));
//       if (hasDatalabelsConfig && !datalabelsAvailable) {
//         console.warn("datalabels plugin not detected — removing datalabels config to avoid errors.");
//         delete chartConfig.options.plugins.datalabels;
//       }
//     } catch (e) {
//       console.warn("datalabels plugin check failed:", e);
//     }

//     // Finally create chart
//     try {
//       new Chart(ctx, chartConfig);
//       console.log("Chart rendered successfully");
//     } catch (chartErr) {
//       console.error("Chart.js render error:", chartErr);
//       chartContainer.insertAdjacentHTML("beforeend",
//         `<pre style="color:darkred;">⚠️ Chart render failed: ${escapeHtml(chartErr.message || String(chartErr))}</pre>`
//       );
//     }
//   }
// } else {
//   console.log("No chart configuration to render");
// }


//         // 🕐 Conversation time UI update
//         let conversationTime = pData.conversation_time || "0 Min 0 Sec";
//         $("#response-" + pData.id)
//           .nextAll("div")
//           .find(".conversation-time-btn")
//           .first()
//           .attr("data-tooltip", conversationTime)
//           .attr("data-time", conversationTime)
//           .attr("title", conversationTime);

//         if (onComplete) onComplete();
//       }
//     });

//       // helper to escape HTML for UI messages
//         function escapeHtml(str) {
//             if (!str) return "";
//             return String(str)
//             .replace(/&/g, "&amp;")
//             .replace(/</g, "&lt;")
//             .replace(/>/g, "&gt;")
//             .replace(/"/g, "&quot;")
//             .replace(/'/g, "&#39;");
//         }
// }
//  else if (type === "sql") {
//         apex.server.process("GET_SQL_RESULTS", { x01: id }, {
//             dataType: "json",
//             success: function(pData) {
//                 el.innerHTML = "";
//                 let promptText = $("#prompt-" + pData.id).text() || "";
//                 let chartType = null;

//                 if (promptText.toLowerCase().includes("pie chart")) chartType = "pie";
//                 else if (promptText.toLowerCase().includes("bar chart")) chartType = "bar";
//                 else if (promptText.toLowerCase().includes("line chart")) chartType = "line";
//                 else if (promptText.toLowerCase().includes("area chart")) chartType = "area";
//                 else if (promptText.toLowerCase().includes("donut chart")) chartType = "donut";
//                 else if (promptText.toLowerCase().includes("funnel chart")) chartType = "funnel";

//                 if (chartType) renderChart(pData.results, "response-" + pData.id, chartType);
//                 else convert(pData.results, "response-" + pData.id);

//                 cnt++;
//                 scrollToLast();

//                 if (pData.totalRowCount > 10) $(".llm-more-rows-" + id).show();
//                 $(".llm-load-message-" + pData.id).hide();
//                 scrollToLast();

//                 // Inject profile label
//                 let profileLabel = pData.profile_name || "Default";
//                 $("#response-" + pData.id)
//                     .nextAll("div")
//                     .find(".profile-label")
//                     .first()
//                     .text(profileLabel);

//                 // Inject conversation time
//                 let conversationTime = pData.conversation_time || "0 Min 0 Sec";
//                 $("#response-" + pData.id)
//                     .nextAll("div")
//                     .find(".conversation-time-btn")
//                     .first()
//                     .attr("data-time", conversationTime)
//                     .attr("title", conversationTime);

//                 // Inject SQL code if available
//                 if (pData.sql) {
//                     const sqlBlock = document.querySelector("#sql-block-" + pData.id + " code");
//                     if (sqlBlock) {
//                         sqlBlock.textContent = pData.sql;
//                         Prism.highlightElement(sqlBlock);
//                     }
//                 }

//                 if (onComplete) onComplete();
//             }
//         });
//     } else {
//         if (onComplete) onComplete();
//     }
// }







// Ensure Chart.js is loaded only once
function ensureChartJsLoaded(callback) {
  if (window.Chart) {
    // Already loaded
    if (callback) callback();
    return;
  }
  if (!document.querySelector('script[src*="chart.js"]')) {
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/chart.js";
    script.onload = () => {
      console.log("Chart.js loaded");
      if (callback) callback();
    };
    document.head.appendChild(script);
  }
}




function highlightLanguageCodes(el) {
  if (!el) return;

  // --- Helpers
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }
  function escapeHtmlAttr(str) {
    return String(str).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  // --- Step 1: Convert Markdown-style code blocks to <pre><code>
  const codeBlockRegex = /```([^\n\r`]*)\r?\n([\s\S]*?)(```|$)/g;
    el.innerHTML = el.innerHTML.replace(codeBlockRegex, (match, langRaw, code) => {
    const lang = (langRaw || "").trim().toLowerCase();
    const aliasMap = {
        "js": "javascript",
        "javascript": "javascript",
        "py": "python",
        "python": "python",
        "c#": "csharp",
        "c++": "cpp",
        "plsql": "plsql",
        "sql": "sql",
        "sh": "bash",
        "bash": "bash",
        "html": "markup",
        "xml": "markup",
        "json": "json"
    };
    const safeLang = aliasMap[lang] || (lang || "none");

    return `<pre><code class="language-${escapeHtmlAttr(safeLang)}">${code}</code></pre>`;
    });


  // --- Step 2: Inline keyword highlighting (text nodes outside code/pre)
  const walker = document.createTreeWalker(
    el,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        let p = node.parentNode;
        while (p) {
          const name = p.nodeName;
          if (["CODE", "PRE", "SCRIPT", "STYLE"].includes(name)) return NodeFilter.FILTER_REJECT;
          p = p.parentNode;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    },
    false
  );

  const textNodes = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode);

  // Define JSON of inline "code terms" to highlight
  const inlineCodeTerms = [
    "parseFloat\\(\\)",
    "parseInt\\(\\)",
    "\\+"
  ];
  const inlineRegex = new RegExp(`\\b(${inlineCodeTerms.join("|")})\\b`, "g");

  textNodes.forEach(node => {
    const value = node.nodeValue;
    if (!inlineRegex.test(value)) return;

    let lastIndex = 0;
    const frag = document.createDocumentFragment();
    value.replace(inlineRegex, (match, p1, offset) => {
      const before = value.slice(lastIndex, offset);
      if (before) frag.appendChild(document.createTextNode(before));

      const span = document.createElement("span");
      span.className = "inline-code-highlight";
      span.textContent = match;
      frag.appendChild(span);

      lastIndex = offset + match.length;
    });

    const after = value.slice(lastIndex);
    if (after) frag.appendChild(document.createTextNode(after));

    node.parentNode.replaceChild(frag, node);
  });

  // --- Step 3: Run Prism on <pre><code> blocks
  if (typeof Prism !== "undefined" && typeof Prism.highlightAllUnder === "function") {
    Prism.highlightAllUnder(el);
    el.querySelectorAll("pre code[class^='language-']").forEach(cb => {
      try { Prism.highlightElement(cb); } catch (e) {}
    });
  } else {
    console.warn("Prism not detected. Inline highlights added, but syntax highlighting requires Prism.js.");
  }
}




// ===============================
// Fetch latest conversation
// ===============================
function fetchAndAppendLatestConversation() {

  console.log("Starting fetchAndAppendLatestConversation...");

  apex.server.process(
    "GET_LATEST_CONV_ROW",
    { pageItems: "#P1_CONV_ID" },
    {
      dataType: "json",
      success: function (data) {
        console.log("GET_LATEST_CONV_ROW success callback fired");
        // console.log("Raw data received from server:", data);

        if (!data || data.length === 0) {
          console.warn("No conversation data returned from server.");
          return;
        }

        const latest = data[0];
        // console.log("Latest conversation row:", latest);

        const container =
          document.querySelector("#PROMPTS .prompt-list") ||
          document.getElementById("PROMPTS");
        // console.log("Prompt container element:", container);

        if (!container) {
          console.error("Container element not found. Cannot append prompt.");
          return;
        }

        // Normalize server prompt text for matching
        const normalizedServerPrompt = normalizePromptText(latest.prompt || "");
        // console.log("Normalized server prompt:", normalizedServerPrompt);

        // Try to find the existing frontend prompt div with matching normalized prompt text
        let matchedPromptId = null;
        for (const tempPromptId in window.pendingPrompts) {
          if (window.pendingPrompts[tempPromptId] === normalizedServerPrompt) {
            matchedPromptId = tempPromptId;
            break;
          }
        }
        console.log("Matched frontend prompt ID:", matchedPromptId);

        // If matched, update the prompt div ID to the real backend ID
        if (matchedPromptId) {
          const promptDiv = document.getElementById(matchedPromptId);
        //   console.log("Frontend prompt div found:", promptDiv);

          if (promptDiv) {
            promptDiv.id = `prompt-${latest.id}`;
            // console.log(`Updated prompt div ID to backend ID: prompt-${latest.id}`);

            // Remove old loader clone with temporary ID
            const oldLoader = document.getElementById("loading-indicator-" + matchedPromptId);
            if (oldLoader) {
              oldLoader.remove();
            //   console.log("Removed old loader with temporary ID:", matchedPromptId);
            }

            // Append new loader clone with backend ID
            const loaderRegion = document.getElementById("loading-indicator");
            if (loaderRegion) {
              const loaderClone = loaderRegion.cloneNode(true);
              loaderClone.style.display = "flex";
              loaderClone.id = "loading-indicator-" + latest.id;
              promptDiv.insertAdjacentElement("afterend", loaderClone);
            //   console.log("Appended new loader with backend ID:", loaderClone.id);

              showLoadingUI(loaderClone.id);
            }

            // Clean up mapping
            delete window.pendingPrompts[matchedPromptId];
            // console.log("Deleted temporary pendingPrompts entry for:", matchedPromptId);
          }
        }

        // Template for response
        const template = `
        <link href="https://fonts.googleapis.com/css2?family=Fira+Code&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

        ${latest.response_type ? `
            <div id="response-${latest.id}" data-id="${latest.id}" data-type="response" class="llm-chat response response-box "></div>

            <!-- 📊 Hidden chart container (only shown when JSON data is found) -->
            <div id="chart-container-${latest.id}" 
                class="chart-container" 
                style="width:100%; height:400px; margin-top:20px; display:none;"></div>

            <div class="speech-controls" data-id="${latest.id}" 
                style="display: flex; justify-content: space-between; align-items: center; padding: 6px; border-radius: 6px; margin-top: 6px; gap: 6px;">
                
                <!-- LEFT: Buttons -->
                <div style="display: inline-flex; gap: 6px;">
                    <button type="button" class="speech-icon-button" onclick="copyResponseToClipboard('${latest.id}')" data-tooltip="Copy">
                        <i class="fas fa-copy"></i>
                    </button>

                    <button type="button" class="speech-icon-button" onclick="toggleSpeech('${latest.id}', this)" data-tooltip="Read Aloud">
                        <i class="fas fa-volume-high"></i>
                    </button>

                    <button type="button" class="speech-icon-button" onclick="deletePrompt('${latest.id}')" data-tooltip="Delete">
                        <i class="fas fa-trash-alt"></i>
                    </button>

                    <button 
                    type="button" 
                    class="speech-icon-button conversation-time-btn" 
                    data-tooltip="${latest.conversation_time || '0 Min 0 Sec'}" 
                    style="cursor: pointer;">
                    <i class="fas fa-clock"></i>
                    </button>

                    ${latest.profile_name && latest.profile_name.startsWith('AGENT') ? `
                    <button 
                        type="button" 
                        class="speech-icon-button view-agent-logs-btn" 
                        onclick="if('${latest.agent_link}') apex.navigation.redirect('${latest.agent_link}')" 
                        data-tooltip="View Agent Logs"
                        style="cursor: pointer;">
                        <i class="fas fa-lightbulb"></i>
                    </button>
                    ` : ''}
                </div>

                <!-- RIGHT: Profile name -->
                <div style="display: inline-flex; align-items: center; gap: 8px;">
                    <span class="profile-label" 
                        style="font-size: 12px; color: #666; white-space: nowrap;">
                        ${latest.profile_name || "Default"}
                    </span>
                </div>
            </div>
        ` : `
            <!-- SQL response block (unchanged) -->
            <div id="response-${latest.id}" data-id="${latest.id}" data-type="sql"
                class="response response-box"
                style="margin-bottom:0;">
                <div class="loading-spinner llm-load-message-${latest.id}" style="text-align:center; padding: 10px;">
                <i class="fa fa-spinner fa-spin fa-2x"></i>
                </div>
            </div>

            <!-- Buttons row -->
            <div class="chart-sql-buttons" style="margin-top:8px; text-align:right; display:flex; gap:12px; justify-content:flex-end;">
            <a href="javascript:void(0);" class="toggle-charts" data-id="${latest.id}">Customize Charts</a>
            <a href="javascript:void(0);" class="toggle-sql" data-id="${latest.id}">Show SQL</a>
            </div>

            <div id="chart-block-${latest.id}" class="chart-block" style="display:none;">
            <div style="display:flex; gap:8px; margin-bottom:48px; align-items:center;">
                <label style="color:black;">Chart Type:</label>
                <select class="chart-type" data-id="${latest.id}">
                <option value="bar">Bar</option>
                <option value="line">Line</option>
                <option value="area">Area</option>
                <option value="pie">Pie</option>
                <option value="donut">Donut</option>
                </select>

                <label style="color:black;">X Axis:</label>
                <select class="chart-xaxis" data-id="${latest.id}"></select>

                <label style="color:black;">Y Axis:</label>
                <select class="chart-yaxis" data-id="${latest.id}"></select>
            </div>

            <div class="chart-wrapper">
                <canvas id="chart-canvas-${latest.id}"></canvas>
            </div>
            </div>

            <div id="sql-block-${latest.id}" class="sql-block" style="display:none; margin-top: 8px;">
            <pre><code class="language-sql">-- SQL will be injected here --</code></pre>
            </div>

            <div style="padding:6px; border-radius:6px; margin-top:4px; margin-bottom:4px; display:flex; justify-content:space-between; align-items:flex-start;">
                <div style="display:flex; flex-direction:column; gap:4px;">
                    <span class="llm-more-rows-${latest.id}" 
                        style="display:none; font-size:12px; color:#0073e6; font-weight:500;">
                        More Rows Available
                    </span>

                    <div style="display:flex; gap:4px; margin-top:4px;">
                        <button type="button" onclick="apex.navigation.redirect('${latest.explore_link}')"
                            class="t-Button t-Button--icon t-Button--small">
                            <span class="t-Icon fa fa-search" aria-hidden="true"></span>
                            <span class="t-Button-label">Explore</span>
                        </button>
                        <button type="button" onclick="apex.navigation.redirect('${latest.explain_link}')"
                            class="t-Button t-Button--icon t-Button--small">
                            <span class="t-Icon fa fa-lightbulb" aria-hidden="true"></span>
                            <span class="t-Button-label">Explain</span>
                        </button>
                        <button type="button" 
                            class="speech-icon-button conversation-time-btn" 
                            data-time="${latest.conversation_time || '0 Min 0 Sec'}"
                            style="cursor: pointer;">
                            <i class="fas fa-clock"></i>
                        </button>
                    </div>
                </div>

                <span class="profile-label" style="font-size:12px; color:#666; white-space:nowrap;">
                    ${latest.profile_name || "Default"}
                </span>
            </div>
        `}
        `;



        // console.log("Generated HTML template for latest response.");

        // Append response below prompt
        container.insertAdjacentHTML("beforeend", template);
        // console.log("Appended template to container.");

        const respEl = document.getElementById(`response-${latest.id}`);
        scrollToEndFor(respEl);
        // console.log("Scrolled to end of new response element:", respEl);

        // Ensure Chart.js is loaded before handling response
        ensureChartJsLoaded(() => {
          console.log("Chart.js loaded, initializing single LLM response for ID:", latest.id);

          initSingleLLMResponse(latest.id, function() {
            hideLoadingUI("loading-indicator-" + latest.id);

            // Only highlight if it's a text response (not sql/chart)
            const respEl = document.getElementById(`response-${latest.id}`);
            if (respEl && respEl.getAttribute("data-type") === "response") {
              highlightLanguageCodes(respEl);
              console.log("Finished processing LLM response with Prism:", latest.id);
            } else {
              console.log("Skipping highlightLanguageCodes for chart/table response:", latest.id);
            }
          });
        });


        loadPromptHistory();

        // Restore focus to P1_PROMPT1 (retry to handle refresh timing)
        setTimeout(() => {
          const textarea = document.getElementById("P1_PROMPT1");
          if (textarea) {
            textarea.focus({ preventScroll: true });
            // move cursor to end
            textarea.selectionStart = textarea.selectionEnd = textarea.value.length;
            // console.log("Focus restored to P1_PROMPT1");
          } else {
            console.warn("Could not find P1_PROMPT1 to restore focus");
          }
        }, 150); // small delay so refresh completes

         hideLoadingUI("loading-indicator-" + latest.id);

      },
      error: function (jqXHR, textStatus, errorThrown) {
        console.error("GET_LATEST_CONV_ROW AJAX error:", textStatus, errorThrown);

            hideLoadingUI(apex.item("P1_LATEST_LOADER_ID").getValue());

            apex.message.showErrors([
                {
                type: "error",
                location: "page",
                message: "Unexpected error occurred.",
                unsafe: false
                }
            ]);
      }
    }
  );
}


function explorePrompt(url) {
    apex.navigation.redirect(url);
}
function explainPrompt(url) {
    apex.navigation.redirect(url);
}
function deletePrompt(url) {
    apex.navigation.redirect(url);
}
function agentPrompt(url) {
    apex.navigation.redirect(url);
}




function deletePrompt(promptId) {
  console.log("🗑️ Delete button clicked. Prompt ID:", promptId);

  // Ask for confirmation
  if (!confirm("Are you sure you want to delete this prompt?")) {
    console.log("Delete cancelled by user.");
    return; // exit if user cancels
  }

  apex.server.process(
    "DELETE_PROMPT",      // AJAX process name
    { x01: promptId },    // pass promptId as x01
    {
      dataType: "json",   // expecting JSON response
      success: function(pData) {
        console.log("AJAX call SUCCESS. Server response:", pData);

        if (pData.status === "success") {
          // Show success message
          apex.message.showPageSuccess("Prompt Deleted Successfully");

          // Submit the page while preserving P1_CONV_ID
          var convId = $v("P1_CONV_ID"); // get current value
          console.log("Submitting page with P1_CONV_ID:", convId);

          apex.submit("DELETE_AND_REFRESH", { // "DELETE_AND_REFRESH" = request name
            set: { P1_CONV_ID: convId }
          });

        } else {
          console.error("Server returned error:", pData.message);
          alert("Failed to delete prompt: " + pData.message);
        }
      },
      error: function(xhr, status, error) {
        console.error("AJAX request FAILED");
        console.error("Status:", status);
        console.error("Error:", error);
        console.error("Response Text:", xhr.responseText);
        alert("Failed to delete prompt. Check console for details.");
      }
    }
  );
}



$(document).on("click", ".conversation-time-btn", function() {
    let time = $(this).attr("data-time") || "0 Min 0 Sec"; // get updated value
    let $tooltip = $('<div class="temp-tooltip"></div>').text(time)
        .css({
            position: 'absolute',
            background: '#333',
            color: '#fff',
            padding: '4px 8px',
            borderRadius: '4px',
            fontSize: '12px',
            zIndex: 9999,
            whiteSpace: 'nowrap'
        });

    $('body').append($tooltip);

    let offset = $(this).offset();
    $tooltip.css({
        top: offset.top - $tooltip.outerHeight() - 6,
        left: offset.left + $(this).outerWidth()/2 - $tooltip.outerWidth()/2
    });

    setTimeout(() => {
        $tooltip.fadeOut(300, () => $tooltip.remove());
    }, 2000);
});




// function addFullScreenScroll() {
//   // Remove old spacer if exists
//   let spacer = document.getElementById("fullScreenScrollSpacer");
//   if (!spacer) {
//     spacer = document.createElement("div");
//     spacer.id = "fullScreenScrollSpacer";
//     document.body.appendChild(spacer);
//   }

//   // Always set spacer height so that total = viewport height
//   const contentHeight = document.body.scrollHeight - spacer.offsetHeight;
//   const needed = window.innerHeight - contentHeight;
//   spacer.style.height = (needed > 0 ? needed : 0) + "px";
// }

// window.addEventListener("load", addFullScreenScroll);
// window.addEventListener("resize", addFullScreenScroll);



function adjustPadding() {
  const content = document.querySelector('.t-Body-content');
  const screenWidth = window.screen.width; // physical screen width

  if (screenWidth > 1900) {   // external monitor
    content.style.paddingLeft = "296px";
    content.style.paddingRight = "296px";
  } else if (screenWidth > 1200) { // laptop
    content.style.paddingLeft = "156px";
    content.style.paddingRight = "156px";
  } else if (screenWidth > 768) {
    content.style.paddingLeft = "100px";
    content.style.paddingRight = "100px";
  } else {
    content.style.paddingLeft = "20px";
    content.style.paddingRight = "20px";
  }
}

// Run on load + when window is moved/resized
window.addEventListener("load", adjustPadding);
window.addEventListener("resize", adjustPadding);


function adjustLineHeight() {
  document.querySelectorAll(".message-bubble").forEach(el => {
    // Check if text takes more than one line
    if (el.scrollHeight > el.clientHeight + 1) {
      el.classList.add("multi-line");
    } else {
      el.classList.remove("multi-line");
    }
  });
}

// Run on load and when window resizes
window.addEventListener("load", adjustLineHeight);
window.addEventListener("resize", adjustLineHeight);



// Global variables
let promptHistory = [];
let currentIndex = -1;

function loadPromptHistory(callback) {
  apex.server.process("GET_PROMPT_HISTORY", {}, {
    success: function(response) {
      if (response.error) {
        console.error("Error loading prompts:", response.error);
        return;
      }
      try {
        promptHistory = JSON.parse(response.data) || [];
        currentIndex = -1;
        if (typeof callback === "function") {
          callback(promptHistory);
        }
      } catch (e) {
        console.error("Failed to parse JSON:", e);
      }
    }
  });
}

function attachPromptHistoryNavigation(inputId) {
  const input = document.getElementById(inputId);
  if (!input) {
    console.warn("Input not found:", inputId);
    return;
  }

  input.addEventListener("keydown", function(e) {
    if (e.key === "ArrowUp") {
      e.preventDefault();
      if (promptHistory.length > 0 && currentIndex > 0) {
        currentIndex--;
        this.value = promptHistory[currentIndex];
      } else if (currentIndex === -1 && promptHistory.length > 0) {
        // First press of ArrowUp starts at last item
        currentIndex = promptHistory.length - 1;
        this.value = promptHistory[currentIndex];
      }
      // Do nothing if already at first item
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (promptHistory.length > 0 && currentIndex < promptHistory.length - 1) {
        currentIndex++;
        this.value = promptHistory[currentIndex];
      }
      // Do nothing if already at last item
    }
  });
}



const finishedPrompts = new Set();

// ===================================================
// Helper: Remove Placeholder Container
// ===================================================
function removePonderingContainer(tempPromptId) {
    const container = document.getElementById(tempPromptId);
    if (!container) return;

    // Stop all intervals safely
    if (container._dotInterval) {
        clearInterval(container._dotInterval);
        container._dotInterval = null;
    }
    if (container._localDotInterval) {
        clearInterval(container._localDotInterval);
        container._localDotInterval = null;
    }

    // Remove any thinking element inside
    const thinkingEl = container.querySelector(".thinking");
    if (thinkingEl) thinkingEl.remove();

    // Remove container itself
    container.remove();
}

// ===================================================
// Helper: Insert Placeholder Container
// ===================================================
function insertThoughtsContainer(tempPromptId) {
    if (finishedPrompts.has(tempPromptId)) return; // ❌ Do not insert after final

    const chatArea = document.querySelector("#PROMPTS .prompt-list") || document.getElementById("PROMPTS");
    if (!chatArea) {
        console.error("Cannot insert thoughts container: PROMPTS container not found");
        return;
    }

    const div = document.createElement("div");
    div.id = tempPromptId;
    div.className = "agent-thoughts";
    div.innerHTML = `
        <div class='thinking' style="font-weight:600; font-size:0.95em; color:#4576d8; margin-top:6px;">
            💡 Pondering ideas <span class="dots">.....</span>
        </div>
    `;
    chatArea.appendChild(div);
    console.log("Thoughts container inserted for:", tempPromptId);

    // Animate dots
    let dotCount = 0;
    if (!div._dotInterval) {
        const dotsSpan = div.querySelector(".dots");
        div._dotInterval = setInterval(() => {
            dotCount = (dotCount + 1) % 6;
            if (dotsSpan) dotsSpan.textContent = ".".repeat(dotCount);
        }, 150);
    }
}




// ===================================================
// Global maps to track last thought hash and count per prompt
// ===================================================
window.thoughtHistory = {}; // { [tempPromptId]: { lastHash: '', counter: 1, placeholders: { text: hash } } }

// ===================================================
// Simple hash function for strings
// ===================================================
function hashString(str) {
    let hash = 0, i, chr;
    if (str.length === 0) return hash;
    for (i = 0; i < str.length; i++) {
        chr = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}

// ===================================================
// Strip HTML
// ===================================================
function cleanText(text) {
    const div = document.createElement("div");
    div.innerHTML = text;
    return div.textContent || div.innerText || "";
}

// ===================================================
// Render Thoughts in Container
// ===================================================
function renderThoughts(tempPromptId, thoughts, finalResponseReceived = false) {
    if (finishedPrompts.has(tempPromptId)) return;

    let container = document.getElementById(tempPromptId);

    // Filter out empty responses or just dash
    const validThoughts = thoughts.filter(t => {
        const match = t.text.match(/<b>(.*?)<\/b>/);
        const innerText = match ? match[1].trim() : "";
        return innerText.length > 0 && innerText !== "-";
    });

    if (!validThoughts.length) return;

    if (!container) {
        insertThoughtsContainer(tempPromptId);
        container = document.getElementById(tempPromptId);
    }

    // Initialize history for this prompt
    if (!window.thoughtHistory[tempPromptId]) {
        window.thoughtHistory[tempPromptId] = { lastHash: null, counter: 0, placeholders: {} };
    }

    const firstThought = validThoughts[0];
    const cleaned = cleanText(firstThought.text).trim();
    const currentHash = hashString(cleaned);

    // Increment counter only if hash differs
    if (currentHash !== window.thoughtHistory[tempPromptId].lastHash) {
        window.thoughtHistory[tempPromptId].counter++;
        window.thoughtHistory[tempPromptId].lastHash = currentHash;
    }

    const stepNumber = window.thoughtHistory[tempPromptId].counter || 1;

    // Determine placeholder text and icon
    const placeholderIcons = {
        "Analyzing the prompt": "🧐",
        "Thinking": "🤔",
        "Checking distinct values from the database": "🔍",
        "Discovering schema metadata using sample rows": "📊",
        "Searching the web": "🌐",
        "Executing the SQL query": "💻",
        "Querying vector index":"🗂️",
        "Summarizing the content":"✍️",
        "Deep thinking":"🧠"
    };

    let thinkingText = "Thinking";
    for (const pt of Object.keys(placeholderIcons)) {
        if (cleaned.toLowerCase().includes(pt.toLowerCase())) {
            thinkingText = pt;
            break;
        }
    }
    const icon = placeholderIcons[thinkingText] || "🤔";

    // Build placeholder HTML
    let html = `<div class="thinking" style="font-weight:600; font-size:0.95em; color:#4576d8; margin-bottom:6px;">
        ${stepNumber}. ${icon} ${thinkingText}<span class="dots">.....</span>
    </div>`;

    // Render additional non-placeholder thoughts
    validThoughts.forEach(t => {
        const tClean = cleanText(t.text).trim();
        if (Object.keys(placeholderIcons).some(pt => tClean.toLowerCase().includes(pt.toLowerCase()))) return;

        html += `
            <div class="thought-step-collapsible" style="border:1px solid #ccc; border-radius:5px; padding:6px; margin-bottom:6px; background:#fff; font-size:0.9em; color:#222;">
                <div class="thought-content" style="max-height:5.5em; overflow:hidden; line-height:1.4em;">${t.text}</div>
                <div class="thought-footer" style="text-align:right; font-size:0.8em; color:#444; margin-top:2px;">${t.created}</div>
                <a href="javascript:void(0);" class="expand-btn" style="font-size:0.8em; display:none; color:#0056b3; text-decoration:underline; cursor:pointer;">Show more</a>
            </div>
        `;
    });

    container.innerHTML = html;

    // Animate dots
    let dotCount = 0;
    const dotsSpan = container.querySelector(".thinking .dots");
    if (container._dotInterval) clearInterval(container._dotInterval);
    container._dotInterval = setInterval(() => {
        if (dotsSpan) dotsSpan.textContent = ".".repeat((dotCount = (dotCount + 1) % 6));
    }, 200);

    // Collapsible logic
    const steps = container.querySelectorAll(".thought-step-collapsible");
    steps.forEach(step => {
        const contentDiv = step.querySelector(".thought-content");
        const expandBtn = step.querySelector(".expand-btn");
        const lineHeight = parseFloat(getComputedStyle(contentDiv).lineHeight);
        const maxHeight = 2 * lineHeight;
        if (contentDiv.scrollHeight > maxHeight) {
            expandBtn.style.display = "inline-block";
            expandBtn.onclick = () => {
                if (contentDiv.style.maxHeight === "none") {
                    contentDiv.style.maxHeight = maxHeight + "px";
                    expandBtn.textContent = "Show more";
                } else {
                    contentDiv.style.maxHeight = "none";
                    expandBtn.textContent = "Show less";
                }
            };
        }
    });
}









// ===================================================
// Poll Agent Thoughts (Keep polling until stopped)
// ===================================================
function pollAgentThoughts(conversationId, tempPromptId) {
    const pollInterval = 5000;
    let stopPolling = false;

    function checkThoughts() {
        if (stopPolling || finishedPrompts.has(tempPromptId)) return;

        apex.server.process(
            "GET_AGENT_THOUGHTS",
            { x01: conversationId },
            {
                dataType: "json",
                success: function (data) {
                    // console.log("📡 Agent data:", data);

                    if (Array.isArray(data) && data.length > 0) {
                        const thoughts = data.map(item => ({
                            text: item.response,
                            created: new Date().toLocaleTimeString()
                        }));
                        renderThoughts(tempPromptId, thoughts);
                    }

                    setTimeout(checkThoughts, pollInterval);
                },
                error: function () {
                    setTimeout(checkThoughts, pollInterval);
                }
            }
        );
    }

    checkThoughts();

    return function stop() {
        stopPolling = true;
    };
}

// ===================================================
// Run Prompt Asynchronously
// ===================================================
function runPromptAsync() {
    console.log("⚡ runPromptAsync() called!");

    const convId = $v("P1_CONV_ID");
    const tempPromptId = "temp-" + Date.now();
    const conversationalStyle = $v("P1_CONVERSATION_STYLE");

    let stopPolling = () => {};

    if (conversationalStyle === "USER_AGENTS") {
        hideLoadingUI(apex.item("P1_LATEST_LOADER_ID").getValue());
          promptInput.disabled = true;
          runButton.disabled = true;

        // Insert thinking placeholder immediately
        insertThoughtsContainer(tempPromptId);

        // Start polling
        stopPolling = pollAgentThoughts(convId, tempPromptId);
    }

    // Execute prompt asynchronously
    apex.server.process(
        "EXECUTE_PROMPT",
        {
            pageItems: "#P1_ASK_ADB,#P1_SWITCH_NARRATE,#P1_CURRENT_AI_PROFILE,#P1_PROMPT,#P1_CONV_ID,#P1_RAG_CHAT,#P1_RAG_SQL"
        },
        {
            dataType: "json",
            success: function (pData) {
                console.log("EXECUTE_PROMPT finished (async).");

                stopPolling();
                finishedPrompts.add(tempPromptId); // ✅ prevent further thinking inserts
                removePonderingContainer(tempPromptId);

                // Fetch final conversation
                fetchAndAppendLatestConversation();

                const endTime = new Date();
                console.log(`Ending conversation time: ${endTime.toLocaleTimeString()}`);
            },
            error: function (xhr) {
                stopPolling();
                finishedPrompts.add(tempPromptId);
                removePonderingContainer(tempPromptId);

                let serverMessage = "";
                try { serverMessage = JSON.parse(xhr.responseText).message || ""; } catch(e) { serverMessage = xhr.responseText; }
                apex.message.showErrors([{ type:"error", location:"page", message:`Unexpected error occurred.<br><strong>Details:</strong> ${serverMessage}` }]);
            }
        }
    );
}

