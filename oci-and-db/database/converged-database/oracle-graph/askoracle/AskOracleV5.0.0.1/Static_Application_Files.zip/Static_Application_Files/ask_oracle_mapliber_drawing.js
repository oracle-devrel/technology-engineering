/* Ask Oracle drawing v1.6.0. Load after map + interactions.
 * Local annotations only; never submits SQL or changes returned districts.
 * Optional ask_oracle_mapliber_storage_brser.js persists drawings in IndexedDB.
 * Shift+drag always belongs to feature selection, not drawing.
 */
(function () {
  'use strict';
  if (window.askOracleMapDrawing) return;
  const sessions = new Map(), SOURCE = 'aod-drawings';
  const LAYERS = ['aod-fill', 'aod-line', 'aod-point'];
  let storageAdapter = null, menuSerial = 0;
  let stopped = false;
  function attach(id, map, block) {
    const canvas = map.getCanvasContainer();
    const s = { id, map, block, mode: '', features: [], vertices: [], serial: 0, drag: null, preview: null };
    const toolbar = document.createElement('div'); toolbar.className = 'aod-toolbar';
    toolbar.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:10px;background:white;color:#172b3a;';
    toolbar.setAttribute('aria-label', 'Map drawing tools');
    const hint = document.createElement('span'); hint.setAttribute('role', 'status');
    // Same ordinary body-mounted menu approach as Analysis; no popover or canvas styling.
    const controller = new AbortController();
    const listen = (el, type, fn) => el.addEventListener(type, fn, { signal: controller.signal });
    const root = document.createElement('div'); root.className = 'aod-menu-root';
    const trigger = document.createElement('button'); trigger.type = 'button';
    trigger.className = 'aod-menu-trigger'; trigger.textContent = 'Drawing ▾';
    trigger.setAttribute('aria-haspopup', 'menu'); trigger.setAttribute('aria-expanded', 'false');
    const menu = document.createElement('div'); menu.className = 'aod-menu-panel';
    menu.id = 'aod-tools-menu-' + (++menuSerial); menu.hidden = true;
    menu.setAttribute('role', 'menu'); menu.setAttribute('aria-label', 'Drawing menu');
    trigger.setAttribute('aria-controls', menu.id);
    root.appendChild(trigger); toolbar.appendChild(root);
    // The unchanged Analysis module uses this hidden anchor to insert after Drawing.
    const anchor = document.createElement('select'); anchor.hidden = true;
    anchor.tabIndex = -1; anchor.setAttribute('aria-hidden', 'true');
    anchor.style.setProperty('display', 'none', 'important'); toolbar.appendChild(anchor);
    const style = document.createElement('style');
    style.textContent = `
      .aod-menu-root{display:inline-flex;align-items:center}
      .aod-menu-trigger{appearance:none!important;border:0!important;box-shadow:none!important;background:transparent!important;color:#172b3a!important;padding:9px 14px!important;border-radius:6px!important;font:600 14px/1.4 "Segoe UI",Arial,sans-serif!important;cursor:pointer!important}
      .aod-menu-trigger:hover,.aod-menu-trigger[aria-expanded=true]{background:#eaf1f6!important}
      .aod-menu-panel{position:fixed;z-index:100005;box-sizing:border-box;min-width:185px;max-width:calc(100vw - 16px);padding:5px;background:#fff;border:1px solid #dce2e8;border-radius:8px;box-shadow:0 8px 24px #172b3a26;overflow-y:auto}
      .aod-menu-panel[hidden]{display:none!important}
      .aod-menu-panel button{display:block!important;width:100%!important;text-align:left!important;border:0!important;box-shadow:none!important;background:transparent!important;color:#172b3a!important;border-radius:4px!important;padding:9px 12px!important;font:14px/1.4 "Segoe UI",Arial,sans-serif!important;cursor:pointer!important}
      .aod-menu-panel button:hover,.aod-menu-panel button:focus-visible{background:#eaf4fb!important}
      .aod-menu-panel button:disabled,.aod-menu-trigger:disabled{opacity:.45;cursor:default!important}
      .aod-menu-trigger:focus-visible,.aod-menu-panel button:focus-visible{outline:2px solid #007d9a!important;outline-offset:2px}
    `;
    toolbar.appendChild(style); document.body.appendChild(menu);
    const actions = new Map();
    function closeMenu(focus) {
      menu.hidden = true; trigger.setAttribute('aria-expanded', 'false');
      if (focus) trigger.focus();
    }
    function item(label, action) {
      const button = document.createElement('button'); button.type = 'button';
      button.textContent = label; button.setAttribute('role', 'menuitem');
      menu.appendChild(button); actions.set(label, action);
      listen(button, 'click', () => {
        if (s.storageBusy || button.disabled) return;
        closeMenu(true); action();
      });
      return button;
    }
    function enabledItems() { return [...menu.querySelectorAll('button')].filter(button => !button.disabled); }
    function openMenu() {
      if (s.storageBusy || block.hidden) return;
      closeContextMenu(false);
      menu.style.maxHeight = Math.max(1, window.innerHeight - 16) + 'px';
      menu.hidden = false; trigger.setAttribute('aria-expanded', 'true');
      const r = trigger.getBoundingClientRect(), bounds = menu.getBoundingClientRect();
      menu.style.left = Math.max(8, Math.min(r.left, window.innerWidth - bounds.width - 8)) + 'px';
      menu.style.top = Math.max(8, r.bottom + bounds.height < window.innerHeight ? r.bottom + 4 : r.top - bounds.height - 4) + 'px';
      enabledItems()[0]?.focus();
    }
    listen(trigger, 'click', () => menu.hidden ? openMenu() : closeMenu(false));
    listen(trigger, 'keydown', e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); openMenu(); }
    });
    function menuKey(e) {
      if (menu.hidden) return false;
      if (e.key === 'Escape') { stop(e); closeMenu(true); return true; }
      if (!menu.contains(e.target)) return false;
      if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) {
        stop(e);
        const items = enabledItems(), i = items.indexOf(document.activeElement);
        const next = e.key === 'Home' ? 0 : e.key === 'End' ? items.length - 1 :
          (i + (e.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length;
        items[next]?.focus(); return true;
      }
      if (e.key === 'Tab') closeMenu(false);
      return true; // Menu keyboard actions must not finish/cancel an in-progress drawing.
    }
    window.addEventListener('scroll', e => {
      if (e.target !== menu && !(e.target instanceof Node && menu.contains(e.target))) closeMenu(false);
    }, { capture: true, passive: true, signal: controller.signal });
    listen(window, 'resize', () => closeMenu(false));
    function render() {
      const features = s.features.slice();
      if (s.preview) features.push({ type: 'Feature', properties: {}, geometry: s.preview });
      map.getSource(SOURCE).setData({ type: 'FeatureCollection', features });
    }
    function changed() { if (s.storage) s.storage.changed(); }
    function clearSelection() {
      if (s.selected !== undefined && map.getSource(SOURCE)) {
        map.setFeatureState({ source: SOURCE, id: s.selected }, { drawingSelected: false });
      }
      s.selected = undefined;
      const popup = s.popup; s.popup = null; if (popup) popup.remove();
    }
    function hitDrawing(event) {
      const p = pixel(event);
      const hits = map.queryRenderedFeatures([[p[0] - 4, p[1] - 4], [p[0] + 4, p[1] + 4]], { layers: LAYERS });
      return hits.map(hit => s.features.find(f => f.id === hit.id)).find(Boolean);
    }
    function selectFeature(feature) {
      clearSelection(); s.selected = feature.id;
      map.setFeatureState({ source: SOURCE, id: feature.id }, { drawingSelected: true });
    }
    function inspect(feature, event) {
      const previous = s.popup; s.popup = null; if (previous) previous.remove();
      const content = document.createElement('div');
      content.style.cssText = 'max-height:260px;overflow:auto;color:#172b3a;overflow-wrap:anywhere;';
      const properties = feature.properties || {}, heading = document.createElement('h3');
      heading.style.cssText = 'margin:0 0 8px;font-size:15px;';
      heading.textContent = properties.name || (feature.geometry.type === 'LineString' ? 'Line' : feature.geometry.type) + ' ' + feature.id;
      content.appendChild(heading);
      const table = document.createElement('table'); table.style.cssText = 'width:100%;border-collapse:collapse;text-align:left;';
      const row = (label, value) => {
        const tr = document.createElement('tr'), th = document.createElement('th'), td = document.createElement('td');
        th.scope = 'row'; th.textContent = label;
        td.textContent = value == null ? 'NULL' : typeof value === 'object' ? JSON.stringify(value) : String(value);
        th.style.cssText = td.style.cssText = 'padding:4px 8px;border-bottom:1px solid #d8dfe7;vertical-align:top;';
        tr.append(th, td); table.appendChild(tr);
      };
      row('Feature ID', feature.id); row('Geometry', feature.geometry.type);
      const fields = Object.keys(properties).filter(k => k !== 'drawing' && k !== 'name');
      fields.forEach(k => row(k, properties[k])); content.appendChild(table);
      if (!fields.length) {
        const note = document.createElement('p'); note.textContent = 'No custom attributes. Use Save drawings to add optional attributes.'; content.appendChild(note);
      }
      if (window.maplibregl?.Popup) {
        const popup = new window.maplibregl.Popup({ closeOnClick: false, maxWidth: '360px' })
          .setLngLat(coordinate(event)).setDOMContent(content).addTo(map);
        s.popup = popup;
        popup.on('close', () => { if (s.popup === popup) s.popup = null; });
      } else hint.textContent = 'Selected drawing. MapLibre popup support is unavailable.';
      return true;
    }
    function closeContextMenu(focus) {
      if (!s.contextMenu) return;
      s.contextMenu.remove(); s.contextMenu = null;
      if (focus) map.getCanvas().focus();
    }
    function contextMenu(event, feature) {
      closeMenu(false); closeContextMenu(false);
      const panel = document.createElement('div'); s.contextMenu = panel;
      panel.setAttribute('role', 'menu'); panel.setAttribute('aria-label', 'Drawing feature actions');
      panel.style.cssText = 'position:fixed;z-index:100002;display:grid;gap:0;padding:3px;background:#f7f7f7;color:#202020;border:1px solid #b8b8b8;border-radius:2px;box-shadow:2px 3px 8px #0003;min-width:180px;max-width:calc(100vw - 16px);font:13px/1.5 "Segoe UI",Tahoma,Arial,sans-serif;';
      const menuStyle = document.createElement('style');
      menuStyle.textContent = '.aod-context-item{appearance:none!important;display:block!important;width:100%!important;box-sizing:border-box!important;margin:0!important;padding:5px 22px!important;border:0!important;border-radius:0!important;box-shadow:none!important;background:transparent!important;color:#202020!important;font:inherit!important;text-align:left!important;text-transform:none!important;letter-spacing:normal!important;cursor:default!important;min-height:28px!important;height:auto!important;outline:none!important}.aod-context-item:hover,.aod-context-item:focus-visible{background:#dceeff!important;color:#102a43!important}.aod-context-item:focus-visible{outline:1px solid #8ab9e0!important;outline-offset:-1px}.aod-context-item:active{background:#c6e3fc!important}';
      panel.appendChild(menuStyle);
      const location = { clientX: event.clientX, clientY: event.clientY };
      const choices = [
        ['Select feature', () => selectFeature(feature)],
        ['Deselect feature', () => { if (s.selected === feature.id) clearSelection(); }],
        ['Show attributes', () => inspect(feature, location)]
      ].map(([label, action]) => {
        const button = document.createElement('button'); button.type = 'button';
        button.className = 'aod-context-item'; button.textContent = label; button.setAttribute('role', 'menuitem');
        button.addEventListener('click', e => {
          stop(e); closeContextMenu(true);
          if (!s.storageBusy && s.features.some(f => f.id === feature.id)) action();
        }); panel.appendChild(button); return button;
      });
      panel.addEventListener('keydown', e => {
        if (e.key === 'Escape') { stop(e); closeContextMenu(true); }
        else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          stop(e); const i = choices.indexOf(document.activeElement);
          choices[(i + (e.key === 'ArrowDown' ? 1 : choices.length - 1)) % choices.length].focus();
        } else if (e.key === 'Tab') closeContextMenu(false);
      });
      document.body.appendChild(panel); const bounds = panel.getBoundingClientRect();
      panel.style.left = Math.max(4, Math.min(event.clientX, window.innerWidth - bounds.width - 8)) + 'px';
      panel.style.top = Math.max(4, Math.min(event.clientY, window.innerHeight - bounds.height - 8)) + 'px';
      choices[0].focus();
    }
    function outsideContext(event) {
      if (!menu.contains(event.target) && !root.contains(event.target)) closeMenu(false);
      if (s.contextMenu && !s.contextMenu.contains(event.target)) closeContextMenu(false);
    }
    function mode(next) {
      closeContextMenu(false);
      clearSelection(); s.inspectStart = null; s.inspectClick = false;
      s.mode = next; s.vertices = []; s.preview = null; s.drag = null; render();
      canvas.style.cursor = next === 'Select' ? 'pointer' : next ? 'crosshair' : s.oldCursor;
      hint.textContent = next === 'Select' ? 'Click a drawing to highlight only. Right-click for Select, Deselect or Show attributes.' : next === 'Point' ? 'Click to place points.' : next === 'Line' || next === 'Polygon' ? 'Click vertices; Finish / Enter to save; Escape to cancel.' : next === 'Rectangle' ? 'Drag to draw a rectangle (without Shift).' : next === 'Delete' ? 'Click a drawn shape to delete it. Districts are not deleted.' : 'Right-click a drawing for Select, Deselect or Show attributes. Shift + drag selects districts.';
      finishButton.disabled = !['Line', 'Polygon'].includes(next);
    }
    function commit(geometry) {
      s.features.push({ type: 'Feature', id: ++s.serial, properties: { drawing: true }, geometry });
      s.preview = null; s.vertices = []; render(); changed();
    }
    function finish() {
      const points = s.vertices;
      if (s.mode === 'Line' && points.length >= 2) { commit({ type: 'LineString', coordinates: points.slice() }); mode(''); }
      else if (s.mode === 'Polygon' && points.length >= 3) { commit({ type: 'Polygon', coordinates: [[...points, points[0]]] }); mode(''); }
      else hint.textContent = 'Add at least ' + (s.mode === 'Polygon' ? '3' : '2') + ' different vertices first.';
    }
    ['Point', 'Line', 'Polygon', 'Rectangle', 'Delete'].forEach(name => item(name === 'Delete' ? 'Delete drawing' : name, () => mode(name)));
    item('Select drawing', () => mode('Select'));
    const finishButton = item('Finish', finish);
    item('Cancel / Pan', () => mode(''));
    item('Clear drawings', () => { const hadDrawings = s.features.length > 0; s.features = []; mode(''); if (hadDrawings) changed(); });
    toolbar.appendChild(hint);
    const surface = block.querySelector('.ask-oracle-map-canvas');
    block.insertBefore(toolbar, surface || block.firstChild);
    map.addSource(SOURCE, { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
    const selected = ['boolean', ['feature-state', 'drawingSelected'], false];
    map.addLayer({ id: LAYERS[0], source: SOURCE, type: 'fill', filter: ['==', ['geometry-type'], 'Polygon'], paint: { 'fill-color': ['case', selected, '#ffd600', '#ab47bc'], 'fill-opacity': ['case', selected, 0.5, 0.25] } });
    map.addLayer({ id: LAYERS[1], source: SOURCE, type: 'line', filter: ['!=', ['geometry-type'], 'Point'], paint: { 'line-color': ['case', selected, '#ffd600', '#852899'], 'line-width': ['case', selected, 5, 3] } });
    map.addLayer({ id: LAYERS[2], source: SOURCE, type: 'circle', filter: ['==', ['geometry-type'], 'Point'], paint: { 'circle-color': ['case', selected, '#ffd600', '#852899'], 'circle-radius': ['case', selected, 9, 6], 'circle-stroke-color': '#ffffff', 'circle-stroke-width': 2 } });
    s.oldCursor = canvas.style.cursor;
    function pixel(event) { const r = map.getCanvas().getBoundingClientRect(); return [event.clientX - r.left, event.clientY - r.top]; }
    function coordinate(event) { const p = map.unproject(pixel(event)); return [p.lng, p.lat]; }
    function stop(e) { e.preventDefault(); e.stopImmediatePropagation(); }
    function rectangle(a, b) { return { type: 'Polygon', coordinates: [[a, [b[0], a[1]], b, [a[0], b[1]], a]] }; }
    function down(e) {
      if (e.button === 2 && !s.storageBusy && !e.shiftKey && hitDrawing(e)) { stop(e); return; }
      s.inspectStart = null; s.inspectClick = false;
      if (!s.storageBusy && (!s.mode || s.mode === 'Select') && !e.shiftKey && e.button === 0) {
        s.inspectStart = { point: pixel(e), pointerId: e.pointerId }; return;
      }
      if (s.storageBusy || !s.mode || e.shiftKey || e.button !== 0) return;
      stop(e); s.drag = { start: pixel(e), coordinate: coordinate(e), pointerId: e.pointerId };
    }
    function move(e) {
      if (s.mode === 'Select') return;
      if (!s.mode || e.shiftKey || (s.drag && e.pointerId !== s.drag.pointerId)) return;
      if (s.drag) stop(e);
      if (s.mode === 'Rectangle' && s.drag) s.preview = rectangle(s.drag.coordinate, coordinate(e));
      else if (s.vertices.length && (s.mode === 'Line' || s.mode === 'Polygon')) {
        const points = [...s.vertices, coordinate(e)];
        s.preview = s.mode === 'Polygon' && points.length >= 3 ? { type: 'Polygon', coordinates: [[...points, points[0]]] } : { type: 'LineString', coordinates: points };
      }
      render();
    }
    function up(e) {
      if (s.inspectStart && e.pointerId === s.inspectStart.pointerId) {
        const p = pixel(e), a = s.inspectStart.point;
        s.inspectClick = !e.shiftKey && Math.hypot(p[0] - a[0], p[1] - a[1]) < 5;
        s.inspectStart = null; return;
      }
      if (!s.drag || e.pointerId !== s.drag.pointerId) return;
      stop(e); const drag = s.drag; s.drag = null;
      const p = pixel(e), distance = Math.hypot(p[0] - drag.start[0], p[1] - drag.start[1]);
      if (s.mode === 'Rectangle') {
        if (distance >= 4 && Math.abs(p[0] - drag.start[0]) >= 2 && Math.abs(p[1] - drag.start[1]) >= 2) commit(rectangle(drag.coordinate, coordinate(e)));
        else { s.preview = null; render(); }
      } else if (distance < 5) {
        if (s.mode === 'Point') commit({ type: 'Point', coordinates: coordinate(e) });
        else if (s.mode === 'Delete') {
          const hit = map.queryRenderedFeatures(p, { layers: LAYERS })[0];
          if (hit && s.features.some(f => f.id === hit.id)) { s.features = s.features.filter(f => f.id !== hit.id); render(); changed(); }
        } else {
          const next = coordinate(e), last = s.vertices[s.vertices.length - 1];
          if (!last || last[0] !== next[0] || last[1] !== next[1]) s.vertices.push(next);
          s.preview = s.vertices.length > 1 ? { type: 'LineString', coordinates: s.vertices.slice() } : { type: 'Point', coordinates: next }; render();
        }
      }
    }
    function blockClick(e) {
      if (e.shiftKey || s.storageBusy) return;
      if (e.type === 'contextmenu') {
        const feature = hitDrawing(e);
        if (feature) { stop(e); contextMenu(e, feature); }
        return;
      }
      if (e.type === 'mousedown' && e.button === 2 && hitDrawing(e)) { stop(e); return; }
      if (!s.mode || s.mode === 'Select') {
        if (e.type !== 'click') return; // Ordinary dragging still pans the map.
        if (!s.inspectClick) { if (s.mode === 'Select') stop(e); return; }
        s.inspectClick = false;
        const feature = hitDrawing(e);
        if (feature) { if (s.mode === 'Select') selectFeature(feature); stop(e); }
        else { clearSelection(); if (s.mode === 'Select') stop(e); }
        return;
      }
      stop(e);
    }
    function key(e) {
      if (menuKey(e)) return;
      if (s.contextMenu && e.key === 'Escape') { stop(e); closeContextMenu(true); return; }
      if ((!s.mode && !s.popup) || block.hidden || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.target.isContentEditable) return;
      if (e.key === 'Escape') { stop(e); mode(''); }
      if (e.key === 'Enter' && ['Line', 'Polygon'].includes(s.mode) && e.target.tagName !== 'BUTTON') { stop(e); finish(); }
    }
    const cancel = () => { closeMenu(false); closeContextMenu(false); if (s.mode || s.popup) mode(''); };
    const moving = () => { closeMenu(false); closeContextMenu(false); };
    map.on('movestart', moving);
    document.addEventListener('pointerdown', outsideContext, true);
    canvas.addEventListener('pointerdown', down, true);
    canvas.addEventListener('pointermove', move, true);
    ['click', 'dblclick', 'contextmenu', 'mousedown'].forEach(name => canvas.addEventListener(name, blockClick, true));
    document.addEventListener('pointerup', up, true); document.addEventListener('pointercancel', cancel, true);
    document.addEventListener('keydown', key, true); window.addEventListener('blur', cancel);
    s.cancel = cancel;
    const storageStatus = document.createElement('span'); storageStatus.setAttribute('role', 'status');
    toolbar.appendChild(storageStatus);
    s.port = {
      id, block,
      getDrawings: () => JSON.parse(JSON.stringify(s.features)),
      replaceDrawings: features => {
        s.features = JSON.parse(JSON.stringify(features));
        s.serial = Math.max(0, ...s.features.map(f => Number(f.id) || 0));
        mode('');
      },
      addAction: (label, action) => {
        const option = item(label, action);
        return { setDisabled: value => { option.disabled = value; }, remove: () => { actions.delete(label); option.remove(); } };
      },
      setStatus: text => { storageStatus.textContent = text; },
      setBusy: busy => {
        if (busy && !s.storageBusy) mode('');
        s.storageBusy = busy; trigger.disabled = busy; if (busy) closeMenu(false);
      },
      isAlive: () => sessions.get(id) === s
    };
    s.attachStorage = () => { if (storageAdapter && !s.storage) s.storage = storageAdapter.attach(s.port); };
    s.dispose = removed => {
      closeMenu(false); controller.abort(); menu.remove();
      closeContextMenu(false); map.off('movestart', moving);
      document.removeEventListener('pointerdown', outsideContext, true);
      if (!removed) { try { clearSelection(); } catch (_) { /* map already removed */ } }
      else { const popup = s.popup; s.popup = null; if (popup) popup.remove(); }
      if (s.storage) s.storage.dispose();
      canvas.style.cursor = s.oldCursor; toolbar.remove();
      canvas.removeEventListener('pointerdown', down, true); canvas.removeEventListener('pointermove', move, true);
      ['click', 'dblclick', 'contextmenu', 'mousedown'].forEach(name => canvas.removeEventListener(name, blockClick, true));
      document.removeEventListener('pointerup', up, true); document.removeEventListener('pointercancel', cancel, true);
      document.removeEventListener('keydown', key, true); window.removeEventListener('blur', cancel); map.off('remove', removedHandler);
      if (!removed) { try { LAYERS.slice().reverse().forEach(l => { if (map.getLayer(l)) map.removeLayer(l); }); if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) { /* destroyed map */ } }
      sessions.delete(id);
    };
    const removedHandler = () => s.dispose(true); map.on('remove', removedHandler);
    sessions.set(id, s); mode(''); s.attachStorage();
  }
  function scan() {
    if (stopped) return;
    sessions.forEach(s => { if (!s.block.isConnected || window.askOracleMap?.getMap(s.id) !== s.map) s.dispose(false); else if (s.block.hidden) s.cancel(); });
    document.querySelectorAll('.llm-conv-show-map-btn[data-id]').forEach(button => {
      const id = button.getAttribute('data-id'), map = window.askOracleMap?.getMap(id);
      if (!map || sessions.has(id) || !map.getLayer('ao-areas')) return;
      const block = map.getContainer().closest('.ask-oracle-map-block');
      if (block) { try { attach(id, map, block); } catch (e) { console.warn('Map drawing:', e.message); } }
    });
  }
  const timer = window.setInterval(scan, 1000);
  window.askOracleMapDrawing = { version: '1.6.0', refresh: scan, isDrawing: id => !!sessions.get(String(id))?.mode,
    registerStorage: adapter => {
      if (storageAdapter === adapter) return;
      sessions.forEach(s => { if (s.storage) s.storage.dispose(); s.storage = null; });
      storageAdapter = adapter; sessions.forEach(s => s.attachStorage());
    },
    destroy: () => { stopped = true; window.clearInterval(timer); sessions.forEach(s => s.dispose(false)); delete window.askOracleMapDrawing; } };
  scan();
})();
