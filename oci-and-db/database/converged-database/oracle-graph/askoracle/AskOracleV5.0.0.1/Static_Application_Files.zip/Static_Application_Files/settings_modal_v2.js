window.AskOracleSettings = (function ($) {
  "use strict";

  var PROC = {
    BOOTSTRAP: "SETTINGS_BOOTSTRAP",
    GET_PROFILE_ATTRS: "SETTINGS_GET_PROFILE_ATTRS",
    SAVE_PROFILE_ATTRS: "SETTINGS_SAVE_PROFILE_ATTRS",
    CREATE_PROFILE: "SETTINGS_CREATE_PROFILE",
    CREATE_RAG_VECTOR_INDEX: "SETTINGS_CREATE_RAG_VECTOR_INDEX",
    DROP_RAG_VECTOR_INDEX: "SETTINGS_DROP_RAG_VECTOR_INDEX",
    GET_VECTOR_INDEXES: "SETTINGS_GET_VECTOR_INDEXES",
    DROP_PROFILE: "SETTINGS_DROP_PROFILE",
    GET_AGENT_DESC: "SETTINGS_GET_AGENT_TEAM_DESC",
    SAVE_AGENT_ENTITY: "SETTINGS_SAVE_AGENT_ENTITY",
    DROP_AGENT_TEAM: "SETTINGS_DROP_AGENT_TEAM",
    INSTALL_PREBUILT_AGENT: "SETTINGS_INSTALL_PREBUILT_AGENT",
    SAVE_PREBUILT_AGENT_PARAMS: "SETTINGS_SAVE_PREBUILT_AGENT_PARAMS",
    UNINSTALL_PREBUILT_AGENT: "SETTINGS_UNINSTALL_PREBUILT_AGENT",
    GET_AGENT_MISSION_LOGS: "SETTINGS_GET_AGENT_MISSION_LOGS",
    SAVE_ADMIN: "SETTINGS_SAVE_ADMIN_CONFIG",
    SAVE_CONV_MODE: "SETTINGS_SAVE_CONV_MODE",
    SET_THEME: "SETTINGS_SET_THEME",
    LIST_DB_LINKS: "SETTINGS_LIST_DB_LINKS",
    CREATE_DB_LINK: "SETTINGS_CREATE_DB_LINK",
    DROP_DB_LINK: "SETTINGS_DROP_DB_LINK",
    LIST_DB_LINK_TABLES: "SETTINGS_LIST_DB_LINK_TABLES",
    CREATE_CATALOG: "SETTINGS_CREATE_CATALOG",
    AGENT_BUILDER_CHAT: "SETTINGS_AGENT_BUILDER_CHAT"
  };

  var THEME_CHANGE_FLAG_KEY = "ASK_ORACLE_THEME_CHANGED";
  var THEME_CHANGE_FLAG_CONSUMED_KEY = THEME_CHANGE_FLAG_KEY + "_CONSUMED";
  var SETTINGS_THEME_MODE_KEY = "ASK_ORACLE_SETTINGS_THEME_MODE_V1";
  var APP_ZOOM_STORAGE_KEY = "ASK_ORACLE_APP_ZOOM_PCT";
  var ASK_ORACLE_UI_SYNC_KEY = "ASK_ORACLE_UI_SYNC_V1";
  var PREBUILT_AGENT_STATE_KEY = "ASK_ORACLE_PREBUILT_AGENT_STATE_V1";
  var PREBUILT_AGENT_VIEW_MODE_KEY = "ASK_ORACLE_PREBUILT_AGENT_VIEW_MODE_V1";
  var SETTINGS_BOOTSTRAP_CACHE_KEY = "ASK_ORACLE_SETTINGS_BOOTSTRAP_CACHE_V7";
  var SETTINGS_SIDEBAR_COLLAPSED_KEY = "ASK_ORACLE_SETTINGS_SIDEBAR_COLLAPSED_V1";
  var SETTINGS_LAST_NAV_KEY = "ASK_ORACLE_SETTINGS_LAST_NAV_V1";
  var SETTINGS_BOOTSTRAP_CACHE_TTL_MS = 90000;
  var ASK_ORACLE_SYNC_SELECTED_NL2SQL = "selected_nl2sql_profile";
  var ASK_ORACLE_SYNC_SELECTED_RAG = "selected_rag_profile";
  var ASK_ORACLE_SYNC_SELECTED_AGENT = "selected_agent_team";
  var ASK_ORACLE_SYNC_DEFAULT_CONV_MODE = "default_conversation_mode";
  var APP_ZOOM_MIN = 80;
  var APP_ZOOM_MAX = 200;
  var APP_ZOOM_STEP = 5;
  var IS_ADMIN_USER = false;
  var IS_CONFIG_ADMIN_USER = false;
  var USER_ROLE = "USER";
  var SETTINGS_NAV_RESTORE_COMPLETE = false;
  var SETTINGS_HAS_EXPLICIT_DEEP_LINK = false;
  var CAN_MANAGE_SETTINGS = false;
  var CURRENT_AGENT_TEAM_DATA = null;
  var LAST_BOOTSTRAP_DATA = null;
  var ALL_PROFILE_OPTIONS = [];
  var ATTR_EDIT_STATE = {
    NL2SQL: false,
    RAG: false
  };
  var ATTR_ORIGINAL_ATTRS = {
    NL2SQL: [],
    RAG: []
  };
  var ATTR_ORIGINAL_SERIALIZED = {
    NL2SQL: "",
    RAG: ""
  };
  var BUSY_COUNT = 0;
  var AGENT_SELECT_SUBMIT_BLOCK_UNTIL = 0;
  var BACKEND_CALLABLE_OPTIONS = [];
  var AVAILABLE_OBJECT_OPTIONS = [];
  var AGENT_PROFILE_LOOKUP = {};
  var AGENT_TEAM_MAP_SEARCH_TEXT = "";
  var ALL_AGENT_ENTITY_OPTIONS = {
    TEAM: [],
    AGENT: [],
    TASK: [],
    TOOL: []
  };
  var AGENT_CREATE_ENTITY_OPTIONS = {
    AGENT: [],
    TASK: [],
    TOOL: []
  };
  var TEAM_MAP_ZOOM = 0.7;
  var TEAM_MAP_ORIENTATION = "horizontal";
  var TEAM_MAP_LINK_REDRAW_TIMERS = [];
  var TEAM_MAP_LINK_RESIZE_OBSERVER = null;
  var TEAM_MAP_DRAGGING = false;
  var TEAM_MAP_DRAG_START_X = 0;
  var TEAM_MAP_DRAG_START_Y = 0;
  var TEAM_MAP_DRAG_SCROLL_LEFT = 0;
  var TEAM_MAP_DRAG_SCROLL_TOP = 0;
  var AGENT_EDITOR_HOME = null;
  var AGENT_STUDIO_STEP = 1;
  var AGENT_BUILDER_DEFAULT_TEAM = "SELECT_AI_AGENT_BUILDER";
  var AGENT_BUILDER_MODE = "graphical";
  var AGENT_BUILDER_NL_CONVERSATION_ID = "";
  var AGENT_BUILDER_NL_HISTORY = [];
  var AGENT_BUILDER_NL_PENDING_SEQ = 0;
  var AGENT_BUILDER_NL_IS_SENDING = false;
  var AGENT_STUDIO_TOOLS = [];
  var AGENT_STUDIO_TOOL_POSITIONS = {};
  var AGENT_STUDIO_TOOL_TASK_MAP = {};
  var AGENT_STUDIO_TOOL_GROUP_POSITIONS = {};
  var AGENT_STUDIO_TOOL_GROUP_COLLAPSED = {};
  var AGENT_STUDIO_TEAM_MAPPINGS = [];
  var AGENT_STUDIO_NEW_TOOL_PAYLOADS = {};
  var AGENT_STUDIO_ZOOM = 0.8;
  var AGENT_STUDIO_IS_SAVING = false;
  var PREBUILT_AGENT_METADATA = [];
  var PREBUILT_AGENT_STATE = {};
  var PREBUILT_AGENT_BOOTSTRAP_SYNCED = false;
  var PREBUILT_AGENT_DIALOG_AGENT_ID = "";
  var PREBUILT_AGENT_DIALOG_ACTION = "install";
  var DUPLICATE_PROFILE_CONTEXT = null;
  var PREBUILT_AGENT_PENDING_GRANT_INSTALL = null;
  var PREBUILT_AGENT_VIEW_MODE = "card";
  var MISSION_LOG_ROWS = [];
  var MISSION_TOOL_ROWS = [];
  var MISSION_ACTIVE_CONVERSATION_ID = "";
  var MISSION_VIEW_MODE = "board";
  var MISSION_LOG_PANE_PCT = 42;
  var MISSION_RESIZE_ACTIVE = false;
  var MISSION_MAP_ZOOM = 0.75;
  var MISSION_MAP_TOOL_DETAILS = {};
  var VECTOR_INDEX_ROWS = [];
  var DB_LINK_ROWS = [];
  var CATALOG_TABLE_ROWS = [];
  var CATALOG_HISTORY_ROWS = [];
  var ACTIVE_CATALOG_DETAILS = "";
  var ACTIVE_CATALOG_PROFILE_LINK = {
    catalogName: "",
    profileName: ""
  };
  var PROVIDER_OPTIONS = [
    { value: "oci", label: "oci" },
    { value: "openai", label: "openai" },
    { value: "cohere", label: "cohere" },
    { value: "azure", label: "azure" },
    { value: "google", label: "google" },
    { value: "anthropic", label: "anthropic" },
    { value: "huggingface", label: "huggingface" },
    { value: "aws", label: "aws" },
    { value: "database", label: "database" }
  ];
  var MODEL_OPTIONS_BY_PROVIDER = {
    oci: [
      "cohere.command-r-plus",
      "cohere.command-r-16k",
      "meta.llama-3.1-70b-instruct",
      "meta.llama-3.1-405b-instruct"
    ],
    openai: ["gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini"],
    azure: ["gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini"],
    cohere: ["command-r-plus", "command-r", "embed-english-v3.0", "embed-multilingual-v3.0"],
    google: ["gemini-2.0-flash", "gemini-1.5-pro", "gemini-1.5-flash"],
    anthropic: ["claude-3-5-sonnet-latest", "claude-3-5-haiku-latest"],
    huggingface: [],
    aws: ["anthropic.claude-3-5-sonnet-20240620-v1:0"],
    database: []
  };
  var ADMIN_SAVE_KEY_CANDIDATES = {
    SHOW_EXPORT_PDF: [
      "SHOW_EXPORT_PDF",
      "SHOW_EXPORT_PDF_BUTTON",
      "SHOW_PDF_EXPORT",
      "ENABLE_EXPORT_PDF",
      "ENABLE_PDF_EXPORT"
    ],
    SHOW_EXPORT_EXCEL: [
      "SHOW_EXPORT_EXCEL",
      "SHOW_EXPORT_EXCEL_BUTTON",
      "SHOW_EXCEL_EXPORT",
      "ENABLE_EXPORT_EXCEL",
      "ENABLE_EXCEL_EXPORT"
    ],
    SHOW_CONVERSATION_TIMER: [
      "SHOW_CONVERSATION_TIMER",
      "SHOW_CONVERSATION_TIMER_BUTTON",
      "SHOW_TIMER_BUTTON",
      "ENABLE_CONVERSATION_TIMER",
      "ENABLE_TIMER_BUTTON"
    ],
    SHOW_DELETE_PROMPT: [
      "SHOW_DELETE_PROMPT",
      "SHOW_DELETE_PROMPT_BUTTON",
      "SHOW_DELETE_BUTTON",
      "ENABLE_DELETE_PROMPT",
      "ENABLE_DELETE_BUTTON"
    ],
    ENABLE_END_USER_SWITCH_NL2SQL_PROFILE: [
      "ENABLE_END_USER_SWITCH_NL2SQL_PROFILE",
      "SHOW_END_USER_NL2SQL_PROFILE",
      "SHOW_NL2SQL_PROFILE_SWITCH"
    ],
    ENABLE_END_USER_SWITCH_RAG_PROFILE: [
      "ENABLE_END_USER_SWITCH_RAG_PROFILE",
      "SHOW_END_USER_RAG_PROFILE",
      "SHOW_RAG_PROFILE_SWITCH"
    ],
    RETENTION_DAYS: [
      "RETENTION_DAYS",
      "CONVERSATION_RETENTION_DAYS",
      "HISTORY_RETENTION_DAYS"
    ]
  };
  var PROFILE_ATTR_METADATA = {
    common: {
      provider: { label: "provider", type: "provider_select", priority: 1, help: "AI provider for this profile." },
      credential_name: { label: "credential_name", type: "text", priority: 2, help: "Credential used to call the provider API." },
      model: { label: "model", type: "model_select", priority: 3, help: "Chat or completion model used for responses." },
      provider_endpoint: { label: "provider_endpoint", type: "text", priority: 16, help: "Endpoint for OpenAI-compatible providers.", providerScope: "non_oci" },
      region: { label: "region", type: "text", priority: 17, help: "Provider region, commonly required for OCI." },
      object_list_mode: {
        label: "object_list_mode",
        type: "select",
        priority: 18,
        help: "Use 'all' for most profiles (stable, no vector index dependency). Use 'automated' only when object-list vector indexing is configured for the profile; otherwise runtime can fail with missing *_OBJECT_LIST_VECINDEX errors.",
        profileTypes: ["NL2SQL"],
        options: [
          { value: "", label: "- Select -" },
          { value: "all", label: "all" },
          { value: "automated", label: "automated" }
        ]
      },
      object_list: { label: "object_list", type: "object_list", priority: 19, help: "Select database objects for NL2SQL grounding. You can also paste objects from another schema under Advanced / manual edit.", rows: 6, profileTypes: ["NL2SQL"] },
      comments: { label: "comments", type: "boolean", priority: 30, help: "Include comments in metadata sent to the model.", profileTypes: ["NL2SQL"] },
      constraints: { label: "constraints", type: "boolean", priority: 31, help: "Include PK/FK metadata in prompts.", profileTypes: ["NL2SQL"] },
      enforce_object_list: { label: "enforce_object_list", type: "boolean", priority: 32, help: "Restrict the model to listed database objects.", profileTypes: ["NL2SQL"] },
      conversation: { label: "conversation", type: "boolean", priority: 33, help: "Enable conversation memory for this profile." },
      conversation_length: {
        label: "conversation_length",
        type: "number",
        priority: 904,
        advanced: true,
        help: "Optional number of exchanges retained in conversation history."
      },
      annotations: { label: "annotations", type: "boolean", priority: 35, help: "Include annotations where supported.", profileTypes: ["NL2SQL"] },
      case_sensitive_values: { label: "case_sensitive_values", type: "boolean", priority: 36, help: "Respect case-sensitive string values in prompts.", profileTypes: ["NL2SQL"] },
      max_tokens: { label: "max_tokens", type: "number", priority: 40, help: "Maximum tokens returned per generation." },
      temperature: { label: "temperature", type: "number", priority: 41, help: "Sampling temperature for response variation.", step: "0.1", min: "0" },
      seed: { label: "seed", type: "number", priority: 42, help: "Optional numeric seed for more repeatable outputs." },
      embedding_model: {
        label: "embedding_model",
        type: "model_select",
        priority: 901,
        advanced: true,
        help: "Embedding model defined in the AI profile."
      },
      source_language: {
        label: "source_language",
        type: "text",
        priority: 902,
        advanced: true,
        help: "Input language sent to the provider for translation."
      },
      target_language: {
        label: "target_language",
        type: "text",
        priority: 903,
        advanced: true,
        help: "Target language for provider translation output."
      },
      stop_tokens: {
        label: "stop_tokens",
        type: "string_array",
        priority: 9999,
        advanced: true,
        help: "Stop tokens are optional text sequences that tell the model where to stop generating a response. Most users should leave this blank. Use END, STOP or [\"END\", \"STOP\"].",
        rows: 4
      },
      oci_compartment_id: { label: "oci_compartment_id", type: "text", priority: 50, help: "OCI compartment identifier for Generative AI.", providerScope: "oci" },
      oci_endpoint_id: { label: "oci_endpoint_id", type: "text", priority: 51, help: "Endpoint OCID for dedicated OCI AI clusters.", providerScope: "oci" },
      oci_apiformat: {
        label: "oci_apiformat",
        type: "select",
        priority: 52,
        help: "OCI API format when using OCI Generative AI.",
        providerScope: "oci",
        options: [
          { value: "", label: "- Select -" },
          { value: "COHERE", label: "COHERE" },
          { value: "GENERIC", label: "GENERIC" }
        ]
      },
      oci_runtimetype: {
        label: "oci_runtimetype",
        type: "text",
        priority: 905,
        advanced: true,
        help: "Deprecated OCI runtime type; retain only if your environment still needs it.",
        providerScope: "oci"
      },
      azure_resource_name: {
        label: "azure_resource_name",
        type: "text",
        priority: 906,
        advanced: true,
        help: "Azure OpenAI resource name when applicable.",
        providerScope: "azure"
      },
      azure_deployment_name: {
        label: "azure_deployment_name",
        type: "text",
        priority: 907,
        advanced: true,
        help: "Azure OpenAI deployed model name.",
        providerScope: "azure"
      },
      azure_embedding_deployment_name: {
        label: "azure_embedding_deployment_name",
        type: "text",
        priority: 908,
        advanced: true,
        help: "Azure OpenAI deployed embedding model name.",
        providerScope: "azure"
      }
    },
    NL2SQL: {},
    RAG: {
      embedding_model: { label: "embedding_model", type: "model_select", priority: 4, required: true, help: "Required for RAG profiles. Used to generate retrieval embeddings." },
      vector_index_name: { label: "vector_index_name", type: "text", priority: 5, help: "Vector index connected to this RAG profile." },
      enable_sources: { label: "enable_sources", type: "boolean", priority: 10, help: "Show citations in RAG responses." },
      enable_source_offsets: { label: "enable_source_offsets", type: "boolean", priority: 11, help: "Return source offsets for retrieved excerpts." },
      enable_custom_source_uri: { label: "enable_custom_source_uri", type: "boolean", priority: 12, help: "Use custom source URLs from Object Storage metadata when present." }
    }
  };

  function showSuccess(msg) {
    apex.message.clearErrors();
    apex.message.showPageSuccess(msg);
  }

  function makeFriendlyErrorMessage(msg) {
    var raw = String(msg || "").trim();
    var match;
    if (!raw) return "Unexpected error.";
    if (/"error"\s*:\s*"Your session has ended\."/i.test(raw) || /Your session has ended\./i.test(raw)) {
      return "Your session has ended. Please sign in again and reopen Settings.";
    }
    match = raw.match(/ORA-20051:\s*Invalid value for task object\s*-\s*([^\n\r<]+)/i);
    if (match) {
      var badTask = String(match[1] || "").trim().replace(/[."'`]+$/g, "");
      return "Invalid task object name: '" + badTask + "'. Task object names cannot contain spaces or special characters. Use letters, numbers, and underscores, for example '" + badTask.replace(/\s+/g, "_").replace(/[^A-Za-z0-9_]/g, "_") + "'.";
    }
    match = raw.match(/ORA-\d+:\s*([^<\n\r]+)/i);
    if (match && /invalid value|invalid name|required|not authorized|already exists|unsupported save mode/i.test(match[1])) {
      return String(match[1] || raw).trim();
    }
    return raw;
  }

  function highlightInvalidValueFromError(msg) {
    var raw = String(msg || "");
    var match = raw.match(/Invalid value for task object\s*-\s*([^\n\r<]+)/i);
    if (!match) return;
    var badValue = String(match[1] || "").trim().replace(/[."'`]+$/g, "");
    if (!badValue) return;
    $("input, textarea, select").each(function() {
      var $field = $(this);
      var value = String($field.val() == null ? "" : $field.val()).trim();
      if (value === badValue || value.indexOf(badValue) >= 0) {
        markFieldError(this, "Invalid value: '" + badValue + "'. Use letters, numbers, and underscores with no spaces.");
      }
    });
  }

  function showError(msg) {
    apex.message.clearErrors();
    highlightInvalidValueFromError(msg);
    apex.message.showErrors([{ type: "error", location: "page", message: makeFriendlyErrorMessage(msg), unsafe: false }]);
  }

  function showAdminSettingUpdated(key, value) {
    var normalizedKey = String(key || "").trim().toUpperCase();
    if (!normalizedKey) return;
    var normalizedValue = String(value == null ? "" : value).trim().toUpperCase();
    var isEnabled = normalizeAdminFlag(normalizedValue);
    var visibilityText = isEnabled ? "shown." : "hidden.";
    var messageByKey = {
      SHOW_OPEN_IN_EDITOR: "Code Editor is now " + visibilityText,
      SHOW_AGENT_THOUGHTS: "Agent Thoughts button is now " + visibilityText,
      SHOW_EXPORT_PDF: "Export PDF button is now " + visibilityText,
      SHOW_EXPORT_EXCEL: "Export Excel button is now " + visibilityText,
      SHOW_CONVERSATION_TIMER: "Timer button is now " + visibilityText,
      SHOW_DELETE_PROMPT: "Delete button is now " + visibilityText,
      ENABLE_END_USER_SWITCH_CONV_STYLE: "End user conversation style switch is now " + visibilityText,
      ENABLE_END_USER_SWITCH_PROFILES_AGENTS: "End user profiles/agents switch is now " + visibilityText,
      ENABLE_END_USER_SWITCH_NL2SQL_PROFILE: "End user NL2SQL profile switch is now " + visibilityText,
      ENABLE_END_USER_SWITCH_RAG_PROFILE: "End user RAG profile switch is now " + visibilityText
    };
    if (normalizedKey === "APP_ZOOM_PCT") {
      showSuccess("App text size updated to " + normalizeZoomPct(value) + "%.");
      return;
    }
    if (normalizedKey === "RETENTION_DAYS") {
      showSuccess("Retention days set to " + normalizeRetentionDays(value) + ".");
      return;
    }
    if (normalizedKey === "APP_DISPLAY_NAME") {
      showSuccess("App name updated.");
      return;
    }
    if (normalizedKey === "PROMPT_BAR_TITLE") {
      showSuccess("Prompt bar title updated.");
      return;
    }
    if (normalizedKey === "PROMPT_PLACEHOLDER") {
      showSuccess("Prompt placeholder updated.");
      return;
    }
    if (normalizedKey === "AI_INFO_MESSAGE") {
      showSuccess("AI info message updated.");
      return;
    }
    if (normalizedKey === "APP_LOGO_URL") {
      showSuccess("App logo updated.");
      return;
    }
    if (normalizedKey === "DEFAULT_NL2SQL_PROFILE") {
      showSuccess("Default NL2SQL profile updated.");
      return;
    }
    if (normalizedKey === "DEFAULT_RAG_PROFILE") {
      showSuccess("Default RAG profile updated.");
      return;
    }
    if (normalizedKey === "DEFAULT_AGENT_TEAM") {
      showSuccess("Default agent team updated.");
      return;
    }
    if (normalizedKey === "ADMIN_OWNER_APP_USER") {
      showSuccess("App admin users updated.");
      return;
    }
    if (normalizedKey === "DEVELOPER_OWNER_APP_USER") {
      showSuccess("Developer users updated.");
      return;
    }
    if (normalizedKey === "USER_OWNER_APP_USER") {
      showSuccess("User users updated.");
      return;
    }
    if (normalizedKey === "AGENT_RUN_SERVICE_LEVEL") {
      showSuccess("Agent run service level updated.");
      return;
    }
    showSuccess(messageByKey[normalizedKey] || ("Admin setting updated: " + normalizedKey));
  }

  function isSettingsDebugEnabled() {
    try {
      return window.ASK_ORACLE_SETTINGS_DEBUG === true ||
        window.localStorage.getItem("ASK_ORACLE_SETTINGS_DEBUG") === "Y" ||
        /(?:\?|&)ao_debug=Y(?:&|$)/i.test(window.location.search || "");
    } catch (e) {
      return false;
    }
  }

  function debugSettingsLog(label, payload) {
    var logFn;
    if (!isSettingsDebugEnabled() || !window.console) return;
    logFn = window.console.log || window.console.debug;
    if (!logFn) return;
    logFn.call(window.console, "[AskOracleSettings] " + label, payload);
  }

  function getSettingsDebugState() {
    var studioSelect = $("#aoAgentStudioNewToolFunction");
    var createSelect = $("#aoAgentCreateToolFunction");
    var editSelect = $("#aoAgentEditToolFunction");
    var studioOptionHost = studioSelect.is("input[list]") ? $("#" + studioSelect.attr("list")) : studioSelect;
    var createOptionHost = createSelect.is("input[list]") ? $("#" + createSelect.attr("list")) : createSelect;
    var editOptionHost = editSelect.is("input[list]") ? $("#" + editSelect.attr("list")) : editSelect;
    return {
      debug_version: "callable-dropdown-debug-2026-05-07-app-schema-datalist",
      debug_enabled: isSettingsDebugEnabled(),
      root_count: $("#aoSettings").length,
      init_done: !!window.__AO_SETTINGS_V2_INIT_DONE,
      bootstrap_keys: Object.keys(LAST_BOOTSTRAP_DATA || {}),
      schema_owner: (LAST_BOOTSTRAP_DATA || {}).schema_owner || "",
      bootstrap_backend_callables_count: ((LAST_BOOTSTRAP_DATA || {}).backend_callables || []).length,
      bootstrap_backend_callables_error: (LAST_BOOTSTRAP_DATA || {}).backend_callables_error || "",
      bootstrap_backend_callables_sample: ((LAST_BOOTSTRAP_DATA || {}).backend_callables || []).slice(0, 5),
      backend_callable_options_count: BACKEND_CALLABLE_OPTIONS.length,
      backend_callable_options_sample: BACKEND_CALLABLE_OPTIONS.slice(0, 5),
      studio_select_count: studioSelect.length,
      studio_option_count: studioOptionHost.find("option").length,
      studio_options_sample: studioOptionHost.find("option").slice(0, 6).map(function() {
        return { value: this.value, text: $(this).text() };
      }).get(),
      create_tool_option_count: createOptionHost.find("option").length,
      edit_tool_option_count: editOptionHost.find("option").length
    };
  }

  function logSettingsDebugState() {
    var state = getSettingsDebugState();
    if (window.console && window.console.log) {
      window.console.log("[AskOracleSettings] debug state", state);
    }
    return state;
  }

  function ajax(processName, data, cb) {
    apex.server.process(processName, data || {}, {
      dataType: "json",
      success: function (pData) {
        debugSettingsLog("AJAX success: " + processName, {
          keys: Object.keys(pData || {}),
          schema_owner: (pData || {}).schema_owner || "",
          backend_callables_count: ((pData || {}).backend_callables || []).length,
          backend_callables_error: (pData || {}).backend_callables_error || "",
          backend_callables_sample: ((pData || {}).backend_callables || []).slice(0, 5)
        });
        cb(null, pData || {});
      },
      error: function (xhr) {
        debugSettingsLog("AJAX error: " + processName, {
          status: xhr && xhr.status,
          responseText: xhr && xhr.responseText
        });
        cb(xhr || { responseText: "Unknown AJAX error" });
      }
    });
  }

  function ajaxPromise(processName, data) {
    return $.Deferred(function(defer) {
      ajax(processName, data || {}, function(err, response) {
        if (err) {
          defer.reject(err);
          return;
        }
        if (response && response.success === false) {
          defer.reject({ responseText: response.message || "Server process failed.", response: response });
          return;
        }
        defer.resolve(response || {});
      });
    }).promise();
  }

  function ensureBusyOverlay() {
    if ($("#aoBusyOverlay").length) return;
    $("body").append(
      "<div id='aoBusyOverlay' class='ao-busy-overlay is-hidden' aria-live='polite' aria-busy='true'>" +
        "<div class='ao-busy-card'>" +
          "<div class='ao-busy-spinner' aria-hidden='true'></div>" +
          "<div id='aoBusyText' class='ao-busy-text'>Working...</div>" +
        "</div>" +
      "</div>"
    );
  }

  function showBusy(message) {
    BUSY_COUNT += 1;
    ensureBusyOverlay();
    $("#aoBusyText").text(String(message || "Working..."));
    $("#aoBusyOverlay").removeClass("is-hidden");
  }

  function updateBusyText(message) {
    if (!$("#aoBusyOverlay").length) return;
    $("#aoBusyText").text(String(message || "Working..."));
  }

  function hideBusy() {
    BUSY_COUNT = Math.max(0, Number(BUSY_COUNT || 0) - 1);
    if (BUSY_COUNT > 0) return;
    $("#aoBusyOverlay").addClass("is-hidden");
  }

  function ajaxWithBusy(processName, data, busyMessage, cb) {
    showBusy(busyMessage);
    ajax(processName, data, function(err, response) {
      hideBusy();
      cb(err, response);
    });
  }

  function readUiSyncState() {
    var raw = null;
    try { raw = sessionStorage.getItem(ASK_ORACLE_UI_SYNC_KEY); } catch (e) {}
    if (!raw) {
      try { raw = localStorage.getItem(ASK_ORACLE_UI_SYNC_KEY); } catch (e2) {}
    }
    if (!raw) return {};
    try {
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return {};
      var currentUser = getCurrentAppUser();
      var syncUser = normalizeAppUserName(parsed.app_user);
      if (currentUser && syncUser && syncUser !== currentUser) return {};
      if (!syncUser && parsed.admin_config && typeof parsed.admin_config === "object") return {};
      return parsed;
    } catch (e3) {
      return {};
    }
  }

  function persistUiSyncState(patch) {
    if (!patch || typeof patch !== "object") return;
    var next = readUiSyncState();
    Object.keys(patch).forEach(function (k) {
      next[k] = patch[k];
    });
    var appUser = getCurrentAppUser();
    if (appUser) next.app_user = appUser;
    next.updated_at = String(Date.now());
    var payload = JSON.stringify(next);
    try { sessionStorage.setItem(ASK_ORACLE_UI_SYNC_KEY, payload); } catch (e) {}
    try { localStorage.setItem(ASK_ORACLE_UI_SYNC_KEY, payload); } catch (e2) {}
    dispatchUiSyncChange(next);
  }

  function getSettingsCacheScopeKey() {
    var appId = getApexRuntimeValue("APP_ID", "pFlowId");
    var sessionId = getApexRuntimeValue("APP_SESSION", "pInstance");
    var userName = getCurrentAppUser();
    return String(appId || "app") + "::" + String(sessionId || "session") + "::" + String(userName || "user");
  }

  function readBootstrapCache() {
    var raw = null;
    try { raw = sessionStorage.getItem(SETTINGS_BOOTSTRAP_CACHE_KEY); } catch (e1) {}
    if (!raw) {
      try { raw = localStorage.getItem(SETTINGS_BOOTSTRAP_CACHE_KEY); } catch (e2) {}
    }
    if (!raw) return null;
    try {
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return null;
      if (!parsed.data || typeof parsed.data !== "object") return null;
      if (String(parsed.scope || "") !== getSettingsCacheScopeKey()) return null;
      if (Number(parsed.expires_at || 0) < Date.now()) return null;
      return parsed.data;
    } catch (e3) {
      return null;
    }
  }

  function writeBootstrapCache(data) {
    if (!data || typeof data !== "object") return;
    var payload = JSON.stringify({
      scope: getSettingsCacheScopeKey(),
      updated_at: Date.now(),
      expires_at: Date.now() + SETTINGS_BOOTSTRAP_CACHE_TTL_MS,
      data: data
    });
    try { sessionStorage.setItem(SETTINGS_BOOTSTRAP_CACHE_KEY, payload); } catch (e1) {}
    try { localStorage.setItem(SETTINGS_BOOTSTRAP_CACHE_KEY, payload); } catch (e2) {}
  }

  function syncConvModeSelectFromUiSync() {
    var state = readUiSyncState();
    var syncedMode = String((state && state.default_conversation_mode) || "").trim().toUpperCase();
    if (!syncedMode) return;
    $("#aoConvModeSelect").val(syncedMode);
  }

  function normalizeSettingsAgentTeamName(value) {
    return String(value || "").trim().toUpperCase().replace(/[^A-Z0-9]+/g, "");
  }

  function isSettingsOnlyAgentTeam(value) {
    return normalizeSettingsAgentTeamName(value) === "SELECTAIAGENTBUILDER";
  }

  function sanitizeSettingsSharedAgentTeam(value) {
    var team = String(value || "").trim();
    if (!team) return "";
    return isSettingsOnlyAgentTeam(team) ? "" : team;
  }

  function applyConversationModeToLivePage(modeValue, extraOptions) {
    var mode = String(modeValue || "").trim().toUpperCase();
    var opts = extraOptions && typeof extraOptions === "object" ? extraOptions : {};
    if (!mode) return false;

    var targets = [];
    var seen = [];
    var addTarget = function(target) {
      if (!target) return;
      if (seen.indexOf(target) >= 0) return;
      seen.push(target);
      targets.push(target);
    };

    addTarget(window);
    try { addTarget(window.parent); } catch (e1) {}
    try { addTarget(window.top); } catch (e2) {}
    try { addTarget(window.opener); } catch (e3) {}

    for (var i = 0; i < targets.length; i += 1) {
      var target = targets[i];
      if (!target) continue;
      try {
        if (target === window) continue;
        if (typeof target.setConversationStyle === "function") {
          var selectedTeam = sanitizeSettingsSharedAgentTeam(opts.selectedAgentTeam || opts.selected_agent_team || "");
          target.setConversationStyle(mode, {
            skipSuccess: true,
            skipPreferencePersist: true,
            selectedAgentTeam: selectedTeam
          });
          try {
            if (selectedTeam) {
              if (typeof target.persistAskOracleUiSyncState === "function") {
                target.persistAskOracleUiSyncState({
                  default_conversation_mode: mode,
                  selected_agent_team: selectedTeam
                });
              } else if (typeof target.persistLlmConvUiSyncState === "function") {
                target.persistLlmConvUiSyncState({
                  default_conversation_mode: mode,
                  selected_agent_team: selectedTeam
                });
              }
              if (typeof target.scheduleAskOracleAdminUiStateApply === "function") {
                target.scheduleAskOracleAdminUiStateApply(true);
              } else if (typeof target.scheduleLlmConvAdminUiStateApply === "function") {
                target.scheduleLlmConvAdminUiStateApply(true);
              }
            }
          } catch (e5) {}
          return true;
        }
      } catch (e4) {}
    }
    return false;
  }

  function dispatchUiSyncChange(state) {
    var targets = [];
    var seen = [];
    var addTarget = function(target) {
      if (!target) return;
      if (seen.indexOf(target) >= 0) return;
      seen.push(target);
      targets.push(target);
    };

    addTarget(window);
    try { addTarget(window.parent); } catch (e1) {}
    try { addTarget(window.top); } catch (e2) {}
    try {
      for (var i = 0; i < window.frames.length; i += 1) {
        addTarget(window.frames[i]);
      }
    } catch (e3) {}

    targets.forEach(function(target) {
      try {
        var CustomEventCtor = typeof target.CustomEvent === "function" ? target.CustomEvent : CustomEvent;
        target.dispatchEvent(new CustomEventCtor("askoracleuisyncchange", {
          detail: { state: state }
        }));
      } catch (e4) {}
    });
  }

  function readStoredSettingsNav() {
    var raw = "";
    try { raw = localStorage.getItem(SETTINGS_LAST_NAV_KEY) || ""; } catch (e1) {}
    if (!raw) {
      try { raw = sessionStorage.getItem(SETTINGS_LAST_NAV_KEY) || ""; } catch (e2) {}
    }
    if (!raw) return null;
    try {
      var parsed = JSON.parse(raw);
      var section = String(parsed && parsed.section || "").trim();
      var navKey = String(parsed && parsed.navKey || "").trim();
      return section && navKey ? { section: section, navKey: navKey } : null;
    } catch (e3) {
      return null;
    }
  }

  function storeSettingsNav(section, navKey) {
    var payload = JSON.stringify({
      section: String(section || "").trim(),
      navKey: String(navKey || section || "").trim()
    });
    try { localStorage.setItem(SETTINGS_LAST_NAV_KEY, payload); } catch (e1) {}
    try { sessionStorage.setItem(SETTINGS_LAST_NAV_KEY, payload); } catch (e2) {}
  }

  function restoreStoredSettingsNav() {
    if (SETTINGS_NAV_RESTORE_COMPLETE || SETTINGS_HAS_EXPLICIT_DEEP_LINK) return false;
    var stored = readStoredSettingsNav();
    if (!stored || !isNavAllowed(stored.section, stored.navKey)) return false;
    var $storedNav = $(".ao-nav[data-nav-key='" + stored.navKey + "']").first();
    if (!$storedNav.length || $storedNav.hasClass("is-hidden")) return false;
    SETTINGS_NAV_RESTORE_COMPLETE = true;
    setNav(stored.section, stored.navKey, { persist: false });
    return true;
  }

  function setNav(section, navKey, options) {
    var opts = options || {};
    var key = String(navKey || section || "").trim();
    if (!isNavAllowed(section, key)) {
      var fallback = getRoleDefaultNav();
      section = fallback.section;
      key = fallback.navKey;
    }
    var $targetNav = key ? $(".ao-nav[data-nav-key='" + key + "']") : $();
    if (!$targetNav.length) $targetNav = $(".ao-nav[data-section='" + section + "']").first();
    if ($targetNav.hasClass("is-hidden")) {
      var safeFallback = getRoleDefaultNav();
      section = safeFallback.section;
      key = safeFallback.navKey;
      $targetNav = $(".ao-nav[data-nav-key='" + key + "']").first();
    }
    $(".ao-nav").removeClass("is-active");
    $targetNav.addClass("is-active");
    $(".ao-panel").removeClass("is-active");
    $(".ao-panel[data-section='" + section + "']").addClass("is-active");
    if (opts.persist !== false && $targetNav.length && !$targetNav.hasClass("is-hidden")) {
      storeSettingsNav(section, key);
    }
    if (section !== "agent-teams") {
      collapseTeamMapExpanded();
    } else {
      scheduleAgentTeamMapLinkRedraw();
      window.requestAnimationFrame(drawAgentStudioLinks);
    }
    if (section === "agent-logs") {
      /* Always refresh when opening Agent Logs so new executions are visible. */
      loadMissionControl(true);
    }
    if (section === "vector-indexes") {
      ensureVectorIndexAdminCardsOnVectorPage();
      loadVectorIndexes();
    }
  }

  function setScreen(group, screen) {
    var targetGroup = String(group || "").trim();
    var targetScreen = String(screen || "default").trim();
    if (!targetGroup) return;
    $(".ao-screen[data-screen-group='" + targetGroup + "']").removeClass("is-active");
    $(".ao-screen[data-screen-group='" + targetGroup + "'][data-screen='" + targetScreen + "']").addClass("is-active");
    if (targetGroup === "agent-teams" && targetScreen !== "default") {
      collapseTeamMapExpanded();
    }
  }

  function normalizeAdminFlag(v) {
    var s = String(v == null ? "" : v).trim().toUpperCase();
    var normalized = s.replace(/[^A-Z0-9]+/g, "_").replace(/^_+|_+$/g, "");
    return v === true ||
      s === "Y" ||
      s === "1" ||
      s === "TRUE" ||
      s === "YES" ||
      normalized === "SHOW" ||
      normalized === "SHOWN" ||
      normalized === "VISIBLE" ||
      normalized === "ENABLED" ||
      normalized === "ENABLE" ||
      normalized === "SHOW_TO_ALL" ||
      normalized === "SHOW_TO_ALL_USERS" ||
      normalized === "SHOW_ALL_USERS" ||
      normalized === "ALL_USERS" ||
      normalized === "ALL";
  }

  function normalizeUserRole(value, isAdminFallback) {
    var role = String(value == null ? "" : value).trim().toUpperCase();
    if (role === "ADMIN" || role === "DEVELOPER" || role === "USER") {
      return role;
    }
    return normalizeAdminFlag(isAdminFallback) ? "ADMIN" : "USER";
  }

  function normalizeAppUserName(value) {
    return String(value == null ? "" : value).trim().toUpperCase();
  }

  function getCurrentAppUser(data) {
    var userName = "";
    var dataUserKeys = [
      "current_app_user",
      "CURRENT_APP_USER",
      "app_user",
      "APP_USER",
      "current_user",
      "CURRENT_USER",
      "user_name",
      "USER_NAME"
    ];
    if (data && typeof data === "object") {
      for (var i = 0; i < dataUserKeys.length; i += 1) {
        if (Object.prototype.hasOwnProperty.call(data, dataUserKeys[i])) {
          userName = String(data[dataUserKeys[i]] || "");
          if (userName) return normalizeAppUserName(userName);
        }
      }
    }
    try {
      userName = String(window.apex && apex.env ? (apex.env.APP_USER || "") : "");
    } catch (e1) {}
    if (!userName && typeof window.$v === "function") {
      try {
        userName = String(window.$v("APP_USER") || "");
      } catch (e2) {}
    }
    if (!userName && window.apex && apex.item && typeof apex.item === "function") {
      try {
        userName = String(apex.item("APP_USER").getValue() || "");
      } catch (e3) {}
    }
    return normalizeAppUserName(userName);
  }

  function isCurrentUserInOwnersCsv(ownerCsv, data) {
    var currentUser = getCurrentAppUser(data);
    var normalizedOwners = normalizeAdminOwnersCsv(ownerCsv);
    if (!currentUser || !normalizedOwners) return false;
    return normalizedOwners.split(",").some(function(owner) {
      return normalizeAppUserName(owner) === currentUser;
    });
  }

  function getExplicitUserRole(data) {
    var role = String(getBootstrapValue(data, "user_role", "USER_ROLE") || "").trim().toUpperCase();
    if (role === "ADMIN" || role === "DEVELOPER" || role === "USER") return role;
    return "";
  }

  function resolveConfiguredUserRole(data, adminOwnerUsers, developerOwnerUsers, userOwnerUsers) {
    var hasConfiguredOwners = !!(normalizeAdminOwnersCsv(adminOwnerUsers) || normalizeAdminOwnersCsv(developerOwnerUsers) || normalizeAdminOwnersCsv(userOwnerUsers));
    var explicitRole = getExplicitUserRole(data);
    if (isCurrentUserInOwnersCsv(adminOwnerUsers, data)) return "ADMIN";
    if (isCurrentUserInOwnersCsv(developerOwnerUsers, data)) return "DEVELOPER";
    if (isCurrentUserInOwnersCsv(userOwnerUsers, data)) return "USER";
    if (hasConfiguredOwners) {
      return explicitRole === "DEVELOPER" ? "DEVELOPER" : "USER";
    }
    if (explicitRole) return explicitRole;
    return normalizeAdminFlag(getBootstrapValue(data, "is_admin", "IS_ADMIN")) ? "ADMIN" : "USER";
  }

  function getRoleDefaultNav() {
    if (USER_ROLE === "USER") {
      return { section: "agent-teams", navKey: "agent-team" };
    }
    return { section: "nl2sql-profile", navKey: "nl2sql-profile" };
  }

  function isNavAllowed(section, navKey) {
    var key = String(navKey || section || "").trim().toLowerCase();
    var sectionKey = String(section || "").trim().toLowerCase();
    if (!key) return false;
    if (key === "theme-settings" || sectionKey === "theme-settings") return false;
    if (key === "data-sources-connections" || key === "data-sources-catalog" || sectionKey === "data-sources") return false;
    if (USER_ROLE === "ADMIN") {
      return [
        "agent-team",
        "agent-builder",
        "prebuilt-agents",
        "agent-logs",
        "nl2sql-profile",
        "rag-profile",
        "vector-indexes",
        "admin-settings"
      ].indexOf(key) >= 0 || [
        "agent-teams",
        "prebuilt-agents",
        "agent-logs",
        "nl2sql-profile",
        "rag-profile",
        "vector-indexes",
        "admin-settings"
      ].indexOf(sectionKey) >= 0;
    }
    if (USER_ROLE === "DEVELOPER") {
      return [
        "agent-team",
        "agent-builder",
        "prebuilt-agents",
        "agent-logs",
        "nl2sql-profile",
        "rag-profile",
        "vector-indexes"
      ].indexOf(key) >= 0 || [
        "agent-teams",
        "prebuilt-agents",
        "agent-logs",
        "nl2sql-profile",
        "rag-profile",
        "vector-indexes"
      ].indexOf(sectionKey) >= 0;
    }
    return [
      "agent-team",
      "agent-teams",
      "agent-logs",
      "nl2sql-profile",
      "rag-profile",
      "vector-indexes"
    ].indexOf(key) >= 0 || [
      "agent-teams",
      "agent-logs",
      "nl2sql-profile",
      "rag-profile",
      "vector-indexes"
    ].indexOf(sectionKey) >= 0;
  }

  function applyNavVisibility($node, allowed) {
    $node.toggleClass("is-hidden", !allowed);
    $node.attr("aria-hidden", allowed ? "false" : "true");
    $node.prop("disabled", false).removeAttr("disabled");
    if (allowed) {
      $node.removeAttr("tabindex");
      $node.each(function() {
        this.style.removeProperty("display");
      });
    } else {
      $node.attr("tabindex", "-1");
      $node.each(function() {
        this.style.setProperty("display", "none", "important");
      });
    }
  }

  function syncNavGroupVisibility() {
    $(".ao-settings__sidebar .ao-nav-group-label").each(function() {
      var group = this;
      var hasVisibleNav = false;
      var node = group.nextElementSibling;
      while (node) {
        if (node.classList && node.classList.contains("ao-nav-group-label")) break;
        if (node.classList && node.classList.contains("ao-nav") && !node.classList.contains("is-hidden") && $(node).is(":visible")) {
          hasVisibleNav = true;
          break;
        }
        node = node.nextElementSibling;
      }
      $(group).toggleClass("is-hidden", !hasVisibleNav).toggle(hasVisibleNav);
    });
  }

  function hideEmptyAppSettingsHeader() {
    $(".ao-settings__sidebar .ao-nav-group-label").each(function() {
      var $group = $(this);
      var label = String($group.find(".ao-nav-group-label-text").text() || "").trim().toLowerCase();
      if (label !== "app settings") return;
      var shouldShow = !!(IS_CONFIG_ADMIN_USER && $(".ao-settings__sidebar .ao-nav[data-nav-key='admin-settings']:not(.is-hidden)").length);
      $group.toggleClass("is-hidden", !shouldShow).attr("aria-hidden", shouldShow ? "false" : "true");
      if (shouldShow) {
        this.style.removeProperty("display");
      } else {
        this.style.setProperty("display", "none", "important");
      }
    });
  }

  function forceHideLeftNavForRole() {
    var role = normalizeUserRole(USER_ROLE, IS_ADMIN_USER);
    var hideKeys = ["data-sources-connections", "data-sources-catalog", "theme-settings"];

    if (!IS_CONFIG_ADMIN_USER) {
      hideKeys.push("admin-settings");
    }

    if (role !== "ADMIN" && role !== "DEVELOPER") {
      hideKeys.push("agent-builder");
      hideKeys.push("prebuilt-agents");
    }

    hideKeys.forEach(function(navKey) {
      var $nav = $(".ao-settings__sidebar .ao-nav[data-nav-key='" + navKey + "']");
      $nav.addClass("is-hidden")
        .attr("aria-hidden", "true")
        .attr("tabindex", "-1")
        .prop("disabled", false)
        .removeAttr("disabled")
        .each(function() {
          this.style.setProperty("display", "none", "important");
        });
    });

    syncNavGroupVisibility();
  }

  function applyAdminVisibility(isAdmin, userRole) {
    USER_ROLE = normalizeUserRole(userRole, isAdmin);
    IS_ADMIN_USER = IS_CONFIG_ADMIN_USER && USER_ROLE === "ADMIN";
    CAN_MANAGE_SETTINGS = USER_ROLE === "ADMIN" || USER_ROLE === "DEVELOPER";
    var adminNav = $(".ao-nav[data-section='admin-settings']");
    var adminPanel = $(".ao-panel[data-section='admin-settings']");

    $(".ao-nav").each(function() {
      var $nav = $(this);
      var allowed = isNavAllowed($nav.attr("data-section"), $nav.attr("data-nav-key"));
      applyNavVisibility($nav, allowed);
    });
    $(".ao-panel").each(function() {
      var $panel = $(this);
      var allowed = isNavAllowed($panel.attr("data-section"), $panel.attr("data-section"));
      $panel.toggleClass("is-hidden", !allowed);
    });
    applyNavVisibility(adminNav, IS_CONFIG_ADMIN_USER && isNavAllowed("admin-settings", "admin-settings"));
    adminPanel.toggleClass("is-hidden", !(IS_CONFIG_ADMIN_USER && isNavAllowed("admin-settings", "admin-settings")));
    $(".ao-admin-only").toggleClass("is-hidden", !CAN_MANAGE_SETTINGS);
    forceHideLeftNavForRole();
    syncNavGroupVisibility();
    hideEmptyAppSettingsHeader();

    restoreStoredSettingsNav();

    if (!isNavAllowed($(".ao-panel.is-active").attr("data-section"), $(".ao-nav.is-active").attr("data-nav-key"))) {
      var fallback = getRoleDefaultNav();
      setNav(fallback.section, fallback.navKey);
    }

    syncAttrEditUi("NL2SQL");
    syncAttrEditUi("RAG");
  }

  function getAttrUiConfig(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    if (type === "NL2SQL") {
      return {
        container: "#aoNl2sqlAttrs",
        editBtn: "#aoEditNl2sqlAttrs",
        cancelBtn: "#aoCancelNl2sqlAttrs,#aoCancelNl2sqlAttrsBottom",
        saveRow: "#aoNl2sqlSaveRow",
        saveBtn: "#aoSaveNl2sqlAll,#aoSaveNl2sqlAllTop"
      };
    }
    return {
      container: "#aoRagAttrs",
      editBtn: "#aoEditRagAttrs",
      cancelBtn: "#aoCancelRagAttrs,#aoCancelRagAttrsBottom",
      saveRow: "#aoRagSaveRow",
      saveBtn: "#aoSaveRagAll,#aoSaveRagAllTop"
    };
  }

  function stableStringify(value) {
    if (Array.isArray(value)) {
      return "[" + value.map(stableStringify).join(",") + "]";
    }
    if (value && typeof value === "object") {
      return "{" + Object.keys(value).sort().map(function(key) {
        return JSON.stringify(key) + ":" + stableStringify(value[key]);
      }).join(",") + "}";
    }
    return JSON.stringify(value);
  }

  function getCurrentAttrSerialized(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    var cfg = getAttrUiConfig(type);
    try {
      return stableStringify(collectAttrs(type, cfg.container));
    } catch (e) {
      return "__invalid__" + String(e && e.message ? e.message : e);
    }
  }

  function isAttrDirty(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    return getCurrentAttrSerialized(type) !== String(ATTR_ORIGINAL_SERIALIZED[type] || "");
  }

  function syncAttrDirtyState(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    if (type !== "NL2SQL" && type !== "RAG") return;
    var cfg = getAttrUiConfig(type);
    var editable = isAttrEditable(type);
    var dirty = editable && isAttrDirty(type);
    $(cfg.saveBtn).prop("disabled", !dirty).toggleClass("is-disabled", !dirty);
  }

  function setAttrOriginalSnapshot(profileType, attrs) {
    var type = String(profileType || "").trim().toUpperCase();
    ATTR_ORIGINAL_ATTRS[type] = (attrs || []).map(function(row) {
      return $.extend({}, row || {});
    });
    ATTR_ORIGINAL_SERIALIZED[type] = getCurrentAttrSerialized(type);
  }

  function isAttrEditable(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    return !!(CAN_MANAGE_SETTINGS && ATTR_EDIT_STATE[type]);
  }

  function getReadonlyEmptyDisplayLabel(attrName) {
    var key = String(attrName || "").trim().toLowerCase();
    if (key === "object_list_mode") return "Default";
    return "Not specified";
  }

  function applyReadonlyAttrDisplay(profileType, editable) {
    var type = String(profileType || "").trim().toUpperCase();
    var cfg = getAttrUiConfig(type);
    var isEditable = !!editable;
    var $container = $(cfg.container);

    $container.find(".ao-attr-row[data-attr-name]").each(function() {
      var $row = $(this);
      var attrName = String($row.attr("data-attr-name") || "").trim();
      var $field = $row.find(".js-ao-attr-val").first();
      var label;
      var $blank;

      if (!$field.length) return;

      if (isEditable) {
        $field.removeClass("ao-input--muted-display");
        if ($field.attr("data-ao-readonly-filled") === "1") {
          $field.val("");
          $field.removeAttr("data-ao-readonly-filled");
        }
        if ($field.is("select")) {
          $field.find("option[data-ao-readonly-label='1']").each(function() {
            var $option = $(this);
            var original = String($option.attr("data-ao-original-label") || "- Select -");
            $option.text(original);
            $option.removeAttr("data-ao-readonly-label");
            $option.removeAttr("data-ao-original-label");
          });
        }
        return;
      }

      if ($row.hasClass("is-provider-hidden")) return;

      if ($field.is("select")) {
        $field.find("option[data-ao-readonly-label='1']").each(function() {
          var $option = $(this);
          var original = String($option.attr("data-ao-original-label") || "- Select -");
          $option.text(original);
          $option.removeAttr("data-ao-readonly-label");
          $option.removeAttr("data-ao-original-label");
        });

        if (String($field.val() || "").trim()) {
          $field.removeClass("ao-input--muted-display");
          return;
        }

        label = getReadonlyEmptyDisplayLabel(attrName);
        $blank = $field.find("option[value='']").first();
        if ($blank.length) {
          if (!$blank.attr("data-ao-original-label")) {
            $blank.attr("data-ao-original-label", String($blank.text() || "- Select -"));
          }
          $blank.text(label);
          $blank.attr("data-ao-readonly-label", "1");
        }
        $field.val("");
        $field.addClass("ao-input--muted-display");
        return;
      }

      if (String($field.val() || "").trim()) {
        $field.removeClass("ao-input--muted-display");
        return;
      }

      label = getReadonlyEmptyDisplayLabel(attrName);
      $field.val(label);
      $field.attr("data-ao-readonly-filled", "1");
      $field.addClass("ao-input--muted-display");
    });
  }

  function syncAttrEditUi(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    var cfg = getAttrUiConfig(type);
    var editable = isAttrEditable(type);
    var canManage = !!CAN_MANAGE_SETTINGS;
    var hasSelectedProfile = !!selectedProfileValue(type);
    if (!hasSelectedProfile && editable) {
      ATTR_EDIT_STATE[type] = false;
      editable = false;
    }

    $(cfg.editBtn).toggle(canManage && hasSelectedProfile && !editable);
    $(cfg.cancelBtn).toggle(canManage && hasSelectedProfile && editable);
    $(cfg.saveBtn).toggle(canManage && hasSelectedProfile && editable);
    $(cfg.saveRow).toggle(canManage && hasSelectedProfile && editable);
    $(cfg.container).toggleClass("is-editing", editable).toggleClass("is-readonly", !editable);
    $(cfg.container).find(".js-ao-attr-val")
      .prop("readonly", !editable)
      .prop("disabled", !editable);
    $(cfg.container).find(".ao-object-picker")
      .toggleClass("is-readonly", !editable)
      .find(".ao-object-picker-search, .ao-object-picker-type, .ao-object-picker-select, [data-remove-object]")
      .prop("disabled", !editable);
    if (!editable) {
      $(cfg.container).find(".ao-manual-object-list").prop("open", false);
    }
    applyProfileProviderVisibility(type);
    applyReadonlyAttrDisplay(type, editable);
    syncAttrDirtyState(type);
    syncDuplicateProfileButtons();
  }

  function syncDuplicateProfileButtons() {
    $("#aoDuplicateNl2sqlProfile").prop("disabled", !(CAN_MANAGE_SETTINGS && selectedProfileValue("NL2SQL")));
    $("#aoDuplicateRagProfile").prop("disabled", !(CAN_MANAGE_SETTINGS && selectedProfileValue("RAG")));
  }

  function setAttrEditMode(profileType, enabled) {
    var type = String(profileType || "").trim().toUpperCase();
    ATTR_EDIT_STATE[type] = !!enabled;
    syncAttrEditUi(type);
  }

  function cancelAttrEdits(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    var cfg = getAttrUiConfig(type);
    ATTR_EDIT_STATE[type] = false;
    renderAttrs(cfg.container, ATTR_ORIGINAL_ATTRS[type] || []);
    syncAttrEditUi(type);
  }

  function setAdminSection(section) {
    var target = String(section || "ui").trim().toLowerCase();
    if (!$(".ao-admin-tab[data-admin-section='" + target + "']").length) {
      target = "ui";
    }
    $(".ao-admin-tab[data-admin-section]").removeClass("is-active");
    $(".ao-admin-tab[data-admin-section='" + target + "']").addClass("is-active");
    $(".ao-admin-panel").removeClass("is-active");
    $(".ao-admin-panel[data-admin-section='" + target + "']").addClass("is-active");
    var $activeAdminPanel = $(".ao-panel[data-section='admin-settings'] > .ao-admin-panel[data-admin-section='" + target + "']");
    if ($activeAdminPanel.length) {
      $activeAdminPanel.scrollTop(0);
    }
  }

  function setNl2sqlAdminCardView(mode) {
    var target = String(mode || "").trim().toLowerCase();
    if (target !== "create" && target !== "drop") target = "none";
    $("#aoShowNl2sqlCreate, #aoShowNl2sqlDrop").removeClass("is-active");
    $("#aoNl2sqlCreateCard, #aoNl2sqlDropCard").removeClass("is-active");
    if (target === "none") return;
    if (target === "create") {
      $("#aoShowNl2sqlCreate").addClass("is-active");
      $("#aoNl2sqlCreateCard").addClass("is-active");
      return;
    }
    $("#aoShowNl2sqlDrop").addClass("is-active");
    $("#aoNl2sqlDropCard").addClass("is-active");
  }

  function setRagAdminCardView(mode) {
    var target = String(mode || "").trim().toLowerCase();
    var valid = ["profile-create", "profile-drop"];
    if (valid.indexOf(target) < 0) target = "none";
    $("#aoShowRagProfileCreate, #aoShowRagProfileDrop").removeClass("is-active");
    $("#aoRagProfileCreateCard, #aoRagProfileDropCard").removeClass("is-active");
    if (target === "none") return;
    if (target === "profile-create") {
      $("#aoShowRagProfileCreate").addClass("is-active");
      $("#aoRagProfileCreateCard").addClass("is-active");
      return;
    }
    $("#aoShowRagProfileDrop").addClass("is-active");
    $("#aoRagProfileDropCard").addClass("is-active");
  }

  function ensureVectorIndexAdminCardsOnVectorPage() {
    var $host = $("#aoVectorIndexAdminCards");
    if (!$host.length) return;
    $("#aoRagVectorCreateCard, #aoRagVectorDropCard").each(function() {
      if (this.parentNode !== $host[0]) $host.append(this);
    });
  }

  function setVectorIndexAdminCardView(mode) {
    ensureVectorIndexAdminCardsOnVectorPage();
    var target = String(mode || "").trim().toLowerCase();
    if (["create", "drop"].indexOf(target) < 0) target = "none";
    $("#aoShowVectorIndexCreate, #aoShowVectorIndexDrop").removeClass("is-active");
    $("#aoRagVectorCreateCard, #aoRagVectorDropCard").removeClass("is-active");
    if (target === "none") return;
    if (target === "create") {
      $("#aoShowVectorIndexCreate, #aoRagVectorCreateCard").addClass("is-active");
      return;
    }
    $("#aoShowVectorIndexDrop, #aoRagVectorDropCard").addClass("is-active");
  }

  function setAgentCreatePanel(mode) {
    var target = String(mode || "overview").trim().toLowerCase();
    var valid = ["overview", "tool", "task", "agent", "team", "edit"];
    var titleByPanel = {
      overview: "Agent Builder",
      tool: "Create Tool",
      task: "Create Task",
      agent: "Agent Definition",
      team: "Create Team",
      edit: "Agent Editor"
    };
    var copyByPanel = {
      overview: "Choose a block in the workflow to create tools, tasks, agents, and teams.",
      tool: "Create a callable capability that tasks can use.",
      task: "Create task instructions and connect them to available tools.",
      agent: "Define the agent and link it to one or more AI profiles.",
      team: "Create a team that maps agents to tasks.",
      edit: "Edit the selected team, agent, task, or tool in a dedicated workspace."
    };
    function getManageTitleHtml(panelKey, label) {
      var safeLabel = apex.util.escapeHTML(String(label || ""));
      if (panelKey === "overview") {
        return "<span class='ao-section-title-icon' aria-hidden='true'>" +
          "<svg viewBox='0 0 24 24' focusable='false'><path d='m3 18 4-4 3 3 6-6 5 5'/><path d='M15 5h4v4'/><path d='M3 6h8'/></svg>" +
          "</span><span>" + safeLabel + "</span>";
      }
      return safeLabel;
    }
    if (valid.indexOf(target) < 0) target = "overview";
    $(".ao-agent-create-panel[data-agent-create-section]").removeClass("is-active");
    $(".ao-agent-create-panel[data-agent-create-section='" + target + "']").addClass("is-active");
    $("[data-agent-create-panel]").removeClass("is-active");
    $("[data-agent-create-panel='" + target + "']").addClass("is-active");
    $("#aoAgentManageTitle").html(getManageTitleHtml(target, titleByPanel[target] || "Agent Builder"));
    $("#aoAgentManageCopy").text(copyByPanel[target] || copyByPanel.overview);
    if (target === "edit") {
      refreshAgentEntityOptions();
    }
    if (target === "task" || target === "team" || target === "overview") {
      refreshAgentCreateLinkOptions();
    }
    if (target === "overview") {
      setAgentStudioEditorVisible(false);
      applyAgentBuilderModeUi();
      window.requestAnimationFrame(drawAgentStudioLinks);
    }
  }

  function formatAgentBuilderArtifactSections(artifacts) {
    var safeArtifacts = artifacts && typeof artifacts === "object" ? artifacts : {};
    var sections = [
      { label: "Agent Definition", key: "agent" },
      { label: "Team Definition", key: "team" },
      { label: "Task Definition", key: "task" },
      { label: "Tool PL/SQL", key: "toolPlsql" },
      { label: "Additional Procedures/Functions", key: "additionalProcedures" }
    ];
    var output = [];
    sections.forEach(function(section) {
      var value = String(safeArtifacts[section.key] || "").trim();
      if (!value) return;
      output.push("--------------------------------");
      output.push(section.label);
      output.push("--------------------------------");
      output.push(value);
      output.push("");
    });
    return output.join("\n").trim();
  }

  function applyAgentBuilderModeUi() {
    var $overviewPanel = $(".ao-agent-create-panel[data-agent-create-section='overview']");
    var isOverview = $overviewPanel.hasClass("is-active");
    AGENT_BUILDER_MODE = "graphical";
    $(".ao-builder-mode-btn[data-builder-mode='graphical']").addClass("is-active").attr("aria-selected", "true");
    $(".ao-builder-mode-btn[data-builder-mode='natural-language']").removeClass("is-active").attr("aria-selected", "false");
    $overviewPanel.removeClass("is-builder-mode-natural-language").addClass("is-builder-mode-graphical");
    $("#aoNaturalLanguageBuilder").addClass("is-hidden");
    $overviewPanel.find(".ao-agent-studio").toggleClass("is-hidden", !isOverview);
    $("#aoNlBuilderDefaultTeam").text("Default Agent Team: " + AGENT_BUILDER_DEFAULT_TEAM);
    if (isOverview) {
      window.requestAnimationFrame(drawAgentStudioLinks);
    }
  }

  function renderNlBuilderChatHistory() {
    var html = "";
    AGENT_BUILDER_NL_HISTORY.forEach(function(item, idx) {
      var role = String((item && item.role) || "assistant").trim().toLowerCase();
      var text = String((item && item.text) || "").trim();
      var rendered;
      if (!text) return;
      html += "<div class='ao-nl-chat-message ao-nl-chat-message--" + (role === "user" ? "user" : "assistant") + "'>";
      html += "<span class='ao-nl-chat-role'>" + (role === "user" ? "You" : "Builder") + "</span>";
      if (item && item.thinking) {
        html += "<div class='ao-nl-chat-thinking'><span>Thinking</span><span class='ao-nl-chat-thinking-dots'><i></i><i></i><i></i></span></div>";
      } else if (role === "user") {
        html += "<pre class='ao-nl-chat-text'>" + apex.util.escapeHTML(text) + "</pre>";
      } else {
        rendered = renderNlBuilderMessageBody(item);
        html += rendered.html;
        if (rendered.hasCode && role !== "user") {
          AGENT_BUILDER_NL_HISTORY[idx].editorCode = rendered.editorCode;
          html += "<div class='ao-nl-chat-actions'><button type='button' class='t-Button ao-nl-open-editor-btn' data-nl-history-index='" + idx + "'>Open in Editor</button></div>";
        } else if (AGENT_BUILDER_NL_HISTORY[idx]) {
          delete AGENT_BUILDER_NL_HISTORY[idx].editorCode;
        }
      }
      html += "</div>";
    });
    if (!html) {
      html = "<div class='ao-muted-box'>Describe the agent you want to build to get started.</div>";
    }
    $("#aoNlBuilderChatHistory").html(html);
    var panel = $("#aoNlBuilderChatHistory")[0];
    if (panel) panel.scrollTop = panel.scrollHeight;
  }

  function isNlBuilderSqlLikeLanguage(language, code) {
    var lang = String(language || "").trim().toLowerCase();
    var sample = String(code || "").trim().toLowerCase();
    if (!lang) {
      return /\b(create|replace|declare|begin|procedure|function|package|dbms_cloud_ai_agent|apex_json|select|from)\b/.test(sample);
    }
    return ["sql", "plsql", "oracle", "pgsql", "postgresql"].indexOf(lang) >= 0;
  }

  function looksLikeNlBuilderCode(text) {
    var sample = String(text || "").trim().toLowerCase();
    if (!sample) return false;
    if (sample.indexOf("```") >= 0) return true;
    return /\b(create\s+or\s+replace|declare|begin|end;|dbms_cloud_ai_agent|procedure|function|package)\b/.test(sample);
  }

  function renderNlBuilderCodeBlock(code, language) {
    var text = String(code || "").replace(/\r\n?/g, "\n");
    var lines = text.split("\n");
    var lang = String(language || "").trim();
    var isSqlLike = isNlBuilderSqlLikeLanguage(lang, text);
    var html = "";

    if (isSqlLike) {
      lines.forEach(function(line) {
        var commentIndex = line.indexOf("--");
        var codePart = commentIndex >= 0 ? line.slice(0, commentIndex) : line;
        var commentPart = commentIndex >= 0 ? line.slice(commentIndex) : "";
        var lineHtml = highlightPlsqlCodeLine(codePart);
        if (commentPart) {
          lineHtml += "<span class='ao-plsql-token-comment'>" + apex.util.escapeHTML(commentPart) + "</span>";
        }
        html += "<span class='ao-nl-code-line'>" + lineHtml + "</span>";
      });
    } else {
      html = apex.util.escapeHTML(text);
    }

    return (
      "<div class='ao-nl-code-block'>" +
        "<div class='ao-nl-code-head'>" + apex.util.escapeHTML((lang || (isSqlLike ? "plsql" : "text")).toUpperCase()) + "</div>" +
        "<pre class='ao-nl-code'><code>" + html + "</code></pre>" +
      "</div>"
    );
  }

  function parseNlBuilderFencedCode(text) {
    var input = String(text || "");
    var codeFenceRe = /```([a-z0-9_+-]*)[ \t]*\n?([\s\S]*?)```/ig;
    var blocks = [];
    var lastIndex = 0;
    var match;
    while ((match = codeFenceRe.exec(input)) !== null) {
      if (match.index > lastIndex) {
        blocks.push({ type: "text", value: input.slice(lastIndex, match.index) });
      }
      blocks.push({
        type: "code",
        language: String(match[1] || "").trim(),
        value: String(match[2] || "")
      });
      lastIndex = codeFenceRe.lastIndex;
    }
    if (lastIndex < input.length) {
      blocks.push({ type: "text", value: input.slice(lastIndex) });
    }
    if (!blocks.length) {
      blocks.push({ type: "text", value: input });
    }
    return blocks;
  }

  function renderNlBuilderMessageBody(item) {
    var text = String((item && item.text) || "").trim();
    var generatedCode = String((item && item.generatedCode) || "").trim();
    var blocks = parseNlBuilderFencedCode(text);
    var htmlParts = [];
    var editorParts = [];
    var hasFencedCode = false;

    blocks.forEach(function(block) {
      if (!block || block.type === "text") {
        var plain = String((block && block.value) || "").trim();
        if (!plain) return;
        htmlParts.push("<pre class='ao-nl-chat-text'>" + apex.util.escapeHTML(plain) + "</pre>");
        return;
      }
      hasFencedCode = true;
      editorParts.push(String(block.value || "").trim());
      htmlParts.push(renderNlBuilderCodeBlock(block.value, block.language));
    });

    if (!hasFencedCode && !generatedCode && looksLikeNlBuilderCode(text)) {
      htmlParts = [renderNlBuilderCodeBlock(text, "plsql")];
      editorParts = [text];
    }

    if (generatedCode) {
      htmlParts.push("<div class='ao-nl-code-label'>Generated Artifacts</div>");
      htmlParts.push(renderNlBuilderCodeBlock(generatedCode, "plsql"));
      editorParts.push(generatedCode);
    }

    var editorCode = editorParts
      .map(function(part) { return String(part || "").trim(); })
      .filter(Boolean)
      .filter(function(part, idx, arr) { return arr.indexOf(part) === idx; })
      .join("\n\n");

    return {
      html: htmlParts.join(""),
      hasCode: !!editorCode,
      editorCode: editorCode
    };
  }

  function setNlBuilderStatus(message, isError) {
    $("#aoNlBuilderStatus").text(String(message || "")).toggleClass("is-error", !!isError);
  }

  function createNlBuilderConversationId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return "nlb_" + String(window.crypto.randomUUID()).replace(/-/g, "");
    }
    return "nlb_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 10);
  }

  function resetNlBuilderSession() {
    AGENT_BUILDER_NL_CONVERSATION_ID = createNlBuilderConversationId();
    AGENT_BUILDER_NL_HISTORY = [];
    AGENT_BUILDER_NL_IS_SENDING = false;
    $("#aoNlBuilderPrompt").val("");
    setNlBuilderStatus("");
    renderNlBuilderChatHistory();
  }

  function sendNlBuilderPrompt() {
    var message = String($("#aoNlBuilderPrompt").val() || "").trim();
    var pendingId;

    function resolvePendingReply(replyText, artifacts) {
      var finalText = String(replyText || "").trim();
      var generatedCode = formatAgentBuilderArtifactSections(artifacts || {});
      var updated = false;
      for (var i = AGENT_BUILDER_NL_HISTORY.length - 1; i >= 0; i -= 1) {
        var row = AGENT_BUILDER_NL_HISTORY[i];
        if (row && row.thinking && row.pending_id === pendingId) {
          AGENT_BUILDER_NL_HISTORY[i] = {
            role: "assistant",
            text: finalText || "No response received.",
            generatedCode: generatedCode
          };
          updated = true;
          break;
        }
      }
      if (!updated) {
        AGENT_BUILDER_NL_HISTORY.push({
          role: "assistant",
          text: finalText || "No response received.",
          generatedCode: generatedCode
        });
      }
    }

    if (AGENT_BUILDER_NL_IS_SENDING) return;
    if (!message) {
      showError("Enter a prompt first.");
      return;
    }
    AGENT_BUILDER_NL_IS_SENDING = true;
    $("#aoNlBuilderSend").prop("disabled", true);
    if (!String(AGENT_BUILDER_NL_CONVERSATION_ID || "").trim()) {
      AGENT_BUILDER_NL_CONVERSATION_ID = createNlBuilderConversationId();
    }
    AGENT_BUILDER_NL_HISTORY.push({ role: "user", text: message });
    pendingId = ++AGENT_BUILDER_NL_PENDING_SEQ;
    AGENT_BUILDER_NL_HISTORY.push({ role: "assistant", text: "Thinking", thinking: true, pending_id: pendingId });
    renderNlBuilderChatHistory();
    setNlBuilderStatus("", false);
    $("#aoNlBuilderPrompt").val("");

    ajax(PROC.AGENT_BUILDER_CHAT, {
      x01: AGENT_BUILDER_NL_CONVERSATION_ID || "",
      x02: AGENT_BUILDER_DEFAULT_TEAM,
      p_clob_01: message
    }, function(err, data) {
      AGENT_BUILDER_NL_IS_SENDING = false;
      $("#aoNlBuilderSend").prop("disabled", false);

      if (err) {
        resolvePendingReply("Unable to reach Natural Language Builder service.");
        renderNlBuilderChatHistory();
        setNlBuilderStatus("Unable to reach the Natural Language Builder service.", true);
        showError(err.responseText || "Natural Language Builder request failed.");
        return;
      }
      if (!data || data.success === false) {
        resolvePendingReply("The builder returned an error.");
        renderNlBuilderChatHistory();
        setNlBuilderStatus("The builder returned an error. Review the message and retry.", true);
        showError((data && data.message) || "Natural Language Builder request failed.");
        return;
      }

      AGENT_BUILDER_NL_CONVERSATION_ID = String(data.conversation_id || AGENT_BUILDER_NL_CONVERSATION_ID || "").trim();
      resolvePendingReply(String(data.reply || data.raw_response || "").trim(), data.artifacts || {});
      renderNlBuilderChatHistory();

      var combinedCode = formatAgentBuilderArtifactSections(data.artifacts || {});
      if (combinedCode) {
        $("#aoAgentStudioPlsqlCode").val(combinedCode);
        setAgentStudioEditorVisible(true);
        setAgentStudioStep(5);
      }
      setNlBuilderStatus("Done. You can continue refining in chat or edit generated code directly.", false);
    });
  }

  function getAgentEditorPanel() {
    return $(".ao-agent-create-panel[data-agent-create-section='edit']");
  }

  function rememberAgentEditorHome() {
    var $panel = getAgentEditorPanel();
    if (!AGENT_EDITOR_HOME && $panel.length) {
      AGENT_EDITOR_HOME = $panel.parent();
    }
    return $panel;
  }

  function moveAgentEditorToManage() {
    var $panel = rememberAgentEditorHome();
    if (AGENT_EDITOR_HOME && $panel.length && !$panel.parent().is(AGENT_EDITOR_HOME)) {
      AGENT_EDITOR_HOME.append($panel);
    }
    $("#aoAgentInlineEditorHost").addClass("is-hidden");
  }

  function moveAgentEditorToInline() {
    var $panel = rememberAgentEditorHome();
    if (!$panel.length) return;
    $("#aoAgentInlineEditorPanel").append($panel);
    $("#aoAgentInlineEditorHost").removeClass("is-hidden");
    $panel.addClass("is-active");
    if ($("#aoAgentInlineEditorHost").length && typeof $("#aoAgentInlineEditorHost")[0].scrollIntoView === "function") {
      $("#aoAgentInlineEditorHost")[0].scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }

  function openFreshScreen(target) {
    var parts = String(target || "").split(":");
    var group = String(parts[0] || "").trim();
    var screen = String(parts[1] || "default").trim();
    if (!group) return;
    if (screen === "manage" && !CAN_MANAGE_SETTINGS) {
      screen = "default";
    }
    setScreen(group, screen);
  }

  function copyTextToClipboard(value) {
    var text = String(value == null ? "" : value).trim();
    if (!text) return;
    if (!(navigator.clipboard && typeof navigator.clipboard.writeText === "function")) {
      showError("Copy is not available in this browser.");
      return;
    }
    navigator.clipboard.writeText(text).then(function() {
      showSuccess("Copied to clipboard.");
    }).catch(function() {
      showError("Copy failed.");
    });
  }

  function copyElementTextById(targetId) {
    var id = String(targetId || "").trim();
    if (!id) return;
    var node = document.getElementById(id);
    var text = "";
    if (node) {
      if (typeof node.value === "string") text = String(node.value || "");
      else text = String(node.innerText || node.textContent || "");
    }
    copyTextToClipboard(text);
  }

  function getSummaryCopyButtonHtml(value) {
    var text = String(value == null ? "" : value).trim();
    if (!text) return "";
    return "<button type='button' class='ao-summary-copy-btn' data-copy-summary-value='" + escapeAttr(text) + "' title='Copy OCI Compartment ID' aria-label='Copy OCI Compartment ID'><svg viewBox='0 0 24 24' aria-hidden='true' focusable='false'><rect x='9' y='9' width='10' height='10' rx='1.5'></rect><path d='M15 9V6.5A1.5 1.5 0 0 0 13.5 5h-8A1.5 1.5 0 0 0 4 6.5v8A1.5 1.5 0 0 0 5.5 16H9'></path></svg></button>";
  }

  function fillSelect(selector, rows, selectedValue, options) {
    var $target = $(selector);
    var isDatalistInput = $target.is("input[list]");
    var listId = isDatalistInput ? String($target.attr("list") || "") : "";
    var $list = listId ? $("#" + listId) : $();
    var opts = options && typeof options === "object" ? options : {};
    var safeRows = Array.isArray(rows) ? rows : [];
    var includeBlank = isDatalistInput ? false : (Object.prototype.hasOwnProperty.call(opts, "includeBlank") ? !!opts.includeBlank : true);
    var blankLabel = String(opts.blankLabel || "- Select -");
    var autoSelectFirst = !!opts.autoSelectFirst;
    var firstRowValue = "";
    safeRows.some(function (r) {
      var value = String((r && r.r) || "").trim();
      if (!value) return false;
      firstRowValue = value;
      return true;
    });
    var resolvedSelectedValue = String(selectedValue == null ? "" : selectedValue).trim();
    var selectedValueExists = safeRows.some(function(r) {
      return String((r && r.r) || "").trim() === resolvedSelectedValue;
    });
    if (autoSelectFirst && (!resolvedSelectedValue || !selectedValueExists) && firstRowValue) {
      resolvedSelectedValue = firstRowValue;
    }

    var html = "";
    if (!isDatalistInput && includeBlank) {
      html += "<option value=''>" + apex.util.escapeHTML(blankLabel) + "</option>";
    }
    safeRows.forEach(function (r) {
      var rawValue = String((r && r.r) || "").trim();
      if (!rawValue) return;
      var rawLabel = String((r && r.d) || rawValue).trim();
      var rVal = apex.util.escapeHTML(rawValue);
      var dVal = apex.util.escapeHTML(rawLabel || rawValue);
      var sel = resolvedSelectedValue && resolvedSelectedValue === rawValue ? " selected" : "";
      if (isDatalistInput) {
        html += "<option value='" + rVal + "' label='" + dVal + "'></option>";
      } else {
        html += "<option value='" + rVal + "'" + sel + ">" + dVal + "</option>";
      }
    });
    if (isDatalistInput) {
      $list.html(html);
      if (resolvedSelectedValue) $target.val(resolvedSelectedValue);
      else if (selectedValue != null) $target.val("");
    } else {
      $target.html(html);
      if (resolvedSelectedValue) {
        $target.val(resolvedSelectedValue);
      } else if (!includeBlank && firstRowValue) {
        $target.val(firstRowValue);
      }
    }
    if (/ToolFunction|NewToolFunction/i.test(selector)) {
      debugSettingsLog("fillSelect: " + selector, {
        row_count: (rows || []).length,
        selected_value: selectedValue || "",
        option_count_after_fill: isDatalistInput ? $list.find("option").length : $target.find("option").length,
        element_count: $target.length,
        suggestion_list_id: listId,
        sample: (rows || []).slice(0, 5)
      });
    }
  }

  function fillMultiSelect(selector, rows, selectedValues) {
    var selected = Array.isArray(selectedValues) ? selectedValues.map(String) : [];
    var html = "";
    (rows || []).forEach(function (r) {
      var value = String((r && r.r) || "").trim();
      if (!value) return;
      var rVal = apex.util.escapeHTML(value);
      var dVal = apex.util.escapeHTML((r && r.d) || value);
      var sel = selected.indexOf(value) >= 0 ? " selected" : "";
      html += "<option value='" + rVal + "'" + sel + ">" + dVal + "</option>";
    });
    $(selector).html(html);
  }

  function getSelectValues(selector) {
    var raw = $(selector).val();
    if (Array.isArray(raw)) {
      return raw.map(function(item) { return String(item || "").trim(); }).filter(Boolean);
    }
    var value = String(raw || "").trim();
    return value ? [value] : [];
  }

  function ensureSelectOption(selector, value) {
    var optionValue = String(value || "").trim();
    var $target = $(selector);
    var isDatalistInput = $target.is("input[list]");
    var listId = isDatalistInput ? String($target.attr("list") || "") : "";
    var $optionHost = isDatalistInput && listId ? $("#" + listId) : $target;
    if (!optionValue) return;
    var exists = false;
    $optionHost.find("option").each(function() {
      if (String($(this).attr("value") || "") === optionValue) exists = true;
    });
    if (!exists) {
      $optionHost.append(
        "<option value='" + apex.util.escapeHTML(optionValue) + "'>" + apex.util.escapeHTML(optionValue) + "</option>"
      );
    }
    if (isDatalistInput) $target.val(optionValue);
  }

  function adminToggleIdByKey(key) {
    var map = {
      SHOW_OPEN_IN_EDITOR: "#aoToggleOpenEditor",
      SHOW_AGENT_THOUGHTS: "#aoToggleAgentThoughts",
      SHOW_EXPORT_PDF: "#aoToggleExportPdf",
      SHOW_EXPORT_PDF_BUTTON: "#aoToggleExportPdf",
      SHOW_EXPORT_EXCEL: "#aoToggleExportExcel",
      SHOW_EXPORT_EXCEL_BUTTON: "#aoToggleExportExcel",
      SHOW_CONVERSATION_TIMER: "#aoToggleConversationTimer",
      SHOW_CONVERSATION_TIMER_BUTTON: "#aoToggleConversationTimer",
      SHOW_DELETE_PROMPT: "#aoToggleDeletePrompt",
      SHOW_DELETE_PROMPT_BUTTON: "#aoToggleDeletePrompt",
      ENABLE_END_USER_SWITCH_CONV_STYLE: "#aoToggleEndUserConvStyle",
      ENABLE_END_USER_SWITCH_PROFILES_AGENTS: "#aoToggleEndUserProfilesAgents",
      ENABLE_END_USER_SWITCH_NL2SQL_PROFILE: "#aoToggleEndUserNl2sqlProfile",
      ENABLE_END_USER_SWITCH_RAG_PROFILE: "#aoToggleEndUserRagProfile"
    };
    return map[key] || null;
  }

  function getAdminSaveKeyCandidates(key) {
    var baseKey = String(key || "").trim().toUpperCase();
    var list = [baseKey];
    var mapped = ADMIN_SAVE_KEY_CANDIDATES[baseKey];
    if (Array.isArray(mapped)) {
      mapped.forEach(function (item) {
        var normalized = String(item || "").trim().toUpperCase();
        if (!normalized) return;
        if (list.indexOf(normalized) >= 0) return;
        list.push(normalized);
      });
    }
    return list;
  }

  function isInvalidConfigKeyMessage(message) {
    var text = String(message || "").trim().toLowerCase();
    if (!text) return false;
    var normalized = text
      .replace(/[_:-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (!normalized) return false;
    if (
      normalized.indexOf("invalid config key") >= 0 ||
      normalized.indexOf("unknown config key") >= 0 ||
      normalized.indexOf("app config key") >= 0
    ) {
      return true;
    }
    if (
      normalized.indexOf("config key") >= 0 &&
      (
        normalized.indexOf("invalid") >= 0 ||
        normalized.indexOf("unknown") >= 0 ||
        normalized.indexOf("not found") >= 0 ||
        normalized.indexOf("does not exist") >= 0 ||
        normalized.indexOf("missing") >= 0 ||
        normalized.indexOf("unsupported") >= 0
      )
    ) {
      return true;
    }
    return false;
  }

  function extractAdminSaveErrorMessage(err, data) {
    var pieces = [];
    var add = function(v) {
      var text = String(v == null ? "" : v).trim();
      if (!text) return;
      if (pieces.indexOf(text) >= 0) return;
      pieces.push(text);
    };

    if (data && typeof data === "object") {
      add(data.message);
      add(data.error);
      add(data.error_message);
      add(data.details);
      add(data.responseText);
    }
    if (err && typeof err === "object") {
      add(err.responseText);
      add(err.statusText);
      add(err.message);
    } else {
      add(err);
    }
    return pieces.join(" | ");
  }

  function resolveBootstrapFlag(data, keys, fallbackValue) {
    var source = data && typeof data === "object" ? data : {};
    var candidates = Array.isArray(keys) ? keys : [keys];
    for (var i = 0; i < candidates.length; i += 1) {
      var key = String(candidates[i] || "").trim();
      if (!key) continue;
      if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
      var raw = source[key];
      if (raw == null || String(raw).trim() === "") continue;
      return normalizeAdminFlag(raw);
    }
    return !!fallbackValue;
  }

  function normalizeZoomPct(v) {
    var n = Number(v);
    if (!isFinite(n)) {
      var text = String(v == null ? "" : v);
      var match = text.match(/-?\d+(?:\.\d+)?/);
      n = match ? Number(match[0]) : NaN;
    }
    if (!isFinite(n)) n = 100;
    n = Math.round(n / APP_ZOOM_STEP) * APP_ZOOM_STEP;
    if (n < APP_ZOOM_MIN) n = APP_ZOOM_MIN;
    if (n > APP_ZOOM_MAX) n = APP_ZOOM_MAX;
    return n;
  }

  function normalizeRetentionDays(v) {
    var n = Number(v);
    if (!isFinite(n)) n = 7;
    n = Math.round(n);
    if (n < 0) n = 0;
    if (n > 3650) n = 3650;
    return n;
  }

  function setZoomLabel(pct) {
    $("#aoAppZoomValue").text(String(normalizeZoomPct(pct)) + "%");
  }

  function normalizeAdminTextValue(value, fallbackValue) {
    var text = String(value == null ? "" : value).trim();
    if (text) return text;
    return String(fallbackValue == null ? "" : fallbackValue).trim();
  }

  function normalizeOptionalAdminTextValue(value) {
    return String(value == null ? "" : value).trim();
  }

  function normalizeAdminOwnersCsv(value) {
    var text = String(value == null ? "" : value).trim().toUpperCase();
    text = text.replace(/[\r\n]+/g, ",");
    text = text.replace(/[;]+/g, ",");
    text = text.replace(/\s*,\s*/g, ",");
    text = text.replace(/,+/g, ",");
    text = text.replace(/^,|,$/g, "");
    return text;
  }

  function getBootstrapValue(data, lowerKey, upperKey) {
    if (!data || typeof data !== "object") return "";
    if (Object.prototype.hasOwnProperty.call(data, lowerKey)) return data[lowerKey];
    if (upperKey && Object.prototype.hasOwnProperty.call(data, upperKey)) return data[upperKey];
    return "";
  }

  function configureZoomSliderBounds() {
    var $input = $("#aoAppZoomInput");
    if (!$input.length) return;
    $input.attr("min", String(APP_ZOOM_MIN));
    $input.attr("max", String(APP_ZOOM_MAX));
    $input.attr("step", String(APP_ZOOM_STEP));
    setZoomSliderValue($input.val());
  }

  function setZoomSliderProgress(pct) {
    return normalizeZoomPct(pct);
  }

  function setZoomSliderValue(pct) {
    var normalized = normalizeZoomPct(pct);
    var $input = $("#aoAppZoomInput");
    if (!$input.length) {
      setZoomLabel(normalized);
      return normalized;
    }
    $input.val(normalized);
    var applied = normalizeZoomPct($input.val());
    if (applied !== normalized) {
      $input.val(applied);
    }
    setZoomSliderProgress(applied);
    setZoomLabel(applied);
    return applied;
  }

  function readStoredZoomPct() {
    var raw = null;
    try { raw = sessionStorage.getItem(APP_ZOOM_STORAGE_KEY); } catch (e) {}
    if (raw == null || raw === "") {
      try { raw = localStorage.getItem(APP_ZOOM_STORAGE_KEY); } catch (e2) {}
    }
    if (raw == null || raw === "") return null;
    return normalizeZoomPct(raw);
  }

  function readStoredSidebarCollapsed() {
    var raw = "";
    try {
      raw = String(localStorage.getItem(SETTINGS_SIDEBAR_COLLAPSED_KEY) || "").trim().toUpperCase();
    } catch (e) {
      raw = "";
    }
    return raw === "Y" || raw === "TRUE" || raw === "1";
  }

  function applySidebarCollapsedState(collapsed, options) {
    var isCollapsed = !!collapsed;
    var persist = !options || options.persist !== false;
    var $root = $("#aoSettings");
    var $toggle = $("#aoSidebarToggle");
    var ariaExpanded = isCollapsed ? "false" : "true";
    var actionLabel = isCollapsed ? "Expand navigation" : "Collapse navigation";

    $root.toggleClass("is-sidebar-collapsed", isCollapsed);

    if ($toggle.length) {
      $toggle.attr("aria-expanded", ariaExpanded);
      $toggle.attr("aria-label", actionLabel);
      $toggle.attr("title", actionLabel);
    }

    if (persist) {
      try {
        localStorage.setItem(SETTINGS_SIDEBAR_COLLAPSED_KEY, isCollapsed ? "Y" : "N");
      } catch (e) {}
    }
  }

  function toggleSidebarCollapsedState() {
    var isCollapsed = $("#aoSettings").hasClass("is-sidebar-collapsed");
    applySidebarCollapsedState(!isCollapsed, { persist: true });
  }

  function applyZoomToWindow(targetWindow, pct) {
    if (!targetWindow || !targetWindow.document || !targetWindow.document.documentElement) return;
    var scale = normalizeZoomPct(pct) / 100;
    targetWindow.document.documentElement.style.setProperty("--ask-oracle-font-scale", String(scale));
  }

  function applyAppZoomPreview(pct) {
    var normalized = normalizeZoomPct(pct);
    applyZoomToWindow(window, normalized);
    try {
      if (window.parent && window.parent !== window) {
        applyZoomToWindow(window.parent, normalized);
      }
    } catch (e) {}
    try { sessionStorage.setItem(APP_ZOOM_STORAGE_KEY, String(normalized)); } catch (e) {}
    try { localStorage.setItem(APP_ZOOM_STORAGE_KEY, String(normalized)); } catch (e2) {}
  }

  function normalizeThemeMode(value) {
    return "light";
  }

  function readStoredThemeMode() {
    return "light";
  }

  function persistThemeMode(mode) {
    try { sessionStorage.setItem(SETTINGS_THEME_MODE_KEY, "light"); } catch (e) {}
  }

  function isSystemDarkMode() {
    return false;
  }

  function getThemePreviewByMode(mode) {
    return "light";
  }

  function syncThemeToggleStateUi(mode) {
    var normalized = normalizeThemeMode(mode);
    var $modeSelect = $("#aoThemeModeSelect");
    if ($modeSelect.length) {
      $modeSelect.val(normalized);
    }
    var isSystem = normalized === "system";
    $(".ao-theme-toggle-group").toggleClass("is-dark", isSystem);
  }

  function applyThemePreviewMode(mode, options) {
    var normalized = normalizeThemeMode(mode);
    var opts = options || {};
    $("#aoSettings").attr("data-theme-preview", getThemePreviewByMode(normalized));
    if (opts.syncToggle !== false) {
      syncThemeToggleStateUi(normalized);
    }
  }

  function selectedProfileValue(profileType) {
    if (profileType === "NL2SQL") return String($("#aoNl2sqlSelect").val() || "").trim();
    if (profileType === "RAG") return String($("#aoRagSelect").val() || "").trim();
    return "";
  }

  function renderVectorIndexSummary() {
    var indexName = String($("#aoVectorIndexSelect").val() || "").trim();
    var selectedRow = null;
    var indexCount = VECTOR_INDEX_ROWS.length;
    var html;
    var attributes;
    var usedAttributes = {};

    function normalizedAttributeName(value) {
      return String(value || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
    }

    function attributeValue(names) {
      var aliases = Array.isArray(names) ? names : [names];
      var result = "";
      attributes.some(function(attribute) {
        var name = normalizedAttributeName(attribute.attribute_name != null ? attribute.attribute_name : attribute.ATTRIBUTE_NAME);
        var matched = aliases.some(function(alias) {
          var normalizedAlias = normalizedAttributeName(alias);
          /* Oracle versions use slightly different prefixes/suffixes for
             these attributes (for example VECTOR_INDEX_PIPELINE_NAME). */
          return name === normalizedAlias ||
            (normalizedAlias.length > 3 && name.indexOf(normalizedAlias) >= 0);
        });
        if (!matched) return false;
        usedAttributes[name] = true;
        result = String(attribute.attribute_value != null ? attribute.attribute_value : attribute.ATTRIBUTE_VALUE || "").trim();
        return true;
      });
      return result || "Not specified";
    }

    function summaryItem(label, value) {
      var text = String(value == null || value === "" ? "Not specified" : value);
      var isOciCompartmentId = normalizedAttributeName(label) === "ocicompartmentid";
      var copyButton = isOciCompartmentId && text !== "Not specified"
        ? getSummaryCopyButtonHtml(text)
        : "";
      return "<div class='ao-vector-index-summary-item'><span class='ao-summary-item-label'>" + apex.util.escapeHTML(label) + copyButton + "</span><strong title='" + escapeAttr(text) + "'>" + apex.util.escapeHTML(text) + "</strong></div>";
    }

    VECTOR_INDEX_ROWS.some(function(row) {
      if (String((row && row.index_name) || "").trim() !== indexName) return false;
      selectedRow = row;
      return true;
    });

    if (!indexName) {
      $("#aoVectorIndexSummary").html(
        "<div class='ao-muted-box'>" + (indexCount ? "Select a vector index to view its summary." : "No vector indexes are available in this database.") + "</div>"
      );
      return;
    }

    attributes = selectedRow && Array.isArray(selectedRow.attributes) ? selectedRow.attributes : [];
    var columns = [
      [
        ["Vector Index Name", indexName],
        ["Index ID", (selectedRow && selectedRow.index_id) || "Not specified"],
        ["Status", (selectedRow && selectedRow.status) || "Not specified"],
        ["Created", (selectedRow && selectedRow.created) || "Not specified"],
        ["Description", (selectedRow && selectedRow.description) || "Not specified"]
      ],
      [
        ["Pipeline Name", attributeValue(["pipeline_name", "pipeline"])],
        ["Location", attributeValue(["location", "object_storage_location", "object_storage_url"])],
        ["Object Storage Credential", attributeValue(["object_storage_credential", "credential_name", "credential"])],
        ["Refresh Rate", attributeValue(["refresh_rate", "refresh_rate_minutes"])]
      ],
      [
        ["Profile Name", attributeValue(["profile_name", "embedding_profile_name"])],
        ["Vector DB Provider", attributeValue(["vector_db_provider", "db_provider", "provider"])],
        ["Last Modified", (selectedRow && selectedRow.last_modified) || "Not specified"],
        ["Vector Indexes in Database", indexCount]
      ]
    ];

    attributes.forEach(function(attribute) {
      var name = String(attribute.attribute_name != null ? attribute.attribute_name : attribute.ATTRIBUTE_NAME || "").trim();
      var normalizedName = normalizedAttributeName(name);
      var value = String(attribute.attribute_value != null ? attribute.attribute_value : attribute.ATTRIBUTE_VALUE || "").trim();
      if (!name || usedAttributes[normalizedName]) return;
      columns[1 + (columns[1].length <= columns[2].length ? 0 : 1)].push([name, value || "Not specified"]);
    });

    html = "<div class='ao-vector-index-summary-grid'>";
    columns.forEach(function(column) {
      html += "<div class='ao-vector-index-summary-column'>";
      column.forEach(function(item) { html += summaryItem(item[0], item[1]); });
      html += "</div>";
    });
    html += "</div>";
    $("#aoVectorIndexSummary").html(html);
  }

  function loadVectorIndexes() {
    ajax(PROC.GET_VECTOR_INDEXES, {}, function(err, data) {
      var rows;
      var selected;
      if (err || !data || data.success === false) {
        renderVectorIndexSummary();
        return;
      }
      rows = Array.isArray(data.rows) ? data.rows : [];
      VECTOR_INDEX_ROWS = rows.map(function(row) {
        var source = row && typeof row === "object" ? row : {};
        return {
          index_id: source.index_id != null ? source.index_id : source.INDEX_ID,
          index_name: String(source.index_name != null ? source.index_name : source.INDEX_NAME || "").trim(),
          status: source.status != null ? source.status : source.STATUS,
          description: source.description != null ? source.description : source.DESCRIPTION,
          created: source.created != null ? source.created : source.CREATED,
          last_modified: source.last_modified != null ? source.last_modified : source.LAST_MODIFIED,
          attributes: Array.isArray(source.attributes) ? source.attributes : (Array.isArray(source.ATTRIBUTES) ? source.ATTRIBUTES : [])
        };
      }).filter(function(row) { return !!row.index_name; });
      selected = String($("#aoVectorIndexSelect").val() || "").trim();
      fillSelect("#aoVectorIndexSelect", VECTOR_INDEX_ROWS.map(function(row) {
        return { r: row.index_name, d: row.index_name };
      }), selected, { includeBlank: true, blankLabel: "Select Vector Index", autoSelectFirst: true });
      renderVectorIndexSummary();
    });
  }

  function parseObjectListLines(textValue) {
    var out = [];
    String(textValue || "").split(/\r?\n/).forEach(function (line) {
      var s = line.trim();
      if (!s) return;
      if (!/^[A-Za-z][A-Za-z0-9_$#]*(\.[A-Za-z][A-Za-z0-9_$#]*)?$/.test(s)) {
        throw new Error("Invalid object name: '" + s + "'. Use OWNER.OBJECT or OWNER with letters, numbers, underscores, $, and #.");
      }
      var i = s.indexOf(".");
      if (i > 0 && i < s.length - 1) {
        out.push({ owner: s.substring(0, i).trim(), name: s.substring(i + 1).trim() });
      } else {
        out.push({ owner: s });
      }
    });
    return out;
  }

  function objectListTextToNames(textValue) {
    return parseObjectListLines(textValue).map(function(item) {
      if (!item || typeof item !== "object") return "";
      if (item.owner && item.name) return item.owner + "." + item.name;
      return String(item.owner || item.name || "").trim();
    }).filter(Boolean);
  }

  function setObjectListText(targetId, names) {
    $("#" + targetId).val((names || []).filter(Boolean).join("\n"));
  }

  function objectTypeMatchesFilter(objectType, typeFilter) {
    var normalizedType = String(objectType || "").trim().toUpperCase();
    var normalizedFilter = String(typeFilter || "").trim().toUpperCase();
    if (!normalizedFilter) return true;
    if (normalizedFilter === "CATALOG") return false;
    if (normalizedFilter === "GRAPH") {
      return normalizedType === "GRAPH" || normalizedType === "PROPERTY GRAPH";
    }
    return normalizedType === normalizedFilter;
  }

  function getProfileTypeFromContext($el) {
    var $host = $el && $el.length ? $el.closest("[data-profile-type]") : $();
    return String($host.attr("data-profile-type") || "").trim().toUpperCase();
  }

  function isObjectPickerEditableForContext($el) {
    var profileType = getProfileTypeFromContext($el);
    if (!profileType) return true;
    return isAttrEditable(profileType);
  }

  function renderObjectPicker($picker) {
    var targetId = String($picker.attr("data-object-picker-target") || "").trim();
    var query = String($picker.find(".ao-object-picker-search").val() || "").trim().toLowerCase();
    var typeFilter = String($picker.find(".ao-object-picker-type").val() || "").trim().toUpperCase();
    var pickerEditable = isObjectPickerEditableForContext($picker);
    var selected = [];
    var selectedMap = {};
    var optionsHtml = "";
    var chipsHtml = "";
    var optionCount = 0;
    if (!targetId) return;
    try {
      selected = objectListTextToNames($("#" + targetId).val());
    } catch (e) {
      selected = String($("#" + targetId).val() || "").split(/\r?\n/).map(function(line) { return String(line || "").trim(); }).filter(Boolean);
    }
    selected.forEach(function(name) { selectedMap[name.toUpperCase()] = true; });
    if (typeFilter === "CATALOG") {
      var catalogNames = {};
      (CATALOG_HISTORY_ROWS || []).forEach(function(row) {
        var name = String((row && row.catalog_name) || "").trim();
        if (!name) return;
        catalogNames[name.toUpperCase()] = name;
      });
      Object.keys(catalogNames).sort().forEach(function(key) {
        var name = String(catalogNames[key] || "").trim();
        var haystack = ("CATALOG " + name).toLowerCase();
        if (query && haystack.indexOf(query) < 0) return;
        optionCount += 1;
        optionsHtml += "<option value='" + escapeAttr(name) + "'>" + apex.util.escapeHTML("CATALOG - " + name) + "</option>";
      });
    } else {
      (AVAILABLE_OBJECT_OPTIONS || []).forEach(function(row) {
        var value = String((row && row.r) || "").trim();
        var label = String((row && row.d) || value).trim();
        var type = String((row && row.type) || "").trim();
        var haystack = (value + " " + label + " " + type).toLowerCase();
        var selectedKey = value.toUpperCase();
        var typeMatches = objectTypeMatchesFilter(type, typeFilter);
        if (!value) return;
        if (!typeMatches) return;
        if (query && haystack.indexOf(query) < 0) return;
        optionCount += 1;
        optionsHtml += "<option value='" + escapeAttr(value) + "'" + (selectedMap[selectedKey] ? " selected" : "") + ">" + apex.util.escapeHTML(label) + "</option>";
      });
    }
    if (!optionsHtml) {
      optionsHtml = "<option value='' disabled>No matching objects</option>";
    }
    selected.forEach(function(name) {
      chipsHtml += "<span class='ao-object-chip'>" + apex.util.escapeHTML(name) + "<button type='button' data-remove-object='" + escapeAttr(name) + "' aria-label='Remove " + escapeAttr(name) + "'>x</button></span>";
    });
    if (!chipsHtml) chipsHtml = "<span class='ao-object-picker-empty'>No objects selected.</span>";
    var $select = $picker.find(".ao-object-picker-select");
    $select.html(optionsHtml);
    /* Keep the object selector tall enough in edit mode to show multiple rows. */
    $select.attr("size", Math.max(10, Math.min(18, optionCount || 10)));
    $picker.find(".ao-object-picker-selected").html(chipsHtml);
    $picker.find(".ao-object-picker-available-count").text(optionCount + " object" + (optionCount === 1 ? "" : "s"));
    $picker.find(".ao-object-picker-selected-count").text(selected.length + " selected");
    $picker.toggleClass("is-readonly", !pickerEditable);
    $picker.find(".ao-object-picker-search, .ao-object-picker-type, .ao-object-picker-select, [data-remove-object]")
      .prop("disabled", !pickerEditable);
    var $nl2sqlHost = $picker.closest("#aoNl2sqlAttrs[data-profile-type='NL2SQL']");
    if ($nl2sqlHost.length) {
      $nl2sqlHost.find("#aoNl2sqlSelectedCount").text(selected.length + " Total selected objects");
    }
  }

  function refreshObjectPickers() {
    $(".ao-object-picker[data-object-picker-target]").each(function() {
      renderObjectPicker($(this));
    });
  }

  function parseStopTokens(textValue) {
    var raw = String(textValue || "").trim();
    var parsed;
    var tokens = [];
    if (!raw) return tokens;
    if (raw.charAt(0) === "[") {
      try {
        parsed = JSON.parse(raw);
      } catch (e) {
        throw new Error("Stop tokens must be a JSON array of strings or comma/newline-separated text. Example: END, STOP or [\"END\", \"STOP\"].");
      }
      if (!Array.isArray(parsed) || parsed.some(function(item) { return typeof item !== "string"; })) {
        throw new Error("Stop tokens JSON must be an array of strings. Example: [\"END\", \"STOP\"].");
      }
      return parsed.map(function(item) { return String(item || "").trim(); }).filter(Boolean);
    }
    raw.split(/[\n,]/).forEach(function (s) {
      var t = s.trim();
      if (t) tokens.push(t);
    });
    return tokens;
  }

  function parseStopTokensFromField(selector) {
    var field = $(selector).get(0);
    try {
      return parseStopTokens($(selector).val());
    } catch (e) {
      markFieldError(field, e.message || "Invalid stop token syntax.");
      throw e;
    }
  }

  function parseLineArray(textValue) {
    var out = [];
    String(textValue || "")
      .split(/\r?\n/)
      .forEach(function(line) {
        var value = String(line || "").trim();
        if (!value) return;
        out.push(value);
      });
    return out;
  }

  function parseBooleanLike(value) {
    var text = String(value == null ? "" : value).trim().toLowerCase();
    if (!text) return null;
    if (text === "true" || text === "y" || text === "yes" || text === "1") return true;
    if (text === "false" || text === "n" || text === "no" || text === "0") return false;
    return null;
  }

  function booleanValueToSelect(value) {
    var parsed = parseBooleanLike(value);
    if (parsed == null) return "";
    return parsed ? "true" : "false";
  }

  function escapeAttr(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function normalizePrebuiltAgentStatus(value) {
    var status = String(value || "").trim().toLowerCase().replace(/[\s-]+/g, "_");
    if (
      status === "installed" ||
      status === "installing" ||
      status === "update_available" ||
      status === "unsupported" ||
      status === "install_error" ||
      status === "not_installed"
    ) return status;
    return "not_installed";
  }

  function getPrebuiltAgentState() {
    var raw = "";
    try { raw = localStorage.getItem(PREBUILT_AGENT_STATE_KEY); } catch (e1) {}
    if (!raw) {
      try { raw = sessionStorage.getItem(PREBUILT_AGENT_STATE_KEY); } catch (e2) {}
    }
    if (!raw) return {};
    try {
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return {};
      Object.keys(parsed).forEach(function(agentId) {
        var row = parsed[agentId];
        if (!row || typeof row !== "object") return;
        if (normalizePrebuiltAgentStatus(row.status || "") === "install_error") {
          row.status = "not_installed";
          row.installStatus = "";
        }
        row.installStatusMessage = "";
      });
      return parsed;
    } catch (e3) {
      return {};
    }
  }

  function persistPrebuiltAgentState() {
    var safeState = {};
    Object.keys(PREBUILT_AGENT_STATE || {}).forEach(function(agentId) {
      var row = PREBUILT_AGENT_STATE[agentId];
      if (!row || typeof row !== "object") return;
      var normalizedStatus = normalizePrebuiltAgentStatus(row.status || "");
      var persistedStatus = normalizedStatus === "install_error" ? "not_installed" : normalizedStatus;
      safeState[agentId] = $.extend({}, row, {
        status: persistedStatus,
        installStatus: persistedStatus === "installing" ? String(row.installStatus || "") : "",
        installStatusMessage: ""
      });
    });
    var payload = JSON.stringify(safeState);
    try { localStorage.setItem(PREBUILT_AGENT_STATE_KEY, payload); } catch (e1) {}
    try { sessionStorage.setItem(PREBUILT_AGENT_STATE_KEY, payload); } catch (e2) {}
  }

  function normalizePrebuiltViewMode(value) {
    var mode = String(value || "").trim().toLowerCase();
    return mode === "table" ? "table" : "card";
  }

  function loadPrebuiltAgentViewMode() {
    var raw = "";
    try { raw = localStorage.getItem(PREBUILT_AGENT_VIEW_MODE_KEY); } catch (e1) {}
    if (!raw) {
      try { raw = sessionStorage.getItem(PREBUILT_AGENT_VIEW_MODE_KEY); } catch (e2) {}
    }
    return normalizePrebuiltViewMode(raw || "card");
  }

  function persistPrebuiltAgentViewMode(mode) {
    var normalized = normalizePrebuiltViewMode(mode);
    try { localStorage.setItem(PREBUILT_AGENT_VIEW_MODE_KEY, normalized); } catch (e1) {}
    try { sessionStorage.setItem(PREBUILT_AGENT_VIEW_MODE_KEY, normalized); } catch (e2) {}
  }

  function applyPrebuiltViewModeButtons() {
    var isTable = PREBUILT_AGENT_VIEW_MODE === "table";
    var $cardBtn = $("#aoPrebuiltViewCards");
    var $tableBtn = $("#aoPrebuiltViewTable");
    if ($cardBtn.length) {
      $cardBtn.toggleClass("is-active", !isTable);
      $cardBtn.attr("aria-pressed", isTable ? "false" : "true");
    }
    if ($tableBtn.length) {
      $tableBtn.toggleClass("is-active", isTable);
      $tableBtn.attr("aria-pressed", isTable ? "true" : "false");
    }
  }

  function setPrebuiltAgentViewMode(mode) {
    var normalized = normalizePrebuiltViewMode(mode);
    PREBUILT_AGENT_VIEW_MODE = normalized;
    persistPrebuiltAgentViewMode(normalized);
    applyPrebuiltViewModeButtons();
    renderPrebuiltAgents();
  }

  function normalizePrebuiltAgent(agent) {
    var item = agent && typeof agent === "object" ? agent : {};
    var id = String(item.id || "").trim();
    return {
      id: id,
      name: String(item.name || id || "Agent").trim(),
      version: String(item.version || "0.0.0").trim(),
      description: String(item.description || "").trim(),
      detailsSections: normalizePrebuiltDetailsSections(item.detailsSections || item.details_sections || item.readmeSections || item.readme_sections),
      subtitle: String(item.subtitle || item.shortDescription || item.short_description || "").trim(),
      publisher: String(item.publisher || item.provider || "Oracle").trim(),
      category: String(item.category || "AI Agent as a Service").trim(),
      readmeUrl: String(item.readmeUrl || item.readme_url || item.githubReadmeUrl || item.github_readme_url || "").trim(),
      helpDocUrl: String(item.helpDocUrl || item.help_doc_url || item.helpUrl || item.help_url || item.readmeUrl || item.readme_url || "").trim(),
      repoUrl: String(item.repoUrl || "").trim(),
      iconUrl: String(item.iconUrl || item.icon_url || item.logoUrl || item.logo_url || item.imageUrl || item.image_url || "").trim(),
      installNote: String(item.installNote || item.install_note || "").trim(),
      supportNote: String(item.supportNote || item.support_note || "").trim(),
      supportedDatabaseVersions: String(item.supportedDatabaseVersions || item.supported_database_versions || "").trim(),
      displayOrder: Number(item.displayOrder || item.display_order || item.sortOrder || item.sort_order || item.order || 0) || 0,
      supportedDatabaseMajorVersions: normalizePrebuiltStringArray(item.supportedDatabaseMajorVersions || item.supported_database_major_versions).map(function(version) {
        return Number(version);
      }).filter(function(version) {
        return isFinite(version) && version > 0;
      }),
      minDatabaseMajorVersion: Number(item.minDatabaseMajorVersion || item.min_database_major_version || 0) || 0,
      backgroundInstall: item.backgroundInstall === true || item.background_install === true,
      jobLogTable: String(item.jobLogTable || item.job_log_table || "").trim(),
      installSqlFile: String(item.installSqlFile || "").trim(),
      installSqlUrl: String(item.installSqlUrl || item.install_sql_url || "").trim(),
      installProcedure: String(item.installProcedure || item.install_procedure || "").trim(),
      toolsProcedure: String(item.toolsProcedure || item.tools_procedure || "").trim(),
      agentProcedure: String(item.agentProcedure || item.agent_procedure || "").trim(),
      toolsSqlFile: String(item.toolsSqlFile || "tools.sql").trim(),
      agentSqlFile: String(item.agentSqlFile || "agent.sql").trim(),
      teamName: String(item.teamName || item.agentTeamName || item.team_name || item.agent_team_name || "").trim(),
      status: normalizePrebuiltAgentStatus(item.status),
      requiredObjectPrivileges: normalizePrebuiltStringArray(item.requiredObjectPrivileges || item.required_object_privileges || item.requiredPrivileges || item.required_privileges),
      requiredSystemPrivileges: normalizePrebuiltStringArray(item.requiredSystemPrivileges || item.required_system_privileges),
      requiredParams: Array.isArray(item.requiredParams) ? item.requiredParams : [],
      optionalParams: Array.isArray(item.optionalParams) ? item.optionalParams : []
    };
  }

  function getPrebuiltAgentReadmeUrl(agent) {
    return String((agent && agent.readmeUrl) || "").trim();
  }

  function normalizePrebuiltDetailsSections(value) {
    if (!Array.isArray(value)) return [];
    return value.map(function(section) {
      var item = section && typeof section === "object" ? section : {};
      var body = item.body;
      var items = item.items;
      if (typeof body === "string") body = [body];
      if (!Array.isArray(body)) body = [];
      if (!Array.isArray(items)) items = [];
      return {
        title: String(item.title || item.heading || "").trim(),
        body: body.map(function(text) {
          return String(text == null ? "" : text).trim();
        }).filter(Boolean),
        items: items.map(function(text) {
          return String(text == null ? "" : text).trim();
        }).filter(Boolean)
      };
    }).filter(function(section) {
      return section.title || section.body.length || section.items.length;
    });
  }

  function normalizePrebuiltStringArray(value) {
    if (Array.isArray(value)) {
      return value.map(function(item) {
        return String(item == null ? "" : item).trim();
      }).filter(Boolean);
    }
    var text = String(value == null ? "" : value).trim();
    if (!text) return [];
    return text.split(/[,\n]/).map(function(item) {
      return String(item || "").trim();
    }).filter(Boolean);
  }

  function getPrebuiltAgentSubtitle(agent) {
    var explicit = String((agent && agent.subtitle) || "").trim();
    if (explicit) return explicit;
    var description = String((agent && agent.description) || "").trim();
    if (!description) return "Packaged Select AI agent";
    var firstSentence = description.split(/(?<=[.!?])\s+/)[0] || description;
    if (firstSentence.length > 110) firstSentence = firstSentence.substring(0, 107).trim() + "...";
    return firstSentence;
  }

  function getPrebuiltAgentIconMarkup(agent, viewMode) {
    var safeMode = String(viewMode || "card").toLowerCase() === "table" ? "table" : "card";
    var iconUrl = String((agent && agent.iconUrl) || "").trim();
    var fallback = "<span class='ao-prebuilt-agent-icon-fallback' aria-hidden='true'>" +
      "<span class='fa fa-cube'></span>" +
      "</span>";
    if (!iconUrl) return fallback;
    var name = String((agent && agent.name) || "Agent").trim();
    return "<img class='ao-prebuilt-agent-icon ao-prebuilt-agent-icon--" + safeMode + "' src='" + escapeAttr(iconUrl) + "' alt='" + escapeAttr(name + " icon") + "' loading='lazy' decoding='async' onerror=\"this.style.display='none';this.nextElementSibling&&this.nextElementSibling.classList.remove('is-hidden');\" />" +
      "<span class='ao-prebuilt-agent-icon-fallback is-hidden' aria-hidden='true'><span class='fa fa-cube'></span></span>";
  }

  function getPrebuiltAgentInitials(agent) {
    var stop = { ai: true, agent: true, select: true, oracle: true, oci: true };
    var words = String((agent && agent.name) || "").trim().split(/\s+/).filter(function(word) {
      return word && !stop[word.toLowerCase()];
    });
    if (!words.length) words = String((agent && agent.id) || "AI").split(/[-_]+/);
    return words.slice(0, 2).map(function(word) {
      return word.charAt(0).toUpperCase();
    }).join("") || "AI";
  }

  function getPrebuiltAgentById(agentId) {
    var id = String(agentId || "").trim();
    for (var i = 0; i < PREBUILT_AGENT_METADATA.length; i += 1) {
      if (PREBUILT_AGENT_METADATA[i].id === id) return PREBUILT_AGENT_METADATA[i];
    }
    return null;
  }

  function getPrebuiltAgentDisplayOrder(agent) {
    var order = Number(agent && agent.displayOrder);
    return isFinite(order) && order > 0 ? order : 1000;
  }

  function getPrebuiltAgentTeamName(agent) {
    var explicitTeamName = String(
      (agent && (agent.teamName || agent.agentTeamName || agent.team_name || agent.agent_team_name)) || ""
    ).trim();
    if (explicitTeamName) return explicitTeamName.toUpperCase();
    var id = String((agent && agent.id) || "").trim();
    if (!id) return "";
    return id.toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_+|_+$/g, "") + "_TEAM";
  }

  function getPrebuiltAgentTeamDisplayName(teamName) {
    var raw = String(teamName || "").trim();
    if (!raw) return "";
    var text = raw.replace(/_TEAM$/i, "").replace(/[_-]+/g, " ").toLowerCase();
    text = text.replace(/\b([a-z])/g, function(match) {
      return match.toUpperCase();
    });
    return text.replace(/\bOci\b/g, "OCI").replace(/\bNl2sql\b/g, "NL2SQL").replace(/\bPlsql\b/g, "PL/SQL");
  }

  function getPrebuiltAgentInstallSqlUrl(agent) {
    var explicitUrl = String((agent && agent.installSqlUrl) || "").trim();
    if (explicitUrl) return explicitUrl;

    var installSqlFile = String((agent && agent.installSqlFile) || "").trim();
    if (/^https?:\/\//i.test(installSqlFile)) return installSqlFile;

    var repoUrl = String((agent && agent.repoUrl) || "").trim();
    if (!repoUrl || !/^https?:\/\//i.test(repoUrl) || !installSqlFile) return "";

    var fileName = installSqlFile.split(/[\\/]/).pop();
    return repoUrl.replace(/\/?$/, "/") + fileName;
  }

  function getCurrentAppSchema() {
    var value = String(
      (LAST_BOOTSTRAP_DATA && (LAST_BOOTSTRAP_DATA.schema_owner || LAST_BOOTSTRAP_DATA.app_schema || LAST_BOOTSTRAP_DATA.appSchema)) || ""
    ).trim();
    if (value) return value.toUpperCase();
    try {
      if (window.apex && typeof apex.item === "function") {
        var item = apex.item("P0_APP_SCHEMA");
        if (item && typeof item.getValue === "function") value = String(item.getValue() || "").trim();
      }
    } catch (e) {}
    return value ? value.toUpperCase() : "";
  }

  function getPrebuiltParamHelpText(param) {
    var cfg = param && typeof param === "object" ? param : {};
    var explicit = String(cfg.helpText || cfg.help_text || cfg.help || cfg.description || "").trim();
    if (explicit) return explicit;
    var name = String(cfg.name || "").trim().toLowerCase();
    var label = String(cfg.label || cfg.name || "parameter").trim();
    var defaultHelpByName = {
      schema: "Fixed to the current Ask Oracle application schema. Pre-built agents install their database objects and agent team in this schema.",
      ai_profile: "Select AI profile used by the agent when it reasons, generates SQL, or calls AI services.",
      use_resource_principal: "Choose true when the database should call OCI using resource principal authentication instead of a stored credential.",
      credential_name: "Credential name saved for this agent. Check the agent setup notes for the provider-specific credential setup.",
      compartment_name: "Optional default OCI compartment name. Saved in SELECTAI_AGENT_CONFIG so users do not need to provide it on every request.",
      compartment_ocid: "Optional default OCI compartment OCID. Saved in SELECTAI_AGENT_CONFIG so users do not need to provide it on every request.",
      vault_region: "OCI region used for Vault secret lookups.",
      api_key_vault_secret_ocid: "Vault secret OCID containing the external API key used by the agent.",
      cxid_vault_secret_ocid: "Vault secret OCID containing the Google Custom Search engine id used by web search.",
      provider: "Select one repository provider for this configuration.",
      default_owner: "Default repository owner or organization used when the prompt does not specify one.",
      default_repo: "Default repository name used when the prompt does not specify one.",
      default_branch: "Default branch used when the prompt does not specify one.",
      aws_region: "AWS region used for AWS CodeCommit repositories.",
      azure_organization: "Azure DevOps organization used for Azure Repos.",
      azure_project: "Azure DevOps project used for Azure Repos.",
      cloud_id: "Atlassian Jira Cloud ID for the Jira site this agent should query.",
      scope_mode: "Controls whether Database Inspect indexes full schemas, selected tables, or selected packages.",
      scope_owners: "Schema owners to inspect when the scope is Schemas.",
      object_owner: "Schema that owns the tables or packages selected for inspection.",
      object_names: "Comma-separated table or package names to inspect.",
      match_limit: "Maximum number of metadata matches the agent can retrieve for a question.",
      team_attributes_json: "Advanced Database Inspect team attributes. Use this to mix schema, table, and package scopes in one install.",
      recreate_existing: "Controls whether an existing agent team is kept or rebuilt."
    };
    return defaultHelpByName[name] || "Installer parameter for " + label + ".";
  }

  function renderPrebuiltParamLabel(fieldId, label, required, helpText) {
    var html = "<div class='ao-prebuilt-label-row'>";
    html += "<label for='" + escapeAttr(fieldId) + "'>" + apex.util.escapeHTML(label);
    if (required) html += " <span class='ao-prebuilt-required'>*</span>";
    html += "</label>";
    html += "</div>";
    return html;
  }

  function isPrebuiltAiProfileParam(name, type) {
    var paramName = String(name || "").trim().toLowerCase();
    var paramType = String(type || "").trim().toLowerCase();
    return paramType === "profile" ||
      paramType === "ai_profile" ||
      paramName === "ai_profile";
  }

  function getPrebuiltVisibleWhen(param) {
    var cfg = param && typeof param === "object" ? param : {};
    var rule = cfg.visibleWhen || cfg.visible_when || null;
    if (!rule || typeof rule !== "object") return null;
    var paramName = String(rule.param || rule.name || rule.field || "").trim();
    var values = rule.values || rule.value;
    if (!paramName) return null;
    if (!Array.isArray(values)) values = values == null ? [] : [values];
    values = values.map(function(value) {
      return String(value == null ? "" : value).trim();
    }).filter(Boolean);
    return { param: paramName, values: values };
  }

  function getPrebuiltAgentEffectiveStatus(agent) {
    var id = String((agent && agent.id) || "").trim();
    var baseStatus = normalizePrebuiltAgentStatus(agent && agent.status);
    var state = id ? (PREBUILT_AGENT_STATE[id] || {}) : {};
    var stateStatus = normalizePrebuiltAgentStatus(state.status || "");
    var installedVersion = String(state.installedVersion || state.version || "").trim();
    var metadataVersion = String((agent && agent.version) || "").trim();

    if (getPrebuiltSupportWarning(agent)) return "unsupported";
    if (stateStatus === "install_error") return "install_error";
    if (PREBUILT_AGENT_BOOTSTRAP_SYNCED && stateStatus === "not_installed") return "not_installed";
    if (stateStatus === "installing") return "installing";
    if (stateStatus === "installed" || stateStatus === "update_available") {
      if (installedVersion && metadataVersion && installedVersion !== metadataVersion) return "update_available";
      return stateStatus === "update_available" ? "update_available" : "installed";
    }
    if (baseStatus === "installed" || baseStatus === "update_available") return baseStatus;
    return "not_installed";
  }

  function getPrebuiltStatusLabel(status) {
    var normalized = normalizePrebuiltAgentStatus(status);
    if (normalized === "installed") return "Installed";
    if (normalized === "installing") return "Installing";
    if (normalized === "update_available") return "Update available";
    if (normalized === "unsupported") return "Unsupported";
    if (normalized === "install_error") return "Installation error";
    return "Not installed";
  }

  function getDatabaseMajorVersion() {
    var version = Number(LAST_BOOTSTRAP_DATA && LAST_BOOTSTRAP_DATA.database_major_version);
    return isFinite(version) && version > 0 ? version : 0;
  }

  function getPrebuiltSupportWarning(agent) {
    var minVersion = Number(agent && agent.minDatabaseMajorVersion);
    var currentVersion = getDatabaseMajorVersion();
    var exactVersions = Array.isArray(agent && agent.supportedDatabaseMajorVersions) ? agent.supportedDatabaseMajorVersions : [];
    if (!currentVersion) return "";
    if (exactVersions.length && exactVersions.indexOf(currentVersion) < 0) {
      return (agent && agent.supportNote) ||
        ((agent && agent.name ? agent.name : "This agent") + " requires " +
          String((agent && agent.supportedDatabaseVersions) || ("Oracle Database " + exactVersions.join(" or "))).trim() +
          ". Current database major version is " + currentVersion + ".");
    }
    if (!isFinite(minVersion) || minVersion <= 0 || currentVersion >= minVersion) return "";
    var supported = String((agent && agent.supportedDatabaseVersions) || ("Oracle Database " + minVersion + " or later")).trim();
    return (agent && agent.supportNote) ||
      ((agent && agent.name ? agent.name : "This agent") + " requires " + supported + ". Current database major version is " + currentVersion + ".");
  }

  function normalizePrebuiltJobStatus(value) {
    return String(value || "").trim().toUpperCase();
  }

  function getPrebuiltJobMessage(job) {
    return String(
      (job && (job.error_message || job.status_message || job.current_step)) || ""
    ).trim();
  }

  function isPrebuiltJobBlocked(job) {
    var step = normalizePrebuiltJobStatus(job && job.current_step);
    var message = getPrebuiltJobMessage(job).toUpperCase();
    return step === "PRECHECK_TEAM_EXISTS" ||
      (message.indexOf("AGENT TEAM ALREADY EXISTS") >= 0 && message.indexOf("RECREATE_EXISTING") >= 0);
  }

  function isPrebuiltJobSucceeded(job) {
    var status = normalizePrebuiltJobStatus(job && job.status);
    var step = normalizePrebuiltJobStatus(job && job.current_step);
    return status === "SUCCEEDED" || status === "SUCCESS" || step === "SUCCEEDED" || step === "SUCCESS";
  }

  function getPrebuiltInstallingMessage(job) {
    return getPrebuiltJobMessage(job) ||
      "Still installing. Metadata vectorizing is still going on. Please wait before running this agent.";
  }

  function getPrebuiltAgentStatusMessage(agent, status, state) {
    var supportWarning = getPrebuiltSupportWarning(agent);
    if (supportWarning) return supportWarning;
    if (status === "install_error") {
      return String((state && state.installStatusMessage) || "").trim() ||
        "Installation failed. Check the agent install job log for details.";
    }
    if (status === "installing") {
      return "Installing in background" +
        (state && state.installStatusMessage ? ": " + state.installStatusMessage : ".");
    }
    return "";
  }

  function isPrebuiltJobInstalling(job) {
    var status = normalizePrebuiltJobStatus(job && job.status);
    var step = normalizePrebuiltJobStatus(job && job.current_step);
    if (isPrebuiltJobBlocked(job) || step === "JOB_SUBMISSION_FAILED") return false;
    return status === "PRECHECK" || status === "QUEUED" || status === "RUNNING";
  }

  function isPrebuiltJobFailed(job) {
    var status = normalizePrebuiltJobStatus(job && job.status);
    var step = normalizePrebuiltJobStatus(job && job.current_step);
    return isPrebuiltJobBlocked(job) ||
      status === "FAILED" ||
      status === "FAILED_TO_QUEUE" ||
      step === "JOB_SUBMISSION_FAILED";
  }

  function getPrebuiltLatestJobByAgent(data) {
    var jobs = {};
    ((data && data.prebuilt_agent_jobs) || []).forEach(function(job) {
      var agentId = String((job && job.agent_id) || "").trim();
      if (!agentId || jobs[agentId]) return;
      jobs[agentId] = job;
    });
    return jobs;
  }

  function refreshPrebuiltAgentInstallStateFromBootstrap(data) {
    var rows = (data && data.agent_teams) || [];
    var jobsByAgent = getPrebuiltLatestJobByAgent(data);
    var names = {};
    rows.forEach(function(row) {
      var value = String((row && (row.r || row.d)) || "").trim().toUpperCase();
      if (value) names[value] = true;
    });

    PREBUILT_AGENT_BOOTSTRAP_SYNCED = true;
    PREBUILT_AGENT_METADATA.forEach(function(agent) {
      var teamName = getPrebuiltAgentTeamName(agent);
      var existing = PREBUILT_AGENT_STATE[agent.id] || {};
      var existingStatus = normalizePrebuiltAgentStatus(existing.status || "");
      var latestJob = jobsByAgent[agent.id] || null;
      if (agent.backgroundInstall && latestJob && !isPrebuiltJobSucceeded(latestJob)) {
        if (isPrebuiltJobFailed(latestJob)) {
          PREBUILT_AGENT_STATE[agent.id] = $.extend({}, existing, {
            status: "install_error",
            installStatus: String(latestJob.status || latestJob.current_step || "FAILED"),
            installStatusMessage: getPrebuiltJobMessage(latestJob) || "Background installation failed.",
            installedVersion: ""
          });
        } else {
          PREBUILT_AGENT_STATE[agent.id] = $.extend({}, existing, {
            status: "installing",
            installStatus: String(latestJob.status || latestJob.current_step || ""),
            installStatusMessage: getPrebuiltInstallingMessage(latestJob),
            installedVersion: ""
          });
        }
        return;
      }
      if (!teamName || !names[teamName]) {
        if (latestJob && isPrebuiltJobInstalling(latestJob)) {
          PREBUILT_AGENT_STATE[agent.id] = $.extend({}, existing, {
            status: "installing",
            installStatus: String(latestJob.status || ""),
            installStatusMessage: getPrebuiltInstallingMessage(latestJob),
            installedVersion: ""
          });
          return;
        }
        if (latestJob && isPrebuiltJobFailed(latestJob)) {
          PREBUILT_AGENT_STATE[agent.id] = $.extend({}, existing, {
            status: "install_error",
            installStatus: String(latestJob.status || latestJob.current_step || "FAILED"),
            installStatusMessage: getPrebuiltJobMessage(latestJob) || "Background installation failed.",
            installedVersion: ""
          });
          return;
        }
        if (existingStatus === "installing") {
          PREBUILT_AGENT_STATE[agent.id] = $.extend({}, existing, {
            status: "not_installed",
            installStatus: "",
            installStatusMessage: "",
            installedVersion: ""
          });
          return;
        }
        if (existingStatus === "installed" || existingStatus === "update_available") {
          PREBUILT_AGENT_STATE[agent.id] = $.extend({}, existing, {
            status: "not_installed",
            installedVersion: ""
          });
        }
        return;
      }
      PREBUILT_AGENT_STATE[agent.id] = $.extend({}, existing, {
        status: "installed",
        installStatus: latestJob ? String(latestJob.status || "SUCCEEDED") : "",
        installStatusMessage: latestJob ? String(latestJob.status_message || "") : "",
        installedVersion: String(existing.installedVersion || agent.version || "").trim()
      });
    });
    persistPrebuiltAgentState();
  }

  function renderPrebuiltProfileDatalist() {
    var html = "";
    (ALL_PROFILE_OPTIONS || []).forEach(function(row) {
      var value = String((row && (row.r || row.d)) || "").trim();
      if (!value) return;
      html += "<option value='" + escapeAttr(value) + "'></option>";
    });
    $("#aoPrebuiltAgentAiProfileOptions").html(html);
  }

  function renderPrebuiltAgents() {
    var $grid = $("#aoPrebuiltAgentGrid");
    var $empty = $("#aoPrebuiltAgentEmpty");
    if (!$grid.length) return;

    var query = String($("#aoPrebuiltAgentSearch").val() || "").trim().toLowerCase();
    var filter = normalizePrebuiltAgentStatus($("#aoPrebuiltAgentFilter").val() || "all");
    if ($("#aoPrebuiltAgentFilter").val() === "all") filter = "all";

    var shown = [];
    PREBUILT_AGENT_METADATA.forEach(function(agent) {
      var status = getPrebuiltAgentEffectiveStatus(agent);
      var haystack = [agent.name, agent.id, agent.description].join(" ").toLowerCase();
      if (query && haystack.indexOf(query) < 0) return;
      if (filter !== "all" && status !== filter) return;
      shown.push({ agent: agent, status: status });
    });
    shown.sort(function(a, b) {
      var orderA = getPrebuiltAgentDisplayOrder(a.agent);
      var orderB = getPrebuiltAgentDisplayOrder(b.agent);
      if (orderA !== orderB) return orderA - orderB;
      return String(a.agent.name || "").localeCompare(String(b.agent.name || ""));
    });

    var isTableView = PREBUILT_AGENT_VIEW_MODE === "table";
    $grid.toggleClass("ao-prebuilt-grid--table", isTableView);

    if (!PREBUILT_AGENT_METADATA.length) {
      $grid.html("<div class='ao-muted-box'>No prebuilt agent metadata found.</div>");
      $empty.addClass("is-hidden");
      return;
    }

    function buildPrebuiltActionButtonsHtml(agent, status) {
      var isInstalled = status === "installed" || status === "update_available";
      var isInstalling = status === "installing";
      var isUnsupported = status === "unsupported";
      var canUpdate = status === "update_available";
      var actionsHtml = "";
      var compact = isTableView === true;

      function actionText(action, label) {
        if (!compact) return label;
        var iconByAction = {
          edit: "fa-sliders-h",
          install: "fa-download",
          update: "fa-sync-alt",
          recreate: "fa-redo",
          uninstall: "fa-trash-alt",
          unsupported: "fa-ban",
          installing: "fa-spinner fa-spin"
        };
        var icon = iconByAction[action] || "fa-circle";
        return "<span class='fa " + icon + "' aria-hidden='true'></span><span>" + apex.util.escapeHTML(label) + "</span>";
      }

      if (isUnsupported) {
        actionsHtml += "<button type='button' class='t-Button ao-prebuilt-action-btn ao-prebuilt-action-btn--neutral' disabled>" + actionText("unsupported", "Unsupported") + "</button>";
      } else if (isInstalling) {
        actionsHtml += "<button type='button' class='t-Button ao-prebuilt-action-btn ao-prebuilt-action-btn--neutral' disabled>" + actionText("installing", "Installing") + "</button>";
      } else if (isInstalled) {
        if (canUpdate) {
          actionsHtml += "<button type='button' class='t-Button t-Button--hot ao-prebuilt-action-btn ao-prebuilt-action-btn--primary ao-admin-only' data-prebuilt-action='update' data-agent-id='" + escapeAttr(agent.id) + "'>" + actionText("update", "Update") + "</button>";
        } else {
          actionsHtml += "<button type='button' class='t-Button ao-prebuilt-action-btn ao-prebuilt-action-btn--secondary ao-admin-only' data-prebuilt-action='edit' data-agent-id='" + escapeAttr(agent.id) + "'>" + actionText("edit", "Edit") + "</button>";
        }
        actionsHtml += "<button type='button' class='t-Button ao-prebuilt-action-btn ao-prebuilt-action-btn--danger-subtle ao-admin-only' data-prebuilt-action='uninstall' data-agent-id='" + escapeAttr(agent.id) + "'>" + actionText("uninstall", "Uninstall") + "</button>";
      } else {
        actionsHtml += "<button type='button' class='t-Button t-Button--hot ao-prebuilt-action-btn ao-prebuilt-action-btn--primary ao-admin-only' data-prebuilt-action='install' data-agent-id='" + escapeAttr(agent.id) + "'>" + actionText("install", "Install") + "</button>";
      }
      return actionsHtml;
    }

    var html = "";
    if (isTableView) {
      html += "<div class='ao-prebuilt-table-wrap'><table class='ao-prebuilt-table'><thead><tr>";
      html += "<th>Agent</th>";
      html += "<th>Version</th>";
      html += "<th>Team</th>";
      html += "<th>Status</th>";
      html += "<th>Actions</th>";
      html += "</tr></thead><tbody>";

      shown.forEach(function(item) {
        var agent = item.agent;
        var status = item.status;
        var subtitle = getPrebuiltAgentSubtitle(agent);
        var teamName = getPrebuiltAgentTeamName(agent);
        var state = PREBUILT_AGENT_STATE[agent.id] || {};
        var statusMessage = getPrebuiltAgentStatusMessage(agent, status, state);

        html += "<tr data-prebuilt-agent-id='" + escapeAttr(agent.id) + "'>";
        html += "<td><div class='ao-prebuilt-table__agent-cell'>";
        html += "<span class='ao-prebuilt-agent-icon-wrap ao-prebuilt-agent-icon-wrap--table'>" + getPrebuiltAgentIconMarkup(agent, "table") + "</span>";
        html += "<span class='ao-prebuilt-table__agent-meta'><div class='ao-prebuilt-table__title'>" + apex.util.escapeHTML(agent.name) + "</div>";
        html += "<div class='ao-prebuilt-table__subtitle'>" + apex.util.escapeHTML(subtitle) + "</div>";
        html += "<button type='button' class='ao-prebuilt-link-btn' data-prebuilt-info='" + escapeAttr(agent.id) + "'>More details</button></span></div></td>";
        html += "<td><span class='ao-prebuilt-table__meta'>" + apex.util.escapeHTML(agent.version) + "</span></td>";
        html += "<td><span class='ao-prebuilt-table__meta'>" + apex.util.escapeHTML(getPrebuiltAgentTeamDisplayName(teamName)) + "</span></td>";
        html += "<td><span class='ao-prebuilt-badge ao-prebuilt-badge--" + escapeAttr(status) + "'>" + apex.util.escapeHTML(getPrebuiltStatusLabel(status)) + "</span>";
        if (statusMessage) {
          html += "<div class='ao-prebuilt-table__subtitle'>" + apex.util.escapeHTML(statusMessage) + "</div>";
        }
        html += "</td>";
        html += "<td><div class='ao-prebuilt-card__actions'>" + buildPrebuiltActionButtonsHtml(agent, status) + "</div></td>";
        html += "</tr>";
      });

      html += "</tbody></table></div>";
    } else {
      shown.forEach(function(item) {
        var agent = item.agent;
        var status = item.status;
        var subtitle = getPrebuiltAgentSubtitle(agent);
        var state = PREBUILT_AGENT_STATE[agent.id] || {};
        var statusMessage = getPrebuiltAgentStatusMessage(agent, status, state);
        var isProblemStatus = status === "install_error" || status === "unsupported";
        html += "<article class='ao-card ao-prebuilt-card' data-prebuilt-agent-id='" + escapeAttr(agent.id) + "' data-prebuilt-open='" + escapeAttr(agent.id) + "' role='button' tabindex='0' aria-label='Open details for " + escapeAttr(agent.name) + "'>";
        html += "<div class='ao-prebuilt-card__title-row'><span class='ao-prebuilt-agent-icon-wrap ao-prebuilt-agent-icon-wrap--card'>" + getPrebuiltAgentIconMarkup(agent, "card") + "</span><h4 class='ao-prebuilt-card__title'>" + apex.util.escapeHTML(agent.name) + "</h4></div>";
        html += "<p class='ao-prebuilt-card__subtitle'>" + apex.util.escapeHTML(subtitle) + "</p>";
        html += "<div class='ao-prebuilt-card__status'><span class='ao-prebuilt-badge ao-prebuilt-badge--" + escapeAttr(status) + "'>" + apex.util.escapeHTML(getPrebuiltStatusLabel(status)) + "</span></div>";
        if (statusMessage) {
          html += "<div class='ao-prebuilt-card__notice" + (isProblemStatus ? " ao-prebuilt-card__notice--warning" : "") + "'>" + apex.util.escapeHTML(statusMessage) + "</div>";
        }
        html += "<div class='ao-prebuilt-card__actions'>";
        html += buildPrebuiltActionButtonsHtml(agent, status);
        html += "</div>";
        html += "</article>";
      });
    }

    $grid.html(html || "");
    $empty.toggleClass("is-hidden", shown.length > 0);
    applyAdminVisibility(IS_ADMIN_USER, USER_ROLE);
  }

  function ensurePrebuiltInfoDialog() {
    var $existingDialog = $("#aoPrebuiltInfoDialog");
    if ($existingDialog.length) {
      if (!$("#aoPrebuiltInfoReadme").length) {
        $existingDialog.find(".ao-prebuilt-dialog__actions").first().prepend(
          "<a id='aoPrebuiltInfoReadme' class='t-Button is-hidden' href='#' target='_blank' rel='noopener noreferrer'>View GitHub README</a>"
        );
      }
      return;
    }
    $("body").append(
      "<div id='aoPrebuiltInfoDialog' class='ao-prebuilt-dialog ao-prebuilt-info-dialog is-hidden' role='dialog' aria-modal='true' aria-labelledby='aoPrebuiltInfoTitle'>" +
        "<div class='ao-prebuilt-dialog__backdrop' data-prebuilt-info-close='true'></div>" +
        "<div class='ao-prebuilt-dialog__card ao-prebuilt-dialog__card--info' role='document'>" +
          "<div class='ao-prebuilt-dialog__header'>" +
            "<div>" +
              "<h3 id='aoPrebuiltInfoTitle'>Agent details</h3>" +
              "<p id='aoPrebuiltInfoSubtitle'></p>" +
            "</div>" +
            "<button type='button' class='ao-prebuilt-dialog__close' data-prebuilt-info-close='true' aria-label='Close'>×</button>" +
          "</div>" +
          "<div id='aoPrebuiltInfoBody' class='ao-prebuilt-info-body'></div>" +
          "<div class='ao-prebuilt-dialog__actions'>" +
            "<a id='aoPrebuiltInfoReadme' class='t-Button is-hidden' href='#' target='_blank' rel='noopener noreferrer'>View GitHub README</a>" +
            "<button type='button' class='t-Button t-Button--hot' data-prebuilt-info-close='true'>Done</button>" +
          "</div>" +
        "</div>" +
      "</div>"
    );
  }

  function renderPrebuiltParamList(params) {
    var rows = Array.isArray(params) ? params : [];
    if (!rows.length) return "<span class='ao-muted-inline'>None</span>";
    return rows.map(function(param) {
      var name = String((param && param.name) || "").trim();
      var label = String((param && param.label) || name).trim();
      if (!name && !label) return "";
      return "<span class='ao-prebuilt-pill'>" + apex.util.escapeHTML(label || name) + "</span>";
    }).join("");
  }

  function renderPrebuiltStringPills(values) {
    var rows = normalizePrebuiltStringArray(values);
    if (!rows.length) return "<span class='ao-muted-inline'>None</span>";
    return rows.map(function(value) {
      return "<span class='ao-prebuilt-pill'>" + apex.util.escapeHTML(value) + "</span>";
    }).join("");
  }

  function renderPrebuiltDetailsSections(agent) {
    var sections = Array.isArray(agent && agent.detailsSections) ? agent.detailsSections : [];
    if (!sections.length) {
      return "<p class='ao-prebuilt-info-description'>" + apex.util.escapeHTML((agent && agent.description) || "No description provided.") + "</p>";
    }
    return sections.map(function(section) {
      var html = "<div class='ao-prebuilt-info-section ao-prebuilt-info-section--readme'>";
      if (section.title) {
        html += "<h4>" + apex.util.escapeHTML(section.title) + "</h4>";
      }
      section.body.forEach(function(text) {
        html += "<p>" + apex.util.escapeHTML(text) + "</p>";
      });
      if (section.items.length) {
        html += "<ul>";
        section.items.forEach(function(text) {
          html += "<li>" + apex.util.escapeHTML(text) + "</li>";
        });
        html += "</ul>";
      }
      html += "</div>";
      return html;
    }).join("");
  }

  function openPrebuiltAgentInfo(agent) {
    if (!agent) return;
    ensurePrebuiltInfoDialog();
    var status = getPrebuiltAgentEffectiveStatus(agent);
    var html = "";
    html += "<div class='ao-prebuilt-info-meta'>";
    html += "<span>Version " + apex.util.escapeHTML(agent.version) + "</span>";
    html += "<span>" + apex.util.escapeHTML(getPrebuiltStatusLabel(status)) + "</span>";
    html += "<span>" + apex.util.escapeHTML(agent.category || "AI Agent as a Service") + "</span>";
    html += "</div>";
    html += renderPrebuiltDetailsSections(agent);
    if (agent.supportNote) {
      html += "<div class='ao-prebuilt-info-section'><h4>Database support</h4><p class='ao-prebuilt-info-note'>" + apex.util.escapeHTML(agent.supportNote) + "</p></div>";
    }
    if (agent.installNote) {
      html += "<div class='ao-prebuilt-info-section'><h4>Install timing</h4><p class='ao-prebuilt-info-note'>" + apex.util.escapeHTML(agent.installNote) + "</p></div>";
    }
    html += "<div class='ao-prebuilt-info-section'><h4>Required inputs</h4><div class='ao-prebuilt-pill-row'>" + renderPrebuiltParamList(agent.requiredParams) + "</div></div>";
    html += "<div class='ao-prebuilt-info-section'><h4>Optional inputs</h4><div class='ao-prebuilt-pill-row'>" + renderPrebuiltParamList(agent.optionalParams) + "</div></div>";
    if ((agent.requiredObjectPrivileges || []).length) {
      html += "<div class='ao-prebuilt-info-section'><h4>Prerequisite object grants</h4><div class='ao-prebuilt-pill-row'>" + renderPrebuiltStringPills(agent.requiredObjectPrivileges) + "</div></div>";
    }
    $("#aoPrebuiltInfoTitle").text(agent.name);
    $("#aoPrebuiltInfoSubtitle").text(getPrebuiltAgentSubtitle(agent));
    $("#aoPrebuiltInfoBody").html(html);
    var readmeUrl = getPrebuiltAgentReadmeUrl(agent);
    $("#aoPrebuiltInfoReadme")
      .attr("href", readmeUrl || "#")
      .toggleClass("is-hidden", !readmeUrl);
    $("#aoPrebuiltInfoDialog").removeClass("is-hidden");
  }

  function closePrebuiltAgentInfo() {
    $("#aoPrebuiltInfoDialog").addClass("is-hidden");
  }

  function ensurePrebuiltGrantDialog() {
    if ($("#aoPrebuiltGrantDialog").length) return;
    $("body").append(
      "<div id='aoPrebuiltGrantDialog' class='ao-prebuilt-dialog ao-prebuilt-grant-dialog is-hidden' role='dialog' aria-modal='true' aria-labelledby='aoPrebuiltGrantTitle'>" +
        "<div class='ao-prebuilt-dialog__backdrop' data-prebuilt-grant-close='true'></div>" +
        "<div class='ao-prebuilt-dialog__card ao-prebuilt-dialog__card--grant' role='document'>" +
          "<div class='ao-prebuilt-dialog__header'>" +
            "<div>" +
              "<h3 id='aoPrebuiltGrantTitle'>Prerequisite grants required</h3>" +
              "<p id='aoPrebuiltGrantCopy'>Ask an administrator to run these grants before continuing.</p>" +
            "</div>" +
            "<button type='button' class='ao-prebuilt-dialog__close' data-prebuilt-grant-close='true' aria-label='Close'>×</button>" +
          "</div>" +
          "<div class='ao-prebuilt-grant-body'>" +
            "<div id='aoPrebuiltGrantSummary' class='ao-prebuilt-grant-summary'></div>" +
            "<pre id='aoPrebuiltGrantSql' class='ao-prebuilt-grant-sql'></pre>" +
          "</div>" +
          "<div class='ao-prebuilt-dialog__actions ao-prebuilt-dialog__actions--split'>" +
            "<button id='aoPrebuiltGrantCopySql' type='button' class='t-Button'>Copy grants</button>" +
            "<span class='ao-prebuilt-dialog__action-spacer'></span>" +
            "<button type='button' class='t-Button' data-prebuilt-grant-close='true'>Cancel</button>" +
            "<button id='aoPrebuiltGrantContinue' type='button' class='t-Button t-Button--hot'>I have applied grants, continue</button>" +
          "</div>" +
        "</div>" +
      "</div>"
    );
  }

  function getPrebuiltGrantStatementsFromResult(result) {
    var grants = [];
    var rows = (result && result.missing_grants) || [];
    rows.forEach(function(row) {
      var statement = String((row && (row.grant_sql || row.statement)) || "").trim();
      if (statement) grants.push(statement.replace(/;?\s*$/, ";"));
    });
    return grants;
  }

  function openPrebuiltGrantDialog(agent, params, action, result) {
    ensurePrebuiltGrantDialog();
    var grants = getPrebuiltGrantStatementsFromResult(result);
    PREBUILT_AGENT_PENDING_GRANT_INSTALL = {
      agentId: agent && agent.id,
      params: $.extend({}, params || {}),
      action: action
    };
    $("#aoPrebuiltGrantTitle").text("Prerequisite grants for " + ((agent && agent.name) || "agent"));
    $("#aoPrebuiltGrantCopy").text("These grants were not verified for the target schema. Run them as ADMIN, then continue the install.");
    $("#aoPrebuiltGrantSummary").html(
      "<strong>Target schema:</strong> " + apex.util.escapeHTML((params && params.schema) || "") +
      "<br><strong>Missing or unverified grants:</strong> " + grants.length
    );
    $("#aoPrebuiltGrantSql").text(grants.join("\n"));
    $("#aoPrebuiltGrantDialog").removeClass("is-hidden");
  }

  function closePrebuiltGrantDialog() {
    PREBUILT_AGENT_PENDING_GRANT_INSTALL = null;
    $("#aoPrebuiltGrantDialog").addClass("is-hidden");
  }

  function getPrebuiltMetadataUrl() {
    var candidates = [];
    try { candidates.push(window.ASK_ORACLE_PREBUILT_AGENTS_METADATA_URL); } catch (e1) {}
    try {
      candidates.push(window.ASK_ORACLE_ADMIN_CONFIG && window.ASK_ORACLE_ADMIN_CONFIG.PREBUILT_AGENTS_METADATA_URL);
    } catch (e2) {}
    try {
      if (window.apex && typeof apex.item === "function") {
        var item = apex.item("P20000_PREBUILT_AGENTS_METADATA_URL");
        if (item && typeof item.getValue === "function") candidates.push(item.getValue());
      }
    } catch (e3) {}
    candidates.push($("#aoPrebuiltAgentsPanel").attr("data-metadata-url"));

    for (var i = 0; i < candidates.length; i += 1) {
      var url = String(candidates[i] == null ? "" : candidates[i]).trim();
      if (!url) continue;
      if (/^#.*#$/.test(url) || /^&[A-Z0-9_]+\.$/i.test(url)) continue;
      return url;
    }
    return "";
  }

  function loadPrebuiltAgentMetadata() {
    if (!$("#aoPrebuiltAgentGrid").length) return;
    var metadataUrl = getPrebuiltMetadataUrl();
    PREBUILT_AGENT_STATE = getPrebuiltAgentState();
    if (!metadataUrl) {
      PREBUILT_AGENT_METADATA = [];
      $("#aoPrebuiltAgentGrid").html(
        "<div class='ao-muted-box'>Set the Object Storage metadata.json URL in window.ASK_ORACLE_PREBUILT_AGENTS_METADATA_URL, ASK_ORACLE_ADMIN_CONFIG.PREBUILT_AGENTS_METADATA_URL, page item P20000_PREBUILT_AGENTS_METADATA_URL, or data-metadata-url.</div>"
      );
      $("#aoPrebuiltAgentEmpty").addClass("is-hidden");
      return;
    }

    $("#aoPrebuiltAgentGrid").html("<div class='ao-muted-box'>Loading prebuilt agents...</div>");

    $.ajax({
      url: metadataUrl,
      dataType: "json",
      cache: false
    }).done(function(data) {
      PREBUILT_AGENT_METADATA = (Array.isArray(data) ? data : []).map(normalizePrebuiltAgent).filter(function(agent) {
        return !!agent.id;
      });
      refreshPrebuiltAgentInstallStateFromBootstrap(LAST_BOOTSTRAP_DATA || {});
      renderPrebuiltAgents();
    }).fail(function(xhr) {
      PREBUILT_AGENT_METADATA = [];
      $("#aoPrebuiltAgentGrid").html(
        "<div class='ao-muted-box'>Unable to load metadata.json from Object Storage. Verify the URL and CORS access for this APEX app.</div>"
      );
      debugSettingsLog("prebuilt metadata load failed", {
        url: metadataUrl,
        status: xhr && xhr.status,
        responseText: xhr && xhr.responseText
      });
    });
  }

  function renderPrebuiltParamField(param, value) {
    var cfg = param && typeof param === "object" ? param : {};
    var name = String(cfg.name || "").trim();
    if (!name) return "";
    var label = String(cfg.label || name).trim();
    var type = String(cfg.type || "string").trim().toLowerCase();
    var required = cfg.required === true;
    var placeholder = String(cfg.placeholder || "").trim();
    var helpText = getPrebuiltParamHelpText(cfg);
    var options = Array.isArray(cfg.options) ? cfg.options : [];
    var currentValue = String(value == null ? "" : value);
    var fieldId = "aoPrebuiltParam_" + name.replace(/[^A-Za-z0-9_]/g, "_");
    var isSchemaParam = name.toLowerCase() === "schema";
    var isReadOnlyParam = isSchemaParam || cfg.readOnly === true || cfg.readonly === true;
    var isAiProfileParam = isPrebuiltAiProfileParam(name, type);
    var configKey = String(cfg.configKey || cfg.config_key || cfg.storageKey || cfg.storage_key || "").trim();
    var visibleWhen = getPrebuiltVisibleWhen(cfg);
    var visibleAttrs = visibleWhen
      ? " data-visible-param='" + escapeAttr(visibleWhen.param) + "' data-visible-values='" + escapeAttr(visibleWhen.values.join("|")) + "'"
      : "";
    var wideClass = name.length > 28 || /ocid|json|description/i.test(name) ? " ao-prebuilt-dialog__field--wide" : "";
    var fixedClass = isReadOnlyParam ? " ao-prebuilt-dialog__field--fixed" : "";
    var configKeyAttr = configKey ? " data-config-key='" + escapeAttr(configKey) + "'" : "";
    var html = "<div class='ao-prebuilt-dialog__field" + wideClass + fixedClass + "'" + visibleAttrs + configKeyAttr + ">";
    if (isAiProfileParam && ALL_PROFILE_OPTIONS && ALL_PROFILE_OPTIONS.length) {
      html += renderPrebuiltParamLabel(fieldId, label, required, helpText);
      html += "<select id='" + escapeAttr(fieldId) + "' class='ao-input js-ao-prebuilt-param' data-param-name='" + escapeAttr(name) + "'" + (required ? " data-required='true'" : "") + ">";
      html += "<option value=''>" + (required ? "- Select AI Profile -" : "- Optional -") + "</option>";
      (ALL_PROFILE_OPTIONS || []).forEach(function(row) {
        var optionValue = String((row && (row.r || row.d)) || "").trim();
        var optionLabel = String((row && (row.d || row.r)) || optionValue).trim();
        if (!optionValue) return;
        html += "<option value='" + escapeAttr(optionValue) + "'" + (currentValue === optionValue ? " selected" : "") + ">" + apex.util.escapeHTML(optionLabel || optionValue) + "</option>";
      });
      html += "</select>";
      if (helpText) html += "<div class='ao-prebuilt-field-help'>" + apex.util.escapeHTML(helpText) + "</div>";
    } else if (type === "checkbox") {
      html += "<label class='ao-prebuilt-checkline'>";
      html += "<input id='" + escapeAttr(fieldId) + "' class='js-ao-prebuilt-param' type='checkbox' value='true' data-param-name='" + escapeAttr(name) + "'" + (required ? " data-required='true'" : "") + " data-required-value='" + escapeAttr(cfg.requiredValue || "") + "'" + (currentValue === "true" ? " checked" : "") + " />";
      html += "<span>" + apex.util.escapeHTML(label) + (required ? " <span class='ao-prebuilt-required'>*</span>" : "") + "</span>";
      html += "</label>";
      if (helpText) html += "<div class='ao-prebuilt-field-help'>" + apex.util.escapeHTML(helpText) + "</div>";
    } else if (options.length || type === "select") {
      html += renderPrebuiltParamLabel(fieldId, label, required, helpText);
      html += "<select id='" + escapeAttr(fieldId) + "' class='ao-input js-ao-prebuilt-param' data-param-name='" + escapeAttr(name) + "'" + (required ? " data-required='true'" : "") + ">";
      if (!required) html += "<option value=''>- Optional -</option>";
      options.forEach(function(option) {
        var optionValue = "";
        var optionLabel = "";
        if (option && typeof option === "object") {
          optionValue = String(option.value == null ? option.label : option.value).trim();
          optionLabel = String(option.label == null ? optionValue : option.label).trim();
        } else {
          optionValue = String(option == null ? "" : option).trim();
          optionLabel = optionValue;
        }
        if (!optionValue && !optionLabel) return;
        html += "<option value='" + escapeAttr(optionValue) + "'" + (currentValue === optionValue ? " selected" : "") + ">" + apex.util.escapeHTML(optionLabel || optionValue) + "</option>";
      });
      html += "</select>";
      if (helpText) html += "<div class='ao-prebuilt-field-help'>" + apex.util.escapeHTML(helpText) + "</div>";
    } else if (type === "boolean") {
      html += renderPrebuiltParamLabel(fieldId, label, required, helpText);
      html += "<select id='" + escapeAttr(fieldId) + "' class='ao-input js-ao-prebuilt-param' data-param-name='" + escapeAttr(name) + "'" + (required ? " data-required='true'" : "") + ">";
      html += "<option value=''>- Select -</option>";
      html += "<option value='true'" + (currentValue === "true" ? " selected" : "") + ">true</option>";
      html += "<option value='false'" + (currentValue === "false" ? " selected" : "") + ">false</option>";
      html += "</select>";
      if (helpText) html += "<div class='ao-prebuilt-field-help'>" + apex.util.escapeHTML(helpText) + "</div>";
    } else if (type === "textarea" || type === "json" || /json/i.test(name)) {
      html += renderPrebuiltParamLabel(fieldId, label, required, helpText);
      html += "<textarea id='" + escapeAttr(fieldId) + "' class='ao-input js-ao-prebuilt-param ao-prebuilt-textarea' data-param-name='" + escapeAttr(name) + "'" + (required ? " data-required='true'" : "") + (placeholder ? " placeholder='" + escapeAttr(placeholder) + "'" : "") + " autocomplete='off'>" + apex.util.escapeHTML(currentValue || "") + "</textarea>";
      if (helpText) html += "<div class='ao-prebuilt-field-help'>" + apex.util.escapeHTML(helpText) + "</div>";
    } else {
      html += renderPrebuiltParamLabel(fieldId, label, required, helpText);
      var listAttr = isAiProfileParam ? " list='aoPrebuiltAgentAiProfileOptions'" : "";
      var inputType = type === "number" ? "number" : "text";
      html += "<input id='" + escapeAttr(fieldId) + "' class='ao-input js-ao-prebuilt-param' type='" + escapeAttr(inputType) + "' value='" + escapeAttr(currentValue || "") + "' data-param-name='" + escapeAttr(name) + "'" + (required ? " data-required='true'" : "") + (isReadOnlyParam ? " readonly aria-readonly='true' data-fixed-param='true'" : "") + (placeholder ? " placeholder='" + escapeAttr(placeholder) + "'" : "") + listAttr + " autocomplete='off' />";
      if (helpText) html += "<div class='ao-prebuilt-field-help'>" + apex.util.escapeHTML(helpText) + "</div>";
    }
    html += "</div>";
    return html;
  }

  function applyPrebuiltDialogFlow() {
    var $dialog = $("#aoPrebuiltAgentDialogFields");
    $dialog.find(".ao-prebuilt-dialog__field[data-visible-param]").each(function() {
      var $fieldWrapper = $(this);
      var controllerName = String($fieldWrapper.attr("data-visible-param") || "").trim();
      var expectedValues = String($fieldWrapper.attr("data-visible-values") || "")
        .split("|")
        .map(function(value) { return String(value || "").trim().toUpperCase(); })
        .filter(Boolean);
      var currentValue = String(
        $dialog.find(".js-ao-prebuilt-param[data-param-name='" + controllerName + "']").val() || ""
      ).trim().toUpperCase();
      var shouldShow = expectedValues.length === 0 || expectedValues.indexOf(currentValue) >= 0;
      $fieldWrapper.toggleClass("is-hidden", !shouldShow);
      $fieldWrapper.find(".js-ao-prebuilt-param").prop("disabled", !shouldShow);
      if (!shouldShow) {
        $fieldWrapper.find(".js-ao-prebuilt-param").each(function() {
          clearFieldError(this);
        });
      }
    });
  }

  function openPrebuiltAgentDialog(agent, action) {
    if (!agent) return;
    var normalizedAction = action === "update" ? "update" : (action === "edit" ? "edit" : (action === "recreate" ? "recreate" : "install"));
    var stored = PREBUILT_AGENT_STATE[agent.id] || {};
    // For fresh installs, do not prefill previous values from local state.
    // Keep old values only for update/edit flows.
    var storedParams = (normalizedAction === "install")
      ? {}
      : (stored.params && typeof stored.params === "object" ? $.extend({}, stored.params) : {});
    var params = agent.requiredParams.concat(agent.optionalParams);
    var html = "";
    var titlePrefix = normalizedAction === "update"
      ? "Update "
      : (normalizedAction === "edit" ? "Edit Parameters - " : (normalizedAction === "recreate" ? "Drop & Recreate - " : "Install "));
    var dialogVerb = normalizedAction === "update"
      ? "update"
      : (normalizedAction === "edit" ? "save parameter changes for" : (normalizedAction === "recreate" ? "drop and recreate" : "install"));
    var buttonText = normalizedAction === "update"
      ? "Update"
      : (normalizedAction === "edit" ? "Save Params" : (normalizedAction === "recreate" ? "Drop & Recreate" : "Install"));

    var currentGroup = "";
    params.forEach(function(param) {
      var group = String((param && (param.group || param.groupLabel || param.group_label)) || "").trim();
      if (group && group !== currentGroup) {
        currentGroup = group;
        html += "<div class='ao-prebuilt-param-group'>" + apex.util.escapeHTML(group) + "</div>";
      } else if (!group) {
        currentGroup = "";
      }
      var name = String((param && param.name) || "").trim();
      var value = storedParams[name] || "";
      if (name === "schema") value = getCurrentAppSchema() || value;
      if (!value && param && param.defaultValue != null) value = String(param.defaultValue);
      if (!value && param && param.default_value != null) value = String(param.default_value);
      html += renderPrebuiltParamField(param, value);
    });
    if (agent.installNote) {
      html = "<div class='ao-prebuilt-install-note'>" + apex.util.escapeHTML(agent.installNote) + "</div>" + html;
    }

    PREBUILT_AGENT_DIALOG_AGENT_ID = agent.id;
    PREBUILT_AGENT_DIALOG_ACTION = normalizedAction;
    renderPrebuiltProfileDatalist();
    $("#aoPrebuiltAgentDialogTitle").text(titlePrefix + agent.name);
    $("#aoPrebuiltAgentDialogCopy").text(
      "Version " + agent.version + ". Enter the required parameters to " + dialogVerb + " this prebuilt agent."
    );
    $("#aoPrebuiltAgentDialogFields").html(html || "<div class='ao-muted-box'>No parameters are defined for this agent.</div>");
    applyPrebuiltDialogFlow();
    if (normalizedAction === "edit") {
      $("#aoPrebuiltAgentDialogFields .js-ao-prebuilt-param").each(function() {
        var $field = $(this);
        var initialValue = $field.is(":checkbox")
          ? ($field.prop("checked") ? "true" : "false")
          : String($field.val() == null ? "" : $field.val()).trim();
        $field.attr("data-initial-value", initialValue);
      });
    }
    $("#aoPrebuiltAgentRunInstall").text(buttonText);
    $("#aoPrebuiltAgentDropRecreate").toggleClass("is-hidden", normalizedAction !== "edit");
    $("#aoPrebuiltAgentDialog").removeClass("is-hidden");
    window.setTimeout(function() {
      $("#aoPrebuiltAgentDialogFields")
        .find("input:not([readonly]),select,textarea")
        .filter(":enabled:visible")
        .first()
        .trigger("focus");
    }, 20);
  }

  function closePrebuiltAgentDialog() {
    $("body").removeClass("ao-prebuilt-confirm-active");
    $("#aoPrebuiltAgentDialog").addClass("is-hidden");
    PREBUILT_AGENT_DIALOG_AGENT_ID = "";
    PREBUILT_AGENT_DIALOG_ACTION = "install";
    $("#aoPrebuiltAgentDialogFields").empty();
    $("#aoPrebuiltAgentDropRecreate").addClass("is-hidden");
  }

  function setPrebuiltAgentConfirmLayerActive(active) {
    $("body").toggleClass("ao-prebuilt-confirm-active", !!active);
  }

  function collectPrebuiltDialogParams() {
    var params = {};
    var configKeyMap = {};
    var firstInvalid = null;
    $("#aoPrebuiltAgentDialogFields .js-ao-prebuilt-param").each(function() {
      var field = this;
      var $field = $(field);
      if ($field.prop("disabled")) return;
      var name = String($field.attr("data-param-name") || "").trim();
      var configKey = String($field.closest(".ao-prebuilt-dialog__field").attr("data-config-key") || "").trim();
      var required = $field.attr("data-required") === "true";
      var requiredValue = String($field.attr("data-required-value") || "").trim();
      var isCheckbox = $field.is(":checkbox");
      var value = isCheckbox ? ($field.prop("checked") ? "true" : "false") : String($field.val() == null ? "" : $field.val()).trim();
      clearFieldError(field);
      if (required && !value) {
        markFieldError(field, "Required.");
        if (!firstInvalid) firstInvalid = field;
        return;
      }
      if (requiredValue && value !== requiredValue) {
        markFieldError(field, "Required.");
        if (!firstInvalid) firstInvalid = field;
        return;
      }
      if (PREBUILT_AGENT_DIALOG_ACTION === "edit") {
        var initialValue = String($field.attr("data-initial-value") || "").trim();
        if (value === initialValue) return;
      }
      if (name && value !== "") {
        params[name] = value;
        if (configKey && configKey.toUpperCase() !== name.toUpperCase()) {
          configKeyMap[name] = configKey;
        }
      }
    });
    var appSchema = getCurrentAppSchema();
    if (appSchema) params.schema = appSchema;
    if (firstInvalid) {
      firstInvalid.focus();
      return null;
    }
    if (Object.keys(configKeyMap).length) {
      Object.defineProperty(params, "__configKeyMap", {
        value: configKeyMap,
        enumerable: false
      });
    }
    return params;
  }

  function buildPrebuiltAgentActionParams(agent, params, options) {
    var opts = options || {};
    var payload = $.extend({}, params || {});
    if (opts.includeConfigKeyMap === true && params && params.__configKeyMap && Object.keys(params.__configKeyMap).length) {
      payload.config_key_map = params.__configKeyMap;
    }
    var teamName = String(payload.team_name || "").trim() || getPrebuiltAgentTeamName(agent);
    if (teamName) payload.team_name = teamName;
    if (agent && agent.id) payload.agent_id = agent.id;
    if (agent && agent.version) payload.agent_version = agent.version;
    if (agent && agent.installSqlFile) payload.install_sql_file = agent.installSqlFile;
    var installSqlUrl = getPrebuiltAgentInstallSqlUrl(agent);
    if (installSqlUrl) payload.install_sql_url = installSqlUrl;
    if (agent && agent.installProcedure) payload.install_procedure = agent.installProcedure;
    if (agent && agent.toolsProcedure) payload.tools_procedure = agent.toolsProcedure;
    if (agent && agent.agentProcedure) payload.agent_procedure = agent.agentProcedure;
    if (agent && agent.minDatabaseMajorVersion) payload.min_database_major_version = String(agent.minDatabaseMajorVersion);
    if (agent && agent.supportedDatabaseMajorVersions && agent.supportedDatabaseMajorVersions.length) {
      payload.supported_database_major_versions = agent.supportedDatabaseMajorVersions;
    }
    if (agent && agent.supportedDatabaseVersions) payload.supported_database_versions = agent.supportedDatabaseVersions;
    if (agent && agent.backgroundInstall) payload.background_install = "Y";
    if (agent && agent.jobLogTable) payload.job_log_table = agent.jobLogTable;
    payload.required_object_privileges = normalizePrebuiltStringArray(agent && agent.requiredObjectPrivileges);
    payload.required_system_privileges = normalizePrebuiltStringArray(agent && agent.requiredSystemPrivileges);
    return payload;
  }

  function executePrebuiltAgentInstall(agent, params, action) {
    var isUpdate = action === "update";
    var isEdit = action === "edit";
    var actionLabel = isUpdate ? "Updating" : (isEdit ? "Saving parameters for" : "Installing");
    var busyHint = agent.installNote ? " This can take a few minutes." : "";
    var busyMessage = actionLabel + " " + agent.name + "..." + busyHint;
    var submittedStatus = agent.backgroundInstall && !isEdit ? "installing" : "installed";
    var successMessage = agent.name + (isUpdate ? " update submitted." : (isEdit ? " parameters saved." : " install submitted."));
    if (submittedStatus === "installing") successMessage += " The agent team is being created in the background; this can take several minutes.";
    var actionParams = buildPrebuiltAgentActionParams(agent, params);
    var payload = JSON.stringify(actionParams);

    showBusy(busyMessage);
    if (agent.installSqlFile) {
      updateBusyText(actionLabel + " agent..." + busyHint);
      ajaxPromise(PROC.INSTALL_PREBUILT_AGENT, {
        x01: agent.id,
        x02: "install",
        x03: agent.installSqlFile,
        x04: agent.version,
        p_clob_01: payload
      }).then(function(result) {
        if (result && result.team_name) actionParams.team_name = String(result.team_name);
        PREBUILT_AGENT_STATE[agent.id] = {
          status: submittedStatus,
          installedVersion: submittedStatus === "installed" ? agent.version : "",
          installStatus: submittedStatus === "installing" ? "PRECHECK" : "SUCCEEDED",
          installStatusMessage: submittedStatus === "installing" ? "Background job submitted. Creating the agent team." : "",
          params: actionParams
        };
        persistPrebuiltAgentState();
        renderPrebuiltAgents();
        closePrebuiltAgentDialog();
        showSuccess(successMessage);
        bootstrap();
        if (submittedStatus === "installing") schedulePrebuiltAgentStatusRefresh();
      }).fail(function(err) {
        showError((err && err.responseText) || "Unable to install prebuilt agent.");
      }).always(function() {
        hideBusy();
      });
      return;
    }

    ajaxPromise(PROC.INSTALL_PREBUILT_AGENT, {
      x01: agent.id,
      x02: "tools",
      x03: agent.toolsSqlFile,
      x04: agent.version,
      p_clob_01: payload
    }).then(function() {
      updateBusyText(actionLabel + " agent..." + busyHint);
      return ajaxPromise(PROC.INSTALL_PREBUILT_AGENT, {
        x01: agent.id,
        x02: "agent",
        x03: agent.agentSqlFile,
        x04: agent.version,
        p_clob_01: payload
      });
    }).then(function(result) {
      if (result && result.team_name) actionParams.team_name = String(result.team_name);
      PREBUILT_AGENT_STATE[agent.id] = {
        status: submittedStatus,
        installedVersion: submittedStatus === "installed" ? agent.version : "",
        installStatus: submittedStatus === "installing" ? "PRECHECK" : "SUCCEEDED",
        installStatusMessage: submittedStatus === "installing" ? "Background job submitted. Creating the agent team." : "",
        params: actionParams
      };
      persistPrebuiltAgentState();
      renderPrebuiltAgents();
      closePrebuiltAgentDialog();
      showSuccess(successMessage);
      bootstrap();
      if (submittedStatus === "installing") schedulePrebuiltAgentStatusRefresh();
    }).fail(function(err) {
      showError((err && err.responseText) || "Unable to install prebuilt agent.");
    }).always(function() {
      hideBusy();
    });
  }

  function schedulePrebuiltAgentStatusRefresh() {
    [6000, 15000, 30000, 60000].forEach(function(delay) {
      window.setTimeout(function() {
        bootstrap();
      }, delay);
    });
  }

  function recreatePrebuiltAgent(agent, params) {
    var uninstallParams = buildPrebuiltAgentActionParams(agent, params);
    var proceed = function() {
      showBusy("Dropping " + agent.name + " before recreate...");
      ajaxPromise(PROC.UNINSTALL_PREBUILT_AGENT, {
        x01: agent.id,
        x02: agent.version,
        p_clob_01: JSON.stringify(uninstallParams)
      }).then(function() {
        hideBusy();
        runPrebuiltAgentInstall(agent, params, "install");
      }).fail(function(err) {
        hideBusy();
        showError((err && err.responseText) || "Unable to drop agent before recreate.");
      });
    };

    if (apex.message && typeof apex.message.confirm === "function") {
      setPrebuiltAgentConfirmLayerActive(true);
      apex.message.confirm(
        "Drop and recreate " + agent.name + "? This will drop current prebuilt team objects before reinstall.",
        function(okPressed) {
          setPrebuiltAgentConfirmLayerActive(false);
          if (okPressed) proceed();
        }
      );
      return;
    }
    setPrebuiltAgentConfirmLayerActive(false);
    if (window.confirm("Drop and recreate " + agent.name + "?")) proceed();
  }

  function savePrebuiltAgentParamsOnly(agent, params) {
    var actionParams = buildPrebuiltAgentActionParams(agent, params, { includeConfigKeyMap: true });
    showBusy("Saving parameters for " + agent.name + "...");
    ajaxPromise(PROC.SAVE_PREBUILT_AGENT_PARAMS, {
      x01: agent.id,
      x02: agent.version,
      p_clob_01: JSON.stringify(actionParams)
    }).then(function(result) {
      if (result && result.team_name) actionParams.team_name = String(result.team_name);
      PREBUILT_AGENT_STATE[agent.id] = $.extend({}, PREBUILT_AGENT_STATE[agent.id] || {}, {
        params: actionParams
      });
      persistPrebuiltAgentState();
      renderPrebuiltAgents();
      closePrebuiltAgentDialog();
      showSuccess(agent.name + " parameters saved.");
    }).fail(function(err) {
      showError((err && err.responseText) || "Unable to save agent parameters.");
    }).always(function() {
      hideBusy();
    });
  }

  function runPrebuiltAgentInstall(agent, params, action) {
    var supportWarning = getPrebuiltSupportWarning(agent);
    if (supportWarning) {
      showError(supportWarning);
      return;
    }
    if (action === "edit") {
      savePrebuiltAgentParamsOnly(agent, params);
      return;
    }
    if (action === "recreate") {
      recreatePrebuiltAgent(agent, params);
      return;
    }
    var actionParams = buildPrebuiltAgentActionParams(agent, params);
    var payload = JSON.stringify(actionParams);

    showBusy("Checking prerequisite grants...");
    ajaxPromise(PROC.INSTALL_PREBUILT_AGENT, {
      x01: agent.id,
      x02: "precheck",
      x03: agent.installSqlFile || agent.toolsSqlFile || agent.agentSqlFile,
      x04: agent.version,
      p_clob_01: payload
    }).then(function(result) {
      hideBusy();
      if (result && (result.has_missing_grants === true || (result.missing_grants || []).length > 0)) {
        openPrebuiltGrantDialog(agent, params, action, result);
        return;
      }
      executePrebuiltAgentInstall(agent, params, action);
    }).fail(function(err) {
      hideBusy();
      showError((err && err.responseText) || "Unable to check prerequisite grants.");
    });
  }

  function normalizeMissionStatus(row) {
    var status = String((row && row.status) || "").trim().toUpperCase();
    if (status === "RUNNING" || status === "FAILED" || status === "COMPLETED") return status;
    return "COMPLETED";
  }

  function getMissionResponseRows(response, candidateKeys) {
    var source = response && typeof response === "object" ? response : {};
    var nested = source.data && typeof source.data === "object" ? source.data : {};
    var result = source.result && typeof source.result === "object" ? source.result : {};
    var payload = source.payload && typeof source.payload === "object" ? source.payload : {};
    var candidates = Array.isArray(candidateKeys) ? candidateKeys : [];
    var containers = [source, nested, result, payload];
    var i;
    var j;
    var k;
    var keys;
    var key;

    for (i = 0; i < containers.length; i += 1) {
      keys = Object.keys(containers[i]);
      for (j = 0; j < candidates.length; j += 1) {
        key = candidates[j];
        if (Array.isArray(containers[i][key])) return containers[i][key];
        for (k = 0; k < keys.length; k += 1) {
          if (String(keys[k]).toLowerCase() === String(key).toLowerCase() && Array.isArray(containers[i][keys[k]])) {
            return containers[i][keys[k]];
          }
        }
      }
    }
    return [];
  }

  function normalizeMissionRow(row) {
    var source = row && typeof row === "object" ? row : {};
    var normalized = $.extend({}, source);
    var aliases = {
      conversationid: "conversation_id",
      conversationpromptid: "conversation_prompt_id",
      teamname: "team_name",
      teamexecid: "team_exec_id",
      agentname: "agent_name",
      taskname: "task_name",
      profilename: "profile_name",
      promptaction: "prompt_action",
      promptresponse: "prompt_response",
      toolname: "tool_name",
      toolinput: "tool_input",
      tooloutput: "tool_output",
      tooloutputalt: "tool_output_alt",
      startdate: "start_date",
      responsecreated: "response_created",
      invocationid: "invocation_id"
    };

    Object.keys(source).forEach(function(key) {
      var normalizedKey = String(key || "").toLowerCase().replace(/[^a-z0-9]/g, "");
      var targetKey = aliases[normalizedKey] || String(key || "").toLowerCase();
      if (!Object.prototype.hasOwnProperty.call(normalized, targetKey)) {
        normalized[targetKey] = source[key];
      }
    });
    return normalized;
  }

  function normalizeMissionAgentName(row) {
    var agentName = String((row && row.agent_name) || "").trim();
    return agentName || "UNKNOWN_AGENT";
  }

  function missionShortText(value, maxLen) {
    var text = String(value == null ? "" : value).replace(/\s+/g, " ").trim();
    if (!text) return "";
    var limit = Number(maxLen || 160);
    if (text.length <= limit) return text;
    return text.slice(0, limit - 1) + "...";
  }

  function missionSortByCreatedDesc(rows) {
    return (rows || []).slice().sort(function(a, b) {
      var createdCompare = String(b.created || "").localeCompare(String(a.created || ""));
      if (createdCompare) return createdCompare;
      return String(b.modified || "").localeCompare(String(a.modified || ""));
    });
  }

  function missionRenderBoardRows(rows, rowRenderer) {
    var html = "";
    missionSortByCreatedDesc(rows).forEach(function(row) {
      html += rowRenderer(row);
    });
    return html;
  }

  function setMissionPaneSplit(logPanePct) {
    var pct = Math.max(28, Math.min(68, Number(logPanePct || MISSION_LOG_PANE_PCT)));
    MISSION_LOG_PANE_PCT = pct;
    $("#aoAgentLogsPanel .ao-mission-layout").css("--ao-mission-log-pane-pct", pct + "%");
    $("#aoMissionPaneResizer").attr("aria-valuenow", String(Math.round(pct)));
  }

  function startMissionPaneResize(event) {
    var pointerEvent = event.originalEvent || event;
    var $panel = $("#aoAgentLogsPanel");
    var layout = $panel.find(".ao-mission-layout")[0];
    if (!layout || !$panel.hasClass("ao-mission-has-selection")) return;
    event.preventDefault();
    MISSION_RESIZE_ACTIVE = true;
    $("body").addClass("ao-mission-pane-resizing");
    $("#aoMissionPaneResizer").addClass("is-dragging");
    if (pointerEvent.pointerId != null && event.currentTarget && event.currentTarget.setPointerCapture) {
      event.currentTarget.setPointerCapture(pointerEvent.pointerId);
    }
    updateMissionPaneResize(pointerEvent);
  }

  function updateMissionPaneResize(event) {
    if (!MISSION_RESIZE_ACTIVE) return;
    var layout = $("#aoAgentLogsPanel .ao-mission-layout")[0];
    if (!layout) return;
    var rect = layout.getBoundingClientRect();
    if (!rect.width) return;
    var x = Number(event.clientX || 0);
    var pct = ((x - rect.left) / rect.width) * 100;
    setMissionPaneSplit(pct);
  }

  function stopMissionPaneResize() {
    if (!MISSION_RESIZE_ACTIVE) return;
    MISSION_RESIZE_ACTIVE = false;
    $("body").removeClass("ao-mission-pane-resizing");
    $("#aoMissionPaneResizer").removeClass("is-dragging");
  }

  function missionEventTimeValue(value) {
    return String(value == null ? "" : value).trim();
  }

  function missionPromptTextFromRows(rows) {
    var promptRows = (rows || []).slice().sort(function(a, b) {
      return String(a.created || "").localeCompare(String(b.created || ""));
    });
    for (var i = 0; i < promptRows.length; i += 1) {
      var promptText = String(promptRows[i].prompt || "").trim();
      if (promptText) return promptText;
    }
    return "";
  }

  function missionUniqueByKey(rows, keyFn) {
    var seen = {};
    var out = [];
    (rows || []).forEach(function(row) {
      var key = String(keyFn(row) || "").trim();
      if (!key || seen[key]) return;
      seen[key] = true;
      out.push(row);
    });
    return out;
  }

  function extractMissionToolNamesFromText(value) {
    return extractMissionToolInvocationsFromText(value).map(function(item) {
      return item.tool_name;
    });
  }

  function cleanMissionToolDetailText(value) {
    return String(value || "")
      .replace(/^```[a-zA-Z]*\s*/g, "")
      .replace(/```\s*$/g, "")
      .trim();
  }

  function formatMissionToolDetailText(value) {
    var text = cleanMissionToolDetailText(value);
    if (!text) return "";
    try {
      return JSON.stringify(JSON.parse(text), null, 2);
    } catch (e1) {
      var jsonStart = text.search(/[\[{]/);
      var jsonEnd = Math.max(text.lastIndexOf("}"), text.lastIndexOf("]"));
      if (jsonStart >= 0 && jsonEnd > jsonStart) {
        var before = text.slice(0, jsonStart).trim();
        var jsonText = text.slice(jsonStart, jsonEnd + 1);
        var after = text.slice(jsonEnd + 1).trim();
        try {
          var formattedJson = JSON.stringify(JSON.parse(jsonText), null, 2);
          return [before, formattedJson, after].filter(function(part) { return !!part; }).join("\n");
        } catch (e2) {}
      }
    }
    return text;
  }

  function extractMissionToolInvocationsFromText(value) {
    var text = String(value || "");
    var invocations = [];
    var seen = {};
    var actionRegex = /\bAction\s*:\s*([A-Z][A-Z0-9_$#]+)/gi;
    var matches = [];
    var match;
    while ((match = actionRegex.exec(text)) !== null) {
      matches.push({ name: String(match[1] || "").trim(), index: match.index });
    }
    matches.forEach(function(item, index) {
      var name = item.name;
      var key = name.toUpperCase();
      var nextIndex = matches[index + 1] ? matches[index + 1].index : text.length;
      var segment = text.slice(item.index, nextIndex);
      var inputMatch = segment.match(/\bAction\s+Input\s*:\s*([\s\S]*?)(?=\n\s*(?:Observation|Thought|Final Answer|Action\s*:)|$)/i);
      var outputMatch = segment.match(/\bObservation\s*:\s*([\s\S]*?)(?=\n\s*(?:Thought|Final Answer|Action\s*:)|$)/i);
      if (!name || seen[key]) return;
      if (["CHAT", "FINAL", "FINAL_ANSWER", "RESPONSE"].indexOf(key) >= 0) return;
      seen[key] = true;
      invocations.push({
        tool_name: name,
        tool_input: inputMatch ? cleanMissionToolDetailText(inputMatch[1]) : "",
        tool_output: outputMatch ? cleanMissionToolDetailText(outputMatch[1]) : ""
      });
    });
    return invocations;
  }

  function buildMissionFallbackToolRows(promptRows) {
    var rows = [];
    var seen = {};
    (promptRows || []).forEach(function(row) {
      var agentName = String(row.agent_name || "").trim();
      var taskName = String(row.task_name || "").trim();
      extractMissionToolInvocationsFromText(row.prompt_response).forEach(function(tool) {
        var toolName = String(tool.tool_name || "").trim();
        var key = [agentName, taskName, toolName, row.created].join("|").toUpperCase();
        if (seen[key]) return;
        seen[key] = true;
        rows.push({
          conversation_id: row.conversation_id,
          team_exec_id: row.team_exec_id,
          agent_name: agentName,
          task_name: taskName,
          tool_name: toolName,
          start_date: row.created,
          tool_input: tool.tool_input || "",
          tool_output: tool.tool_output || "",
          response_created: row.created
        });
      });
    });
    return rows;
  }

  function assignMissionToolStepNumbers(promptRows, toolRows) {
    var promptEvents = [];
    var responseEvents = [];
    var toolEvents = [];
    (promptRows || []).forEach(function(row) {
      if (String(row.prompt || "").trim()) promptEvents.push(row);
      if (String(row.prompt_response || "").trim()) responseEvents.push(row);
    });
    promptEvents.sort(function(a, b) { return missionEventTimeValue(a.created).localeCompare(missionEventTimeValue(b.created)); });
    responseEvents.sort(function(a, b) { return missionEventTimeValue(a.created).localeCompare(missionEventTimeValue(b.created)); });
    toolEvents = (toolRows || []).slice().sort(function(a, b) {
      var av = missionEventTimeValue(a.start_date || a.response_created);
      var bv = missionEventTimeValue(b.start_date || b.response_created);
      if (av !== bv) return av.localeCompare(bv);
      return Number(a.invocation_id || 0) - Number(b.invocation_id || 0);
    });

    var stepCounter = 0;
    var responseStepByCreated = {};
    promptEvents.forEach(function() { stepCounter += 1; });
    responseEvents.forEach(function(row) {
      stepCounter += 1;
      responseStepByCreated[missionEventTimeValue(row.created)] = stepCounter;
    });
    toolEvents.forEach(function(row) {
      if (row.response_created && responseStepByCreated[missionEventTimeValue(row.response_created)]) {
        row.step_number = responseStepByCreated[missionEventTimeValue(row.response_created)];
      } else {
        stepCounter += 1;
        row.step_number = stepCounter;
      }
    });
    return toolRows || [];
  }

  function applyMissionMapZoom() {
    var zoomPct = Math.round(MISSION_MAP_ZOOM * 100);
    $("#aoMissionMapCanvas").css("--ao-mission-map-zoom", MISSION_MAP_ZOOM);
    $("#aoMissionMapZoomLabel").text(zoomPct + "%");
  }

  function centerMissionMapView() {
    var canvas = $("#aoMissionMapCanvas")[0];
    if (!canvas) return;
    canvas.scrollLeft = Math.max(0, Math.round((canvas.scrollWidth - canvas.clientWidth) / 2));
  }

  function adjustMissionMapZoom(delta) {
    MISSION_MAP_ZOOM = Math.max(0.55, Math.min(1.35, Math.round((MISSION_MAP_ZOOM + delta) * 20) / 20));
    applyMissionMapZoom();
    window.requestAnimationFrame(centerMissionMapView);
  }

  function buildMissionConversationMapData(conversationId) {
    var convId = String(conversationId || "").trim();
    var promptRows = (MISSION_LOG_ROWS || []).filter(function(row) {
      return String(row.conversation_id || "") === convId;
    });
    var toolRows = (MISSION_TOOL_ROWS || []).filter(function(row) {
      return String(row.conversation_id || "") === convId;
    });
    if (!toolRows.length) {
      toolRows = buildMissionFallbackToolRows(promptRows);
    }
    toolRows = assignMissionToolStepNumbers(promptRows, toolRows);
    var teamRows = missionUniqueByKey(promptRows, function(row) { return row.team_name; });
    var agentRows = missionUniqueByKey(toolRows.length ? toolRows : promptRows, function(row) { return row.agent_name; });
    var taskRows = missionUniqueByKey(toolRows.length ? toolRows : promptRows, function(row) { return row.task_name; });
    return {
      teamRows: teamRows,
      agentRows: agentRows,
      taskRows: taskRows,
      toolRows: toolRows
    };
  }

  function renderMissionConversationMap(conversationId) {
    var convId = String(conversationId || "").trim();
    var data = buildMissionConversationMapData(convId);
    var $canvas = $("#aoMissionMapCanvas");
    if (!$canvas.length) return;
    closeMissionToolDetail();
    MISSION_MAP_TOOL_DETAILS = {};

    function renderMissionMapNode(type, name, isEmpty) {
      var normalizedType = String(type || "").trim().toUpperCase();
      var safeName = String(name || "").trim();
      var typeLabel = normalizedType.charAt(0) + normalizedType.slice(1).toLowerCase();
      var html = "<div class='ao-team-node ao-team-node--" + escapeAttr(normalizedType.toLowerCase()) + (isEmpty ? " ao-team-node--empty" : "") + "'>";
      html += "<span class='ao-team-node-type'>" + apex.util.escapeHTML(typeLabel) + "</span>";
      html += "<strong>" + apex.util.escapeHTML(safeName || ("No " + typeLabel.toLowerCase())) + "</strong>";
      html += "</div>";
      return html;
    }

    function renderMissionToolNode(toolRow, detailId) {
      var toolName = String(toolRow && toolRow.tool_name || "").trim();
      var stepNumber = Number(toolRow && toolRow.step_number || 0);
      var html = "<div class='ao-team-node ao-team-node--tool ao-mission-tool-node'>";
      html += "<div class='ao-mission-tool-node__top'>";
      html += "<span class='ao-team-node-type'>Tool</span>";
      html += "<button type='button' class='ao-mission-tool-info' data-mission-tool-detail='" + escapeAttr(detailId) + "' aria-label='View tool input and output' title='View input and output'>i</button>";
      html += "</div>";
      html += "<strong>" + apex.util.escapeHTML(toolName || "Tool") + "</strong>";
      if (stepNumber) {
        html += "<span class='ao-mission-tool-step'>Step " + apex.util.escapeHTML(String(stepNumber)) + "</span>";
      }
      html += "</div>";
      return html;
    }

    var teamName = data.teamRows.length ? String(data.teamRows[0].team_name || "").trim() : "Team";
    var branches = [];
    data.agentRows.forEach(function(agentRow) {
      var agentName = String(agentRow.agent_name || "").trim();
      if (!agentName) return;
      var taskMatches = data.taskRows.filter(function(taskRow) {
        return String(taskRow.agent_name || "").trim() === agentName;
      });
      if (!taskMatches.length) taskMatches = [{ agent_name: agentName, task_name: String(agentRow.task_name || "").trim() }];
      taskMatches.forEach(function(taskRow) {
        var taskName = String(taskRow.task_name || "").trim();
        var tools = data.toolRows.filter(function(toolRow) {
          return String(toolRow.agent_name || "").trim() === agentName &&
                 String(toolRow.task_name || "").trim() === taskName;
        }).sort(function(a, b) {
          var as = Number(a.step_number || 0);
          var bs = Number(b.step_number || 0);
          if (as !== bs) return as - bs;
          return missionEventTimeValue(a.start_date || a.response_created).localeCompare(missionEventTimeValue(b.start_date || b.response_created));
        });
        branches.push({ agentName: agentName, taskName: taskName, tools: tools });
      });
    });

    MISSION_MAP_ZOOM = 0.75;
    var html = "";
    html += "<div class='ao-team-tree ao-team-tree--rooted ao-mission-team-tree' role='tree' aria-label='Conversation map'>";
    html += "<div class='ao-team-root'>" + renderMissionMapNode("TEAM", teamName || "Team", false) + "</div>";
    html += "<div class='ao-team-branches'>";
    if (!branches.length) {
      html += "<div class='ao-team-branch'>";
      html += "<span class='ao-team-branch-line ao-team-branch-line--from-root' aria-hidden='true'></span>";
      html += renderMissionMapNode("AGENT", "No agent captured", true);
      html += "<span class='ao-team-connector' aria-hidden='true'></span>";
      html += renderMissionMapNode("TASK", "No task captured", true);
      html += "<div class='ao-team-tool-tree'><div class='ao-team-tool-stack'><div class='ao-team-tool-branch'>";
      html += "<span class='ao-team-tool-line' aria-hidden='true'></span>";
      html += renderMissionMapNode("TOOL", "No tools captured", true);
      html += "</div></div></div>";
      html += "</div>";
    } else {
      branches.forEach(function(branch) {
        html += "<div class='ao-team-branch'>";
        html += "<span class='ao-team-branch-line ao-team-branch-line--from-root' aria-hidden='true'></span>";
        html += renderMissionMapNode("AGENT", branch.agentName || "Agent", false);
        html += "<span class='ao-team-connector' aria-hidden='true'></span>";
        html += renderMissionMapNode("TASK", branch.taskName || "Task", false);
        html += "<div class='ao-team-tool-tree'>";
        html += "<div class='ao-team-tool-stack'>";
        if (branch.tools.length) {
          branch.tools.forEach(function(toolRow) {
            var toolName = String(toolRow.tool_name || "").trim();
            var detailId = "mission-tool-" + Object.keys(MISSION_MAP_TOOL_DETAILS).length;
            MISSION_MAP_TOOL_DETAILS[detailId] = {
              step_number: Number(toolRow.step_number || 0),
              tool_name: toolName || "Tool",
              agent_name: branch.agentName || "",
              task_name: branch.taskName || "",
              input: String(toolRow.tool_input || "").trim(),
              output: String(toolRow.tool_output || toolRow.tool_output_alt || "").trim()
            };
            html += "<div class='ao-team-tool-branch'>";
            html += "<span class='ao-team-tool-line' aria-hidden='true'></span>";
            html += renderMissionToolNode(toolRow, detailId);
            html += "</div>";
          });
        } else {
          html += "<div class='ao-team-tool-branch'>";
          html += "<span class='ao-team-tool-line' aria-hidden='true'></span>";
          html += renderMissionMapNode("TOOL", "No tools captured", true);
          html += "</div>";
        }
        html += "</div></div></div>";
      });
    }
    html += "</div>";
    html += "</div>";

    $canvas.html(html);
    applyMissionMapZoom();
    window.requestAnimationFrame(centerMissionMapView);
    $("#aoMissionMapDialogCopy").text("Conversation: " + convId + " | Team -> Agent -> Task -> Tool");
  }

  function openMissionToolDetail(detailId) {
    var detail = MISSION_MAP_TOOL_DETAILS[String(detailId || "")];
    if (!detail) return;
    var inputText = formatMissionToolDetailText(detail.input) || "No input captured.";
    var outputText = formatMissionToolDetailText(detail.output) || "No output captured.";
    var bodyHtml = "";
    bodyHtml += "<section class='ao-map-drawer-block'><h5>Tool Input</h5><pre class='ao-map-drawer-code'>" + apex.util.escapeHTML(inputText) + "</pre></section>";
    bodyHtml += "<section class='ao-map-drawer-block'><h5>Tool Output</h5><pre class='ao-map-drawer-code'>" + apex.util.escapeHTML(outputText) + "</pre></section>";
    $("#aoMissionToolDetailStep").text(detail.step_number ? "Step " + detail.step_number : "Tool");
    $("#aoMissionToolDetailTitle").text(detail.tool_name || "Tool");
    $("#aoMissionToolDetailBody").html(bodyHtml);
    $("#aoMissionToolDetail").removeClass("is-hidden").attr("aria-hidden", "false");
  }

  function closeMissionToolDetail() {
    $("#aoMissionToolDetail").addClass("is-hidden").attr("aria-hidden", "true");
  }

  function renderMissionControl() {
    var $list = $("#aoMissionList");
    var $detail = $("#aoMissionDetail");
    var $panel = $("#aoAgentLogsPanel");
    if (!$list.length) return;

    var agentFilter = String($("#aoMissionAgentFilter").val() || "").trim().toUpperCase();
    var statusFilter = String($("#aoMissionStatusFilter").val() || "").trim().toUpperCase();
    var search = String($("#aoMissionSearch").val() || "").trim().toLowerCase();
    var uniqueAgents = {};
    var filteredRows = (MISSION_LOG_ROWS || []).filter(function(row) {
      var agentName = normalizeMissionAgentName(row);
      uniqueAgents[agentName] = true;
      var rowStatus = normalizeMissionStatus(row);
      if (agentFilter && agentName.toUpperCase() !== agentFilter) return false;
      if (statusFilter && rowStatus !== statusFilter) return false;
      if (search) {
        var haystack = [
          row.conversation_id,
          row.conversation_prompt_id,
          row.profile_name,
          row.prompt_action,
          row.prompt,
          row.prompt_response
        ].join(" ").toLowerCase();
        if (haystack.indexOf(search) < 0) return false;
      }
      return true;
    });

    var convLatest = {};
    var rowsByConversation = {};
    filteredRows.forEach(function(row) {
      var key = String(row.conversation_id || "").trim();
      if (!key) return;
      if (!rowsByConversation[key]) rowsByConversation[key] = [];
      rowsByConversation[key].push(row);
      var existing = convLatest[key];
      if (!existing) {
        convLatest[key] = row;
        return;
      }
      var rowCreated = String(row.created || "");
      var existingCreated = String(existing.created || "");
      if (rowCreated > existingCreated) {
        convLatest[key] = row;
      } else if (rowCreated === existingCreated && String(row.modified || "") > String(existing.modified || "")) {
        convLatest[key] = row;
      }
    });
    var latestRows = missionSortByCreatedDesc(Object.keys(convLatest).map(function(key) { return convLatest[key]; }));

    var statusCounts = { RUNNING: 0, FAILED: 0, COMPLETED: 0 };
    latestRows.forEach(function(row) {
      var st = normalizeMissionStatus(row);
      statusCounts[st] = (statusCounts[st] || 0) + 1;
    });
    $("#aoMissionKpiTotal").text(String(latestRows.length));
    $("#aoMissionKpiRunning").text(String(statusCounts.RUNNING || 0));
    $("#aoMissionKpiFailed").text(String(statusCounts.FAILED || 0));
    $("#aoMissionKpiCompleted").text(String(statusCounts.COMPLETED || 0));
    $("#aoMissionMeta").text("Showing " + latestRows.length + " conversations");

    var agentOpts = Object.keys(uniqueAgents).sort();
    var currentAgent = String($("#aoMissionAgentFilter").val() || "").trim();
    var optionsHtml = "<option value=''>All Agents</option>";
    agentOpts.forEach(function(agent) {
      optionsHtml += "<option value='" + escapeAttr(agent) + "'" + (currentAgent === agent ? " selected" : "") + ">" + apex.util.escapeHTML(agent) + "</option>";
    });
    $("#aoMissionAgentFilter").html(optionsHtml);

    if (!latestRows.length) {
      $list.html("<div class='ao-muted-box'>No mission log rows match current filters.</div>");
      $detail.html("<div class='ao-muted-box'>No conversation selected.</div>");
      $("#aoMissionConversationLabel").text("Select a log row");
      $panel.removeClass("ao-mission-has-selection");
      return;
    }

    if (MISSION_ACTIVE_CONVERSATION_ID && !convLatest[MISSION_ACTIVE_CONVERSATION_ID]) {
      MISSION_ACTIVE_CONVERSATION_ID = "";
    }

    var buildMissionRowHtml = function(row) {
      var convId = String(row.conversation_id || "");
      var st = normalizeMissionStatus(row);
      var agentName = normalizeMissionAgentName(row);
      var promptText = missionShortText(missionPromptTextFromRows(rowsByConversation[convId]) || row.prompt, MISSION_ACTIVE_CONVERSATION_ID ? 120 : 180);
      var html = "";
      html += "<div class='ao-mission-row" + (convId === MISSION_ACTIVE_CONVERSATION_ID ? " is-active" : "") + "' data-mission-conv-id='" + escapeAttr(convId) + "'>";
      html += "<div class='ao-mission-row__top'><strong title='" + escapeAttr(promptText || convId) + "'>" + apex.util.escapeHTML(promptText || "No prompt captured") + "</strong><span class='ao-mission-badge ao-mission-badge--" + escapeAttr(st) + "'>" + apex.util.escapeHTML(st) + "</span></div>";
      html += "<div class='ao-mission-row__meta'>" + apex.util.escapeHTML(agentName) + " | Action: " + apex.util.escapeHTML(String(row.prompt_action || "")) + "</div>";
      html += "</div>";
      return html;
    };

    if (MISSION_VIEW_MODE === "list") {
      var listHtml = "";
      latestRows.forEach(function(row) { listHtml += buildMissionRowHtml(row); });
      $list.html(listHtml || "<div class='ao-muted-box'>No rows.</div>");
    } else {
      var byStatus = { RUNNING: [], FAILED: [], COMPLETED: [] };
      var statusLabelMap = { RUNNING: "Inbox", FAILED: "In Progress", COMPLETED: "Review" };
      latestRows.forEach(function(row) {
        byStatus[normalizeMissionStatus(row)].push(row);
      });
      var boardHtml = "<div class='ao-mission-board'>";
      ["RUNNING", "FAILED", "COMPLETED"].forEach(function(st) {
        boardHtml += "<div class='ao-mission-col'>";
        boardHtml += "<div class='ao-mission-col__head'><span>" + apex.util.escapeHTML(statusLabelMap[st] || st) + "</span><span class='ao-mission-col__count'>" + byStatus[st].length + "</span></div>";
        if (!byStatus[st].length) {
          boardHtml += "<div class='ao-muted-box'>No items</div>";
        } else {
          boardHtml += missionRenderBoardRows(byStatus[st], buildMissionRowHtml);
        }
        boardHtml += "</div>";
      });
      boardHtml += "</div>";
      $list.html(boardHtml);
    }

    var detailRows = filteredRows.filter(function(row) {
      return String(row.conversation_id || "") === MISSION_ACTIVE_CONVERSATION_ID;
    }).sort(function(a, b) {
      return String(a.created || "").localeCompare(String(b.created || ""));
    });
    var detailToolRows = (MISSION_TOOL_ROWS || []).filter(function(row) {
      return String(row.conversation_id || "") === MISSION_ACTIVE_CONVERSATION_ID;
    }).sort(function(a, b) {
      var av = missionEventTimeValue(a.start_date);
      var bv = missionEventTimeValue(b.start_date);
      if (av !== bv) return av.localeCompare(bv);
      return Number(a.invocation_id || 0) - Number(b.invocation_id || 0);
    });

    $("#aoMissionConversationLabel").text(MISSION_ACTIVE_CONVERSATION_ID || "Select a log row");
    $("#aoMissionShowMap").prop("disabled", !MISSION_ACTIVE_CONVERSATION_ID);
    if (!MISSION_ACTIVE_CONVERSATION_ID) {
      $detail.html("<div class='ao-muted-box'>Pick an execution from the board to open Conversation Debug.</div>");
      $panel.removeClass("ao-mission-has-selection");
    } else {
      var events = [];
      setMissionPaneSplit(MISSION_LOG_PANE_PCT);
      detailRows.forEach(function(row) {
        var promptText = String(row.prompt || "").trim();
        var responseText = String(row.prompt_response || "").trim();
        if (promptText) {
          events.push({
            type: "prompt",
            at: missionEventTimeValue(row.created),
            row: row,
            text: promptText
          });
        }
        if (responseText) {
          events.push({
            type: "response",
            at: missionEventTimeValue(row.created),
            row: row,
            text: responseText
          });
        }
      });
      detailToolRows.forEach(function(row) {
        events.push({
          type: "tool",
          at: missionEventTimeValue(row.start_date),
          row: row
        });
      });
      events.sort(function(a, b) {
        var typeOrder = { prompt: 0, response: 1, tool: 2 };
        var ao = typeOrder[a.type] == null ? 9 : typeOrder[a.type];
        var bo = typeOrder[b.type] == null ? 9 : typeOrder[b.type];
        if (ao !== bo) return ao - bo;
        if (a.at !== b.at) return a.at.localeCompare(b.at);
        return 0;
      });

      var detailHtml = "";
      var stepCounter = 0;
      events.forEach(function(ev) {
        if (ev.type === "prompt") {
          var row = ev.row;
          var st = normalizeMissionStatus(row);
          stepCounter += 1;
          detailHtml += "<div class='ao-mission-turn'>";
          detailHtml += "<div class='ao-mission-turn__head'>Step " + stepCounter + " • " + apex.util.escapeHTML(String(row.created || "")) + " • " + apex.util.escapeHTML(String(row.prompt_action || "")) + " • <span class='ao-mission-badge ao-mission-badge--" + escapeAttr(st) + "'>" + apex.util.escapeHTML(st) + "</span></div>";
          detailHtml += "<div class='ao-mission-turn__body'><strong>Prompt:</strong>\n" + apex.util.escapeHTML(ev.text) + "</div>";
          detailHtml += "</div>";
          return;
        }

        if (ev.type === "response") {
          var responseRow = ev.row;
          var responseStatus = normalizeMissionStatus(responseRow);
          stepCounter += 1;
          detailHtml += "<div class='ao-mission-turn'>";
          detailHtml += "<div class='ao-mission-turn__head'>Step " + stepCounter + " • " + apex.util.escapeHTML(String(responseRow.created || "")) + " • " + apex.util.escapeHTML(String(responseRow.prompt_action || "")) + " • <span class='ao-mission-badge ao-mission-badge--" + escapeAttr(responseStatus) + "'>" + apex.util.escapeHTML(responseStatus) + "</span></div>";
          detailHtml += "<div class='ao-mission-turn__body'><strong>Response:</strong>\n" + apex.util.escapeHTML(ev.text) + "</div>";
          detailHtml += "</div>";
          return;
        }

        var tool = ev.row;
        var toolInput = String(tool.tool_input || "").trim();
        var toolOutput = String(tool.tool_output || tool.tool_output_alt || "").trim();
        if (!toolInput && !toolOutput) return;
        stepCounter += 1;
        detailHtml += "<div class='ao-mission-turn'>";
        detailHtml += "<div class='ao-mission-turn__head'>Step " + stepCounter + " • " + apex.util.escapeHTML(String(tool.start_date || "")) + " • TOOL • " + apex.util.escapeHTML(String(tool.tool_name || "")) + "</div>";
        detailHtml += "<div class='ao-mission-turn__body'><strong>Agent/Task:</strong> " + apex.util.escapeHTML(String(tool.agent_name || "")) + " / " + apex.util.escapeHTML(String(tool.task_name || "")) + "</div>";
        if (toolInput) {
          detailHtml += "<div class='ao-mission-turn__body'><strong>Tool Input:</strong>\n" + apex.util.escapeHTML(toolInput) + "</div>";
        }
        if (toolOutput) {
          detailHtml += "<div class='ao-mission-turn__body'><strong>Tool Output:</strong>\n" + apex.util.escapeHTML(toolOutput) + "</div>";
        }
        detailHtml += "</div>";
      });
      $detail.html(detailHtml || "<div class='ao-muted-box'>No steps available for this conversation.</div>");
      $panel.addClass("ao-mission-has-selection");
    }
  }

  function loadMissionControl(forceReload) {
    if (!$("#aoAgentLogsPanel").length) return;
    if (!forceReload && MISSION_LOG_ROWS.length) {
      renderMissionControl();
      return;
    }
    $("#aoMissionList").html("<div class='ao-muted-box'>Loading mission logs...</div>");
    ajaxPromise(PROC.GET_AGENT_MISSION_LOGS, {}).then(function(resp) {
      MISSION_LOG_ROWS = getMissionResponseRows(resp, ["rows", "logs", "mission_logs", "agent_logs", "log_rows", "mission_log_rows", "agent_log_rows"])
        .map(normalizeMissionRow);
      MISSION_TOOL_ROWS = getMissionResponseRows(resp, ["tool_rows", "mission_tool_rows", "agent_tool_rows"])
        .map(normalizeMissionRow);
      renderMissionControl();
    }).fail(function(err) {
      $("#aoMissionList").html("<div class='ao-muted-box'>Unable to load mission logs.</div>");
      showError((err && err.responseText) || "Unable to load mission logs.");
    });
  }

  function confirmPrebuiltAgentUninstall(agent) {
    if (!agent) return;
    var run = function() {
      var stored = PREBUILT_AGENT_STATE[agent.id] || {};
      var uninstallParams = buildPrebuiltAgentActionParams(agent, (stored && stored.params) || {});
      showBusy("Uninstalling " + agent.name + "...");
      ajaxPromise(PROC.UNINSTALL_PREBUILT_AGENT, {
        x01: agent.id,
        x02: agent.version,
        p_clob_01: JSON.stringify(uninstallParams)
      }).then(function() {
        PREBUILT_AGENT_STATE[agent.id] = {
          status: "not_installed",
          installedVersion: "",
          params: uninstallParams
        };
        persistPrebuiltAgentState();
        renderPrebuiltAgents();
        showSuccess(agent.name + " uninstalled.");
        bootstrap();
      }).fail(function(err) {
        showError((err && err.responseText) || "Unable to uninstall prebuilt agent.");
      }).always(function() {
        hideBusy();
      });
    };

    if (apex.message && typeof apex.message.confirm === "function") {
      apex.message.confirm("Uninstall " + agent.name + "? This will drop the prebuilt team and its related agent objects.", function(okPressed) {
        if (okPressed) run();
      });
      return;
    }
    if (window.confirm("Uninstall " + agent.name + "?")) run();
  }

  function getNameRuleMessage(kind) {
    var label = String(kind || "name").trim();
    return label.charAt(0).toUpperCase() + label.slice(1) + " names must start with a letter and use only letters, numbers, and underscores. Spaces are not allowed.";
  }

  function clearFieldError(selector) {
    var $field = $(selector);
    $field.removeClass("is-invalid");
    $field.closest("div").find(".ao-field-error[data-for='" + escapeAttr($field.attr("id") || "") + "']").remove();
  }

  function markFieldError(selector, message) {
    var $field = $(selector);
    var id = String($field.attr("id") || "");
    if (!$field.length) return;
    clearFieldError(selector);
    $field.addClass("is-invalid");
    $field.after("<div class='ao-field-error' data-for='" + escapeAttr(id) + "'>" + apex.util.escapeHTML(message) + "</div>");
  }

  function validateIdentifierValue(value, kind) {
    var text = String(value || "").trim();
    var label = String(kind || "Name").trim();
    if (!text) return label + " is required.";
    if (/\s/.test(text)) return "Spaces are not allowed in " + label.toLowerCase() + ". Use letters, numbers, and underscores.";
    if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(text)) return getNameRuleMessage(label.toLowerCase());
    return "";
  }

  function validateNameField(selector, kind) {
    var message = validateIdentifierValue($(selector).val(), kind);
    if (message) {
      markFieldError(selector, message);
      throw new Error(message);
    }
    clearFieldError(selector);
  }

  function addNameRuleHelpers() {
    $("[data-ao-name-field]").each(function() {
      var $field = $(this);
      var kind = String($field.attr("data-ao-name-field") || "name");
      if ($field.next(".ao-name-rule").length) return;
      $field.after("<div class='ao-name-rule'>" + apex.util.escapeHTML(getNameRuleMessage(kind)) + "</div>");
    });
  }

  function addInfoTipForLabel(inputId, helpText) {
    var $label = $("label[for='" + inputId + "']");
    if (!$label.length || $label.find(".ao-info-tip").length || !helpText) return;
    $label.append(" <span class='ao-info-tip' tabindex='0' role='button' aria-label='" + escapeAttr(helpText) + "' title='" + escapeAttr(helpText) + "' data-tooltip='" + escapeAttr(helpText) + "'>Info</span>");
  }

  function addProfileBuilderTooltips() {
    var map = {
      aoCreateProvider: PROFILE_ATTR_METADATA.common.provider.help,
      aoCreateCredential: PROFILE_ATTR_METADATA.common.credential_name.help,
      aoCreateModel: PROFILE_ATTR_METADATA.common.model.help,
      aoCreateRegion: PROFILE_ATTR_METADATA.common.region.help,
      aoCreateObjectListMode: PROFILE_ATTR_METADATA.common.object_list_mode.help,
      aoCreateProviderEndpoint: PROFILE_ATTR_METADATA.common.provider_endpoint.help,
      aoCreateObjectList: PROFILE_ATTR_METADATA.common.object_list.help,
      aoCreateEmbeddingModel: PROFILE_ATTR_METADATA.RAG.embedding_model.help,
      aoCreateConversationLength: PROFILE_ATTR_METADATA.common.conversation_length.help,
      aoCreateAzureResourceName: PROFILE_ATTR_METADATA.common.azure_resource_name.help,
      aoCreateOciRuntimeType: PROFILE_ATTR_METADATA.common.oci_runtimetype.help,
      aoCreateSourceLanguage: "Language of the input text sent to the provider for translation.",
      aoCreateTargetLanguage: "Language into which the provider translates the text.",
      aoRagCreateProvider: PROFILE_ATTR_METADATA.common.provider.help,
      aoRagCreateCredential: PROFILE_ATTR_METADATA.common.credential_name.help,
      aoRagCreateModel: PROFILE_ATTR_METADATA.common.model.help,
      aoRagCreateRegion: PROFILE_ATTR_METADATA.common.region.help,
      aoRagCreateVectorIndex: PROFILE_ATTR_METADATA.RAG.vector_index_name.help,
      aoRagCreateEmbeddingModel: PROFILE_ATTR_METADATA.RAG.embedding_model.help,
      aoRagCreateObjectListMode: PROFILE_ATTR_METADATA.common.object_list_mode.help,
      aoRagCreateObjectList: PROFILE_ATTR_METADATA.common.object_list.help,
      aoRagCreateEnableSources: PROFILE_ATTR_METADATA.RAG.enable_sources.help,
      aoRagCreateEnableSourceOffsets: PROFILE_ATTR_METADATA.RAG.enable_source_offsets.help,
      aoRagCreateEnableCustomSourceUri: PROFILE_ATTR_METADATA.RAG.enable_custom_source_uri.help
    };
    Object.keys(map).forEach(function(id) {
      addInfoTipForLabel(id, map[id]);
    });
  }

  function getProviderKey(value) {
    var key = String(value || "").trim().toLowerCase();
    if (/azure/.test(key)) return "azure";
    if (/openai/.test(key)) return "openai";
    if (/cohere/.test(key)) return "cohere";
    if (/google|gemini/.test(key)) return "google";
    if (/anthropic|claude/.test(key)) return "anthropic";
    if (/huggingface/.test(key)) return "huggingface";
    if (/aws|bedrock/.test(key)) return "aws";
    if (/database/.test(key)) return "database";
    if (/oci|oracle/.test(key)) return "oci";
    return key;
  }

  function getProviderSelectOptions(currentValue) {
    var rows = PROVIDER_OPTIONS.slice();
    var current = String(currentValue || "").trim();
    if (current && !rows.some(function(row) { return String(row.value || "").toLowerCase() === current.toLowerCase(); })) {
      rows.unshift({ value: current, label: current + " (current/custom)" });
    }
    rows.unshift({ value: "", label: "- Select -" });
    return rows;
  }

  function getModelSuggestions(providerValue, currentValue) {
    var key = getProviderKey(providerValue);
    var rows = (MODEL_OPTIONS_BY_PROVIDER[key] || []).slice();
    var current = String(currentValue || "").trim();
    if (current && rows.map(function(item) { return item.toLowerCase(); }).indexOf(current.toLowerCase()) < 0) {
      rows.unshift(current);
    }
    return rows;
  }

  function renderDatalistOptions(values) {
    return (values || []).map(function(value) {
      return "<option value='" + escapeAttr(value) + "'></option>";
    }).join("");
  }

  function providerLovRows() {
    return PROVIDER_OPTIONS.map(function(option) {
      return { d: option.label || option.value, r: option.value };
    });
  }

  function isProfileAttrApplicable(profileType, attrName, config) {
    var typeKey = String(profileType || "").trim().toUpperCase();
    var appliesTo = config && Array.isArray(config.profileTypes) ? config.profileTypes : null;
    if (!appliesTo || !appliesTo.length) return true;
    return appliesTo.map(function(item) { return String(item || "").trim().toUpperCase(); }).indexOf(typeKey) >= 0;
  }

  function profileProviderScopeMatches(scope, providerValue) {
    var providerKey = getProviderKey(providerValue);
    var normalizedScope = String(scope || "").trim().toLowerCase();
    if (!normalizedScope) return true;
    if (normalizedScope === "oci") return providerKey === "oci";
    if (normalizedScope === "azure") return providerKey === "azure";
    if (normalizedScope === "non_oci") return !!providerKey && providerKey !== "oci";
    return providerKey === normalizedScope;
  }

  function refreshProfileModelDatalists(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    var cfg = getAttrUiConfig(type);
    var $container = $(cfg.container);
    var provider = String($container.find(".ao-attr-row[data-attr-name='provider'] .js-ao-attr-val").val() || "").trim();
    $container.find(".js-ao-model-field").each(function() {
      var $input = $(this);
      var listId = String($input.attr("list") || "");
      if (!listId) return;
      $("#" + listId).html(renderDatalistOptions(getModelSuggestions(provider, $input.val())));
    });
  }

  function applyProfileProviderVisibility(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    var cfg = getAttrUiConfig(type);
    var editable = isAttrEditable(type);
    var $container = $(cfg.container);
    var provider = String($container.find(".ao-attr-row[data-attr-name='provider'] .js-ao-attr-val").val() || "").trim();

    $container.find(".ao-attr-row[data-provider-scope]").each(function() {
      var $row = $(this);
      var matches = profileProviderScopeMatches($row.attr("data-provider-scope"), provider);
      $row.toggleClass("is-hidden is-provider-hidden", !matches);
      $row.find(".js-ao-attr-val").prop("disabled", !matches || !editable);
    });
  }

  function getProfileAttrConfig(profileType, name) {
    var key = String(name || "").trim();
    var typeKey = String(profileType || "").trim().toUpperCase();
    var commonConfig = PROFILE_ATTR_METADATA.common[key] || null;
    var typedConfig = (PROFILE_ATTR_METADATA[typeKey] || {})[key] || null;
    return $.extend({}, commonConfig || {}, typedConfig || {}, { key: key });
  }

  function formatProfileAttrDisplayLabel(label) {
    var text = String(label || "").trim();
    if (!text) return "";
    text = text.replace(/[_-]+/g, " ").replace(/\s+/g, " ").toLowerCase();
    text = text.replace(/\b([a-z])/g, function(match) {
      return match.toUpperCase();
    });
    return text
      .replace(/\bOci\b/g, "OCI")
      .replace(/\bApi\b/g, "API")
      .replace(/\bId\b/g, "ID")
      .replace(/\bUrl\b/g, "URL")
      .replace(/\bUri\b/g, "URI")
      .replace(/\bNl2sql\b/g, "NL2SQL")
      .replace(/\bRag\b/g, "RAG")
      .replace(/\bPlsql\b/g, "PL/SQL");
  }

  function getProfileAttrIconKey(attrName, config) {
    var key = String(attrName || "").trim().toLowerCase();
    if (key === "provider") return "cloud";
    if (key === "credential_name") return "key";
    if (key === "model" || key === "embedding_model") return "chip";
    if (key === "region") return "globe";
    if (key === "object_list_mode") return "stack";
    if (key === "object_list") return "database";
    if (key === "vector_index_name") return "vector";
    if (key === "provider_endpoint") return "link";
    if (key === "stop_tokens") return "stop";
    if (key === "conversation" || key === "conversation_length") return "chat";
    if (key === "constraints" || key === "enforce_object_list") return "shield";
    if (key === "comments" || key === "annotations") return "note";

    var type = String((config && config.type) || "").trim().toLowerCase();
    if (type === "boolean") return "toggle";
    if (type === "number") return "hash";
    if (type === "object_list") return "database";
    if (type === "model_select") return "chip";
    if (type === "select" || type === "provider_select") return "list";
    if (type === "string_array") return "list";
    return "field";
  }

  function getProfileAttrIconSvg(iconKey) {
    switch (iconKey) {
      case "cloud":
        return "<svg viewBox='0 0 24 24' focusable='false'><path d='M7.5 18h9a4 4 0 0 0 .7-7.94A5.2 5.2 0 0 0 7 8.6 3.6 3.6 0 0 0 7.5 18Z'/></svg>";
      case "key":
        return "<svg viewBox='0 0 24 24' focusable='false'><circle cx='8.1' cy='12' r='3.3'/><path d='M11.1 12H21'/><path d='M16.5 12v2.2'/><path d='M19 12v2.2'/></svg>";
      case "chip":
        return "<svg viewBox='0 0 24 24' focusable='false'><rect x='7' y='7' width='10' height='10' rx='1.6'/><path d='M9.5 3.8v2.4M14.5 3.8v2.4M9.5 17.8v2.4M14.5 17.8v2.4M3.8 9.5h2.4M17.8 9.5h2.4M3.8 14.5h2.4M17.8 14.5h2.4'/></svg>";
      case "globe":
        return "<svg viewBox='0 0 24 24' focusable='false'><circle cx='12' cy='12' r='8'/><path d='M4.6 12h14.8'/><path d='M12 4a12.5 12.5 0 0 1 0 16'/><path d='M12 4a12.5 12.5 0 0 0 0 16'/></svg>";
      case "stack":
        return "<svg viewBox='0 0 24 24' focusable='false'><path d='m12 5 7 3.5-7 3.5-7-3.5Z'/><path d='m5 12 7 3.5 7-3.5'/><path d='m5 15.5 7 3.5 7-3.5'/></svg>";
      case "database":
        return "<svg viewBox='0 0 24 24' focusable='false'><ellipse cx='12' cy='6.7' rx='6.7' ry='2.6'/><path d='M5.3 6.7v10.7c0 1.4 3 2.6 6.7 2.6s6.7-1.2 6.7-2.6V6.7'/><path d='M5.3 12c0 1.4 3 2.6 6.7 2.6s6.7-1.2 6.7-2.6'/></svg>";
      case "vector":
        return "<svg viewBox='0 0 24 24' focusable='false'><circle cx='6' cy='6' r='1.8'/><circle cx='18' cy='6' r='1.8'/><circle cx='6' cy='18' r='1.8'/><circle cx='18' cy='18' r='1.8'/><path d='M7.8 6h8.4M6 7.8v8.4M18 7.8v8.4M7.8 18h8.4'/></svg>";
      case "link":
        return "<svg viewBox='0 0 24 24' focusable='false'><path d='m10.4 13.6-2 2a3 3 0 1 1-4.2-4.2l2-2'/><path d='m13.6 10.4 2-2a3 3 0 0 1 4.2 4.2l-2 2'/><path d='M8.9 15.1h6.2'/></svg>";
      case "stop":
        return "<svg viewBox='0 0 24 24' focusable='false'><rect x='6.2' y='6.2' width='11.6' height='11.6' rx='2.3'/></svg>";
      case "chat":
        return "<svg viewBox='0 0 24 24' focusable='false'><path d='M5.6 6.2h12.8a2 2 0 0 1 2 2v7.2a2 2 0 0 1-2 2H11l-4.6 3v-3H5.6a2 2 0 0 1-2-2V8.2a2 2 0 0 1 2-2Z'/></svg>";
      case "shield":
        return "<svg viewBox='0 0 24 24' focusable='false'><path d='M12 3.8 5.4 6.3V11c0 4.2 2.8 7.7 6.6 9.2 3.8-1.5 6.6-5 6.6-9.2V6.3Z'/><path d='m9.4 11.8 1.8 1.8 3.5-3.5'/></svg>";
      case "note":
        return "<svg viewBox='0 0 24 24' focusable='false'><path d='M6.2 4.8h11.6a1.6 1.6 0 0 1 1.6 1.6v11.2a1.6 1.6 0 0 1-1.6 1.6H6.2a1.6 1.6 0 0 1-1.6-1.6V6.4a1.6 1.6 0 0 1 1.6-1.6Z'/><path d='M8.2 9h7.6M8.2 12h7.6M8.2 15h5.2'/></svg>";
      case "toggle":
        return "<svg viewBox='0 0 24 24' focusable='false'><rect x='4.2' y='8.2' width='15.6' height='7.6' rx='3.8'/><circle cx='10.1' cy='12' r='2.5'/></svg>";
      case "hash":
        return "<svg viewBox='0 0 24 24' focusable='false'><path d='M9 4.8 7.6 19.2M15.4 4.8 14 19.2M5 9.3h14M4.3 14.7h14'/></svg>";
      case "list":
        return "<svg viewBox='0 0 24 24' focusable='false'><circle cx='6.3' cy='7' r='1.1'/><circle cx='6.3' cy='12' r='1.1'/><circle cx='6.3' cy='17' r='1.1'/><path d='M9.2 7h8.8M9.2 12h8.8M9.2 17h8.8'/></svg>";
      default:
        return "<svg viewBox='0 0 24 24' focusable='false'><rect x='5.2' y='5.2' width='13.6' height='13.6' rx='2.2'/></svg>";
    }
  }

  function getProfileAttributeNames(profileType, attrs) {
    var typeKey = String(profileType || "").trim().toUpperCase();
    var names = [];
    Object.keys(PROFILE_ATTR_METADATA.common).forEach(function(name) {
      if (!isProfileAttrApplicable(typeKey, name, getProfileAttrConfig(typeKey, name))) return;
      if (names.indexOf(name) < 0) names.push(name);
    });
    Object.keys(PROFILE_ATTR_METADATA[typeKey] || {}).forEach(function(name) {
      if (!isProfileAttrApplicable(typeKey, name, getProfileAttrConfig(typeKey, name))) return;
      if (names.indexOf(name) < 0) names.push(name);
    });
    (attrs || []).forEach(function(row) {
      var name = String((row && row.attribute_name) || "").trim();
      var cfg = getProfileAttrConfig(typeKey, name);
      if (!name || names.indexOf(name) >= 0) return;
      if (!isProfileAttrApplicable(typeKey, name, cfg)) return;
      names.push(name);
    });
    return names;
  }

  function normalizeProfileAttrs(profileType, attrs) {
    var values = {};
    (attrs || []).forEach(function(row) {
      var name = String((row && row.attribute_name) || "").trim();
      if (!name) return;
      values[name] = row.attribute_value;
    });

    return getProfileAttributeNames(profileType, attrs).map(function(name) {
      return {
        attribute_name: name,
        attribute_value: Object.prototype.hasOwnProperty.call(values, name) ? values[name] : ""
      };
    });
  }

  function formatProfileAttrValue(attrName, value, config) {
    var key = String(attrName || "").trim();
    var meta = config || {};
    if (value == null) return "";

    if (key === "object_list" && Array.isArray(value)) {
      return value.map(function(item) {
        if (!item || typeof item !== "object") return "";
        if (item.owner && item.name) return item.owner + "." + item.name;
        return String(item.owner || item.name || "").trim();
      }).filter(Boolean).join("\n");
    }

    if (Array.isArray(value)) {
      return value.map(function(item) {
        return typeof item === "string" ? item : JSON.stringify(item);
      }).join("\n");
    }

    if (typeof value === "object") {
      try { return JSON.stringify(value, null, 2); } catch (e) { return String(value); }
    }

    if (meta.type === "boolean") {
      return booleanValueToSelect(value);
    }

    return String(value);
  }

  function getFieldWrapper(selector) {
    var $field = $(selector);
    return $field.closest(".ao-field, .ao-form-field, .ao-row > div, label");
  }

  function toggleCreateProviderField(selector, visible) {
    var $field = $(selector);
    var $wrapper = getFieldWrapper(selector);
    $wrapper.toggleClass("is-hidden", !visible);
    $field.prop("disabled", !visible);
  }

  function updateCreateModelList(inputSelector, providerValue) {
    var $input = $(inputSelector);
    var listId = String($input.attr("list") || "");
    if (!listId) return;
    $("#" + listId).html(renderDatalistOptions(getModelSuggestions(providerValue, $input.val())));
  }

  function applyProviderRulesFor(prefix, hintSelector) {
    var key = String(prefix || "").trim();
    if (!key) return;
    var provider = String($("#" + key + "Provider").val() || "").trim();
    var providerKey = getProviderKey(provider);
    var isOci = providerKey === "oci";
    var isNonOci = !!providerKey && !isOci;

    updateCreateModelList("#" + key + "Model", provider);
    updateCreateModelList("#" + key + "EmbeddingModel", provider);

    toggleCreateProviderField("#" + key + "ProviderEndpoint", isNonOci);
    toggleCreateProviderField("#" + key + "OciCompartment", isOci);
    toggleCreateProviderField("#" + key + "OciEndpoint", isOci);
    toggleCreateProviderField("#" + key + "OciApiFormat", isOci);

    var $hint = $(hintSelector);
    if (!$hint.length) return;

    if (isOci) {
      $hint.text("OCI selected: credential_name is required. OCI compartment, API format, and endpoint are optional.");
    } else if (provider) {
      $hint.text("Non-OCI provider selected: credential_name, model and provider_endpoint are required.");
    } else {
      $hint.text("Choose provider to apply required fields.");
    }
  }

  function applyProviderRules() {
    applyProviderRulesFor("aoCreate", "#aoCreateProviderHint");
  }

  function applyRagProviderRules() {
    applyProviderRulesFor("aoRagCreate", "#aoRagCreateProviderHint");
  }

  function applyProfileCreateDefaults() {
    if (!String($("#aoCreateObjectListMode").val() || "").trim()) {
      $("#aoCreateObjectListMode").val("all");
    }
    if (!String($("#aoRagCreateEnableSources").val() || "").trim()) {
      $("#aoRagCreateEnableSources").val("true");
    }
    updateCreateModelList("#aoCreateModel", $("#aoCreateProvider").val());
  }

  function armAgentSelectSubmitBlock() {
    AGENT_SELECT_SUBMIT_BLOCK_UNTIL = Date.now() + 1500;
  }

  function shouldBlockAgentSelectSubmit() {
    return Date.now() < Number(AGENT_SELECT_SUBMIT_BLOCK_UNTIL || 0);
  }

  function isAgentSelectorNode(node) {
    return !!(node && node.id && (node.id === "aoAgentTeamPicker" || node.id === "aoAgentFilterSelect"));
  }

  function installAgentSelectGuards() {
    if (window.__AO_AGENT_SELECT_GUARDS_INSTALLED) return;
    window.__AO_AGENT_SELECT_GUARDS_INSTALLED = true;
    document.addEventListener("change", function(event) {
      var target = event && event.target;
      if (!target || !target.id) return;
      if (!isAgentSelectorNode(target)) return;
      if (typeof event.preventDefault === "function") event.preventDefault();
      if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
      if (typeof event.stopPropagation === "function") event.stopPropagation();
    }, true);

    document.addEventListener("focusin", function(event) {
      if (!isAgentSelectorNode(event && event.target)) return;
      armAgentSelectSubmitBlock();
    }, true);

    document.addEventListener("pointerdown", function(event) {
      if (!isAgentSelectorNode(event && event.target)) return;
      armAgentSelectSubmitBlock();
    }, true);

    document.addEventListener("mousedown", function(event) {
      if (!isAgentSelectorNode(event && event.target)) return;
      armAgentSelectSubmitBlock();
    }, true);

    document.addEventListener("submit", function(event) {
      var active = document && document.activeElement ? document.activeElement : null;
      if (!shouldBlockAgentSelectSubmit() && !isAgentSelectorNode(active)) return;
      if (typeof event.preventDefault === "function") event.preventDefault();
      if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
      if (typeof event.stopPropagation === "function") event.stopPropagation();
    }, true);

    if (window.apex && apex.jQuery) {
      apex.jQuery(document).on("apexbeforepagesubmit.AO_AGENT_GUARD", function(event) {
        var active = document && document.activeElement ? document.activeElement : null;
        if (!shouldBlockAgentSelectSubmit() && !isAgentSelectorNode(active)) return;
        if (event && typeof event.preventDefault === "function") event.preventDefault();
        if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        if (event && typeof event.stopPropagation === "function") event.stopPropagation();
        return false;
      });
    }
  }

  function renderAttrs(containerSelector, attrs) {
    var $container = $(containerSelector);
    var profileType = String($container.attr("data-profile-type") || "").trim().toUpperCase();
    var profileName = selectedProfileValue(profileType);
    var isNl2sqlModern = profileType === "NL2SQL" && String($container.attr("id") || "") === "aoNl2sqlAttrs";
    var isCompactProfile = isNl2sqlModern || (profileType === "RAG" && String($container.attr("id") || "") === "aoRagAttrs");
    if (!attrs || !attrs.length) {
      $container.html("<div class='ao-muted-box'>Select a profile to load attributes.</div>");
      setAttrOriginalSnapshot(profileType, []);
      return;
    }

    var sortedAttrs = normalizeProfileAttrs(profileType, attrs).slice().sort(function (a, b) {
      var an = String((a && a.attribute_name) || "").trim();
      var bn = String((b && b.attribute_name) || "").trim();
      var ac = getProfileAttrConfig(profileType, an);
      var bc = getProfileAttrConfig(profileType, bn);
      var ap = Number(ac.priority || 999);
      var bp = Number(bc.priority || 999);
      if (ap !== bp) return ap - bp;
      return an.localeCompare(bn);
    });

    var normalHtml = "";
    var summaryHtml = "";
    var objectListHtml = "";
    var advancedHtml = "";
    var compactSummaryItems = [];
    var compactObjectCount = null;
    var compactObjectNames = [];
    var hasAdvancedValue = false;
    sortedAttrs.forEach(function (a) {
      var attrName = String(a.attribute_name || "").trim();
      var attrNameKey = attrName.toLowerCase();
      var config = getProfileAttrConfig(profileType, attrName);
      var value = formatProfileAttrValue(attrName, a.attribute_value, config);
      var rowHtml = "";
      var isLong = config.type === "object_list" ||
        config.type === "string_array" ||
        config.type === "textarea" ||
        value.indexOf("\n") >= 0 ||
        value.length > 160;
      var options = Array.isArray(config.options) ? config.options : [];
      var listId;
      var rowScope = config.providerScope ? " data-provider-scope='" + escapeAttr(config.providerScope) + "'" : "";
      var rowClass = "ao-attr-row" + (isLong ? " ao-attr-row--long" : "") + (config.advanced ? " ao-attr-row--advanced" : "");

      if (isCompactProfile) {
        if (attrNameKey === "object_list") {
          compactObjectNames = String(value || "").split(/\r?\n/).map(function(item) {
            return String(item || "").trim();
          }).filter(Boolean);
          compactObjectCount = compactObjectNames.length;
        } else {
          compactSummaryItems.push({
            label: formatProfileAttrDisplayLabel(config.label || attrName),
            value: String(value || "").trim() || getReadonlyEmptyDisplayLabel(attrName),
            advanced: !!config.advanced,
            canCopy: attrNameKey === "oci_compartment_id" && !!String(value || "").trim()
          });
        }
      }

      rowHtml += "<div class='" + rowClass + "' data-attr-name='" + escapeAttr(attrName) + "'" + rowScope + ">";
      rowHtml += "<label class='ao-attr-name'><span class='ao-attr-icon' aria-hidden='true'>" + getProfileAttrIconSvg(getProfileAttrIconKey(attrNameKey, config)) + "</span><span class='ao-attr-name-text'>" + apex.util.escapeHTML(formatProfileAttrDisplayLabel(config.label || attrName)) + "</span>";
      if (config.help && !isNl2sqlModern) {
        rowHtml += " <span class='ao-info-tip' tabindex='0' role='button' aria-label='" + escapeAttr(config.help) + "' title='" + escapeAttr(config.help) + "' data-tooltip='" + escapeAttr(config.help) + "'>Info</span>";
      }
      rowHtml += "</label>";

      if (config.type === "select") {
        rowHtml += "<select class='ao-input js-ao-attr-val'>";
        options.forEach(function(option) {
          var optionValue = String(option.value == null ? "" : option.value);
          var selected = optionValue === String(value || "") ? " selected" : "";
          rowHtml += "<option value='" + escapeAttr(optionValue) + "'" + selected + ">" + apex.util.escapeHTML(option.label || optionValue) + "</option>";
        });
        rowHtml += "</select>";
      } else if (config.type === "provider_select") {
        rowHtml += "<select class='ao-input js-ao-attr-val js-ao-provider-field'>";
        getProviderSelectOptions(value).forEach(function(option) {
          var optionValue = String(option.value == null ? "" : option.value);
          var selected = optionValue.toLowerCase() === String(value || "").toLowerCase() ? " selected" : "";
          rowHtml += "<option value='" + escapeAttr(optionValue) + "'" + selected + ">" + apex.util.escapeHTML(option.label || optionValue) + "</option>";
        });
        rowHtml += "</select>";
      } else if (config.type === "model_select") {
        listId = "aoModelListAttr" + profileType + attrName.replace(/[^A-Za-z0-9_]/g, "_");
        rowHtml += "<input class='ao-input js-ao-attr-val js-ao-model-field' type='text' list='" + escapeAttr(listId) + "' value='" + escapeAttr(value) + "' />";
        rowHtml += "<datalist id='" + escapeAttr(listId) + "'></datalist>";
      } else if (config.type === "boolean") {
        rowHtml += "<select class='ao-input js-ao-attr-val'>";
        rowHtml += "<option value=''>- Select -</option>";
        rowHtml += "<option value='true'" + (String(value) === "true" ? " selected" : "") + ">true</option>";
        rowHtml += "<option value='false'" + (String(value) === "false" ? " selected" : "") + ">false</option>";
        rowHtml += "</select>";
      } else if (config.type === "object_list") {
        var pickerId = "aoObjectListAttr" + profileType + attrName.replace(/[^A-Za-z0-9_]/g, "_");
        rowHtml += "<div class='ao-object-picker' data-object-picker-target='" + escapeAttr(pickerId) + "'>";
        rowHtml += "<div class='ao-object-picker-controls'>";
        rowHtml += "<input class='ao-input ao-object-picker-search' type='text' placeholder='Search tables, views, graphs...' />";
        rowHtml += "<select class='ao-input ao-object-picker-type' aria-label='Filter object type'><option value=''>All object types</option><option value='TABLE'>Tables</option><option value='VIEW'>Views</option><option value='CATALOG'>Data Collection</option><option value='GRAPH'>Graphs</option><option value='ANALYTIC VIEW'>Analytic views</option></select>";
        rowHtml += "</div>";
        rowHtml += "<div class='ao-object-picker-selected-head'><span>SELECTED OBJECTS</span><span class='ao-object-picker-selected-count'>0 selected</span></div>";
        rowHtml += "<div class='ao-object-picker-selected' aria-live='polite'></div>";
        rowHtml += "<div class='ao-object-picker-available'>";
        rowHtml += "<div class='ao-object-picker-available-head'><span>AVAILABLE OBJECTS</span><span class='ao-object-picker-available-count'>0 objects</span></div>";
        rowHtml += "<select class='ao-input ao-object-picker-select' multiple size='16'></select>";
        rowHtml += "</div>";
        rowHtml += "</div>";
        rowHtml += "<details class='ao-manual-object-list'><summary>Advanced / manual edit</summary>";
        rowHtml += "<textarea id='" + escapeAttr(pickerId) + "' class='ao-input ao-textarea js-ao-attr-val ao-object-list-manual' rows='" + escapeAttr(config.rows || 4) + "'>" + apex.util.escapeHTML(value) + "</textarea>";
        rowHtml += "<div class='ao-inline-note'>Select objects from the list or paste objects from another schema, one per line.</div></details>";
      } else if (isLong) {
        rowHtml += "<textarea class='ao-input ao-textarea js-ao-attr-val' rows='" + escapeAttr(config.rows || 4) + "'>" + apex.util.escapeHTML(value) + "</textarea>";
      } else if (config.type === "number") {
        rowHtml += "<input class='ao-input js-ao-attr-val' type='number' value='" + escapeAttr(value) + "'";
        if (config.step) rowHtml += " step='" + escapeAttr(config.step) + "'";
        if (config.min) rowHtml += " min='" + escapeAttr(config.min) + "'";
        rowHtml += " />";
      } else {
        rowHtml += "<input class='ao-input js-ao-attr-val' type='text' value='" + escapeAttr(value) + "' />";
      }
      if (config.type === "string_array") {
        rowHtml += "<div class='ao-inline-note'>Use comma-separated values or a JSON array, for example END, STOP or [\"END\", \"STOP\"].</div>";
      }
      rowHtml += "</div>";

      if (isNl2sqlModern && attrNameKey === "object_list") {
        objectListHtml = rowHtml;
      } else if (isNl2sqlModern) {
        summaryHtml += rowHtml;
      } else if (config.advanced) {
        if (String(value || "").trim()) hasAdvancedValue = true;
        advancedHtml += rowHtml;
      } else {
        normalHtml += rowHtml;
      }
    });

    if (isCompactProfile && profileName) {
      compactSummaryItems.unshift({
        label: "Profile Name",
        value: profileName,
        advanced: false
      });
    }

    if (isNl2sqlModern) {
      var layoutHtml = "";
      var visibleCompactItems = compactSummaryItems.slice();
      if (compactObjectCount != null) {
        visibleCompactItems.push({
          label: "Accessible Objects",
          value: compactObjectCount + (compactObjectCount === 1 ? " object" : " objects")
        });
      }
      layoutHtml += "<div class='ao-nl2sql-modern-layout'>";
      layoutHtml += "<section class='ao-nl2sql-read-summary'>";
      layoutHtml += "<div class='ao-nl2sql-read-summary-grid'>";
      visibleCompactItems.forEach(function(item) {
        var displayValue = String(item.value || "");
        if (displayValue.length > 90) displayValue = displayValue.slice(0, 87) + "...";
        layoutHtml += "<div class='ao-nl2sql-read-summary-item'>";
        layoutHtml += "<span class='ao-summary-item-label'>" + apex.util.escapeHTML(item.label) + (item.canCopy ? getSummaryCopyButtonHtml(item.value) : "") + "</span>";
        layoutHtml += "<strong title='" + escapeAttr(String(item.value || "")) + "'>" + apex.util.escapeHTML(displayValue) + "</strong>";
        layoutHtml += "</div>";
      });
      layoutHtml += visibleCompactItems.length ? "" : "<div class='ao-muted-box'>No configured values available.</div>";
      layoutHtml += "</div>";
      layoutHtml += "<div class='ao-compact-selected-objects'>";
      layoutHtml += "<div class='ao-compact-selected-objects-head'><strong>Selected Objects</strong><span>" + compactObjectNames.length + " selected</span></div>";
      layoutHtml += "<div class='ao-compact-selected-object-list'>";
      compactObjectNames.forEach(function(objectName) {
        layoutHtml += "<span class='ao-compact-selected-object-chip'>" + apex.util.escapeHTML(objectName) + "</span>";
      });
      layoutHtml += compactObjectNames.length ? "" : "<span class='ao-object-picker-empty'>No objects selected.</span>";
      layoutHtml += "</div></div>";
      layoutHtml += "</section>";
      layoutHtml += "<div class='ao-nl2sql-edit-layout'>";
      layoutHtml += "<section class='ao-nl2sql-summary-card'>";
      layoutHtml += "<div class='ao-nl2sql-summary-grid'>";
      layoutHtml += summaryHtml || "<div class='ao-muted-box'>No summary attributes available.</div>";
      layoutHtml += "</div>";
      layoutHtml += "</section>";
      layoutHtml += "<section class='ao-nl2sql-object-card'>";
      layoutHtml += "<div class='ao-nl2sql-object-card-head'>";
      layoutHtml += "<h5 class='ao-nl2sql-section-title'>Object List</h5>";
      layoutHtml += "<span id='aoNl2sqlSelectedCount' class='ao-nl2sql-selected-count'>0 Total selected objects</span>";
      layoutHtml += "</div>";
      layoutHtml += objectListHtml || "<div class='ao-muted-box'>Object list attribute is not available.</div>";
      if (normalHtml) {
        layoutHtml += "<div class='ao-nl2sql-extra-grid'>" + normalHtml + "</div>";
      }
      if (advancedHtml) {
        layoutHtml += "<details class='ao-advanced-settings ao-attr-advanced'" + (hasAdvancedValue ? " open" : "") + "><summary>Advanced settings</summary>" + advancedHtml + "</details>";
      }
      layoutHtml += "</section>";
      layoutHtml += "</div>";
      layoutHtml += "</div>";
      $container.html(layoutHtml);
    } else if (isCompactProfile) {
      var ragLayoutHtml = "<div class='ao-nl2sql-modern-layout'>";
      ragLayoutHtml += "<section class='ao-nl2sql-read-summary'><div class='ao-nl2sql-read-summary-grid'>";
      compactSummaryItems.forEach(function(item) {
        var displayValue = String(item.value || "");
        if (displayValue.length > 90) displayValue = displayValue.slice(0, 87) + "...";
        ragLayoutHtml += "<div class='ao-nl2sql-read-summary-item'>";
        ragLayoutHtml += "<span class='ao-summary-item-label'>" + apex.util.escapeHTML(item.label) + (item.canCopy ? getSummaryCopyButtonHtml(item.value) : "") + "</span>";
        ragLayoutHtml += "<strong title='" + escapeAttr(String(item.value || "")) + "'>" + apex.util.escapeHTML(displayValue) + "</strong>";
        ragLayoutHtml += "</div>";
      });
      if (compactObjectCount != null) {
        ragLayoutHtml += "<div class='ao-nl2sql-read-summary-item'><span>Accessible Objects</span><strong>" + apex.util.escapeHTML(compactObjectCount + (compactObjectCount === 1 ? " object" : " objects")) + "</strong></div>";
      }
      ragLayoutHtml += compactSummaryItems.length || compactObjectCount != null ? "" : "<div class='ao-muted-box'>No profile attributes available.</div>";
      ragLayoutHtml += "</div>";
      if (compactObjectCount != null) {
        ragLayoutHtml += "<div class='ao-compact-selected-objects'><div class='ao-compact-selected-objects-head'><strong>Selected Objects</strong><span>" + compactObjectNames.length + " selected</span></div><div class='ao-compact-selected-object-list'>";
        compactObjectNames.forEach(function(objectName) {
          ragLayoutHtml += "<span class='ao-compact-selected-object-chip'>" + apex.util.escapeHTML(objectName) + "</span>";
        });
        ragLayoutHtml += compactObjectNames.length ? "" : "<span class='ao-object-picker-empty'>No objects selected.</span>";
        ragLayoutHtml += "</div></div>";
      }
      ragLayoutHtml += "</section>";
      ragLayoutHtml += "<div class='ao-nl2sql-edit-layout'>";
      ragLayoutHtml += normalHtml;
      if (advancedHtml) {
        ragLayoutHtml += "<details class='ao-advanced-settings ao-attr-advanced'" + (hasAdvancedValue ? " open" : "") + "><summary>Advanced settings</summary>" + advancedHtml + "</details>";
      }
      ragLayoutHtml += "</div></div>";
      $container.html(ragLayoutHtml);
    } else {
      if (advancedHtml) {
        normalHtml += "<details class='ao-advanced-settings ao-attr-advanced'" + (hasAdvancedValue ? " open" : "") + "><summary>Advanced settings</summary>" + advancedHtml + "</details>";
      }
      $container.html(normalHtml);
    }
    refreshObjectPickers();
    refreshProfileModelDatalists(profileType);
    applyProfileProviderVisibility(profileType);
    setAttrOriginalSnapshot(profileType, attrs);
    syncAttrEditUi(profileType);
  }

  function parseJsonArraySafe(val) {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    try {
      var parsed = JSON.parse(val);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      return [];
    }
  }

  function normalizeAgentEntityKey(key) {
    return String(key || "").trim().toLowerCase().replace(/[^a-z0-9]+/g, "");
  }

  function getAgentRowValue(row, candidates) {
    if (!row || typeof row !== "object") return "";
    var keys = Object.keys(row);
    if (!keys.length) return "";
    var wanted = (Array.isArray(candidates) ? candidates : [candidates]).map(normalizeAgentEntityKey);
    for (var i = 0; i < keys.length; i += 1) {
      var rawKey = keys[i];
      var normalizedKey = normalizeAgentEntityKey(rawKey);
      if (wanted.indexOf(normalizedKey) < 0) continue;
      return row[rawKey];
    }
    return "";
  }

  function parseJsonValueSafe(value) {
    if (value == null) return null;
    if (typeof value === "object") return value;
    var text = String(value || "").trim();
    if (!text) return null;
    if ((text.charAt(0) === "{" && text.charAt(text.length - 1) === "}") ||
        (text.charAt(0) === "[" && text.charAt(text.length - 1) === "]")) {
      try { return JSON.parse(text); } catch (e) {}
    }
    return null;
  }

  function stringifyAgentValue(value) {
    if (value == null) return "";
    if (typeof value === "string") {
      var trimmed = value.trim();
      if (!trimmed) return "";
      var parsed = parseJsonValueSafe(trimmed);
      if (parsed) return JSON.stringify(parsed, null, 2);
      return trimmed
        .replace(/\\r\\n/g, "\n")
        .replace(/\\n/g, "\n")
        .replace(/\\t/g, "\t");
    }
    if (typeof value === "object") {
      try { return JSON.stringify(value, null, 2); } catch (e) { return String(value); }
    }
    return String(value);
  }

  function normalizeAgentAttrsForTextarea(rows) {
    var attrs = [];
    (rows || []).forEach(function(row) {
      if (!row || typeof row !== "object") return;
      var attrName = String(getAgentRowValue(row, ["attribute_name", "attr_name", "name"]) || "").trim();
      if (!attrName) return;
      var attrValue = stringifyAgentValue(getAgentRowValue(row, ["attribute_value", "attr_value", "value", "val"]));
      var attrDesc = stringifyAgentValue(getAgentRowValue(row, ["description", "comments", "details"]));
      attrs.push({ k: attrName, v: attrValue });
      if (attrDesc) attrs.push({ k: attrName + " description", v: attrDesc });
    });
    return attrs;
  }

  function buildEntityAttrMap(rows, entityNameKeys) {
    var map = {};
    (rows || []).forEach(function(row) {
      if (!row || typeof row !== "object") return;
      var entityName = String(getAgentRowValue(row, entityNameKeys) || "").trim();
      if (!entityName) entityName = "__GLOBAL__";
      if (!map[entityName]) map[entityName] = [];
      var attrName = String(getAgentRowValue(row, ["attribute_name", "attr_name", "name"]) || "").trim();
      var attrValue = getAgentRowValue(row, ["attribute_value", "attr_value", "value", "val"]);
      var attrDesc = getAgentRowValue(row, ["description", "comments", "details"]);
      if (attrName) {
        map[entityName].push({
          k: attrName,
          v: stringifyAgentValue(attrValue),
          d: stringifyAgentValue(attrDesc)
        });
      }
    });
    return map;
  }

  function collectEntityNames(rows, nameCandidates) {
    var out = [];
    (rows || []).forEach(function(row) {
      var name = String(getAgentRowValue(row, nameCandidates) || "").trim();
      if (!name) return;
      if (out.indexOf(name) >= 0) return;
      out.push(name);
    });
    return out;
  }

  function parseAgentMappingsFromTeamAttrs(teamAttrRows) {
    var mappings = [];
    (teamAttrRows || []).forEach(function(row) {
      var attrName = String(getAgentRowValue(row, ["attribute_name", "attr_name", "name"]) || "").trim().toLowerCase();
      if (attrName !== "agents") return;
      var attrValue = getAgentRowValue(row, ["attribute_value", "attr_value", "value", "val"]);
      var parsed = parseJsonValueSafe(attrValue);
      if (!Array.isArray(parsed)) return;
      parsed.forEach(function(item) {
        if (!item || typeof item !== "object") return;
        var name = String(item.name || item.agent_name || item.agent || "").trim();
        var task = String(item.task || item.task_name || item.agent_task_name || "").trim();
        if (!name) return;
        mappings.push({ name: name, task: task });
      });
    });
    return mappings;
  }

  function normalizeAgentName(value) {
    return String(value || "").trim().toUpperCase();
  }

  function buildAgentProfileLookup(rows) {
    var out = {};
    (rows || []).forEach(function(row) {
      var agentName = String((row && (row.r || row.d)) || "").trim();
      var profileName = String((row && (row.profile_name || row.PROFILE_NAME)) || "").trim();
      if (agentName && profileName) {
        out[normalizeAgentName(agentName)] = profileName;
      }
    });
    return out;
  }

  function addUniqueCardAttr(attrs, key, value) {
    var k = String(key || "").trim();
    var v = stringifyAgentValue(value);
    if (!k || !v) return;
    var marker = k + "||" + v;
    var exists = attrs.some(function(item) {
      return (String(item.k || "").trim() + "||" + String(item.v || "").trim()) === marker;
    });
    if (!exists) attrs.push({ k: k, v: v });
  }

  function addRowFieldsAsAttrs(row, attrs, skipKeys) {
    if (!row || typeof row !== "object") return;
    var skip = (Array.isArray(skipKeys) ? skipKeys : []).map(normalizeAgentEntityKey);
    var hiddenKeys = {
      created: true,
      lastmodified: true,
      oraclemaintained: true,
      status: true,
      agentteamid: true
    };
    Object.keys(row).forEach(function(key) {
      var normalized = normalizeAgentEntityKey(key);
      if (!key || skip.indexOf(normalized) >= 0) return;
      if (hiddenKeys[normalized]) return;
      addUniqueCardAttr(attrs, key, row[key]);
    });
  }

  function formatAgentEntityAttrValue(key, value) {
    var text = String(value == null ? "" : value).replace(/\r\n?/g, "\n").trim();
    var normalizedKey = normalizeAgentEntityKey(key);
    var isLongText = text.length > 120;
    var shouldWrapBySentence = /instruction|description|goal|summary|details|notes|prompt/.test(normalizedKey) || isLongText;
    if (!text || !shouldWrapBySentence) return text;

    return text
      .split("\n")
      .map(function(line) {
        var cleanLine = String(line || "").trim();
        if (!cleanLine) return "";
        return cleanLine.replace(/([.?!])\s+(?=[A-Z0-9])/g, "$1\n");
      })
      .join("\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function renderAgentEntityCards(selector, cards, emptyText) {
    if (!cards || !cards.length) {
      $(selector).html("<div class='ao-muted-box'>" + apex.util.escapeHTML(emptyText || "No data found.") + "</div>");
      return;
    }
    var html = "<div class='ao-entity-grid'>";
    cards.forEach(function(card) {
      var rawTitle = String(card.title || "Item");
      var title = apex.util.escapeHTML(rawTitle);
      var attrs = Array.isArray(card.attrs) ? card.attrs : [];
      html += "<article class='ao-entity-card' data-entity-name='" + escapeAttr(rawTitle) + "'>";
      html += "<h5 class='ao-entity-title'>" + title + "</h5>";
      if (!attrs.length) {
        html += "<div class='ao-muted-box'>No attributes found.</div>";
      } else {
        html += "<div class='ao-entity-kv'>";
        attrs.forEach(function(item) {
          var key = String(item.k || "");
          var formattedValue = formatAgentEntityAttrValue(key, item.v);
          html += "<div class='ao-entity-k'>" + apex.util.escapeHTML(key) + "</div>";
          html += "<div class='ao-entity-v'>" + apex.util.escapeHTML(formattedValue) + "</div>";
        });
        html += "</div>";
      }
      html += "</article>";
    });
    html += "</div>";
    $(selector).html(html);
  }

  function renderMapNode(type, name, agentName, isEmpty) {
    var normalizedType = String(type || "").trim().toUpperCase();
    var safeName = String(name || "").trim();
    var safeAgent = String(agentName || "").trim();
    var typeLabel = normalizedType.charAt(0) + normalizedType.slice(1).toLowerCase();
    var html = "<div class='ao-team-node ao-team-node--" + normalizedType.toLowerCase() + (isEmpty ? " ao-team-node--empty" : "") + "'";
    if (!isEmpty) {
      html += " role='button' tabindex='0'";
      html += " data-map-type='" + escapeAttr(normalizedType) + "'";
      html += " data-map-name='" + escapeAttr(safeName) + "'";
      html += " data-map-search='" + escapeAttr((normalizedType + " " + safeName + " " + safeAgent).toLowerCase()) + "'";
      if (safeAgent) html += " data-map-agent='" + escapeAttr(safeAgent) + "'";
    }
    html += ">";
    html += "<span class='ao-team-node-type'>" + apex.util.escapeHTML(typeLabel) + "</span>";
    html += "<strong>" + apex.util.escapeHTML(safeName || ("No " + typeLabel.toLowerCase())) + "</strong>";
    if (!isEmpty && CAN_MANAGE_SETTINGS) {
      html += "<span role='button' tabindex='0' class='ao-map-edit ao-admin-only' title='Edit " + escapeAttr(typeLabel) + "' aria-label='Edit " + escapeAttr(typeLabel) + "' data-map-edit-type='" + escapeAttr(normalizedType) + "' data-map-edit-name='" + escapeAttr(safeName) + "'>";
      html += "<svg viewBox='0 0 16 16' focusable='false' aria-hidden='true'><path d='M8.2 3.1H4.1a1.3 1.3 0 0 0-1.3 1.3v7.5a1.3 1.3 0 0 0 1.3 1.3h7.5a1.3 1.3 0 0 0 1.3-1.3V7.8'></path><path d='M7.2 9.2 12.4 4l1.6 1.6-5.2 5.2-2 .4.4-2Z'></path></svg>";
      html += "</span>";
    }
    html += "</div>";
    return html;
  }

  function applyTeamMapZoom() {
    var zoomPct = Math.round(TEAM_MAP_ZOOM * 100);
    var $map = $("#aoAgentTeamMap");
    $map.css("--ao-team-map-zoom", TEAM_MAP_ZOOM);
    $("#aoTeamMapZoomLabel").text(zoomPct + "%");
    scheduleAgentTeamMapLinkRedraw();
  }

  function scheduleAgentTeamMapLinkRedraw() {
    TEAM_MAP_LINK_REDRAW_TIMERS.forEach(function(timerId) {
      window.clearTimeout(timerId);
    });
    TEAM_MAP_LINK_REDRAW_TIMERS = [];
    window.requestAnimationFrame(function() {
      window.requestAnimationFrame(drawAgentTeamMapLinks);
    });
    [50, 150, 350, 700].forEach(function(delay) {
      TEAM_MAP_LINK_REDRAW_TIMERS.push(window.setTimeout(drawAgentTeamMapLinks, delay));
    });
  }

  function observeAgentTeamMapLayout() {
    if (typeof ResizeObserver === "undefined") return;
    if (TEAM_MAP_LINK_RESIZE_OBSERVER) {
      try { TEAM_MAP_LINK_RESIZE_OBSERVER.disconnect(); } catch (e) {}
    }
    TEAM_MAP_LINK_RESIZE_OBSERVER = new ResizeObserver(function() {
      scheduleAgentTeamMapLinkRedraw();
    });
    var map = $("#aoAgentTeamMap")[0];
    var tree = $("#aoAgentTeamMap .ao-team-tree")[0];
    if (map) TEAM_MAP_LINK_RESIZE_OBSERVER.observe(map);
    if (tree) TEAM_MAP_LINK_RESIZE_OBSERVER.observe(tree);
  }

  function applyTeamMapOrientationUi() {
    var isVertical = TEAM_MAP_ORIENTATION === "vertical";
    var $map = $("#aoAgentTeamMap");
    var $btn = $("#aoTeamMapOrientationToggle");
    $map.toggleClass("ao-map-orientation-vertical", isVertical);
    $map.toggleClass("ao-map-orientation-horizontal", !isVertical);
    if ($btn.length) {
      $btn
        .text("⟳")
        .attr("title", isVertical ? "Map orientation: Vertical (switch to Horizontal)" : "Map orientation: Horizontal (switch to Vertical)")
        .attr("aria-label", isVertical ? "Switch map orientation to horizontal" : "Switch map orientation to vertical");
    }
  }

  function adjustTeamMapZoom(delta) {
    TEAM_MAP_ZOOM = Math.max(0.6, Math.min(1.6, Math.round((TEAM_MAP_ZOOM + delta) * 10) / 10));
    applyTeamMapZoom();
    centerAgentTeamMapView();
  }

  function centerAgentTeamMapView() {
    var map = $("#aoAgentTeamMap")[0];
    var tree = $("#aoAgentTeamMap .ao-team-tree")[0];
    var targetLeft;
    var targetTop;
    if (!map || !tree) return;
    targetLeft = Math.max(0, Math.round((tree.scrollWidth - map.clientWidth) / 2));
    targetTop = Math.max(0, Math.round((tree.scrollHeight - map.clientHeight) / 2));
    map.scrollLeft = targetLeft;
    map.scrollTop = targetTop;
  }

  function fitAgentTeamMapView() {
    var map = $("#aoAgentTeamMap")[0];
    var tree = $("#aoAgentTeamMap .ao-team-tree")[0];
    var rawScale;
    if (!map || !tree) return;
    rawScale = Math.min(
      (map.clientWidth - 40) / Math.max(tree.scrollWidth, 1),
      (map.clientHeight - 40) / Math.max(tree.scrollHeight, 1)
    );
    TEAM_MAP_ZOOM = Math.max(0.6, Math.min(1.4, Math.round(rawScale * 10) / 10 || 1));
    applyTeamMapZoom();
    window.setTimeout(centerAgentTeamMapView, 0);
  }

  function ensureTeamMapControlsDocked() {
    var $host = $("#aoAgentTeamWorkspace .ao-map-head-actions").first();
    var $controls;
    if (!$host.length) return;
    $controls = $("#aoTeamMapZoomOut").closest(".ao-map-zoom");
    if (!$controls.length) {
      $controls = $(
        "<div class='ao-map-zoom' aria-label='Map zoom'>" +
          "<button id='aoTeamMapZoomOut' type='button' class='ao-link-btn'>-</button>" +
          "<span id='aoTeamMapZoomLabel'>70%</span>" +
          "<button id='aoTeamMapZoomIn' type='button' class='ao-link-btn'>+</button>" +
          "<button id='aoTeamMapFitView' type='button' class='ao-link-btn ao-map-fit-btn' title='Fit to View' aria-label='Recenter and fit to view'>⤢</button>" +
          "<button id='aoTeamMapOrientationToggle' type='button' class='ao-link-btn ao-map-orientation-btn' title='Map orientation: Horizontal (switch to Vertical)' aria-label='Switch map orientation to vertical'>⟳</button>" +
          "<button id='aoTeamMapExpandCanvas' type='button' class='ao-link-btn ao-square-icon-btn' aria-label='Expand playground' title='Expand playground' aria-pressed='false'></button>" +
        "</div>"
      );
      $host.append($controls);
    }
    if ($controls.parent().is($host)) {
      applyTeamMapOrientationUi();
      return;
    }
    $host.append($controls);
    applyTeamMapOrientationUi();
  }

  function syncTeamMapExpandControls() {
    var expanded = $("#aoAgentTeamWorkspace").hasClass("is-map-expanded");
    $("#aoTeamMapExpandCanvas")
      .attr("aria-pressed", expanded ? "true" : "false")
      .attr("aria-label", expanded ? "Collapse playground" : "Expand playground")
      .attr("title", expanded ? "Collapse playground" : "Expand playground");
  }

  function collapseTeamMapExpanded() {
    var $workspace = $("#aoAgentTeamWorkspace");
    if (!$workspace.length || !$workspace.hasClass("is-map-expanded")) {
      syncTeamMapExpandControls();
      return;
    }
    $workspace.removeClass("is-map-expanded");
    $("body").removeClass("ao-map-expanded-lock");
    syncTeamMapExpandControls();
    window.requestAnimationFrame(function() {
      drawAgentTeamMapLinks();
      centerAgentTeamMapView();
    });
  }

  function toggleTeamMapExpanded() {
    var $workspace = $("#aoAgentTeamWorkspace");
    if (!$workspace.length) return;
    var expanded = !$workspace.hasClass("is-map-expanded");
    $workspace.toggleClass("is-map-expanded", expanded);
    $("body").toggleClass("ao-map-expanded-lock", expanded);
    syncTeamMapExpandControls();
    window.requestAnimationFrame(function() {
      drawAgentTeamMapLinks();
      centerAgentTeamMapView();
    });
  }

  function renderAgentTeamMap() {
    var $mapEl = $("#aoAgentTeamMap");
    TEAM_MAP_ZOOM = 0.7;
    ensureTeamMapControlsDocked();
    applyTeamMapZoom();

    if (!CURRENT_AGENT_TEAM_DATA) {
      $mapEl.html("<div class='ao-muted-box'>Select an agent team to view the map.</div>");
      return;
    }

    var teamName = getCurrentTeamName();
    var mappings = parseAgentMappingsFromTeamAttrs(CURRENT_AGENT_TEAM_DATA.teamAttrRows);
    if (!mappings.length) {
      $mapEl.html("<div class='ao-muted-box'>No agent/task mappings found for this team.</div>");
      return;
    }

    var html = "<div class='ao-team-tree ao-team-tree--rooted' role='tree' aria-label='Agent team map'>";
    html += "<svg id='aoAgentTeamMapLinkSvg' class='ao-team-map-svg' aria-hidden='true'></svg>";
    html += "<div class='ao-team-root'>" + renderMapNode("TEAM", teamName || "Team", "", false) + "</div>";
    html += "<div class='ao-team-branches'>";
    mappings.forEach(function(mapping) {
      var agentName = String(mapping.name || "").trim();
      var taskName = String(mapping.task || "").trim();
      var tools = taskName ? collectToolNamesFromTaskAttrs(CURRENT_AGENT_TEAM_DATA.taskAttrRows, [taskName]) : [];

      html += "<div class='ao-team-branch'>";
      html += "<span class='ao-team-branch-line ao-team-branch-line--from-root' aria-hidden='true'></span>";
      html += renderMapNode("AGENT", agentName || "Agent", agentName, false);
      html += "<span class='ao-team-connector' aria-hidden='true'></span>";
      html += renderMapNode("TASK", taskName || "No task", agentName, false);
      html += "<div class='ao-team-tool-tree'>";
      if (tools.length) {
        html += "<div class='ao-team-tool-stack" + (tools.length === 1 ? " ao-team-tool-stack--single" : "") + "'>";
        tools.forEach(function(toolName) {
          html += "<div class='ao-team-tool-branch'>";
          html += "<span class='ao-team-tool-line' aria-hidden='true'></span>";
          html += renderMapNode("TOOL", toolName, agentName, false);
          html += "</div>";
        });
        html += "</div>";
      } else {
        html += "<div class='ao-team-tool-stack ao-team-tool-stack--single'>";
        html += "<div class='ao-team-tool-branch'>";
        html += "<span class='ao-team-tool-line' aria-hidden='true'></span>";
        html += renderMapNode("TOOL", "No tools", agentName, true);
        html += "</div>";
        html += "</div>";
      }
      html += "</div>";
      html += "</div>";
    });
    html += "</div>";
    html += "</div>";
    $mapEl.html(html);
    ensureTeamMapControlsDocked();
    applyTeamMapOrientationUi();
    syncTeamMapExpandControls();
    applyAgentTeamMapSearch();
    observeAgentTeamMapLayout();
    window.requestAnimationFrame(function() {
      drawAgentTeamMapLinks();
      centerAgentTeamMapView();
    });
    scheduleAgentTeamMapLinkRedraw();
  }

  function drawAgentTeamMapLinks() {
    var tree = $("#aoAgentTeamMap .ao-team-tree")[0];
    var svg = $("#aoAgentTeamMapLinkSvg")[0];
    var rootNode = $("#aoAgentTeamMap .ao-team-root .ao-team-node")[0];
    var zoom = TEAM_MAP_ZOOM || 1;
    var treeRect;
    var width;
    var height;
    var paths = [];
    var pathIndex = 0;
    var isVertical = TEAM_MAP_ORIENTATION === "vertical";
    if (!tree || !svg || !rootNode) return false;
    treeRect = tree.getBoundingClientRect();
    if (treeRect.width <= 1 || treeRect.height <= 1) return false;
    if (rootNode.getBoundingClientRect().width <= 1 || rootNode.getBoundingClientRect().height <= 1) return false;
    width = Math.max(tree.scrollWidth, Math.ceil(treeRect.width / zoom));
    height = Math.max(tree.scrollHeight, Math.ceil(treeRect.height / zoom));

    function point(el, side) {
      var rect;
      if (!el) return null;
      rect = el.getBoundingClientRect();
      if (side === "top") {
        return {
          x: (rect.left - treeRect.left) / zoom + rect.width / (2 * zoom),
          y: (rect.top - treeRect.top) / zoom
        };
      }
      if (side === "bottom") {
        return {
          x: (rect.left - treeRect.left) / zoom + rect.width / (2 * zoom),
          y: (rect.top - treeRect.top) / zoom + rect.height / zoom
        };
      }
      return {
        x: (rect.left - treeRect.left) / zoom + (side === "right" ? rect.width / zoom : 0),
        y: (rect.top - treeRect.top) / zoom + rect.height / (2 * zoom)
      };
    }

    function addPath(a, b, kind) {
      var id;
      var delta;
      var dir;
      var d;
      if (!a || !b) return;
      id = "aoTeamMapPath" + pathIndex;
      pathIndex += 1;
      if (isVertical) {
        delta = Math.max(54, Math.abs(b.y - a.y) * 0.48);
        dir = b.y >= a.y ? 1 : -1;
        d = "M " + a.x + " " + a.y + " C " + a.x + " " + (a.y + delta * dir) + ", " + b.x + " " + (b.y - delta * dir) + ", " + b.x + " " + b.y;
      } else {
        delta = Math.max(54, Math.abs(b.x - a.x) * 0.48);
        d = "M " + a.x + " " + a.y + " C " + (a.x + delta) + " " + a.y + ", " + (b.x - delta) + " " + b.y + ", " + b.x + " " + b.y;
      }
      paths.push("<path id='" + id + "' class='ao-team-map-path ao-team-map-path--" + kind + "' marker-end='url(#aoTeamMapArrow)' d='" + d + "' />");
    }

    $("#aoAgentTeamMap .ao-team-branch").each(function(branchIndex) {
      var branch = $(this);
      var agentNode = branch.find(".ao-team-node--agent")[0];
      var taskNode = branch.find(".ao-team-node--task")[0];
      var rootOut = point(rootNode, isVertical ? "bottom" : "right");
      var agentIn = point(agentNode, isVertical ? "top" : "left");
      var agentOut = point(agentNode, isVertical ? "bottom" : "right");
      var taskIn = point(taskNode, isVertical ? "top" : "left");
      var taskOut = point(taskNode, isVertical ? "bottom" : "right");
      addPath(rootOut, agentIn, "main");
      addPath(agentOut, taskIn, "main");
      branch.find(".ao-team-node--tool").each(function(toolIndex) {
        addPath(taskOut, point(this, isVertical ? "top" : "left"), "tool");
      });
    });

    svg.setAttribute("viewBox", "0 0 " + width + " " + height);
    svg.setAttribute("width", width);
    svg.setAttribute("height", height);
    svg.innerHTML = "<defs><marker id='aoTeamMapArrow' viewBox='0 0 12 12' refX='10.5' refY='6' markerWidth='8' markerHeight='8' orient='auto-start-reverse'><path d='M 0 0 L 12 6 L 0 12 z' class='ao-team-map-arrow' /></marker></defs>" + paths.join("");
    return paths.length > 0;
  }

  function applyAgentTeamMapSearch() {
    var $search = $("#aoAgentTeamMapSearch");
    var query = String($search.length ? $search.val() : AGENT_TEAM_MAP_SEARCH_TEXT || "").trim().toLowerCase();
    var totalMatches = 0;
    AGENT_TEAM_MAP_SEARCH_TEXT = query;
    $("#aoAgentTeamMap .ao-team-node[data-map-type]").each(function() {
      var $node = $(this);
      var haystack = String($node.attr("data-map-search") || "").toLowerCase();
      var matched = !query || haystack.indexOf(query) >= 0;
      $node.toggleClass("is-search-match", !!query && matched);
      $node.toggleClass("is-search-dimmed", !!query && !matched);
      if (query && matched) totalMatches += 1;
    });
    $("#aoAgentTeamMap").toggleClass("is-searching", !!query);
    if (!query) {
      $("#aoAgentTeamMapSearchState").text("");
    } else if (totalMatches) {
      $("#aoAgentTeamMapSearchState").text(totalMatches + " matching node" + (totalMatches === 1 ? "" : "s") + " highlighted.");
    } else {
      $("#aoAgentTeamMapSearchState").text("No matches found.");
    }
  }

  function focusAgentDetailCard(selector, entityName) {
    var targetName = String(entityName || "").trim();
    var $box = $(selector);
    var $target = $();
    if (targetName) {
      $box.find(".ao-entity-card[data-entity-name]").each(function() {
        if (String($(this).attr("data-entity-name") || "") === targetName) {
          $target = $(this);
          return false;
        }
      });
    }
    $box.find(".ao-entity-card").removeClass("is-map-selected");
    if ($target.length) $target.addClass("is-map-selected");
    if ($box.length && typeof $box[0].scrollIntoView === "function") {
      $box[0].scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }

  function showOnlyAgentDetailCard(selector, entityName) {
    var targetName = String(entityName || "").trim();
    var $box = $(selector);
    var $cards = $box.find(".ao-entity-card[data-entity-name]");
    if (!$cards.length || !targetName) return;
    $cards.each(function() {
      var cardName = String($(this).attr("data-entity-name") || "");
      $(this).toggle(cardName === targetName);
    });
  }

  function showAgentMapDetail(type) {
    var normalizedType = String(type || "").trim().toUpperCase();
    $(".ao-map-detail-section").addClass("is-hidden");
    $(".ao-map-detail-section[data-map-detail='" + normalizedType + "']").removeClass("is-hidden");
  }

  function renderMapNodeAttrsTable(title, attrs) {
    var html = "<section class='ao-map-drawer-block'><h5>" + apex.util.escapeHTML(title) + "</h5>";
    if (!Array.isArray(attrs) || !attrs.length) {
      html += "<div class='ao-map-drawer-empty'>No attributes available.</div></section>";
      return html;
    }
    html += "<div class='ao-map-drawer-kv'>";
    attrs.forEach(function(item) {
      html += "<div class='ao-map-drawer-k'>" + apex.util.escapeHTML(String(item.k || "")) + "</div>";
      html += "<div class='ao-map-drawer-v'>" + apex.util.escapeHTML(formatAgentEntityAttrValue(String(item.k || ""), item.v)) + "</div>";
    });
    html += "</div></section>";
    return html;
  }

  function closeMapNodeDrawer() {
    $("#aoMapNodeDrawer, #aoMapNodeDrawerOverlay").addClass("is-hidden").attr("aria-hidden", "true");
  }

  function openMapNodeDrawer(type, name, agentName) {
    var normalizedType = String(type || "").trim().toUpperCase();
    var title = String(name || "").trim();
    var selectedAgent = String(agentName || "").trim();
    var bodyHtml = "";
    var cards;
    var taskNames;

    if (!CURRENT_AGENT_TEAM_DATA) return;

    $("#aoMapNodeDrawerType").text(normalizedType);
    $("#aoMapNodeDrawerTitle").text(title || "Details");

    if (normalizedType === "TEAM") {
      bodyHtml += "<section class='ao-map-drawer-block'><h5>Team Description</h5><pre class='ao-map-drawer-code'>" +
        apex.util.escapeHTML(String(CURRENT_AGENT_TEAM_DATA.teamDescription || "")) + "</pre></section>";
      bodyHtml += renderMapNodeAttrsTable("Team Attributes", normalizeAgentAttrsForTextarea(CURRENT_AGENT_TEAM_DATA.teamAttrRows || []));
    } else if (normalizedType === "AGENT") {
      cards = buildAgentCards(CURRENT_AGENT_TEAM_DATA.teamAttrRows, CURRENT_AGENT_TEAM_DATA.agentAttrRows, title);
      bodyHtml += cards.length
        ? renderMapNodeAttrsTable("Agent Attributes", cards[0].attrs || [])
        : "<div class='ao-map-drawer-empty'>No agent details available.</div>";
    } else if (normalizedType === "TASK") {
      cards = buildTaskCards(
        CURRENT_AGENT_TEAM_DATA.tasksRows,
        CURRENT_AGENT_TEAM_DATA.taskAttrRows,
        CURRENT_AGENT_TEAM_DATA.teamAttrRows,
        selectedAgent
      ).filter(function(c) { return String(c.title || "") === title; });
      bodyHtml += cards.length
        ? renderMapNodeAttrsTable("Task Attributes", cards[0].attrs || [])
        : "<div class='ao-map-drawer-empty'>No task details available.</div>";
    } else if (normalizedType === "TOOL") {
      taskNames = getTaskNamesForAgent(CURRENT_AGENT_TEAM_DATA.teamAttrRows, selectedAgent);
      cards = buildToolCards(
        CURRENT_AGENT_TEAM_DATA.toolsRows,
        CURRENT_AGENT_TEAM_DATA.toolAttrRows,
        CURRENT_AGENT_TEAM_DATA.taskAttrRows,
        taskNames
      ).filter(function(c) { return String(c.title || "") === title; });
      bodyHtml += cards.length
        ? renderMapNodeAttrsTable("Tool Attributes", cards[0].attrs || [])
        : "<div class='ao-map-drawer-empty'>No tool details available.</div>";
    }

    $("#aoMapNodeDrawerBody").html(bodyHtml);
    $("#aoMapNodeDrawer, #aoMapNodeDrawerOverlay").removeClass("is-hidden").attr("aria-hidden", "false");
  }

  function openAgentEditorForMapNode(type, name) {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to edit agent definitions.");
      return;
    }
    var entityType = String(type || "").trim().toUpperCase();
    var entityName = String(name || "").trim();
    if (!entityType || !entityName) return;
    moveAgentEditorToInline();
    $(".ao-agent-create-panel[data-agent-create-section='edit']").addClass("is-active");
    $("#aoAgentEditEntityType").val(entityType);
    refreshAgentEntityOptions();
    ensureSelectOption("#aoAgentEditEntityName", entityName);
    $("#aoAgentEditEntityName").val(entityName);
    $("#aoAgentInlineEditorTitle").text("Edit " + entityType.charAt(0) + entityType.slice(1).toLowerCase() + ": " + entityName);
    populateAgentEntityEditor();
  }

  function handleAgentTeamMapClick(node) {
    var $node = $(node);
    var type = String($node.attr("data-map-type") || "").trim().toUpperCase();
    var name = String($node.attr("data-map-name") || "").trim();
    var agentName = String($node.attr("data-map-agent") || "").trim();
    var targetSelector = "#aoAgentTeamAgents";

    $("#aoAgentTeamMap .ao-team-node").removeClass("is-map-node-selected");
    $node.addClass("is-map-node-selected");

    if (agentName) {
      $("#aoAgentFilterSelect").val(agentName);
      renderAgentTeamDetailsByAgent(agentName);
    } else {
      renderAgentTeamDetailsByAgent($("#aoAgentFilterSelect").val());
    }

    if (type === "TASK") targetSelector = "#aoAgentTeamTasks";
    if (type === "TOOL") targetSelector = "#aoAgentTeamTools";
    if (type === "TEAM") targetSelector = "#aoAgentTeamDesc";
    showAgentMapDetail(type);
    if (type !== "TEAM") showOnlyAgentDetailCard(targetSelector, name);
    focusAgentDetailCard(targetSelector, name);
    closeMapNodeDrawer();
    openAgentTeamPlsqlDialog(
      buildFocusedAgentTeamPlsqlCode(type, name, agentName),
      (type || "NODE") + " Get Code"
    );
  }

  function clearAgentTeamBoxes() {
    fillSelect("#aoAgentFilterSelect", [], "");
    fillSelect("#aoAgentEditEntityName", [], "");
    $("#aoAgentTeamWorkspace").addClass("is-hidden");
    $(".ao-map-detail-section").addClass("is-hidden");
    $("#aoAgentTeamMapSearch").val("");
    $("#aoAgentTeamMapSearchState").text("");
    AGENT_TEAM_MAP_SEARCH_TEXT = "";
    collapseTeamMapExpanded();
    closeMapNodeDrawer();
    $("#aoAgentTeamMap").html("<div class='ao-muted-box'>Select an agent team to view the map.</div>");
    renderAgentEntityCards("#aoAgentTeamAgents", [], "No agents found.");
    renderAgentEntityCards("#aoAgentTeamTasks", [], "No tasks found.");
    renderAgentEntityCards("#aoAgentTeamTools", [], "No tools found.");
    CURRENT_AGENT_TEAM_DATA = null;
    $("#aoAgentEditName, #aoAgentEditTeamDescription, #aoAgentEditTeamAgents, #aoAgentEditAgentDescription, #aoAgentEditRole, #aoAgentEditTaskDescription, #aoAgentEditInstruction, #aoAgentEditTaskTools, #aoAgentEditTaskInputs, #aoAgentEditToolDescription, #aoAgentEditToolFunction, #aoAgentEditToolInstruction, #aoAgentEditToolParams, #aoAgentEditToolInputs").val("");
    $("#aoAgentEditTeamProcess, #aoAgentEditEnableHumanTool, #aoAgentEditTaskEnableHumanTool, #aoAgentEditToolType").val("");
    $("#aoAgentEditTeamAgent, #aoAgentEditTeamTask").val("");
    renderEditTeamMappingList();
    refreshAgentCreateLinkOptions();
  }

  function buildAgentCards(teamAttrRows, agentAttrRows, selectedAgentName) {
    var cards = [];
    var agentAttrMap = buildEntityAttrMap(agentAttrRows, ["agent_name", "ai_agent_name", "name", "agent"]);
    var mappings = parseAgentMappingsFromTeamAttrs(teamAttrRows);
    var selectedKey = normalizeAgentName(selectedAgentName);
    var seen = {};

    mappings.forEach(function(mapping) {
      var agentName = String(mapping.name || "").trim();
      if (selectedKey && normalizeAgentName(agentName) !== selectedKey) return;
      if (!agentName || seen[agentName]) return;
      seen[agentName] = true;
      var attrs = [];
      if (mapping.task) addUniqueCardAttr(attrs, "task", mapping.task);
      (agentAttrMap[agentName] || []).forEach(function(row) {
        addUniqueCardAttr(attrs, row.k, row.v);
        if (row.d) addUniqueCardAttr(attrs, row.k + " description", row.d);
      });
      cards.push({ title: agentName, attrs: attrs });
    });

    Object.keys(agentAttrMap).forEach(function(agentName) {
      if (agentName === "__GLOBAL__" || seen[agentName]) return;
      if (selectedKey && normalizeAgentName(agentName) !== selectedKey) return;
      var attrs = [];
      (agentAttrMap[agentName] || []).forEach(function(row) {
        addUniqueCardAttr(attrs, row.k, row.v);
        if (row.d) addUniqueCardAttr(attrs, row.k + " description", row.d);
      });
      cards.push({ title: agentName, attrs: attrs });
      seen[agentName] = true;
    });

    if (!selectedKey && !cards.length && agentAttrMap.__GLOBAL__) {
      var globalAttrs = [];
      agentAttrMap.__GLOBAL__.forEach(function(row) {
        addUniqueCardAttr(globalAttrs, row.k, row.v);
        if (row.d) addUniqueCardAttr(globalAttrs, row.k + " description", row.d);
      });
      cards.push({ title: "Agent", attrs: globalAttrs });
    }
    return cards;
  }

  function getTaskNamesForAgent(teamAttrRows, selectedAgentName) {
    var selectedKey = normalizeAgentName(selectedAgentName);
    var taskNames = [];
    parseAgentMappingsFromTeamAttrs(teamAttrRows).forEach(function(mapping) {
      var agentName = String(mapping.name || "").trim();
      var taskName = String(mapping.task || "").trim();
      if (!taskName) return;
      if (selectedKey && normalizeAgentName(agentName) !== selectedKey) return;
      if (taskNames.indexOf(taskName) >= 0) return;
      taskNames.push(taskName);
    });
    return taskNames;
  }

  function buildTaskCards(tasksRows, taskAttrRows, teamAttrRows, selectedAgentName) {
    var cards = [];
    var taskAttrMap = buildEntityAttrMap(taskAttrRows, ["task_name", "agent_task_name", "task"]);
    var taskRows = Array.isArray(tasksRows) ? tasksRows : [];
    var taskNames = [];
    var selectedKey = normalizeAgentName(selectedAgentName);
    var fromMappings = parseAgentMappingsFromTeamAttrs(teamAttrRows)
      .filter(function(item) {
        if (!selectedKey) return true;
        return normalizeAgentName(item.name) === selectedKey;
      })
      .map(function(item) { return item.task; });

    fromMappings.forEach(function(name) {
      var taskName = String(name || "").trim();
      if (!taskName || taskNames.indexOf(taskName) >= 0) return;
      taskNames.push(taskName);
    });

    if (!selectedKey) {
      collectEntityNames(taskAttrRows, ["task_name", "agent_task_name", "task"]).forEach(function(name) {
        if (taskNames.indexOf(name) < 0) taskNames.push(name);
      });
      collectEntityNames(tasksRows, ["agent_task_name", "task_name", "task", "name"]).forEach(function(name) {
        if (taskNames.indexOf(name) < 0) taskNames.push(name);
      });
    }

    taskNames.forEach(function(taskName) {
      var attrs = [];
      (taskAttrMap[taskName] || []).forEach(function(row) {
        addUniqueCardAttr(attrs, row.k, row.v);
        if (row.d) addUniqueCardAttr(attrs, row.k + " description", row.d);
      });
      if (!attrs.length) {
        var taskRow = null;
        for (var i = 0; i < taskRows.length; i += 1) {
          var candidateName = String(getAgentRowValue(taskRows[i], ["agent_task_name", "task_name", "task", "name"]) || "").trim();
          if (candidateName === taskName) {
            taskRow = taskRows[i];
            break;
          }
        }
        addRowFieldsAsAttrs(taskRow, attrs, [
          "agent_task_name",
          "task_name",
          "task",
          "name",
          "agent_team_name",
          "team_name",
          "agent_team"
        ]);
      }
      cards.push({ title: taskName, attrs: attrs });
    });

    if (!selectedKey && !cards.length && taskAttrMap.__GLOBAL__) {
      var globalAttrs = [];
      taskAttrMap.__GLOBAL__.forEach(function(row) {
        addUniqueCardAttr(globalAttrs, row.k, row.v);
      });
      cards.push({ title: "Task", attrs: globalAttrs });
    }
    return cards;
  }

  function collectToolNamesFromTaskAttrs(taskAttrRows, allowedTaskNames) {
    var out = [];
    var allowed = Array.isArray(allowedTaskNames) && allowedTaskNames.length
      ? allowedTaskNames.map(function(item) { return normalizeAgentEntityKey(item); })
      : null;
    (taskAttrRows || []).forEach(function(row) {
      var taskName = String(getAgentRowValue(row, ["task_name", "agent_task_name", "task"]) || "").trim();
      if (allowed && allowed.indexOf(normalizeAgentEntityKey(taskName)) < 0) return;
      var attrName = String(getAgentRowValue(row, ["attribute_name", "attr_name", "name"]) || "").trim().toLowerCase();
      if (attrName !== "tools") return;
      var attrValue = getAgentRowValue(row, ["attribute_value", "attr_value", "value", "val"]);
      var parsed = parseJsonValueSafe(attrValue);
      if (Array.isArray(parsed)) {
        parsed.forEach(function(item) {
          var name = String(item || "").trim();
          if (!name || out.indexOf(name) >= 0) return;
          out.push(name);
        });
      }
    });
    return out;
  }

  function buildToolCards(toolsRows, toolAttrRows, taskAttrRows, allowedTaskNames) {
    var cards = [];
    var toolAttrMap = buildEntityAttrMap(toolAttrRows, ["tool_name", "agent_tool_name", "tool"]);
    var toolRows = Array.isArray(toolsRows) ? toolsRows : [];
    var toolNames = [];
    var hasTaskFilter = Array.isArray(allowedTaskNames) && allowedTaskNames.length > 0;

    collectToolNamesFromTaskAttrs(taskAttrRows, allowedTaskNames).forEach(function(name) {
      if (toolNames.indexOf(name) < 0) toolNames.push(name);
    });

    if (!hasTaskFilter) {
      collectEntityNames(toolAttrRows, ["tool_name", "agent_tool_name", "tool"]).forEach(function(name) {
        if (toolNames.indexOf(name) < 0) toolNames.push(name);
      });
      collectEntityNames(toolsRows, ["agent_tool_name", "tool_name", "tool", "name"]).forEach(function(name) {
        if (toolNames.indexOf(name) < 0) toolNames.push(name);
      });
    }

    toolNames.forEach(function(toolName) {
      var attrs = [];
      (toolAttrMap[toolName] || []).forEach(function(row) {
        addUniqueCardAttr(attrs, row.k, row.v);
        if (row.d) addUniqueCardAttr(attrs, row.k + " description", row.d);
      });
      if (!attrs.length) {
        var toolRow = null;
        for (var i = 0; i < toolRows.length; i += 1) {
          var candidateName = String(getAgentRowValue(toolRows[i], ["agent_tool_name", "tool_name", "tool", "name"]) || "").trim();
          if (candidateName === toolName) {
            toolRow = toolRows[i];
            break;
          }
        }
        addRowFieldsAsAttrs(toolRow, attrs, [
          "agent_tool_name",
          "tool_name",
          "tool",
          "name",
          "agent_team_name",
          "team_name",
          "agent_team"
        ]);
      }
      cards.push({ title: toolName, attrs: attrs });
    });

    if (!hasTaskFilter && !cards.length && toolAttrMap.__GLOBAL__) {
      var globalAttrs = [];
      toolAttrMap.__GLOBAL__.forEach(function(row) {
        addUniqueCardAttr(globalAttrs, row.k, row.v);
      });
      cards.push({ title: "Tool", attrs: globalAttrs });
    }
    return cards;
  }

  function buildTeamAttributeCards(teamAttrRows, teamRows) {
    var cards = [];
    var attrs = [];
    (teamAttrRows || []).forEach(function(row) {
      var attrName = String(getAgentRowValue(row, ["attribute_name", "attr_name", "name"]) || "").trim();
      var attrValue = getAgentRowValue(row, ["attribute_value", "attr_value", "value", "val"]);
      if (!attrName) return;
      addUniqueCardAttr(attrs, attrName, attrValue);
    });
    if (!attrs.length && teamRows && teamRows.length && typeof teamRows[0] === "object") {
      Object.keys(teamRows[0]).forEach(function(key) {
        if (!key) return;
        if (normalizeAgentEntityKey(key) === "description") return;
        addUniqueCardAttr(attrs, key, teamRows[0][key]);
      });
    }
    if (attrs.length) cards.push({ title: "Team Attributes", attrs: attrs });
    return cards;
  }

  function buildTeamAttributesDisplayText(teamAttrRows, teamRows, teamDescription) {
    var description = String(teamDescription || "").trim();
    var cards = buildTeamAttributeCards(teamAttrRows, teamRows);
    var attrs = cards.length && Array.isArray(cards[0].attrs) ? cards[0].attrs : [];
    var lines;
    var hasDescriptionLine;

    if (!attrs.length) return description;

    lines = attrs.map(function(item) {
      var key = String(item && item.k || "").trim();
      var value = formatAgentEntityAttrValue(key, item && item.v);
      var text = String(value || "").trim();
      if (!text) return "";
      return key ? (key + ": " + text) : text;
    }).filter(function(line) {
      return !!line;
    });

    hasDescriptionLine = lines.some(function(line) {
      return /^description\s*:/i.test(String(line || ""));
    });

    if (description && !hasDescriptionLine) {
      lines.unshift("description: " + description);
    }

    return lines.join("\n");
  }

  function loadAttrs(profileType) {
    var profileName = selectedProfileValue(profileType);
    if (!profileName) {
      if (profileType === "NL2SQL") renderAttrs("#aoNl2sqlAttrs", []);
      if (profileType === "RAG") renderAttrs("#aoRagAttrs", []);
      return;
    }

    ajax(PROC.GET_PROFILE_ATTRS, {
      x01: profileType,
      x02: profileName,
      pageItems: "#P20000_SERVICE,#P20000_RAGSERVICE"
    }, function (err, data) {
      if (err) {
        showError(err.responseText || "Unable to load profile attributes.");
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to load profile attributes.");
        return;
      }
      if (profileType === "NL2SQL") renderAttrs("#aoNl2sqlAttrs", data.attributes);
      if (profileType === "RAG") renderAttrs("#aoRagAttrs", data.attributes);
    });
  }

  function collectAttrs(profileType, containerSelector) {
    var obj = {};
    $(containerSelector).find(".ao-attr-row[data-attr-name]").each(function () {
      var $row = $(this);
      var name = String($row.attr("data-attr-name") || "").trim();
      var value = $row.find(".js-ao-attr-val").val();
      var config = getProfileAttrConfig(profileType, name);
      var parsedBool;
      var trimmedValue;
      var parsedArray;
      if (!name) return;
      if (!isProfileAttrApplicable(profileType, name, config)) return;
      if ($row.hasClass("is-provider-hidden")) return;
      if (config.type === "object_list") {
        parsedArray = parseObjectListLines(value);
        /* Always pass object_list, including [] when user clears entries. */
        obj[name] = parsedArray;
      } else if (config.type === "boolean") {
        parsedBool = parseBooleanLike(value);
        if (parsedBool != null) obj[name] = parsedBool;
      } else if (config.type === "number") {
        trimmedValue = String(value == null ? "" : value).trim();
        if (trimmedValue !== "") obj[name] = Number(trimmedValue);
      } else if (config.type === "string_array") {
        try {
          parsedArray = parseStopTokens(value);
        } catch (e) {
          markFieldError($row.find(".js-ao-attr-val").get(0), e.message || "Invalid stop token syntax.");
          throw e;
        }
        if (parsedArray.length) obj[name] = parsedArray;
      } else if (name === "input") {
        parsedArray = parseLineArray(value);
        if (parsedArray.length) obj[name] = parsedArray;
      } else {
        trimmedValue = String(value == null ? "" : value).trim();
        if (trimmedValue !== "") obj[name] = trimmedValue;
      }
    });
    return obj;
  }

  function saveAttrs(profileType, containerSelector) {
    var profileName = selectedProfileValue(profileType);
    if (!profileName) {
      showError("Please select a profile first.");
      return;
    }
    if (!isAttrDirty(profileType)) {
      showError("No changes to save.");
      syncAttrDirtyState(profileType);
      return;
    }

    var attrs;
    try {
      attrs = collectAttrs(profileType, containerSelector);
    } catch (e) {
      showError(e.message || "Invalid profile attribute value.");
      return;
    }

    ajaxWithBusy(PROC.SAVE_PROFILE_ATTRS, {
      x01: profileType,
      x02: profileName,
      p_clob_01: JSON.stringify(attrs),
      pageItems: "#P20000_SERVICE,#P20000_RAGSERVICE"
    }, "Saving " + profileType + " attributes...", function (err, data) {
      if (err) {
        showError(err.responseText || "Unable to save attributes.");
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to save attributes.");
        return;
      }
      showSuccess("Attributes saved.");
      setAttrEditMode(profileType, false);
      loadAttrs(profileType);
    });
  }

  function buildCreateProfilePayload() {
    var profileName = String($("#aoCreateName").val() || "").trim();
    var description = String($("#aoCreateDescription").val() || "").trim();

    var provider = String($("#aoCreateProvider").val() || "").trim();
    var credential = String($("#aoCreateCredential").val() || "").trim();
    var model = String($("#aoCreateModel").val() || "").trim();
    var region = String($("#aoCreateRegion").val() || "").trim();
    var providerEndpoint = String($("#aoCreateProviderEndpoint").val() || "").trim();

    var objectListMode = String($("#aoCreateObjectListMode").val() || "all").trim();
    var objectList = parseObjectListLines($("#aoCreateObjectList").val());

    var temperature = String($("#aoCreateTemperature").val() || "").trim();
    var maxTokens = String($("#aoCreateMaxTokens").val() || "").trim();
    var seed = String($("#aoCreateSeed").val() || "").trim();
    var embeddingModel = String($("#aoCreateEmbeddingModel").val() || "").trim();
    var conversationLength = String($("#aoCreateConversationLength").val() || "").trim();
    var azureResourceName = String($("#aoCreateAzureResourceName").val() || "").trim();
    var azureDeploymentName = String($("#aoCreateAzureDeploymentName").val() || "").trim();
    var azureEmbeddingDeploymentName = String($("#aoCreateAzureEmbeddingDeploymentName").val() || "").trim();
    var ociRuntimeType = String($("#aoCreateOciRuntimeType").val() || "").trim();
    var sourceLanguage = String($("#aoCreateSourceLanguage").val() || "").trim();
    var targetLanguage = String($("#aoCreateTargetLanguage").val() || "").trim();
    var additionalAttrsRaw = String($("#aoCreateAdditionalAttrsJson").val() || "").trim();
    var additionalAttrs = null;

    var stopTokens = parseStopTokensFromField("#aoCreateStopTokens");

    var ociCompartment = String($("#aoCreateOciCompartment").val() || "").trim();
    var ociEndpoint = String($("#aoCreateOciEndpoint").val() || "").trim();
    var ociApiFormat = String($("#aoCreateOciApiFormat").val() || "").trim();
    var providerLower = getProviderKey(provider);

    if (!profileName) {
      throw new Error("Profile Name is required.");
    }
    validateNameField("#aoCreateName", "Profile");

    if (!provider) {
      throw new Error("Provider is required.");
    }

    if (!credential) {
      throw new Error("Credential Name is required.");
    }
    if (additionalAttrsRaw) {
      try {
        additionalAttrs = JSON.parse(additionalAttrsRaw);
      } catch (parseErr) {
        markFieldError("#aoCreateAdditionalAttrsJson", "Additional Attributes JSON must be valid JSON.");
        throw new Error("Additional Attributes JSON must be valid JSON.");
      }
      if (!additionalAttrs || Array.isArray(additionalAttrs) || typeof additionalAttrs !== "object") {
        markFieldError("#aoCreateAdditionalAttrsJson", "Additional Attributes JSON must be a JSON object.");
        throw new Error("Additional Attributes JSON must be a JSON object.");
      }
      clearFieldError("#aoCreateAdditionalAttrsJson");
    } else {
      clearFieldError("#aoCreateAdditionalAttrsJson");
    }

    if (providerLower === "oci") {
      // Optional OCI attributes can be provided as needed.
    } else {
      if (!model) throw new Error("Model is required for non-OCI providers.");
      if (!providerEndpoint) throw new Error("Provider Endpoint is required for non-OCI providers.");
    }

    var attrs = {};

    if (provider) attrs.provider = provider;
    if (providerEndpoint && providerLower !== "oci") attrs.provider_endpoint = providerEndpoint;

    attrs.credential_name = credential;

    if (model) attrs.model = model;
    if (region) attrs.region = region;

    if (objectListMode) attrs.object_list_mode = objectListMode;
    if (objectList.length) attrs.object_list = objectList;

    attrs.comments = $("#aoCreateComments").is(":checked");
    attrs.constraints = $("#aoCreateConstraints").is(":checked");
    attrs.enforce_object_list = $("#aoCreateEnforceObjectList").is(":checked");
    attrs.conversation = $("#aoCreateConversation").is(":checked");
    attrs.annotations = $("#aoCreateAnnotations").is(":checked");
    attrs.case_sensitive_values = $("#aoCreateCaseSensitive").is(":checked");

    if (temperature !== "") attrs.temperature = Number(temperature);
    if (maxTokens !== "") attrs.max_tokens = Number(maxTokens);
    if (seed !== "") attrs.seed = Number(seed);
    if (conversationLength !== "") attrs.conversation_length = Number(conversationLength);
    if (embeddingModel) attrs.embedding_model = embeddingModel;
    if (azureResourceName) attrs.azure_resource_name = azureResourceName;
    if (azureDeploymentName) attrs.azure_deployment_name = azureDeploymentName;
    if (azureEmbeddingDeploymentName) attrs.azure_embedding_deployment_name = azureEmbeddingDeploymentName;
    if (ociRuntimeType) attrs.oci_runtimetype = ociRuntimeType;
    if (sourceLanguage) attrs.source_language = sourceLanguage;
    if (targetLanguage) attrs.target_language = targetLanguage;

    if (stopTokens.length) attrs.stop_tokens = stopTokens;

    if (providerLower === "oci") {
      if (ociCompartment) attrs.oci_compartment_id = ociCompartment;
      if (ociEndpoint) attrs.oci_endpoint_id = ociEndpoint;
      if (ociApiFormat) attrs.oci_apiformat = ociApiFormat;
    }
    if (additionalAttrs) attrs = $.extend({}, attrs, additionalAttrs);

    return {
      profile_name: profileName,
      description: description,
      attributes: attrs
    };
  }

  function buildCreateRagProfilePayload() {
    var profileName = String($("#aoRagCreateName").val() || "").trim();
    var description = String($("#aoRagCreateDescription").val() || "").trim();

    var provider = String($("#aoRagCreateProvider").val() || "").trim();
    var credential = String($("#aoRagCreateCredential").val() || "").trim();
    var model = String($("#aoRagCreateModel").val() || "").trim();
    var region = String($("#aoRagCreateRegion").val() || "").trim();
    var providerEndpoint = String($("#aoRagCreateProviderEndpoint").val() || "").trim();
    var vectorIndexName = String($("#aoRagCreateVectorIndex").val() || "").trim();
    var embeddingModel = String($("#aoRagCreateEmbeddingModel").val() || "").trim();
    var conversationLength = String($("#aoRagCreateConversationLength").val() || "").trim();
    var enableSources = String($("#aoRagCreateEnableSources").val() || "").trim();
    var enableSourceOffsets = String($("#aoRagCreateEnableSourceOffsets").val() || "").trim();
    var enableCustomSourceUri = String($("#aoRagCreateEnableCustomSourceUri").val() || "").trim();

    var temperature = String($("#aoRagCreateTemperature").val() || "").trim();
    var maxTokens = String($("#aoRagCreateMaxTokens").val() || "").trim();
    var seed = String($("#aoRagCreateSeed").val() || "").trim();
    var stopTokens = parseStopTokensFromField("#aoRagCreateStopTokens");

    var ociCompartment = String($("#aoRagCreateOciCompartment").val() || "").trim();
    var ociEndpoint = String($("#aoRagCreateOciEndpoint").val() || "").trim();
    var ociApiFormat = String($("#aoRagCreateOciApiFormat").val() || "").trim();
    var providerLower = getProviderKey(provider);

    if (!profileName) throw new Error("RAG profile name is required.");
    validateNameField("#aoRagCreateName", "Profile");
    if (!provider) throw new Error("Provider is required.");
    if (!credential) throw new Error("Credential Name is required.");
    if (!vectorIndexName) throw new Error("Vector Index Name is required.");
    if (providerLower === "oci") {
      // Optional OCI attributes can be provided as needed.
    } else {
      if (!model) throw new Error("Model is required for non-OCI providers.");
      if (!providerEndpoint) throw new Error("Provider Endpoint is required for non-OCI providers.");
    }

    var attrs = {};
    attrs.provider = provider;
    attrs.credential_name = credential;
    attrs.vector_index_name = vectorIndexName;

    if (providerEndpoint && providerLower !== "oci") attrs.provider_endpoint = providerEndpoint;
    if (model) attrs.model = model;
    if (region) attrs.region = region;
    if (embeddingModel) attrs.embedding_model = embeddingModel;

    attrs.conversation = $("#aoRagCreateConversation").is(":checked");

    if (temperature !== "") attrs.temperature = Number(temperature);
    if (maxTokens !== "") attrs.max_tokens = Number(maxTokens);
    if (seed !== "") attrs.seed = Number(seed);
    if (conversationLength !== "") attrs.conversation_length = Number(conversationLength);
    if (stopTokens.length) attrs.stop_tokens = stopTokens;

    if (parseBooleanLike(enableSources) != null) attrs.enable_sources = parseBooleanLike(enableSources);
    if (parseBooleanLike(enableSourceOffsets) != null) attrs.enable_source_offsets = parseBooleanLike(enableSourceOffsets);
    if (parseBooleanLike(enableCustomSourceUri) != null) attrs.enable_custom_source_uri = parseBooleanLike(enableCustomSourceUri);

    if (providerLower === "oci") {
      if (ociCompartment) attrs.oci_compartment_id = ociCompartment;
      if (ociEndpoint) attrs.oci_endpoint_id = ociEndpoint;
      if (ociApiFormat) attrs.oci_apiformat = ociApiFormat;
    }

    return {
      profile_name: profileName,
      description: description,
      attributes: attrs
    };
  }

  function resetCreatePanelFields(panelSelector) {
    var $panel = $(panelSelector);
    if (!$panel.length) return;
    $panel.find("input, select, textarea").each(function() {
      var field = this;
      var type = String(field.type || "").toLowerCase();
      if (type === "checkbox" || type === "radio") {
        field.checked = !!field.defaultChecked;
      } else if (field.tagName && field.tagName.toLowerCase() === "select") {
        field.selectedIndex = 0;
      } else {
        field.value = field.defaultValue || "";
      }
      $(field).removeClass("is-invalid has-error").removeAttr("aria-invalid");
    });
    $panel.find(".ao-object-picker-selected").empty();
    $panel.find(".ao-object-picker-select").val([]);
    refreshObjectPickers();
  }

  function resetNl2sqlProfileCreateForm() {
    resetCreatePanelFields("#aoNl2sqlCreateCard");
  }

  function resetRagProfileCreateForm() {
    resetCreatePanelFields("#aoRagProfileCreateCard");
  }

  function resetVectorIndexCreateForm() {
    resetCreatePanelFields("#aoRagVectorCreateCard");
  }

  function createNl2sqlProfile() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to create profiles.");
      return;
    }
    var payload;
    try {
      payload = buildCreateProfilePayload();
    } catch (e) {
      showError(e.message || "Invalid profile inputs.");
      return;
    }

    var existsInLov = $("#aoNl2sqlSelect option").filter(function () {
      return String($(this).val() || "").toUpperCase() === payload.profile_name.toUpperCase();
    }).length > 0;

    if (existsInLov) {
      showError("Profile name already exists. Please choose another name.");
      return;
    }

    ajaxWithBusy(PROC.CREATE_PROFILE, {
      x01: payload.profile_name,
      x02: payload.description,
      p_clob_01: JSON.stringify(payload.attributes)
    }, "Creating NL2SQL profile...", function (err, data) {
      if (err) {
        showError(err.responseText || "Unable to create profile.");
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to create profile.");
        return;
      }
      showSuccess("NL2SQL profile created: " + payload.profile_name);
      resetNl2sqlProfileCreateForm();
      bootstrap();
    });
  }

  function createRagProfile() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to create profiles.");
      return;
    }
    var payload;
    try {
      payload = buildCreateRagProfilePayload();
    } catch (e) {
      showError(e.message || "Invalid RAG profile inputs.");
      return;
    }

    var existsInLov = $("#aoRagSelect option").filter(function () {
      return String($(this).val() || "").toUpperCase() === payload.profile_name.toUpperCase();
    }).length > 0;
    if (existsInLov) {
      showError("RAG profile name already exists. Please choose another name.");
      return;
    }

    ajaxWithBusy(PROC.CREATE_PROFILE, {
      x01: payload.profile_name,
      x02: payload.description,
      p_clob_01: JSON.stringify(payload.attributes)
    }, "Creating RAG profile...", function (err, data) {
      if (err) {
        showError(err.responseText || "Unable to create RAG profile.");
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to create RAG profile.");
        return;
      }
      showSuccess("RAG profile created: " + payload.profile_name);
      resetRagProfileCreateForm();
      bootstrap();
    });
  }

  function profileNameExists(profileType, profileName) {
    var type = String(profileType || "").trim().toUpperCase();
    var selector = type === "RAG" ? "#aoRagSelect" : "#aoNl2sqlSelect";
    var requestedName = String(profileName || "").trim().toUpperCase();
    if (!requestedName) return false;
    if ((ALL_PROFILE_OPTIONS || []).some(function(row) {
      return String((row && row.r) || "").trim().toUpperCase() === requestedName;
    })) return true;
    return $(selector + " option").filter(function() {
      return String($(this).val() || "").trim().toUpperCase() === requestedName;
    }).length > 0;
  }

  function getDuplicateProfileNameSuggestion(profileType, originalName) {
    var type = String(profileType || "").trim().toUpperCase();
    var base = String(originalName || "PROFILE").trim()
      .replace(/[^A-Za-z0-9_]+/g, "_")
      .replace(/^_+|_+$/g, "") || "PROFILE";
    var candidate = base + "_COPY";
    var suffix = 2;

    while (profileNameExists(type, candidate)) {
      candidate = base + "_COPY_" + suffix;
      suffix += 1;
    }
    return candidate;
  }

  function openDuplicateProfileDialog(profileType) {
    var type = String(profileType || "").trim().toUpperCase();
    var originalName = selectedProfileValue(type);
    var suggestedName;
    var label = type === "RAG" ? "RAG profile" : "NL2SQL profile";

    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to duplicate profiles.");
      return;
    }
    if (!originalName) {
      showError("Please select a " + label + " first.");
      return;
    }

    suggestedName = getDuplicateProfileNameSuggestion(type, originalName);
    DUPLICATE_PROFILE_CONTEXT = { type: type, originalName: originalName };
    $("#aoDuplicateProfileDialogTitle").text("Duplicate " + label);
    $("#aoDuplicateProfileDialogCopy").text("Create a new profile from " + originalName + ". All profile attributes will be copied.");
    $("#aoDuplicateProfileName").val(suggestedName);
    clearFieldError("#aoDuplicateProfileName");
    $("#aoDuplicateProfileDialog").removeClass("is-hidden");
    window.setTimeout(function() {
      $("#aoDuplicateProfileName").trigger("focus").trigger("select");
    }, 20);
  }

  function closeDuplicateProfileDialog() {
    $("#aoDuplicateProfileDialog").addClass("is-hidden");
    DUPLICATE_PROFILE_CONTEXT = null;
    $("#aoDuplicateProfileName").val("");
    clearFieldError("#aoDuplicateProfileName");
  }

  function duplicateProfile(profileType, originalName, duplicateName) {
    var type = String(profileType || "").trim().toUpperCase();
    var label = type === "RAG" ? "RAG profile" : "NL2SQL profile";
    duplicateName = String(duplicateName || "").trim();

    var nameError = validateIdentifierValue(duplicateName, "Profile");
    if (nameError) {
      markFieldError("#aoDuplicateProfileName", nameError);
      return;
    }
    if (profileNameExists(type, duplicateName)) {
      markFieldError("#aoDuplicateProfileName", "Profile name already exists. Please choose another name.");
      return;
    }

    ajaxWithBusy(PROC.GET_PROFILE_ATTRS, {
      x01: type,
      x02: originalName,
      pageItems: "#P20000_SERVICE,#P20000_RAGSERVICE"
    }, "Loading " + label + " configuration...", function(err, data) {
      var attributes;
      if (err) {
        showError(err.responseText || "Unable to load profile attributes.");
        return;
      }
      if (!data || !data.success) {
        showError((data && data.message) || "Unable to load profile attributes.");
        return;
      }

      attributes = buildProfileAttrsPayloadFromRows(type, data.attributes || []);
      ajaxWithBusy(PROC.CREATE_PROFILE, {
        x01: duplicateName,
        x02: "Duplicate of " + originalName,
        p_clob_01: JSON.stringify(attributes)
      }, "Duplicating " + label + "...", function(createErr, createData) {
        if (createErr) {
          showError(createErr.responseText || "Unable to duplicate profile.");
          return;
        }
        if (!createData || !createData.success) {
          showError((createData && createData.message) || "Unable to duplicate profile.");
          return;
        }
        closeDuplicateProfileDialog();
        showSuccess(label.charAt(0).toUpperCase() + label.slice(1) + " duplicated: " + duplicateName);
        bootstrap();
      });
    });
  }

  function createRagVectorIndex() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to create vector index.");
      return;
    }
    var indexName = String($("#aoRagVectorIndexName").val() || "").trim();
    var embeddingProfileName = String($("#aoRagVectorProfileName").val() || "").trim();
    var vectorDbProvider = String($("#aoRagVectorDbProvider").val() || "").trim() || "oracle";
    var vectorCredential = String($("#aoRagVectorCredential").val() || "").trim();
    var location = String($("#aoRagVectorLocation").val() || "").trim();
    var status = String($("#aoRagVectorStatus").val() || "").trim();
    var description = String($("#aoRagVectorDescription").val() || "").trim();
    var waitForCompletion = $("#aoRagVectorWaitForCompletion").is(":checked") ? "Y" : "N";
    var additionalAttrsRaw = String($("#aoRagVectorAttributesJson").val() || "").trim();
    var vectorTableName = String($("#aoRagVectorTableName").val() || "").trim();
    var vectorDimension = String($("#aoRagVectorDimension").val() || "").trim();
    var vectorDistanceMetric = String($("#aoRagVectorDistanceMetric").val() || "").trim();
    var chunkSize = String($("#aoRagVectorChunkSize").val() || "").trim();
    var chunkOverlap = String($("#aoRagVectorChunkOverlap").val() || "").trim();
    var refreshRate = String($("#aoRagVectorRefreshRate").val() || "").trim();
    var matchLimit = String($("#aoRagVectorMatchLimit").val() || "").trim();
    var similarityThreshold = String($("#aoRagVectorSimilarityThreshold").val() || "").trim();
    var enableSources = String($("#aoRagVectorEnableSources").val() || "").trim().toLowerCase();

    if (!indexName) {
      showError("Vector Index Name is required.");
      return;
    }
    try {
      validateNameField("#aoRagVectorIndexName", "Object");
    } catch (e) {
      showError(e.message);
      return;
    }
    if (!embeddingProfileName) {
      showError("Embedding Profile Name is required.");
      return;
    }
    if (!vectorCredential) {
      showError("Vector DB Credential Name is required.");
      return;
    }
    if (!location) {
      showError("Location is required.");
      return;
    }

    if (additionalAttrsRaw) {
      try { JSON.parse(additionalAttrsRaw); } catch (e) {
        showError("Additional Attributes JSON must be valid JSON.");
        return;
      }
    }

    var attrsObj = {};
    if (vectorTableName) attrsObj.vector_table_name = vectorTableName;
    if (vectorDimension !== "") attrsObj.vector_dimension = Number(vectorDimension);
    if (vectorDistanceMetric) attrsObj.vector_distance_metric = vectorDistanceMetric;
    if (chunkSize !== "") attrsObj.chunk_size = Number(chunkSize);
    if (chunkOverlap !== "") attrsObj.chunk_overlap = Number(chunkOverlap);
    if (refreshRate !== "") attrsObj.refresh_rate = Number(refreshRate);
    if (matchLimit !== "") attrsObj.match_limit = Number(matchLimit);
    if (similarityThreshold !== "") attrsObj.similarity_threshold = Number(similarityThreshold);
    if (enableSources === "true" || enableSources === "false") attrsObj.enable_sources = enableSources === "true";

    if (additionalAttrsRaw) {
      try {
        attrsObj = $.extend({}, attrsObj, JSON.parse(additionalAttrsRaw));
      } catch (e2) {
        showError("Additional Attributes JSON must be valid JSON.");
        return;
      }
    }

    var mergedAttrsRaw = Object.keys(attrsObj).length ? JSON.stringify(attrsObj) : "";

    ajaxWithBusy(PROC.CREATE_RAG_VECTOR_INDEX, {
      x01: indexName,
      x02: embeddingProfileName,
      x03: vectorDbProvider,
      x04: vectorCredential,
      x05: location,
      x06: status,
      x07: description,
      x08: waitForCompletion,
      p_clob_01: mergedAttrsRaw
    }, waitForCompletion === "Y" ? "Creating vector index and waiting for completion..." : "Submitting vector index creation...", function(err, data) {
      if (err) {
        showError(err.responseText || "Unable to create vector index.");
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to create vector index.");
        return;
      }
      showSuccess("Vector index created: " + indexName);
      resetVectorIndexCreateForm();
      bootstrap();
    });
  }

  function dropNl2sqlProfile() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to drop profiles.");
      return;
    }
    var profileName = String($("#aoDropNl2sqlSelect").val() || "").trim();
    if (!profileName) {
      showError("Please select profile to drop.");
      return;
    }

    var runDrop = function () {
      ajaxWithBusy(PROC.DROP_PROFILE, { x01: profileName }, "Dropping NL2SQL profile...", function (err, data) {
        if (err) {
          showError(err.responseText || "Unable to drop profile.");
          return;
        }
        if (!data.success) {
          showError(data.message || "Unable to drop profile.");
          return;
        }
        showSuccess("Profile dropped: " + profileName);
        bootstrap();
      });
    };

    if (window.apex && apex.message && typeof apex.message.confirm === "function") {
      apex.message.confirm("Drop profile '" + profileName + "'? This cannot be undone.", function (okPressed) {
        if (!okPressed) return;
        runDrop();
      });
    } else {
      if (!window.confirm("Drop profile '" + profileName + "'? This cannot be undone.")) return;
      runDrop();
    }
  }

  function dropRagProfile() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to drop profiles.");
      return;
    }
    var profileName = String($("#aoDropRagSelect").val() || "").trim();
    if (!profileName) {
      showError("Please select RAG profile to drop.");
      return;
    }

    var runDrop = function () {
      ajaxWithBusy(PROC.DROP_PROFILE, { x01: profileName }, "Dropping RAG profile...", function (err, data) {
        if (err) {
          showError(err.responseText || "Unable to drop RAG profile.");
          return;
        }
        if (!data.success) {
          showError(data.message || "Unable to drop RAG profile.");
          return;
        }
        showSuccess("RAG profile dropped: " + profileName);
        bootstrap();
      });
    };

    if (window.apex && apex.message && typeof apex.message.confirm === "function") {
      apex.message.confirm("Drop RAG profile '" + profileName + "'? This cannot be undone.", function (okPressed) {
        if (!okPressed) return;
        runDrop();
      });
    } else {
      if (!window.confirm("Drop RAG profile '" + profileName + "'? This cannot be undone.")) return;
      runDrop();
    }
  }

  function dropRagVectorIndex() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to drop vector index.");
      return;
    }
    var indexName = String($("#aoDropRagVectorIndexSelect").val() || "").trim();
    if (!indexName) {
      showError("Please provide vector index name to drop.");
      return;
    }

    var runDrop = function() {
      ajaxWithBusy(PROC.DROP_RAG_VECTOR_INDEX, { x01: indexName }, "Dropping vector index...", function(err, data) {
        if (err) {
          showError(err.responseText || "Unable to drop vector index.");
          return;
        }
        if (!data.success) {
          showError(data.message || "Unable to drop vector index.");
          return;
        }
        showSuccess("Vector index dropped: " + indexName);
        bootstrap();
      });
    };

    if (window.apex && apex.message && typeof apex.message.confirm === "function") {
      apex.message.confirm("Drop vector index '" + indexName + "'? This cannot be undone.", function(okPressed) {
        if (!okPressed) return;
        runDrop();
      });
    } else {
      if (!window.confirm("Drop vector index '" + indexName + "'? This cannot be undone.")) return;
      runDrop();
    }
  }

  function setDataSourceSection(section) {
    var target = String(section || "connections").toLowerCase();
    if (!$(".ao-admin-panel[data-ds-section='" + target + "']").length) target = "connections";
    $(".ao-admin-tab[data-ds-section]").removeClass("is-active");
    $(".ao-admin-tab[data-ds-section='" + target + "']").addClass("is-active");
    $(".ao-admin-panel[data-ds-section]").removeClass("is-active");
    $(".ao-admin-panel[data-ds-section='" + target + "']").addClass("is-active");
  }

  function setDbLinkCardView(target) {
    var mode = String(target || "list").toLowerCase();
    if (["list", "create"].indexOf(mode) < 0) mode = "list";
    $("#aoDbLinkListCard, #aoDbLinkCreateCard").hide();
    if (mode === "list") $("#aoDbLinkListCard").show();
    if (mode === "create") $("#aoDbLinkCreateCard").show();
    $("#aoOpenDbLinkCreate").toggle(mode !== "create");
  }

  function addDbGatewayParamRow(key, value) {
    var k = String(key || "").trim();
    var v = String(value || "").trim();
    var rowHtml =
      "<div class='ao-dblink-gateway-row'>" +
      "<input class='ao-input' data-gw-key='1' type='text' placeholder='key (e.g. db_type)' value='" + escapeAttr(k) + "' />" +
      "<input class='ao-input' data-gw-value='1' type='text' placeholder='value (e.g. mysql)' value='" + escapeAttr(v) + "' />" +
      "<button type='button' class='t-Button' data-remove-gw-param='1'>Remove</button>" +
      "</div>";
    $("#aoDbGatewayParamsRows").append(rowHtml);
  }

  function collectGatewayParamsJson() {
    var out = {};
    $("#aoDbGatewayParamsRows .ao-dblink-gateway-row").each(function() {
      var key = String($(this).find("[data-gw-key='1']").val() || "").trim();
      var value = String($(this).find("[data-gw-value='1']").val() || "").trim();
      if (!key) return;
      out[key] = value;
    });
    return Object.keys(out).length ? JSON.stringify(out) : "";
  }

  function createDbLink() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to create connection.");
      return;
    }
    var payload = {
      db_link_name: String($("#aoDbLinkName").val() || "").trim(),
      db_type: String($("#aoDbType").val() || "").trim(),
      hostname: String($("#aoDbHost").val() || "").trim(),
      port: String($("#aoDbPort").val() || "").trim(),
      service_name: String($("#aoDbServiceName").val() || "").trim(),
      ssl_server_cert_dn: String($("#aoDbSslDn").val() || "").trim(),
      credential_name: String($("#aoDbLinkCredential").val() || "").trim(),
      directory_name: String($("#aoDbDirectoryName").val() || "").trim(),
      gateway_link: $("#aoDbGatewayLink").is(":checked") ? "true" : "false",
      gateway_params_json: collectGatewayParamsJson()
    };
    if (!payload.db_link_name || !payload.db_type || !payload.hostname || !payload.port || !payload.service_name || !payload.credential_name) {
      showError("Database connection name, category, host, port, service name, and credential are required.");
      return;
    }
    ajaxWithBusy(PROC.CREATE_DB_LINK, {
      p_clob_01: JSON.stringify(payload)
    }, "Creating database link...", function(err, data) {
      if (err) {
        showError(err.responseText || "Unable to create database link.");
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to create database link.");
        return;
      }
      showSuccess("Connection created: " + payload.db_link_name);
      refreshDbLinks();
      setDbLinkCardView("list");
    });
  }

  function dropDbLink(dbLinkName) {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to drop connection.");
      return;
    }
    var name = String(dbLinkName || "").trim();
    if (!name) return;
    var runDrop = function() {
      ajaxWithBusy(PROC.DROP_DB_LINK, { x01: name }, "Dropping database link...", function(err, data) {
        if (err) {
          showError(err.responseText || "Unable to drop database link.");
          return;
        }
        if (!data.success) {
          showError(data.message || "Unable to drop database link.");
          return;
        }
        showSuccess("Connection dropped: " + name);
        refreshDbLinks();
      });
    };
    if (window.apex && apex.message && typeof apex.message.confirm === "function") {
      apex.message.confirm("Drop database connection '" + name + "'? This cannot be undone.", function(okPressed) {
        if (!okPressed) return;
        runDrop();
      });
    } else if (window.confirm("Drop database connection '" + name + "'? This cannot be undone.")) {
      runDrop();
    }
  }

  function loadDbLinkTables() {
    var dbLinkName = String($("#aoCatalogDbLinkSelect").val() || "").trim();
    if (!dbLinkName) {
      showError("Select a database connection.");
      return;
    }
    ajaxWithBusy(PROC.LIST_DB_LINK_TABLES, { x01: dbLinkName }, "Loading remote tables...", function(err, data) {
      if (err) {
        showError(err.responseText || "Unable to load remote tables.");
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to load remote tables.");
        return;
      }
      CATALOG_TABLE_ROWS = Array.isArray(data.tables) ? data.tables : [];
      renderCatalogTables();
    });
  }

  function createCatalogViews() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to create data collection.");
      return;
    }
    var dbLinkName = String($("#aoCatalogDbLinkSelect").val() || "").trim();
    var catalogName = String($("#aoCatalogName").val() || "").trim();
    var selected = [];
    $("#aoCatalogTables input[type='checkbox']:checked").each(function() {
      var idx = Number($(this).attr("data-cat-table-index"));
      if (Number.isNaN(idx) || !CATALOG_TABLE_ROWS[idx]) return;
      selected.push(CATALOG_TABLE_ROWS[idx]);
    });
    if (!dbLinkName) {
      showError("Select a database connection.");
      return;
    }
    if (!catalogName) {
      showError("Data collection name is required.");
      return;
    }
    if (!selected.length) {
      showError("Select at least one table.");
      return;
    }
    ajaxWithBusy(PROC.CREATE_CATALOG, {
      p_clob_01: JSON.stringify({
        catalog_name: catalogName,
        db_link_name: dbLinkName,
        tables: selected
      })
    }, "Creating data collection views...", function(err, data) {
      if (err) {
        if (window.console && window.console.error) {
          window.console.error("[Data Collection Create] Request failed", err);
        }
        showError(err.responseText || "Unable to create data collection.");
        return;
      }
      if (!data.success) {
        if (window.console && window.console.error) {
          window.console.error("[Data Collection Create] Backend error:", data.message || data);
        }
        showError(data.message || "Unable to create data collection.");
        return;
      }
      showSuccess("Data collection created: " + catalogName + " (" + selected.length + " views)");
      resetCatalogCreateForm();
      setCatalogCardView("list");
      loadCatalogHistory();
    });
  }

  function resetCatalogCreateForm() {
    $("#aoCatalogName").val("");
    $("#aoCatalogDbLinkSelect").val("");
    CATALOG_TABLE_ROWS = [];
    $("#aoCatalogTables").html("Select a database connection and load tables.");
  }

  function setCatalogCardView(target) {
    var mode = String(target || "list").toLowerCase();
    if (["list", "create"].indexOf(mode) < 0) mode = "list";
    $("#aoCatalogListCard, #aoCatalogCreateCard").hide();
    if (mode === "list") $("#aoCatalogListCard").show();
    if (mode === "create") $("#aoCatalogCreateCard").show();
    $("#aoOpenCatalogCreate").toggle(mode !== "create");
  }

  function dropCatalogByName(catalogNameInput) {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to drop data collection.");
      return;
    }
    var catalogName = String(catalogNameInput || "").trim();
    if (!catalogName) {
      showError("Data collection name is required.");
      return;
    }
    var runDrop = function() {
      ajaxWithBusy(PROC.CREATE_CATALOG, {
        x01: "__DROP__",
        x02: catalogName
      }, "Dropping data collection...", function(err, data) {
        if (err) {
          showError(err.responseText || "Unable to drop data collection.");
          return;
        }
        if (!data.success) {
          showError(data.message || "Unable to drop data collection.");
          return;
        }
        showSuccess("Data collection dropped: " + catalogName);
        loadCatalogHistory();
      });
    };
    if (window.apex && apex.message && typeof apex.message.confirm === "function") {
      apex.message.confirm("Drop data collection '" + catalogName + "'? Mapped views will be dropped.", function(okPressed) {
        if (!okPressed) return;
        runDrop();
      });
    } else if (window.confirm("Drop data collection '" + catalogName + "'? Mapped views will be dropped.")) {
      runDrop();
    }
  }

  function getNl2sqlProfilesForCatalogLink() {
    var rows = [];
    var seen = {};
    var bootstrapRows = (LAST_BOOTSTRAP_DATA && Array.isArray(LAST_BOOTSTRAP_DATA.nl2sql_profiles))
      ? LAST_BOOTSTRAP_DATA.nl2sql_profiles
      : [];

    bootstrapRows.forEach(function(row) {
      var value = String((row && (row.r || row.d)) || "").trim();
      if (!value) return;
      if (seen[value.toUpperCase()]) return;
      seen[value.toUpperCase()] = true;
      rows.push({
        name: value,
        subtitle: "NL2SQL AI profile"
      });
    });

    if (!rows.length) {
      $("#aoNl2sqlSelect option").each(function() {
        var value = String($(this).val() || "").trim();
        if (!value) return;
        if (seen[value.toUpperCase()]) return;
        seen[value.toUpperCase()] = true;
        rows.push({
          name: value,
          subtitle: "NL2SQL AI profile"
        });
      });
    }

    return rows.sort(function(a, b) {
      return String(a.name || "").localeCompare(String(b.name || ""));
    });
  }

  function normalizeCatalogObjectEntry(rawName, fallbackOwner) {
    var text = String(rawName || "").trim();
    var defaultOwner = String(fallbackOwner || "").trim();
    var match = text.match(/^([A-Za-z][A-Za-z0-9_$#]*)(?:\.([A-Za-z][A-Za-z0-9_$#]*))?$/);
    if (!match) return null;
    if (match[2]) {
      return {
        owner: String(match[1] || "").trim().toUpperCase(),
        name: String(match[2] || "").trim().toUpperCase()
      };
    }
    if (!defaultOwner) return null;
    return {
      owner: defaultOwner.toUpperCase(),
      name: String(match[1] || "").trim().toUpperCase()
    };
  }

  function buildCatalogObjectEntries(catalogNameInput) {
    var catalogName = String(catalogNameInput || "").trim().toUpperCase();
    var schemaOwner = getCurrentAppSchema();
    var seen = {};
    var entries = [];

    if (!catalogName) return entries;

    (CATALOG_HISTORY_ROWS || []).forEach(function(row) {
      if (String((row && row.catalog_name) || "").trim().toUpperCase() !== catalogName) return;
      var sourceOwner = String((row && row.source_owner) || "").trim();
      var fallbackOwner = schemaOwner || sourceOwner;
      var viewEntry = normalizeCatalogObjectEntry(String((row && row.view_name) || "").trim(), fallbackOwner);
      var key;
      if (!viewEntry) return;
      key = viewEntry.owner + "." + viewEntry.name;
      if (seen[key]) return;
      seen[key] = true;
      entries.push(viewEntry);
    });

    return entries;
  }

  function parseProfileObjectListLinesSafe(rawText) {
    var lines = parseLineArray(rawText);
    var schemaOwner = getCurrentAppSchema();
    var out = [];

    lines.forEach(function(line) {
      var entry;
      try {
        var parsed = parseObjectListLines(line);
        if (parsed.length) {
          if (parsed[0] && parsed[0].owner && parsed[0].name) {
            out.push({
              owner: String(parsed[0].owner || "").trim().toUpperCase(),
              name: String(parsed[0].name || "").trim().toUpperCase()
            });
          } else if (parsed[0] && parsed[0].owner) {
            out.push({ owner: String(parsed[0].owner || "").trim().toUpperCase() });
          }
          return;
        }
      } catch (e) {}
      entry = normalizeCatalogObjectEntry(line, schemaOwner);
      if (entry) out.push(entry);
    });

    return out;
  }

  function buildProfileAttrsPayloadFromRows(profileType, rows) {
    var normalizedType = String(profileType || "").trim().toUpperCase();
    var payload = {};

    (rows || []).forEach(function(row) {
      var attrName = String((row && row.attribute_name) || "").trim();
      var rawValue = row ? row.attribute_value : "";
      var value = String(rawValue == null ? "" : rawValue);
      var config;
      var parsed;
      var trimmed;
      var boolVal;

      if (!attrName) return;
      config = getProfileAttrConfig(normalizedType, attrName);

      if (config.type === "object_list") {
        parsed = parseProfileObjectListLinesSafe(value);
        if (parsed.length) payload[attrName] = parsed;
        return;
      }

      if (config.type === "boolean") {
        boolVal = parseBooleanLike(value);
        if (boolVal != null) payload[attrName] = boolVal;
        return;
      }

      if (config.type === "number") {
        trimmed = String(value || "").trim();
        if (trimmed !== "") payload[attrName] = Number(trimmed);
        return;
      }

      if (config.type === "string_array") {
        try {
          parsed = parseStopTokens(value);
        } catch (e) {
          parsed = parseLineArray(value);
        }
        if (parsed.length) payload[attrName] = parsed;
        return;
      }

      if (attrName === "input") {
        parsed = parseLineArray(value);
        if (parsed.length) payload[attrName] = parsed;
        return;
      }

      trimmed = String(value || "").trim();
      if (trimmed !== "") payload[attrName] = trimmed;
    });

    return payload;
  }

  function normalizeObjectListEntryForMerge(item) {
    var owner;
    var name;
    if (!item || typeof item !== "object") return null;
    owner = String(item.owner || "").trim().toUpperCase();
    name = String(item.name || "").trim().toUpperCase();
    if (owner && name) return { key: owner + "." + name, value: { owner: owner, name: name } };
    if (owner) return { key: owner, value: { owner: owner } };
    return null;
  }

  function mergeCatalogObjectsIntoProfileObjectList(existingEntries, catalogEntries) {
    var merged = [];
    var seen = {};
    var addedCount = 0;

    (existingEntries || []).forEach(function(item) {
      var normalized = normalizeObjectListEntryForMerge(item);
      if (!normalized) return;
      if (seen[normalized.key]) return;
      seen[normalized.key] = true;
      merged.push(normalized.value);
    });

    (catalogEntries || []).forEach(function(item) {
      var normalized = normalizeObjectListEntryForMerge(item);
      if (!normalized) return;
      if (seen[normalized.key]) return;
      seen[normalized.key] = true;
      merged.push(normalized.value);
      addedCount += 1;
    });

    return {
      merged: merged,
      added: addedCount
    };
  }

  function ensureUiToastHost() {
    if ($("#aoUiToastHost").length) return;
    $("body").append("<div id='aoUiToastHost' class='ao-ui-toast-host' aria-live='polite' aria-atomic='true'></div>");
  }

  function showUiToast(message, tone) {
    var text = String(message || "").trim();
    var normalizedTone = String(tone || "success").trim().toLowerCase();
    var className = "is-success";
    var toastId;
    var $toast;

    if (!text) return;
    if (normalizedTone === "error") className = "is-error";
    if (normalizedTone === "info") className = "is-info";

    ensureUiToastHost();
    toastId = "aoUiToast_" + Date.now() + "_" + Math.floor(Math.random() * 100000);
    $toast = $("<div id='" + escapeAttr(toastId) + "' class='ao-ui-toast " + className + "' role='status'></div>");
    $toast.text(text);
    $("#aoUiToastHost").append($toast);
    window.setTimeout(function() {
      $toast.addClass("is-visible");
    }, 20);
    window.setTimeout(function() {
      $toast.removeClass("is-visible");
      window.setTimeout(function() { $toast.remove(); }, 220);
    }, 3200);
  }

  function renderCatalogProfileLinkOptions(selectedProfile) {
    var rows = getNl2sqlProfilesForCatalogLink();
    var normalizedSelected = String(selectedProfile || "").trim().toUpperCase();
    var selectedValue = normalizedSelected ? "" : String((rows[0] && rows[0].name) || "").trim();
    var html = "";

    if (!rows.length) {
      $("#aoCatalogProfileList").html("<div class='ao-muted-box'>No NL2SQL AI profiles found. Create one first, then link this data collection.</div>");
      $("#aoCatalogProfileLinkAdd").prop("disabled", true);
      ACTIVE_CATALOG_PROFILE_LINK.profileName = "";
      return;
    }

    rows.forEach(function(row) {
      var name = String((row && row.name) || "").trim();
      var subtitle = String((row && row.subtitle) || "").trim();
      var isSelected = normalizedSelected ? normalizedSelected === name.toUpperCase() : selectedValue && selectedValue.toUpperCase() === name.toUpperCase();
      if (isSelected) selectedValue = name;
      html += "<button type='button' class='ao-catalog-profile-option" + (isSelected ? " is-active" : "") + "' data-catalog-profile-option='" + escapeAttr(name) + "'>";
      html += "  <span class='ao-catalog-profile-option-name'>" + apex.util.escapeHTML(name) + "</span>";
      html += "  <span class='ao-catalog-profile-option-subtitle'>" + apex.util.escapeHTML(subtitle || "NL2SQL AI profile") + "</span>";
      html += "</button>";
    });

    $("#aoCatalogProfileList").html(html);
    ACTIVE_CATALOG_PROFILE_LINK.profileName = selectedValue;
    $("#aoCatalogProfileLinkAdd").prop("disabled", !ACTIVE_CATALOG_PROFILE_LINK.profileName);
  }

  function closeCatalogProfileLinkDialog() {
    ACTIVE_CATALOG_PROFILE_LINK.catalogName = "";
    ACTIVE_CATALOG_PROFILE_LINK.profileName = "";
    $("#aoCatalogProfileLinkCatalogName").text("");
    $("#aoCatalogProfileLinkSummary").text("");
    $("#aoCatalogProfileList").html("");
    $("#aoCatalogProfileLinkAdd").prop("disabled", true);
    $("#aoCatalogProfileLinkDialog").addClass("is-hidden");
  }

  function openCatalogProfileLinkDialog(catalogNameInput) {
    var catalogName = String(catalogNameInput || "").trim();
    var catalogEntries;
    var defaultProfile;

    if (!catalogName) {
      showError("Data collection name is required.");
      return;
    }
    catalogEntries = buildCatalogObjectEntries(catalogName);
    if (!catalogEntries.length) {
      showError("No data collection objects found to link for '" + catalogName + "'.");
      return;
    }

    ACTIVE_CATALOG_PROFILE_LINK.catalogName = catalogName;
    defaultProfile = selectedProfileValue("NL2SQL");
    ACTIVE_CATALOG_PROFILE_LINK.profileName = String(defaultProfile || "").trim();

    $("#aoCatalogProfileLinkCatalogName").text(catalogName);
    $("#aoCatalogProfileLinkSummary").text(
      "This will append " +
      catalogEntries.length +
      " view" +
      (catalogEntries.length === 1 ? "" : "s") +
      " from this data collection to the selected NL2SQL profile object list."
    );
    renderCatalogProfileLinkOptions(ACTIVE_CATALOG_PROFILE_LINK.profileName);
    $("#aoCatalogProfileLinkDialog").removeClass("is-hidden");
  }

  function addCatalogToAiProfile() {
    var catalogName = String(ACTIVE_CATALOG_PROFILE_LINK.catalogName || "").trim();
    var profileName = String(ACTIVE_CATALOG_PROFILE_LINK.profileName || "").trim();
    var catalogEntries = buildCatalogObjectEntries(catalogName);

    if (!catalogName) {
      showError("Data collection name is required.");
      return;
    }
    if (!profileName) {
      showError("Choose an NL2SQL AI profile.");
      return;
    }
    if (!catalogEntries.length) {
      showError("No data collection objects found to link for '" + catalogName + "'.");
      return;
    }

    ajaxWithBusy(PROC.GET_PROFILE_ATTRS, {
      x01: "NL2SQL",
      x02: profileName,
      pageItems: "#P20000_SERVICE,#P20000_RAGSERVICE"
    }, "Loading AI profile attributes...", function(loadErr, loadData) {
      if (loadErr) {
        showError(loadErr.responseText || "Unable to load AI profile attributes.");
        return;
      }
      if (!loadData || loadData.success === false) {
        showError((loadData && loadData.message) || "Unable to load AI profile attributes.");
        return;
      }

      var attrsPayload = buildProfileAttrsPayloadFromRows("NL2SQL", loadData.attributes);
      var mergeResult = mergeCatalogObjectsIntoProfileObjectList(attrsPayload.object_list, catalogEntries);
      attrsPayload.object_list = mergeResult.merged;

      ajaxWithBusy(PROC.SAVE_PROFILE_ATTRS, {
        x01: "NL2SQL",
        x02: profileName,
        p_clob_01: JSON.stringify(attrsPayload),
        pageItems: "#P20000_SERVICE,#P20000_RAGSERVICE"
      }, "Linking data collection to AI profile...", function(saveErr, saveData) {
        if (saveErr) {
          showError(saveErr.responseText || "Unable to save AI profile attributes.");
          return;
        }
        if (!saveData || saveData.success === false) {
          showError((saveData && saveData.message) || "Unable to save AI profile attributes.");
          return;
        }

        closeCatalogProfileLinkDialog();
        if (selectedProfileValue("NL2SQL").toUpperCase() === profileName.toUpperCase()) {
          loadAttrs("NL2SQL");
        }
        if (mergeResult.added > 0) {
          showUiToast("Successfully added " + mergeResult.added + " data collection views to " + profileName + ".", "success");
        } else {
          showUiToast("All data collection views are already present in " + profileName + ".", "info");
        }
      });
    });
  }

  function buildAgentLovRows(agentsRows, teamAttrRows) {
    var out = [];
    var seen = {};

    (agentsRows || []).forEach(function(row) {
      var name = String(getAgentRowValue(row, ["agent_name", "name", "agent"]) || "").trim();
      var key = normalizeAgentName(name);
      if (!name || seen[key]) return;
      seen[key] = true;
      out.push({ d: name, r: name });
    });

    parseAgentMappingsFromTeamAttrs(teamAttrRows).forEach(function(mapping) {
      var name = String(mapping.name || "").trim();
      var key = normalizeAgentName(name);
      if (!name || seen[key]) return;
      seen[key] = true;
      out.push({ d: name, r: name });
    });

    return out;
  }

  function renderAgentTeamDetailsByAgent(selectedAgentName) {
    if (!CURRENT_AGENT_TEAM_DATA) {
      renderAgentEntityCards("#aoAgentTeamAgents", [], "No agents found.");
      renderAgentEntityCards("#aoAgentTeamTasks", [], "No tasks found.");
      renderAgentEntityCards("#aoAgentTeamTools", [], "No tools found.");
      return;
    }

    var selectedAgent = String(selectedAgentName || "").trim();
    var taskNames = getTaskNamesForAgent(CURRENT_AGENT_TEAM_DATA.teamAttrRows, selectedAgent);

    renderAgentEntityCards(
      "#aoAgentTeamAgents",
      buildAgentCards(CURRENT_AGENT_TEAM_DATA.teamAttrRows, CURRENT_AGENT_TEAM_DATA.agentAttrRows, selectedAgent),
      "No agents found."
    );
    renderAgentEntityCards(
      "#aoAgentTeamTasks",
      buildTaskCards(CURRENT_AGENT_TEAM_DATA.tasksRows, CURRENT_AGENT_TEAM_DATA.taskAttrRows, CURRENT_AGENT_TEAM_DATA.teamAttrRows, selectedAgent),
      "No tasks found."
    );
    renderAgentEntityCards(
      "#aoAgentTeamTools",
      buildToolCards(CURRENT_AGENT_TEAM_DATA.toolsRows, CURRENT_AGENT_TEAM_DATA.toolAttrRows, CURRENT_AGENT_TEAM_DATA.taskAttrRows, taskNames),
      "No tools found."
    );
  }

  function getCurrentTeamName() {
    return String($("#aoAgentTeamPicker").val() || "").trim();
  }

  function resetDropAgentTeamConfirm() {
    $("#aoDropAgentTeamMap")
      .removeClass("is-confirming")
      .text("Drop Team");
  }

  function getMappingForAgent(agentName) {
    var targetKey = normalizeAgentName(agentName);
    var mappings = CURRENT_AGENT_TEAM_DATA ? parseAgentMappingsFromTeamAttrs(CURRENT_AGENT_TEAM_DATA.teamAttrRows) : [];
    var fallback = null;
    for (var i = 0; i < mappings.length; i += 1) {
      if (!fallback && mappings[i] && String(mappings[i].name || "").trim()) {
        fallback = mappings[i];
      }
      if (targetKey && normalizeAgentName(mappings[i].name) === targetKey) {
        return mappings[i];
      }
    }
    return fallback;
  }

  function getSelectedBuilderMapContext() {
    var $selected = $("#aoAgentTeamMap .ao-team-node.is-map-node-selected").first();
    var type = String($selected.attr("data-map-type") || "").trim().toUpperCase();
    var name = String($selected.attr("data-map-name") || "").trim();
    var agentName = String($selected.attr("data-map-agent") || "").trim();
    var mapping;

    if (type === "AGENT") {
      agentName = name;
      mapping = getMappingForAgent(agentName);
      return {
        agentName: agentName,
        taskName: String((mapping && mapping.task) || "").trim()
      };
    }

    if (type === "TASK") {
      mapping = getMappingForAgent(agentName);
      return {
        agentName: String((mapping && mapping.name) || agentName || "").trim(),
        taskName: name
      };
    }

    if (type === "TOOL") {
      mapping = getMappingForAgent(agentName);
      return {
        agentName: String((mapping && mapping.name) || agentName || "").trim(),
        taskName: String((mapping && mapping.task) || "").trim()
      };
    }

    mapping = getMappingForAgent(agentName);
    return {
      agentName: String((mapping && mapping.name) || "").trim(),
      taskName: String((mapping && mapping.task) || "").trim()
    };
  }

  function applyExistingAgentDetailsToStudio(agentName) {
    var selectedAgent = String(agentName || $("#aoAgentStudioExistingAgent").val() || "").trim();
    var profileName;
    var role;
    var humanTool;
    if (!selectedAgent) return;
    profileName = CURRENT_AGENT_TEAM_DATA
      ? String(getEntityAttributeValue("AGENT", selectedAgent, "profile_name") || "").trim()
      : "";
    if (!profileName) {
      profileName = String(AGENT_PROFILE_LOOKUP[normalizeAgentName(selectedAgent)] || "").trim();
    }
    role = CURRENT_AGENT_TEAM_DATA
      ? String(getEntityAttributeValue("AGENT", selectedAgent, "role") || "").trim()
      : "";
    humanTool = CURRENT_AGENT_TEAM_DATA
      ? getEntityAttributeValue("AGENT", selectedAgent, "enable_human_tool")
      : "";
    if (profileName) {
      ensureSelectOption("#aoAgentStudioProfile", profileName);
      $("#aoAgentStudioProfile").val(profileName);
    }
    if (role) $("#aoAgentStudioRole").val(role);
    if (humanTool != null && String(humanTool).trim()) {
      $("#aoAgentStudioHumanTool").val(booleanValueToSelect(humanTool));
    }
  }

  function openCurrentTeamInAgentBuilder() {
    var teamName = getCurrentTeamName();
    var context;
    var allMappings;
    var allTasks = [];
    var uniqueTools = [];
    var seenToolByTask = {};
    var primaryKey;
    if (!CURRENT_AGENT_TEAM_DATA || !teamName) {
      showError("Select an agent team first.");
      return;
    }

    context = getSelectedBuilderMapContext();
    allMappings = parseAgentMappingsFromTeamAttrs(CURRENT_AGENT_TEAM_DATA.teamAttrRows);
    allMappings.forEach(function(mapping) {
      var taskName = String((mapping && mapping.task) || "").trim();
      if (taskName && allTasks.indexOf(taskName) < 0) allTasks.push(taskName);
    });

    resetAgentStudioFlow();
    $("#aoAgentStudioTeamName").val(teamName);
    $("#aoAgentStudioGuardrails").val(CURRENT_AGENT_TEAM_DATA.teamDescription || getEntityDescription("TEAM", teamName));

    if (context.agentName) {
      $("#aoAgentStudioAgentMode").val("existing");
      ensureSelectOption("#aoAgentStudioExistingAgent", context.agentName);
      $("#aoAgentStudioExistingAgent").val(context.agentName);
      $("#aoAgentStudioAgentName").val(context.agentName);
      applyExistingAgentDetailsToStudio(context.agentName);
    }

    if (context.taskName) {
      $("#aoAgentStudioTaskMode").val("existing");
      ensureSelectOption("#aoAgentStudioExistingTask", context.taskName);
      $("#aoAgentStudioExistingTask").val(context.taskName);
      $("#aoAgentStudioTaskName").val(context.taskName);
      $("#aoAgentStudioTaskGoal").val(String(getEntityAttributeValue("TASK", context.taskName, "instruction") || "").trim());
      $("#aoAgentStudioTaskDescription").val(getEntityDescription("TASK", context.taskName));
      autoGrowTextareas("#aoAgentStudioTaskGoal");
    }

    AGENT_STUDIO_TOOLS = [];
    AGENT_STUDIO_TOOL_TASK_MAP = {};
    allTasks.forEach(function(taskName) {
      var taskTools = collectToolNamesFromTaskAttrs(CURRENT_AGENT_TEAM_DATA.taskAttrRows, [taskName]) || [];
      taskTools.forEach(function(toolName) {
        var toolKey = String(toolName || "").trim().toUpperCase();
        var bindingKey;
        if (!toolKey) return;
        if (uniqueTools.indexOf(toolName) < 0) uniqueTools.push(toolName);
        if (!Array.isArray(AGENT_STUDIO_TOOL_TASK_MAP[toolKey])) AGENT_STUDIO_TOOL_TASK_MAP[toolKey] = [];
        bindingKey = toolKey + "||" + String(taskName || "").trim().toUpperCase();
        if (!seenToolByTask[bindingKey]) {
          AGENT_STUDIO_TOOL_TASK_MAP[toolKey].push(taskName);
          seenToolByTask[bindingKey] = true;
        }
      });
    });
    AGENT_STUDIO_TOOLS = uniqueTools.slice();
    AGENT_STUDIO_TOOL_GROUP_POSITIONS = {};
    AGENT_STUDIO_TOOL_POSITIONS = {};
    AGENT_STUDIO_TEAM_MAPPINGS = allMappings.filter(function(mapping) {
      return normalizeStudioMappingKey(mapping.name, mapping.task) !== normalizeStudioMappingKey(context.agentName, context.taskName);
    }).map(function(mapping) {
      return {
        name: String(mapping.name || "").trim(),
        task: String(mapping.task || "").trim()
      };
    }).filter(function(mapping) {
      return mapping.name && mapping.task;
    });
    moveAgentEditorToManage();
    AGENT_BUILDER_MODE = "graphical";
    openFreshScreen("agent-teams:manage");
    setNav("agent-teams", "agent-builder");
    setAgentCreatePanel("overview");
    syncAgentStudioModeUi();
    updateAgentStudioCanvas();
    renderAgentStudioSelectedTools();
    renderAgentStudioReview();
    setAgentStudioStep(context.agentName ? 2 : 1);
    setAgentStudioEditorVisible(false);
    showSuccess("Loaded team in Agent Builder.");
  }

  function dropSelectedAgentTeam(buttonNode) {
    var teamName = getCurrentTeamName();
    var $button = $(buttonNode || "#aoDropAgentTeamMap");
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to drop agent teams.");
      return;
    }
    if (!teamName) {
      showError("Select an agent team to drop.");
      return;
    }
    if (!$button.hasClass("is-confirming")) {
      $button.addClass("is-confirming").text("Confirm Drop Team");
      return;
    }

    ajaxWithBusy(PROC.DROP_AGENT_TEAM, { x01: teamName }, "Dropping agent team...", function(err, data) {
      if (err) {
        showError(err.responseText || "Unable to drop agent team.");
        resetDropAgentTeamConfirm();
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to drop agent team.");
        resetDropAgentTeamConfirm();
        return;
      }
      showSuccess("Agent team dropped: " + teamName);
      $("#aoAgentTeamPicker").val("");
      resetDropAgentTeamConfirm();
      clearAgentTeamBoxes();
      bootstrap();
    });
  }

  function getCurrentEditorEntityType() {
    return String($("#aoAgentEditEntityType").val() || "TEAM").trim().toUpperCase();
  }

  function getCurrentEditorEntityName() {
    return String($("#aoAgentEditEntityName").val() || "").trim();
  }

  function getEntityMetaRows(entityType) {
    if (!CURRENT_AGENT_TEAM_DATA) return [];
    switch (String(entityType || "").trim().toUpperCase()) {
      case "TEAM":
        return CURRENT_AGENT_TEAM_DATA.teamMetaRows || [];
      case "AGENT":
        return CURRENT_AGENT_TEAM_DATA.agentMetaRows || [];
      case "TASK":
        return CURRENT_AGENT_TEAM_DATA.taskMetaRows || [];
      case "TOOL":
        return CURRENT_AGENT_TEAM_DATA.toolMetaRows || [];
      default:
        return [];
    }
  }

  function getEntityAttrRows(entityType) {
    if (!CURRENT_AGENT_TEAM_DATA) return [];
    switch (String(entityType || "").trim().toUpperCase()) {
      case "TEAM":
        return CURRENT_AGENT_TEAM_DATA.teamAttrRows || [];
      case "AGENT":
        return CURRENT_AGENT_TEAM_DATA.agentAttrRows || [];
      case "TASK":
        return CURRENT_AGENT_TEAM_DATA.taskAttrRows || [];
      case "TOOL":
        return CURRENT_AGENT_TEAM_DATA.toolAttrRows || [];
      default:
        return [];
    }
  }

  function getEntityNameRows(entityType) {
    if (!CURRENT_AGENT_TEAM_DATA) return [];
    switch (String(entityType || "").trim().toUpperCase()) {
      case "TEAM":
        return [{ d: getCurrentTeamName(), r: getCurrentTeamName() }];
      case "AGENT":
        return buildAgentLovRows(CURRENT_AGENT_TEAM_DATA.agentsRows, CURRENT_AGENT_TEAM_DATA.teamAttrRows);
      case "TASK":
        return getTaskNamesForAgent(CURRENT_AGENT_TEAM_DATA.teamAttrRows, "")
          .map(function(name) { return { d: name, r: name }; });
      case "TOOL":
        return buildToolCards(CURRENT_AGENT_TEAM_DATA.toolsRows, CURRENT_AGENT_TEAM_DATA.toolAttrRows, CURRENT_AGENT_TEAM_DATA.taskAttrRows, [])
          .map(function(card) { return { d: card.title, r: card.title }; });
      default:
        return [];
    }
  }

  function uniqueLovRows(rows) {
    var out = [];
    var seen = {};
    (rows || []).forEach(function(row) {
      var value = String((row && (row.r || row.R || row.value || row.VALUE || row.d || row.D)) || "").trim();
      var display = String((row && (row.d || row.D || row.label || row.LABEL)) || value).trim();
      var key = value.toUpperCase();
      if (!value || seen[key]) return;
      seen[key] = true;
      out.push({ d: display, r: value });
    });
    return out;
  }

  function getExistingAgentEntityRows(entityType) {
    var type = String(entityType || "").trim().toUpperCase();
    return uniqueLovRows((ALL_AGENT_ENTITY_OPTIONS[type] || []).concat(getEntityNameRows(type)));
  }

  function agentEntityExists(entityType, entityName) {
    var target = String(entityName || "").trim().toUpperCase();
    if (!target) return false;
    return getExistingAgentEntityRows(entityType).some(function(row) {
      return String((row && row.r) || (row && row.d) || "").trim().toUpperCase() === target;
    });
  }

  function duplicateAgentEntityMessage(entityType, entityName) {
    var label = String(entityType || "item").trim().toLowerCase();
    return label.charAt(0).toUpperCase() + label.slice(1) + " '" + entityName + "' already exists. Use a different name or edit the existing " + label + ".";
  }

  function assertAgentCreateNameAvailable(entityType, entityName, fieldSelector) {
    var name = String(entityName || "").trim();
    var message;
    if (!name || !agentEntityExists(entityType, name)) return;
    message = duplicateAgentEntityMessage(entityType, name);
    if (fieldSelector) markFieldError(fieldSelector, message);
    throw new Error(message);
  }

  function filterBackendCallableRows(rows) {
    var normalizedRows = uniqueLovRows(rows || []);
    debugSettingsLog("backend callable filter", {
      raw_count: (rows || []).length,
      normalized_count: normalizedRows.length,
      filtered_count: normalizedRows.length,
      raw_sample: (rows || []).slice(0, 5),
      filtered_sample: normalizedRows.slice(0, 5)
    });
    return normalizedRows;
  }

  function getToolOptionSearchText(row) {
    var value = String((row && row.r) || "").trim();
    var label = String((row && row.d) || value).trim();
    var description = "";
    if (CURRENT_AGENT_TEAM_DATA && value) {
      description = getEntityDescription("TOOL", value);
    }
    return (value + " " + label + " " + description).toLowerCase();
  }

  function filterToolLovRows(rows, query, selectedValues) {
    var q = String(query || "").trim().toLowerCase();
    var selected = {};
    (Array.isArray(selectedValues) ? selectedValues : []).forEach(function(value) {
      selected[String(value || "").trim().toUpperCase()] = true;
    });
    if (!q) return rows || [];
    return (rows || []).filter(function(row) {
      var value = String((row && row.r) || "").trim();
      return selected[value.toUpperCase()] || getToolOptionSearchText(row).indexOf(q) >= 0;
    });
  }

  function refreshToolFilteredSelects() {
    var selectedCreateTools = getSelectValues("#aoAgentCreateTaskTools");
    var createQuery = String($("#aoAgentCreateTaskToolFilter").val() || "");
    fillMultiSelect(
      "#aoAgentCreateTaskTools",
      filterToolLovRows(AGENT_CREATE_ENTITY_OPTIONS.TOOL, createQuery, selectedCreateTools),
      selectedCreateTools
    );

    if (getCurrentEditorEntityType() === "TOOL") {
      var currentTool = $("#aoAgentEditEntityName").val();
      var editQuery = String($("#aoAgentEditToolFilter").val() || "");
      fillSelect("#aoAgentEditEntityName", filterToolLovRows(getEntityNameRows("TOOL"), editQuery, currentTool ? [currentTool] : []), currentTool);
    }
  }

  function refreshAgentCreateLinkOptions() {
    AGENT_CREATE_ENTITY_OPTIONS.AGENT = uniqueLovRows((ALL_AGENT_ENTITY_OPTIONS.AGENT || []).concat(getEntityNameRows("AGENT")));
    AGENT_CREATE_ENTITY_OPTIONS.TASK = uniqueLovRows((ALL_AGENT_ENTITY_OPTIONS.TASK || []).concat(getEntityNameRows("TASK")));
    AGENT_CREATE_ENTITY_OPTIONS.TOOL = uniqueLovRows((ALL_AGENT_ENTITY_OPTIONS.TOOL || []).concat(getEntityNameRows("TOOL")));

    fillMultiSelect("#aoAgentCreateTaskTools", AGENT_CREATE_ENTITY_OPTIONS.TOOL, getSelectValues("#aoAgentCreateTaskTools"));
    fillMultiSelect("#aoAgentCreateTaskInputs", AGENT_CREATE_ENTITY_OPTIONS.TASK, getSelectValues("#aoAgentCreateTaskInputs"));
    fillSelect("#aoAgentCreateTeamAgent", AGENT_CREATE_ENTITY_OPTIONS.AGENT, $("#aoAgentCreateTeamAgent").val());
    fillSelect("#aoAgentCreateTeamTask", AGENT_CREATE_ENTITY_OPTIONS.TASK, $("#aoAgentCreateTeamTask").val());
    fillSelect("#aoAgentEditTeamAgent", AGENT_CREATE_ENTITY_OPTIONS.AGENT, $("#aoAgentEditTeamAgent").val());
    fillSelect("#aoAgentEditTeamTask", AGENT_CREATE_ENTITY_OPTIONS.TASK, $("#aoAgentEditTeamTask").val());
    fillSelect("#aoAgentStudioExistingAgent", AGENT_CREATE_ENTITY_OPTIONS.AGENT, $("#aoAgentStudioExistingAgent").val());
    fillSelect("#aoAgentStudioExistingTask", AGENT_CREATE_ENTITY_OPTIONS.TASK, $("#aoAgentStudioExistingTask").val());
    fillSelect("#aoAgentStudioTeamAgent", AGENT_CREATE_ENTITY_OPTIONS.AGENT, $("#aoAgentStudioTeamAgent").val());
    fillSelect("#aoAgentStudioTeamTask", AGENT_CREATE_ENTITY_OPTIONS.TASK, $("#aoAgentStudioTeamTask").val());
    fillSelect("#aoAgentStudioNewToolFunction", BACKEND_CALLABLE_OPTIONS, $("#aoAgentStudioNewToolFunction").val());
    refreshAgentStudioOptions();
    refreshToolFilteredSelects();
  }

  function getEntityDescription(entityType, entityName) {
    var type = String(entityType || "").trim().toUpperCase();
    var target = String(entityName || "").trim();
    var rows = getEntityMetaRows(type);
    if (type === "TEAM") {
      return String((rows[0] && getAgentRowValue(rows[0], ["description"])) || CURRENT_AGENT_TEAM_DATA.teamDescription || "").trim();
    }
    for (var i = 0; i < rows.length; i += 1) {
      var rowName = String(getAgentRowValue(rows[i], ["agent_name", "task_name", "tool_name", "name"]) || "").trim();
      if (rowName !== target) continue;
      return String(getAgentRowValue(rows[i], ["description"]) || "").trim();
    }
    return "";
  }

  function getEntityAttributeValue(entityType, entityName, attrName) {
    var type = String(entityType || "").trim().toUpperCase();
    var target = String(entityName || "").trim();
    var wantedAttr = String(attrName || "").trim().toLowerCase();
    var rows = getEntityAttrRows(type);

    for (var i = 0; i < rows.length; i += 1) {
      var row = rows[i];
      var rowAttr = String(getAgentRowValue(row, ["attribute_name", "attr_name", "name"]) || "").trim().toLowerCase();
      var rowEntity = String(getAgentRowValue(row, ["agent_name", "task_name", "tool_name", "agent_team_name", "team_name", "name"]) || "").trim();
      if (type !== "TEAM" && rowEntity !== target) continue;
      if (rowAttr !== wantedAttr) continue;
      return getAgentRowValue(row, ["attribute_value", "attr_value", "value", "val"]);
    }
    return "";
  }

  function formatAgentMappingsForEditor(teamAttrRows) {
    return parseAgentMappingsFromTeamAttrs(teamAttrRows).map(function(item) {
      return String(item.name || "").trim() + " => " + String(item.task || "").trim();
    }).join("\n");
  }

  function renderEditTeamMappingList() {
    var mappings;
    var html = "";
    try {
      mappings = parseAgentMappingsForSave($("#aoAgentEditTeamAgents").val());
    } catch (e) {
      mappings = [];
    }
    if (!mappings.length) {
      $("#aoAgentEditTeamMappingList").html("<div class='ao-muted-box'>No agent to task mappings added.</div>");
      return;
    }
    mappings.forEach(function(item, index) {
      html += "<div class='ao-mapping-row'>";
      html += "<span class='ao-mapping-node ao-mapping-node--agent'>" + apex.util.escapeHTML(item.name) + "</span>";
      html += "<span class='ao-mapping-arrow' aria-hidden='true'>→</span>";
      html += "<span class='ao-mapping-node ao-mapping-node--task'>" + apex.util.escapeHTML(item.task) + "</span>";
      html += "<button type='button' class='ao-link-btn ao-remove-edit-team-mapping' data-index='" + index + "'>Remove</button>";
      html += "</div>";
    });
    $("#aoAgentEditTeamMappingList").html(html);
  }

  function setEditTeamMappings(mappings) {
    var text = (mappings || []).map(function(item) {
      return String(item.name || "").trim() + " => " + String(item.task || "").trim();
    }).join("\n");
    $("#aoAgentEditTeamAgents").val(text);
    renderEditTeamMappingList();
  }

  function parseAgentMappingsForSave(textValue) {
    var out = [];
    var seen = {};
    String(textValue || "").split(/\r?\n/).forEach(function(line) {
      var raw = String(line || "").trim();
      var parts;
      var agentName;
      var taskName;
      var key;
      if (!raw) return;
      parts = raw.split(/\s*=>\s*/);
      if (parts.length < 2) {
        throw new Error("Agent mappings must use 'Agent Name => Task Name' format.");
      }
      agentName = String(parts.shift() || "").trim();
      taskName = String(parts.join("=>") || "").trim();
      if (!agentName || !taskName) {
        throw new Error("Each agent mapping must include both an agent and a task.");
      }
      if (validateIdentifierValue(agentName, "Agent")) {
        throw new Error("Invalid agent name in mapping: '" + agentName + "'. Agent names must use letters, numbers, and underscores with no spaces.");
      }
      if (validateIdentifierValue(taskName, "Task")) {
        throw new Error("Invalid task name in mapping: '" + taskName + "'. Task names must use letters, numbers, and underscores with no spaces.");
      }
      key = agentName.toUpperCase() + "|" + taskName.toUpperCase();
      if (seen[key]) return;
      seen[key] = true;
      out.push({ name: agentName, task: taskName });
    });
    return out;
  }

  function autoGrowTextarea(node) {
    var el = node && node.jquery ? node[0] : node;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.max(el.scrollHeight, 96) + "px";
  }

  function autoGrowTextareas(selector) {
    $(selector).each(function() {
      autoGrowTextarea(this);
    });
  }

  function getAgentStudioState() {
    var agentMode = String($("#aoAgentStudioAgentMode").val() || "new").trim().toLowerCase();
    var taskMode = String($("#aoAgentStudioTaskMode").val() || "new").trim().toLowerCase();
    var toolMode = String($("#aoAgentStudioToolMode").val() || "existing").trim().toLowerCase();
    var existingAgent = String($("#aoAgentStudioExistingAgent").val() || "").trim();
    var existingTask = String($("#aoAgentStudioExistingTask").val() || "").trim();
    return {
      teamMode: "new",
      agentMode: agentMode === "existing" ? "existing" : "new",
      taskMode: taskMode === "existing" ? "existing" : "new",
      toolMode: toolMode === "new" ? "new" : "existing",
      taskName: taskMode === "existing" ? existingTask : String($("#aoAgentStudioTaskName").val() || "").trim(),
      taskGoal: String($("#aoAgentStudioTaskGoal").val() || "").trim(),
      taskDescription: String($("#aoAgentStudioTaskDescription").val() || "").trim(),
      agentName: agentMode === "existing" ? existingAgent : String($("#aoAgentStudioAgentName").val() || "").trim(),
      profileName: String($("#aoAgentStudioProfile").val() || "").trim(),
      role: String($("#aoAgentStudioRole").val() || "").trim(),
      humanTool: String($("#aoAgentStudioHumanTool").val() || "").trim(),
      teamDescription: String($("#aoAgentStudioGuardrails").val() || "").trim(),
      teamName: String($("#aoAgentStudioTeamName").val() || "").trim(),
      teamMappings: AGENT_STUDIO_TEAM_MAPPINGS.slice(),
      tools: AGENT_STUDIO_TOOLS.slice(),
      toolTaskMap: (function() {
        var out = {};
        Object.keys(AGENT_STUDIO_TOOL_TASK_MAP || {}).forEach(function(key) {
          out[key] = Array.isArray(AGENT_STUDIO_TOOL_TASK_MAP[key])
            ? AGENT_STUDIO_TOOL_TASK_MAP[key].slice()
            : [];
        });
        return out;
      }())
    };
  }

  function getToolTaskBindings(toolName) {
    var key = String(toolName || "").trim().toUpperCase();
    var bindings = AGENT_STUDIO_TOOL_TASK_MAP[key];
    if (!Array.isArray(bindings)) return [];
    return bindings.filter(function(taskName) { return !!String(taskName || "").trim(); });
  }

  function refreshAgentStudioOptions() {
    var currentProfile = $("#aoAgentStudioProfile").val();
    var currentTool = $("#aoAgentStudioToolSelect").val();
    fillSelect("#aoAgentStudioProfile", ALL_PROFILE_OPTIONS, currentProfile);
    if (currentProfile) {
      ensureSelectOption("#aoAgentStudioProfile", currentProfile);
      $("#aoAgentStudioProfile").val(currentProfile);
    }
    fillSelect("#aoAgentStudioToolSelect", AGENT_CREATE_ENTITY_OPTIONS.TOOL, currentTool);
    renderAgentStudioToolList();
    renderAgentStudioSelectedTools();
    syncAgentStudioModeUi();
    updateAgentStudioCanvas();
  }

  function renderAgentStudioToolList() {
    if (!$("#aoAgentStudioToolList").length) return;
    var query = String($("#aoAgentStudioToolSearch").val() || "").trim().toLowerCase();
    var html = "";
    (AGENT_CREATE_ENTITY_OPTIONS.TOOL || []).forEach(function(row) {
      var name = String((row && row.r) || "").trim();
      var label = String((row && row.d) || name).trim();
      if (!name) return;
      if (query && (name + " " + label).toLowerCase().indexOf(query) < 0) return;
      html += "<div class='ao-studio-component-card' draggable='true' tabindex='0' data-studio-tool='" + escapeAttr(name) + "'>";
      html += "<strong>" + apex.util.escapeHTML(label) + "</strong>";
      html += "<span>Drag to canvas or click to connect</span>";
      html += "</div>";
    });
    if (!html) html = "<div class='ao-muted-box'>No tools found. Create a tool first or adjust the search.</div>";
    $("#aoAgentStudioToolList").html(html);
  }

  function renderAgentStudioTaskBindingOptions() {
    var $select = $("#aoAgentStudioToolTaskSelect");
    var tasks = getAgentStudioTaskCandidates();
    var current = String($select.val() || "").trim();
    var html = "";
    if (!$select.length) return;
    if (!tasks.length) {
      $select.html("<option value=''>- Select Task -</option>").val("");
      return;
    }
    tasks.forEach(function(taskName) {
      html += "<option value='" + escapeAttr(taskName) + "'>" + apex.util.escapeHTML(taskName) + "</option>";
    });
    $select.html(html);
    if (current && tasks.indexOf(current) >= 0) {
      $select.val(current);
    } else {
      $select.val(tasks[0]);
    }
  }

  function getAgentStudioTaskCandidates() {
    var state = getAgentStudioState();
    var tasks = [];
    function pushTask(name) {
      var value = String(name || "").trim();
      if (!value || tasks.indexOf(value) >= 0) return;
      tasks.push(value);
    }
    pushTask(state.taskName);
    (state.teamMappings || []).forEach(function(mapping) {
      pushTask(mapping && mapping.task);
    });
    return tasks;
  }

  function resolveAgentStudioToolTask(toolName, preferredTaskName) {
    var candidates = getAgentStudioTaskCandidates();
    var preferred = String(preferredTaskName || "").trim();
    var selected = String($("#aoAgentStudioToolTaskSelect").val() || "").trim();
    if (preferred && candidates.indexOf(preferred) >= 0) return preferred;
    if (selected && candidates.indexOf(selected) >= 0) return selected;
    if (candidates.length <= 1) return String(candidates[0] || "").trim();
    showError("Select the task in the editor before connecting this tool.");
    return "";
  }

  function addAgentStudioTool(toolName, preferredTaskName) {
    var name = String(toolName || "").trim();
    var taskName;
    var key;
    var currentBindings;
    if (!name) {
      showError("Choose a tool to connect.");
      return;
    }
    taskName = resolveAgentStudioToolTask(name, preferredTaskName);
    if (!taskName) return;
    key = String(name || "").trim().toUpperCase();
    currentBindings = getToolTaskBindings(name);
    if (currentBindings.indexOf(taskName) >= 0) {
      updateAgentStudioCanvas();
      renderAgentStudioReview();
      return;
    }
    if (AGENT_STUDIO_TOOLS.indexOf(name) < 0) {
      AGENT_STUDIO_TOOLS.push(name);
    }
    currentBindings.push(taskName);
    AGENT_STUDIO_TOOL_TASK_MAP[key] = currentBindings;
    AGENT_STUDIO_TOOL_GROUP_COLLAPSED[String(taskName || "").trim().toUpperCase()] = false;
    renderAgentStudioSelectedTools();
    updateAgentStudioCanvas();
    renderAgentStudioReview();
  }

  function normalizeStudioMappingKey(agentName, taskName) {
    return normalizeAgentName(agentName) + "=>" + String(taskName || "").trim().toUpperCase();
  }

  function layoutAgentStudioMappings() {
    var baseAgentLeft = 332;
    var baseTaskLeft = 614;
    var startTop = 460;
    var rowGap = 170;
    AGENT_STUDIO_TEAM_MAPPINGS.forEach(function(mapping, index) {
      var agentX = Number(mapping.agent_x);
      var taskX = Number(mapping.task_x);
      var agentY = Number(mapping.agent_y);
      var taskY = Number(mapping.task_y);
      if (Number.isNaN(agentX)) mapping.agent_x = baseAgentLeft;
      if (Number.isNaN(taskX)) mapping.task_x = baseTaskLeft;
      if (Number.isNaN(agentY)) mapping.agent_y = startTop + index * rowGap;
      if (Number.isNaN(taskY)) mapping.task_y = startTop + index * rowGap;
    });
  }

  function resizeAgentStudioCanvasForContent() {
    var canvas = $("#aoAgentStudioCanvas")[0];
    var inner = $("#aoAgentStudioCanvasInner")[0];
    var zoom = AGENT_STUDIO_ZOOM || 1;
    var innerRect;
    var maxRight = 0;
    var maxBottom = 0;
    var minWidth = 1320;
    var minHeight = 720;
    var padding = 100;
    var width;
    var height;
    if (!canvas || !inner || !inner.getBoundingClientRect) return;
    innerRect = inner.getBoundingClientRect();
    $("#aoAgentStudioCanvasInner .ao-studio-node, #aoAgentStudioDropHint").each(function() {
      var rect;
      var left;
      var top;
      var right;
      var bottom;
      if (!this || !this.getBoundingClientRect) return;
      if (!$(this).is(":visible")) return;
      rect = this.getBoundingClientRect();
      left = (rect.left - innerRect.left) / zoom;
      top = (rect.top - innerRect.top) / zoom;
      right = left + rect.width / zoom;
      bottom = top + rect.height / zoom;
      if (right > maxRight) maxRight = right;
      if (bottom > maxBottom) maxBottom = bottom;
    });
    width = Math.max(minWidth, Math.ceil(maxRight + padding));
    height = Math.max(minHeight, Math.ceil(maxBottom + padding));
    canvas.style.setProperty("--ao-studio-inner-width", width + "px");
    canvas.style.setProperty("--ao-studio-inner-height", height + "px");
  }

  function renderAgentStudioTeamMappings() {
    var html = "";
    var canvasHtml = "";
    layoutAgentStudioMappings();
    AGENT_STUDIO_TEAM_MAPPINGS.forEach(function(mapping, index) {
      var agentName = String((mapping && mapping.name) || "").trim();
      var taskName = String((mapping && mapping.task) || "").trim();
      var agentLeft = mapping.agent_x != null ? Number(mapping.agent_x) : 332;
      var agentTop = mapping.agent_y != null ? Number(mapping.agent_y) : (460 + index * 170);
      var taskLeft = mapping.task_x != null ? Number(mapping.task_x) : 614;
      var taskTop = mapping.task_y != null ? Number(mapping.task_y) : (460 + index * 170);
      if (!agentName || !taskName) return;
      html += "<div class='ao-studio-team-mapping-row'>";
      html += "<span><strong>" + apex.util.escapeHTML(agentName) + "</strong> -> " + apex.util.escapeHTML(taskName) + "</span>";
      html += "<button type='button' data-remove-studio-mapping='" + index + "' aria-label='Remove mapping'>x</button>";
      html += "</div>";
      canvasHtml += "<div class='ao-studio-node ao-studio-node--agent ao-studio-node--mapped' draggable='true' data-studio-node='agent' data-studio-node-uid='mapping-" + index + "-agent' data-studio-mapping-index='" + index + "' data-studio-mapping-kind='agent' style='left:" + agentLeft + "px !important;top:" + agentTop + "px !important;'>";
      canvasHtml += "<span>Agent</span><strong>" + apex.util.escapeHTML(agentName) + "</strong><em>Existing agent</em></div>";
      canvasHtml += "<div class='ao-studio-node ao-studio-node--task ao-studio-node--mapped' draggable='true' data-studio-node='task' data-studio-node-uid='mapping-" + index + "-task' data-studio-mapping-index='" + index + "' data-studio-mapping-kind='task' data-task-name='" + escapeAttr(taskName.toUpperCase()) + "' style='left:" + taskLeft + "px !important;top:" + taskTop + "px !important;'>";
      canvasHtml += "<span>Task</span><strong>" + apex.util.escapeHTML(taskName) + "</strong><em>Existing task</em></div>";
    });
    if (!html) html = "<div class='ao-inline-note'>No additional mappings added yet.</div>";
    $("#aoAgentStudioTeamMappings").html(html);
    $("#aoAgentStudioTeamMappingNodes").html(canvasHtml).toggle(!!canvasHtml);
    resizeAgentStudioCanvasForContent();
  }

  function addAgentStudioTeamMapping() {
    var agentName = String($("#aoAgentStudioTeamAgent").val() || "").trim();
    var taskName = String($("#aoAgentStudioTeamTask").val() || "").trim();
    var newKey = normalizeStudioMappingKey(agentName, taskName);
    var exists = false;
    if (!agentName || !taskName) {
      showError("Choose both an existing agent and an existing task before adding a team mapping.");
      return;
    }
    if (normalizeStudioMappingKey(getAgentStudioState().agentName, getAgentStudioState().taskName) === newKey) {
      showError("This mapping is already represented by the primary Agent and Task boxes.");
      return;
    }
    AGENT_STUDIO_TEAM_MAPPINGS.forEach(function(mapping) {
      if (normalizeStudioMappingKey(mapping.name, mapping.task) === newKey) exists = true;
    });
    if (exists) {
      showError("This agent to task mapping is already added.");
      return;
    }
    AGENT_STUDIO_TEAM_MAPPINGS.push({ name: agentName, task: taskName });
    $("#aoAgentStudioTeamAgent, #aoAgentStudioTeamTask").val("");
    renderAgentStudioTeamMappings();
    renderAgentStudioReview();
    window.requestAnimationFrame(drawAgentStudioLinks);
  }

  function removeAgentStudioTeamMapping(indexValue) {
    var index = Number(indexValue);
    if (Number.isNaN(index) || index < 0 || index >= AGENT_STUDIO_TEAM_MAPPINGS.length) return;
    AGENT_STUDIO_TEAM_MAPPINGS.splice(index, 1);
    renderAgentStudioTeamMappings();
    renderAgentStudioReview();
    window.requestAnimationFrame(drawAgentStudioLinks);
  }

  function createAndConnectAgentStudioToolDraft() {
    var name = String($("#aoAgentStudioNewToolName").val() || "").trim();
    var toolType = String($("#aoAgentStudioNewToolType").val() || "").trim();
    var callable = String($("#aoAgentStudioNewToolFunction").val() || "").trim();
    var instruction = String($("#aoAgentStudioNewToolInstruction").val() || "").trim();
    var description = String($("#aoAgentStudioNewToolDescription").val() || "").trim();
    var attributes = {};
    var toolParams;
    var toolInputs;
    if (!name) {
      showError("Tool name is required.");
      return;
    }
    try {
      validateNameField("#aoAgentStudioNewToolName", "Tool");
      assertAgentCreateNameAvailable("TOOL", name, "#aoAgentStudioNewToolName");
    } catch (nameError) {
      showError(nameError.message);
      return;
    }
    try {
      toolParams = parseOptionalJsonObject($("#aoAgentStudioNewToolParams").val(), "Tool Params");
      toolInputs = parseOptionalJsonArray($("#aoAgentStudioNewToolInputs").val(), "Tool Inputs");
    } catch (e) {
      showError(e.message);
      return;
    }
    if (toolType) attributes.tool_type = toolType;
    if (callable) attributes["function"] = callable;
    if (instruction) attributes.instruction = instruction;
    if (toolParams) attributes.tool_params = toolParams;
    if (toolInputs) attributes.tool_inputs = toolInputs;
    if (!attributes.tool_type && !attributes["function"]) {
      showError("Choose a backend function or procedure for custom tools.");
      return;
    }
    if (!attributes.tool_type && !attributes.instruction) {
      showError("Tool instruction is required for custom tools.");
      return;
    }
    AGENT_STUDIO_NEW_TOOL_PAYLOADS[name] = {
      entity_type: "TOOL",
      entity_name: name,
      description: description,
      attributes: attributes
    };
    addAgentStudioTool(name, $("#aoAgentStudioToolTaskSelect").val());
    $("#aoAgentStudioNewToolName, #aoAgentStudioNewToolInstruction, #aoAgentStudioNewToolParams, #aoAgentStudioNewToolInputs, #aoAgentStudioNewToolDescription").val("");
    $("#aoAgentStudioNewToolType, #aoAgentStudioNewToolFunction").val("");
  }

  function resetAgentStudioFlow() {
    AGENT_STUDIO_TOOLS = [];
    AGENT_STUDIO_TOOL_POSITIONS = {};
    AGENT_STUDIO_TOOL_TASK_MAP = {};
    AGENT_STUDIO_TOOL_GROUP_POSITIONS = {};
    AGENT_STUDIO_TOOL_GROUP_COLLAPSED = {};
    AGENT_STUDIO_TEAM_MAPPINGS = [];
    AGENT_STUDIO_NEW_TOOL_PAYLOADS = {};
    $("#aoAgentStudioAgentMode, #aoAgentStudioTaskMode").val("new");
    $("#aoAgentStudioToolMode").val("existing");
    $("#aoAgentStudioExistingAgent, #aoAgentStudioExistingTask, #aoAgentStudioTeamAgent, #aoAgentStudioTeamTask").val("");
    $("#aoAgentStudioTeamName, #aoAgentStudioGuardrails, #aoAgentStudioAgentName, #aoAgentStudioRole, #aoAgentStudioTaskName, #aoAgentStudioTaskGoal, #aoAgentStudioTaskDescription, #aoAgentStudioNewToolName, #aoAgentStudioNewToolInstruction, #aoAgentStudioNewToolParams, #aoAgentStudioNewToolInputs, #aoAgentStudioNewToolDescription").val("");
    $("#aoAgentStudioProfile, #aoAgentStudioHumanTool, #aoAgentStudioToolSelect, #aoAgentStudioNewToolType, #aoAgentStudioNewToolFunction").val("");
    $(".ao-studio-node--team, .ao-studio-node--agent, .ao-studio-node--task").css({ left: "", top: "" });
    autoGrowTextareas("#aoAgentStudioTaskGoal");
    syncAgentStudioModeUi();
    renderAgentStudioTeamMappings();
    renderAgentStudioSelectedTools();
    updateAgentStudioCanvas();
    setAgentStudioStep(1);
    setAgentStudioEditorVisible(false);
  }

  function applyAgentStudioZoom() {
    var zoomPct = Math.round(AGENT_STUDIO_ZOOM * 100);
    $("#aoAgentStudioCanvas").css("--ao-studio-zoom", AGENT_STUDIO_ZOOM);
    $("#aoAgentStudioCanvasInner").css("--ao-studio-zoom", AGENT_STUDIO_ZOOM);
    $("#aoAgentStudioZoomLabel").text(zoomPct + "%");
    window.requestAnimationFrame(drawAgentStudioLinks);
  }

  function adjustAgentStudioZoom(delta) {
    AGENT_STUDIO_ZOOM = Math.max(0.4, Math.min(1.4, Math.round((AGENT_STUDIO_ZOOM + delta) * 10) / 10));
    applyAgentStudioZoom();
  }

  function syncAgentStudioExpandControls() {
    var $studioCard = $("#aoAgentStudioCanvas").closest(".ao-card--studio");
    var mapExpanded = $studioCard.hasClass("is-studio-expanded");
    $("#aoAgentStudioExpandCanvas")
      .attr("aria-pressed", mapExpanded ? "true" : "false")
      .attr("aria-label", mapExpanded ? "Collapse playground" : "Expand playground")
      .attr("title", mapExpanded ? "Collapse playground" : "Expand playground");
  }

  function setAgentStudioEditorVisible(isVisible) {
    var visible = !!isVisible;
    var $studio = $("#aoAgentStudioCanvas").closest(".ao-agent-studio");
    var $guide = $studio.find(".ao-studio-guide");
    if (!$studio.length) return;
    $studio.toggleClass("is-editor-hidden", !visible);
    $guide.toggleClass("is-hidden", !visible).attr("aria-hidden", visible ? "false" : "true");
    if (!visible) {
      $(".ao-studio-node[data-studio-node]").removeClass("is-selected");
    }
  }

  function toggleAgentStudioExpanded() {
    var $studioCard = $("#aoAgentStudioCanvas").closest(".ao-card--studio");
    var expanded = !$studioCard.hasClass("is-studio-expanded");
    $studioCard.toggleClass("is-studio-expanded", expanded);
    syncAgentStudioExpandControls();
    $("body").toggleClass("ao-studio-expanded-lock", expanded);
    window.requestAnimationFrame(drawAgentStudioLinks);
  }

  function removeAgentStudioTool(toolName, taskName) {
    var name = String(toolName || "").trim();
    var key = String(name || "").trim().toUpperCase();
    var removeTask = String(taskName || "").trim();
    var bindings = getToolTaskBindings(name);
    if (removeTask) {
      bindings = bindings.filter(function(task) { return String(task || "").trim() !== removeTask; });
      if (bindings.length) {
        AGENT_STUDIO_TOOL_TASK_MAP[key] = bindings;
      } else {
        delete AGENT_STUDIO_TOOL_TASK_MAP[key];
        AGENT_STUDIO_TOOLS = AGENT_STUDIO_TOOLS.filter(function(item) { return item !== name; });
      }
    } else {
      AGENT_STUDIO_TOOLS = AGENT_STUDIO_TOOLS.filter(function(item) { return item !== name; });
      delete AGENT_STUDIO_TOOL_TASK_MAP[key];
    }
    delete AGENT_STUDIO_TOOL_POSITIONS[key];
    delete AGENT_STUDIO_NEW_TOOL_PAYLOADS[name];
    renderAgentStudioSelectedTools();
    updateAgentStudioCanvas();
    renderAgentStudioReview();
  }

  function renderAgentStudioSelectedTools() {
    var html = "";
    AGENT_STUDIO_TOOLS.forEach(function(name) {
      var bindings = getToolTaskBindings(name);
      if (!bindings.length) bindings = [""];
      bindings.forEach(function(taskName) {
        html += "<div class='ao-studio-selected-tool'>";
        html += "<strong>" + apex.util.escapeHTML(name) + "</strong>";
        html += "<span>" + (AGENT_STUDIO_NEW_TOOL_PAYLOADS[name] ? "New tool" : "Existing tool") + (taskName ? " -> " + apex.util.escapeHTML(taskName) : "") + "</span>";
        html += "<button type='button' data-remove-studio-tool='" + escapeAttr(name) + "' data-remove-studio-tool-task='" + escapeAttr(taskName) + "'>Remove</button>";
        html += "</div>";
      });
    });
    if (!html) html = "<div class='ao-muted-box'>No tools connected yet.</div>";
    $("#aoAgentStudioSelectedTools").html(html);
  }

  function syncAgentStudioModeUi() {
    ["agent", "task", "tool"].forEach(function(type) {
      var defaultMode = type === "tool" ? "existing" : "new";
      var mode = String($("#aoAgentStudio" + type.charAt(0).toUpperCase() + type.slice(1) + "Mode").val() || defaultMode).trim().toLowerCase();
      var isExisting = mode === "existing";
      $("[data-studio-existing-for='" + type + "']").css("display", isExisting ? "grid" : "none");
      $("[data-studio-new-for='" + type + "']").css("display", isExisting ? "none" : "grid");
      if (type === "agent") {
        $("#aoAgentStudioAgentName").prop("readonly", isExisting);
        if (isExisting) {
          $("#aoAgentStudioAgentName").val($("#aoAgentStudioExistingAgent").val() || "");
          applyExistingAgentDetailsToStudio($("#aoAgentStudioExistingAgent").val());
        }
      }
      if (type === "task") {
        $("#aoAgentStudioTaskName").prop("readonly", isExisting);
        if (isExisting) $("#aoAgentStudioTaskName").val($("#aoAgentStudioExistingTask").val() || "");
      }
    });
    autoGrowTextareas("#aoAgentStudioTaskGoal");
  }

  function updateAgentStudioCanvas() {
    var state = getAgentStudioState();
    var html = "";
    var toolsByTask = {};
    var taskOrder = [];
    function getDefaultToolGroupPosition(taskKey, groupIndex) {
      var normalizedTask = String(taskKey || "").trim().toUpperCase();
      var primaryTaskName = String(state.taskName || "").trim().toUpperCase();
      var taskLeft = null;
      var taskTop = null;
      var taskWidth = 260;
      var columnGap = 90;
      var rowGap = 96;
      var stackOffset = Math.max(0, Number(groupIndex) || 0);
      var mappedMatch;
      var primaryNode;
      var primaryPos;

      if (normalizedTask && normalizedTask !== primaryTaskName) {
        mappedMatch = (AGENT_STUDIO_TEAM_MAPPINGS || []).find(function(mapping) {
          return String((mapping && mapping.task) || "").trim().toUpperCase() === normalizedTask;
        });
        if (mappedMatch) {
          if (!Number.isNaN(Number(mappedMatch.task_x))) taskLeft = Number(mappedMatch.task_x);
          if (!Number.isNaN(Number(mappedMatch.task_y))) taskTop = Number(mappedMatch.task_y);
        }
      }

      if (taskLeft == null || taskTop == null) {
        primaryNode = $(".ao-studio-node--task[data-studio-node='task']").not(".ao-studio-node--mapped").first();
        if (primaryNode && primaryNode.length) {
          primaryPos = primaryNode.position();
          if (primaryPos) {
            if (taskLeft == null && !Number.isNaN(Number(primaryPos.left))) taskLeft = Number(primaryPos.left);
            if (taskTop == null && !Number.isNaN(Number(primaryPos.top))) taskTop = Number(primaryPos.top);
          }
          if (!Number.isNaN(Number(primaryNode.outerWidth()))) {
            taskWidth = Number(primaryNode.outerWidth()) || taskWidth;
          }
        }
      }

      if (taskLeft == null) taskLeft = 796;
      if (taskTop == null) taskTop = 340;

      return {
        x: Math.round(taskLeft + taskWidth + columnGap),
        y: Math.round(taskTop + stackOffset * rowGap)
      };
    }
    $("#aoAgentStudioTitle").text(state.teamName || "Agent Team Flow");
    $("#aoAgentStudioCanvasTeamName").text(state.teamName || "New Team");
    $("#aoAgentStudioCanvasAgentName").text(state.agentName || "New Agent");
    $("#aoAgentStudioCanvasProfileName").text(state.profileName || "No profile selected");
    $("#aoAgentStudioCanvasTaskName").text(state.taskName || "New Task");
    $(".ao-studio-node--task[data-studio-node='task']").not(".ao-studio-node--mapped").attr("data-task-name", String(state.taskName || "").trim().toUpperCase());
    state.tools.forEach(function(toolName) {
      var key = String(toolName || "").trim().toUpperCase();
      var bindings = Array.isArray(AGENT_STUDIO_TOOL_TASK_MAP[key]) ? AGENT_STUDIO_TOOL_TASK_MAP[key].slice() : [];
      if (!bindings.length) bindings = [String(state.taskName || "").trim()];
      bindings.forEach(function(boundTaskName, bindingIndex) {
        var toolTaskName = String(boundTaskName || "").trim().toUpperCase();
        var bindingKey = key + "::" + String(toolTaskName || "_UNBOUND_") + "::" + String(bindingIndex);
        if (!toolsByTask[toolTaskName]) {
          toolsByTask[toolTaskName] = [];
          taskOrder.push(toolTaskName);
        }
        toolsByTask[toolTaskName].push({ name: toolName, key: bindingKey, task: toolTaskName });
      });
    });
    taskOrder.forEach(function(taskKey, groupIndex) {
      var groupUid = "tool-group-" + taskKey;
      var groupPos = AGENT_STUDIO_TOOL_GROUP_POSITIONS[taskKey] || null;
      var isCollapsed = !!AGENT_STUDIO_TOOL_GROUP_COLLAPSED[taskKey];
      var style = "";
      if (!groupPos || groupPos.x == null || groupPos.y == null) {
        groupPos = getDefaultToolGroupPosition(taskKey, groupIndex);
      }
      if (groupPos && groupPos.x != null && groupPos.y != null) {
        style = " style='left:" + Number(groupPos.x) + "px !important;top:" + Number(groupPos.y) + "px !important;position:absolute !important;'";
      }
      html += "<div class='ao-studio-tool-group" + (isCollapsed ? " is-collapsed" : "") + "' draggable='true' data-studio-node='tool-group' data-studio-node-uid='" + escapeAttr(groupUid) + "' data-tool-task='" + escapeAttr(taskKey) + "'" + style + ">";
      html += "<div class='ao-studio-tool-group-head'>";
      html += "<button type='button' class='ao-studio-tool-group-toggle' data-toggle-tool-group='" + escapeAttr(taskKey) + "' aria-label='Toggle tool group'>" + (isCollapsed ? "+" : "−") + "</button>";
      html += "<strong>Tools for " + apex.util.escapeHTML(taskKey || "TASK") + "</strong>";
      html += "</div>";
      html += "<div class='ao-studio-tool-group-body'>";
      (toolsByTask[taskKey] || []).forEach(function(toolObj) {
        html += "<div class='ao-studio-node ao-studio-node--tool' draggable='true' data-studio-node='tool' data-studio-node-uid='tool-" + escapeAttr(toolObj.key) + "' data-tool-name='" + escapeAttr(toolObj.name) + "' data-tool-task='" + escapeAttr(toolObj.task) + "'>";
        html += "<button type='button' aria-label='Remove tool' data-remove-studio-tool='" + escapeAttr(toolObj.name) + "' data-remove-studio-tool-task='" + escapeAttr(toolObj.task) + "'>x</button>";
        html += "<span>Tool</span>";
        html += "<strong>" + apex.util.escapeHTML(toolObj.name) + "</strong>";
        html += "</div>";
      });
      html += "</div>";
      html += "</div>";
    });
    $("#aoAgentStudioCanvasTools").html(html);
    renderAgentStudioTeamMappings();
    renderAgentStudioTaskBindingOptions();
    resizeAgentStudioCanvasForContent();
    window.requestAnimationFrame(drawAgentStudioLinks);
  }

  function drawAgentStudioLinks() {
    var canvas = $("#aoAgentStudioCanvas")[0];
    var inner = $("#aoAgentStudioCanvasInner")[0] || canvas;
    var svg = $("#aoAgentStudioLinks")[0];
    if (!canvas || !svg) return;
    var innerRect = inner.getBoundingClientRect();
    var scrollLeft = canvas.scrollLeft || 0;
    var scrollTop = canvas.scrollTop || 0;
    var zoom = AGENT_STUDIO_ZOOM || 1;
    var width = Math.max(inner.scrollWidth || 1080, Math.ceil(innerRect.width / zoom));
    var height = Math.max(inner.scrollHeight || 560, Math.ceil(innerRect.height / zoom));
    var paths = [];

    function point(selectorOrElement, side) {
      var $el = selectorOrElement && selectorOrElement.nodeType ? $(selectorOrElement) : $(selectorOrElement);
      var el = $el[0];
      var rect;
      if (!el) return null;
      rect = el.getBoundingClientRect();
      return {
        x: (rect.left - innerRect.left) / zoom + (side === "left" ? 0 : rect.width / zoom),
        y: (rect.top - innerRect.top) / zoom + rect.height / (2 * zoom)
      };
    }

    function pathBetween(a, b, active) {
      var delta = Math.max(60, Math.abs(b.x - a.x) / 2);
      paths.push("<path class='ao-studio-link" + (active ? " ao-studio-link--active" : "") + "' d='M " + a.x + " " + a.y + " C " + (a.x + delta) + " " + a.y + ", " + (b.x - delta) + " " + b.y + ", " + b.x + " " + b.y + "' />");
    }

    var teamOut = point("[data-studio-node='team']", "right");
    var agentIn = point("[data-studio-node='agent']", "left");
    var agentOut = point("[data-studio-node='agent']", "right");
    var primaryTaskNode = $(".ao-studio-node[data-studio-node='task']").not(".ao-studio-node--mapped")[0];
    var taskIn = point(primaryTaskNode, "left");
    var taskOut = point(primaryTaskNode, "right");
    if (teamOut && agentIn) pathBetween(teamOut, agentIn, true);
    if (agentOut && taskIn) pathBetween(agentOut, taskIn, true);
    $(".ao-studio-node--mapped[data-studio-mapping-kind='agent']").each(function() {
      var mappedAgentOut;
      var mappedTaskIn;
      var mappedAgentIn = point(this, "left");
      var index = String($(this).attr("data-studio-mapping-index") || "");
      if (teamOut && mappedAgentIn) pathBetween(teamOut, mappedAgentIn, true);
      mappedAgentOut = point(this, "right");
      mappedTaskIn = point(".ao-studio-node--mapped[data-studio-mapping-index='" + index + "'][data-studio-mapping-kind='task']", "left");
      if (mappedAgentOut && mappedTaskIn) pathBetween(mappedAgentOut, mappedTaskIn, true);
    });
    $("[data-studio-node='tool-group']").each(function() {
      var groupIn = point(this, "left");
      var taskName = String($(this).attr("data-tool-task") || "").trim().toUpperCase();
      var sourceTaskNode = null;
      if (taskName) {
        sourceTaskNode = $(".ao-studio-node[data-studio-node='task']").filter(function() {
          return String($(this).attr("data-task-name") || "").trim().toUpperCase() === taskName;
        }).first()[0] || null;
      }
      var sourceOut = point(sourceTaskNode || primaryTaskNode, "right");
      if (sourceOut && groupIn) pathBetween(sourceOut, groupIn, true);
    });
    svg.setAttribute("viewBox", "0 0 " + width + " " + height);
    svg.setAttribute("width", width);
    svg.setAttribute("height", height);
    svg.innerHTML = paths.join("");
  }

  function placeAgentStudioNode(block, originalEvent, nodeUid) {
    var normalizedBlock = String(block || "").trim().toLowerCase();
    var canvas = $("#aoAgentStudioCanvas")[0];
    var inner = $("#aoAgentStudioCanvasInner")[0] || canvas;
    var uid = String(nodeUid || "").trim();
    var node = uid ? $("[data-studio-node-uid='" + escapeAttr(uid) + "']")[0] : (normalizedBlock ? $("[data-studio-node='" + normalizedBlock + "']").not(".ao-studio-node--mapped").first()[0] : null);
    var innerRect;
    var zoom = AGENT_STUDIO_ZOOM || 1;
    var x;
    var y;
    if (!canvas || !node || !originalEvent) return;
    innerRect = inner.getBoundingClientRect();
    x = (originalEvent.clientX - innerRect.left) / zoom - node.offsetWidth / 2;
    y = (originalEvent.clientY - innerRect.top) / zoom - node.offsetHeight / 2;
    x = Math.max(24, Math.min(x, Math.max(24, (inner.scrollWidth || 1080) - node.offsetWidth - 24)));
    y = Math.max(24, Math.min(y, Math.max(24, (inner.scrollHeight || 560) - node.offsetHeight - 24)));
    node.style.setProperty("left", x + "px", "important");
    node.style.setProperty("top", y + "px", "important");
    if (uid && $(node).is("[data-studio-mapping-index]")) {
      var index = Number($(node).attr("data-studio-mapping-index"));
      var kind = String($(node).attr("data-studio-mapping-kind") || "").trim().toLowerCase();
      if (!Number.isNaN(index) && AGENT_STUDIO_TEAM_MAPPINGS[index]) {
        if (kind === "agent") {
          AGENT_STUDIO_TEAM_MAPPINGS[index].agent_x = x;
          AGENT_STUDIO_TEAM_MAPPINGS[index].agent_y = y;
        } else if (kind === "task") {
          AGENT_STUDIO_TEAM_MAPPINGS[index].task_x = x;
          AGENT_STUDIO_TEAM_MAPPINGS[index].task_y = y;
        }
      }
    }
    if (normalizedBlock === "tool-group") {
      var groupTask = String($(node).attr("data-tool-task") || "").trim().toUpperCase();
      if (groupTask) AGENT_STUDIO_TOOL_GROUP_POSITIONS[groupTask] = { x: x, y: y };
    }
    if (normalizedBlock === "tool") {
      var toolName = String($(node).attr("data-tool-name") || "").trim().toUpperCase();
      if (toolName) AGENT_STUDIO_TOOL_POSITIONS[toolName] = { x: x, y: y };
    }
    resizeAgentStudioCanvasForContent();
    window.requestAnimationFrame(drawAgentStudioLinks);
  }

  function setAgentStudioStep(step) {
    var nextStep = Math.max(1, Math.min(5, Number(step) || 1));
    var titleByStep = {
      1: "Team",
      2: "Agent",
      3: "Task",
      4: "Tools",
      5: "Review"
    };
    var copyByStep = {
      1: "Create a new team as the root of this flow.",
      2: "Create a new agent or associate an existing agent.",
      3: "Create a new task or associate an existing task.",
      4: "Connect existing tools or define a new backend tool.",
      5: "Review the team, agent, task, and tools before creating."
    };
    AGENT_STUDIO_STEP = nextStep;
    $("[data-agent-studio-step]").removeClass("is-active");
    $("[data-agent-studio-step='" + nextStep + "']").addClass("is-active");
    $(".ao-studio-step[data-agent-studio-panel]").removeClass("is-active");
    $(".ao-studio-step[data-agent-studio-panel='" + nextStep + "']").addClass("is-active");
    $("#aoStudioInspectorTitle").text(titleByStep[nextStep] || "Editor");
    $("#aoStudioInspectorCopy").text(copyByStep[nextStep] || "Click a block on the canvas to configure it here.");
    $(".ao-studio-node[data-studio-node]").removeClass("is-selected");
    if (nextStep === 1) $(".ao-studio-node[data-studio-node='team']").addClass("is-selected");
    if (nextStep === 2) $(".ao-studio-node[data-studio-node='agent']").addClass("is-selected");
    if (nextStep === 3) $(".ao-studio-node[data-studio-node='task']").addClass("is-selected");
    if (nextStep === 4) $(".ao-studio-node[data-studio-node='tool']").addClass("is-selected");
    $("#aoAgentStudioPrev").prop("disabled", nextStep === 1);
    $("#aoAgentStudioNext").text(nextStep === 5 ? "Create Agent" : "Next");
    syncAgentStudioModeUi();
    renderAgentStudioReview();
    window.requestAnimationFrame(drawAgentStudioLinks);
  }

  function validateAgentStudioState() {
    var state = getAgentStudioState();
    var issues = [];
    function countToolsForTask(taskName) {
      var count = 0;
      var normalizedTask = String(taskName || "").trim().toUpperCase();
      (state.tools || []).forEach(function(toolName) {
        var mappedTasks = (state.toolTaskMap || {})[String(toolName || "").trim().toUpperCase()];
        var taskList = Array.isArray(mappedTasks) ? mappedTasks : [];
        if (!taskList.length) taskList = [normalizedTask];
        taskList.forEach(function(mappedTask) {
          if (String(mappedTask || "").trim().toUpperCase() === normalizedTask) count += 1;
        });
      });
      return count;
    }
    var hasAdditionalMappings = !!(state.teamMappings && state.teamMappings.length);
    var currentPairStarted = !!(state.agentName || state.taskName || state.tools.length || state.profileName || state.role || state.taskGoal);
    var requireCurrentPair = !hasAdditionalMappings || currentPairStarted;
    if (requireCurrentPair && !state.taskName) issues.push("Task name is required.");
    if (requireCurrentPair && state.taskMode === "new" && !state.taskGoal) issues.push("Task instruction is required.");
    if (requireCurrentPair && !state.agentName) issues.push("Agent name is required.");
    if (requireCurrentPair && state.agentMode === "new" && !state.profileName) issues.push("AI profile is required.");
    if (requireCurrentPair && state.agentMode === "new" && !state.role) issues.push("Agent role is required.");
    if (requireCurrentPair && state.taskMode === "new" && countToolsForTask(state.taskName) === 0) issues.push("Connect at least one tool for the selected task.");
    if (!hasAdditionalMappings && !(state.agentName && state.taskName)) issues.push("Add at least one agent to task mapping for the team.");
    if (!state.teamName) issues.push("Team name is required.");
    if (state.teamName) {
      var teamNameError = validateIdentifierValue(state.teamName, "Team");
      if (teamNameError) issues.push(teamNameError);
    }
    if (requireCurrentPair && state.agentMode === "new" && state.agentName) {
      var agentNameError = validateIdentifierValue(state.agentName, "Agent");
      if (agentNameError) issues.push(agentNameError);
      if (!agentNameError && agentEntityExists("AGENT", state.agentName)) issues.push(duplicateAgentEntityMessage("AGENT", state.agentName) + " Or choose Existing Agent.");
    }
    if (requireCurrentPair && state.taskMode === "new" && state.taskName) {
      var taskNameError = validateIdentifierValue(state.taskName, "Task");
      if (taskNameError) issues.push(taskNameError);
      if (!taskNameError && agentEntityExists("TASK", state.taskName)) issues.push(duplicateAgentEntityMessage("TASK", state.taskName) + " Or choose Existing Task.");
    }
    Object.keys(AGENT_STUDIO_NEW_TOOL_PAYLOADS || {}).forEach(function(toolName) {
      if (agentEntityExists("TOOL", toolName)) issues.push(duplicateAgentEntityMessage("TOOL", toolName) + " Use Existing Tool instead.");
    });
    return issues;
  }

  function renderAgentStudioValidation() {
    var issues = validateAgentStudioState();
    var html = "";
    if (!issues.length) {
      html = "<div class='ao-studio-validation-row is-ok'>Ready to create. The flow has a team, agent, task, and tool mapping.</div>";
    } else {
      issues.forEach(function(issue) {
        html += "<div class='ao-studio-validation-row is-error'>" + apex.util.escapeHTML(issue) + "</div>";
      });
    }
    $("#aoAgentStudioValidation").html(html);
    return issues;
  }

  function hasAgentStudioDraftState() {
    var state = getAgentStudioState();
    var newToolDraftFields = [
      "#aoAgentStudioNewToolName",
      "#aoAgentStudioNewToolInstruction",
      "#aoAgentStudioNewToolParams",
      "#aoAgentStudioNewToolInputs",
      "#aoAgentStudioNewToolDescription",
      "#aoAgentStudioNewToolType",
      "#aoAgentStudioNewToolFunction"
    ];
    var hasDraftInFields = newToolDraftFields.some(function(selector) {
      return !!String($(selector).val() || "").trim();
    });
    return !!(
      String(state.teamName || "").trim() ||
      String(state.teamDescription || "").trim() ||
      String(state.agentName || "").trim() ||
      String(state.taskName || "").trim() ||
      String(state.profileName || "").trim() ||
      String(state.role || "").trim() ||
      String(state.taskGoal || "").trim() ||
      String(state.taskDescription || "").trim() ||
      String(state.humanTool || "").trim() ||
      (state.tools && state.tools.length) ||
      (state.teamMappings && state.teamMappings.length) ||
      Object.keys(AGENT_STUDIO_NEW_TOOL_PAYLOADS || {}).length ||
      hasDraftInFields
    );
  }

  function setAgentStudioButtonState(selector, disabled) {
    var $button = $(selector);
    if (!$button.length) return;
    $button.prop("disabled", !!disabled);
    $button.attr("aria-disabled", disabled ? "true" : "false");
    $button.toggleClass("is-disabled", !!disabled);
  }

  function refreshAgentStudioActionButtons(validationIssues) {
    var issues = Array.isArray(validationIssues) ? validationIssues : validateAgentStudioState();
    var hasDraft = hasAgentStudioDraftState();
    var canResetDraft = hasDraft && !AGENT_STUDIO_IS_SAVING;
    var canCreateAgent = !!CAN_MANAGE_SETTINGS && hasDraft && !AGENT_STUDIO_IS_SAVING && issues.length === 0;

    setAgentStudioButtonState("#aoAgentStudioNewFlow", !canResetDraft);
    setAgentStudioButtonState("#aoAgentStudioDeleteFlow", !canResetDraft);
    setAgentStudioButtonState("#aoSaveAgentStudioFlow", !canCreateAgent);
  }

  function renderAgentStudioReview() {
    var state = getAgentStudioState();
    var toolLabels = [];
    (state.tools || []).forEach(function(toolName) {
      var mappedTasks = (state.toolTaskMap || {})[String(toolName || "").trim().toUpperCase()];
      var taskList = Array.isArray(mappedTasks) && mappedTasks.length ? mappedTasks : [state.taskName || ""];
      taskList.forEach(function(mappedTask) {
        var taskName = String(mappedTask || "").trim();
        toolLabels.push(taskName ? (toolName + " -> " + taskName) : toolName);
      });
    });
    var rows = [
      ["Team", state.teamName || "Missing"],
      ["Agent", (state.agentName || "Missing") + " (" + state.agentMode + ")"],
      ["Task", (state.taskName || "Missing") + " (" + state.taskMode + ")"],
      ["Profile", state.profileName || (state.agentMode === "existing" ? "Existing agent profile" : "Missing")],
      ["Tools", toolLabels.length ? toolLabels.join(", ") : "Existing task tools or none selected"],
      ["Additional Mappings", state.teamMappings.length ? state.teamMappings.map(function(item) { return item.name + " -> " + item.task; }).join(", ") : "None"]
    ];
    var html = rows.map(function(row) {
      return "<div class='ao-studio-review-row'><strong>" + apex.util.escapeHTML(row[0]) + "</strong><span>" + apex.util.escapeHTML(row[1]) + "</span></div>";
    }).join("");
    $("#aoAgentStudioReview").html(html);
    var issues = renderAgentStudioValidation();
    renderAgentStudioPlsqlPreview();
    refreshAgentStudioActionButtons(issues);
  }

  function buildAgentStudioPayloads() {
    var state = getAgentStudioState();
    var boolValue = parseBooleanLike(state.humanTool);
    var payloads = [];
    var taskNames = [];
    var agentNames = [];
    var teamAgents = [];
    var seenMappings = {};
    var seenPayloads = {};

    function addUniqueTaskName(taskName) {
      var name = String(taskName || "").trim();
      if (!name) return;
      if (taskNames.some(function(item) { return String(item || "").trim().toUpperCase() === name.toUpperCase(); })) return;
      taskNames.push(name);
    }

    function addUniqueAgentName(agentName) {
      var name = String(agentName || "").trim();
      if (!name) return;
      if (agentNames.some(function(item) { return String(item || "").trim().toUpperCase() === name.toUpperCase(); })) return;
      agentNames.push(name);
    }

    function pushPayload(payload) {
      var type = String(payload && payload.entity_type || "").trim().toUpperCase();
      var name = String(payload && payload.entity_name || "").trim().toUpperCase();
      var key = type + "::" + name;
      if (!type || !name || seenPayloads[key]) return;
      seenPayloads[key] = true;
      payloads.push(payload);
    }

    function getArrayAttribute(entityType, entityName, attrName) {
      var raw = getEntityAttributeValue(entityType, entityName, attrName);
      var parsed = parseJsonValueSafe(raw);
      if (Array.isArray(parsed)) {
        return parsed.map(function(item) { return String(item || "").trim(); }).filter(Boolean);
      }
      return parseLineArray(String(raw || ""));
    }

    function getToolsForTask(taskName) {
      var normalizedTask = String(taskName || "").trim().toUpperCase();
      return (state.tools || []).filter(function(toolName) {
        var mappedTasks = (state.toolTaskMap || {})[String(toolName || "").trim().toUpperCase()];
        var taskList = Array.isArray(mappedTasks) ? mappedTasks : [];
        if (!taskList.length) taskList = [normalizedTask];
        return taskList.some(function(mappedTask) {
          return String(mappedTask || "").trim().toUpperCase() === normalizedTask;
        });
      });
    }

    function addTeamMapping(agentName, taskName) {
      var agent = String(agentName || "").trim();
      var task = String(taskName || "").trim();
      var key = normalizeStudioMappingKey(agent, task);
      if (!agent || !task || seenMappings[key]) return;
      seenMappings[key] = true;
      addUniqueAgentName(agent);
      addUniqueTaskName(task);
      teamAgents.push({ name: agent, task: task });
    }

    state.tools.forEach(function(toolName) {
      if (AGENT_STUDIO_NEW_TOOL_PAYLOADS[toolName]) {
        pushPayload(AGENT_STUDIO_NEW_TOOL_PAYLOADS[toolName]);
      }
    });

    state.teamMappings.forEach(function(mapping) {
      addTeamMapping(mapping.name, mapping.task);
    });
    addTeamMapping(state.agentName, state.taskName);

    taskNames.forEach(function(taskName) {
      var isPrimaryTask = String(taskName || "").trim().toUpperCase() === String(state.taskName || "").trim().toUpperCase();
      var taskAttributes = {};
      var instruction = isPrimaryTask
        ? String(state.taskGoal || "").trim()
        : String(getEntityAttributeValue("TASK", taskName, "instruction") || "").trim();
      var taskTools = getToolsForTask(taskName);
      var existingTaskTools = collectToolNamesFromTaskAttrs(CURRENT_AGENT_TEAM_DATA ? CURRENT_AGENT_TEAM_DATA.taskAttrRows : [], [taskName]) || [];
      var taskInputs = getArrayAttribute("TASK", taskName, "input");
      var existingTaskHumanTool = parseBooleanLike(getEntityAttributeValue("TASK", taskName, "enable_human_tool"));

      if (!taskTools.length && existingTaskTools.length) {
        taskTools = existingTaskTools.slice();
      }

      if (instruction) taskAttributes.instruction = instruction;
      if (taskTools.length) taskAttributes.tools = taskTools;
      if (taskInputs.length) taskAttributes.input = taskInputs;
      if (isPrimaryTask && boolValue != null) {
        taskAttributes.enable_human_tool = boolValue;
      } else if (existingTaskHumanTool != null) {
        taskAttributes.enable_human_tool = existingTaskHumanTool;
      }

      pushPayload({
        entity_type: "TASK",
        entity_name: taskName,
        description: isPrimaryTask
          ? String(state.taskDescription || "").trim()
          : getEntityDescription("TASK", taskName) || "",
        attributes: taskAttributes
      });
    });

    agentNames.forEach(function(agentName) {
      var isPrimaryAgent = String(agentName || "").trim().toUpperCase() === String(state.agentName || "").trim().toUpperCase();
      var existingLinkedProfiles = getArrayAttribute("AGENT", agentName, "linked_profiles");
      var primaryProfile = isPrimaryAgent
        ? String(state.profileName || "").trim()
        : String(getEntityAttributeValue("AGENT", agentName, "profile_name") || "").trim();
      var role = isPrimaryAgent
        ? String(state.role || "").trim()
        : String(getEntityAttributeValue("AGENT", agentName, "role") || "").trim();
      var existingAgentHumanTool = parseBooleanLike(getEntityAttributeValue("AGENT", agentName, "enable_human_tool"));
      var agentAttributes = {};

      if (primaryProfile) {
        agentAttributes.profile_name = primaryProfile;
      }
      if (existingLinkedProfiles.length) {
        agentAttributes.linked_profiles = existingLinkedProfiles.filter(function(profileName) {
          return String(profileName || "").trim().toUpperCase() !== String(primaryProfile || "").trim().toUpperCase();
        });
        if (!agentAttributes.linked_profiles.length) delete agentAttributes.linked_profiles;
      }
      if (role) agentAttributes.role = role;
      if (isPrimaryAgent && boolValue != null) {
        agentAttributes.enable_human_tool = boolValue;
      } else if (existingAgentHumanTool != null) {
        agentAttributes.enable_human_tool = existingAgentHumanTool;
      }

      pushPayload({
        entity_type: "AGENT",
        entity_name: agentName,
        description: isPrimaryAgent
          ? (String(getEntityDescription("AGENT", agentName) || "").trim() || "Created from guided Agent Builder.")
          : (getEntityDescription("AGENT", agentName) || ""),
        attributes: agentAttributes
      });
    });

    pushPayload({
      entity_type: "TEAM",
      entity_name: state.teamName,
      description: state.teamDescription || "Created from Agent Builder.",
      attributes: {
        process: String(getEntityAttributeValue("TEAM", state.teamName, "process") || "sequential").trim() || "sequential",
        agents: teamAgents
      }
    });

    return payloads;
  }

  function getAgentEntityProcedureStem(entityType) {
    var type = String(entityType || "").trim().toUpperCase();
    if (type === "TEAM") return "team";
    if (type === "AGENT") return "agent";
    if (type === "TASK") return "task";
    if (type === "TOOL") return "tool";
    return "entity";
  }

  function getAgentEntityNameArgument(entityType) {
    var type = String(entityType || "").trim().toUpperCase();
    if (type === "TEAM") return "team_name";
    if (type === "AGENT") return "agent_name";
    if (type === "TASK") return "task_name";
    if (type === "TOOL") return "tool_name";
    return "entity_name";
  }

  function quotePlsqlLiteral(value) {
    var text = String(value == null ? "" : value);
    var delimiters = [
      ["[", "]"],
      ["{", "}"],
      ["(", ")"],
      ["<", ">"],
      ["~", "~"],
      ["!", "!"],
      ["#", "#"],
      ["$", "$"]
    ];
    for (var i = 0; i < delimiters.length; i += 1) {
      var open = delimiters[i][0];
      var close = delimiters[i][1];
      if (text.indexOf(close + "'") < 0) {
        return "q'" + open + text + close + "'";
      }
    }
    return "'" + text.replace(/'/g, "''") + "'";
  }

  function formatAgentStudioPlsqlPayload(payload) {
    var entityType = String(payload.entity_type || "").trim().toUpperCase();
    var stem = getAgentEntityProcedureStem(entityType);
    var nameArg = getAgentEntityNameArgument(entityType);
    var nameLiteral = quotePlsqlLiteral(payload.entity_name);
    var description = String(payload.description || "").trim();
    var attributesJson = JSON.stringify(payload.attributes || {}, null, 2);
    var lines = [];

    lines.push("begin");
    lines.push("  dbms_cloud_ai_agent.create_" + stem + "(");
    lines.push("    " + nameArg + " => " + nameLiteral + ",");
    lines.push("    attributes => " + quotePlsqlLiteral(attributesJson) + ",");
    lines.push("    description => " + (description ? quotePlsqlLiteral(description) : "null"));
    lines.push("  );");
    lines.push("end;");
    lines.push("/");
    return lines.join("\n");
  }

  function buildAgentStudioPlsqlCode() {
    var state = getAgentStudioState();
    var payloads = buildAgentStudioPayloads();
    var comments = [
      "-- Generated from Agent Builder.",
      "-- Review this PL/SQL before clicking Create Agent."
    ];

    if (state.agentMode === "existing" && state.agentName) {
      comments.push("-- Existing agent referenced and not recreated: " + state.agentName);
    }
    if (state.taskMode === "existing" && state.taskName) {
      comments.push("-- Existing task referenced and not recreated: " + state.taskName);
    }
    state.tools.forEach(function(toolName) {
      if (!AGENT_STUDIO_NEW_TOOL_PAYLOADS[toolName]) {
        comments.push("-- Existing tool referenced and not recreated: " + toolName);
      }
    });

    return comments.join("\n") + "\n\n" + payloads.map(formatAgentStudioPlsqlPayload).join("\n\n");
  }

  function buildAgentTeamPlsqlCodeFromCurrentTeam() {
    var payloads = [];
    var teamName = getCurrentTeamName();
    var teamDescription = getEntityDescription("TEAM", teamName) || "";
    var mappings = CURRENT_AGENT_TEAM_DATA ? parseAgentMappingsFromTeamAttrs(CURRENT_AGENT_TEAM_DATA.teamAttrRows) : [];
    var orderedTaskNames = [];
    var orderedAgentNames = [];
    var seenTask = {};
    var seenAgent = {};
    var seenTool = {};
    var teamAgents = [];

    if (!CURRENT_AGENT_TEAM_DATA || !teamName) return "-- Select a team first.";

    mappings.forEach(function(mapping) {
      var agentName = String(mapping.name || "").trim();
      var taskName = String(mapping.task || "").trim();
      if (!agentName || !taskName) return;
      teamAgents.push({ name: agentName, task: taskName });
      if (!seenAgent[agentName.toUpperCase()]) {
        seenAgent[agentName.toUpperCase()] = true;
        orderedAgentNames.push(agentName);
      }
      if (!seenTask[taskName.toUpperCase()]) {
        seenTask[taskName.toUpperCase()] = true;
        orderedTaskNames.push(taskName);
      }
    });

    orderedTaskNames.forEach(function(taskName) {
      var taskTools = collectToolNamesFromTaskAttrs(CURRENT_AGENT_TEAM_DATA.taskAttrRows, [taskName]) || [];
      taskTools.forEach(function(toolName) {
        var toolKey = String(toolName || "").trim().toUpperCase();
        var attrs = {};
        var desc = getEntityDescription("TOOL", toolName) || "";
        if (!toolName || seenTool[toolKey]) return;
        seenTool[toolKey] = true;
        attrs["function"] = getEntityAttributeValue("TOOL", toolName, "function");
        attrs.instruction = getEntityAttributeValue("TOOL", toolName, "instruction");
        attrs.tool_type = getEntityAttributeValue("TOOL", toolName, "tool_type");
        attrs.tool_params = parseJsonValueSafe(getEntityAttributeValue("TOOL", toolName, "tool_params"));
        attrs.tool_inputs = parseJsonValueSafe(getEntityAttributeValue("TOOL", toolName, "tool_inputs"));
        Object.keys(attrs).forEach(function(k) {
          if (attrs[k] == null || attrs[k] === "" || (Array.isArray(attrs[k]) && !attrs[k].length) || (typeof attrs[k] === "object" && !Array.isArray(attrs[k]) && !Object.keys(attrs[k]).length)) {
            delete attrs[k];
          }
        });
        payloads.push({
          entity_type: "TOOL",
          entity_name: toolName,
          description: desc,
          attributes: attrs
        });
      });
    });

    orderedTaskNames.forEach(function(taskName) {
      var taskAttrs = {
        instruction: String(getEntityAttributeValue("TASK", taskName, "instruction") || "").trim(),
        tools: collectToolNamesFromTaskAttrs(CURRENT_AGENT_TEAM_DATA.taskAttrRows, [taskName]) || []
      };
      var enableHuman = parseBooleanLike(getEntityAttributeValue("TASK", taskName, "enable_human_tool"));
      if (enableHuman != null) taskAttrs.enable_human_tool = enableHuman;
      payloads.push({
        entity_type: "TASK",
        entity_name: taskName,
        description: getEntityDescription("TASK", taskName) || "",
        attributes: taskAttrs
      });
    });

    orderedAgentNames.forEach(function(agentName) {
      var agentAttrs = {
        profile_name: String(getEntityAttributeValue("AGENT", agentName, "profile_name") || "").trim(),
        role: String(getEntityAttributeValue("AGENT", agentName, "role") || "").trim()
      };
      var enableHuman = parseBooleanLike(getEntityAttributeValue("AGENT", agentName, "enable_human_tool"));
      if (enableHuman != null) agentAttrs.enable_human_tool = enableHuman;
      payloads.push({
        entity_type: "AGENT",
        entity_name: agentName,
        description: getEntityDescription("AGENT", agentName) || "",
        attributes: agentAttrs
      });
    });

    payloads.push({
      entity_type: "TEAM",
      entity_name: teamName,
      description: teamDescription,
      attributes: {
        process: String(getEntityAttributeValue("TEAM", teamName, "process") || "sequential").trim() || "sequential",
        agents: teamAgents
      }
    });

    return [
      "-- Generated from Agent Teams map",
      "-- Create order: TOOLS, TASKS, AGENTS, TEAM",
      ""
    ].join("\n") + payloads.map(formatAgentStudioPlsqlPayload).join("\n\n");
  }

  function cleanupAgentPayloadAttrs(attrs) {
    Object.keys(attrs || {}).forEach(function(k) {
      if (attrs[k] == null || attrs[k] === "" || (Array.isArray(attrs[k]) && !attrs[k].length) || (typeof attrs[k] === "object" && !Array.isArray(attrs[k]) && !Object.keys(attrs[k]).length)) {
        delete attrs[k];
      }
    });
    return attrs;
  }

  function buildFocusedAgentTeamPlsqlPayload(entityType, entityName) {
    var type = String(entityType || "").trim().toUpperCase();
    var name = String(entityName || "").trim();
    var teamName = getCurrentTeamName();
    var attrs;
    var mappings;
    var teamAgents;
    var enableHuman;

    if (!CURRENT_AGENT_TEAM_DATA || !teamName || !type) return null;

    if (type === "TEAM") {
      mappings = parseAgentMappingsFromTeamAttrs(CURRENT_AGENT_TEAM_DATA.teamAttrRows);
      teamAgents = [];
      mappings.forEach(function(mapping) {
        var agentName = String(mapping.name || "").trim();
        var taskName = String(mapping.task || "").trim();
        if (!agentName || !taskName) return;
        teamAgents.push({ name: agentName, task: taskName });
      });
      return {
        entity_type: "TEAM",
        entity_name: teamName,
        description: getEntityDescription("TEAM", teamName) || "",
        attributes: {
          process: String(getEntityAttributeValue("TEAM", teamName, "process") || "sequential").trim() || "sequential",
          agents: teamAgents
        }
      };
    }

    if (!name) return null;

    if (type === "AGENT") {
      attrs = {
        profile_name: String(getEntityAttributeValue("AGENT", name, "profile_name") || "").trim(),
        role: String(getEntityAttributeValue("AGENT", name, "role") || "").trim()
      };
      enableHuman = parseBooleanLike(getEntityAttributeValue("AGENT", name, "enable_human_tool"));
      if (enableHuman != null) attrs.enable_human_tool = enableHuman;
      return {
        entity_type: "AGENT",
        entity_name: name,
        description: getEntityDescription("AGENT", name) || "",
        attributes: cleanupAgentPayloadAttrs(attrs)
      };
    }

    if (type === "TASK") {
      attrs = {
        instruction: String(getEntityAttributeValue("TASK", name, "instruction") || "").trim(),
        tools: collectToolNamesFromTaskAttrs(CURRENT_AGENT_TEAM_DATA.taskAttrRows, [name]) || []
      };
      enableHuman = parseBooleanLike(getEntityAttributeValue("TASK", name, "enable_human_tool"));
      if (enableHuman != null) attrs.enable_human_tool = enableHuman;
      return {
        entity_type: "TASK",
        entity_name: name,
        description: getEntityDescription("TASK", name) || "",
        attributes: cleanupAgentPayloadAttrs(attrs)
      };
    }

    if (type === "TOOL") {
      attrs = {
        "function": getEntityAttributeValue("TOOL", name, "function"),
        instruction: getEntityAttributeValue("TOOL", name, "instruction"),
        tool_type: getEntityAttributeValue("TOOL", name, "tool_type"),
        tool_params: parseJsonValueSafe(getEntityAttributeValue("TOOL", name, "tool_params")),
        tool_inputs: parseJsonValueSafe(getEntityAttributeValue("TOOL", name, "tool_inputs"))
      };
      return {
        entity_type: "TOOL",
        entity_name: name,
        description: getEntityDescription("TOOL", name) || "",
        attributes: cleanupAgentPayloadAttrs(attrs)
      };
    }

    return null;
  }

  function buildFocusedAgentTeamPlsqlCode(entityType, entityName, agentName) {
    var payload = buildFocusedAgentTeamPlsqlPayload(entityType, entityName);
    var normalizedType = String(entityType || "").trim().toUpperCase();
    var selectedName = String(entityName || "").trim() || getCurrentTeamName();
    var selectedAgent = String(agentName || "").trim();
    var contextLine = "";

    if (!payload) return buildAgentTeamPlsqlCodeFromCurrentTeam();
    if (normalizedType === "TOOL" && selectedAgent) {
      contextLine = "-- Context agent: " + selectedAgent;
    }

    return [
      "-- Generated from Agent Teams map node selection",
      "-- Focus: " + payload.entity_type + " " + selectedName,
      contextLine
    ].filter(Boolean).join("\n") + "\n\n" + formatAgentStudioPlsqlPayload(payload);
  }

  function highlightPlsqlCodeLine(line) {
    var text = String(line || "");
    var tokenRe = /\b(?:create|or|replace|package|body|procedure|function|return|begin|end|declare|as|is|null|select|from|where|and|insert|into|values|update|delete|merge|when|then|else|loop|while|for|exit|if|elsif|commit|rollback|exception|raise)\b|\b(?:dbms_cloud_ai_agent|dbms_cloud_ai|dbms_assert|apex_json|json_object|json_arrayagg)\b|\b\d+(?:\.\d+)?\b|q'\[[\s\S]*?\]'|q'\{[\s\S]*?\}'|'(?:''|[^'])*'/gi;
    var html = "";
    var lastIndex = 0;
    var match;
    while ((match = tokenRe.exec(text)) !== null) {
      var token = match[0];
      var tokenStart = match.index;
      var tokenLower = String(token || "").toLowerCase();
      var cls = "ao-plsql-token-literal";
      if (/^q'[\[\{]/i.test(token) || /^'/.test(token)) {
        cls = "ao-plsql-token-string";
      } else if (/^\d/.test(token)) {
        cls = "ao-plsql-token-number";
      } else if (tokenLower.indexOf("dbms_") === 0 || tokenLower.indexOf("apex_") === 0 || tokenLower.indexOf("json_") === 0) {
        cls = "ao-plsql-token-fn";
      } else {
        cls = "ao-plsql-token-keyword";
      }
      html += apex.util.escapeHTML(text.slice(lastIndex, tokenStart));
      html += "<span class='" + cls + "'>" + apex.util.escapeHTML(token) + "</span>";
      lastIndex = tokenStart + token.length;
    }
    html += apex.util.escapeHTML(text.slice(lastIndex));
    return html;
  }

  function renderAgentTeamPlsqlHighlightedPreview(code) {
    var text = String(code || "");
    var lines = text.split("\n");
    var gutterWidth = String(Math.max(lines.length, 1)).length;
    var html = "";
    lines.forEach(function(line, idx) {
      var commentIndex = line.indexOf("--");
      var codePart = commentIndex >= 0 ? line.slice(0, commentIndex) : line;
      var commentPart = commentIndex >= 0 ? line.slice(commentIndex) : "";
      var lineHtml = highlightPlsqlCodeLine(codePart);
      if (commentPart) {
        lineHtml += "<span class='ao-plsql-token-comment'>" + apex.util.escapeHTML(commentPart) + "</span>";
      }
      html += "<span class='ao-plsql-line'><span class='ao-plsql-ln' style='width:" + gutterWidth + "ch;'>" + (idx + 1) + "</span><span class='ao-plsql-line-code'>" + lineHtml + "</span></span>";
    });
    $("#aoAgentTeamPlsqlHighlighted").html(html);
  }

  function openAgentTeamPlsqlDialog(previewCode, previewTitle) {
    var resolvedCode;
    if (!String(previewCode || "").trim() && (!CURRENT_AGENT_TEAM_DATA || !getCurrentTeamName())) {
      showError("Select an agent team first.");
      return;
    }
    resolvedCode = String(previewCode || "").trim() || buildAgentTeamPlsqlCodeFromCurrentTeam();
    $("#aoAgentTeamPlsqlDialogTitle").text(String(previewTitle || "Agent Team Get Code"));
    $("#aoAgentTeamPlsqlCode").val(resolvedCode);
    renderAgentTeamPlsqlHighlightedPreview(resolvedCode);
    $("#aoAgentTeamPlsqlDialog").removeClass("is-hidden");
  }

  function closeAgentTeamPlsqlDialog() {
    $("#aoAgentTeamPlsqlDialog").addClass("is-hidden");
  }

  function resolveAskOracleEditorRuntime() {
    var candidates = [window];
    var seen = [window];

    function addCandidate(candidate) {
      if (!candidate) return;
      if (seen.indexOf(candidate) >= 0) return;
      seen.push(candidate);
      candidates.push(candidate);
    }

    try { addCandidate(window.parent); } catch (e1) {}
    try { addCandidate(window.top); } catch (e2) {}

    for (var i = 0; i < candidates.length; i += 1) {
      var candidate = candidates[i];
      if (!candidate) continue;
      try {
        if (typeof candidate.openResponseInEditor === "function" && candidate.document) {
          return candidate;
        }
      } catch (e3) {}
    }
    return null;
  }

  function getAskOracleEditorCandidateScriptUrls(runtime) {
    var doc = runtime && runtime.document;
    var urls = [];
    var seen = {};
    var scripts;

    function addUrl(url) {
      var value = String(url || "").trim();
      if (!value) return;
      if (seen[value]) return;
      seen[value] = true;
      urls.push(value);
    }

    function deriveSiblingScript(url, fileName) {
      var src = String(url || "").trim();
      if (!src) return "";
      return src.replace(/[^\/?#]+(?=(?:[?#].*)?$)/, fileName);
    }

    if (!doc) return urls;
    try {
      scripts = doc.querySelectorAll("script[src]");
      Array.prototype.forEach.call(scripts, function(node) {
        var src = String((node && node.getAttribute("src")) || "").trim();
        if (!src) return;
        if (/ask_oracle_function\.js(?:[?#].*)?$/i.test(src) || /execute_page_load\.js(?:[?#].*)?$/i.test(src)) {
          addUrl(src);
          return;
        }
        if (/settings_modal_v2\.js(?:[?#].*)?$/i.test(src)) {
          addUrl(deriveSiblingScript(src, "ask_oracle_function.js"));
          addUrl(deriveSiblingScript(src, "execute_page_load.js"));
        }
      });
    } catch (e) {}
    return urls;
  }

  function loadAskOracleEditorScript(runtime, src, done) {
    var doc = runtime && runtime.document;
    var callback = typeof done === "function" ? done : function() {};
    var script;
    if (!doc || !src) {
      callback(false);
      return;
    }
    try {
      script = doc.createElement("script");
      script.src = src;
      script.async = true;
      script.onload = function() { callback(true); };
      script.onerror = function() { callback(false); };
      (doc.head || doc.documentElement).appendChild(script);
    } catch (e) {
      callback(false);
    }
  }

  function ensureAskOracleEditorRuntime(onDone) {
    var callback = typeof onDone === "function" ? onDone : function() {};
    var immediate = resolveAskOracleEditorRuntime();
    var runtimes = [];
    var seen = [];
    var idxRuntime = 0;

    function addRuntime(runtime) {
      if (!runtime) return;
      if (seen.indexOf(runtime) >= 0) return;
      seen.push(runtime);
      runtimes.push(runtime);
    }

    function finish(runtime) {
      callback(runtime || null);
    }

    function tryScriptsOnRuntime(runtime, done) {
      var candidateUrls;
      var idxUrl = 0;
      if (!runtime) {
        done(null);
        return;
      }
      try {
        if (typeof runtime.openResponseInEditor === "function") {
          done(runtime);
          return;
        }
      } catch (e1) {}
      candidateUrls = getAskOracleEditorCandidateScriptUrls(runtime);
      if (!candidateUrls.length) {
        done(null);
        return;
      }

      function nextUrl() {
        var src;
        if (idxUrl >= candidateUrls.length) {
          done(null);
          return;
        }
        src = candidateUrls[idxUrl++];
        loadAskOracleEditorScript(runtime, src, function() {
          try {
            if (typeof runtime.openResponseInEditor === "function") {
              done(runtime);
              return;
            }
          } catch (e2) {}
          nextUrl();
        });
      }

      nextUrl();
    }

    function nextRuntime() {
      if (idxRuntime >= runtimes.length) {
        finish(null);
        return;
      }
      tryScriptsOnRuntime(runtimes[idxRuntime++], function(found) {
        if (found) {
          finish(found);
          return;
        }
        nextRuntime();
      });
    }

    if (immediate) {
      finish(immediate);
      return;
    }
    addRuntime(window);
    try { addRuntime(window.parent); } catch (e3) {}
    try { addRuntime(window.top); } catch (e4) {}
    nextRuntime();
  }

  function openNlBuilderResponseInEditor(historyIndex) {
    var idx = Number(historyIndex);
    var row;
    var editorCode;
    var responseId;
    var editorRuntime;
    var runtimeDocument;
    var host;
    var responseEl;
    var codeEl;
    var languageClass;
    if (!isFinite(idx)) return;
    row = AGENT_BUILDER_NL_HISTORY[idx];
    if (!row || typeof row !== "object") return;
    editorCode = String(row.editorCode || row.generatedCode || "").trim();
    if (!editorCode) {
      showError("No code found in this response.");
      return;
    }
    setNlBuilderStatus("Opening code editor...", false);
    ensureAskOracleEditorRuntime(function(runtime) {
      if (!runtime) {
        setNlBuilderStatus("", false);
        showError("Open in Editor is not available in this page context.");
        return;
      }
      editorRuntime = runtime;
      runtimeDocument = editorRuntime.document;

      responseId = "nl_builder_" + String(idx + 1);
      host = runtimeDocument.getElementById("aoNlBuilderEditorPayloadHost");
      if (!host) {
        host = runtimeDocument.createElement("div");
        host.id = "aoNlBuilderEditorPayloadHost";
        host.style.display = "none";
        if (runtimeDocument.body) runtimeDocument.body.appendChild(host);
      }
      responseEl = runtimeDocument.getElementById("response-" + responseId);
      if (!responseEl) {
        responseEl = runtimeDocument.createElement("div");
        responseEl.id = "response-" + responseId;
        responseEl.setAttribute("data-id", responseId);
        responseEl.className = "response response-box";
        host.appendChild(responseEl);
      }
      responseEl.innerHTML = "";
      codeEl = runtimeDocument.createElement("code");
      languageClass = looksLikeNlBuilderCode(editorCode) ? "language-sql" : "language-text";
      codeEl.className = languageClass;
      codeEl.textContent = editorCode;
      responseEl.appendChild(runtimeDocument.createElement("pre")).appendChild(codeEl);
      if (typeof editorRuntime.cacheResponseDownloadPayload === "function") {
        try {
          if (Object.prototype.hasOwnProperty.call(editorRuntime, "ASK_ORACLE_RESPONSE_PAYLOAD_CACHE_ENABLED")) {
            editorRuntime.ASK_ORACLE_RESPONSE_PAYLOAD_CACHE_ENABLED = true;
          }
          editorRuntime.cacheResponseDownloadPayload(responseId, {
            content: editorCode,
            ext: languageClass === "language-sql" ? "sql" : "txt",
            hasCode: true
          });
        } catch (e) {}
      }
      try {
        editorRuntime.openResponseInEditor(responseId);
        setNlBuilderStatus("", false);
      } catch (err) {
        setNlBuilderStatus("", false);
        showError("Unable to open the code editor.");
      }
    });
  }

  function renderAgentStudioPlsqlPreview() {
    var issues = validateAgentStudioState();
    if (!$("#aoAgentStudioPlsqlCode").length) return;
    if (issues.length) {
      $("#aoAgentStudioPlsqlCode").val("-- Complete the validation items above to preview the generated PL/SQL.");
      $("#aoCopyAgentStudioPlsql").prop("disabled", true);
      return;
    }
    try {
      $("#aoAgentStudioPlsqlCode").val(buildAgentStudioPlsqlCode());
      $("#aoCopyAgentStudioPlsql").prop("disabled", false);
    } catch (e) {
      $("#aoAgentStudioPlsqlCode").val("-- Unable to generate PL/SQL preview: " + String((e && e.message) || e || "Unknown error"));
      $("#aoCopyAgentStudioPlsql").prop("disabled", true);
    }
  }

  function saveAgentStudioFlow() {
    var issues = renderAgentStudioValidation();
    var payloads;
    var state;
    var shouldRecreateExisting = false;
    if (AGENT_STUDIO_IS_SAVING) return;
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to create agent definitions.");
      refreshAgentStudioActionButtons(issues);
      return;
    }
    if (issues.length) {
      showError("Complete the highlighted builder steps before creating the agent.");
      setAgentStudioStep(5);
      refreshAgentStudioActionButtons(issues);
      return;
    }
    state = getAgentStudioState();
    payloads = buildAgentStudioPayloads();
    AGENT_STUDIO_IS_SAVING = true;
    refreshAgentStudioActionButtons([]);

    function doneWithError(message) {
      AGENT_STUDIO_IS_SAVING = false;
      refreshAgentStudioActionButtons();
      showError(message || "Unable to save agent flow.");
    }

    function saveNext(index) {
      var payload = payloads[index];
      if (!payload) {
        AGENT_STUDIO_IS_SAVING = false;
        showSuccess("Agent flow saved.");
        bootstrap();
        return;
      }

      persistAgentEntityPayload(payload, shouldRecreateExisting ? "RECREATE_EXISTING" : "CREATE", function(err, data) {
        var message;
        if (err || !data.success) {
          message = extractAgentEntitySaveError(err, data, "Unable to create agent.");
          if (!isAgentEntityAlreadyExistsError(message)) {
            doneWithError(message);
            return;
          }
          if (shouldRecreateExisting) {
            doneWithError(message);
            return;
          }
          confirmAgentEntityRecreate(payload.entity_type, payload.entity_name, function() {
            shouldRecreateExisting = true;
            AGENT_STUDIO_IS_SAVING = true;
            refreshAgentStudioActionButtons([]);
            saveNext(index);
          });
          AGENT_STUDIO_IS_SAVING = false;
          refreshAgentStudioActionButtons();
          return;
        }
        saveNext(index + 1);
      });
    }

    function runSaveSequence() {
      AGENT_STUDIO_IS_SAVING = true;
      refreshAgentStudioActionButtons([]);
      saveNext(0);
    }

    if (state.teamName && agentEntityExists("TEAM", state.teamName)) {
      confirmAgentEntityRecreate("TEAM", state.teamName, function() {
        shouldRecreateExisting = true;
        runSaveSequence();
      });
      AGENT_STUDIO_IS_SAVING = false;
      refreshAgentStudioActionButtons();
      return;
    }

    runSaveSequence();
  }

  function prettifyJsonValue(value) {
    var parsed = parseJsonValueSafe(value);
    if (parsed == null) {
      return String(value || "").trim();
    }
    try { return JSON.stringify(parsed, null, 2); } catch (e) { return String(value || "").trim(); }
  }

  function lineifyJsonArrayValue(value) {
    var parsed = parseJsonValueSafe(value);
    if (Array.isArray(parsed)) {
      return parsed.map(function(item) { return String(item || "").trim(); }).filter(Boolean).join("\n");
    }
    return String(value || "").trim();
  }

  function refreshAgentEntityOptions() {
    var entityType = getCurrentEditorEntityType();
    var currentName = getCurrentEditorEntityName();
    var rows = getEntityNameRows(entityType);
    if (entityType === "TOOL") {
      rows = filterToolLovRows(rows, $("#aoAgentEditToolFilter").val(), currentName ? [currentName] : []);
    }
    var selected = currentName;
    var hasSelected = false;

    rows.forEach(function(row) {
      if (String(row.r || "") === selected) hasSelected = true;
    });
    if (!hasSelected) {
      selected = rows.length ? String(rows[0].r || "") : "";
    }

    fillSelect("#aoAgentEditEntityName", rows, selected);
    $("#aoAgentEditToolFilter").toggleClass("is-hidden", entityType !== "TOOL");
    populateAgentEntityEditor();
  }

  function populateAgentEntityEditor() {
    var entityType = getCurrentEditorEntityType();
    var entityName = getCurrentEditorEntityName();
    var isType = function(type) { return entityType === type; };

    $("[data-entity-editor]").hide();
    $("[data-entity-editor='" + entityType + "']").show();
    $("#aoAgentEditName").val(entityName || getCurrentTeamName());

    if (!CURRENT_AGENT_TEAM_DATA) return;

    if (isType("TEAM")) {
      $("#aoAgentEditName").val(getCurrentTeamName());
      $("#aoAgentEditTeamDescription").val(CURRENT_AGENT_TEAM_DATA.teamDescription || getEntityDescription("TEAM", getCurrentTeamName()));
      $("#aoAgentEditTeamProcess").val(String(getEntityAttributeValue("TEAM", getCurrentTeamName(), "process") || "sequential").trim() || "sequential");
      $("#aoAgentEditTeamAgents").val(formatAgentMappingsForEditor(CURRENT_AGENT_TEAM_DATA.teamAttrRows));
      refreshAgentCreateLinkOptions();
      renderEditTeamMappingList();
      return;
    }

    if (!entityName) return;

    if (isType("AGENT")) {
      $("#aoAgentEditAgentDescription").val(getEntityDescription("AGENT", entityName));
      $("#aoAgentEditProfileName").val(String(getEntityAttributeValue("AGENT", entityName, "profile_name") || "").trim());
      $("#aoAgentEditEnableHumanTool").val(booleanValueToSelect(getEntityAttributeValue("AGENT", entityName, "enable_human_tool")));
      $("#aoAgentEditRole").val(String(getEntityAttributeValue("AGENT", entityName, "role") || "").trim());
      return;
    }

    if (isType("TASK")) {
      $("#aoAgentEditTaskDescription").val(getEntityDescription("TASK", entityName));
      $("#aoAgentEditInstruction").val(String(getEntityAttributeValue("TASK", entityName, "instruction") || "").trim());
      $("#aoAgentEditTaskTools").val(lineifyJsonArrayValue(getEntityAttributeValue("TASK", entityName, "tools")));
      $("#aoAgentEditTaskInputs").val(lineifyJsonArrayValue(getEntityAttributeValue("TASK", entityName, "input")));
      $("#aoAgentEditTaskEnableHumanTool").val(booleanValueToSelect(getEntityAttributeValue("TASK", entityName, "enable_human_tool")));
      return;
    }

    if (isType("TOOL")) {
      $("#aoAgentEditToolDescription").val(getEntityDescription("TOOL", entityName));
      $("#aoAgentEditToolType").val(String(getEntityAttributeValue("TOOL", entityName, "tool_type") || "").trim());
      var toolFunction = String(getEntityAttributeValue("TOOL", entityName, "function") || "").trim();
      ensureSelectOption("#aoAgentEditToolFunction", toolFunction);
      $("#aoAgentEditToolFunction").val(toolFunction);
      $("#aoAgentEditToolInstruction").val(String(getEntityAttributeValue("TOOL", entityName, "instruction") || "").trim());
      $("#aoAgentEditToolParams").val(prettifyJsonValue(getEntityAttributeValue("TOOL", entityName, "tool_params")));
      $("#aoAgentEditToolInputs").val(prettifyJsonValue(getEntityAttributeValue("TOOL", entityName, "tool_inputs")));
    }
  }

  function parseOptionalJsonObject(textValue, label) {
    var raw = String(textValue || "").trim();
    if (!raw) return null;
    try {
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        throw new Error();
      }
      return parsed;
    } catch (e) {
      throw new Error(label + " must be a valid JSON object.");
    }
  }

  function parseOptionalJsonArray(textValue, label) {
    var raw = String(textValue || "").trim();
    if (!raw) return null;
    try {
      var parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) throw new Error();
      return parsed;
    } catch (e) {
      throw new Error(label + " must be a valid JSON array.");
    }
  }

  function buildAgentEntitySavePayload() {
    var entityType = getCurrentEditorEntityType();
    var entityName = getCurrentEditorEntityName();
    var description = "";
    var attributes = {};
    var boolValue;

    if (!entityName && entityType !== "TEAM") {
      throw new Error("Please select an item to edit.");
    }

    if (entityType === "TEAM") {
      entityName = getCurrentTeamName();
      if (entityName) {
        var teamNameError = validateIdentifierValue(entityName, "Team");
        if (teamNameError) throw new Error(teamNameError);
      }
      description = String($("#aoAgentEditTeamDescription").val() || "").trim();
      attributes.process = String($("#aoAgentEditTeamProcess").val() || "sequential").trim() || "sequential";
      attributes.agents = parseAgentMappingsForSave($("#aoAgentEditTeamAgents").val());
      if (!attributes.agents.length) throw new Error("At least one agent to task mapping is required.");
      return { entity_type: entityType, entity_name: entityName, description: description, attributes: attributes };
    }

    if (entityType === "AGENT") {
      description = String($("#aoAgentEditAgentDescription").val() || "").trim();
      attributes.profile_name = String($("#aoAgentEditProfileName").val() || "").trim();
      attributes.role = String($("#aoAgentEditRole").val() || "").trim();
      if (!attributes.profile_name) throw new Error("Profile Name is required.");
      if (!attributes.role) throw new Error("Role is required.");
      boolValue = parseBooleanLike($("#aoAgentEditEnableHumanTool").val());
      if (boolValue != null) attributes.enable_human_tool = boolValue;
      return { entity_type: entityType, entity_name: entityName, description: description, attributes: attributes };
    }

    if (entityType === "TASK") {
      description = String($("#aoAgentEditTaskDescription").val() || "").trim();
      attributes.instruction = String($("#aoAgentEditInstruction").val() || "").trim();
      if (!attributes.instruction) throw new Error("Instruction is required.");
      var tools = parseLineArray($("#aoAgentEditTaskTools").val());
      var inputs = parseLineArray($("#aoAgentEditTaskInputs").val());
      if (tools.length) attributes.tools = tools;
      if (inputs.length) attributes.input = inputs;
      boolValue = parseBooleanLike($("#aoAgentEditTaskEnableHumanTool").val());
      if (boolValue != null) attributes.enable_human_tool = boolValue;
      return { entity_type: entityType, entity_name: entityName, description: description, attributes: attributes };
    }

    if (entityType === "TOOL") {
      description = String($("#aoAgentEditToolDescription").val() || "").trim();
      attributes.tool_type = String($("#aoAgentEditToolType").val() || "").trim();
      attributes["function"] = String($("#aoAgentEditToolFunction").val() || "").trim();
      attributes.instruction = String($("#aoAgentEditToolInstruction").val() || "").trim();
      var toolParams = parseOptionalJsonObject($("#aoAgentEditToolParams").val(), "Tool Params");
      var toolInputs = parseOptionalJsonArray($("#aoAgentEditToolInputs").val(), "Tool Inputs");
      if (toolParams) attributes.tool_params = toolParams;
      if (toolInputs) attributes.tool_inputs = toolInputs;
      if (!attributes.tool_type && !attributes["function"]) {
        throw new Error("Function / Procedure is required for custom tools.");
      }
      if (!attributes.tool_type && !attributes.instruction) {
        throw new Error("Instruction is required for custom tools.");
      }
      if (!attributes.tool_type) delete attributes.tool_type;
      if (!attributes["function"]) delete attributes["function"];
      if (!attributes.instruction) delete attributes.instruction;
      return { entity_type: entityType, entity_name: entityName, description: description, attributes: attributes };
    }

    throw new Error("Unsupported definition type.");
  }

  function buildAgentCreateToolPayload() {
    var entityName = String($("#aoAgentCreateToolName").val() || "").trim();
    var description = String($("#aoAgentCreateToolDescription").val() || "").trim();
    var attributes = {};
    var toolType = String($("#aoAgentCreateToolType").val() || "").trim();
    var callable = String($("#aoAgentCreateToolFunction").val() || "").trim();
    var instruction = String($("#aoAgentCreateToolInstruction").val() || "").trim();
    var toolParams = parseOptionalJsonObject($("#aoAgentCreateToolParams").val(), "Tool Params");
    var toolInputs = parseOptionalJsonArray($("#aoAgentCreateToolInputs").val(), "Tool Inputs");

    if (!entityName) throw new Error("Tool Name is required.");
    validateNameField("#aoAgentCreateToolName", "Tool");
    assertAgentCreateNameAvailable("TOOL", entityName, "#aoAgentCreateToolName");
    if (toolType) attributes.tool_type = toolType;
    if (callable) attributes["function"] = callable;
    if (instruction) attributes.instruction = instruction;
    if (toolParams) attributes.tool_params = toolParams;
    if (toolInputs) attributes.tool_inputs = toolInputs;
    if (!attributes.tool_type && !attributes["function"]) throw new Error("Function / Procedure is required for custom tools.");
    if (!attributes.tool_type && !attributes.instruction) throw new Error("Instruction is required for custom tools.");

    return { entity_type: "TOOL", entity_name: entityName, description: description, attributes: attributes };
  }

  function buildAgentCreateTaskPayload() {
    var entityName = String($("#aoAgentCreateTaskName").val() || "").trim();
    var description = String($("#aoAgentCreateTaskDescription").val() || "").trim();
    var instruction = String($("#aoAgentCreateTaskInstruction").val() || "").trim();
    var tools = getSelectValues("#aoAgentCreateTaskTools");
    var inputs = getSelectValues("#aoAgentCreateTaskInputs");
    var boolValue = parseBooleanLike($("#aoAgentCreateTaskHumanTool").val());
    var attributes = {};

    if (!entityName) throw new Error("Task Name is required.");
    validateNameField("#aoAgentCreateTaskName", "Task");
    assertAgentCreateNameAvailable("TASK", entityName, "#aoAgentCreateTaskName");
    if (!instruction) throw new Error("Instruction is required.");
    attributes.instruction = instruction;
    if (tools.length) attributes.tools = tools;
    if (inputs.length) attributes.input = inputs;
    if (boolValue != null) attributes.enable_human_tool = boolValue;

    return { entity_type: "TASK", entity_name: entityName, description: description, attributes: attributes };
  }

  function buildAgentCreateAgentPayload() {
    var entityName = String($("#aoAgentCreateAgentName").val() || "").trim();
    var description = String($("#aoAgentCreateAgentDescription").val() || "").trim();
    var profiles = getSelectValues("#aoAgentCreateAgentProfiles");
    var role = String($("#aoAgentCreateAgentRole").val() || "").trim();
    var boolValue = parseBooleanLike($("#aoAgentCreateAgentHumanTool").val());
    var attributes = {};

    if (!entityName) throw new Error("Agent Name is required.");
    validateNameField("#aoAgentCreateAgentName", "Agent");
    assertAgentCreateNameAvailable("AGENT", entityName, "#aoAgentCreateAgentName");
    if (!profiles.length) throw new Error("At least one AI Profile is required.");
    if (!role) throw new Error("Role is required.");
    attributes.profile_name = profiles[0];
    if (profiles.length > 1) attributes.linked_profiles = profiles.slice(1);
    attributes.role = role;
    if (boolValue != null) attributes.enable_human_tool = boolValue;

    return { entity_type: "AGENT", entity_name: entityName, description: description, attributes: attributes };
  }

  function buildAgentCreateTeamPayload() {
    var entityName = String($("#aoAgentCreateTeamName").val() || "").trim();
    var description = String($("#aoAgentCreateTeamDescription").val() || "").trim();
    var attributes = {};

    if (!entityName) throw new Error("Team Name is required.");
    validateNameField("#aoAgentCreateTeamName", "Team");
    attributes.process = String($("#aoAgentCreateTeamProcess").val() || "sequential").trim() || "sequential";
    attributes.agents = parseAgentMappingsForSave($("#aoAgentCreateTeamMappings").val());
    if (!attributes.agents.length) throw new Error("At least one agent to task mapping is required.");

    return { entity_type: "TEAM", entity_name: entityName, description: description, attributes: attributes };
  }

  function clearAgentCreateForm(entityType) {
    var type = String(entityType || "").trim().toUpperCase();
    if (type === "TOOL") {
      $("#aoAgentCreateToolName, #aoAgentCreateToolDescription, #aoAgentCreateToolInstruction, #aoAgentCreateToolParams, #aoAgentCreateToolInputs").val("");
      $("#aoAgentCreateToolType, #aoAgentCreateToolFunction").val("");
    } else if (type === "TASK") {
      $("#aoAgentCreateTaskName, #aoAgentCreateTaskInstruction, #aoAgentCreateTaskDescription").val("");
      $("#aoAgentCreateTaskHumanTool").val("");
      $("#aoAgentCreateTaskTools, #aoAgentCreateTaskInputs").val([]);
    } else if (type === "AGENT") {
      $("#aoAgentCreateAgentName, #aoAgentCreateAgentRole, #aoAgentCreateAgentDescription").val("");
      $("#aoAgentCreateAgentHumanTool").val("");
      $("#aoAgentCreateAgentProfiles").val([]);
    } else if (type === "TEAM") {
      $("#aoAgentCreateTeamName, #aoAgentCreateTeamMappings, #aoAgentCreateTeamDescription").val("");
      $("#aoAgentCreateTeamProcess").val("sequential");
      $("#aoAgentCreateTeamAgent, #aoAgentCreateTeamTask").val("");
    }
  }

  function addTeamCreateMapping() {
    var agentName = String($("#aoAgentCreateTeamAgent").val() || "").trim();
    var taskName = String($("#aoAgentCreateTeamTask").val() || "").trim();
    var current = String($("#aoAgentCreateTeamMappings").val() || "").trim();
    var line;
    if (!agentName || !taskName) {
      showError("Choose both an agent and a task before adding a team mapping.");
      return;
    }
    line = agentName + " => " + taskName;
    $("#aoAgentCreateTeamMappings").val(current ? current + "\n" + line : line);
  }

  function addTeamEditMapping() {
    var agentName = String($("#aoAgentEditTeamAgent").val() || "").trim();
    var taskName = String($("#aoAgentEditTeamTask").val() || "").trim();
    var mappings;
    if (!agentName || !taskName) {
      showError("Choose both an agent and a task before adding a team mapping.");
      return;
    }
    try {
      mappings = parseAgentMappingsForSave($("#aoAgentEditTeamAgents").val());
    } catch (e) {
      showError(e.message || "Unable to read current team mappings.");
      return;
    }
    mappings.push({ name: agentName, task: taskName });
    setEditTeamMappings(mappings);
    $("#aoAgentEditTeamAgent, #aoAgentEditTeamTask").val("");
  }

  function extractAgentEntitySaveError(err, data, fallback) {
    var fromData = data && data.message ? String(data.message) : "";
    var fromErr = err && err.responseText ? String(err.responseText) : "";
    var raw = String(fromData || fromErr || fallback || "Unable to save agent definition.").trim();
    return makeFriendlyErrorMessage(raw || fallback || "Unable to save agent definition.");
  }

  function isAgentEntityAlreadyExistsError(message) {
    return /already exists/i.test(String(message || ""));
  }

  function confirmAgentEntityRecreate(entityType, entityName, onConfirm) {
    var label = String(entityType || "item").trim().toLowerCase();
    var confirmText = "Drop and recreate existing " + label + " '" + String(entityName || "").trim() + "'?";
    if (window.apex && apex.message && typeof apex.message.confirm === "function") {
      apex.message.confirm(confirmText, function(okPressed) {
        if (!okPressed) return;
        if (typeof onConfirm === "function") onConfirm();
      });
      return;
    }
    if (!window.confirm(confirmText)) return;
    if (typeof onConfirm === "function") onConfirm();
  }

  function persistAgentEntityPayload(payload, saveMode, callback) {
    var mode = String(saveMode || "CREATE").trim().toUpperCase();
    var entityLabel = String(payload && payload.entity_type || "item").toLowerCase();
    ajaxWithBusy(PROC.SAVE_AGENT_ENTITY, {
      x01: payload.entity_type,
      x02: payload.entity_name,
      x04: mode,
      x03: payload.description,
      p_clob_01: JSON.stringify(payload.attributes)
    }, (mode === "CREATE" ? "Creating " : "Saving ") + entityLabel + "...", function(err, data) {
      if (typeof callback === "function") callback(err, data || {});
    });
  }

  function createAgentEntity(payloadBuilder, successPanel) {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to save agent definitions.");
      return;
    }

    var payload;
    try {
      payload = payloadBuilder();
    } catch (e) {
      showError(e.message || "Unable to prepare the definition.");
      return;
    }

    var onSaved = function() {
      showSuccess((payload.entity_type || "Item") + " saved: " + payload.entity_name);
      clearAgentCreateForm(payload.entity_type);
      setAgentCreatePanel(successPanel || "overview");
      bootstrap();
    };

    persistAgentEntityPayload(payload, "CREATE", function(err, data) {
      var message;
      if (err || !data.success) {
        message = extractAgentEntitySaveError(err, data, "Unable to save agent definition.");
        if (!isAgentEntityAlreadyExistsError(message)) {
          showError(message);
          return;
        }
        confirmAgentEntityRecreate(payload.entity_type, payload.entity_name, function() {
          persistAgentEntityPayload(payload, "RECREATE_EXISTING", function(recreateErr, recreateData) {
            if (recreateErr || !recreateData.success) {
              showError(extractAgentEntitySaveError(recreateErr, recreateData, "Unable to recreate agent definition."));
              return;
            }
            onSaved();
          });
        });
        return;
      }
      onSaved();
    });
  }

  function saveAgentEntity() {
    if (!CAN_MANAGE_SETTINGS) {
      showError("Not authorized to edit agent definitions.");
      return;
    }
    if (!CURRENT_AGENT_TEAM_DATA) {
      showError("Please select an agent team first.");
      return;
    }

    var payload;
    try {
      payload = buildAgentEntitySavePayload();
    } catch (e) {
      showError(e.message || "Unable to prepare the selected definition.");
      return;
    }

    var label = String(payload.entity_type || "").toLowerCase();
    var confirmText = "Drop and recreate " + label + " '" + payload.entity_name + "'?";
    var runSave = function() {
      ajaxWithBusy(PROC.SAVE_AGENT_ENTITY, {
        x01: payload.entity_type,
        x02: payload.entity_name,
        x04: "UPDATE",
        x03: payload.description,
        p_clob_01: JSON.stringify(payload.attributes)
      }, "Saving " + String(payload.entity_type || "item").toLowerCase() + "...", function(err, data) {
        if (err) {
          showError(err.responseText || "Unable to save agent definition.");
          return;
        }
        if (!data.success) {
          showError(data.message || "Unable to save agent definition.");
          return;
        }
        showSuccess((payload.entity_type || "Item") + " updated: " + payload.entity_name);
        bootstrap();
      });
    };

    if (window.apex && apex.message && typeof apex.message.confirm === "function") {
      apex.message.confirm(confirmText + " This action uses drop and recreate.", function(okPressed) {
        if (!okPressed) return;
        runSave();
      });
    } else {
      if (!window.confirm(confirmText + " This action uses drop and recreate.")) return;
      runSave();
    }
  }

  function loadAgentTeamDetails(teamName) {
    var selectedTeam = String(teamName || $("#aoAgentTeamPicker").val() || "").trim();
    if (!selectedTeam) {
      $("#aoAgentTeamDesc").val("");
      clearAgentTeamBoxes();
      return;
    }
    ajax(PROC.GET_AGENT_DESC, {
      x01: selectedTeam
    }, function (err, data) {
      if (err) {
        showError(err.responseText || "Unable to load agent team details.");
        return;
      }
      if (data && data.success === false) {
        showError(data.message || "Unable to load agent team details.");
        $("#aoAgentTeamDesc").val("");
        clearAgentTeamBoxes();
        return;
      }
      var agentsRows = parseJsonArraySafe(data.agents_json);
      var toolsRows = parseJsonArraySafe(data.tools_json);
      var tasksRows = parseJsonArraySafe(data.tasks_json);
      var teamAttrRows = parseJsonArraySafe(data.team_attributes_json);
      var taskAttrRows = parseJsonArraySafe(data.task_attributes_json);
      var toolAttrRows = parseJsonArraySafe(data.tool_attributes_json);
      var agentAttrRows = parseJsonArraySafe(data.agent_attributes_json);
      var teamMetaRows = parseJsonArraySafe(data.team_meta_json);
      var agentMetaRows = parseJsonArraySafe(data.agent_meta_json);
      var taskMetaRows = parseJsonArraySafe(data.task_meta_json);
      var toolMetaRows = parseJsonArraySafe(data.tool_meta_json);
      var agentLovRows = buildAgentLovRows(agentsRows, teamAttrRows);
      var selectedAgent = String($("#aoAgentFilterSelect").val() || "").trim();
      var selectedAgentExists = false;

      agentLovRows.forEach(function(row) {
        if (String(row.r || "") === selectedAgent) selectedAgentExists = true;
      });
      if (!selectedAgentExists) {
        selectedAgent = agentLovRows.length ? String(agentLovRows[0].r || "").trim() : "";
      }

      CURRENT_AGENT_TEAM_DATA = {
        agentsRows: agentsRows,
        toolsRows: toolsRows,
        tasksRows: tasksRows,
        teamAttrRows: teamAttrRows,
        taskAttrRows: taskAttrRows,
        toolAttrRows: toolAttrRows,
        agentAttrRows: agentAttrRows,
        teamMetaRows: teamMetaRows,
        agentMetaRows: agentMetaRows,
        taskMetaRows: taskMetaRows,
        toolMetaRows: toolMetaRows,
        teamDescription: String(data.team_description || "").trim()
      };

      $("#aoAgentTeamDesc").val(
        buildTeamAttributesDisplayText(teamAttrRows, teamMetaRows, data.team_description)
      );
      fillSelect("#aoAgentFilterSelect", agentLovRows, selectedAgent);
      $("#aoAgentTeamWorkspace").removeClass("is-hidden");
      $(".ao-map-detail-section").addClass("is-hidden");
      renderAgentTeamMap();
      renderAgentTeamDetailsByAgent(selectedAgent);
      refreshAgentCreateLinkOptions();
      refreshAgentEntityOptions();
    });
  }

  function saveAdmin(key, value, options) {
    var keyName = String(key || "").trim().toUpperCase();
    var opts = options && typeof options === "object" ? options : {};
    if (!IS_ADMIN_USER && keyName !== "APP_ZOOM_PCT") {
      var authError = "Not authorized to change admin settings.";
      if (typeof opts.onError === "function") {
        opts.onError({ responseText: authError }, { success: false, message: authError, config_key: keyName }, keyName);
      } else {
        showError(authError);
      }
      return;
    }
    var requestPayload = {
      x01: key,
      x02: value
    };
    var handleResponse = function (err, data) {
      if (err) {
        if (typeof opts.onError === "function") {
          opts.onError(err, data || {}, keyName);
        } else {
          showError(err.responseText || "Unable to save admin setting.");
        }
        return;
      }
      if (!data.success) {
        if (typeof opts.onError === "function") {
          opts.onError(err || {}, data || {}, keyName);
        } else {
          showError(data.message || "Unable to save admin setting.");
        }
        return;
      }
      var keyName = data.config_key || key;
      if (keyName === "APP_ZOOM_PCT") {
        var zoomPct = setZoomSliderValue(data.config_value || value);
        applyAppZoomPreview(zoomPct);
        window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
        window.ASK_ORACLE_ADMIN_CONFIG.APP_ZOOM_PCT = String(zoomPct);
        persistUiSyncState({
          admin_config: $.extend({}, window.ASK_ORACLE_ADMIN_CONFIG)
        });
        if (!opts.suppressSuccessMessage) {
          showAdminSettingUpdated("APP_ZOOM_PCT", zoomPct);
        }
        if (typeof opts.onSuccess === "function") opts.onSuccess(data, keyName);
        return;
      }
      var toggleSelector = adminToggleIdByKey(keyName);
      if (toggleSelector) {
        $(toggleSelector).prop("checked", String(data.config_value || "").toUpperCase() !== "Y");
      }
      window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
      if (keyName === "RETENTION_DAYS") {
        window.ASK_ORACLE_ADMIN_CONFIG[keyName] = String(normalizeRetentionDays(data.config_value));
      } else if (
        keyName === "APP_DISPLAY_NAME" ||
        keyName === "PROMPT_BAR_TITLE" ||
        keyName === "PROMPT_PLACEHOLDER" ||
        keyName === "AI_INFO_MESSAGE" ||
        keyName === "APP_LOGO_URL" ||
        keyName === "DEFAULT_NL2SQL_PROFILE" ||
        keyName === "DEFAULT_RAG_PROFILE" ||
        keyName === "DEFAULT_AGENT_TEAM" ||
        keyName === "ADMIN_OWNER_APP_USER" ||
        keyName === "DEVELOPER_OWNER_APP_USER" ||
        keyName === "USER_OWNER_APP_USER" ||
        keyName === "AGENT_RUN_SERVICE_LEVEL"
      ) {
        if (
          keyName === "ADMIN_OWNER_APP_USER" ||
          keyName === "DEVELOPER_OWNER_APP_USER" ||
          keyName === "USER_OWNER_APP_USER"
        ) {
          window.ASK_ORACLE_ADMIN_CONFIG[keyName] = normalizeAdminOwnersCsv(data.config_value);
        } else {
          window.ASK_ORACLE_ADMIN_CONFIG[keyName] = String(data.config_value == null ? "" : data.config_value).trim();
        }
      } else {
        window.ASK_ORACLE_ADMIN_CONFIG[keyName] = data.config_value === "Y" ? "Y" : "N";
      }
      persistUiSyncState({
        admin_config: $.extend({}, window.ASK_ORACLE_ADMIN_CONFIG)
      });
      if (!opts.suppressSuccessMessage) {
        showAdminSettingUpdated(data.config_key || key, data.config_value);
      }
      if (typeof opts.onSuccess === "function") opts.onSuccess(data, keyName);
    };

    if (opts.busyMessage) {
      ajaxWithBusy(PROC.SAVE_ADMIN, requestPayload, opts.busyMessage, handleResponse);
    } else {
      ajax(PROC.SAVE_ADMIN, requestPayload, handleResponse);
    }
  }

  function saveAdminWithFallback(key, value) {
    var canonicalKey = String(key || "").trim().toUpperCase();
    var candidates = getAdminSaveKeyCandidates(canonicalKey);
    var isBooleanKey = canonicalKey !== "APP_ZOOM_PCT" && canonicalKey !== "RETENTION_DAYS";

    function persistLocalFallback() {
      window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
      var fallbackValue = isBooleanKey
        ? (String(value || "").toUpperCase() === "Y" ? "Y" : "N")
        : (canonicalKey === "RETENTION_DAYS" ? String(normalizeRetentionDays(value)) : String(normalizeZoomPct(value)));
      window.ASK_ORACLE_ADMIN_CONFIG[canonicalKey] = fallbackValue;
      persistUiSyncState({
        admin_config: $.extend({}, window.ASK_ORACLE_ADMIN_CONFIG)
      });
      var toggleSelector = adminToggleIdByKey(canonicalKey);
      if (toggleSelector && isBooleanKey) {
        $(toggleSelector).prop("checked", String(fallbackValue || "").toUpperCase() !== "Y");
      }
      showAdminSettingUpdated(canonicalKey, fallbackValue);
    }

    function tryCandidate(index) {
      if (index >= candidates.length) {
        persistLocalFallback();
        return;
      }
      var candidate = candidates[index];
      saveAdmin(candidate, value, {
        onSuccess: function(data, savedKey) {
          var normalizedSavedKey = String(savedKey || "").trim().toUpperCase();
          var normalizedValue = isBooleanKey
            ? (data && data.config_value === "Y" ? "Y" : "N")
            : String((data && data.config_value != null) ? data.config_value : value);
          window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
          window.ASK_ORACLE_ADMIN_CONFIG[canonicalKey] = normalizedValue;
          if (normalizedSavedKey && normalizedSavedKey !== canonicalKey) {
            window.ASK_ORACLE_ADMIN_CONFIG[normalizedSavedKey] = normalizedValue;
          }
          persistUiSyncState({
            admin_config: $.extend({}, window.ASK_ORACLE_ADMIN_CONFIG)
          });
        },
        onError: function(err, data) {
          var message = extractAdminSaveErrorMessage(err, data);
          if (isInvalidConfigKeyMessage(message)) {
            tryCandidate(index + 1);
            return;
          }
          showError(message || "Unable to save admin setting.");
        }
      });
    }

    tryCandidate(0);
  }

  function applyTheme() {
    var mode = "light";
    persistThemeMode(mode);
    applyThemePreviewMode(mode, { syncToggle: true });
  }

  function bindSystemThemeModeListener() {
    applyThemePreviewMode("light", { syncToggle: true });
  }

  function saveConversationMode() {
    if (!IS_ADMIN_USER) {
      showError("Not authorized to change conversation settings.");
      return;
    }
    var v = String($("#aoConvModeSelect").val() || "").trim();
    if (!v) {
      showError("Please select a conversation mode.");
      return;
    }
    var retentionDays = normalizeRetentionDays($("#aoRetentionDays").val());
    var agentRunServiceLevel = String($("#aoAgentRunServiceLevel").val() || "MEDIUM").trim().toUpperCase();
    if (["LOW", "MEDIUM", "HIGH"].indexOf(agentRunServiceLevel) === -1) {
      agentRunServiceLevel = "MEDIUM";
    }
    var defaultNl2sqlProfile = normalizeOptionalAdminTextValue($("#aoDefaultNl2sqlProfile").val());
    var defaultRagProfile = normalizeOptionalAdminTextValue($("#aoDefaultRagProfile").val());
    var defaultAgentTeam = normalizeOptionalAdminTextValue($("#aoDefaultAgentTeam").val());
    var sharedDefaultAgentTeam = sanitizeSettingsSharedAgentTeam(defaultAgentTeam);
    $("#aoRetentionDays").val(retentionDays);
    $("#aoAgentRunServiceLevel").val(agentRunServiceLevel);

    try {
      if (window.apex && typeof apex.item === "function" && apex.item("P20000_CONV_TYPE")) {
        apex.item("P20000_CONV_TYPE").setValue(v, null, true);
      }
    } catch (e) {}
    showBusy("Saving conversation settings...");
    ajax(PROC.SAVE_CONV_MODE, { x01: v }, function (err, data) {
      if (err) {
        hideBusy();
        showError(err.responseText || "Unable to save conversation mode.");
        return;
      }
      if (!data.success) {
        hideBusy();
        showError(data.message || "Unable to save conversation mode.");
        return;
      }
      var savedMode = String(data.conversation_mode || v || "CHAT_WITH_DB").trim().toUpperCase();
      window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
      window.ASK_ORACLE_ADMIN_CONFIG.DEFAULT_CONVERSATION_MODE = savedMode;

      var settings = [
        { key: "RETENTION_DAYS", value: String(retentionDays) },
        { key: "AGENT_RUN_SERVICE_LEVEL", value: agentRunServiceLevel },
        { key: "DEFAULT_NL2SQL_PROFILE", value: defaultNl2sqlProfile },
        { key: "DEFAULT_RAG_PROFILE", value: defaultRagProfile },
        { key: "DEFAULT_AGENT_TEAM", value: defaultAgentTeam }
      ];

      function saveNext(index) {
        if (index >= settings.length) {
          window.ASK_ORACLE_ADMIN_CONFIG.DEFAULT_CONVERSATION_MODE = savedMode;
          window.ASK_ORACLE_ADMIN_CONFIG.RETENTION_DAYS = String(retentionDays);
          window.ASK_ORACLE_ADMIN_CONFIG.AGENT_RUN_SERVICE_LEVEL = agentRunServiceLevel;
          window.ASK_ORACLE_ADMIN_CONFIG.DEFAULT_NL2SQL_PROFILE = defaultNl2sqlProfile;
          window.ASK_ORACLE_ADMIN_CONFIG.DEFAULT_RAG_PROFILE = defaultRagProfile;
          window.ASK_ORACLE_ADMIN_CONFIG.DEFAULT_AGENT_TEAM = defaultAgentTeam;
          /* Defaults are applied on the next Home load. Do not broadcast the
             conversation-mode default into an already active conversation. */
          var liveSyncAdminConfig = $.extend({}, window.ASK_ORACLE_ADMIN_CONFIG);
          delete liveSyncAdminConfig.DEFAULT_CONVERSATION_MODE;
          delete liveSyncAdminConfig.default_conversation_mode;
          persistUiSyncState({
            default_conversation_mode: "",
            selected_nl2sql_profile: defaultNl2sqlProfile,
            selected_rag_profile: defaultRagProfile,
            selected_agent_team: sharedDefaultAgentTeam,
            admin_config: liveSyncAdminConfig
          });
          hideBusy();
          showSuccess("Conversation settings saved.");
          return;
        }
        saveAdmin(settings[index].key, settings[index].value, {
          suppressSuccessMessage: true,
          onSuccess: function() {
            saveNext(index + 1);
          },
          onError: function(saveErr, saveData) {
            hideBusy();
            showError(extractAdminSaveErrorMessage(saveErr, saveData) || "Unable to save conversation settings.");
          }
        });
      }

      saveNext(0);
    });
  }

  function saveRoleAccessControls() {
    if (!IS_ADMIN_USER) {
      showError("Not authorized to change role access controls.");
      return;
    }

    var adminOwnerUsers = normalizeAdminOwnersCsv($("#aoAdminOwnerUsers").val());
    var developerOwnerUsers = normalizeAdminOwnersCsv($("#aoDeveloperOwnerUsers").val());
    var userOwnerUsers = normalizeAdminOwnersCsv($("#aoUserOwnerUsers").val());
    if (!adminOwnerUsers) {
      showError("Please enter at least one admin user.");
      return;
    }

    $("#aoAdminOwnerUsers").val(adminOwnerUsers);
    $("#aoDeveloperOwnerUsers").val(developerOwnerUsers);
    $("#aoUserOwnerUsers").val(userOwnerUsers);

    showBusy("Saving role access controls...");
    var keys = [
      { key: "ADMIN_OWNER_APP_USER", value: adminOwnerUsers },
      { key: "DEVELOPER_OWNER_APP_USER", value: developerOwnerUsers },
      { key: "USER_OWNER_APP_USER", value: userOwnerUsers }
    ];
    var idx = 0;

    function saveNext() {
      if (idx >= keys.length) {
        hideBusy();
        window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
        window.ASK_ORACLE_ADMIN_CONFIG.ADMIN_OWNER_APP_USER = adminOwnerUsers;
        window.ASK_ORACLE_ADMIN_CONFIG.DEVELOPER_OWNER_APP_USER = developerOwnerUsers;
        window.ASK_ORACLE_ADMIN_CONFIG.USER_OWNER_APP_USER = userOwnerUsers;
        window.ASK_ORACLE_ADMIN_CONFIG.USER_ROLE = resolveConfiguredUserRole({}, adminOwnerUsers, developerOwnerUsers, userOwnerUsers);
        IS_CONFIG_ADMIN_USER = isCurrentUserInOwnersCsv(adminOwnerUsers, {});
        applyAdminVisibility(window.ASK_ORACLE_ADMIN_CONFIG.USER_ROLE === "ADMIN", window.ASK_ORACLE_ADMIN_CONFIG.USER_ROLE);
        persistUiSyncState({
          admin_config: $.extend({}, window.ASK_ORACLE_ADMIN_CONFIG)
        });
        showSuccess("Role access controls saved.");
        return;
      }
      var current = keys[idx];
      saveAdmin(current.key, current.value, {
        suppressSuccessMessage: true,
        onSuccess: function() {
          idx += 1;
          saveNext();
        },
        onError: function(err, data) {
          hideBusy();
          showError(extractAdminSaveErrorMessage(err, data) || "Unable to save role access controls.");
        }
      }
      );
    }

    saveNext();
  }

  function saveUiSettings() {
    if (!IS_ADMIN_USER) {
      showError("Not authorized to change UI settings.");
      return;
    }

    var appDisplayName = normalizeAdminTextValue($("#aoUiAppName").val(), "Ask Oracle Select AI");
    var appLogoUrl = normalizeOptionalAdminTextValue($("#aoUiAppLogoUrl").val());
    var promptBarTitle = normalizeAdminTextValue($("#aoUiPromptBarTitle").val(), "Ask Oracle");
    var promptPlaceholder = normalizeAdminTextValue($("#aoUiPromptPlaceholder").val(), "Ask Question");
    var aiInfoMessage = normalizeAdminTextValue($("#aoUiAiInfoMessage").val(), "AI models can make mistakes. Verify responses.");
    var handleError = function(err, data) {
      hideBusy();
      showError(extractAdminSaveErrorMessage(err, data) || "Unable to save UI settings.");
    };

    $("#aoUiAppName").val(appDisplayName);
    $("#aoUiAppLogoUrl").val(appLogoUrl);
    $("#aoUiPromptBarTitle").val(promptBarTitle);
    $("#aoUiPromptPlaceholder").val(promptPlaceholder);
    $("#aoUiAiInfoMessage").val(aiInfoMessage);

    showBusy("Saving UI settings...");
    saveAdmin("APP_DISPLAY_NAME", appDisplayName, {
      suppressSuccessMessage: true,
      onSuccess: function() {
        saveAdmin("APP_LOGO_URL", appLogoUrl, {
          suppressSuccessMessage: true,
          onSuccess: function() {
            saveAdmin("PROMPT_BAR_TITLE", promptBarTitle, {
              suppressSuccessMessage: true,
              onSuccess: function() {
                saveAdmin("PROMPT_PLACEHOLDER", promptPlaceholder, {
                  suppressSuccessMessage: true,
                  onSuccess: function() {
                    saveAdmin("AI_INFO_MESSAGE", aiInfoMessage, {
                      suppressSuccessMessage: true,
                      onSuccess: function() {
                        window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
                        window.ASK_ORACLE_ADMIN_CONFIG.APP_DISPLAY_NAME = appDisplayName;
                        window.ASK_ORACLE_ADMIN_CONFIG.APP_LOGO_URL = appLogoUrl;
                        window.ASK_ORACLE_ADMIN_CONFIG.PROMPT_BAR_TITLE = promptBarTitle;
                        window.ASK_ORACLE_ADMIN_CONFIG.PROMPT_PLACEHOLDER = promptPlaceholder;
                        window.ASK_ORACLE_ADMIN_CONFIG.AI_INFO_MESSAGE = aiInfoMessage;
                        persistUiSyncState({
                          admin_config: $.extend({}, window.ASK_ORACLE_ADMIN_CONFIG)
                        });
                        applySettingsHeaderBrand(appDisplayName, appLogoUrl);
                        hideBusy();
                        showSuccess("UI settings saved.");
                      },
                      onError: handleError
                    });
                  },
                  onError: handleError
                });
              },
              onError: handleError
            });
          },
          onError: handleError
        });
      },
      onError: handleError
    });
  }

  function normalizeDbCategory(hostValue) {
    var host = String(hostValue || "").toLowerCase();
    if (host.indexOf("redshift") >= 0 || host.indexOf("awsredshift") >= 0) return "awsredshift";
    if (host.indexOf("mysql") >= 0) return "mysql";
    if (host.indexOf("postgres") >= 0) return "postgresql";
    if (host.indexOf("snowflake") >= 0) return "snowflake";
    if (host.indexOf("salesforce") >= 0 || host.indexOf("force.com") >= 0) return "salesforce";
    if (host.indexOf("sqlserver") >= 0 || host.indexOf("mssql") >= 0) return "mssql";
    if (host.indexOf("oracle") >= 0) return "oracle";
    return "other";
  }

  function renderDbLinkList() {
    var filter = String($("#aoDbLinkCategoryFilter").val() || "all").toLowerCase();
    var rows = (DB_LINK_ROWS || []).filter(function(row) {
      if (filter === "all") return true;
      return String(row.category || "").toLowerCase() === filter;
    });
    if (!rows.length) {
      $("#aoDbLinkList").html("No connections found.");
      return;
    }
    var html = "<table class='ao-dblink-table'><thead><tr><th>Data Link Name</th><th>Created</th><th>Action</th></tr></thead><tbody>";
    rows.forEach(function(row) {
      var dbLinkName = String(row.db_link || "");
      html += "<tr>";
      html += "<td class='ao-dblink-name-cell'>" + apex.util.escapeHTML(dbLinkName) + "</td>";
      html += "<td class='ao-dblink-created-cell'>" + apex.util.escapeHTML(String(row.created || "")) + "</td>";
      html += "<td class='ao-dblink-actions-cell'>";
      html += "  <div class='ao-row-actions'>";
      html += "    <button type='button' class='ao-row-more-btn ao-admin-only' data-dblink-menu-trigger='" + escapeAttr(dbLinkName) + "' aria-label='More actions' title='More actions'>⋮</button>";
      html += "    <div class='ao-row-menu' data-dblink-menu='" + escapeAttr(dbLinkName) + "'>";
      html += "      <button type='button' class='ao-row-menu-item is-danger ao-admin-only' data-drop-dblink='" + escapeAttr(dbLinkName) + "'>Delete Data Link</button>";
      html += "    </div>";
      html += "  </div>";
      html += "</td>";
      html += "</tr>";
    });
    html += "</tbody></table>";
    $("#aoDbLinkList").html(html);
    if (!CAN_MANAGE_SETTINGS) {
      $("#aoDbLinkList [data-drop-dblink], #aoDbLinkList [data-dblink-menu-trigger]").prop("disabled", true);
    }
  }

  function renderCatalogTables() {
    if (!CATALOG_TABLE_ROWS.length) {
      $("#aoCatalogTables").html("No tables found for this database connection.");
      return;
    }
    var html = "<div class='ao-checkbox-list'>";
    CATALOG_TABLE_ROWS.forEach(function(row, idx) {
      var tableRef = String((row.owner ? row.owner + "." : "") + row.table_name);
      html += "<label><input type='checkbox' data-cat-table-index='" + idx + "' /> <span>" + apex.util.escapeHTML(tableRef) + "</span></label>";
    });
    html += "</div>";
    $("#aoCatalogTables").html(html);
  }

  function refreshDbLinks(callback) {
    var done = typeof callback === "function" ? callback : null;
    // Temporarily disabled: database-link listing is not used by this UI.
    // Keep this no-op wrapper so existing create/drop handlers remain safe.
    if (done) done(null, { success: true, db_links: DB_LINK_ROWS });
    return;

    /*
    ajaxWithBusy(PROC.LIST_DB_LINKS, {}, "Loading database links...", function(err, data) {
      if (err) {
        showError(err.responseText || "Unable to load database links.");
        if (done) done(err);
        return;
      }
      if (!data.success) {
        showError(data.message || "Unable to load database links.");
        if (done) done(data);
        return;
      }
      DB_LINK_ROWS = Array.isArray(data.db_links) ? data.db_links : [];
      var categories = { all: true };
      DB_LINK_ROWS.forEach(function(row) {
        categories[String(row.category || "other").toLowerCase()] = true;
      });
      var categoryRows = Object.keys(categories).sort().map(function(key) {
        return { d: key, r: key };
      });
      fillSelect("#aoDbLinkCategoryFilter", categoryRows, $("#aoDbLinkCategoryFilter").val() || "all", {
        includeBlank: false
      });
      var lov = DB_LINK_ROWS.map(function(row) { return { d: row.db_link, r: row.db_link }; });
      fillSelect("#aoCatalogDbLinkSelect", lov, $("#aoCatalogDbLinkSelect").val() || "");
      renderDbLinkList();
      if (done) done(null, data);
    });
    */
  }

  function loadCatalogHistory() {
    ajax(PROC.CREATE_CATALOG, { x01: "__LIST__" }, function(err, data) {
      if (err || !data || data.success === false) {
        $("#aoCatalogList").html("Data collection list unavailable.");
        $("#aoCatalogDetails").hide().html("");
        ACTIVE_CATALOG_DETAILS = "";
        return;
      }
      var rows = Array.isArray(data.history) ? data.history : [];
      CATALOG_HISTORY_ROWS = rows.slice();
      if (!rows.length) {
        $("#aoCatalogList").html("No data collections created yet.");
        $("#aoCatalogDetails").hide().html("");
        ACTIVE_CATALOG_DETAILS = "";
        return;
      }
      var grouped = {};
      rows.forEach(function(row) {
        var c = String((row && row.catalog_name) || "").trim();
        if (!c) return;
        if (!grouped[c]) {
          grouped[c] = {
            catalog_name: c,
            db_link_name: String((row && row.db_link_name) || "").trim(),
            created_on: String((row && row.created_on) || "").trim(),
            table_map: {},
            view_map: {}
          };
        }
        var t = String((row && row.table_name) || "").trim();
        var v = String((row && row.view_name) || "").trim();
        if (t) grouped[c].table_map[t.toUpperCase()] = t;
        if (v) grouped[c].view_map[v.toUpperCase()] = v;
      });

      var summaryRows = Object.keys(grouped).sort().map(function(k) {
        var g = grouped[k];
        return {
          catalog_name: g.catalog_name,
          db_link_name: g.db_link_name,
          created_on: g.created_on,
          total_views: Object.keys(g.view_map).length
        };
      });

      var html = "<table class='ao-dblink-table ao-catalog-table'><thead><tr><th>Data Collection Name</th><th>Data Link Name</th><th>Total Views</th><th>Created</th><th></th></tr></thead><tbody>";
      summaryRows.forEach(function(row) {
        var catalogName = String(row.catalog_name || "").trim();
        html += "<tr>";
        html += "<td class='ao-catalog-name-cell'><button type='button' class='ao-link-btn ao-link-btn--inline' data-open-catalog='" + escapeAttr(catalogName) + "'>" + apex.util.escapeHTML(catalogName) + "</button></td>";
        html += "<td>" + apex.util.escapeHTML(String(row.db_link_name || "")) + "</td>";
        html += "<td>" + apex.util.escapeHTML(String(row.total_views || 0)) + "</td>";
        html += "<td>" + apex.util.escapeHTML(String(row.created_on || "")) + "</td>";
        html += "<td class='ao-dblink-actions-cell'>";
        html += "  <div class='ao-row-actions'>";
        html += "    <button type='button' class='ao-row-more-btn ao-admin-only' data-catalog-menu-trigger='" + escapeAttr(catalogName) + "' aria-label='More actions' title='More actions'>⋮</button>";
        html += "    <div class='ao-row-menu' data-catalog-menu='" + escapeAttr(catalogName) + "'>";
        html += "      <button type='button' class='ao-row-menu-item ao-admin-only' data-add-catalog-to-profile='" + escapeAttr(catalogName) + "'><span class='fa fa-id-badge ao-row-menu-icon' aria-hidden='true'></span><span>Add to AI Profile</span></button>";
        html += "      <button type='button' class='ao-row-menu-item is-danger ao-admin-only' data-drop-catalog='" + escapeAttr(catalogName) + "'>Drop Data Collection</button>";
        html += "    </div>";
        html += "  </div>";
        html += "</td>";
        html += "</tr>";
      });
      html += "</tbody></table>";
      $("#aoCatalogList").html(html);
      if (!CAN_MANAGE_SETTINGS) {
        $("#aoCatalogList [data-drop-catalog], #aoCatalogList [data-add-catalog-to-profile], #aoCatalogList [data-catalog-menu-trigger]").prop("disabled", true);
      }
      $("#aoCatalogDetails").hide().html("");
      ACTIVE_CATALOG_DETAILS = "";
    });
  }

  function renderCatalogDetails(catalogNameInput) {
    var catalogName = String(catalogNameInput || "").trim();
    if (!catalogName) {
      $("#aoCatalogDetails").hide().html("");
      ACTIVE_CATALOG_DETAILS = "";
      return;
    }
    var detailRows = (CATALOG_HISTORY_ROWS || []).filter(function(row) {
      return String((row && row.catalog_name) || "").trim().toUpperCase() === catalogName.toUpperCase();
    });
    if (!detailRows.length) {
      $("#aoCatalogDetails").hide().html("");
      ACTIVE_CATALOG_DETAILS = "";
      return;
    }
    var html = "<div class='ao-catalog-details-title'>Data Collection: " + apex.util.escapeHTML(catalogName) + "</div>";
    html += "<table class='ao-dblink-table ao-catalog-table'><thead><tr><th>Table</th><th>View</th><th>Data Link Name</th><th>Created</th></tr></thead><tbody>";
    detailRows.forEach(function(row) {
      html += "<tr>";
      html += "<td>" + apex.util.escapeHTML(String((row && row.table_name) || "")) + "</td>";
      html += "<td>" + apex.util.escapeHTML(String((row && row.view_name) || "")) + "</td>";
      html += "<td>" + apex.util.escapeHTML(String((row && row.db_link_name) || "")) + "</td>";
      html += "<td>" + apex.util.escapeHTML(String((row && row.created_on) || "")) + "</td>";
      html += "</tr>";
    });
    html += "</tbody></table>";
    $("#aoCatalogDetails").html(html).show();
    ACTIVE_CATALOG_DETAILS = catalogName.toUpperCase();
  }

  function bootstrap(options) {
    var opts = options || {};
    var useCache = opts.useCache === true;
    var forceServer = !!opts.forceServer;
    var hasAppliedCache = false;

    function applyBootstrapData(data) {
      if (!data || typeof data !== "object") return;
      LAST_BOOTSTRAP_DATA = data || {};
      ATTR_EDIT_STATE.NL2SQL = false;
      ATTR_EDIT_STATE.RAG = false;

      fillSelect("#aoNl2sqlSelect", data.nl2sql_profiles, data.current_nl2sql, {
        includeBlank: true,
        blankLabel: "Select NL2 SQL Profile"
      });
      fillSelect("#aoDropNl2sqlSelect", data.nl2sql_profiles, "");
      fillSelect("#aoRagSelect", data.rag_profiles, data.current_rag, {
        includeBlank: true,
        blankLabel: "Select RAG Profile"
      });
      fillSelect("#aoDropRagSelect", data.rag_profiles, "");
      fillSelect("#aoDropRagVectorIndexSelect", data.vector_indexes, "");
      fillSelect("#aoRagCreateVectorIndex", data.vector_indexes, "");
      fillSelect("#aoVectorIndexSelect", data.vector_indexes, $("#aoVectorIndexSelect").val() || "", {
        includeBlank: true,
        blankLabel: "Select Vector Index",
        autoSelectFirst: true
      });
      VECTOR_INDEX_ROWS = (data.vector_indexes || []).map(function(row) {
        return { index_name: String((row && row.r) || "").trim() };
      }).filter(function(row) { return !!row.index_name; });
      renderVectorIndexSummary();
      fillSelect("#aoRagVectorProfileName", data.nl2sql_profiles, data.current_nl2sql || "");
      fillSelect("#aoDefaultNl2sqlProfile", data.nl2sql_profiles, data.default_nl2sql_profile || "");
      fillSelect("#aoDefaultRagProfile", data.rag_profiles, data.default_rag_profile || "");
      var agentTeamRows = Array.isArray(data.agent_teams) ? data.agent_teams : [];
      var firstAgentTeam = "";
      agentTeamRows.some(function(row) {
        var candidate = String((row && row.r) || "").trim();
        if (!candidate) return false;
        firstAgentTeam = candidate;
        return true;
      });
      fillSelect("#aoDefaultAgentTeam", agentTeamRows, data.default_agent_team || "");
      fillSelect("#aoAgentTeamPicker", agentTeamRows, firstAgentTeam, {
        includeBlank: true,
        blankLabel: "Select Agent Team",
        autoSelectFirst: true
      });
      fillSelect("#aoAgentFilterSelect", [], "", {
        includeBlank: true,
        blankLabel: "Select Item"
      });
      fillSelect("#aoCreateCredential", data.credentials, data.current_credential);
      fillSelect("#aoRagCreateCredential", data.credentials, data.current_credential);
      fillSelect("#aoRagVectorCredential", data.credentials, data.current_credential);
      fillSelect("#aoCreateProvider", providerLovRows(), $("#aoCreateProvider").val());
      fillSelect("#aoRagCreateProvider", providerLovRows(), $("#aoRagCreateProvider").val());
      ALL_AGENT_ENTITY_OPTIONS.TEAM = uniqueLovRows(data.agent_teams || []);
      ALL_AGENT_ENTITY_OPTIONS.AGENT = uniqueLovRows(data.agents || []);
      ALL_AGENT_ENTITY_OPTIONS.TASK = uniqueLovRows(data.agent_tasks || []);
      ALL_AGENT_ENTITY_OPTIONS.TOOL = uniqueLovRows(data.agent_tools || []);
      AGENT_PROFILE_LOOKUP = buildAgentProfileLookup(data.agents || []);
      BACKEND_CALLABLE_OPTIONS = filterBackendCallableRows(data.backend_callables || []);
      AVAILABLE_OBJECT_OPTIONS = uniqueLovRows(data.available_objects || []);
      fillSelect("#aoAgentCreateToolFunction", BACKEND_CALLABLE_OPTIONS, "");
      fillSelect("#aoAgentEditToolFunction", BACKEND_CALLABLE_OPTIONS, "");
      fillSelect("#aoAgentStudioNewToolFunction", BACKEND_CALLABLE_OPTIONS, "");
      refreshObjectPickers();
      ALL_PROFILE_OPTIONS = [];
      (data.nl2sql_profiles || []).concat(data.rag_profiles || []).forEach(function(row) {
        var value = String((row && row.r) || "").trim();
        if (!value) return;
        if (ALL_PROFILE_OPTIONS.some(function(item) { return String(item.r || "") === value; })) return;
        ALL_PROFILE_OPTIONS.push({ d: row.d || value, r: value });
      });
      fillSelect("#aoAgentEditProfileName", ALL_PROFILE_OPTIONS, "");
      fillMultiSelect("#aoAgentCreateAgentProfiles", ALL_PROFILE_OPTIONS, []);
      refreshAgentCreateLinkOptions();
      setNl2sqlAdminCardView("none");
      setRagAdminCardView("none");

      var nl2sqlToLoad = data.current_nl2sql;
      if (!nl2sqlToLoad && data.nl2sql_profiles && data.nl2sql_profiles.length) {
        nl2sqlToLoad = data.nl2sql_profiles[0].r;
      }
      if (nl2sqlToLoad) {
        $("#aoNl2sqlSelect").val(nl2sqlToLoad);
        apex.item("P20000_SERVICE").setValue(nl2sqlToLoad, null, true);
        loadAttrs("NL2SQL");
      } else {
        renderAttrs("#aoNl2sqlAttrs", []);
        syncAttrEditUi("NL2SQL");
      }

      var ragToLoad = data.current_rag;
      if (!ragToLoad && data.rag_profiles && data.rag_profiles.length) {
        ragToLoad = data.rag_profiles[0].r;
      }
      if (ragToLoad) {
        $("#aoRagSelect").val(ragToLoad);
        apex.item("P20000_RAGSERVICE").setValue(ragToLoad, null, true);
        loadAttrs("RAG");
      } else {
        renderAttrs("#aoRagAttrs", []);
        syncAttrEditUi("RAG");
      }

      $("#aoAgentTeamDesc").val("");
      clearAgentTeamBoxes();
      if (firstAgentTeam) {
        $("#aoAgentTeamPicker").val(firstAgentTeam);
        loadAgentTeamDetails(firstAgentTeam);
      }

      var showOpenEditor = resolveBootstrapFlag(data, ["show_open_in_editor", "SHOW_OPEN_IN_EDITOR"], true);
      var showAgentThoughts = resolveBootstrapFlag(data, ["show_agent_thoughts", "SHOW_AGENT_THOUGHTS"], true);
      var showExportPdf = resolveBootstrapFlag(data, ["show_export_pdf", "show_export_pdf_button", "SHOW_EXPORT_PDF"], true);
      var showExportExcel = resolveBootstrapFlag(data, ["show_export_excel", "show_export_excel_button", "SHOW_EXPORT_EXCEL"], true);
      var showConversationTimer = resolveBootstrapFlag(data, ["show_conversation_timer", "show_conversation_timer_button", "SHOW_CONVERSATION_TIMER"], true);
      var showDeletePrompt = resolveBootstrapFlag(data, ["show_delete_prompt", "show_delete_prompt_button", "SHOW_DELETE_PROMPT"], true);
      var showEndUserConvStyleSwitch = resolveBootstrapFlag(data, ["enable_end_user_switch_conv_style", "ENABLE_END_USER_SWITCH_CONV_STYLE"], true);
      var showEndUserProfileAgentSwitch = resolveBootstrapFlag(data, ["enable_end_user_switch_profiles_agents", "ENABLE_END_USER_SWITCH_PROFILES_AGENTS"], true);
      var showEndUserNl2sqlSwitch = resolveBootstrapFlag(data, ["enable_end_user_switch_nl2sql_profile", "ENABLE_END_USER_SWITCH_NL2SQL_PROFILE"], true);
      var showEndUserRagSwitch = resolveBootstrapFlag(data, ["enable_end_user_switch_rag_profile", "ENABLE_END_USER_SWITCH_RAG_PROFILE"], true);

      $("#aoToggleOpenEditor").prop("checked", !showOpenEditor);
      $("#aoToggleAgentThoughts").prop("checked", !showAgentThoughts);
      $("#aoToggleExportPdf").prop("checked", !showExportPdf);
      $("#aoToggleExportExcel").prop("checked", !showExportExcel);
      $("#aoToggleConversationTimer").prop("checked", !showConversationTimer);
      $("#aoToggleDeletePrompt").prop("checked", !showDeletePrompt);
      $("#aoToggleEndUserConvStyle").prop("checked", !showEndUserConvStyleSwitch);
      $("#aoToggleEndUserProfilesAgents").prop("checked", !showEndUserProfileAgentSwitch);
      $("#aoToggleEndUserNl2sqlProfile").prop("checked", !showEndUserNl2sqlSwitch);
      $("#aoToggleEndUserRagProfile").prop("checked", !showEndUserRagSwitch);
      configureZoomSliderBounds();
      var appZoomSource = data.app_zoom_pct;
      if (appZoomSource == null || String(appZoomSource).trim() === "") {
        appZoomSource = readStoredZoomPct();
      }
      var appZoomPct = setZoomSliderValue(appZoomSource);
      applyAppZoomPreview(appZoomPct);
      var syncedState = readUiSyncState();
      var syncedConvMode = String((syncedState && syncedState.default_conversation_mode) || "").trim().toUpperCase();
      var convMode = String(syncedConvMode || data.current_conv_mode || "CHAT_WITH_DB").trim().toUpperCase();
      var retentionDays = normalizeRetentionDays(data.retention_days);
      var appDisplayName = normalizeAdminTextValue(data.app_display_name, "Ask Oracle Select AI");
      var promptBarTitle = normalizeAdminTextValue(data.prompt_bar_title, "Ask Oracle");
      var promptPlaceholder = normalizeAdminTextValue(data.prompt_placeholder, "Ask Question");
      var aiInfoMessage = normalizeAdminTextValue(getBootstrapValue(data, "ai_info_message", "AI_INFO_MESSAGE"), "AI models can make mistakes. Verify responses.");
      var appLogoUrl = normalizeOptionalAdminTextValue(data.app_logo_url);
      var defaultNl2sqlProfile = normalizeOptionalAdminTextValue(data.default_nl2sql_profile);
      var defaultRagProfile = normalizeOptionalAdminTextValue(data.default_rag_profile);
      var defaultAgentTeam = normalizeOptionalAdminTextValue(data.default_agent_team);
      var adminOwnerUsers = normalizeAdminOwnersCsv(getBootstrapValue(data, "admin_owner_app_user", "ADMIN_OWNER_APP_USER"));
      var developerOwnerUsers = normalizeAdminOwnersCsv(getBootstrapValue(data, "developer_owner_app_user", "DEVELOPER_OWNER_APP_USER"));
      var userOwnerUsers = normalizeAdminOwnersCsv(getBootstrapValue(data, "user_owner_app_user", "USER_OWNER_APP_USER"));
      var currentAppUser = getCurrentAppUser(data);
      var userRole = resolveConfiguredUserRole(data, adminOwnerUsers, developerOwnerUsers, userOwnerUsers);
      USER_ROLE = userRole;
      IS_CONFIG_ADMIN_USER = isCurrentUserInOwnersCsv(adminOwnerUsers, data);
      IS_ADMIN_USER = IS_CONFIG_ADMIN_USER && USER_ROLE === "ADMIN";
      CAN_MANAGE_SETTINGS = USER_ROLE === "ADMIN" || USER_ROLE === "DEVELOPER";
      var agentRunServiceLevel = String(data.agent_run_service_level || "MEDIUM").trim().toUpperCase();
      if (["LOW", "MEDIUM", "HIGH"].indexOf(agentRunServiceLevel) === -1) {
        agentRunServiceLevel = "MEDIUM";
      }
      $("#aoConvModeSelect").val(convMode);
      $("#aoRetentionDays").val(retentionDays);
      $("#aoAgentRunServiceLevel").val(agentRunServiceLevel);
      $("#aoUiAppName").val(appDisplayName);
      $("#aoUiAppLogoUrl").val(appLogoUrl);
      $("#aoUiPromptBarTitle").val(promptBarTitle);
      $("#aoUiPromptPlaceholder").val(promptPlaceholder);
      $("#aoUiAiInfoMessage").val(aiInfoMessage);
      $("#aoDefaultNl2sqlProfile").val(defaultNl2sqlProfile);
      $("#aoDefaultRagProfile").val(defaultRagProfile);
      $("#aoDefaultAgentTeam").val(defaultAgentTeam);
      $("#aoAdminOwnerUsers").val(adminOwnerUsers);
      $("#aoDeveloperOwnerUsers").val(developerOwnerUsers);
      $("#aoUserOwnerUsers").val(userOwnerUsers);
      applySettingsHeaderBrand(appDisplayName, appLogoUrl);

      window.ASK_ORACLE_ADMIN_CONFIG = {
        SHOW_OPEN_IN_EDITOR: showOpenEditor ? "Y" : "N",
        SHOW_AGENT_THOUGHTS: showAgentThoughts ? "Y" : "N",
        SHOW_EXPORT_PDF: showExportPdf ? "Y" : "N",
        SHOW_EXPORT_EXCEL: showExportExcel ? "Y" : "N",
        SHOW_CONVERSATION_TIMER: showConversationTimer ? "Y" : "N",
        SHOW_DELETE_PROMPT: showDeletePrompt ? "Y" : "N",
        ENABLE_END_USER_SWITCH_CONV_STYLE: showEndUserConvStyleSwitch ? "Y" : "N",
        ENABLE_END_USER_SWITCH_PROFILES_AGENTS: showEndUserProfileAgentSwitch ? "Y" : "N",
        ENABLE_END_USER_SWITCH_NL2SQL_PROFILE: showEndUserNl2sqlSwitch ? "Y" : "N",
        ENABLE_END_USER_SWITCH_RAG_PROFILE: showEndUserRagSwitch ? "Y" : "N",
        DEFAULT_CONVERSATION_MODE: convMode,
        RETENTION_DAYS: String(retentionDays),
        AGENT_RUN_SERVICE_LEVEL: agentRunServiceLevel,
        ADMIN_OWNER_APP_USER: adminOwnerUsers,
        DEVELOPER_OWNER_APP_USER: developerOwnerUsers,
        USER_OWNER_APP_USER: userOwnerUsers,
        USER_ROLE: userRole,
        CURRENT_APP_USER: currentAppUser,
        APP_ZOOM_PCT: String(appZoomPct),
        APP_DISPLAY_NAME: appDisplayName,
        APP_LOGO_URL: appLogoUrl,
        PROMPT_BAR_TITLE: promptBarTitle,
        PROMPT_PLACEHOLDER: promptPlaceholder,
        AI_INFO_MESSAGE: aiInfoMessage,
        DEFAULT_NL2SQL_PROFILE: defaultNl2sqlProfile,
        DEFAULT_RAG_PROFILE: defaultRagProfile,
        DEFAULT_AGENT_TEAM: defaultAgentTeam
      };

      var themeMode = readStoredThemeMode();
      applyThemePreviewMode(themeMode, { syncToggle: true });
      applyAdminVisibility(data.is_admin, userRole);
      setAdminSection("ui");
      setDbLinkCardView("list");
      if (!$("#aoDbGatewayParamsRows .ao-dblink-gateway-row").length) {
        addDbGatewayParamRow("db_type", "");
      }
      refreshDbLinks();
      loadCatalogHistory();
      setCatalogCardView("list");
      applyProfileCreateDefaults();
      applyProviderRules();
      applyRagProviderRules();
      refreshPrebuiltAgentInstallStateFromBootstrap(data);
      renderPrebuiltAgents();
      /* A bootstrap response contains index names only. If this page is
         already open, reload its detail rows so it cannot overwrite the
         attributes returned by SETTINGS_GET_VECTOR_INDEXES. */
      if ($("#aoVectorIndexesPanel").hasClass("is-active")) {
        loadVectorIndexes();
      }
      persistUiSyncState({
        admin_config: $.extend({}, window.ASK_ORACLE_ADMIN_CONFIG),
        default_conversation_mode: convMode,
        selected_nl2sql_profile: defaultNl2sqlProfile || String($("#aoNl2sqlSelect").val() || "").trim(),
        selected_rag_profile: defaultRagProfile || String($("#aoRagSelect").val() || "").trim(),
        selected_agent_team: sanitizeSettingsSharedAgentTeam(defaultAgentTeam)
      });
    }

    if (useCache && !forceServer) {
      var cached = readBootstrapCache();
      if (cached) {
        applyBootstrapData(cached);
        hasAppliedCache = true;
      }
    }

    ajax(PROC.BOOTSTRAP, {
      pageItems: "#P20000_SERVICE,#P20000_RAGSERVICE,#P20000_AGENT_SERVICE"
    }, function (err, data) {
      if (err) {
        if (!hasAppliedCache) {
          showError(err.responseText || "Failed to initialize settings.");
        }
        return;
      }
      writeBootstrapCache(data || {});
      applyBootstrapData(data || {});
    });
  }

  function getApexRuntimeValue(envKey, inputId) {
    var envValue = "";
    var inputValue = "";
    try {
      envValue = window.apex && apex.env ? apex.env[envKey] : "";
    } catch (e1) {}
    if (envValue) return String(envValue);
    try {
      inputValue = $("#" + inputId).val();
    } catch (e2) {}
    return String(inputValue || "");
  }

  function navigateToApexPage(pageId) {
    var targetPage = String(pageId || "1").trim() || "1";
    var appId = getApexRuntimeValue("APP_ID", "pFlowId");
    var sessionId = getApexRuntimeValue("APP_SESSION", "pInstance");
    var isFramed = false;
    var params;
    var targetUrl;

    if (!sessionId) {
      try {
        params = new URLSearchParams(window.location.search || "");
        sessionId = params.get("session") || params.get("p_instance") || "";
      } catch (e1) {}
    }

    if (appId) {
      targetUrl = "f?p=" + encodeURIComponent(appId) + ":" + encodeURIComponent(targetPage) + ":" + encodeURIComponent(sessionId || "");
    } else {
      targetUrl = "f?p=1:" + encodeURIComponent(targetPage) + ":" + encodeURIComponent(sessionId || "");
    }

    if (targetPage === "1") {
      try {
        isFramed = !!(window.parent && window.parent !== window);
      } catch (e0) {
        isFramed = false;
      }
      if (isFramed) {
        var dialogNav = null;
        try {
          if (window.apex && apex.navigation && apex.navigation.dialog && typeof apex.navigation.dialog.close === "function") {
            dialogNav = apex.navigation.dialog;
          } else if (window.parent && window.parent.apex && window.parent.apex.navigation &&
                     window.parent.apex.navigation.dialog &&
                     typeof window.parent.apex.navigation.dialog.close === "function") {
            dialogNav = window.parent.apex.navigation.dialog;
          }
        } catch (eNav) {}
        if (dialogNav) {
          try {
            dialogNav.close(true, {});
            return;
          } catch (eClose1) {
            try {
              dialogNav.close();
              return;
            } catch (eClose2) {}
          }
        }
      }
      try {
        var referrer = String(document.referrer || "").trim();
        var currentHref = String(window.location.href || "");
        var canTryBack = !!(window.history && window.history.length > 1 && referrer && referrer !== currentHref);
        if (canTryBack) {
          var beforeHref = currentHref;
          window.history.back();
          window.setTimeout(function() {
            try {
              if (String(window.location.href || "") === beforeHref) {
                if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
                  apex.navigation.redirect(targetUrl);
                } else {
                  window.location.href = targetUrl;
                }
              }
            } catch (eTimeout) {}
          }, 250);
          return;
        }
      } catch (e3) {}
    }

    if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
      apex.navigation.redirect(targetUrl);
    } else {
      window.location.href = targetUrl;
    }
  }

  function openDbLinkCreateInNewTab() {
    var appId = String(getApexRuntimeValue("APP_ID", "pFlowId") || "").trim();
    var sessionId = String(getApexRuntimeValue("APP_SESSION", "pInstance") || "").trim();
    var pageId = String(getApexRuntimeValue("APP_PAGE_ID", "pFlowStepId") || "").trim() || "20000";
    var baseUrl = appId
      ? ("f?p=" + encodeURIComponent(appId) + ":" + encodeURIComponent(pageId) + ":" + encodeURIComponent(sessionId))
      : ("f?p=1:" + encodeURIComponent(pageId) + ":" + encodeURIComponent(sessionId));
    var createUrl = baseUrl + "::NO:::#dblink-create";
    try {
      window.open(createUrl, "_blank", "noopener,noreferrer");
    } catch (e) {
      window.location.href = createUrl;
    }
  }

  function openDbLinkCreateInPage() {
    setNav("data-sources", "data-sources-connections");
    setDataSourceSection("connections");
    setDbLinkCardView("create");
    applyDbLinkCreatePrefillFromUrl();
    window.setTimeout(function() {
      var createCard = document.querySelector("[data-ds-section='connections'] .ao-subcard.ao-profile-panel-box");
      var target = document.getElementById("aoDbLinkName");
      if (createCard && createCard.scrollIntoView) {
        createCard.scrollIntoView({ behavior: "smooth", block: "start" });
      }
      if (target && typeof target.focus === "function") target.focus();
    }, 60);
  }

  function applyDbLinkCreatePrefillFromUrl() {
    var params;
    var hashText;
    var hashQuery;
    var hashParams;
    var map;
    var hasPrefill = false;

    try {
      params = new URLSearchParams(String((window.location && window.location.search) || ""));
    } catch (e) {
      return;
    }
    if (!params) return;

    try {
      hashText = String((window.location && window.location.hash) || "");
      hashQuery = "";
      if (hashText.indexOf("?") >= 0) {
        hashQuery = hashText.substring(hashText.indexOf("?") + 1);
      } else if (hashText.indexOf("&") >= 0) {
        hashQuery = hashText.substring(hashText.indexOf("&") + 1);
      }
      hashParams = new URLSearchParams(hashQuery || "");
    } catch (eHash) {
      hashParams = null;
    }

    map = {
      db_link_name: "#aoDbLinkName",
      db_type: "#aoDbType",
      hostname: "#aoDbHost",
      port: "#aoDbPort",
      service_name: "#aoDbServiceName",
      credential_name: "#aoDbLinkCredential",
      ssl_server_cert_dn: "#aoDbSslDn",
      directory_name: "#aoDbDirectoryName"
    };

    Object.keys(map).forEach(function(key) {
      var value = String(params.get(key) || "").trim();
      if (!value && hashParams) {
        value = String(hashParams.get(key) || "").trim();
      }
      if (!value) return;
      $(map[key]).val(value);
      hasPrefill = true;
    });

    if (hasPrefill) {
      var createCard = document.querySelector("[data-ds-section='connections'] .ao-subcard.ao-profile-panel-box");
      if (createCard && createCard.scrollIntoView) {
        createCard.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
  }

  function isHomeTargetHref(href) {
    var text = String(href || "").trim();
    var appId = String(getApexRuntimeValue("APP_ID", "pFlowId") || "").trim();
    var match;
    if (!text) return false;
    match = text.match(/(?:^|[?&])p=([^:]+):([^:]+):/i);
    if (!match) return false;
    if (String(match[2] || "").trim() !== "1") return false;
    if (appId && String(match[1] || "").trim() !== appId) return false;
    return true;
  }

  function bindEvents() {
    $(document).on("click", "#aoSidebarToggle", function(event) {
      event.preventDefault();
      toggleSidebarCollapsedState();
    });

    $(document).on("click", "[data-ao-home-page], .ao-header-home-link, .ao-home-link, a[href*='f?p=']", function (event) {
      var explicitPage = $(this).attr("data-ao-home-page");
      var href = $(this).attr("href");
      var shouldHandle = !!explicitPage || isHomeTargetHref(href);
      if (!shouldHandle) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      navigateToApexPage(explicitPage || "1");
    });

    $(document).on("click", ".ao-nav", function (event) {
      event.preventDefault();
      event.stopImmediatePropagation();
      var section = $(this).attr("data-section");
      var navKey = $(this).attr("data-nav-key");
      if ($(this).hasClass("is-hidden") || !isNavAllowed(section, navKey)) {
        return;
      }
      var target = String($(this).attr("data-open-screen") || "").trim();
      var agentCreateMode = String($(this).attr("data-agent-create-mode") || "").trim().toLowerCase();
      if (target) {
        if (target === "agent-teams:manage") {
          moveAgentEditorToManage();
        }
        openFreshScreen(target);
      }
      setNav(section, navKey);
      if (section === "vector-indexes") {
        openFreshScreen("vector-indexes:default");
        setVectorIndexAdminCardView("none");
      }
      if (section === "data-sources") {
        if (navKey === "data-sources-catalog") {
          setDataSourceSection("catalog");
          resetCatalogCreateForm();
          setCatalogCardView("list");
        } else {
          setDataSourceSection("connections");
        }
      }
      if (target === "agent-teams:manage") {
        AGENT_BUILDER_MODE = "graphical";
        setAgentCreatePanel(agentCreateMode || "overview");
      } else if (target === "agent-teams:default") {
        setAgentCreatePanel("overview");
      }
    });

    $(document).on("input", "#aoPrebuiltAgentSearch", function() {
      renderPrebuiltAgents();
    });

    $(document).on("change", "#aoPrebuiltAgentFilter", function() {
      renderPrebuiltAgents();
    });

    $(document).on("click", "[data-prebuilt-view]", function(event) {
      event.preventDefault();
      setPrebuiltAgentViewMode($(this).attr("data-prebuilt-view"));
    });

    $(document).on("click", "[data-prebuilt-info]", function(event) {
      event.preventDefault();
      var agent = getPrebuiltAgentById($(this).attr("data-prebuilt-info"));
      openPrebuiltAgentInfo(agent);
    });

    $(document).on("click", "[data-prebuilt-info-close]", function(event) {
      event.preventDefault();
      closePrebuiltAgentInfo();
    });

    $(document).on("click", "[data-prebuilt-grant-close]", function(event) {
      event.preventDefault();
      closePrebuiltGrantDialog();
    });

    $(document).on("click", "#aoPrebuiltGrantCopySql", function(event) {
      event.preventDefault();
      var text = String($("#aoPrebuiltGrantSql").text() || "").trim();
      if (!text) return;
      if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
        navigator.clipboard.writeText(text).then(function() {
          showSuccess("Grant statements copied.");
        }).catch(function() {
          showError("Unable to copy grant statements.");
        });
      } else {
        showError("Clipboard is not available in this browser.");
      }
    });

    $(document).on("click", "#aoPrebuiltGrantContinue", function(event) {
      event.preventDefault();
      var pending = PREBUILT_AGENT_PENDING_GRANT_INSTALL;
      if (!pending) return;
      var agent = getPrebuiltAgentById(pending.agentId);
      var params = $.extend({}, pending.params || {});
      var action = pending.action || "install";
      PREBUILT_AGENT_PENDING_GRANT_INSTALL = null;
      $("#aoPrebuiltGrantDialog").addClass("is-hidden");
      if (agent) executePrebuiltAgentInstall(agent, params, action);
    });

    $(document).on("click", "[data-prebuilt-action]", function(event) {
      event.preventDefault();
      event.stopPropagation();
      if ($(this).prop("disabled")) return;
      var agent = getPrebuiltAgentById($(this).attr("data-agent-id"));
      var action = String($(this).attr("data-prebuilt-action") || "").trim();
      if (!agent) return;
      if (action === "uninstall") {
        confirmPrebuiltAgentUninstall(agent);
        return;
      }
      if (action === "recreate") {
        openPrebuiltAgentDialog(agent, "recreate");
        return;
      }
      if (getPrebuiltSupportWarning(agent)) {
        showError(getPrebuiltSupportWarning(agent));
        return;
      }
      openPrebuiltAgentDialog(agent, action);
    });

    $(document).on("click", "[data-prebuilt-open]", function(event) {
      if ($(event.target).closest("[data-prebuilt-action], .t-Button, .ao-prebuilt-link-btn").length) return;
      var agent = getPrebuiltAgentById($(this).attr("data-prebuilt-open"));
      if (agent) openPrebuiltAgentInfo(agent);
    });

    $(document).on("keydown", "[data-prebuilt-open]", function(event) {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      var agent = getPrebuiltAgentById($(this).attr("data-prebuilt-open"));
      if (agent) openPrebuiltAgentInfo(agent);
    });

    $(document).on("click", "[data-prebuilt-dialog-close]", function(event) {
      event.preventDefault();
      closePrebuiltAgentDialog();
    });

    $(document).on("click", "[data-duplicate-profile-close]", function(event) {
      event.preventDefault();
      closeDuplicateProfileDialog();
    });

    $(document).on("click", "#aoConfirmDuplicateProfile", function(event) {
      var context = DUPLICATE_PROFILE_CONTEXT;
      event.preventDefault();
      if (!context) return;
      duplicateProfile(context.type, context.originalName, $("#aoDuplicateProfileName").val());
    });

    $(document).on("keydown", "#aoDuplicateProfileDialog", function(event) {
      if (event.key === "Escape") {
        event.preventDefault();
        closeDuplicateProfileDialog();
      } else if (event.key === "Enter" && $(event.target).is("input")) {
        event.preventDefault();
        $("#aoConfirmDuplicateProfile").trigger("click");
      }
    });

    $(document).on("click", "#aoPrebuiltAgentRunInstall", function(event) {
      event.preventDefault();
      var agent = getPrebuiltAgentById(PREBUILT_AGENT_DIALOG_AGENT_ID);
      var params = collectPrebuiltDialogParams();
      if (!agent || !params) return;
      runPrebuiltAgentInstall(agent, params, PREBUILT_AGENT_DIALOG_ACTION);
    });

    $(document).on("click", "#aoPrebuiltAgentDropRecreate", function(event) {
      event.preventDefault();
      var agent = getPrebuiltAgentById(PREBUILT_AGENT_DIALOG_AGENT_ID);
      var params = collectPrebuiltDialogParams();
      if (!agent || !params) return;
      PREBUILT_AGENT_DIALOG_ACTION = "recreate";
      runPrebuiltAgentInstall(agent, params, "recreate");
    });

    $(document).on("input change", "#aoPrebuiltAgentDialogFields .js-ao-prebuilt-param", function() {
      applyPrebuiltDialogFlow();
    });

    $(document).on("keydown", "#aoPrebuiltAgentDialog", function(event) {
      if (event.key === "Escape") {
        event.preventDefault();
        closePrebuiltAgentDialog();
      }
      if (event.key === "Enter" && $(event.target).is("input[type='text']")) {
        event.preventDefault();
        $("#aoPrebuiltAgentRunInstall").trigger("click");
      }
    });

    $(document).on("keydown", "#aoPrebuiltInfoDialog, #aoPrebuiltGrantDialog", function(event) {
      if (event.key !== "Escape") return;
      event.preventDefault();
      closePrebuiltAgentInfo();
      closePrebuiltGrantDialog();
    });

    $(document).on("click", "#aoMissionRefresh", function(event) {
      event.preventDefault();
      loadMissionControl(true);
    });

    $(document).on("input change", "#aoMissionAgentFilter, #aoMissionStatusFilter, #aoMissionSearch", function() {
      renderMissionControl();
    });

    $(document).on("click", "[data-mission-view]", function(event) {
      event.preventDefault();
      var mode = String($(this).attr("data-mission-view") || "").trim().toLowerCase();
      MISSION_VIEW_MODE = mode === "list" ? "list" : "board";
      $(".ao-mission-view-btn").removeClass("is-active");
      $(this).addClass("is-active");
      renderMissionControl();
    });

    $(document).on("click", "[data-mission-conv-id]", function(event) {
      event.preventDefault();
      var convId = String($(this).attr("data-mission-conv-id") || "").trim();
      if (!convId) return;
      MISSION_ACTIVE_CONVERSATION_ID = convId;
      renderMissionControl();
    });

    $(document).on("pointerdown", "#aoMissionPaneResizer", startMissionPaneResize);

    $(document).on("mousedown", "#aoMissionPaneResizer", function(event) {
      if (window.PointerEvent) return;
      startMissionPaneResize(event);
    });

    $(document).on("pointermove", function(event) {
      updateMissionPaneResize(event.originalEvent || event);
    });

    $(document).on("mousemove", function(event) {
      if (window.PointerEvent) return;
      updateMissionPaneResize(event.originalEvent || event);
    });

    $(document).on("pointerup pointercancel", stopMissionPaneResize);

    $(document).on("mouseup", function() {
      if (window.PointerEvent) return;
      stopMissionPaneResize();
    });

    $(document).on("keydown", "#aoMissionPaneResizer", function(event) {
      var step = event.shiftKey ? 8 : 3;
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        setMissionPaneSplit(MISSION_LOG_PANE_PCT - step);
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        setMissionPaneSplit(MISSION_LOG_PANE_PCT + step);
      }
    });

    $(document).on("click", "#aoMissionCloseDebug", function(event) {
      event.preventDefault();
      MISSION_ACTIVE_CONVERSATION_ID = "";
      renderMissionControl();
    });

    $(document).on("click", "#aoMissionShowMap", function(event) {
      event.preventDefault();
      if (!MISSION_ACTIVE_CONVERSATION_ID) return;
      renderMissionConversationMap(MISSION_ACTIVE_CONVERSATION_ID);
      $("#aoMissionMapDialog").removeClass("is-hidden");
    });

    $(document).on("click", "#aoMissionMapZoomOut", function(event) {
      event.preventDefault();
      adjustMissionMapZoom(-0.1);
    });

    $(document).on("click", "#aoMissionMapZoomIn", function(event) {
      event.preventDefault();
      adjustMissionMapZoom(0.1);
    });

    $(document).on("click", "[data-mission-tool-detail]", function(event) {
      event.preventDefault();
      event.stopPropagation();
      openMissionToolDetail($(this).attr("data-mission-tool-detail"));
    });

    $(document).on("click", "#aoMissionToolDetailClose", function(event) {
      event.preventDefault();
      closeMissionToolDetail();
    });

    $(document).on("click", "[data-mission-map-close]", function(event) {
      event.preventDefault();
      $("#aoMissionMapDialog").addClass("is-hidden");
      closeMissionToolDetail();
    });

    $(document).on("click", "[data-open-screen]", function (event) {
      event.preventDefault();
      var target = String($(this).attr("data-open-screen") || "").trim();
      var ragMode = String($(this).attr("data-rag-manage-mode") || "").trim().toLowerCase();
      var nl2sqlMode = String($(this).attr("data-nl2sql-manage-mode") || "").trim().toLowerCase();
      var agentCreateMode = String($(this).attr("data-agent-create-mode") || "").trim().toLowerCase();
      if (target === "agent-teams:manage") {
        moveAgentEditorToManage();
      }
      openFreshScreen(target);
      if (target === "rag:manage" && ragMode) {
        setRagAdminCardView(ragMode);
      } else if (target === "rag:default") {
        setRagAdminCardView("none");
      }
      if (target === "vector-indexes:default") {
        setVectorIndexAdminCardView("none");
      }
      if (target === "nl2sql:manage") {
        setNl2sqlAdminCardView(nl2sqlMode || "create");
      } else if (target === "nl2sql:default") {
        setNl2sqlAdminCardView("none");
      }
      if (target === "agent-teams:manage") {
        AGENT_BUILDER_MODE = "graphical";
        setNav("agent-teams", $(this).attr("data-nav-key") || "agent-builder");
        setAgentCreatePanel(agentCreateMode || "overview");
      } else if (target === "agent-teams:default") {
        setNav("agent-teams", "agent-team");
        setAgentCreatePanel("overview");
      }
    });

    $(document).on("click", "[data-agent-create-panel]", function (event) {
      event.preventDefault();
      moveAgentEditorToManage();
      setAgentCreatePanel($(this).attr("data-agent-create-panel"));
    });

    $(document).on("click", "[data-agent-studio-step]", function(event) {
      event.preventDefault();
      setAgentStudioStep($(this).attr("data-agent-studio-step"));
    });

    $(document).on("click", ".ao-builder-mode-btn[data-builder-mode]", function(event) {
      event.preventDefault();
      AGENT_BUILDER_MODE = "graphical";
      applyAgentBuilderModeUi();
    });

    $("#aoNlBuilderSend").on("click", function(event) {
      event.preventDefault();
      sendNlBuilderPrompt();
    });

    $("#aoNlBuilderPrompt").on("keydown", function(event) {
      if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        sendNlBuilderPrompt();
      }
    });

    $("#aoNlBuilderClearSession").on("click", function(event) {
      event.preventDefault();
      resetNlBuilderSession();
    });

    $(document).on("click", ".ao-nl-open-editor-btn[data-nl-history-index]", function(event) {
      event.preventDefault();
      openNlBuilderResponseInEditor($(this).attr("data-nl-history-index"));
    });

    $(document).on("click", ".ao-studio-node[data-studio-node]", function(event) {
      var node = String($(this).attr("data-studio-node") || "").trim().toLowerCase();
      var stepByNode = { team: 1, agent: 2, task: 3, tool: 4 };
      var mappingIndex = Number($(this).attr("data-studio-mapping-index"));
      var mappingKind = String($(this).attr("data-studio-mapping-kind") || "").trim().toLowerCase();
      var mapping;
      var taskName;
      if ($(event.target).is("[data-remove-studio-tool]")) return;
      event.preventDefault();
      if (!Number.isNaN(mappingIndex) && mappingIndex >= 0 && mappingIndex < AGENT_STUDIO_TEAM_MAPPINGS.length) {
        mapping = AGENT_STUDIO_TEAM_MAPPINGS[mappingIndex] || null;
      }
      if (mapping && mappingKind === "agent") {
        $("#aoAgentStudioAgentMode").val("existing");
        ensureSelectOption("#aoAgentStudioExistingAgent", mapping.name);
        $("#aoAgentStudioExistingAgent").val(String(mapping.name || "").trim());
        $("#aoAgentStudioAgentName").val(String(mapping.name || "").trim());
        applyExistingAgentDetailsToStudio(mapping.name);
      }
      if ((mapping && mappingKind === "task") || node === "task") {
        taskName = mapping
          ? String(mapping.task || "").trim()
          : String($(this).attr("data-task-name") || "").trim();
        if (taskName) {
          $("#aoAgentStudioTaskMode").val("existing");
          ensureSelectOption("#aoAgentStudioExistingTask", taskName);
          $("#aoAgentStudioExistingTask").val(taskName);
          $("#aoAgentStudioTaskName").val(taskName);
          $("#aoAgentStudioTaskGoal").val(String(getEntityAttributeValue("TASK", taskName, "instruction") || "").trim());
          $("#aoAgentStudioTaskDescription").val(getEntityDescription("TASK", taskName));
          autoGrowTextareas("#aoAgentStudioTaskGoal");
        }
      }
      if (node === "tool" && $(this).attr("data-tool-name")) {
        $("#aoAgentStudioToolMode").val("existing");
        $("#aoAgentStudioToolSelect").val($(this).attr("data-tool-name"));
      }
      syncAgentStudioModeUi();
      setAgentStudioEditorVisible(true);
      setAgentStudioStep(stepByNode[node] || 1);
    });

    $("#aoAgentStudioNewFlow").on("click", function(event) {
      event.preventDefault();
      resetAgentStudioFlow();
    });

    $("#aoAgentStudioDeleteFlow").on("click", function(event) {
      event.preventDefault();
      resetAgentStudioFlow();
      showSuccess("Draft flow deleted.");
    });

    $("#aoAgentStudioPreviewPlsql").on("click", function(event) {
      event.preventDefault();
      setAgentStudioEditorVisible(true);
      setAgentStudioStep(5);
      renderAgentStudioPlsqlPreview();
      if ($("#aoAgentStudioPlsqlPreview").length && typeof $("#aoAgentStudioPlsqlPreview")[0].scrollIntoView === "function") {
        $("#aoAgentStudioPlsqlPreview")[0].scrollIntoView({ behavior: "smooth", block: "nearest" });
      }
    });

    $("#aoDropAgentTeamMap").on("click", function(event) {
      event.preventDefault();
      dropSelectedAgentTeam(this);
    });

    $("#aoEditAgentTeamInBuilder").on("click", function(event) {
      event.preventDefault();
      openCurrentTeamInAgentBuilder();
    });

    $("#aoPreviewAgentTeamPlsql").on("click", function(event) {
      event.preventDefault();
      openAgentTeamPlsqlDialog();
    });

    $("#aoCopyAgentTeamPlsql").on("click", function(event) {
      event.preventDefault();
      copyElementTextById("aoAgentTeamPlsqlCode");
    });

    $(document).on("click", "[data-agent-team-plsql-close]", function(event) {
      event.preventDefault();
      closeAgentTeamPlsqlDialog();
    });

    $("#aoAgentStudioZoomOut").on("click", function(event) {
      event.preventDefault();
      adjustAgentStudioZoom(-0.1);
    });

    $("#aoAgentStudioZoomIn").on("click", function(event) {
      event.preventDefault();
      adjustAgentStudioZoom(0.1);
    });

    $("#aoAgentStudioCanvas").on("wheel", function() {
      /* Wheel zoom intentionally disabled: use explicit + / - controls only. */
    });

    $("#aoAgentStudioExpandCanvas").on("click", function(event) {
      event.preventDefault();
      toggleAgentStudioExpanded();
    });

    $("#aoAgentStudioPrev").on("click", function(event) {
      event.preventDefault();
      setAgentStudioStep(AGENT_STUDIO_STEP - 1);
    });

    $("#aoAgentStudioNext").on("click", function(event) {
      event.preventDefault();
      if (AGENT_STUDIO_STEP >= 5) {
        saveAgentStudioFlow();
        return;
      }
      setAgentStudioStep(AGENT_STUDIO_STEP + 1);
    });

    $("#aoAgentStudioTaskName, #aoAgentStudioTaskGoal, #aoAgentStudioAgentName, #aoAgentStudioProfile, #aoAgentStudioTeamName, #aoAgentStudioExistingAgent, #aoAgentStudioExistingTask").on("input change", function() {
      if (this.id === "aoAgentStudioTaskGoal") {
        autoGrowTextarea(this);
      }
      syncAgentStudioModeUi();
      updateAgentStudioCanvas();
      renderAgentStudioReview();
    });

    $("#aoAgentStudioRole, #aoAgentStudioTaskDescription, #aoAgentStudioGuardrails, #aoAgentStudioTeamName, #aoAgentStudioHumanTool").on("input change", renderAgentStudioReview);

    $("#aoAgentStudioAgentMode, #aoAgentStudioTaskMode, #aoAgentStudioToolMode").on("change", function() {
      syncAgentStudioModeUi();
      updateAgentStudioCanvas();
      renderAgentStudioReview();
    });

    $(document).on("input", "[data-ao-name-field]", function() {
      clearFieldError(this);
    });

    $(document).on("input change", ".ao-input", function() {
      clearFieldError(this);
    });

    $("#aoAgentCreateTaskToolFilter, #aoAgentEditToolFilter").on("input", refreshToolFilteredSelects);

    $("#aoAgentTeamMapSearch").on("input", applyAgentTeamMapSearch);
    $("#aoAgentTeamMapSearchClear").on("click", function(event) {
      event.preventDefault();
      $("#aoAgentTeamMapSearch").val("");
      applyAgentTeamMapSearch();
    });

    $(document).on("input", ".ao-object-picker-search", function() {
      if (!isObjectPickerEditableForContext($(this))) return;
      renderObjectPicker($(this).closest(".ao-object-picker"));
    });

    $(document).on("change", ".ao-object-picker-type", function() {
      if (!isObjectPickerEditableForContext($(this))) return;
      renderObjectPicker($(this).closest(".ao-object-picker"));
    });

    $(document).on("mousedown", ".ao-object-picker-select option", function(event) {
      var $option = $(this);
      var $select = $option.parent();
      var preSelectedValues = ($select.val() || []).map(String);
      if (!isObjectPickerEditableForContext($select)) {
        event.preventDefault();
        return;
      }
      $select.data("aoPrevSelected", preSelectedValues);
      event.preventDefault();
      $option.prop("selected", !$option.prop("selected"));
      $select.trigger("change");
    });

    $(document).on("mousemove", ".ao-object-picker-select option", function(event) {
      if (!isObjectPickerEditableForContext($(this).parent())) {
        event.preventDefault();
        return;
      }
      event.preventDefault();
    });

    $(document).on("change", ".ao-object-picker-select", function(event) {
      var $selectEl = $(this);
      var $picker = $selectEl.closest(".ao-object-picker");
      var targetId = String($picker.attr("data-object-picker-target") || "");
      var typeFilter = String($picker.find(".ao-object-picker-type").val() || "").trim().toUpperCase();
      var selectedValues = ($selectEl.val() || []).map(String);
      var existingValues = [];
      var prevSelectedValues = ($selectEl.data("aoPrevSelected") || []).map(String);
      var visibleOptions = $selectEl.find("option").map(function() { return String(this.value || "").trim().toUpperCase(); }).get();
      var selectedMap = {};
      var explicitDeselectedMap = {};
      try {
        existingValues = objectListTextToNames($("#" + targetId).val());
      } catch (e) {
        existingValues = String($("#" + targetId).val() || "")
          .split(/\r?\n/)
          .map(function(line) { return String(line || "").trim(); })
          .filter(function(line) { return !!line && line !== "."; })
          .map(function(line) { return line.replace(/\.$/, ""); })
          .filter(Boolean);
      }
      if (!isObjectPickerEditableForContext($(this))) {
        event.preventDefault();
        renderObjectPicker($picker);
        return;
      }
      if (typeFilter === "CATALOG") {
        var catalogName = String(selectedValues.length ? selectedValues[selectedValues.length - 1] : "").trim();
        var schemaOwner = String(
          (LAST_BOOTSTRAP_DATA && (LAST_BOOTSTRAP_DATA.schema_owner || LAST_BOOTSTRAP_DATA.app_schema || LAST_BOOTSTRAP_DATA.appSchema)) || ""
        ).trim();
        var catalogViews = [];
        var catalogNameSet = {};
        var mergedSeen = {};
        var merged = [];
        if (!catalogName) {
          renderObjectPicker($picker);
          return;
        }
        (CATALOG_HISTORY_ROWS || []).forEach(function(row) {
          var cName = String((row && row.catalog_name) || "").trim();
          if (!cName) return;
          catalogNameSet[cName.toUpperCase()] = true;
        });
        (CATALOG_HISTORY_ROWS || []).forEach(function(row) {
          if (String((row && row.catalog_name) || "").trim().toUpperCase() !== catalogName.toUpperCase()) return;
          var viewName = String((row && row.view_name) || "").trim();
          if (!viewName) return;
          catalogViews.push(schemaOwner ? (schemaOwner + "." + viewName) : viewName);
        });
        existingValues.concat(catalogViews).forEach(function(name) {
          var value = String(name || "").trim();
          var key = value.toUpperCase();
          if (catalogNameSet[key]) return;
          if (key.indexOf("CATALOG - ") === 0) return;
          if (!value || mergedSeen[key]) return;
          mergedSeen[key] = true;
          merged.push(value);
        });
        $selectEl.val([]);
        $selectEl.removeData("aoPrevSelected");
        setObjectListText(targetId, merged);
        renderObjectPicker($picker);
        syncAttrDirtyState(String($picker.closest("[data-profile-type]").attr("data-profile-type") || "").trim().toUpperCase());
        if (catalogViews.length) {
          showSuccess("Added all views from data collection: " + catalogName);
        } else {
          showError("No views found for data collection: " + catalogName);
        }
        return;
      }
      selectedValues.forEach(function(name) {
        selectedMap[String(name || "").trim().toUpperCase()] = true;
      });
      prevSelectedValues.forEach(function(name) {
        var key = String(name || "").trim().toUpperCase();
        if (!key) return;
        if (visibleOptions.indexOf(key) < 0) return;
        if (selectedMap[key]) return;
        explicitDeselectedMap[key] = true;
      });
      existingValues.forEach(function(name) {
        var key = String(name || "").trim().toUpperCase();
        if (!key || selectedMap[key] || explicitDeselectedMap[key]) return;
        selectedValues.push(name);
        selectedMap[key] = true;
      });
      setObjectListText(targetId, selectedValues);
      $selectEl.removeData("aoPrevSelected");
      renderObjectPicker($picker);
      syncAttrDirtyState(String($picker.closest("[data-profile-type]").attr("data-profile-type") || "").trim().toUpperCase());
    });

    $(document).on("input", ".ao-object-list-manual", function() {
      if (!isObjectPickerEditableForContext($(this))) return;
      refreshObjectPickers();
      syncAttrDirtyState(String($(this).closest("[data-profile-type]").attr("data-profile-type") || "").trim().toUpperCase());
    });

    $(document).on("input change", "#aoNl2sqlAttrs .js-ao-attr-val, #aoRagAttrs .js-ao-attr-val", function() {
      var $container = $(this).closest("[data-profile-type]");
      var profileType = String($container.attr("data-profile-type") || "").trim().toUpperCase();
      if ($(this).hasClass("js-ao-provider-field")) {
        refreshProfileModelDatalists(profileType);
        applyProfileProviderVisibility(profileType);
      }
      if ($(this).hasClass("ao-object-list-manual")) {
        refreshObjectPickers();
      }
      syncAttrDirtyState(profileType);
    });

    $(document).on("click", "[data-remove-object]", function(event) {
      var $picker = $(this).closest(".ao-object-picker");
      var targetId = String($picker.attr("data-object-picker-target") || "");
      var removeName = String($(this).attr("data-remove-object") || "").trim().toUpperCase();
      var names = [];
      if (!isObjectPickerEditableForContext($(this))) {
        event.preventDefault();
        return;
      }
      event.preventDefault();
      try {
        names = objectListTextToNames($("#" + targetId).val());
      } catch (e) {
        names = [];
      }
      setObjectListText(targetId, names.filter(function(name) {
        return String(name || "").trim().toUpperCase() !== removeName;
      }));
      renderObjectPicker($picker);
      syncAttrDirtyState(String($picker.closest("[data-profile-type]").attr("data-profile-type") || "").trim().toUpperCase());
    });

    if ($("#aoAgentStudioToolSearch").length) {
      $("#aoAgentStudioToolSearch").on("input", renderAgentStudioToolList);
    }

    $(document).on("click", ".ao-builder-palette-card[data-studio-block]", function(event) {
      var block = String($(this).attr("data-studio-block") || "").trim().toLowerCase();
      var stepByBlock = { team: 1, agent: 2, task: 3, tool: 4 };
      event.preventDefault();
      setAgentStudioEditorVisible(true);
      setAgentStudioStep(stepByBlock[block] || 1);
    });

    $(document).on("dragstart", ".ao-builder-palette-card[data-studio-block]", function(event) {
      var originalEvent = event.originalEvent;
      if (originalEvent && originalEvent.dataTransfer) {
        originalEvent.dataTransfer.setData("application/x-ao-builder-block", $(this).attr("data-studio-block"));
        originalEvent.dataTransfer.effectAllowed = "copy";
      }
    });

    $(document).on("dragstart", ".ao-studio-node[data-studio-node], .ao-studio-tool-group[data-studio-node='tool-group']", function(event) {
      var originalEvent = event.originalEvent;
      if (originalEvent && originalEvent.dataTransfer) {
        originalEvent.dataTransfer.setData("application/x-ao-existing-node", $(this).attr("data-studio-node"));
        originalEvent.dataTransfer.setData("application/x-ao-existing-node-uid", $(this).attr("data-studio-node-uid") || "");
        originalEvent.dataTransfer.setData("application/x-ao-existing-tool-name", $(this).attr("data-tool-name") || "");
        originalEvent.dataTransfer.effectAllowed = "move";
      }
    });

    $(document).on("click", ".ao-studio-component-card[data-studio-tool]", function(event) {
      event.preventDefault();
      addAgentStudioTool($(this).attr("data-studio-tool"), $("#aoAgentStudioToolTaskSelect").val());
    });

    $(document).on("dragstart", ".ao-studio-component-card[data-studio-tool]", function(event) {
      var originalEvent = event.originalEvent;
      if (originalEvent && originalEvent.dataTransfer) {
        originalEvent.dataTransfer.setData("text/plain", $(this).attr("data-studio-tool"));
        originalEvent.dataTransfer.effectAllowed = "copy";
      }
    });

    $("#aoAgentStudioCanvas").on("dragover", function(event) {
      event.preventDefault();
      $(this).addClass("is-drag-over");
    }).on("dragleave drop", function(event) {
      var originalEvent = event.originalEvent;
      var block = "";
      var nodeUid = "";
      event.preventDefault();
      $(this).removeClass("is-drag-over");
      if (event.type !== "drop") return;
      if (originalEvent && originalEvent.dataTransfer) {
        block = String(originalEvent.dataTransfer.getData("application/x-ao-builder-block") || "").trim().toLowerCase();
        if (!block) {
          block = String(originalEvent.dataTransfer.getData("application/x-ao-existing-node") || "").trim().toLowerCase();
          nodeUid = String(originalEvent.dataTransfer.getData("application/x-ao-existing-node-uid") || "").trim();
        }
      }
      if (block) {
        setAgentStudioEditorVisible(true);
        setAgentStudioStep({ team: 1, agent: 2, task: 3, tool: 4, "tool-group": 4 }[block] || 1);
        if (nodeUid) {
          placeAgentStudioNode(block, originalEvent, nodeUid);
          return;
        }
        if (block === "tool") {
          if ($("#aoAgentStudioToolMode").val() === "new") {
            createAndConnectAgentStudioToolDraft();
          } else if ($("#aoAgentStudioToolSelect").val()) {
            addAgentStudioTool($("#aoAgentStudioToolSelect").val(), $("#aoAgentStudioToolTaskSelect").val());
          } else {
            showError("Choose a tool before dropping the Tool block.");
          }
        } else {
          placeAgentStudioNode(block, originalEvent, nodeUid);
        }
        return;
      }
      addAgentStudioTool(
        originalEvent && originalEvent.dataTransfer ? originalEvent.dataTransfer.getData("text/plain") : "",
        $("#aoAgentStudioToolTaskSelect").val()
      );
    }).on("scroll", drawAgentStudioLinks).on("click", function(event) {
      var $target = $(event.target);
      if ($target.closest(".ao-studio-node[data-studio-node]").length) return;
      if ($target.closest(".ao-studio-tool-group").length) return;
      setAgentStudioEditorVisible(false);
    });

    $(document).on("click", "[data-toggle-tool-group]", function(event) {
      var taskKey;
      event.preventDefault();
      event.stopPropagation();
      taskKey = String($(this).attr("data-toggle-tool-group") || "").trim().toUpperCase();
      if (!taskKey) return;
      AGENT_STUDIO_TOOL_GROUP_COLLAPSED[taskKey] = !AGENT_STUDIO_TOOL_GROUP_COLLAPSED[taskKey];
      updateAgentStudioCanvas();
    });

    $("#aoAgentStudioAddTool").on("click", function(event) {
      event.preventDefault();
      addAgentStudioTool($("#aoAgentStudioToolSelect").val(), $("#aoAgentStudioToolTaskSelect").val());
    });

    $("#aoAgentStudioCreateToolDraft").on("click", function(event) {
      event.preventDefault();
      createAndConnectAgentStudioToolDraft();
    });

    $("#aoAgentStudioAddTeamMapping").on("click", function(event) {
      event.preventDefault();
      addAgentStudioTeamMapping();
    });

    $(document).on("click", "[data-remove-studio-tool]", function(event) {
      event.preventDefault();
      event.stopPropagation();
      removeAgentStudioTool($(this).attr("data-remove-studio-tool"), $(this).attr("data-remove-studio-tool-task"));
    });

    $(document).on("click", "[data-remove-studio-mapping]", function(event) {
      event.preventDefault();
      removeAgentStudioTeamMapping($(this).attr("data-remove-studio-mapping"));
    });

    $("#aoAgentStudioValidate").on("click", function(event) {
      event.preventDefault();
      setAgentStudioEditorVisible(true);
      setAgentStudioStep(5);
      renderAgentStudioValidation();
    });

    $("#aoSaveAgentStudioFlow").on("click", function(event) {
      event.preventDefault();
      saveAgentStudioFlow();
    });

    $(document).on("click", ".ao-admin-tab[data-admin-section]", function () {
      setAdminSection($(this).attr("data-admin-section"));
    });

    $(document).on("click", ".ao-admin-tab[data-ds-section]", function () {
      setDataSourceSection($(this).attr("data-ds-section"));
    });

    $("#aoShowNl2sqlCreate").on("click", function () {
      setNl2sqlAdminCardView("create");
    });

    $("#aoCancelCreateNl2sqlProfile").on("click", function () {
      setNl2sqlAdminCardView("none");
    });

    $("#aoShowNl2sqlDrop").on("click", function () {
      setNl2sqlAdminCardView("drop");
    });

    $("#aoShowRagProfileCreate").on("click", function () {
      setRagAdminCardView("profile-create");
    });

    $("#aoCancelCreateRagProfile").on("click", function () {
      setRagAdminCardView("none");
    });

    $("#aoShowRagProfileDrop").on("click", function () {
      setRagAdminCardView("profile-drop");
    });

    // Database-link refresh is temporarily disabled.
    // $("#aoRefreshDbLinks").on("click", refreshDbLinks);
    $("#aoOpenDbLinkCreate").on("click", function() { setDbLinkCardView("create"); });
    $("#aoBackToDbLinks").on("click", function() { setDbLinkCardView("list"); });
    $("#aoCancelDbLinkCreate").on("click", function() { setDbLinkCardView("list"); });
    $("#aoDbLinkCategoryFilter").on("change", renderDbLinkList);
    $("#aoCreateDbLink").on("click", createDbLink);
    $("#aoAddDbGatewayParam").on("click", function() { addDbGatewayParamRow("", ""); });
    $(document).on("click", "[data-remove-gw-param]", function() {
      $(this).closest(".ao-dblink-gateway-row").remove();
    });
    $("#aoOpenCatalogCreate").on("click", function() {
      resetCatalogCreateForm();
      setCatalogCardView("create");
    });
    $("#aoBackToCatalogList").on("click", function() { setCatalogCardView("list"); });
    $("#aoCancelCatalogCreate").on("click", function() { setCatalogCardView("list"); });
    $("#aoLoadCatalogTables").on("click", loadDbLinkTables);
    $("#aoCreateCatalogViews").on("click", createCatalogViews);
    $("#aoCatalogProfileLinkAdd").on("click", addCatalogToAiProfile);
    $(document).on("click", "[data-catalog-profile-link-close]", function(event) {
      event.preventDefault();
      closeCatalogProfileLinkDialog();
    });
    $(document).on("click", "[data-catalog-profile-option]", function(event) {
      event.preventDefault();
      var profileName = String($(this).attr("data-catalog-profile-option") || "").trim();
      if (!profileName) return;
      ACTIVE_CATALOG_PROFILE_LINK.profileName = profileName;
      $("#aoCatalogProfileList [data-catalog-profile-option]").removeClass("is-active");
      $(this).addClass("is-active");
      $("#aoCatalogProfileLinkAdd").prop("disabled", false);
    });
    $(document).on("click", "#aoCatalogProfileLinkDialog .ao-prebuilt-dialog__card", function(event) {
      event.stopPropagation();
    });
    $(document).on("click", "#aoCatalogProfileLinkDialog .ao-prebuilt-dialog__backdrop", function() {
      closeCatalogProfileLinkDialog();
    });
    $(document).on("click", "#aoCatalogProfileLinkDialog", function() {
      closeCatalogProfileLinkDialog();
    });
    $(document).on("keydown", function(event) {
      if (event.key === "Escape" && !$("#aoCatalogProfileLinkDialog").hasClass("is-hidden")) {
        closeCatalogProfileLinkDialog();
      }
    });
    $(document).on("click", "[data-add-catalog-to-profile]", function(event) {
      event.preventDefault();
      event.stopPropagation();
      $("[data-catalog-menu]").removeClass("is-open");
      openCatalogProfileLinkDialog($(this).attr("data-add-catalog-to-profile"));
    });
    $(document).on("click", "[data-drop-catalog]", function() {
      dropCatalogByName($(this).attr("data-drop-catalog"));
    });
    $(document).on("click", "[data-open-catalog]", function(event) {
      event.preventDefault();
      var catalogName = String($(this).attr("data-open-catalog") || "").trim();
      if (!catalogName) return;
      if (ACTIVE_CATALOG_DETAILS === catalogName.toUpperCase()) {
        $("#aoCatalogDetails").hide().html("");
        ACTIVE_CATALOG_DETAILS = "";
        return;
      }
      renderCatalogDetails(catalogName);
    });
    $(document).on("click", "[data-drop-dblink]", function() {
      dropDbLink($(this).attr("data-drop-dblink"));
    });
    $(document).on("click", "[data-catalog-menu-trigger]", function(event) {
      event.preventDefault();
      event.stopPropagation();
      var key = String($(this).attr("data-catalog-menu-trigger") || "").trim();
      if (!key) return;
      var selector = "[data-catalog-menu='" + key.replace(/'/g, "\\'") + "']";
      var $menu = $(selector).first();
      var willOpen = !$menu.hasClass("is-open");
      $("[data-catalog-menu]").removeClass("is-open");
      if (willOpen) $menu.addClass("is-open");
    });
    $(document).on("click", function() {
      $("[data-catalog-menu]").removeClass("is-open");
    });
    $(document).on("click", "[data-dblink-menu-trigger]", function(event) {
      event.preventDefault();
      event.stopPropagation();
      var key = String($(this).attr("data-dblink-menu-trigger") || "").trim();
      if (!key) return;
      var selector = "[data-dblink-menu='" + key.replace(/'/g, "\\'") + "']";
      var $menu = $(selector).first();
      var willOpen = !$menu.hasClass("is-open");
      $("[data-dblink-menu]").removeClass("is-open");
      if (willOpen) $menu.addClass("is-open");
    });
    $(document).on("click", function() {
      $("[data-dblink-menu]").removeClass("is-open");
    });
    $(document).on("click", ".ao-row-menu", function(event) {
      event.stopPropagation();
    });

    $(document).on("click", "[data-copy-target]", function () {
      copyElementTextById($(this).attr("data-copy-target"));
    });

    $(document).on("click", "[data-copy-summary-value]", function () {
      copyTextToClipboard($(this).attr("data-copy-summary-value"));
    });

    $("#aoNl2sqlSelect").on("change", function () {
      var v = $(this).val();
      apex.item("P20000_SERVICE").setValue(v);
      persistUiSyncState({ selected_nl2sql_profile: String(v || "").trim() });
      if (!v) {
        setAttrEditMode("NL2SQL", false);
        renderAttrs("#aoNl2sqlAttrs", []);
        syncAttrEditUi("NL2SQL");
        return;
      }
      loadAttrs("NL2SQL");
    });

    $("#aoRagSelect").on("change", function () {
      var v = $(this).val();
      apex.item("P20000_RAGSERVICE").setValue(v);
      persistUiSyncState({ selected_rag_profile: String(v || "").trim() });
      if (v) $("#aoDropRagSelect").val(v);
      if (!v) {
        setAttrEditMode("RAG", false);
        renderAttrs("#aoRagAttrs", []);
        syncAttrEditUi("RAG");
        return;
      }
      loadAttrs("RAG");
    });

    $("#aoVectorIndexSelect").on("change", renderVectorIndexSummary);

    $("#aoOpenVectorIndexCreate").on("click", function() {
      setNav("vector-indexes", "vector-indexes");
      openFreshScreen("vector-indexes:manage");
      setVectorIndexAdminCardView("create");
    });

    $("#aoShowVectorIndexCreate").on("click", function() {
      setVectorIndexAdminCardView("create");
    });

    $("#aoShowVectorIndexDrop").on("click", function() {
      setVectorIndexAdminCardView("drop");
    });

    $("#aoCreateVectorIndexFromRag").on("click", function() {
      var requestedIndexName = String($("#aoRagCreateVectorIndex").val() || "").trim();
      setNav("vector-indexes", "vector-indexes");
      openFreshScreen("vector-indexes:manage");
      setVectorIndexAdminCardView("create");
      if (requestedIndexName) $("#aoRagVectorIndexName").val(requestedIndexName);
    });

    $("#aoAgentTeamPicker").off("input").on("input", function () {
      armAgentSelectSubmitBlock();
      var v = $(this).val();
      resetDropAgentTeamConfirm();
      $("#aoAgentInlineEditorHost").addClass("is-hidden");
      if (!v) {
        $("#aoAgentTeamDesc").val("");
        clearAgentTeamBoxes();
        return;
      }
      loadAgentTeamDetails(v);
    });

    $("#aoAgentFilterSelect").off("input").on("input", function () {
      armAgentSelectSubmitBlock();
      renderAgentTeamDetailsByAgent($(this).val());
    });

    $(document).on("click keydown", ".ao-team-node[data-map-type]", function (event) {
      if (event.type === "keydown" && event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      handleAgentTeamMapClick(this);
    });

    $(document).on("mouseenter", "#aoAgentTeamMap .ao-team-node[data-map-type]", function() {
      $("#aoAgentTeamMap").addClass("is-node-hover");
    });
    $(document).on("mouseleave", "#aoAgentTeamMap .ao-team-node[data-map-type]", function() {
      $("#aoAgentTeamMap").removeClass("is-node-hover");
    });

    $(document).on("click keydown", ".ao-map-edit[data-map-edit-type]", function (event) {
      if (event.type === "keydown" && event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      event.stopPropagation();
      if (!CAN_MANAGE_SETTINGS) return;
      openAgentEditorForMapNode($(this).attr("data-map-edit-type"), $(this).attr("data-map-edit-name"));
    });

    $("#aoCloseInlineAgentEditor").on("click", function () {
      $("#aoAgentInlineEditorHost").addClass("is-hidden");
    });

    $(document).on("click", "#aoTeamMapZoomOut", function () {
      adjustTeamMapZoom(-0.1);
    });

    $(document).on("click", "#aoTeamMapZoomIn", function () {
      adjustTeamMapZoom(0.1);
    });

    $(document).on("click", "#aoTeamMapFitView", function () {
      fitAgentTeamMapView();
    });

    $(document).on("click", "#aoTeamMapOrientationToggle", function () {
      TEAM_MAP_ORIENTATION = TEAM_MAP_ORIENTATION === "vertical" ? "horizontal" : "vertical";
      renderAgentTeamMap();
    });

    $(document).on("click", "#aoTeamMapExpandCanvas", function(event) {
      event.preventDefault();
      toggleTeamMapExpanded();
    });

    $("#aoMapNodeDrawerClose, #aoMapNodeDrawerOverlay").on("click", function () {
      closeMapNodeDrawer();
    });

    $(document).on("keydown", function(event) {
      if (event.key === "Escape") closeMapNodeDrawer();
    });

    $("#aoAgentTeamMap").on("wheel", function() {
      /* Mouse-wheel zoom disabled for Team Map. Use zoom buttons only. */
    });

    $("#aoAgentTeamMap").on("mousedown", function(event) {
      var map = this;
      if (event.which !== 1) return;
      if ($(event.target).closest(".ao-team-node, .ao-map-edit, .ao-map-drawer").length) return;
      TEAM_MAP_DRAGGING = true;
      TEAM_MAP_DRAG_START_X = event.pageX;
      TEAM_MAP_DRAG_START_Y = event.pageY;
      TEAM_MAP_DRAG_SCROLL_LEFT = map.scrollLeft;
      TEAM_MAP_DRAG_SCROLL_TOP = map.scrollTop;
      $(map).addClass("is-dragging");
      event.preventDefault();
    });

    $(document).on("mousemove", function(event) {
      var map = $("#aoAgentTeamMap")[0];
      if (!TEAM_MAP_DRAGGING || !map) return;
      map.scrollLeft = TEAM_MAP_DRAG_SCROLL_LEFT - (event.pageX - TEAM_MAP_DRAG_START_X);
      map.scrollTop = TEAM_MAP_DRAG_SCROLL_TOP - (event.pageY - TEAM_MAP_DRAG_START_Y);
    });

    $(document).on("mouseup", function() {
      TEAM_MAP_DRAGGING = false;
      $("#aoAgentTeamMap").removeClass("is-dragging");
    });

    $(window).off("resize.aoTeamMap").on("resize.aoTeamMap", function () {
      window.requestAnimationFrame(function() {
        drawAgentTeamMapLinks();
        centerAgentTeamMapView();
      });
    });

    $("#aoEditNl2sqlAttrs").on("click", function () {
      setAttrEditMode("NL2SQL", true);
    });

    $("#aoCancelNl2sqlAttrs").on("click", function () {
      cancelAttrEdits("NL2SQL");
    });

    $("#aoEditRagAttrs").on("click", function () {
      setAttrEditMode("RAG", true);
    });

    $("#aoCancelRagAttrs").on("click", function () {
      cancelAttrEdits("RAG");
    });

    $("#aoCancelNl2sqlAttrsBottom").on("click", function () {
      cancelAttrEdits("NL2SQL");
    });

    $("#aoCancelRagAttrsBottom").on("click", function () {
      cancelAttrEdits("RAG");
    });

    $("#aoAgentEditEntityType").on("change", refreshAgentEntityOptions);
    $("#aoAgentEditEntityName").on("change", populateAgentEntityEditor);

    $("#aoSaveNl2sqlAll, #aoSaveNl2sqlAllTop").on("click", function () {
      saveAttrs("NL2SQL", "#aoNl2sqlAttrs");
    });

    $("#aoSaveRagAll, #aoSaveRagAllTop").on("click", function () {
      saveAttrs("RAG", "#aoRagAttrs");
    });

    $("#aoCreateNl2sqlProfile").on("click", createNl2sqlProfile);
    $("#aoCreateRagProfile").on("click", createRagProfile);
    $("#aoDuplicateNl2sqlProfile").on("click", function() {
      openDuplicateProfileDialog("NL2SQL");
    });
    $("#aoDuplicateRagProfile").on("click", function() {
      openDuplicateProfileDialog("RAG");
    });
    $("#aoCreateRagVectorIndex").on("click", createRagVectorIndex);
    $("#aoDropRagProfile").on("click", dropRagProfile);
    $("#aoDropRagVectorIndex").on("click", dropRagVectorIndex);
    $("#aoCreateAgentTool").on("click", function() {
      createAgentEntity(buildAgentCreateToolPayload, "task");
    });
    $("#aoCreateAgentTask").on("click", function() {
      createAgentEntity(buildAgentCreateTaskPayload, "agent");
    });
    $("#aoCreateAgentAgent").on("click", function() {
      createAgentEntity(buildAgentCreateAgentPayload, "team");
    });
    $("#aoCreateAgentTeam").on("click", function() {
      createAgentEntity(buildAgentCreateTeamPayload, "overview");
    });
    $("#aoAddTeamMapping").on("click", addTeamCreateMapping);
    $("#aoAddEditTeamMapping").on("click", addTeamEditMapping);
    $(document).on("click", ".ao-remove-edit-team-mapping", function() {
      var removeIndex = Number($(this).attr("data-index"));
      var mappings = parseAgentMappingsForSave($("#aoAgentEditTeamAgents").val()).filter(function(item, index) {
        return index !== removeIndex;
      });
      setEditTeamMappings(mappings);
    });
    $("#aoSaveAgentEntity").on("click", saveAgentEntity);

    $("#aoToggleOpenEditor").on("change", function () {
      saveAdminWithFallback("SHOW_OPEN_IN_EDITOR", this.checked ? "N" : "Y");
    });

    $("#aoToggleAgentThoughts").on("change", function () {
      saveAdminWithFallback("SHOW_AGENT_THOUGHTS", this.checked ? "N" : "Y");
    });

    $("#aoToggleExportPdf").on("change", function () {
      saveAdminWithFallback("SHOW_EXPORT_PDF", this.checked ? "N" : "Y");
    });

    $("#aoToggleExportExcel").on("change", function () {
      saveAdminWithFallback("SHOW_EXPORT_EXCEL", this.checked ? "N" : "Y");
    });

    $("#aoToggleConversationTimer").on("change", function () {
      saveAdminWithFallback("SHOW_CONVERSATION_TIMER", this.checked ? "N" : "Y");
    });

    $("#aoToggleDeletePrompt").on("change", function () {
      saveAdminWithFallback("SHOW_DELETE_PROMPT", this.checked ? "N" : "Y");
    });

    $("#aoToggleEndUserConvStyle").on("change", function () {
      saveAdminWithFallback("ENABLE_END_USER_SWITCH_CONV_STYLE", this.checked ? "N" : "Y");
    });

    $("#aoToggleEndUserProfilesAgents").on("change", function () {
      saveAdminWithFallback("ENABLE_END_USER_SWITCH_PROFILES_AGENTS", this.checked ? "N" : "Y");
    });

    $("#aoToggleEndUserNl2sqlProfile").on("change", function () {
      saveAdminWithFallback("ENABLE_END_USER_SWITCH_NL2SQL_PROFILE", this.checked ? "N" : "Y");
    });

    $("#aoToggleEndUserRagProfile").on("change", function () {
      saveAdminWithFallback("ENABLE_END_USER_SWITCH_RAG_PROFILE", this.checked ? "N" : "Y");
    });

    $("#aoAppZoomInput").on("input", function () {
      var pct = setZoomSliderValue(this.value);
      applyAppZoomPreview(pct);
    });

    $("#aoAppZoomInput").on("change", function () {
      var pct = setZoomSliderValue(this.value);
      applyAppZoomPreview(pct);
      saveAdmin("APP_ZOOM_PCT", String(pct));
    });

    $("#aoAppZoomDecrease").on("click", function () {
      var current = setZoomSliderValue($("#aoAppZoomInput").val());
      var next = setZoomSliderValue(current - APP_ZOOM_STEP);
      applyAppZoomPreview(next);
      saveAdmin("APP_ZOOM_PCT", String(next));
    });

    $("#aoAppZoomIncrease").on("click", function () {
      var current = setZoomSliderValue($("#aoAppZoomInput").val());
      var next = setZoomSliderValue(current + APP_ZOOM_STEP);
      applyAppZoomPreview(next);
      saveAdmin("APP_ZOOM_PCT", String(next));
    });

    $("#aoCreateProvider").on("change", applyProviderRules);
    $("#aoRagCreateProvider").on("change", applyRagProviderRules);
    $("#aoCreateModel, #aoCreateEmbeddingModel").on("input focus", function() {
      var prefix = this.id.indexOf("aoRagCreate") === 0 ? "aoRagCreate" : "aoCreate";
      updateCreateModelList("#" + this.id, $("#" + prefix + "Provider").val());
    });

    $("#aoSaveConvMode").on("click", saveConversationMode);
    $("#aoSaveRoleAccess").on("click", saveRoleAccessControls);
    $("#aoSaveUiSettings").on("click", saveUiSettings);

    $("#aoConvModeSelect").on("change", function () {
      var v = String($(this).val() || "").trim().toUpperCase();
      if (!v) return;
      persistUiSyncState({ default_conversation_mode: v });
    });

    window.addEventListener("storage", function(event) {
      if (!event || event.key !== ASK_ORACLE_UI_SYNC_KEY) return;
      syncConvModeSelectFromUiSync();
    });
    window.addEventListener("askoracleuisyncchange", function() {
      syncConvModeSelectFromUiSync();
    });

    $("#aoRetentionDays").on("change", function () {
      $(this).val(normalizeRetentionDays($(this).val()));
    });

    $("#aoDropNl2sqlProfile").on("click", dropNl2sqlProfile);

    $("#aoThemeModeSelect").on("change", applyTheme);
  }

  function collapseOuterSettingsRegionChrome() {
    var root = document.getElementById("aoSettings");
    if (!root || typeof root.closest !== "function") {
      return;
    }

    var hostRegion = root.closest(".t-Region, .a-Region");
    if (!hostRegion || !hostRegion.classList) {
      return;
    }

    hostRegion.classList.add("ao-settings-host-region");
  }

  function stretchOuterSettingsDialogLayout() {
    var root = document.getElementById("aoSettings");
    if (!root || typeof root.closest !== "function") {
      return;
    }

    [
      ".ui-dialog-content",
      ".t-Dialog-body",
      ".a-Dialog-body",
      ".t-DialogRegion-body",
      ".t-Region-bodyWrap",
      ".t-Region-body",
      ".a-Region-body",
      ".a-Region-content"
    ].forEach(function(selector) {
      var node = root.closest(selector);
      if (node && node.classList) {
        node.classList.add("ao-settings-host-fill");
      }
    });
  }

  function markSettingsDialogPage() {
    try {
      var root = document.getElementById("aoSettings");
      if (document.documentElement && document.documentElement.classList) {
        document.documentElement.classList.add("ao-settings-dialog-page");
      }
      if (document.body && document.body.classList) {
        document.body.classList.add("ao-settings-dialog-page");
      }
      if (root) {
        var form = root.closest("form");
        if (form && form.classList) {
          form.classList.add("ao-settings-dialog-page-form");
        }
      }
    } catch (e) {}
  }

  function syncSettingsViewportHeight() {
    var root = document.getElementById("aoSettings");
    if (!root || typeof root.getBoundingClientRect !== "function") {
      return;
    }

    var headerHeight = 0;
    try {
      var header = document.querySelector("#t_Header");
      if (header && typeof header.getBoundingClientRect === "function") {
        var headerRect = header.getBoundingClientRect();
        headerHeight = Math.max(0, Math.round(headerRect.height || 0));
      }
    } catch (e) {}

    // Keep a consistent offset so sticky sidebar stays just below the top title bar.
    var stickyTopOffset = Math.max(56, headerHeight + 4);
    root.style.setProperty("--ao-top-titlebar-height", stickyTopOffset + "px");
    root.style.minHeight = "";
    root.style.height = "";
  }

  function applySettingsHeaderBrand(appDisplayName, appLogoUrl) {
    var name = normalizeAdminTextValue(appDisplayName, "Ask Oracle Select AI");
    var logoUrl = normalizeOptionalAdminTextValue(appLogoUrl);
    var headerLink = null;
    var logoNode = null;

    try {
      document.querySelectorAll(
        ".t-Header-logo-link .t-Header-logo-text, .t-Header-logo .t-Header-logo-text, .apex-logo-text"
      ).forEach(function(node) {
        node.textContent = name;
      });
    } catch (e1) {}

    try {
      headerLink = document.querySelector("#t_Header .t-Header-logo-link, .t-Header-logo-link");
    } catch (e2) {}
    if (!headerLink) return;

    headerLink.setAttribute("title", name);
    headerLink.setAttribute("aria-label", name);

    logoNode = headerLink.querySelector(".ask-oracle-custom-app-logo");
    if (!logoUrl) {
      if (logoNode && logoNode.parentNode) logoNode.parentNode.removeChild(logoNode);
      headerLink.classList.remove("ask-oracle-custom-logo-active");
      return;
    }

    if (!logoNode) {
      logoNode = document.createElement("img");
      logoNode.className = "ask-oracle-custom-app-logo";
      logoNode.alt = "";
      logoNode.setAttribute("aria-hidden", "true");
      logoNode.addEventListener("error", function() { this.style.display = "none"; });
      logoNode.addEventListener("load", function() { this.style.removeProperty("display"); });
      var textNode = headerLink.querySelector(".t-Header-logo-text, .apex-logo-text");
      if (textNode && textNode.parentNode === headerLink) {
        headerLink.insertBefore(logoNode, textNode);
      } else {
        headerLink.insertBefore(logoNode, headerLink.firstChild);
      }
    }
    if (logoNode.getAttribute("src") !== logoUrl) {
      logoNode.setAttribute("src", logoUrl);
    }
    logoNode.setAttribute("title", name);
    headerLink.classList.add("ask-oracle-custom-logo-active");
  }

  function applyTopHeaderSettingsLabel() {
    var headerLink = null;
    var existing = null;
    try {
      headerLink = document.querySelector("#t_Header .t-Header-logo-link");
    } catch (e1) {}
    if (!headerLink) return;

    existing = headerLink.querySelector(".ask-oracle-settings-context");
    if (existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
  }

  function ensureSettingsHeaderHomeButton() {
    var pageId = String(getApexRuntimeValue("APP_PAGE_ID", "pFlowStepId") || "").trim();
    var navBar = null;
    var firstNavChild = null;
    var homeBtn = null;

    // Home button must not be shown on dashboard/home page.
    if (pageId === "1") return;

    try {
      navBar = document.querySelector("#t_Header .t-Header-navBar");
      if (!navBar) return;
      homeBtn = navBar.querySelector("#aoHeaderHomeBtn");
      if (!homeBtn) {
        homeBtn = document.createElement("a");
        homeBtn.id = "aoHeaderHomeBtn";
        homeBtn.className = "ao-header-home-link";
        homeBtn.setAttribute("href", "javascript:void(0)");
        homeBtn.setAttribute("data-ao-home-page", "1");
        homeBtn.setAttribute("title", "Home");
        homeBtn.setAttribute("aria-label", "Home");
      }
      homeBtn.innerHTML = "<span class='ao-home-icon' aria-hidden='true'><svg viewBox='0 0 24 24' focusable='false'><path d='M4 10.8 12 4l8 6.8'></path><path d='M6.5 9.8V20h11V9.8'></path></svg></span>";
      homeBtn.style.setProperty("order", "-9999", "important");
      firstNavChild = navBar.firstElementChild;
      if (firstNavChild !== homeBtn) {
        navBar.insertBefore(homeBtn, firstNavChild || null);
      }
    } catch (e) {}
  }

  function scheduleSettingsHeaderHomeButtonRepair() {
    [0, 100, 300, 800, 1600, 3000].forEach(function(delay) {
      window.setTimeout(ensureSettingsHeaderHomeButton, delay);
    });
    try {
      var navBar = document.querySelector("#t_Header .t-Header-navBar");
      if (navBar && !navBar.__aoHomeButtonObserver) {
        navBar.__aoHomeButtonObserver = new MutationObserver(function() {
          ensureSettingsHeaderHomeButton();
        });
        navBar.__aoHomeButtonObserver.observe(navBar, { childList: true });
      }
    } catch (e) {}
  }

  function openInitialDeepLink() {
    var hash = String((window.location && window.location.hash) || "").replace(/^#/, "").toLowerCase();
    SETTINGS_HAS_EXPLICIT_DEEP_LINK = !!hash;
    if (hash === "agent-builder") {
      AGENT_BUILDER_MODE = "graphical";
      openFreshScreen("agent-teams:manage");
      setNav("agent-teams", "agent-builder");
      setAgentCreatePanel("overview");
    } else if (hash === "prebuilt-agents") {
      setNav("prebuilt-agents", "prebuilt-agents");
    } else if (hash === "mission-control" || hash === "agent-logs") {
      setNav("agent-logs", "agent-logs");
    } else if (hash === "profile-builder" || hash === "profile-builder-nl2sql") {
      openFreshScreen("nl2sql:manage");
      setNav("nl2sql-profile", "nl2sql-profile");
      setNl2sqlAdminCardView("create");
    } else if (hash === "profile-builder-rag") {
      openFreshScreen("rag:manage");
      setNav("rag-profile", "rag-profile");
      setRagAdminCardView("profile-create");
    } else if (hash === "vector-index-create") {
      setNav("vector-indexes", "vector-indexes");
      openFreshScreen("vector-indexes:manage");
      setVectorIndexAdminCardView("create");
    } else if (hash === "vector-index-drop") {
      setNav("vector-indexes", "vector-indexes");
      openFreshScreen("vector-indexes:manage");
      setVectorIndexAdminCardView("drop");
    } else if (hash === "dblink-create") {
      setNav("data-sources", "data-sources-connections");
      setDataSourceSection("connections");
      setDbLinkCardView("create");
      applyDbLinkCreatePrefillFromUrl();
      window.setTimeout(function() {
        var target = document.getElementById("aoDbLinkName");
        if (target && typeof target.focus === "function") target.focus();
      }, 60);
    } else {
      SETTINGS_HAS_EXPLICIT_DEEP_LINK = false;
      restoreStoredSettingsNav();
    }
  }

  var initRetryTimer = null;
  var initRetryAttempts = 0;
  var INIT_MAX_RETRY_ATTEMPTS = 40;
  var INIT_RETRY_DELAY_MS = 150;

  function scheduleInitRetry() {
    if (window.__AO_SETTINGS_V2_INIT_DONE) {
      return;
    }
    if (initRetryTimer) {
      return;
    }
    if (initRetryAttempts >= INIT_MAX_RETRY_ATTEMPTS) {
      console.error("Settings root #aoSettings not found");
      return;
    }

    initRetryTimer = window.setTimeout(function() {
      initRetryTimer = null;
      initRetryAttempts += 1;
      init();
    }, INIT_RETRY_DELAY_MS);
  }

  function init() {
    if (window.__AO_SETTINGS_V2_INIT_DONE) {
      debugSettingsLog("init skipped: already initialized", getSettingsDebugState());
      return;
    }
    if (!$ || typeof $.fn === "undefined") {
      console.error("jQuery runtime unavailable");
      return;
    }
    if (!(window.apex && apex.server && apex.item && apex.jQuery)) {
      console.error("APEX runtime unavailable");
      return;
    }
    if (!$("#aoSettings").length) {
      scheduleInitRetry();
      return;
    }
    applyTopHeaderSettingsLabel();
    ensureSettingsHeaderHomeButton();
    scheduleSettingsHeaderHomeButtonRepair();
    debugSettingsLog("init started", {
      root_count: $("#aoSettings").length,
      debug_version: getSettingsDebugState().debug_version
    });
    if (initRetryTimer) {
      window.clearTimeout(initRetryTimer);
      initRetryTimer = null;
    }
    initRetryAttempts = 0;
    window.__AO_SETTINGS_V2_INIT_DONE = true;
    markSettingsDialogPage();
    collapseOuterSettingsRegionChrome();
    stretchOuterSettingsDialogLayout();
    syncSettingsViewportHeight();
    window.addEventListener("resize", syncSettingsViewportHeight);
    window.addEventListener("resize", drawAgentStudioLinks);
    window.addEventListener("resize", scheduleAgentTeamMapLinkRedraw);
    configureZoomSliderBounds();
    var preloadedZoom = readStoredZoomPct();
    if (preloadedZoom != null) {
      var initialZoom = setZoomSliderValue(preloadedZoom);
      applyAppZoomPreview(initialZoom);
    } else {
      setZoomSliderValue(100);
    }
    applyAdminVisibility(false);
    installAgentSelectGuards();
    setScreen("nl2sql", "default");
    setScreen("rag", "default");
    setScreen("vector-indexes", "default");
    setScreen("agent-teams", "default");
    ensureVectorIndexAdminCardsOnVectorPage();
    setNl2sqlAdminCardView("none");
    setRagAdminCardView("none");
    setAgentCreatePanel("overview");
    applyAgentBuilderModeUi();
    resetNlBuilderSession();
    setAgentStudioStep(1);
    setAgentStudioEditorVisible(false);
    applyAgentStudioZoom();
    syncTeamMapExpandControls();
    updateAgentStudioCanvas();
    PREBUILT_AGENT_VIEW_MODE = loadPrebuiltAgentViewMode();
    applyPrebuiltViewModeButtons();
    applySidebarCollapsedState(readStoredSidebarCollapsed(), { persist: false });
    applyThemePreviewMode(readStoredThemeMode(), { syncToggle: true });
    bindSystemThemeModeListener();
    bindEvents();
    loadPrebuiltAgentMetadata();
    addNameRuleHelpers();
    addProfileBuilderTooltips();
    refreshObjectPickers();
    $("#aoAgentEditEntityType").val("TEAM");
    populateAgentEntityEditor();
    bootstrap({ useCache: true });
    openInitialDeepLink();
    debugSettingsLog("init completed", getSettingsDebugState());
  }

  return {
    init: init,
    debug: logSettingsDebugState,
    getDebugState: getSettingsDebugState,
    enableDebug: function() {
      try {
        window.localStorage.setItem("ASK_ORACLE_SETTINGS_DEBUG", "Y");
      } catch (e) {
        window.ASK_ORACLE_SETTINGS_DEBUG = true;
      }
      return logSettingsDebugState();
    },
    disableDebug: function() {
      try {
        window.localStorage.removeItem("ASK_ORACLE_SETTINGS_DEBUG");
      } catch (e) {
        window.ASK_ORACLE_SETTINGS_DEBUG = false;
      }
      return logSettingsDebugState();
    }
  };
})(window.apex && window.apex.jQuery ? window.apex.jQuery : window.jQuery);

// Backward/forward compatibility for both names used in Dynamic Actions.
window.AOSettingsV2 = window.AskOracleSettings;
var AOSettingsV2 = window.AOSettingsV2;
var AskOracleSettings = window.AskOracleSettings;
