(function() {
  if (window.__askOraclePage4SearchChatsLoaded) return;
  window.__askOraclePage4SearchChatsLoaded = true;

  var ROOT_ID = "ask-oracle-page4-search-root";
  var INPUT_ID = "ask-oracle-page4-search-input";
  var RESULTS_ID = "ask-oracle-page4-search-results";
  var CLEAR_ID = "ask-oracle-page4-search-clear";
  var SECTION_TITLE_ID = "ask-oracle-page4-section-title";
  var TEMPLATE_FILE = "search_chats_page4.html";
  var INPUT_SYNC_DELAY_MS = 120;
  var nativeObserver = null;
  var nativeSyncTimer = null;
  var renderToken = 0;
  var state = {
    query: "",
    activeIndex: 0,
    visibleItems: [],
    nativeItems: [],
    recentItems: [],
    loadingNative: false
  };

  function shared() {
    return window.AskOracleSearchChatsShared || {};
  }

  function normalizeText(value) {
    if (shared().normalizeText) return shared().normalizeText(value);
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function getAssetUrl(fileName) {
    if (shared().buildSiblingAssetUrl) return shared().buildSiblingAssetUrl(fileName);
    var script = document.querySelector('script[src*="search_chats.js"]');
    var src = script && script.src ? String(script.src) : "";
    return src ? src.replace(/search_chats\.js(?:[?#].*)?$/i, fileName) : fileName;
  }

  function isPage4() {
    return !!document.getElementById("P4_SEARCH");
  }

  function rootEl() {
    return document.getElementById(ROOT_ID);
  }

  function inputEl() {
    return document.getElementById(INPUT_ID);
  }

  function resultsEl() {
    return document.getElementById(RESULTS_ID);
  }

  function sectionTitleEl() {
    return document.getElementById(SECTION_TITLE_ID);
  }

  function nativeInputEl() {
    return document.getElementById("P4_SEARCH");
  }

  function readCacheItems() {
    if (!shared().getChatIndexItems) return [];
    return shared().getChatIndexItems();
  }

  function mergeCacheItems(items) {
    if (shared().mergeChatIndexItems) {
      shared().mergeChatIndexItems(items);
    }
  }

  function normalizeHref(rawHref) {
    return String(rawHref || "").replace(/&amp;/gi, "&").trim();
  }

  function decodeValue(rawValue) {
    var text = String(rawValue || "").trim();
    if (!text) return "";
    try {
      return decodeURIComponent(text.replace(/\+/g, "%20")).trim();
    } catch (e) {
      return text;
    }
  }

  function extractConversationId(href) {
    var normalized = normalizeHref(href);
    if (!normalized) return "";

    var queryMatch = normalized.match(/[?&]P1_CONV_ID=([^&#]*)/i);
    if (queryMatch && queryMatch[1]) return decodeValue(queryMatch[1]);

    var legacyMatch = normalized.match(/(?:^|:)P1_CONV_ID:([^:&?#]*)/i);
    if (legacyMatch && legacyMatch[1]) return decodeValue(legacyMatch[1]);

    return "";
  }

  function closeDialog() {
    try {
      if (window.apex && apex.navigation && apex.navigation.dialog && typeof apex.navigation.dialog.close === "function") {
        apex.navigation.dialog.close(true);
        return true;
      }
    } catch (e) {}
    try {
      window.close();
      return true;
    } catch (e2) {}
    return false;
  }

  function switchConversationInParent(item) {
    var target = item && typeof item === "object" ? item : {};
    var conversationId = String(target.conversationId || "").trim();
    var href = normalizeHref(target.url);
    var parentWin = null;
    try {
      parentWin = window.parent && window.parent !== window ? window.parent : null;
    } catch (e) {}
    if (!parentWin) return false;

    try {
      if (conversationId && typeof parentWin.switchAskOracleConversationInPlace === "function") {
        parentWin.switchAskOracleConversationInPlace(conversationId, { forceRefresh: true });
        closeDialog();
        return true;
      }
    } catch (e2) {}

    if (!href) return false;
    try {
      if (parentWin.apex && parentWin.apex.navigation && typeof parentWin.apex.navigation.redirect === "function") {
        parentWin.apex.navigation.redirect(href);
      } else {
        parentWin.location.href = href;
      }
      closeDialog();
      return true;
    } catch (e3) {}
    return false;
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function highlightMatch(text, query) {
    var source = String(text || "");
    var needle = normalizeText(query);
    if (!needle) return escapeHtml(source);
    var sourceLower = source.toLowerCase();
    var needleLower = needle.toLowerCase();
    var matchIndex = sourceLower.indexOf(needleLower);
    if (matchIndex < 0) return escapeHtml(source);
    return (
      escapeHtml(source.slice(0, matchIndex)) +
      "<mark>" + escapeHtml(source.slice(matchIndex, matchIndex + needle.length)) + "</mark>" +
      escapeHtml(source.slice(matchIndex + needle.length))
    );
  }

  function startOfDay(ts) {
    var date = new Date(ts);
    date.setHours(0, 0, 0, 0);
    return date.getTime();
  }

  function inferTimestamp(item) {
    var payload = item && typeof item === "object" ? item : {};
    var candidates = [
      payload.last_opened_at,
      payload.timestamp,
      payload.created_at,
      payload.modified_at
    ];
    for (var i = 0; i < candidates.length; i += 1) {
      var n = Number(candidates[i]);
      if (isFinite(n) && n > 0) return n;
    }
    return 0;
  }

  function titleScore(value) {
    var text = normalizeText(value);
    if (!text) return 0;
    var score = text.length;
    if (/\.\.\.$/.test(text) || /…$/.test(text)) score -= 20;
    return score;
  }

  function pickBetterText(primary, secondary) {
    var first = normalizeText(primary);
    var second = normalizeText(secondary);
    if (!first) return second;
    if (!second) return first;
    return titleScore(second) > titleScore(first) ? second : first;
  }

  function mergeConversationItems(existing, incoming, fallbackIndex) {
    var base = existing && typeof existing === "object" ? existing : {};
    var next = incoming && typeof incoming === "object" ? incoming : {};
    var merged = {};
    var existingTs = inferTimestamp(base);
    var incomingTs = inferTimestamp(next);

    merged.conversationId = String(next.conversationId || base.conversationId || "").trim();
    merged.title = pickBetterText(base.title, next.title);
    merged.subtitle = pickBetterText(base.subtitle, next.subtitle);
    merged.url = normalizeHref(next.url || base.url || "");
    merged.pinned = !!(base.pinned || next.pinned);
    merged.current = !!(base.current || next.current);
    merged.source = String(
      next.source === "native" || base.source === "native"
        ? "native"
        : (next.source || base.source || "cache")
    ).trim();
    merged.sortIndex = typeof base.sortIndex === "number"
      ? base.sortIndex
      : (typeof next.sortIndex === "number" ? next.sortIndex : fallbackIndex);
    merged.timestamp = Math.max(existingTs || 0, incomingTs || 0);
    merged.created_at = Number(base.created_at || next.created_at || merged.timestamp || 0) || 0;
    merged.modified_at = Math.max(Number(base.modified_at || 0) || 0, Number(next.modified_at || 0) || 0);
    merged.last_opened_at = Math.max(Number(base.last_opened_at || 0) || 0, Number(next.last_opened_at || 0) || 0);
    merged.last_seen_at = Math.max(Number(base.last_seen_at || 0) || 0, Number(next.last_seen_at || 0) || 0);
    merged.updated_at = Math.max(Number(base.updated_at || 0) || 0, Number(next.updated_at || 0) || 0);
    return merged;
  }

  function formatRelativeBucket(ts) {
    var timestamp = Number(ts);
    if (!isFinite(timestamp) || timestamp <= 0) return "Older";

    var todayStart = startOfDay(Date.now());
    var diffDays = Math.floor((todayStart - startOfDay(timestamp)) / 86400000);
    if (diffDays <= 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays <= 7) return "Last 7 Days";
    if (diffDays <= 30) return "Last 30 Days";
    return "Older";
  }

  function formatDateLabel(ts) {
    var timestamp = Number(ts);
    if (!isFinite(timestamp) || timestamp <= 0) return "";
    try {
      return new Intl.DateTimeFormat(undefined, {
        day: "2-digit",
        month: "short",
        year: "numeric"
      }).format(new Date(timestamp));
    } catch (e) {
      return new Date(timestamp).toLocaleDateString();
    }
  }

  function parseTimestampFromText(text) {
    var raw = normalizeText(text);
    if (!raw) return 0;

    var direct = Date.parse(raw);
    if (isFinite(direct)) return direct;

    var matchers = [
      /\b\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?\b/,
      /\b\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}\b/,
      /\b\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}\b/,
      /\b[A-Za-z]{3,9}\s+\d{1,2},\s+\d{4}\b/
    ];

    for (var i = 0; i < matchers.length; i += 1) {
      var matched = raw.match(matchers[i]);
      if (!matched || !matched[0]) continue;
      var parsed = Date.parse(matched[0]);
      if (isFinite(parsed)) return parsed;
    }
    return 0;
  }

  function collectParentChats() {
    var parentWin = null;
    try {
      parentWin = window.parent && window.parent !== window ? window.parent : null;
    } catch (e) {}
    if (!parentWin || !parentWin.document) return [];

    var treeRoot = parentWin.document.getElementById("t_TreeNav");
    if (!treeRoot) return [];
    var currentConversationId = "";
    try {
      if (typeof parentWin.getAskOracleCurrentConversationId === "function") {
        currentConversationId = String(parentWin.getAskOracleCurrentConversationId() || "").trim();
      }
    } catch (e0) {}

    var items = [];
    var seen = Object.create(null);
    Array.prototype.forEach.call(treeRoot.querySelectorAll("li"), function(node, index) {
      var conversationId = "";
      try {
        if (typeof parentWin.getAskOracleConversationIdFromNavNode === "function") {
          conversationId = String(parentWin.getAskOracleConversationIdFromNavNode(node) || "").trim();
        }
      } catch (e1) {}
      if (!conversationId || seen[conversationId]) return;

      var labelNode = node.querySelector(".a-TreeView-label");
      var title = normalizeText(
        (labelNode && (
          labelNode.getAttribute("data-full-label") ||
          labelNode.getAttribute("aria-label") ||
          labelNode.textContent
        )) || ""
      );
      if (!title || /^history$/i.test(title) || /^pinned$/i.test(title) || /^search chats$/i.test(title)) return;

      var url = "";
      var anchor = node.querySelector('a[href*="P1_CONV_ID"]');
      if (anchor) url = normalizeHref(anchor.getAttribute("href"));
      if (!url) {
        try {
          if (typeof parentWin.getAskOracleNavNodeHref === "function") {
            url = normalizeHref(parentWin.getAskOracleNavNodeHref(node));
          }
        } catch (e2) {}
      }

      items.push({
        conversationId: conversationId,
        title: title,
        url: url,
        pinned: !!(typeof parentWin.isAskOraclePinnedNavContentNode === "function" && parentWin.isAskOraclePinnedNavContentNode(node.querySelector(".a-TreeView-content") || node)),
        current: !!(currentConversationId && currentConversationId === conversationId),
        sortIndex: index
      });
      seen[conversationId] = true;
    });
    mergeCacheItems(items);
    return items;
  }

  function dedupeItems(items) {
    var mergedById = Object.create(null);
    var ordered = [];
    (Array.isArray(items) ? items : []).forEach(function(item, index) {
      var conversationId = String(item && item.conversationId || "").trim();
      if (!conversationId) return;
      if (!mergedById[conversationId]) {
        mergedById[conversationId] = mergeConversationItems(null, item, index);
        ordered.push(conversationId);
        return;
      }
      mergedById[conversationId] = mergeConversationItems(mergedById[conversationId], item, index);
    });
    return ordered.map(function(conversationId) {
      return mergedById[conversationId];
    }).filter(Boolean);
  }

  function getRecentItems() {
    var cacheItems = readCacheItems();
    var parentItems = collectParentChats();
    var merged = dedupeItems(parentItems.concat(cacheItems)).map(function(item, index) {
      var timestamp = inferTimestamp(item);
      return {
        conversationId: String(item.conversationId || "").trim(),
        title: normalizeText(item.title || ""),
        url: normalizeHref(item.url || ""),
        pinned: !!item.pinned,
        current: !!item.current,
        source: item.source || "cache",
        sortIndex: typeof item.sortIndex === "number" ? item.sortIndex : index,
        timestamp: timestamp,
        subtitle: normalizeText(item.subtitle || "")
      };
    }).filter(function(item) {
      return !!item.conversationId && !!item.title;
    });

    merged.sort(function(a, b) {
      if (a.current !== b.current) return a.current ? -1 : 1;
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      if ((b.timestamp || 0) !== (a.timestamp || 0)) return (b.timestamp || 0) - (a.timestamp || 0);
      return (a.sortIndex || 0) - (b.sortIndex || 0);
    });
    return merged.slice(0, 120);
  }

  function filterLocalMatches(query) {
    var normalizedQuery = normalizeText(query).toLowerCase();
    if (!normalizedQuery) return [];
    return getRecentItems().filter(function(item) {
      return String(item.title || "").toLowerCase().indexOf(normalizedQuery) >= 0;
    });
  }

  function setNativeUiHidden() {
    document.body.classList.add("ao-page4-search-enhanced");
    var nativeInput = nativeInputEl();
    if (nativeInput) {
      var inputContainer = nativeInput.closest(".t-Form-fieldContainer, .a-Form-fieldContainer, .t-Form-itemWrapper");
      if (inputContainer) inputContainer.classList.add("ao-page4-native-hidden");
    }
    var nativeResultsRoot = findNativeResultsHost();
    if (nativeResultsRoot) {
      nativeResultsRoot.classList.add("ao-page4-native-hidden");
    }
  }

  function findNativeResultsHost() {
    return document.querySelector(
      ".a-SearchResults, .a-Results, .t-SearchResults, .t-SearchRegion-results"
    );
  }

  function extractNativeResults() {
    var host = findNativeResultsHost();
    if (!host) return [];

    var nodes = Array.prototype.slice.call(
      host.querySelectorAll(
        ".a-SearchResults-item, .a-Results-item, .t-SearchResults-item, li, .a-MediaBlock"
      )
    );

    var items = [];
    nodes.forEach(function(node, index) {
      var link = node.querySelector && node.querySelector('a[href*="P1_CONV_ID"]');
      if (!link) return;

      var href = normalizeHref(link.getAttribute("href"));
      var conversationId = extractConversationId(href);
      if (!conversationId) return;

      var titleNode = node.querySelector(
        ".a-SearchResults-item-title, .a-SearchResults-label, .a-Results-title, .t-SearchResults-title, .a-MediaBlock-label"
      ) || link;
      var subtitleNode = node.querySelector(
        ".a-SearchResults-item-description, .a-SearchResults-desc, .a-Results-desc, .t-SearchResults-desc, .a-MediaBlock-description"
      );
      var fullText = normalizeText(node.textContent || "");
      var timestamp = parseTimestampFromText(fullText);
      items.push({
        conversationId: conversationId,
        title: normalizeText(titleNode.textContent || link.textContent || ""),
        subtitle: normalizeText((subtitleNode && subtitleNode.textContent) || ""),
        url: href,
        source: "native",
        timestamp: timestamp,
        sortIndex: index
      });
    });

    items = dedupeItems(items);
    if (items.length) mergeCacheItems(items);
    return items;
  }

  function setNativeQuery(value) {
    var nextValue = String(value == null ? "" : value);
    var nativeInput = nativeInputEl();
    if (!nativeInput) return;

    try {
      if (window.apex && typeof apex.item === "function") {
        var item = apex.item("P4_SEARCH");
        if (item && typeof item.setValue === "function") {
          item.setValue(nextValue, null, true);
        }
      }
    } catch (e) {}

    nativeInput.value = nextValue;
    ["input", "change", "keyup"].forEach(function(eventName) {
      try {
        nativeInput.dispatchEvent(new Event(eventName, { bubbles: true }));
      } catch (e2) {}
    });
  }

  function updateSectionTitle() {
    var titleEl = sectionTitleEl();
    if (!titleEl) return;
    titleEl.textContent = state.query ? 'Search results for "' + state.query + '"' : "Recent chats";
  }

  function buildGroups(items, query) {
    var normalizedQuery = normalizeText(query);
    if (normalizedQuery) {
      return [{
        title: "Matches",
        items: items
      }];
    }

    var groupsByName = {
      Today: [],
      Yesterday: [],
      "Last 7 Days": [],
      "Last 30 Days": [],
      Older: []
    };

    items.forEach(function(item) {
      var groupName = formatRelativeBucket(item.timestamp);
      if (!groupsByName[groupName]) groupsByName[groupName] = [];
      groupsByName[groupName].push(item);
    });

    return Object.keys(groupsByName).filter(function(key) {
      return groupsByName[key] && groupsByName[key].length;
    }).map(function(key) {
      return { title: key, items: groupsByName[key] };
    });
  }

  function syncActiveIndex() {
    if (!state.visibleItems.length) {
      state.activeIndex = -1;
      return;
    }
    if (state.activeIndex < 0) state.activeIndex = 0;
    if (state.activeIndex >= state.visibleItems.length) state.activeIndex = state.visibleItems.length - 1;
  }

  function renderEmpty(message) {
    var host = resultsEl();
    if (!host) return;
    host.innerHTML = '<div class="ao-page4-search-empty">' + message + "</div>";
  }

  function renderResults() {
    var host = resultsEl();
    if (!host) return;

    updateSectionTitle();
    host.innerHTML = "";
    var visibleItems = [];
    var groups = buildGroups(state.visibleItems, state.query);

    if (!groups.length || !state.visibleItems.length) {
      if (state.query) {
        renderEmpty("No matching chats found yet. Try a different search phrase.");
      } else {
        renderEmpty("<strong>No recent chats available.</strong> Open a few chats and they will appear here.");
      }
      return;
    }

    groups.forEach(function(group) {
      var section = document.createElement("section");
      section.className = "ao-page4-search-group";

      var title = document.createElement("h3");
      title.className = "ao-page4-search-group-title";
      title.textContent = group.title;
      section.appendChild(title);

      group.items.forEach(function(item) {
        visibleItems.push(item);
        var button = document.createElement("button");
        button.type = "button";
        button.className = "ao-page4-search-item";
        if (visibleItems.length - 1 === state.activeIndex) {
          button.classList.add("is-active");
        }
        button.setAttribute("data-item-index", String(visibleItems.length - 1));
        button.setAttribute("title", item.title || "");
        button.innerHTML =
          '<div class="ao-page4-search-item-title">' + highlightMatch(item.title, state.query) + "</div>" +
          (item.subtitle ? '<div class="ao-page4-search-item-subtitle">' + escapeHtml(item.subtitle) + "</div>" : "") +
          '<div class="ao-page4-search-item-meta">' +
            (item.current ? '<span class="ao-page4-search-badge current">Current</span>' : "") +
            (item.pinned ? '<span class="ao-page4-search-badge pinned">Pinned</span>' : "") +
            (item.source === "native" ? '<span class="ao-page4-search-badge native">Search</span>' : "") +
            (item.timestamp ? '<span class="ao-page4-search-item-date">' + escapeHtml(formatDateLabel(item.timestamp)) + "</span>" : "") +
          "</div>";
        button.addEventListener("mouseenter", function() {
          state.activeIndex = Number(button.getAttribute("data-item-index"));
          repaintActiveState();
        });
        button.addEventListener("click", function(event) {
          if (event) {
            event.preventDefault();
            event.stopPropagation();
          }
          switchConversationInParent(item);
        });
        section.appendChild(button);
      });

      host.appendChild(section);
    });

    state.visibleItems = visibleItems;
    syncActiveIndex();
    repaintActiveState();
  }

  function repaintActiveState() {
    var host = resultsEl();
    if (!host) return;
    Array.prototype.forEach.call(host.querySelectorAll(".ao-page4-search-item"), function(node) {
      node.classList.remove("is-active");
    });
    if (state.activeIndex < 0) return;
    var activeNode = host.querySelector('.ao-page4-search-item[data-item-index="' + state.activeIndex + '"]');
    if (!activeNode) return;
    activeNode.classList.add("is-active");
    try {
      activeNode.scrollIntoView({ block: "nearest" });
    } catch (e) {}
  }

  function mergeResults(primary, secondary) {
    var list = [];
    var seen = Object.create(null);
    [primary, secondary].forEach(function(group) {
      (Array.isArray(group) ? group : []).forEach(function(item) {
        var conversationId = String(item && item.conversationId || "").trim();
        if (!conversationId || seen[conversationId]) return;
        seen[conversationId] = true;
        list.push(item);
      });
    });
    return list;
  }

  function computeDisplayItems() {
    if (!state.query) {
      var nativeRecentItems = extractNativeResults();
      state.nativeItems = nativeRecentItems;
      state.visibleItems = mergeResults(nativeRecentItems, getRecentItems());
      state.loadingNative = false;
      syncActiveIndex();
      renderResults();
      return;
    }

    var localMatches = filterLocalMatches(state.query);
    var nativeItems = extractNativeResults();
    state.nativeItems = nativeItems;
    state.visibleItems = mergeResults(nativeItems, localMatches);
    syncActiveIndex();
    renderResults();
  }

  function scheduleQuerySync() {
    if (nativeSyncTimer) clearTimeout(nativeSyncTimer);
    state.loadingNative = !!state.query;
    nativeSyncTimer = setTimeout(function() {
      nativeSyncTimer = null;
      setNativeQuery(state.query);
      computeDisplayItems();
    }, INPUT_SYNC_DELAY_MS);
  }

  function moveSelection(delta) {
    if (!state.visibleItems.length) return;
    var next = state.activeIndex < 0
      ? 0
      : (state.activeIndex + delta + state.visibleItems.length) % state.visibleItems.length;
    state.activeIndex = next;
    repaintActiveState();
  }

  function openActiveItem() {
    if (state.activeIndex < 0 || state.activeIndex >= state.visibleItems.length) return;
    switchConversationInParent(state.visibleItems[state.activeIndex]);
  }

  function bindInput() {
    var input = inputEl();
    var clearBtn = document.getElementById(CLEAR_ID);
    if (!input) return;

    input.addEventListener("input", function() {
      state.query = normalizeText(input.value);
      state.activeIndex = 0;
      scheduleQuerySync();
    });

    input.addEventListener("keydown", function(event) {
      if (!event) return;
      if (event.key === "ArrowDown") {
        event.preventDefault();
        moveSelection(1);
        return;
      }
      if (event.key === "ArrowUp") {
        event.preventDefault();
        moveSelection(-1);
        return;
      }
      if (event.key === "Enter") {
        event.preventDefault();
        openActiveItem();
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        closeDialog();
      }
    });

    if (clearBtn) {
      clearBtn.addEventListener("click", function(event) {
        if (event) {
          event.preventDefault();
          event.stopPropagation();
        }
        input.value = "";
        state.query = "";
        state.activeIndex = 0;
        setNativeQuery("");
        computeDisplayItems();
        try { input.focus({ preventScroll: true }); } catch (e) {}
      });
    }
  }

  function watchNativeResults() {
    var nativeHost = findNativeResultsHost();
    if (!nativeHost || nativeObserver) return;
    nativeObserver = new MutationObserver(function() {
      renderToken += 1;
      var token = renderToken;
      setTimeout(function() {
        if (token !== renderToken) return;
        computeDisplayItems();
      }, 60);
    });
    nativeObserver.observe(nativeHost, { childList: true, subtree: true, characterData: true });
  }

  function getFallbackTemplate() {
    return [
      '<section id="' + ROOT_ID + '" class="ao-page4-search" aria-label="Search Chats">',
      '  <div class="ao-page4-search-shell">',
      '    <header class="ao-page4-search-header">',
      '      <div class="ao-page4-search-input-wrap">',
      '        <span class="ao-page4-search-input-icon" aria-hidden="true">Search</span>',
      '        <input id="' + INPUT_ID + '" class="ao-page4-search-input" type="search" autocomplete="off" spellcheck="false" placeholder="Search chats..." aria-label="Search chats" />',
      '        <button id="' + CLEAR_ID + '" class="ao-page4-search-clear" type="button">Clear</button>',
      "      </div>",
      '      <div class="ao-page4-search-meta"><span>Search chats</span><span>Esc to close</span></div>',
      "    </header>",
      '    <div class="ao-page4-search-body">',
      '      <section class="ao-page4-search-panel">',
      '        <div class="ao-page4-search-panel-title" id="' + SECTION_TITLE_ID + '">Recent chats</div>',
      '        <div id="' + RESULTS_ID + '" class="ao-page4-search-results" aria-live="polite"></div>',
      "      </section>",
      "    </div>",
      "  </div>",
      "</section>"
    ].join("");
  }

  function fetchTemplate() {
    var url = getAssetUrl(TEMPLATE_FILE);
    if (!url || typeof window.fetch !== "function") {
      return Promise.resolve(getFallbackTemplate());
    }
    return fetch(url, { credentials: "same-origin" })
      .then(function(response) {
        if (!response || !response.ok) throw new Error("Template fetch failed");
        return response.text();
      })
      .then(function(html) {
        return String(html || "").trim() || getFallbackTemplate();
      })
      .catch(function() {
        return getFallbackTemplate();
      });
  }

  function mountTemplate(html) {
    if (rootEl()) return rootEl();
    var mountHost = document.querySelector(".t-Dialog-body") ||
      document.querySelector("main") ||
      document.body;
    if (!mountHost) return null;
    mountHost.insertAdjacentHTML("afterbegin", html);
    return rootEl();
  }

  function initUi() {
    if (!isPage4()) return;

    fetchTemplate().then(function(html) {
      var root = mountTemplate(html);
      if (!root) return;
      setNativeUiHidden();
      bindInput();
      watchNativeResults();
      state.recentItems = getRecentItems();
      state.visibleItems = state.recentItems.slice();
      state.query = normalizeText((nativeInputEl() && nativeInputEl().value) || "");
      var input = inputEl();
      if (input) {
        input.value = state.query;
      }
      computeDisplayItems();
      setTimeout(function() {
        try {
          if (input) {
            input.focus();
            input.setSelectionRange(input.value.length, input.value.length);
          }
        } catch (e) {}
      }, 50);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initUi, { once: true });
  } else {
    initUi();
  }
})();
