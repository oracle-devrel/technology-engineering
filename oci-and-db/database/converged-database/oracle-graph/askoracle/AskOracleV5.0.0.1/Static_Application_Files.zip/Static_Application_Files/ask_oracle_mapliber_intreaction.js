/* Ask Oracle map interactions v1.2.2 (filename spelling intentional).
 * Load AFTER #APP_FILES#ask_oracle_mapliber.js (v1.2.1 or compatible).
 * No changes to that file, SQL, profiles or source data. Original result tables
 * are visually filtered only: geometry cells stay in the DOM for the map reader.
 * Uses askOracleMap.getMap(), public MapLibre source data and feature state.
 * One row per mapped feature; only attributes returned with usable geometry are
 * available. Geometry collections can therefore have more than one row.
 * All mapped features (not just visible tiles) participate in Select All.
 * Click/Space toggles selection; selections are additive. Right-click a heading
 * or cell for sorting (keyboard: focus heading, Shift+F10). NULLs sort last.
 * Original table is hidden only while a populated interactive map is open.
 * Otherwise it remains visible without geometry columns. Selected location is
 * suppressed; Show SQL and PDF export logic are not modified.
 * New query/map instances start with a fresh selection. Hide/Show retains it.
 * CSS is included. No additional library, network request or database call.
 */
(function () {
  'use strict';
  if (window.askOracleMapInteractions) return;
  const SOURCE = 'ask-oracle-results';
  const KEY = 'aoInteractionSelected';
  const BASE = ['ao-areas', 'ao-lines', 'ao-points'];
  const LAYERS = ['aoi-fill', 'aoi-outline', 'aoi-line', 'aoi-point'];
  const sessions = new Map();
  const geometryColumn = name => /^(GEOJSON|GEOMETRY|GEOM)$|_GEOJSON$/i.test(name.trim());
  const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
  let stopped = false, timer, observer, scheduled = false, menu, menuOwner, menuReturn;
  let originalChart, chartWrapper;

  // Filter controls, not cached rows: the map still needs the complete GeoJSON.
  function installChartGuard() {
    const fn = window.renderAskOracleNl2SqlAggregateChart;
    if (typeof fn !== 'function' || fn === chartWrapper) return;
    originalChart = fn;
    chartWrapper = function (id) {
      const rows = (window.__askOracleNl2SqlChartRows || {})[id];
      const block = document.getElementById('chart-block-' + id);
      if (block && Array.isArray(rows) && rows.some(r => Object.keys(r).some(geometryColumn))) {
        const first = !block.dataset.aoiChartReady;
        ['.chart-xaxis', '.chart-yaxis', '.chart-series'].forEach((selector, index) => {
          const control = block.querySelector(selector); if (!control) return;
          const previous = control.value;
          Array.from(control.options).forEach(option => { if (geometryColumn(option.value)) option.remove(); });
          const options = Array.from(control.options);
          if (index < 2 && (first || geometryColumn(previous))) {
            const preferred = options.find(o => (index === 0 ? /^district$/i : /^population$/i).test(o.value));
            const fallback = options.find(o => index === 0 || rows.some(r => r[o.value] !== null && r[o.value] !== '' && Number.isFinite(Number(r[o.value]))));
            if (preferred || fallback) control.value = (preferred || fallback).value;
          }
        });
        block.dataset.aoiChartReady = 'true';
      }
      return fn.apply(this, arguments);
    };
    window.renderAskOracleNl2SqlAggregateChart = chartWrapper;
  }

  function installBoxSelection(s) {
    const canvas = s.map.getCanvasContainer();
    const boxZoomEnabled = !!s.map.boxZoom?.isEnabled();
    if (boxZoomEnabled) s.map.boxZoom.disable();
    let drag, rectangle;
    const point = event => {
      const r = s.map.getCanvas().getBoundingClientRect();
      return [Math.max(0, Math.min(r.width, event.clientX - r.left)), Math.max(0, Math.min(r.height, event.clientY - r.top))];
    };
    const stop = event => { event.preventDefault(); event.stopImmediatePropagation(); };
    function finish(event, cancel) {
      if (!drag) return;
      if (event && event.pointerId !== undefined && event.pointerId !== drag.pointerId) return;
      const start = drag.start, end = event && event.clientX !== undefined ? point(event) : start;
      if (event) stop(event);
      drag = null; if (rectangle) rectangle.remove(); rectangle = null;
      s.suppressClickUntil = Date.now() + 300;
      if (!cancel && Math.hypot(end[0] - start[0], end[1] - start[1]) >= 4) {
        const bounds = [[Math.min(start[0], end[0]), Math.min(start[1], end[1])], [Math.max(start[0], end[0]), Math.max(start[1], end[1])]];
        const hits = s.map.queryRenderedFeatures(bounds, { layers: BASE.filter(id => s.map.getLayer(id)) });
        new Set(hits.map(f => f.id)).forEach(id => select(s, id, true)); updateStatus(s);
      }
    }
    function down(event) {
      if (!event.shiftKey || event.button !== 0 || s.block.hidden) return;
      stop(event); drag = { start: point(event), pointerId: event.pointerId };
      rectangle = el('div');
      rectangle.style.cssText = 'position:fixed;pointer-events:none;box-sizing:border-box;border:2px dashed #947900;background:#ffe60033;z-index:100001;';
      document.body.appendChild(rectangle);
    }
    function move(event) {
      if (!drag || event.pointerId !== drag.pointerId) return;
      stop(event); const p = point(event), a = drag.start;
      const r = s.map.getCanvas().getBoundingClientRect();
      Object.assign(rectangle.style, { left: r.left + Math.min(a[0], p[0]) + 'px', top: r.top + Math.min(a[1], p[1]) + 'px', width: Math.abs(a[0] - p[0]) + 'px', height: Math.abs(a[1] - p[1]) + 'px' });
    }
    const up = e => finish(e, false), cancel = e => finish(e, true);
    const key = e => { if (e.key === 'Escape') finish(e, true); };
    const blur = () => finish(null, true);
    canvas.addEventListener('pointerdown', down, true);
    document.addEventListener('pointermove', move, true); document.addEventListener('pointerup', up, true);
    document.addEventListener('pointercancel', cancel, true); document.addEventListener('keydown', key, true);
    window.addEventListener('blur', blur);
    s.cancelBox = blur;
    s.disposeBox = () => {
      blur(); canvas.removeEventListener('pointerdown', down, true);
      document.removeEventListener('pointermove', move, true); document.removeEventListener('pointerup', up, true);
      document.removeEventListener('pointercancel', cancel, true); document.removeEventListener('keydown', key, true);
      window.removeEventListener('blur', blur);
      if (boxZoomEnabled) { try { s.map.boxZoom.enable(); } catch (_) { /* map removed */ } }
    };
  }

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function button(text, action) {
    const node = el('button', 't-Button t-Button--small', text);
    node.type = 'button'; node.addEventListener('click', action); return node;
  }
  function value(row, column) { return column === null ? row.order + 1 : row.properties[column]; }
  function empty(v) { return v === null || v === undefined || v === ''; }
  function compare(a, b, direction) {
    if (empty(a) || empty(b)) return empty(a) ? (empty(b) ? 0 : 1) : -1;
    const number = v => typeof v === 'number' && Number.isFinite(v) ? v :
      (typeof v === 'string' && /^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(v.trim()) ? Number(v) : NaN);
    const na = number(a), nb = number(b);
    return direction * (Number.isFinite(na) && Number.isFinite(nb) ? na - nb : collator.compare(String(a), String(b)));
  }
  function closeMenu(focus) {
    if (menu) menu.remove(); menu = null; menuOwner = null;
    if (focus && menuReturn && menuReturn.isConnected) menuReturn.focus();
    menuReturn = null;
  }
  function sort(s, column, direction) {
    s.sortColumn = column; s.direction = direction;
    s.rows.sort((a, b) => compare(value(a, column), value(b, column), direction) || a.order - b.order);
    renderRows(s);
    s.headings.forEach((heading, key) => heading.setAttribute('aria-sort', key === column ? (direction === 1 ? 'ascending' : 'descending') : 'none'));
    updateStatus(s);
  }
  function openMenu(s, column, target, x, y) {
    closeMenu(false); menuOwner = s; menuReturn = target;
    menu = el('div', 'aoi-menu'); menu.setAttribute('role', 'menu');
    menu.setAttribute('aria-label', 'Sort ' + (column === null ? 'Feature' : column));
    const choices = [['Sort Ascending', 1], ['Sort Descending', -1]].map(([label, direction]) => {
      const b = button(label, () => { sort(s, column, direction); closeMenu(true); });
      b.setAttribute('role', 'menuitem'); menu.appendChild(b); return b;
    });
    menu.addEventListener('keydown', event => {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault(); choices[(choices.indexOf(document.activeElement) + 1) % choices.length].focus();
      }
    });
    document.body.appendChild(menu);
    const box = menu.getBoundingClientRect();
    menu.style.left = Math.max(4, Math.min(x, window.innerWidth - box.width - 8)) + 'px';
    menu.style.top = Math.max(4, Math.min(y, window.innerHeight - box.height - 8)) + 'px';
    choices[0].focus();
  }
  function updateStatus(s) {
    s.status.textContent = s.selected.size + ' of ' + s.rows.length + ' mapped features selected' +
      (s.direction ? '. Sorted by ' + (s.sortColumn === null ? 'Feature' : s.sortColumn) + (s.direction === 1 ? ' ascending.' : ' descending.') : '.');
    s.all.disabled = !s.rows.length || s.selected.size === s.rows.length;
    s.clear.disabled = !s.selected.size;
  }
  function select(s, id, selected) {
    const row = s.byId.get(id);
    if (!row || s.disposed) return;
    s.map.setFeatureState({ source: SOURCE, id: id }, { [KEY]: selected });
    if (selected) s.selected.add(id); else s.selected.delete(id);
    row.node.classList.toggle('aoi-selected', selected);
    row.checkbox.checked = selected;
  }
  function selectAll(s, selected) {
    s.rows.forEach(row => select(s, row.id, selected)); updateStatus(s);
  }
  function toggle(s, id) { select(s, id, !s.selected.has(id)); updateStatus(s); }
  function updateGraphButtonVisibility() {
    // Existing graph extensions can leave controls behind after a conversation
    // is cleared. Hide only orphan controls; never remove/reparent them or
    // change their handlers. Restore them when their response is populated.
    const available = new Map();
    document.querySelectorAll('.llm-conv-show-graph-btn[data-id],.llm-conv-show-graphcy-btn[data-id],.llm-conv-show-graphd3-btn[data-id]').forEach(button => {
      const id = String(button.getAttribute('data-id') || '').trim().replace(/^response-/, '');
      if (!available.has(id)) {
        const response = id && document.getElementById('response-' + id);
        // Do not test visibility: opening a map deliberately hides its SQL table.
        available.set(id, !!response && !!(response.textContent.trim() || response.querySelector('img[src],canvas,svg')));
      }
      button.classList.toggle('aoi-orphan-graph', !available.get(id));
    });
  }
  function updatePresentation() {
    updateGraphButtonVisibility();
    // Restrict filtering to executed SQL tables, never narrative/SQL code blocks.
    document.querySelectorAll('[id^="response-"]').forEach(response => {
      const id = response.id.slice('response-'.length), s = sessions.get(id);
      const mapped = !!s && s.rows.length > 0 && s.panel.isConnected && !s.block.hidden;
      const tables = response.querySelectorAll('table.llm-sql-table, table.sql-result-table, table.sql-results-table, table[data-query-results]');
      let hasGeometryTable = false;
      tables.forEach(table => {
        const headers = Array.from(table.querySelectorAll('thead th'));
        const indices = new Set();
        headers.forEach((th, i) => { if (geometryColumn(th.textContent)) indices.add(i); });
        const hasGeometry = indices.size > 0; hasGeometryTable = hasGeometryTable || hasGeometry;
        // Do not delete cells or alter their text: the main map's table fallback
        // must still be able to retrieve full GeoJSON, including after a rerender.
        Array.from(table.rows).forEach(row => Array.from(row.cells).forEach((cell, i) => {
          cell.classList.toggle('aoi-geometry-cell', indices.has(i));
        }));
        table.querySelectorAll('colgroup col').forEach((col, i) => col.classList.toggle('aoi-geometry-cell', indices.has(i)));
        const wrapper = table.closest('.llm-sql-table-wrap') || table;
        wrapper.classList.toggle('aoi-original-hidden', hasGeometry && mapped);
      });
      response.querySelectorAll('.code-editor-run-output-meta').forEach(meta => {
        meta.classList.toggle('aoi-original-hidden', hasGeometryTable && mapped);
      });
    });
    if (menuOwner && menuOwner.block.hidden) closeMenu(false);
  }
  function renderRows(s) {
    const fragment = document.createDocumentFragment();
    s.rows.forEach(row => {
      if (!row.node) {
        const tr = el('tr'); tr.tabIndex = 0;
        tr.setAttribute('aria-label', 'Toggle selection for feature ' + (row.order + 1));
        const cell = el('td'), cb = el('input'); cb.type = 'checkbox';
        cb.setAttribute('aria-label', 'Select feature ' + (row.order + 1));
        cb.addEventListener('click', event => event.stopPropagation());
        cb.addEventListener('change', () => { select(s, row.id, cb.checked); updateStatus(s); });
        cell.appendChild(cb); tr.appendChild(cell);
        row.checkbox = cb; row.node = tr;
        s.columns.forEach(column => {
          const v = value(row, column);
          const td = el('td', '', v === null || v === undefined ? 'NULL' : String(v));
          td.addEventListener('contextmenu', event => {
            event.preventDefault(); event.stopPropagation(); openMenu(s, column, tr, event.clientX, event.clientY);
          });
          tr.appendChild(td);
        });
        tr.addEventListener('click', () => toggle(s, row.id));
        tr.addEventListener('keydown', event => {
          if (event.target === tr && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); toggle(s, row.id); }
        });
      }
      fragment.appendChild(row.node);
    });
    s.body.replaceChildren(fragment);
  }
  function addLayers(s) {
    const enabled = ['boolean', ['feature-state', KEY], false];
    const opacity = n => ['case', enabled, n, 0];
    const geometry = type => ['==', ['geometry-type'], type];
    [
      { id: LAYERS[0], type: 'fill', filter: geometry('Polygon'), paint: { 'fill-color': '#ffe600', 'fill-opacity': opacity(0.65) } },
      { id: LAYERS[1], type: 'line', filter: geometry('Polygon'), paint: { 'line-color': '#ffdf00', 'line-width': 3, 'line-opacity': opacity(1) } },
      { id: LAYERS[2], type: 'line', filter: geometry('LineString'), paint: { 'line-color': '#ffe600', 'line-width': 5, 'line-opacity': opacity(1) } },
      { id: LAYERS[3], type: 'circle', filter: geometry('Point'), paint: { 'circle-color': '#ffe600', 'circle-radius': 9, 'circle-opacity': opacity(1), 'circle-stroke-color': '#715b00', 'circle-stroke-width': 2, 'circle-stroke-opacity': opacity(1) } }
    ].forEach(layer => { s.map.addLayer(Object.assign({ source: SOURCE }, layer)); s.added.push(layer.id); });
  }
  function dispose(s, removed) {
    if (s.disposed) return; s.disposed = true;
    if (s.disposeBox) s.disposeBox();
    if (menuOwner === s) closeMenu(false);
    s.map.off('click', s.click); s.map.off('remove', s.remove);
    if (!removed) {
      try {
        s.selected.forEach(id => s.map.removeFeatureState({ source: SOURCE, id: id }, KEY));
        s.added.slice().reverse().forEach(id => { if (s.map.getLayer(id)) s.map.removeLayer(id); });
      } catch (_) { /* main map may already have been destroyed */ }
    }
    if (s.panel) s.panel.remove();
    if (sessions.get(s.id) === s) sessions.delete(s.id);
  }
  function attach(id, map, block, data) {
    const s = { id, map, block, rows: [], byId: new Map(), selected: new Set(), headings: new Map(), added: [], disposed: false };
    const columns = new Set();
    data.features.forEach((feature, order) => {
      if (feature.id === undefined || feature.id === null || s.byId.has(feature.id)) throw new Error('Map features need unique IDs.');
      const properties = feature.properties || {};
      Object.keys(properties).forEach(key => {
        if (!geometryColumn(key) && (properties[key] === null || ['string', 'number', 'boolean'].includes(typeof properties[key]))) columns.add(key);
      });
      const row = { id: feature.id, order, properties }; s.rows.push(row); s.byId.set(row.id, row);
    });
    s.columns = columns.size ? Array.from(columns) : [null];
    s.panel = el('section', 'aoi-panel'); s.panel.setAttribute('aria-label', 'Map results and selection');
    s.panel.appendChild(el('h3', '', 'Map results'));
    s.panel.appendChild(el('p', 'aoi-hint', 'Click a row or geometry to toggle yellow selection. Shift + drag a rectangle adds intersecting visible features to the selection. Right-click a heading or cell to sort. This table contains mapped features only.'));
    const toolbar = el('div', 'aoi-toolbar');
    s.all = button('Select All', () => selectAll(s, true));
    s.clear = button('Clear Selection', () => selectAll(s, false));
    s.status = el('span', 'aoi-status'); s.status.setAttribute('role', 'status');
    toolbar.append(s.all, s.clear, s.status); s.panel.appendChild(toolbar);
    const scroll = el('div', 'aoi-scroll'), table = el('table', 'aoi-table');
    const caption = el('caption', '', 'Returned map attributes'); table.appendChild(caption);
    const head = el('thead'), hr = el('tr'); hr.appendChild(el('th', '', 'Select'));
    s.columns.forEach(column => {
      const th = el('th', '', column === null ? 'Feature' : column);
      th.scope = 'col'; th.tabIndex = 0; th.setAttribute('aria-sort', 'none');
      th.setAttribute('aria-haspopup', 'menu'); th.title = 'Right-click to sort (keyboard: Shift+F10)';
      th.addEventListener('contextmenu', event => { event.preventDefault(); openMenu(s, column, th, event.clientX, event.clientY); });
      th.addEventListener('keydown', event => {
        if (event.key === 'ContextMenu' || (event.shiftKey && event.key === 'F10')) {
          event.preventDefault(); const box = th.getBoundingClientRect(); openMenu(s, column, th, box.left, box.bottom);
        }
      });
      hr.appendChild(th); s.headings.set(column, th);
    });
    head.appendChild(hr); s.body = el('tbody'); table.append(head, s.body); scroll.appendChild(table); s.panel.appendChild(scroll);
    s.click = event => {
      if (Date.now() < (s.suppressClickUntil || 0) || (window.askOracleMapDrawing && window.askOracleMapDrawing.isDrawing(id))) return;
      const hits = map.queryRenderedFeatures(event.point, { layers: BASE.filter(layer => map.getLayer(layer)) });
      const hit = hits.find(f => s.byId.has(f.id));
      if (hit) { toggle(s, hit.id); s.byId.get(hit.id).node.scrollIntoView({ block: 'nearest', inline: 'nearest' }); }
    };
    s.remove = () => dispose(s, true);
    try {
      addLayers(s); renderRows(s); updateStatus(s);
      block.appendChild(s.panel); map.on('click', s.click); map.on('remove', s.remove); sessions.set(id, s);
      installBoxSelection(s);
    } catch (error) { dispose(s, false); throw error; }
  }
  function scan() {
    scheduled = false; if (stopped) return;
    installChartGuard();
    const api = window.askOracleMap;
    sessions.forEach(s => { if (!s.block.isConnected || !api || api.getMap(s.id) !== s.map) dispose(s, false); });
    if (!api) { updatePresentation(); return; }
    document.querySelectorAll('.llm-conv-show-map-btn[data-id]').forEach(b => {
      const id = b.getAttribute('data-id'), map = api.getMap(id);
      if (!map || sessions.has(id)) return;
      const block = map.getContainer().closest('.ask-oracle-map-block');
      if (!block || !BASE.every(layer => map.getLayer(layer))) return;
      // getStyle retains the complete inline source, unlike querySourceFeatures
      // which only returns currently loaded tiles (and can duplicate features).
      const source = map.getStyle().sources[SOURCE];
      const data = source && source.data;
      if (!data || data.type !== 'FeatureCollection' || !Array.isArray(data.features)) return;
      try { attach(id, map, block, data); }
      catch (error) { console.warn('Ask Oracle map interactions:', error.message); }
    });
    sessions.forEach(s => { s.panel.hidden = s.rows.length === 0; if (s.block.hidden && s.cancelBox) s.cancelBox(); });
    updatePresentation();
  }
  function schedule() { if (!scheduled && !stopped) { scheduled = true; window.setTimeout(scan, 80); } }
  function outside(event) { if (menu && !menu.contains(event.target)) closeMenu(false); }
  function keys(event) {
    if (!menu) return;
    if (event.key === 'Escape') { event.preventDefault(); closeMenu(true); }
    else if (event.key === 'Tab') closeMenu(true);
  }
  function install() {
    if (stopped) return;
    const style = el('style'); style.id = 'aoi-css';
    style.textContent = '.aoi-panel{padding:16px;border-top:1px solid #ccd5df;color:#172b3a;background:white;font:14px/1.5 Arial,sans-serif}.aoi-panel h3{margin:0 0 8px;font-size:17px}.aoi-hint{margin:0 0 12px}.aoi-toolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px}.aoi-scroll{max-height:360px;overflow:auto}.aoi-table{width:100%;border-collapse:separate;border-spacing:0;text-align:left}.aoi-table caption{text-align:left;padding:4px}.aoi-table th{position:sticky;top:0;background:#edf2f7;z-index:1}.aoi-table td,.aoi-table th{padding:8px 12px;border-bottom:1px solid #d8dfe7;max-width:420px;overflow-wrap:anywhere}.aoi-table tbody tr{cursor:pointer}.aoi-table tr.aoi-selected>td{background:#fff176!important;color:#172b3a!important}.aoi-table input{width:18px;height:18px;accent-color:#725c00}.aoi-table th button{font-weight:bold}.aoi-panel button,.aoi-menu button{min-height:32px;cursor:pointer}.aoi-panel button:disabled{cursor:default}.aoi-panel :focus-visible,.aoi-menu :focus-visible{outline:3px solid #126a9a;outline-offset:2px}.aoi-menu{position:fixed;z-index:100000;background:white;color:#172b3a;padding:6px;border:1px solid #7b8996;border-radius:5px;box-shadow:0 4px 14px #0003;display:grid;gap:4px;max-width:calc(100vw - 16px)}';
    document.head.appendChild(style);
    style.textContent += '.aoi-orphan-graph{display:none!important}';
    // Style-only hiding preserves values used by the main map and SQL display.
    style.textContent += '.aoi-geometry-cell,.aoi-original-hidden,.ask-oracle-map-block .ask-oracle-map-details,.aoi-panel[hidden]{display:none!important}.aoi-table th[aria-sort="ascending"]::after{content:" \\2191"}.aoi-table th[aria-sort="descending"]::after{content:" \\2193"}';
    document.addEventListener('pointerdown', outside); document.addEventListener('keydown', keys);
    observer = new MutationObserver(records => {
      if (records.some(r => !(r.target.closest && r.target.closest('.aoi-panel,.aoi-menu')))) schedule();
    });
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden'], characterData: true });
    timer = window.setInterval(() => { if (!document.hidden) scan(); }, 1000); scan();
  }
  window.askOracleMapInteractions = {
    version: '1.2.2', refresh: schedule,
    getSnapshot: function (id) {
      const s = sessions.get(String(id)); if (!s) return null;
      return { columns: s.columns.map(c => c === null ? 'Feature' : c), rows: s.rows.map(row => ({ id: row.id, selected: s.selected.has(row.id), values: s.columns.map(c => value(row, c)) })) };
    },
    destroy: function () {
      stopped = true; document.removeEventListener('DOMContentLoaded', install);
      if (observer) observer.disconnect(); window.clearInterval(timer);
      if (window.renderAskOracleNl2SqlAggregateChart === chartWrapper) window.renderAskOracleNl2SqlAggregateChart = originalChart;
      sessions.forEach(s => dispose(s, false)); closeMenu(false);
      document.removeEventListener('pointerdown', outside); document.removeEventListener('keydown', keys);
      const style = document.getElementById('aoi-css'); if (style) style.remove();
      document.querySelectorAll('.aoi-geometry-cell,.aoi-original-hidden,.aoi-orphan-graph').forEach(node => {
        node.classList.remove('aoi-geometry-cell', 'aoi-original-hidden', 'aoi-orphan-graph');
      });
      delete window.askOracleMapInteractions;
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, { once: true }); else install();
})();
