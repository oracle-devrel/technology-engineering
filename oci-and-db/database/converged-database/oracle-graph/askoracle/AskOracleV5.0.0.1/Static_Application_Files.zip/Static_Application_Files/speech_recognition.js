(() => {
  const SpeechCtor = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechCtor) {
    console.log("Speech Recognition Not Available");
    return;
  }

  const recognition = new SpeechCtor();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";

  let recording = false;
  let finalTranscript = "";
  let baseText = "";

  function getPromptInput() {
    return document.getElementById("P1_PROMPT1");
  }

  function getMicButton() {
    return document.querySelector("#startSpeechButton, #promptWrapper .llm-recording, .llm-recording");
  }

  function setGlobalMicState(active) {
    const state = !!active;
    window.isRecording = state;
    window.isListening = state;
    window.speechRecognitionActive = state;
    window.__askOracleMicActive = state;
  }

  function setMicButtonUi(active) {
    const btn = getMicButton();
    if (!btn) return;

    const icon = btn.matches("i, svg") ? btn : btn.querySelector("i, svg");
    const target = icon || btn;
    const targetClasses = target && target.classList ? target.classList : btn.classList;

    if (active) {
      targetClasses.remove("fa-microphone");
      targetClasses.add("fa-stop-circle");
      targetClasses.add("fa-anim-flash");
      btn.setAttribute("aria-pressed", "true");
      btn.setAttribute("title", "Stop microphone");
      btn.setAttribute("aria-label", "Stop microphone");
    } else {
      targetClasses.remove("fa-stop-circle");
      targetClasses.remove("fa-anim-flash");
      targetClasses.add("fa-microphone");
      btn.setAttribute("aria-pressed", "false");
      btn.setAttribute("title", "Start microphone");
      btn.setAttribute("aria-label", "Start microphone");
    }
  }

  function syncMicUi(active) {
    recording = !!active;
    setGlobalMicState(active);
    setMicButtonUi(active);
    if (typeof window.refreshRunPromptButtonState === "function") {
      try { window.refreshRunPromptButtonState(); } catch (e) {}
    }
  }

  function updatePromptValue(interimPart) {
    const input = getPromptInput();
    if (!input) return;

    const prefix = baseText ? `${baseText} ` : "";
    const merged = `${prefix}${(finalTranscript + interimPart).trimStart()}`;
    input.value = merged;
    input.selectionStart = input.selectionEnd = input.value.length;

    if (typeof window.autoGrowPromptInput === "function") {
      try { window.autoGrowPromptInput(); } catch (e) {}
    }
    if (typeof window.refreshRunPromptButtonState === "function") {
      try { window.refreshRunPromptButtonState(); } catch (e) {}
    }
  }

  function startSpeechRecognition() {
    if (recording) return;
    const input = getPromptInput();
    baseText = String((input && input.value) || "").replace(/\s+$/, "");
    finalTranscript = "";
    try {
      recognition.start();
    } catch (e) {
      // Ignore duplicate starts from rapid clicks.
    }
  }

  function stopSpeechRecognition() {
    if (!recording) return;
    try {
      recognition.stop();
    } catch (e) {}
  }

  function toggleSpeechRecognition() {
    if (recording) {
      stopSpeechRecognition();
    } else {
      startSpeechRecognition();
    }
  }

  recognition.onstart = () => {
    syncMicUi(true);
  };

  recognition.onend = () => {
    syncMicUi(false);
  };

  recognition.onerror = (event) => {
    console.error("Speech recognition error:", event && event.error);
    if (event && (event.error === "aborted" || event.error === "no-speech" || event.error === "audio-capture")) {
      syncMicUi(false);
    }
  };

  recognition.onresult = (event) => {
    let interimTranscript = "";
    for (let i = event.resultIndex; i < event.results.length; i += 1) {
      const chunk = String((event.results[i] && event.results[i][0] && event.results[i][0].transcript) || "");
      if (event.results[i].isFinal) {
        finalTranscript += chunk;
      } else {
        interimTranscript += chunk;
      }
    }
    updatePromptValue(interimTranscript);
  };

  document.addEventListener("click", (event) => {
    const target = event && event.target;
    if (!target || typeof target.closest !== "function") return;
    const micControl = target.closest("#startSpeechButton, #promptWrapper .llm-recording, .llm-recording");
    if (!micControl) return;
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === "function") {
      event.stopImmediatePropagation();
    }
    toggleSpeechRecognition();
  }, true);

  document.addEventListener("keydown", (event) => {
    if (!event || (event.key !== "Enter" && event.key !== " ")) return;
    const target = event.target;
    if (!target || typeof target.closest !== "function") return;
    const micControl = target.closest("#startSpeechButton, #promptWrapper .llm-recording, .llm-recording");
    if (!micControl) return;
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === "function") {
      event.stopImmediatePropagation();
    }
    toggleSpeechRecognition();
  }, true);

  window.__askOracleSpeechRecognition = recognition;
  window.speechRecognition = recognition;
  window.startSpeechRecognition = startSpeechRecognition;
  window.stopSpeechRecognition = stopSpeechRecognition;
  window.toggleSpeechRecognition = toggleSpeechRecognition;
  syncMicUi(false);
})();
