(function installAskOracleD3Graph() {
  "use strict";

  if (window.__askOracleD3GraphInstalled) return;
  window.__askOracleD3GraphInstalled = true;

  const views = Object.create(null);
  const GRAPH_ID_PATTERN = /^GRAPH_(SOURCE|TARGET|EDGE|VERTEX)_ID$/i;

  function cssEscape(value) {
    return window.CSS && typeof window.CSS.escape === "function"
      ? window.CSS.escape(String(value))
      : String(value).replace(/(["\\])/g, "\\$1");
  }

  function findColumn(columns, patterns) {
    for (const pattern of patterns) {
      const found = columns.find(function (column) { return pattern.test(column); });
      if (found) return found;
    }
    return "";
  }

  function parseIdentity(value) {
    if (value && typeof value === "object") return value;
    try { return JSON.parse(String(value || "")); } catch (error) { return null; }
  }

  function identityKey(value) {
    const parsed = parseIdentity(value);
    if (!parsed) return String(value || "");
    const key = parsed.KEY_VALUE || parsed.key_value || {};
    const keyName = Object.keys(key)[0];
    return keyName ? String(key[keyName]) : String(value || "");
  }

  function propertyRowsToGraph(rows) {
    if (!Array.isArray(rows) || !rows.length) return null;
    const columns = Object.keys(rows[0] || {});
    const sourceGraph = findColumn(columns, [/^GRAPH_SOURCE_ID$/i, /^GRAPH_VERTEX_ID$/i]);
    const targetGraph = findColumn(columns, [/^GRAPH_TARGET_ID$/i]);
    const edgeGraph = findColumn(columns, [/^GRAPH_EDGE_ID$/i]);
    if (!sourceGraph || !targetGraph) return null;

    const sourceBusiness = findColumn(columns, [
      /^(SOURCE|SRC)(_.*)?ID$/i, /^(SOURCE|SRC)_.*NAME$/i
    ]);
    const targetBusiness = findColumn(columns, [
      /^(TARGET|TGT|DEST|DST)(_.*)?ID$/i, /^(TARGET|TGT|DEST|DST)_.*NAME$/i
    ]);
    const edgeBusiness = findColumn(columns.filter(function (column) {
      return !GRAPH_ID_PATTERN.test(column);
    }), [/^(TRANSACTION|TXN|EDGE|TRANSFER)(_.*)?ID$/i]);

    const nodeMap = new Map();
    const links = [];
    function addNode(graphValue, labelValue) {
      const key = identityKey(graphValue);
      if (!key) return "";
      const id = "n:" + key;
      if (!nodeMap.has(id)) {
        nodeMap.set(id, { id: id, label: String(labelValue || key), kind: "property" });
      }
      return id;
    }

    rows.forEach(function (row, index) {
      const source = addNode(row[sourceGraph], sourceBusiness ? row[sourceBusiness] : "");
      const target = addNode(row[targetGraph], targetBusiness ? row[targetBusiness] : "");
      if (!source || !target) return;
      const edgeValue = edgeBusiness ? row[edgeBusiness] : identityKey(row[edgeGraph]);
      links.push({
        id: "e:" + String(edgeValue || index) + ":" + index,
        source: source,
        target: target,
        label: String(edgeValue || "")
      });
    });
    return { nodes: Array.from(nodeMap.values()), links: links };
  }

  function rdfRowsToGraph(rows) {
    if (!Array.isArray(rows) || !rows.length) return null;
    const columns = Object.keys(rows[0] || {});
    const subject = findColumn(columns, [/^SUBJECT$/i, /^S$/i]);
    const predicate = findColumn(columns, [/^PREDICATE$/i, /^P$/i]);
    const object = findColumn(columns, [/^OBJECT$/i, /^O$/i]);
    if (!subject || !predicate || !object) return null;

    const nodeMap = new Map();
    const links = [];
    function addNode(value) {
      const label = String(value == null ? "" : value);
      const id = "rdf:" + label;
      if (!nodeMap.has(id)) nodeMap.set(id, { id: id, label: label, kind: "rdf" });
      return id;
    }
    rows.forEach(function (row, index) {
      links.push({
        id: "rdf-edge:" + index,
        source: addNode(row[subject]),
        target: addNode(row[object]),
        label: String(row[predicate] || "")
      });
    });
    return { nodes: Array.from(nodeMap.values()), links: links };
  }

  function rowsToGraph(rows) {
    return propertyRowsToGraph(rows) || rdfRowsToGraph(rows);
  }

  function getRows(id, callback) {
    const cache = window.__askOracleNl2SqlChartRows || {};
    if (Array.isArray(cache[id]) && cache[id].length) {
      callback(cache[id]);
      return;
    }
    if (!(window.apex && apex.server && typeof apex.server.process === "function")) return;
    apex.server.process("GET_SQL_RESULTS", { x01: id }, {
      dataType: "json",
      success: function (data) {
        const rows = Array.isArray(data && data.results) ? data.results : [];
        window.__askOracleNl2SqlChartRows = window.__askOracleNl2SqlChartRows || {};
        window.__askOracleNl2SqlChartRows[id] = rows;
        callback(rows);
      }
    });
  }

  function serializeSvg(svg) {
    const clone = svg.cloneNode(true);
    clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    return new XMLSerializer().serializeToString(clone);
  }

  function downloadBlob(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function downloadSvg(view) {
    downloadBlob(
      new Blob([serializeSvg(view.svg.node())], { type: "image/svg+xml;charset=utf-8" }),
      "graph-" + view.id + ".svg"
    );
  }

  function downloadPng(view) {
    const svgText = serializeSvg(view.svg.node());
    const source = URL.createObjectURL(new Blob([svgText], { type: "image/svg+xml;charset=utf-8" }));
    const image = new Image();
    image.onload = function () {
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, view.width * 2);
      canvas.height = Math.max(1, view.height * 2);
      const context = canvas.getContext("2d");
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(source);
      canvas.toBlob(function (blob) {
        if (blob) downloadBlob(blob, "graph-" + view.id + ".png");
      }, "image/png");
    };
    image.src = source;
  }

  function applyLayout(view, layoutName) {
    const width = view.width;
    const height = view.height;
    view.simulation.stop();

    if (layoutName === "radial") {
      const radius = Math.min(width, height) * 0.34;
      view.nodes.forEach(function (node, index) {
        const angle = (Math.PI * 2 * index) / Math.max(1, view.nodes.length);
        node.fx = width / 2 + Math.cos(angle) * radius;
        node.fy = height / 2 + Math.sin(angle) * radius;
      });
      view.tick();
      return;
    }

    if (layoutName === "horizontal") {
      view.nodes.forEach(function (node, index) {
        node.fx = 80 + (index % 5) * Math.max(100, (width - 160) / 4);
        node.fy = 90 + Math.floor(index / 5) * 120;
      });
      view.tick();
      return;
    }

    view.nodes.forEach(function (node) { node.fx = null; node.fy = null; });
    view.simulation.alpha(1).restart();
  }

  function createView(id, graph) {
    const block = document.createElement("section");
    block.id = "graphd3-block-" + id;
    block.className = "ask-oracle-graphd3-block";
    block.innerHTML =
      '<div class="ask-oracle-graphd3-toolbar">' +
      '<select class="graphd3-layout" aria-label="Graph layout">' +
      '<option value="force">Force</option><option value="radial">Radial</option>' +
      '<option value="horizontal">Rows</option></select>' +
      '<button type="button" class="t-Button t-Button--small graphd3-fit">Fit</button>' +
      '<button type="button" class="t-Button t-Button--small graphd3-svg">SVG</button>' +
      '<button type="button" class="t-Button t-Button--small graphd3-png">PNG</button>' +
      '</div><div class="ask-oracle-graphd3-canvas"></div>';

    const response = document.getElementById("response-" + id);
    const anchor = document.getElementById("graphcy-block-" + id) ||
      document.getElementById("graph-block-" + id) ||
      document.getElementById("chart-block-" + id) || response;
    if (!anchor || !anchor.parentNode) return null;
    anchor.parentNode.insertBefore(block, anchor.nextSibling);

    const canvas = block.querySelector(".ask-oracle-graphd3-canvas");
    const width = Math.max(640, canvas.clientWidth || 960);
    const height = Math.max(360, canvas.clientHeight || 560);
    const markerId = "graphd3-arrow-" + id.replace(/[^A-Za-z0-9_-]/g, "-");
    const svg = window.d3.select(canvas).append("svg")
      .attr("viewBox", "0 0 " + width + " " + height)
      .attr("width", "100%").attr("height", "100%");
    svg.append("rect").attr("width", width).attr("height", height).attr("fill", "#fff");
    svg.append("defs").append("marker")
      .attr("id", markerId).attr("viewBox", "0 -5 10 10")
      .attr("refX", 30).attr("refY", 0).attr("markerWidth", 6).attr("markerHeight", 6)
      .attr("orient", "auto").append("path").attr("d", "M0,-5L10,0L0,5").attr("fill", "#777");

    const viewport = svg.append("g");
    const links = graph.links.map(function (link) { return Object.assign({}, link); });
    const nodes = graph.nodes.map(function (node) { return Object.assign({}, node); });
    const link = viewport.append("g").selectAll("line").data(links).join("line")
      .attr("stroke", "#858585").attr("stroke-width", 2).attr("marker-end", "url(#" + markerId + ")");
    const edgeLabel = viewport.append("g").selectAll("text").data(links).join("text")
      .attr("font-size", 10).attr("fill", "#555").attr("text-anchor", "middle")
      .text(function (item) { return item.label; });
    const node = viewport.append("g").selectAll("g").data(nodes).join("g");
    node.append("circle").attr("r", 29).attr("fill", "#86bdd0")
      .attr("stroke", "#40788b").attr("stroke-width", 2);
    node.append("text").attr("text-anchor", "middle").attr("dy", 4)
      .attr("font-size", 11).attr("fill", "#17323b")
      .text(function (item) { return item.label; });

    const view = { id: id, block: block, svg: svg, viewport: viewport, width: width, height: height,
      nodes: nodes, links: links, node: node, link: link, edgeLabel: edgeLabel };
    view.tick = function () {
      link.attr("x1", function (item) { return item.source.x; })
        .attr("y1", function (item) { return item.source.y; })
        .attr("x2", function (item) { return item.target.x; })
        .attr("y2", function (item) { return item.target.y; });
      edgeLabel.attr("x", function (item) { return (item.source.x + item.target.x) / 2; })
        .attr("y", function (item) { return (item.source.y + item.target.y) / 2 - 5; });
      node.attr("transform", function (item) { return "translate(" + item.x + "," + item.y + ")"; });
    };
    view.simulation = window.d3.forceSimulation(nodes)
      .force("link", window.d3.forceLink(links).id(function (item) { return item.id; }).distance(150))
      .force("charge", window.d3.forceManyBody().strength(-520))
      .force("center", window.d3.forceCenter(width / 2, height / 2))
      .force("collision", window.d3.forceCollide(55))
      .on("tick", view.tick);

    node.call(window.d3.drag()
      .on("start", function (event, item) {
        if (!event.active) view.simulation.alphaTarget(0.3).restart();
        item.fx = item.x; item.fy = item.y;
      })
      .on("drag", function (event, item) { item.fx = event.x; item.fy = event.y; })
      .on("end", function (event, item) {
        if (!event.active) view.simulation.alphaTarget(0);
        item.fx = null; item.fy = null;
      }));
    svg.call(window.d3.zoom().scaleExtent([0.15, 5]).on("zoom", function (event) {
      viewport.attr("transform", event.transform);
    }));

    views[id] = view;
    block.querySelector(".graphd3-layout").addEventListener("change", function (event) {
      applyLayout(view, event.target.value);
    });
    block.querySelector(".graphd3-fit").addEventListener("click", function () {
      svg.transition().duration(250).call(window.d3.zoom().transform, window.d3.zoomIdentity);
    });
    block.querySelector(".graphd3-svg").addEventListener("click", function () { downloadSvg(view); });
    block.querySelector(".graphd3-png").addEventListener("click", function () { downloadPng(view); });
    return block;
  }

  function toggle(id, button) {
    const existing = document.getElementById("graphd3-block-" + id);
    if (existing) {
      const show = existing.style.display === "none";
      existing.style.display = show ? "block" : "none";
      button.textContent = show ? "Hide GraphD3" : "Show GraphD3";
      return;
    }
    if (!window.d3) {
      if (window.apex && apex.message) apex.message.alert("D3.js is not loaded.");
      return;
    }
    getRows(id, function (rows) {
      const graph = rowsToGraph(rows);
      if (!graph || !graph.nodes.length) {
        if (window.apex && apex.message) apex.message.alert("No graph columns were found in this result.");
        return;
      }
      if (createView(id, graph)) button.textContent = "Hide GraphD3";
    });
  }

  function addButtons() {
    document.querySelectorAll(".llm-conv-show-graph-btn[data-id]").forEach(function (anchor) {
      const id = String(anchor.getAttribute("data-id") || "").trim();
      const parent = anchor.parentNode;
      if (!id || !parent || parent.querySelector('.llm-conv-show-graphd3-btn[data-id="' + cssEscape(id) + '"]')) return;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "t-Button t-Button--small llm-conv-show-graphd3-btn";
      button.setAttribute("data-id", id);
      button.textContent = "Show GraphD3";
      button.addEventListener("click", function (event) {
        event.preventDefault(); event.stopPropagation(); toggle(id, button);
      });
      const graphCyButton = parent.querySelector('.llm-conv-show-graphcy-btn[data-id="' + cssEscape(id) + '"]');
      (graphCyButton || anchor).insertAdjacentElement("afterend", button);
    });
  }

  function installCss() {
    if (document.getElementById("ask-oracle-graphd3-css")) return;
    const style = document.createElement("style");
    style.id = "ask-oracle-graphd3-css";
    style.textContent =
      ".ask-oracle-graphd3-block{position:relative;margin-top:14px;border:1px solid #d7dde5;border-radius:8px;background:#fff;overflow:hidden}" +
      ".ask-oracle-graphd3-canvas{width:100%;height:560px;min-height:320px}" +
      ".ask-oracle-graphd3-canvas svg{display:block;width:100%;height:100%}" +
      ".ask-oracle-graphd3-toolbar{position:absolute;right:12px;bottom:10px;z-index:5;display:flex;gap:6px;align-items:center}" +
      ".graphd3-layout{height:26px;font-size:11px}" +
      ".llm-conv-show-graphd3-btn{height:24px!important;min-height:24px!important;min-width:0!important;padding:2px 6px!important;font-size:10px!important}";
    document.head.appendChild(style);
  }

  function temporarilyAddD3GraphsForPdf() {
    const added = [];
    Object.keys(views).forEach(function (id) {
      const view = views[id];
      const response = document.getElementById("response-" + id);
      if (!response || view.block.style.display === "none") return;
      const holder = document.createElement("div");
      holder.className = "ask-oracle-graphd3-pdf-snapshot";
      holder.style.width = "100%";
      holder.appendChild(view.svg.node().cloneNode(true));
      response.appendChild(holder);
      added.push(holder);
    });
    return function () { added.forEach(function (node) { node.remove(); }); };
  }

  document.addEventListener("click", function (event) {
    const button = event.target.closest && event.target.closest(".export-pdf-response-btn");
    if (!button) return;
    const cleanup = temporarilyAddD3GraphsForPdf();
    window.setTimeout(cleanup, 0);
  }, true);

  installCss();
  addButtons();
  new MutationObserver(addButtons).observe(document.documentElement, { childList: true, subtree: true });
  window.askOracleD3Graph = {
    propertyRowsToGraph: propertyRowsToGraph,
    rdfRowsToGraph: rdfRowsToGraph,
    getView: function (id) { return views[String(id)] || null; }
  };
})();
