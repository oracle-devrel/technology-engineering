(function installAskOracleGraphUiEnhancements() {
  "use strict";

  if (window.__askOracleGraphUiEnhancementsInstalled) return;
  window.__askOracleGraphUiEnhancementsInstalled = true;

  const GRAPH_ID_PATTERN = /^GRAPH_(SOURCE|EDGE|TARGET|VERTEX)_ID$/i;
  const watchedGraphFrames = new WeakSet();

  function isGraphIdentityColumn(name) {
    return GRAPH_ID_PATTERN.test(String(name || "").trim());
  }

  function isNumericValue(value) {
    if (value === null || value === undefined || value === "") return false;
    return Number.isFinite(Number(String(value).replace(/,/g, "").trim()));
  }

  function hideGraphIdentityTableColumns() {
    document.querySelectorAll("table").forEach(function (table) {
      const headers = Array.from(table.querySelectorAll("thead th"));

      headers.forEach(function (header, index) {
        if (!isGraphIdentityColumn(header.textContent)) return;

        header.style.setProperty("display", "none", "important");

        table.querySelectorAll("tbody tr").forEach(function (row) {
          const cell = row.children[index];
          if (cell) cell.style.setProperty("display", "none", "important");
        });
      });
    });
  }

  function temporarilyRemoveGraphIdentityColumns() {
    const removed = [];

    document.querySelectorAll("table").forEach(function (table) {
      const headers = Array.from(table.querySelectorAll("thead th"));
      const indexes = [];

      headers.forEach(function (header, index) {
        if (isGraphIdentityColumn(header.textContent)) indexes.push(index);
      });

      indexes.sort(function (a, b) { return b - a; });
      indexes.forEach(function (index) {
        table.querySelectorAll("tr").forEach(function (row) {
          const cell = row.children[index];
          if (!cell) return;
          removed.push({ cell: cell, parent: row, next: cell.nextSibling });
          cell.remove();
        });
      });
    });

    return function restoreGraphIdentityColumns() {
      removed.reverse().forEach(function (item) {
        item.parent.insertBefore(item.cell, item.next);
      });
    };
  }

  function installGraphExportFilter() {
    document.addEventListener("click", function (event) {
      const button = event.target.closest(
        ".export-pdf-response-btn, .export-excel-response-btn"
      );
      if (!button) return;

      const restore = temporarilyRemoveGraphIdentityColumns();
      window.setTimeout(restore, 0);
    }, true);
  }

  function installGraphExportToolbarStyle(doc) {
    if (!doc || !doc.head || doc.getElementById("ask-oracle-graph-toolbar-position")) {
      return;
    }

    const style = doc.createElement("style");
    style.id = "ask-oracle-graph-toolbar-position";
    style.textContent =
      "#graph-export-toolbar{" +
      "position:absolute!important;" +
      "left:auto!important;" +
      "top:auto!important;" +
      "right:200px!important;" +
      "bottom:8px!important;" +
      "z-index:20!important;" +
      "}";
    doc.head.appendChild(style);
  }

  function positionGraphExportToolbar(doc) {
    if (!doc) return;

    const toolbar = doc.getElementById("graph-export-toolbar");
    const graphContent = doc.getElementById("graphContent") ||
      doc.querySelector(".graph-content, svg") ;
    if (!toolbar || !graphContent) return;

    const host = graphContent.parentElement;
    if (!host) return;

    host.style.setProperty("position", "relative", "important");
    toolbar.style.setProperty("position", "absolute", "important");
    toolbar.style.setProperty("left", "auto", "important");
    toolbar.style.setProperty("top", "auto", "important");
    toolbar.style.setProperty("right", "200px", "important");
    toolbar.style.setProperty("bottom", "8px", "important");
    toolbar.style.setProperty("z-index", "20", "important");
  }

  function installGraphExportToolbarPositioning() {
    installGraphExportToolbarStyle(document);
    positionGraphExportToolbar(document);

    document.querySelectorAll(".ask-oracle-graph-block iframe").forEach(
      function (iframe) {
        if (!watchedGraphFrames.has(iframe)) {
          watchedGraphFrames.add(iframe);
          iframe.addEventListener("load", function () {
            try {
              installGraphExportToolbarStyle(iframe.contentDocument);
              positionGraphExportToolbar(iframe.contentDocument);
            } catch (error) {}
          });
        }

        try {
          installGraphExportToolbarStyle(iframe.contentDocument);
          positionGraphExportToolbar(iframe.contentDocument);
        } catch (error) {}
      }
    );
  }

  function removeGraphIdentityOptions(select) {
    if (!select) return false;

    let changed = false;
    Array.from(select.options).forEach(function (option) {
      if (!isGraphIdentityColumn(option.value) &&
          !isGraphIdentityColumn(option.textContent)) return;

      option.remove();
      changed = true;
    });

    return changed;
  }

  function firstMatchingColumn(columns, patterns) {
    for (const pattern of patterns) {
      const match = columns.find(function (column) {
        return pattern.test(column);
      });
      if (match) return match;
    }
    return "";
  }

  function improveGraphChart(block) {
    const id = String(block.getAttribute("data-id") ||
      (block.id || "").replace(/^chart-block-/, ""));
    const cache = window.__askOracleNl2SqlChartRows || {};
    const rows = cache[id];

    if (!Array.isArray(rows) || !rows.length) return;

    const allColumns = Object.keys(rows[0] || {});
    if (!allColumns.some(isGraphIdentityColumn)) return;

    const columns = allColumns.filter(function (column) {
      return !isGraphIdentityColumn(column);
    });
    if (!columns.length) return;

    const xSelect = block.querySelector(".chart-xaxis");
    const ySelect = block.querySelector(".chart-yaxis");
    const seriesSelect = block.querySelector(".chart-series");

    const optionsChanged = [xSelect, ySelect, seriesSelect].some(
      removeGraphIdentityOptions
    );

    const xColumn = firstMatchingColumn(columns, [
      /^EDGE_ID$/i,
      /^TXN_ID$/i,
      /^TRANSACTION_ID$/i,
      /^TARGET_ID$/i,
      /_ID$/i
    ]) || columns[0];

    const numericColumns = columns.filter(function (column) {
      return rows.some(function (row) {
        return isNumericValue(row[column]);
      });
    });

    const yColumn = firstMatchingColumn(numericColumns, [
      /^AMOUNT$/i,
      /^VALUE$/i,
      /^TOTAL$/i,
      /^COUNT$/i
    ]) || numericColumns.find(function (column) {
      return column !== xColumn;
    }) || numericColumns[0] || "";

    let selectionChanged = false;

    if (xSelect && (!xSelect.value || isGraphIdentityColumn(xSelect.value))) {
      xSelect.value = xColumn;
      selectionChanged = true;
    }

    if (ySelect && yColumn &&
        (!ySelect.value || isGraphIdentityColumn(ySelect.value))) {
      ySelect.value = yColumn;
      selectionChanged = true;
    }

    if ((optionsChanged || selectionChanged) &&
        typeof window.renderAskOracleNl2SqlAggregateChart === "function") {
      window.renderAskOracleNl2SqlAggregateChart(id);
    }
  }

  function applyGraphUiEnhancements() {
    hideGraphIdentityTableColumns();
    document.querySelectorAll(".chart-block").forEach(improveGraphChart);
    installGraphExportToolbarPositioning();
  }

  let scheduled = false;
  function scheduleGraphUiEnhancements() {
    if (scheduled) return;
    scheduled = true;

    window.requestAnimationFrame(function () {
      scheduled = false;
      applyGraphUiEnhancements();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      scheduleGraphUiEnhancements,
      { once: true }
    );
  } else {
    scheduleGraphUiEnhancements();
  }

  installGraphExportFilter();

  new MutationObserver(scheduleGraphUiEnhancements).observe(
    document.documentElement,
    { childList: true, subtree: true }
  );
})();
