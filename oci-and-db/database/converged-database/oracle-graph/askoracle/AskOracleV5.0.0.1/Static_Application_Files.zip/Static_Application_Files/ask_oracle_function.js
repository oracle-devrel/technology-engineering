var askOraclePromptTextareaEl = document.getElementById('P1_PROMPT1');
var ASK_ORACLE_TYPEWRITER_DELAY = 2;
var ASK_ORACLE_TYPEWRITER_DIRECT_RENDER_THRESHOLD = 2000;
var askOracleKnownErrorFilterInstalled = false;

(function applyAskOracleBaseShellPaintEarly() {
  var styleId = "ask-oracle-base-shell-paint";
  var cssText =
    "html,body{background:#f6f8fc!important;}" +
    "body,.t-Body,.t-Body-main,.t-Body-content,.t-Body-contentInner,#t_PageBody{background:#f6f8fc!important;}" +
    ".t-Body-nav,#t_Body_nav,.t-TreeNav,.a-TreeView,.a-TreeView-content{background:#fff!important;}" +
    "#t_Header .t-Header-branding,#t_Header .t-Header-controls,#t_Header .t-Header-logo-link,#t_Header .t-Header-navBar{display:flex!important;align-items:center!important;}" +
    "#t_Header .t-Header-navBar{margin-left:auto!important;justify-content:flex-end!important;}" +
    "#t_Header .t-Header-logo-link .ask-oracle-settings-context::before{content:none!important;display:none!important;}" +
    "#t_Header .t-Header-logo-link .ask-oracle-settings-context{margin-left:24px!important;padding-left:0!important;border-left:0!important;}" +
    "#aoHeaderHomeBtn{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;padding:0 12px!important;border:1px solid #d6deea!important;border-radius:8px!important;background:#fff!important;color:#334155!important;font-size:13px!important;font-weight:600!important;line-height:1!important;text-decoration:none!important;margin-right:16px!important;}" +
    "#aoHeaderHomeBtn:hover{background:#f8fbff!important;border-color:#c7d4e8!important;color:#1e3a8a!important;}";
  try {
    var doc = document;
    if (!doc) return;
    if (doc.getElementById(styleId)) return;
    var styleEl = doc.createElement("style");
    styleEl.id = styleId;
    styleEl.type = "text/css";
    styleEl.appendChild(doc.createTextNode(cssText));
    (doc.head || doc.documentElement).appendChild(styleEl);
  } catch (e) {}
})();

function getAskOracleHomeUrl() {
  try {
    if (window.apex && apex.util && typeof apex.util.makeApplicationUrl === "function") {
      return apex.util.makeApplicationUrl({ pageId: 1 });
    }
  } catch (e1) {}
  try {
    var appId = "";
    var sessionId = "";
    if (window.apex && apex.item) {
      appId = String((apex.item("pFlowId") && apex.item("pFlowId").getValue()) || "").trim();
      sessionId = String((apex.item("pInstance") && apex.item("pInstance").getValue()) || "").trim();
    }
    if (appId) return "f?p=" + appId + ":1:" + sessionId;
  } catch (e2) {}
  return "f?p=&APP_ID.:1:&SESSION.";
}

function isAskOracleSettingsContext() {
  try {
    if (document.getElementById("aoSettings")) return true;
    if (document.body && document.body.classList && document.body.classList.contains("ao-settings-dialog-page")) return true;
    var contextNode = document.querySelector(".ask-oracle-settings-context");
    var contextText = String((contextNode && contextNode.textContent) || "").trim().toLowerCase();
    if (contextText === "settings") return true;
    var href = String(window.location && window.location.href || "").toLowerCase();
    if (href.indexOf("/settings") >= 0 || href.indexOf(":20000:") >= 0 || href.indexOf("p20000_") >= 0) return true;
  } catch (e) {}
  return false;
}

function ensureAskOracleHeaderHomeButton() {
  var navBar = document.querySelector("#t_Header .t-Header-navBar");
  var isSettings = isAskOracleSettingsContext();
  var existing = document.getElementById("aoHeaderHomeBtn");
  if (!navBar) return false;
  if (!isSettings) {
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
    return true;
  }
  if (existing) {
    existing.href = getAskOracleHomeUrl();
    return true;
  }
  var menuBar = navBar.querySelector(".a-MenuBar");
  var homeLink = document.createElement("a");
  homeLink.id = "aoHeaderHomeBtn";
  homeLink.href = getAskOracleHomeUrl();
  homeLink.setAttribute("aria-label", "Home");
  homeLink.textContent = "Home";
  homeLink.addEventListener("click", function(event) {
    event.preventDefault();
    var url = getAskOracleHomeUrl();
    try {
      if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
        apex.navigation.redirect(url);
        return;
      }
    } catch (e3) {}
    window.location.href = url;
  });
  if (menuBar && menuBar.parentNode === navBar) {
    navBar.insertBefore(homeLink, menuBar);
  } else {
    navBar.appendChild(homeLink);
  }
  return true;
}

(function bootstrapAskOracleHeaderHomeButton() {
  var attempts = 0;
  function run() {
    attempts += 1;
    if (ensureAskOracleHeaderHomeButton()) return;
    if (attempts < 20) window.setTimeout(run, 150);
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", run, { once: true });
  } else {
    run();
  }
})();

(function guardAskOracleRepeatedHomeReloads() {
  var themeKey = "ASK_ORACLE_THEME_CHANGED";
  var consumedKey = themeKey + "_CONSUMED";
  var loadKey = "ASK_ORACLE_HOME_LOAD_TIMES";
  try {
    var now = Date.now();
    var raw = sessionStorage.getItem(loadKey);
    var recentLoads = [];
    try { recentLoads = JSON.parse(raw || "[]"); } catch (e1) { recentLoads = []; }
    recentLoads = (Array.isArray(recentLoads) ? recentLoads : [])
      .map(Number)
      .filter(function(ts) { return isFinite(ts) && now - ts < 10000; });
    recentLoads.push(now);
    sessionStorage.setItem(loadKey, JSON.stringify(recentLoads.slice(-8)));

    if (/firefox/i.test(navigator.userAgent || "") || recentLoads.length >= 3) {
      if (sessionStorage.getItem(themeKey) === "Y") {
        sessionStorage.removeItem(themeKey);
        sessionStorage.setItem(consumedKey, "Y");
      }
    }
  } catch (e2) {}
})();

(function applyAskOracleSessionThemeMode() {
  var themeModeKey = "ASK_ORACLE_SETTINGS_THEME_MODE_V1";

  function applyLightThemeClasses() {
    var roots = [document.documentElement, document.body];
    roots.forEach(function(node) {
      if (!node || !node.classList) return;
      node.classList.remove("ask-oracle-dark-ui", "u-Theme--dark", "t-Body--dark", "dark-mode", "theme-dark", "is-dark");
      node.classList.add("u-Theme--light");
      node.setAttribute("data-theme", "light");
      try { node.style.colorScheme = "light"; } catch (e) {}
    });
  }

  try { sessionStorage.setItem(themeModeKey, "light"); } catch (e) {}
  applyLightThemeClasses();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", applyLightThemeClasses, { once: true });
  }
})();

function shouldSuppressAskOracleKnownError(message, source) {
  const text = `${String(message || "")} ${String(source || "")}`.toLowerCase();
  if (!text.trim()) return false;

  if (text.indexOf("textarea is not defined") >= 0) return true;
  if (text.indexOf("chartjs-plugin-funnel") >= 0) return true;
  if (
    text.indexOf("cannot read properties of undefined") >= 0 &&
    text.indexOf("elements") >= 0
  ) {
    return true;
  }
  if (
    text.indexOf("speechrecognition.js") >= 0 &&
    text.indexOf("cannot set properties of null") >= 0 &&
    text.indexOf("onclick") >= 0
  ) {
    return true;
  }
  if (
    text.indexOf("cannot read properties of null") >= 0 &&
    text.indexOf("addeventlistener") >= 0
  ) {
    return true;
  }
  return false;
}

function installAskOracleKnownErrorFilter() {
  if (askOracleKnownErrorFilterInstalled) return;
  askOracleKnownErrorFilterInstalled = true;

  if (typeof window.textarea === "undefined") {
    window.textarea = askOraclePromptTextareaEl || null;
  }
  document.addEventListener("DOMContentLoaded", function() {
    const el = document.getElementById("P1_PROMPT1");
    if (el) window.textarea = el;
  }, { once: true });

  window.addEventListener("error", function(event) {
    const message = event && event.message ? event.message : "";
    const source = event && event.filename ? event.filename : "";
    if (!shouldSuppressAskOracleKnownError(message, source)) return;
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
  }, true);

  window.addEventListener("unhandledrejection", function(event) {
    const reason = event && Object.prototype.hasOwnProperty.call(event, "reason") ? event.reason : "";
    const message =
      reason && typeof reason === "object"
        ? (reason.message || reason.stack || JSON.stringify(reason))
        : String(reason || "");
    if (!shouldSuppressAskOracleKnownError(message, "")) return;
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
  }, true);
}

installAskOracleKnownErrorFilter();

var askOraclePromptCoreBootstrapTimer = null;
var askOraclePromptCoreBootstrapAttempts = 0;
var ASK_ORACLE_PROMPT_CORE_BOOTSTRAP_MAX_ATTEMPTS = 50;

function getAskOraclePromptRootElement() {
  return (
    document.getElementById("promptWrapper") ||
    document.getElementById("P1_PROMPT2") ||
    document.getElementById("P1_PROMPT2_CONTAINER") ||
    document.getElementById("P1_PROMPT2_display") ||
    document.getElementById("P1_PROMP2") ||
    document.getElementById("P1_PROMP2_CONTAINER") ||
    document.getElementById("P1_PROMP2_display") ||
    document
  );
}

function ensureAskOraclePromptCoreElements() {
  const root = getAskOraclePromptRootElement();

  const safeQuery = (selector) => {
    try {
      return root && typeof root.querySelector === "function"
        ? root.querySelector(selector)
        : document.querySelector(selector);
    } catch (e) {
      return null;
    }
  };

  const mapIdIfMissing = (selector, id) => {
    const existing = document.getElementById(id);
    if (existing) return existing;
    const el = safeQuery(selector) || document.querySelector(selector);
    if (el && !el.id) el.id = id;
    return document.getElementById(id) || el || null;
  };

  const promptInput = mapIdIfMissing(
    "#P1_PROMPT1, textarea[name='P1_PROMPT'], textarea, input[type='text']",
    "P1_PROMPT1"
  );
  if (promptInput && !promptInput.getAttribute("name")) {
    promptInput.setAttribute("name", "P1_PROMPT");
  }

  mapIdIfMissing(
    "#addPrompt, .llm-plus-button, button[title*='conversation' i], button[aria-label*='conversation' i]",
    "addPrompt"
  );
  const runBtn = mapIdIfMissing(
    "#runPrompt, .llm-run-button, button[title*='run prompt' i], button[aria-label*='run prompt' i]",
    "runPrompt"
  );
  if (runBtn && !runBtn.getAttribute("type")) {
    runBtn.setAttribute("type", "button");
  }

  const micBtn =
    document.getElementById("startSpeechButton") ||
    mapIdIfMissing(
      "#startSpeechButton, .llm-recording, [aria-label*='dictate' i], [title*='dictate' i], [aria-label*='mic' i], [title*='mic' i]",
      "startSpeechButton"
    );
  if (micBtn && !micBtn.getAttribute("role")) {
    micBtn.setAttribute("role", "button");
  }
}

function bootstrapAskOraclePromptCoreElementsWithRetry() {
  ensureAskOraclePromptCoreElements();

  const hasPrompt = !!document.getElementById("P1_PROMPT1");
  const hasRun = !!document.getElementById("runPrompt");
  if (hasPrompt && hasRun) {
    askOraclePromptCoreBootstrapAttempts = 0;
    if (askOraclePromptCoreBootstrapTimer) {
      clearTimeout(askOraclePromptCoreBootstrapTimer);
      askOraclePromptCoreBootstrapTimer = null;
    }
    return;
  }

  if (askOraclePromptCoreBootstrapAttempts >= ASK_ORACLE_PROMPT_CORE_BOOTSTRAP_MAX_ATTEMPTS) return;
  askOraclePromptCoreBootstrapAttempts += 1;
  if (askOraclePromptCoreBootstrapTimer) clearTimeout(askOraclePromptCoreBootstrapTimer);
  askOraclePromptCoreBootstrapTimer = setTimeout(bootstrapAskOraclePromptCoreElementsWithRetry, 200);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bootstrapAskOraclePromptCoreElementsWithRetry, { once: true });
} else {
  bootstrapAskOraclePromptCoreElementsWithRetry();
}
if (window.apex && apex.jQuery) {
  apex.jQuery(document).on("apexafterrefresh", bootstrapAskOraclePromptCoreElementsWithRetry);
}

var ASK_ORACLE_UI_SYNC_KEY = "ASK_ORACLE_UI_SYNC_V1";
var ASK_ORACLE_SYNC_SELECTED_NL2SQL = "selected_nl2sql_profile";
var ASK_ORACLE_SYNC_SELECTED_RAG = "selected_rag_profile";
var ASK_ORACLE_SYNC_SELECTED_AGENT = "selected_agent_team";
var ASK_ORACLE_SYNC_DEFAULT_CONV_MODE = "default_conversation_mode";
var ASK_ORACLE_INLINE_ICON_STYLE_ID = "ask-oracle-inline-icon-css";
var ASK_ORACLE_RUNTIME_LOGO_STYLE_ID = "ask-oracle-runtime-logo-css";
var ASK_ORACLE_FONT_AWESOME_LINK_ID = "ask-oracle-font-awesome-css";
var ASK_ORACLE_MODE_CHIP_ID = "askOracleSelectedModeChip";
var askOracleModeChipLastMode = "";
var askOracleAdminUiStateTimerIds = [];
var askOracleAdminSetupModalOpen = false;
var askOracleAdminSetupCompleted = false;
var askOracleAdminSetupCheckPromise = null;
var ASK_ORACLE_ADMIN_SETUP_DISMISS_KEY = "ASK_ORACLE_ADMIN_SETUP_DISMISSED_V2";

function ensureAskOracleFontAwesomeCss() {
  if (document.getElementById(ASK_ORACLE_FONT_AWESOME_LINK_ID)) return;
  var primaryHref = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css";
  var fallbackHref = "https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css";
  var link = document.createElement("link");
  link.id = ASK_ORACLE_FONT_AWESOME_LINK_ID;
  link.rel = "stylesheet";
  link.href = primaryHref;
  link.crossOrigin = "anonymous";
  link.referrerPolicy = "no-referrer";
  link.onerror = function() {
    if (link.getAttribute("data-fallback-applied") === "true") return;
    link.setAttribute("data-fallback-applied", "true");
    link.href = fallbackHref;
  };
  document.head.appendChild(link);
}

ensureAskOracleFontAwesomeCss();

function ensureAskOracleInlineIconCss() {
  if (document.getElementById(ASK_ORACLE_INLINE_ICON_STYLE_ID)) return;
  var style = document.createElement("style");
  style.id = ASK_ORACLE_INLINE_ICON_STYLE_ID;
  style.textContent = `
    .ask-oracle-inline-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 1.05em;
      height: 1.05em;
      min-width: 1.05em;
      line-height: 1;
      vertical-align: -0.12em;
      color: currentColor;
    }
    .ask-oracle-inline-icon svg {
      width: 100%;
      height: 100%;
      display: block;
      overflow: visible;
      shape-rendering: geometricPrecision;
    }
    .ask-oracle-inline-icon svg path,
    .ask-oracle-inline-icon svg circle,
    .ask-oracle-inline-icon svg rect,
    .ask-oracle-inline-icon svg line,
    .ask-oracle-inline-icon svg polyline,
    .ask-oracle-inline-icon svg polygon {
      fill: none;
      stroke: currentColor;
      stroke-width: 1.85;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    .ask-oracle-inline-icon svg text {
      font-size: 4.15px;
      font-weight: 800;
      font-family: "Segoe UI", Arial, sans-serif;
      letter-spacing: 0.18px;
    }
    .ask-oracle-inline-icon.ask-oracle-icon-pdf,
    .ask-oracle-inline-icon.ask-oracle-icon-excel {
      color: currentColor;
    }
    .ask-oracle-inline-icon.ask-oracle-icon-pdf svg .ask-oracle-icon-file,
    .ask-oracle-inline-icon.ask-oracle-icon-excel svg .ask-oracle-icon-file {
      fill: none;
      stroke: currentColor;
    }
    .ask-oracle-inline-icon.ask-oracle-icon-pdf svg .ask-oracle-icon-fold,
    .ask-oracle-inline-icon.ask-oracle-icon-excel svg .ask-oracle-icon-fold {
      stroke: currentColor;
    }
    .ask-oracle-inline-icon.ask-oracle-icon-pdf svg text,
    .ask-oracle-inline-icon.ask-oracle-icon-excel svg text {
      fill: currentColor;
    }
    .ask-oracle-inline-icon.ask-oracle-icon-share {
      width: 1.25em;
      height: 1.25em;
      min-width: 1.25em;
    }
    .speech-icon-button .ask-oracle-inline-icon,
    .t-Button .ask-oracle-inline-icon,
    .menu-icon.ask-oracle-inline-icon {
      flex: 0 0 auto;
    }
  `;
  document.head.appendChild(style);
}

function ensureAskOracleRuntimeLogoCss() {
  if (document.getElementById(ASK_ORACLE_RUNTIME_LOGO_STYLE_ID)) return;
  var style = document.createElement("style");
  style.id = ASK_ORACLE_RUNTIME_LOGO_STYLE_ID;
  style.textContent = `
    .t-Header,
    #t_Header,
    header.t-Header,
    .a-Header,
    .t-Body-topNav,
    #t_Header.t-Header,
    #t_Header.t-Header .t-Header-branding,
    #t_Header .t-Header-branding,
    #t_Header .t-Header-nav,
    #t_Header .t-Header-logo,
    #t_Header .t-Header-navBar,
    #t_Header .t-Header-controls,
    #t_Header .t-Header-controlsIcon {
      border-bottom: 0 !important;
      border-bottom-color: transparent !important;
      border-top: 0 !important;
      box-shadow: none !important;
      -webkit-box-shadow: none !important;
      background-image: none !important;
      outline: 0 !important;
    }
    #t_Header .t-Header-branding,
    #t_Header .t-Header-branding * {
      border-bottom-color: transparent !important;
    }
    #t_Header::before,
    #t_Header::after,
    #t_Header .t-Header-branding::before,
    #t_Header .t-Header-branding::after,
    .t-Header::before,
    .t-Header::after {
      content: none !important;
      border: 0 !important;
      box-shadow: none !important;
    }
    #t_Body_content,
    #t_Body_content_offset {
      border-top: 0 !important;
      box-shadow: none !important;
    }
    .t-Header-logo-link .ask-oracle-custom-app-logo {
      display: inline-flex;
      width: 32px;
      height: 32px;
      max-width: 32px;
      max-height: 32px;
      object-fit: contain;
      margin-right: 10px;
      vertical-align: middle;
    }
    .t-Header-logo-link.ask-oracle-custom-logo-active .t-Header-logo-img,
    .t-Header-logo-link.ask-oracle-custom-logo-active .apex-logo-img {
      display: none !important;
    }
  `;
  document.head.appendChild(style);
}

function getAskOracleInlineSvgIcon(name, extraClassName) {
  ensureAskOracleInlineIconCss();
  var safeName = String(name || "").trim().toLowerCase();
  var safeExtraClassName = String(extraClassName || "").trim();
  var className = "ask-oracle-inline-icon" + (safeExtraClassName ? " " + safeExtraClassName : "");
  var iconSvgByName = {
    code: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="M5.7 4.3 2.9 8l2.8 3.7" />
        <path d="M10.3 4.3 13.1 8l-2.8 3.7" />
        <path d="M9.05 2.6 6.95 13.4" />
      </svg>
    `,
    search: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <circle cx="7" cy="7" r="4.35" />
        <path d="m10.35 10.35 3.1 3.1" />
      </svg>
    `,
    lightbulb: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="M8 2.2a4.3 4.3 0 0 0-2.9 7.48c.62.53 1 1.31 1 2.12V12h3.8v-.2c0-.81.38-1.59 1-2.12A4.3 4.3 0 0 0 8 2.2Z" />
        <path d="M6.2 13.15h3.6" />
        <path d="M6.7 14.55h2.6" />
      </svg>
    `,
    clock: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <circle cx="8" cy="8" r="5.45" />
        <path d="M8 4.85v3.4l2.3 1.45" />
      </svg>
    `,
    trash: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="M3.5 4.2h9" />
        <path d="M6 4.2V3.2a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v1" />
        <path d="M4.7 4.2 5.3 13a1 1 0 0 0 1 .9h3.4a1 1 0 0 0 1-.9l.6-8.8" />
        <path d="M6.8 6.35v4.7" />
        <path d="M9.2 6.35v4.7" />
      </svg>
    `,
    volume: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="M3.15 9.75H5.5L8.3 12V4L5.5 6.25H3.15Z" />
        <path d="M10.15 6.2a2.9 2.9 0 0 1 0 3.6" />
        <path d="M11.8 4.75a5 5 0 0 1 0 6.5" />
      </svg>
    `,
    play: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="M5.35 4.15 11.55 8l-6.2 3.85Z" />
      </svg>
    `,
    pause: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="M5.85 4.2v7.6" />
        <path d="M10.15 4.2v7.6" />
      </svg>
    `,
    "play-circle": `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <circle cx="8" cy="8" r="5.45" />
        <path d="M7 5.85 10.15 8 7 10.15Z" />
      </svg>
    `,
    pdf: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path class="ask-oracle-icon-file" d="M4 1.7h5.15L12.7 5.25V14a1 1 0 0 1-1 1H4A1 1 0 0 1 3 14V2.7a1 1 0 0 1 1-1Z" />
        <path class="ask-oracle-icon-fold" d="M9.15 1.7v3.55h3.55" />
        <text x="8" y="11.1" text-anchor="middle">PDF</text>
      </svg>
    `,
    excel: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path class="ask-oracle-icon-file" d="M4 1.7h5.15L12.7 5.25V14a1 1 0 0 1-1 1H4A1 1 0 0 1 3 14V2.7a1 1 0 0 1 1-1Z" />
        <path class="ask-oracle-icon-fold" d="M9.15 1.7v3.55h3.55" />
        <text x="8" y="11.1" text-anchor="middle">XLS</text>
      </svg>
    `,
    copy: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <rect x="5.25" y="3.2" width="7" height="9" rx="1.2" />
        <path d="M3.5 10.8h-.2a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1H9a1 1 0 0 1 1 1v.2" />
      </svg>
    `,
    check: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="m3.1 8.3 2.9 2.9L12.9 4.3" />
      </svg>
    `,
    download: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="M8 2.4v6.8" />
        <path d="m5.2 7.7 2.8 2.9 2.8-2.9" />
        <path d="M3.1 11.9v.9a1 1 0 0 0 1 1h7.8a1 1 0 0 0 1-1v-.9" />
      </svg>
    `,
    share: `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true">
        <path d="M8.8 4.2h2.95v2.95" />
        <path d="M11.75 4.25 7.3 8.7" />
        <path d="M4.2 6.35v5.45a1 1 0 0 0 1 1h5.45a1 1 0 0 0 1-1V9.2" />
      </svg>
    `
  };
  return `<span class="${className}" aria-hidden="true">${iconSvgByName[safeName] || iconSvgByName.code}</span>`;
}

function parseAskOracleUiSyncRaw(raw) {
  if (!raw) return {};
  try {
    var parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (e) {
    return {};
  }
}

function parseAskOracleJsonArraySafe(rawValue) {
  if (rawValue == null) return [];
  var text = String(rawValue).trim();
  if (!text) return [];
  try {
    var parsed = JSON.parse(text);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

function getAskOracleUiSyncUpdatedAt(state) {
  if (!state || typeof state !== "object") return 0;
  var ts = Number(state.updated_at);
  return isFinite(ts) ? ts : 0;
}

function readAskOracleUiSyncState() {
  var sessionRaw = null;
  var localRaw = null;
  try { sessionRaw = sessionStorage.getItem(ASK_ORACLE_UI_SYNC_KEY); } catch (e1) {}
  try { localRaw = localStorage.getItem(ASK_ORACLE_UI_SYNC_KEY); } catch (e2) {}
  var sessionState = parseAskOracleUiSyncRaw(sessionRaw);
  var localState = parseAskOracleUiSyncRaw(localRaw);
  var state = getAskOracleUiSyncUpdatedAt(sessionState) >= getAskOracleUiSyncUpdatedAt(localState)
    ? sessionState
    : localState;
  var currentUser = getAskOracleRuntimeAppUser();
  var syncUser = String((state && state.app_user) || "").trim().toUpperCase();
  if (currentUser && syncUser && syncUser !== currentUser) return {};
  if (!syncUser && state && state.admin_config && typeof state.admin_config === "object") return {};
  return state;
}

function getAskOracleUiSyncValue(key) {
  var state = readAskOracleUiSyncState();
  if (!state || typeof state !== "object") return "";
  return String(state[key] == null ? "" : state[key]).trim();
}

function dispatchAskOracleUiSyncChange(state) {
  var targets = [];
  var seen = [];
  var addTarget = function(target) {
    if (!target) return;
    if (seen.indexOf(target) >= 0) return;
    seen.push(target);
    targets.push(target);
  };

  addTarget(window);
  try { addTarget(window.parent); } catch (e1) {}
  try { addTarget(window.top); } catch (e2) {}
  try {
    for (var i = 0; i < window.frames.length; i += 1) {
      addTarget(window.frames[i]);
    }
  } catch (e3) {}

  targets.forEach(function(target) {
    try {
      var CustomEventCtor = typeof target.CustomEvent === "function" ? target.CustomEvent : CustomEvent;
      target.dispatchEvent(new CustomEventCtor("askoracleuisyncchange", {
        detail: { state: state }
      }));
    } catch (e4) {}
  });
}

function persistAskOracleUiSyncState(patch) {
  if (!patch || typeof patch !== "object") return;
  var next = readAskOracleUiSyncState();
  Object.keys(patch).forEach(function(key) {
    next[key] = patch[key];
  });
  var appUser = getAskOracleRuntimeAppUser();
  if (appUser) next.app_user = appUser;
  next.updated_at = String(Date.now());
  var payload = JSON.stringify(next);
  try { sessionStorage.setItem(ASK_ORACLE_UI_SYNC_KEY, payload); } catch (e1) {}
  try { localStorage.setItem(ASK_ORACLE_UI_SYNC_KEY, payload); } catch (e2) {}
  dispatchAskOracleUiSyncChange(next);
}

function getAskOracleAdminConfigSnapshot() {
  var base = window.ASK_ORACLE_ADMIN_CONFIG && typeof window.ASK_ORACLE_ADMIN_CONFIG === "object"
    ? window.ASK_ORACLE_ADMIN_CONFIG
    : {};
  var syncState = readAskOracleUiSyncState();
  var syncAdmin = syncState && syncState.admin_config && typeof syncState.admin_config === "object"
    ? syncState.admin_config
    : {};
  var merged = mergeAskOracleAdminConfig(base, syncAdmin);
  var baseAdminOwners = normalizeAskOracleAdminOwnersCsv(
    Object.prototype.hasOwnProperty.call(base, "ADMIN_OWNER_APP_USER")
      ? base.ADMIN_OWNER_APP_USER
      : base.admin_owner_app_user
  );
  var mergedAdminOwners = normalizeAskOracleAdminOwnersCsv(
    Object.prototype.hasOwnProperty.call(merged, "ADMIN_OWNER_APP_USER")
      ? merged.ADMIN_OWNER_APP_USER
      : merged.admin_owner_app_user
  );
  var baseHasAdminOwnersKey =
    Object.prototype.hasOwnProperty.call(base, "ADMIN_OWNER_APP_USER") ||
    Object.prototype.hasOwnProperty.call(base, "admin_owner_app_user");
  if (baseHasAdminOwnersKey) {
    // Backend bootstrap value is authoritative for admin owners.
    // Prevent stale local/session sync from masking a missing/blank DB row.
    merged.ADMIN_OWNER_APP_USER = baseAdminOwners;
  }
  if (!mergedAdminOwners && baseAdminOwners) {
    merged.ADMIN_OWNER_APP_USER = baseAdminOwners;
  }
  return merged;
}

function copyAskOracleAuthoritativeConfigKeys(target, source) {
  if (!target || !source || typeof source !== "object") return;
  [
    "ADMIN_OWNER_APP_USER",
    "admin_owner_app_user",
    "DEVELOPER_OWNER_APP_USER",
    "developer_owner_app_user",
    "USER_OWNER_APP_USER",
    "user_owner_app_user",
    "USER_ROLE",
    "user_role",
    "CURRENT_USER_ROLE",
    "current_user_role",
    "CURRENT_APP_USER",
    "current_app_user",
    "APP_USER",
    "app_user",
    "SHOW_OPEN_IN_EDITOR",
    "show_open_in_editor",
    "SHOW_AGENT_THOUGHTS",
    "show_agent_thoughts",
    "SHOW_EXPORT_PDF",
    "show_export_pdf",
    "SHOW_EXPORT_PDF_BUTTON",
    "show_export_pdf_button",
    "SHOW_PDF_EXPORT",
    "show_pdf_export",
    "ENABLE_EXPORT_PDF",
    "enable_export_pdf",
    "ENABLE_PDF_EXPORT",
    "enable_pdf_export",
    "SHOW_EXPORT_EXCEL",
    "show_export_excel",
    "SHOW_EXPORT_EXCEL_BUTTON",
    "show_export_excel_button",
    "SHOW_EXCEL_EXPORT",
    "show_excel_export",
    "ENABLE_EXPORT_EXCEL",
    "enable_export_excel",
    "ENABLE_EXCEL_EXPORT",
    "enable_excel_export",
    "SHOW_CONVERSATION_TIMER",
    "show_conversation_timer",
    "SHOW_CONVERSATION_TIMER_BUTTON",
    "show_conversation_timer_button",
    "SHOW_TIMER_BUTTON",
    "show_timer_button",
    "ENABLE_CONVERSATION_TIMER",
    "enable_conversation_timer",
    "ENABLE_TIMER_BUTTON",
    "enable_timer_button",
    "SHOW_DELETE_PROMPT",
    "show_delete_prompt",
    "SHOW_DELETE_PROMPT_BUTTON",
    "show_delete_prompt_button",
    "SHOW_DELETE_BUTTON",
    "show_delete_button",
    "ENABLE_DELETE_PROMPT",
    "enable_delete_prompt",
    "ENABLE_DELETE_BUTTON",
    "enable_delete_button",
    "ENABLE_END_USER_SWITCH_CONV_STYLE",
    "enable_end_user_switch_conv_style",
    "ENABLE_END_USER_SWITCH_PROFILES_AGENTS",
    "enable_end_user_switch_profiles_agents",
    "ENABLE_END_USER_SWITCH_NL2SQL_PROFILE",
    "enable_end_user_switch_nl2sql_profile",
    "SHOW_END_USER_NL2SQL_PROFILE",
    "show_end_user_nl2sql_profile",
    "SHOW_NL2SQL_PROFILE_SWITCH",
    "show_nl2sql_profile_switch",
    "ENABLE_END_USER_SWITCH_RAG_PROFILE",
    "enable_end_user_switch_rag_profile",
    "SHOW_END_USER_RAG_PROFILE",
    "show_end_user_rag_profile",
    "SHOW_RAG_PROFILE_SWITCH",
    "show_rag_profile_switch",
    "DEFAULT_CONVERSATION_MODE",
    "default_conversation_mode",
    "AI_INFO_MESSAGE",
    "ai_info_message"
  ].forEach(function(key) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      target[key] = source[key];
    }
  });
}

function mergeAskOracleAdminConfig(base, syncAdmin) {
  var merged = Object.assign({}, base || {}, syncAdmin || {});
  // Fresh backend bootstrap config must win for action controls; stale browser
  // sync should not keep end-user switches hidden after APP_CONFIG is changed.
  copyAskOracleAuthoritativeConfigKeys(merged, base);
  return merged;
}

function normalizeAskOracleAdminFlag(value, fallbackValue) {
  if (value == null || value === "") return !!fallbackValue;
  if (value === true || value === false) return value;
  var text = String(value).trim().toUpperCase();
  var normalized = text.replace(/[^A-Z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  if (
    text === "Y" ||
    text === "YES" ||
    text === "TRUE" ||
    text === "1" ||
    normalized === "SHOW" ||
    normalized === "SHOWN" ||
    normalized === "VISIBLE" ||
    normalized === "ENABLED" ||
    normalized === "ENABLE" ||
    normalized === "SHOW_TO_ALL" ||
    normalized === "SHOW_TO_ALL_USERS" ||
    normalized === "SHOW_ALL_USERS" ||
    normalized === "ALL_USERS" ||
    normalized === "ALL"
  ) return true;
  if (
    text === "N" ||
    text === "NO" ||
    text === "FALSE" ||
    text === "0" ||
    normalized === "HIDE" ||
    normalized === "HIDDEN" ||
    normalized === "DISABLED" ||
    normalized === "DISABLE" ||
    normalized === "DO_NOT_SHOW" ||
    normalized === "DONT_SHOW" ||
    normalized === "NONE"
  ) return false;
  return !!fallbackValue;
}

function getAskOracleBootstrapValue(data, lowerKey, upperKey) {
  if (!data || typeof data !== "object") return "";
  if (lowerKey && Object.prototype.hasOwnProperty.call(data, lowerKey)) return data[lowerKey];
  if (upperKey && Object.prototype.hasOwnProperty.call(data, upperKey)) return data[upperKey];
  return "";
}

function getAskOracleBootstrapFlag(data, keys, fallbackValue) {
  var list = Array.isArray(keys) ? keys : [keys];
  for (var i = 0; i < list.length; i += 1) {
    var key = String(list[i] || "").trim();
    if (!key || !data || !Object.prototype.hasOwnProperty.call(data, key)) continue;
    var raw = data[key];
    if (raw == null || String(raw).trim() === "") continue;
    return normalizeAskOracleAdminFlag(raw, fallbackValue);
  }
  return !!fallbackValue;
}

function getAskOracleAdminFlag(configKey, fallbackValue) {
  var cfg = getAskOracleAdminConfigSnapshot();
  var key = String(configKey || "").trim();
  var lowerKey = key.toLowerCase();
  var value = null;
  if (cfg && Object.prototype.hasOwnProperty.call(cfg, key)) {
    value = cfg[key];
  } else if (cfg && lowerKey && Object.prototype.hasOwnProperty.call(cfg, lowerKey)) {
    value = cfg[lowerKey];
  }
  return normalizeAskOracleAdminFlag(value, fallbackValue);
}

function getAskOracleAdminFlagAny(configKeys, fallbackValue) {
  var keys = Array.isArray(configKeys) ? configKeys : [configKeys];
  var cfg = getAskOracleAdminConfigSnapshot();
  if (!cfg || typeof cfg !== "object") return !!fallbackValue;
  for (var i = 0; i < keys.length; i += 1) {
    var key = String(keys[i] || "").trim();
    if (!key) continue;
    var lowerKey = key.toLowerCase();
    var hasKey = Object.prototype.hasOwnProperty.call(cfg, key);
    var hasLowerKey = lowerKey && Object.prototype.hasOwnProperty.call(cfg, lowerKey);
    if (!hasKey && !hasLowerKey) continue;
    var value = hasKey ? cfg[key] : cfg[lowerKey];
    if (value == null || value === "") continue;
    return normalizeAskOracleAdminFlag(value, fallbackValue);
  }
  return !!fallbackValue;
}

function getAskOracleAdminText(configKey, fallbackValue) {
  var cfg = getAskOracleAdminConfigSnapshot();
  var value = cfg && Object.prototype.hasOwnProperty.call(cfg, configKey) ? cfg[configKey] : null;
  var text = String(value == null ? "" : value).trim();
  if (text) return text;
  return String(fallbackValue == null ? "" : fallbackValue).trim();
}

function getAskOracleRuntimeAppUser() {
  var candidates = [];
  try { if (window.apex && apex.env && apex.env.APP_USER) candidates.push(apex.env.APP_USER); } catch (e1) {}
  try { if (window.apex && apex.item) candidates.push(apex.item("APP_USER").getValue()); } catch (e2) {}
  try { if (typeof window.$v === "function") candidates.push(window.$v("APP_USER")); } catch (e3) {}
  try { candidates.push(window.ASK_ORACLE_ADMIN_CONFIG && window.ASK_ORACLE_ADMIN_CONFIG.CURRENT_APP_USER); } catch (e4) {}
  try { candidates.push(window.ASK_ORACLE_ADMIN_CONFIG && window.ASK_ORACLE_ADMIN_CONFIG.current_app_user); } catch (e5) {}
  try { candidates.push(window.ASK_ORACLE_ADMIN_CONFIG && window.ASK_ORACLE_ADMIN_CONFIG.APP_USER); } catch (e6) {}
  try { candidates.push(window.ASK_ORACLE_ADMIN_CONFIG && window.ASK_ORACLE_ADMIN_CONFIG.app_user); } catch (e7) {}
  try { candidates.push(window.APP_USER); } catch (e8) {}
  try { candidates.push(window.appUser); } catch (e9) {}
  try { candidates.push(document.body && document.body.getAttribute("data-app-user")); } catch (e10) {}
  for (var i = 0; i < candidates.length; i += 1) {
    var value = String(candidates[i] == null ? "" : candidates[i]).trim();
    if (value) return value.toUpperCase();
  }
  return "";
}

function getAskOracleConfigCsvValue(cfg, upperKey, lowerKey) {
  if (!cfg || typeof cfg !== "object") return "";
  if (Object.prototype.hasOwnProperty.call(cfg, upperKey)) return cfg[upperKey];
  if (Object.prototype.hasOwnProperty.call(cfg, lowerKey)) return cfg[lowerKey];
  return "";
}

function isAskOracleRuntimeUserInCsv(rawValue) {
  var appUser = getAskOracleRuntimeAppUser();
  if (!appUser) return false;
  var owners = normalizeAskOracleAdminOwnersCsv(rawValue)
    .split(",")
    .map(function(item) { return String(item || "").trim().toUpperCase(); })
    .filter(Boolean);
  return owners.indexOf(appUser) >= 0;
}

function getAskOracleRuntimeUserRole() {
  var cfg = getAskOracleAdminConfigSnapshot();
  var explicitRole = String(
    getAskOracleConfigCsvValue(cfg, "USER_ROLE", "user_role") ||
    getAskOracleConfigCsvValue(cfg, "CURRENT_USER_ROLE", "current_user_role")
  ).trim().toUpperCase();
  var adminOwners = getAskOracleConfigCsvValue(cfg, "ADMIN_OWNER_APP_USER", "admin_owner_app_user");
  var developerOwners = getAskOracleConfigCsvValue(cfg, "DEVELOPER_OWNER_APP_USER", "developer_owner_app_user");
  var userOwners = getAskOracleConfigCsvValue(cfg, "USER_OWNER_APP_USER", "user_owner_app_user");

  if (isAskOracleRuntimeUserInCsv(adminOwners)) return "ADMIN";
  if (isAskOracleRuntimeUserInCsv(developerOwners)) return "DEVELOPER";
  if (isAskOracleRuntimeUserInCsv(userOwners)) return "USER";
  if (explicitRole === "ADMIN" || explicitRole === "DEVELOPER" || explicitRole === "USER") return explicitRole;
  return "USER";
}

function buildAskOracleHomeAdminConfig(data) {
  var cfg = data && typeof data === "object" ? data : {};
  var adminOwners = normalizeAskOracleAdminOwnersCsv(getAskOracleBootstrapValue(cfg, "admin_owner_app_user", "ADMIN_OWNER_APP_USER"));
  var developerOwners = normalizeAskOracleAdminOwnersCsv(getAskOracleBootstrapValue(cfg, "developer_owner_app_user", "DEVELOPER_OWNER_APP_USER"));
  var userOwners = normalizeAskOracleAdminOwnersCsv(getAskOracleBootstrapValue(cfg, "user_owner_app_user", "USER_OWNER_APP_USER"));
  var role = String(getAskOracleBootstrapValue(cfg, "user_role", "USER_ROLE") || "").trim().toUpperCase();
  if (role !== "ADMIN" && role !== "DEVELOPER" && role !== "USER") {
    var appUser = getAskOracleRuntimeAppUser();
    if (appUser && isAskOracleRuntimeUserInCsv(adminOwners)) role = "ADMIN";
    else if (appUser && isAskOracleRuntimeUserInCsv(developerOwners)) role = "DEVELOPER";
    else role = "USER";
  }
  return {
    SHOW_OPEN_IN_EDITOR: getAskOracleBootstrapFlag(cfg, ["show_open_in_editor", "SHOW_OPEN_IN_EDITOR"], true) ? "Y" : "N",
    SHOW_AGENT_THOUGHTS: getAskOracleBootstrapFlag(cfg, ["show_agent_thoughts", "SHOW_AGENT_THOUGHTS"], true) ? "Y" : "N",
    SHOW_EXPORT_PDF: getAskOracleBootstrapFlag(cfg, ["show_export_pdf", "show_export_pdf_button", "SHOW_EXPORT_PDF"], true) ? "Y" : "N",
    SHOW_EXPORT_EXCEL: getAskOracleBootstrapFlag(cfg, ["show_export_excel", "show_export_excel_button", "SHOW_EXPORT_EXCEL"], true) ? "Y" : "N",
    SHOW_CONVERSATION_TIMER: getAskOracleBootstrapFlag(cfg, ["show_conversation_timer", "show_conversation_timer_button", "SHOW_CONVERSATION_TIMER"], true) ? "Y" : "N",
    SHOW_DELETE_PROMPT: getAskOracleBootstrapFlag(cfg, ["show_delete_prompt", "show_delete_prompt_button", "SHOW_DELETE_PROMPT"], true) ? "Y" : "N",
    ENABLE_END_USER_SWITCH_CONV_STYLE: getAskOracleBootstrapFlag(cfg, ["enable_end_user_switch_conv_style", "ENABLE_END_USER_SWITCH_CONV_STYLE"], false) ? "Y" : "N",
    ENABLE_END_USER_SWITCH_PROFILES_AGENTS: getAskOracleBootstrapFlag(cfg, ["enable_end_user_switch_profiles_agents", "ENABLE_END_USER_SWITCH_PROFILES_AGENTS"], false) ? "Y" : "N",
    ENABLE_END_USER_SWITCH_NL2SQL_PROFILE: getAskOracleBootstrapFlag(cfg, ["enable_end_user_switch_nl2sql_profile", "ENABLE_END_USER_SWITCH_NL2SQL_PROFILE"], false) ? "Y" : "N",
    ENABLE_END_USER_SWITCH_RAG_PROFILE: getAskOracleBootstrapFlag(cfg, ["enable_end_user_switch_rag_profile", "ENABLE_END_USER_SWITCH_RAG_PROFILE"], false) ? "Y" : "N",
    DEFAULT_CONVERSATION_MODE: String(getAskOracleBootstrapValue(cfg, "default_conversation_mode", "DEFAULT_CONVERSATION_MODE") || "").trim().toUpperCase(),
    DEFAULT_NL2SQL_PROFILE: String(getAskOracleBootstrapValue(cfg, "default_nl2sql_profile", "DEFAULT_NL2SQL_PROFILE") || "").trim(),
    DEFAULT_RAG_PROFILE: String(getAskOracleBootstrapValue(cfg, "default_rag_profile", "DEFAULT_RAG_PROFILE") || "").trim(),
    DEFAULT_AGENT_TEAM: sanitizeAskOracleHomeAgentTeam(String(getAskOracleBootstrapValue(cfg, "default_agent_team", "DEFAULT_AGENT_TEAM") || "").trim()),
    RETENTION_DAYS: String(getAskOracleBootstrapValue(cfg, "retention_days", "RETENTION_DAYS") || "").trim(),
    AGENT_RUN_SERVICE_LEVEL: String(getAskOracleBootstrapValue(cfg, "agent_run_service_level", "AGENT_RUN_SERVICE_LEVEL") || "").trim().toUpperCase(),
    ADMIN_OWNER_APP_USER: adminOwners,
    DEVELOPER_OWNER_APP_USER: developerOwners,
    USER_OWNER_APP_USER: userOwners,
    USER_ROLE: role,
    CURRENT_APP_USER: getAskOracleRuntimeAppUser(),
    APP_ZOOM_PCT: String(getAskOracleBootstrapValue(cfg, "app_zoom_pct", "APP_ZOOM_PCT") || "").trim(),
    APP_DISPLAY_NAME: String(getAskOracleBootstrapValue(cfg, "app_display_name", "APP_DISPLAY_NAME") || "").trim(),
    APP_LOGO_URL: String(getAskOracleBootstrapValue(cfg, "app_logo_url", "APP_LOGO_URL") || "").trim(),
    PROMPT_BAR_TITLE: String(getAskOracleBootstrapValue(cfg, "prompt_bar_title", "PROMPT_BAR_TITLE") || "").trim(),
    PROMPT_PLACEHOLDER: String(getAskOracleBootstrapValue(cfg, "prompt_placeholder", "PROMPT_PLACEHOLDER") || "").trim(),
    AI_INFO_MESSAGE: String(getAskOracleBootstrapValue(cfg, "ai_info_message", "AI_INFO_MESSAGE") || "").trim()
  };
}

function shouldApplyAskOracleEndUserActionControls() {
  var cfg = getAskOracleAdminConfigSnapshot();
  var userOwners = getAskOracleConfigCsvValue(cfg, "USER_OWNER_APP_USER", "user_owner_app_user");
  var appUser = getAskOracleRuntimeAppUser();
  if (appUser && normalizeAskOracleAdminOwnersCsv(userOwners)) {
    return isAskOracleRuntimeUserInCsv(userOwners);
  }
  return getAskOracleRuntimeUserRole() === "USER";
}

function getAskOracleEndUserOnlyAdminFlag(configKey, fallbackValue) {
  if (!shouldApplyAskOracleEndUserActionControls()) return true;
  return getAskOracleAdminFlag(configKey, fallbackValue);
}

function getAskOracleEndUserOnlyAdminFlagAny(configKeys, fallbackValue) {
  if (!shouldApplyAskOracleEndUserActionControls()) return true;
  return getAskOracleAdminFlagAny(configKeys, fallbackValue);
}

function getAskOracleAppDisplayName() {
  return getAskOracleAdminText("APP_DISPLAY_NAME", "Ask Oracle Select AI");
}

function getAskOraclePromptBarTitle() {
  return getAskOracleAdminText("PROMPT_BAR_TITLE", "Ask Oracle");
}

function getAskOraclePromptPlaceholder() {
  return getAskOracleAdminText("PROMPT_PLACEHOLDER", "Ask Question");
}

function getAskOracleAppLogoUrl() {
  return getAskOracleAdminText("APP_LOGO_URL", "");
}

function getAskOracleAiInfoMessage() {
  return getAskOracleAdminText("AI_INFO_MESSAGE", "AI models can make mistakes. Verify responses.");
}

function isAskOracleOpenEditorEnabled() {
  return getAskOracleEndUserOnlyAdminFlag("SHOW_OPEN_IN_EDITOR", true);
}

function isAskOracleAgentThoughtsButtonEnabled() {
  return getAskOracleEndUserOnlyAdminFlag("SHOW_AGENT_THOUGHTS", true);
}

function isAskOracleEndUserProfileAgentSwitchEnabled() {
  return getAskOracleEndUserOnlyAdminFlag("ENABLE_END_USER_SWITCH_PROFILES_AGENTS", false);
}

function isAskOracleEndUserNl2sqlProfileSwitchEnabled() {
  return getAskOracleEndUserOnlyAdminFlagAny([
    "ENABLE_END_USER_SWITCH_NL2SQL_PROFILE",
    "SHOW_END_USER_NL2SQL_PROFILE",
    "SHOW_NL2SQL_PROFILE_SWITCH"
  ], false);
}

function isAskOracleEndUserRagProfileSwitchEnabled() {
  return getAskOracleEndUserOnlyAdminFlagAny([
    "ENABLE_END_USER_SWITCH_RAG_PROFILE",
    "SHOW_END_USER_RAG_PROFILE",
    "SHOW_RAG_PROFILE_SWITCH"
  ], false);
}

function isAskOracleEndUserConvStyleSwitchEnabled() {
  return getAskOracleEndUserOnlyAdminFlag("ENABLE_END_USER_SWITCH_CONV_STYLE", false);
}

function isAskOraclePdfExportButtonEnabled() {
  return getAskOracleEndUserOnlyAdminFlagAny([
    "SHOW_EXPORT_PDF",
    "SHOW_EXPORT_PDF_BUTTON",
    "SHOW_PDF_EXPORT",
    "ENABLE_EXPORT_PDF",
    "ENABLE_PDF_EXPORT"
  ], true);
}

function isAskOracleExcelExportButtonEnabled() {
  return getAskOracleEndUserOnlyAdminFlagAny([
    "SHOW_EXPORT_EXCEL",
    "SHOW_EXPORT_EXCEL_BUTTON",
    "SHOW_EXCEL_EXPORT",
    "ENABLE_EXPORT_EXCEL",
    "ENABLE_EXCEL_EXPORT"
  ], true);
}

function isAskOracleConversationTimerButtonEnabled() {
  return getAskOracleEndUserOnlyAdminFlagAny([
    "SHOW_CONVERSATION_TIMER",
    "SHOW_CONVERSATION_TIMER_BUTTON",
    "SHOW_TIMER_BUTTON",
    "ENABLE_CONVERSATION_TIMER",
    "ENABLE_TIMER_BUTTON"
  ], true);
}

function isAskOracleDeletePromptButtonEnabled() {
  return getAskOracleEndUserOnlyAdminFlagAny([
    "SHOW_DELETE_PROMPT",
    "SHOW_DELETE_PROMPT_BUTTON",
    "SHOW_DELETE_BUTTON",
    "ENABLE_DELETE_PROMPT",
    "ENABLE_DELETE_BUTTON"
  ], true);
}

var ASK_ORACLE_APP_ZOOM_STORAGE_KEY = "ASK_ORACLE_APP_ZOOM_PCT";
var ASK_ORACLE_FONT_SCALE_STYLE_ID = "ask-oracle-font-scale-style";
var ASK_ORACLE_ACTION_CONTROL_STYLE_ID = "ask-oracle-action-control-style";

function normalizeAskOracleAppZoomPct(value) {
  var n = Number(value);
  if (!isFinite(n)) {
    var match = String(value == null ? "" : value).match(/-?\d+(?:\.\d+)?/);
    n = match ? Number(match[0]) : NaN;
  }
  if (!isFinite(n)) n = 100;
  n = Math.round(n / 5) * 5;
  if (n < 80) n = 80;
  if (n > 200) n = 200;
  return n;
}

function ensureAskOracleAppZoomCss() {
  if (document.getElementById(ASK_ORACLE_FONT_SCALE_STYLE_ID)) return;
  var style = document.createElement("style");
  style.id = ASK_ORACLE_FONT_SCALE_STYLE_ID;
  style.textContent = `
    :root {
      --ask-oracle-font-scale: 1;
      --ask-oracle-table-font-size: 13px;
      --ask-oracle-table-meta-font-size: 12px;
    }
    #P1_PROMPT1,
    #P1_PROMPT1 textarea,
    .message-bubble,
    .response-box,
    .llm-chat,
    .speech-controls .speech-icon-button,
    .response-footer .t-Button,
    .ask-oracle-sql-footer-actions .t-Button {
      font-size: calc(1em * var(--ask-oracle-font-scale));
    }
    .llm-sql-table,
    .code-editor-run-output-table,
    .llm-sql-table th,
    .llm-sql-table td,
    .code-editor-run-output-table th,
    .code-editor-run-output-table td,
    .llm-sql-table td pre,
    .llm-sql-table td code,
    .code-editor-run-output-table td pre,
    .code-editor-run-output-table td code {
      font-size: calc(var(--ask-oracle-table-font-size) * var(--ask-oracle-font-scale)) !important;
    }
    .llm-sql-meta,
    .code-editor-run-output-meta {
      font-size: calc(var(--ask-oracle-table-meta-font-size) * var(--ask-oracle-font-scale)) !important;
    }
  `;
  document.head.appendChild(style);
}

function applyAskOracleAppZoomScale() {
  ensureAskOracleAppZoomCss();
  var cfg = getAskOracleAdminConfigSnapshot();
  var source = cfg && cfg.APP_ZOOM_PCT != null ? cfg.APP_ZOOM_PCT : "";
  if (source == null || String(source).trim() === "") {
    try { source = sessionStorage.getItem(ASK_ORACLE_APP_ZOOM_STORAGE_KEY); } catch (e1) {}
  }
  if (source == null || String(source).trim() === "") {
    try { source = localStorage.getItem(ASK_ORACLE_APP_ZOOM_STORAGE_KEY); } catch (e2) {}
  }
  var pct = normalizeAskOracleAppZoomPct(source);
  document.documentElement.style.setProperty("--ask-oracle-font-scale", String(pct / 100));
  try { sessionStorage.setItem(ASK_ORACLE_APP_ZOOM_STORAGE_KEY, String(pct)); } catch (e3) {}
  try { localStorage.setItem(ASK_ORACLE_APP_ZOOM_STORAGE_KEY, String(pct)); } catch (e4) {}
}

function readAskOracleApexItemCurrentValue(itemName) {
  var itemKey = String(itemName || "").trim();
  if (!itemKey) return "";
  try {
    if (window.apex && typeof apex.item === "function") {
      var apexItem = apex.item(itemKey);
      if (apexItem && typeof apexItem.getValue === "function") {
        return String(apexItem.getValue() == null ? "" : apexItem.getValue()).trim();
      }
    }
  } catch (e) {}
  var el = document.getElementById(itemKey);
  return String(el && typeof el.value !== "undefined" ? el.value : "").trim();
}

function setAskOracleApexItemValueIfPresent(itemName, value, fireChange) {
  var itemKey = String(itemName || "").trim();
  if (!itemKey) return false;
  var nextValue = String(value == null ? "" : value).trim();
  if (!nextValue) return false;
  if (readAskOracleApexItemCurrentValue(itemKey) === nextValue) {
    return true;
  }
  if (fireChange !== true) {
    var silentElement = document.getElementById(itemKey);
    if (silentElement && typeof silentElement.value !== "undefined") {
      silentElement.value = nextValue;
      return true;
    }
  }
  try {
    if (window.apex && typeof apex.item === "function") {
      var apexItem = apex.item(itemKey);
      if (apexItem && typeof apexItem.setValue === "function") {
        apexItem.setValue(nextValue, null, fireChange !== true);
        return true;
      }
    }
  } catch (e) {}
  try {
    if (typeof window.$s === "function") {
      window.$s(itemKey, nextValue, null, fireChange !== true);
      return true;
    }
  } catch (e2) {}
  var element = document.getElementById(itemKey);
  if (!element) return false;
  element.value = nextValue;
  if (fireChange === true) {
    try { element.dispatchEvent(new Event("change", { bubbles: true })); } catch (e3) {}
  }
  return true;
}

function clearAskOracleApexItemValueIfPresent(itemName, fireChange) {
  var itemKey = String(itemName || "").trim();
  if (!itemKey) return false;
  if (readAskOracleApexItemCurrentValue(itemKey) === "") {
    return true;
  }
  if (fireChange !== true) {
    var silentElement = document.getElementById(itemKey);
    if (silentElement && typeof silentElement.value !== "undefined") {
      silentElement.value = "";
      return true;
    }
  }
  try {
    if (window.apex && typeof apex.item === "function") {
      var apexItem = apex.item(itemKey);
      if (apexItem && typeof apexItem.setValue === "function") {
        apexItem.setValue("", null, fireChange !== true);
        return true;
      }
    }
  } catch (e) {}
  try {
    if (typeof window.$s === "function") {
      window.$s(itemKey, "", null, fireChange !== true);
      return true;
    }
  } catch (e2) {}
  var element = document.getElementById(itemKey);
  if (!element) return false;
  element.value = "";
  if (fireChange === true) {
    try { element.dispatchEvent(new Event("change", { bubbles: true })); } catch (e3) {}
  }
  return true;
}

function triggerAskOracleApexItemChange(itemName) {
  var itemKey = String(itemName || "").trim();
  if (!itemKey) return;
  try {
    if (window.apex && typeof apex.item === "function") {
      var apexItem = apex.item(itemKey);
      if (apexItem && typeof apexItem.node === "function") {
        var node = apexItem.node();
        if (node && typeof node.dispatchEvent === "function") {
          node.dispatchEvent(new Event("change", { bubbles: true }));
          return;
        }
      }
    }
  } catch (e1) {}
  try {
    if (window.jQuery) {
      window.jQuery("#" + itemKey).trigger("change");
      return;
    }
  } catch (e2) {}
  var el = document.getElementById(itemKey);
  if (!el || typeof el.dispatchEvent !== "function") return;
  try { el.dispatchEvent(new Event("change", { bubbles: true })); } catch (e3) {}
}

function normalizeAskOracleConversationMode(modeValue) {
  var text = String(modeValue || "").trim().toUpperCase();
  if (!text) return "";
  if (text === "RAG" || text === "RAG_PROFILE" || text === "RAG_PROFILES") return "RAG_PROFILES";
  if (text === "AGENT" || text === "AGENTS" || text === "USER_AGENT" || text === "USER_AGENTS") return "USER_AGENTS";
  return "CHAT_WITH_DB";
}

function getAskOracleCurrentConversationMode() {
  var fromConvType = "";
  var fromConvStyle = "";
  try {
    if (typeof window.$v === "function") {
      fromConvType = String($v("P1_CONV_TYPE") || "").trim();
      fromConvStyle = String($v("P1_CONVERSATION_STYLE") || "").trim();
    }
  } catch (e) {}
  return normalizeAskOracleConversationMode(fromConvStyle || fromConvType);
}

function getAskOracleEffectiveConversationModeForChip() {
  var cfg = getAskOracleAdminConfigSnapshot();
  var cfgMode = normalizeAskOracleConversationMode((cfg && cfg.DEFAULT_CONVERSATION_MODE) || "");
  var forceDefaultMode = shouldApplyAskOracleEndUserActionControls() &&
    cfgMode &&
    !isAskOracleEndUserConvStyleSwitchEnabled();
  if (forceDefaultMode) return cfgMode;

  var selectedMode = normalizeAskOracleConversationMode(window.ASK_ORACLE_CURRENT_CONVERSATION_MODE || "");
  if (selectedMode) return selectedMode;

  var currentMode = getAskOracleCurrentConversationMode();
  if (currentMode) return currentMode;

  if (cfgMode) return cfgMode;

  var syncedMode = normalizeAskOracleConversationMode(getAskOracleUiSyncValue(ASK_ORACLE_SYNC_DEFAULT_CONV_MODE));
  if (syncedMode) return syncedMode;

  var activeBtn = document.querySelector("#plusMenu button.active[data-style]");
  var activeMode = activeBtn ? normalizeAskOracleConversationMode(activeBtn.getAttribute("data-style")) : "";
  if (activeMode) return activeMode;

  return normalizeAskOracleConversationMode(askOracleModeChipLastMode);
}

function getAskOracleConversationModeDisplayName(modeValue) {
  var mode = normalizeAskOracleConversationMode(modeValue) || getAskOracleEffectiveConversationModeForChip();
  if (mode === "RAG_PROFILES") return "RAG";
  if (mode === "USER_AGENTS") return "AGENT";
  return "NL2SQL";
}

function ensureAskOracleConversationModeChip() {
  var promptWrapper = document.getElementById("promptWrapper");
  var plusBtn = document.getElementById("addPrompt");
  if (!promptWrapper || !plusBtn) return null;

  var chip = document.getElementById(ASK_ORACLE_MODE_CHIP_ID);
  if (chip && chip.parentElement !== promptWrapper) {
    try { chip.remove(); } catch (e) {}
    chip = null;
  }
  if (!chip) {
    chip = document.createElement("span");
    chip.id = ASK_ORACLE_MODE_CHIP_ID;
    chip.className = "ask-oracle-mode-chip";
    chip.setAttribute("aria-live", "polite");
    plusBtn.insertAdjacentElement("afterend", chip);
  }
  return chip;
}

function updateAskOracleConversationModeChip(modeValue) {
  var chip = ensureAskOracleConversationModeChip();
  if (!chip) return;
  var mode = normalizeAskOracleConversationMode(modeValue) || getAskOracleEffectiveConversationModeForChip();
  var label = getAskOracleConversationModeDisplayName(mode);
  askOracleModeChipLastMode = mode || "CHAT_WITH_DB";
  chip.textContent = label;
  chip.setAttribute("data-mode", mode || "CHAT_WITH_DB");
  chip.title = "Conversation mode: " + label;
}

function applyAskOracleConversationStyleMenuHighlight(modeValue) {
  var mode = normalizeAskOracleConversationMode(modeValue || getAskOracleCurrentConversationMode());
  if (!mode) return;
  updateAskOracleConversationModeChip(mode);
  var plusMenu = document.getElementById("plusMenu");
  if (!plusMenu || typeof plusMenu.querySelectorAll !== "function") return;
  var buttons = plusMenu.querySelectorAll("button[data-style]");
  if (!buttons || !buttons.length) return;

  buttons.forEach(function(btn) {
    if (!btn) return;
    btn.classList.remove("active");
    btn.removeAttribute("aria-selected");
    btn.removeAttribute("aria-current");
    var checks = btn.querySelectorAll(".fa-check");
    checks.forEach(function(node) {
      try { node.remove(); } catch (e) {}
    });
  });

  var selectedBtn = plusMenu.querySelector('button[data-style="' + mode + '"]');
  if (!selectedBtn) {
    buttons.forEach(function(btn) {
      if (selectedBtn || !btn) return;
      if (normalizeAskOracleConversationMode(btn.getAttribute("data-style")) === mode) selectedBtn = btn;
    });
  }
  if (!selectedBtn) return;
  selectedBtn.classList.add("active");
  selectedBtn.setAttribute("aria-selected", "true");
  selectedBtn.setAttribute("aria-current", "true");
  if (!selectedBtn.querySelector(".fa-check")) {
    selectedBtn.insertAdjacentHTML("beforeend", ' <i class="fa fa-check"></i>');
  }
}

function ensureAskOracleModeSwitchTraceCss() {
  var styleId = "ask-oracle-mode-switch-trace-css";
  if (document.getElementById(styleId)) return;
  var style = document.createElement("style");
  style.id = styleId;
  style.textContent = `
    #promptWrapper.ask-oracle-mode-switch-trace-host { position: relative !important; }
    @property --ask-oracle-gradient-angle { syntax: "<angle>"; initial-value: 0deg; inherits: true; }
    #promptWrapper > .ask-oracle-mode-switch-trace {
      position: absolute; inset: 0; z-index: 20;
      border-radius: inherit; isolation: isolate; pointer-events: none;
      --ask-oracle-gradient-angle: 0deg;
      animation: askOracleGeminiBorderFlow 1250ms linear forwards;
    }
    #promptWrapper > .ask-oracle-mode-switch-trace::before {
      content: ""; position: absolute; inset: 0; box-sizing: border-box; padding: 1.5px; border-radius: inherit;
      background: conic-gradient(from var(--ask-oracle-gradient-angle), #4285f4, #6f6cff, #b35cff, #ec4899, #fb923c, #fbbc05, #4285f4);
      -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
      -webkit-mask-composite: xor; mask-composite: exclude;
    }
    #promptWrapper > .ask-oracle-mode-switch-trace::after {
      content: ""; position: absolute; inset: 0; z-index: -1; box-sizing: border-box; padding: 1.5px; border-radius: inherit;
      background: conic-gradient(from var(--ask-oracle-gradient-angle), #4285f4, #6f6cff, #b35cff, #ec4899, #fb923c, #fbbc05, #4285f4);
      filter: blur(5px); opacity: 0.72;
      -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
      -webkit-mask-composite: xor; mask-composite: exclude;
    }
    @keyframes askOracleGeminiBorderFlow { 0% { --ask-oracle-gradient-angle: 0deg; opacity: 0; } 8% { opacity: 1; } 90% { opacity: 1; } 100% { --ask-oracle-gradient-angle: 360deg; opacity: 0; } }
  `;
  document.head.appendChild(style);
}

function playAskOracleModeSwitchTrace() {
  var promptWrapper = document.getElementById("promptWrapper");
  if (!promptWrapper) return;
  ensureAskOracleModeSwitchTraceCss();
  if (window.getComputedStyle && window.getComputedStyle(promptWrapper).position === "static") promptWrapper.classList.add("ask-oracle-mode-switch-trace-host");
  promptWrapper.querySelectorAll(":scope > .ask-oracle-mode-switch-trace").forEach(function(node) { try { node.remove(); } catch (e) {} });
  var trace = document.createElement("span");
  trace.className = "ask-oracle-mode-switch-trace";
  trace.setAttribute("aria-hidden", "true");
  try { trace.style.borderRadius = window.getComputedStyle(promptWrapper).borderRadius; } catch (e) {}
  promptWrapper.appendChild(trace);
  trace.addEventListener("animationend", function(event) { if (event && event.target !== trace) return; try { trace.remove(); } catch (e) {} }, { once: true });
}

function scheduleAskOraclePromptBorderAnimation(attempt) {
  var retries = Number(attempt) || 0;
  if (document.getElementById("promptWrapper")) {
    playAskOracleModeSwitchTrace();
    return;
  }
  if (retries < 12) {
    window.setTimeout(function() { scheduleAskOraclePromptBorderAnimation(retries + 1); }, 150);
  }
}

if (!window.__askOraclePromptBorderLoadAnimationInstalled) {
  window.__askOraclePromptBorderLoadAnimationInstalled = true;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function() {
      window.setTimeout(function() { scheduleAskOraclePromptBorderAnimation(0); }, 180);
    }, { once: true });
  } else {
    window.setTimeout(function() { scheduleAskOraclePromptBorderAnimation(0); }, 180);
  }
}

function resolveAskOracleSelectValue(itemId, desiredValue) {
  var id = String(itemId || "").trim();
  var wanted = String(desiredValue || "").trim();
  if (!id || !wanted) return "";
  var el = document.getElementById(id);
  if (!el || !el.options || !el.options.length) return wanted;
  var upperWanted = wanted.toUpperCase();
  for (var i = 0; i < el.options.length; i += 1) {
    var optionValue = String(el.options[i].value || "").trim();
    if (!optionValue) continue;
    if (optionValue === wanted || optionValue.toUpperCase() === upperWanted) {
      return optionValue;
    }
  }
  return "";
}

function resolveAskOracleCurrentProfileForAgentTeam(agentTeam) {
  var raw = String(agentTeam || "").trim();
  if (!raw) return "";
  var normalized = raw
    .replace(/^\s*AGENT\s*\|\s*/i, "")
    .replace(/^\s*AGENT\$/i, "")
    .trim();
  var candidates = [
    raw,
    normalized,
    "AGENT | " + normalized,
    "AGENT|" + normalized,
    "AGENT$" + normalized
  ];
  for (var i = 0; i < candidates.length; i += 1) {
    var candidate = String(candidates[i] || "").trim();
    if (!candidate) continue;
    var resolved = resolveAskOracleSelectValue("P1_CURRENT_AI_PROFILE", candidate);
    if (resolved) return resolved;
  }
  return normalized || raw;
}

function getAskOracleControlContainer(node) {
  if (!node || typeof node.closest !== "function") return null;
  return (
    node.closest(".t-Form-fieldContainer") ||
    node.closest(".a-Form-fieldContainer") ||
    node.closest(".apex-item-group") ||
    node.closest(".t-Form-itemWrapper") ||
    node.closest(".apex-item-wrapper") ||
    node.closest(".t-Form-inputContainer") ||
    null
  );
}

function getAskOracleControlVisibilityTargets(itemId) {
  var id = String(itemId || "").trim();
  if (!id) return [];

  var targets = [];
  var seen = [];
  var addTarget = function(node) {
    if (!node || !node.style) return;
    if (seen.indexOf(node) >= 0) return;
    seen.push(node);
    targets.push(node);
  };

  var field = document.getElementById(id);
  var label = document.querySelector("label[for='" + id + "']");
  var itemContainer = document.getElementById(id + "_CONTAINER");
  var itemDisplay = document.getElementById(id + "_DISPLAY");
  [field, label, itemContainer, itemDisplay].forEach(function(node) {
    if (!node) return;
    addTarget(node);
    var container = getAskOracleControlContainer(node);
    if (container) addTarget(container);
  });
  if (itemContainer && typeof itemContainer.querySelectorAll === "function") {
    itemContainer.querySelectorAll(".select2, .select2-container, .apex-item-group, .apex-item-wrapper").forEach(addTarget);
  }
  if (field && field.nextElementSibling && /select2|apex-item|a-Select/i.test(String(field.nextElementSibling.className || ""))) {
    addTarget(field.nextElementSibling);
  }

  return targets;
}

function setAskOracleControlVisibilityById(itemId, visible) {
  var id = String(itemId || "").trim();
  if (!id) return;
  var shouldShow = !!visible;
  var field = document.getElementById(id);
  if (field) {
    field.disabled = !shouldShow;
    if (shouldShow) {
      field.removeAttribute("aria-hidden");
      field.removeAttribute("aria-disabled");
    } else {
      field.setAttribute("aria-hidden", "true");
      field.setAttribute("aria-disabled", "true");
    }
  }
  var targets = getAskOracleControlVisibilityTargets(id);
  targets.forEach(function(node) {
    if (!node || !node.style) return;
    if (shouldShow) {
      node.style.removeProperty("display");
      node.style.removeProperty("visibility");
      node.style.removeProperty("opacity");
      node.style.removeProperty("pointer-events");
    } else {
      node.style.setProperty("display", "none", "important");
      node.style.setProperty("visibility", "hidden", "important");
      node.style.setProperty("pointer-events", "none", "important");
    }
  });
}

function ensureAskOracleActionControlCss() {
  if (document.getElementById(ASK_ORACLE_ACTION_CONTROL_STYLE_ID)) return;
  var style = document.createElement("style");
  style.id = ASK_ORACLE_ACTION_CONTROL_STYLE_ID;
  style.textContent = `
    body.ask-oracle-hide-shared-profile-switch label[for="P1_CURRENT_AI_PROFILE"],
    body.ask-oracle-hide-shared-profile-switch #P1_CURRENT_AI_PROFILE,
    body.ask-oracle-hide-shared-profile-switch #P1_CURRENT_AI_PROFILE_CONTAINER,
    body.ask-oracle-hide-shared-profile-switch #P1_CURRENT_AI_PROFILE_DISPLAY,
    body.ask-oracle-hide-shared-profile-switch #P1_CURRENT_AI_PROFILE_CONTAINER .select2,
    body.ask-oracle-hide-agent-switch label[for="P1_AGENT_PROFILE"],
    body.ask-oracle-hide-agent-switch #P1_AGENT_PROFILE,
    body.ask-oracle-hide-agent-switch #P1_AGENT_PROFILE_CONTAINER,
    body.ask-oracle-hide-agent-switch #P1_AGENT_PROFILE_DISPLAY,
    body.ask-oracle-hide-agent-switch #P1_AGENT_PROFILE_CONTAINER .select2,
    body.ask-oracle-hide-agent-switch label[for="P1_AGENT_TEAM"],
    body.ask-oracle-hide-agent-switch #P1_AGENT_TEAM,
    body.ask-oracle-hide-agent-switch #P1_AGENT_TEAM_CONTAINER,
    body.ask-oracle-hide-agent-switch #P1_AGENT_TEAM_DISPLAY,
    body.ask-oracle-hide-agent-switch #P1_AGENT_TEAM_CONTAINER .select2,
    body.ask-oracle-hide-agent-switch label[for="P1_AGENT_SERVICE"],
    body.ask-oracle-hide-agent-switch #P1_AGENT_SERVICE,
    body.ask-oracle-hide-agent-switch #P1_AGENT_SERVICE_CONTAINER,
    body.ask-oracle-hide-agent-switch #P1_AGENT_SERVICE_DISPLAY,
    body.ask-oracle-hide-agent-switch #P1_AGENT_SERVICE_CONTAINER .select2,
    body.ask-oracle-hide-nl2sql-switch label[for="P1_SERVICE"],
    body.ask-oracle-hide-nl2sql-switch #P1_SERVICE,
    body.ask-oracle-hide-nl2sql-switch #P1_SERVICE_CONTAINER,
    body.ask-oracle-hide-nl2sql-switch #P1_SERVICE_DISPLAY,
    body.ask-oracle-hide-nl2sql-switch #P1_SERVICE_CONTAINER .select2,
    body.ask-oracle-hide-nl2sql-switch label[for="P1_PROFILE"],
    body.ask-oracle-hide-nl2sql-switch #P1_PROFILE,
    body.ask-oracle-hide-nl2sql-switch #P1_PROFILE_CONTAINER,
    body.ask-oracle-hide-nl2sql-switch #P1_PROFILE_DISPLAY,
    body.ask-oracle-hide-nl2sql-switch #P1_PROFILE_CONTAINER .select2,
    body.ask-oracle-hide-rag-switch label[for="P1_RAG_PROFILE"],
    body.ask-oracle-hide-rag-switch #P1_RAG_PROFILE,
    body.ask-oracle-hide-rag-switch #P1_RAG_PROFILE_CONTAINER,
    body.ask-oracle-hide-rag-switch #P1_RAG_PROFILE_DISPLAY,
    body.ask-oracle-hide-rag-switch #P1_RAG_PROFILE_CONTAINER .select2,
    body.ask-oracle-hide-rag-switch label[for="P1_RAG_CHAT"],
    body.ask-oracle-hide-rag-switch #P1_RAG_CHAT,
    body.ask-oracle-hide-rag-switch #P1_RAG_CHAT_CONTAINER,
    body.ask-oracle-hide-rag-switch #P1_RAG_CHAT_DISPLAY,
    body.ask-oracle-hide-rag-switch #P1_RAG_CHAT_CONTAINER .select2,
    body.ask-oracle-hide-rag-switch label[for="P1_RAG_SQL"],
    body.ask-oracle-hide-rag-switch #P1_RAG_SQL,
    body.ask-oracle-hide-rag-switch #P1_RAG_SQL_CONTAINER,
    body.ask-oracle-hide-rag-switch #P1_RAG_SQL_DISPLAY,
    body.ask-oracle-hide-rag-switch #P1_RAG_SQL_CONTAINER .select2,
    body.ask-oracle-hide-rag-switch label[for="P1_RAGSERVICE"],
    body.ask-oracle-hide-rag-switch #P1_RAGSERVICE,
    body.ask-oracle-hide-rag-switch #P1_RAGSERVICE_CONTAINER,
    body.ask-oracle-hide-rag-switch #P1_RAGSERVICE_DISPLAY,
    body.ask-oracle-hide-rag-switch #P1_RAGSERVICE_CONTAINER .select2,
    body.ask-oracle-hide-conv-style-switch label[for="P1_CONVERSATION_STYLE"],
    body.ask-oracle-hide-conv-style-switch #P1_CONVERSATION_STYLE,
    body.ask-oracle-hide-conv-style-switch #P1_CONVERSATION_STYLE_CONTAINER,
    body.ask-oracle-hide-conv-style-switch #P1_CONVERSATION_STYLE_DISPLAY,
    body.ask-oracle-hide-conv-style-switch #P1_CONVERSATION_STYLE_CONTAINER .select2,
    body.ask-oracle-hide-conv-style-switch #addPrompt,
    body.ask-oracle-hide-conv-style-switch #plusMenu,
    body.ask-oracle-hide-conv-style-switch [data-conversation-style-switch],
    body.ask-oracle-hide-conv-style-switch .ask-oracle-conversation-style-switch {
      display: none !important;
      visibility: hidden !important;
      pointer-events: none !important;
    }
  `;
  document.head.appendChild(style);
}

function applyAskOracleActionControlBodyClasses(state) {
  if (!document || !document.body) return;
  ensureAskOracleActionControlCss();
  var body = document.body;
  body.classList.toggle("ask-oracle-hide-agent-switch", !state.showAgentSwitch);
  body.classList.toggle("ask-oracle-hide-nl2sql-switch", !state.showNl2sqlSwitch);
  body.classList.toggle("ask-oracle-hide-rag-switch", !state.showRagSwitch);
  body.classList.toggle("ask-oracle-hide-conv-style-switch", !state.showConvStyleSwitch);
  body.classList.toggle("ask-oracle-hide-shared-profile-switch", !state.showSharedProfileSwitch);
}

function setAskOracleActionIconVisibility(node, visible) {
  if (!node || !node.style) return;
  var shouldShow = !!visible;
  node.disabled = !shouldShow;
  if (shouldShow) {
    node.removeAttribute("hidden");
    node.removeAttribute("aria-hidden");
    node.removeAttribute("aria-disabled");
    node.style.removeProperty("display");
    node.style.removeProperty("visibility");
    node.style.removeProperty("opacity");
    node.style.removeProperty("pointer-events");
  } else {
    node.setAttribute("hidden", "hidden");
    node.setAttribute("aria-hidden", "true");
    node.setAttribute("aria-disabled", "true");
    node.style.setProperty("display", "none", "important");
    node.style.setProperty("visibility", "hidden", "important");
    node.style.setProperty("opacity", "0", "important");
    node.style.setProperty("pointer-events", "none", "important");
  }
}

function getAskOracleResponseIdForActionNode(node) {
  if (!node) return "";
  var directId = String(
    (node.getAttribute && (node.getAttribute("data-response-id") || node.getAttribute("data-id"))) || ""
  ).trim();
  if (directId) return directId.replace(/^response-/, "");
  var host = node.closest
    ? node.closest(".speech-controls[data-id], .chart-sql-buttons[data-response-id], .ask-oracle-response-table-actions[data-response-id], .ask-oracle-sql-footer-actions[data-response-id], .response-footer[data-response-id]")
    : null;
  if (!host || typeof host.getAttribute !== "function") return "";
  return String(host.getAttribute("data-id") || host.getAttribute("data-response-id") || "")
    .trim()
    .replace(/^response-/, "");
}

function getAskOracleConversationPromptIdForResponse(responseId) {
  var normalizedId = String(responseId || "").trim().replace(/^response-/, "");
  if (!normalizedId) return "";
  var responseEl = document.getElementById("response-" + normalizedId) || document.getElementById(normalizedId);
  if (!responseEl || typeof responseEl.getAttribute !== "function") return "";
  return String(responseEl.getAttribute("data-conversation-prompt-id") || "").trim();
}

function shouldShowAskOracleShareLinkButtons() {
  return false;
}

function applyAskOracleAdminActionButtonVisibility() {
  var showOpenEditor = isAskOracleOpenEditorEnabled();
  var showAgentThoughts = isAskOracleAgentThoughtsButtonEnabled();
  var showPdfExport = isAskOraclePdfExportButtonEnabled();
  var showExcelExport = isAskOracleExcelExportButtonEnabled();
  var showConversationTimer = isAskOracleConversationTimerButtonEnabled();
  var showDeletePrompt = isAskOracleDeletePromptButtonEnabled();

  document.querySelectorAll(".view-agent-logs-btn, .agent-thoughts-btn").forEach(function(btn) {
    setAskOracleActionIconVisibility(btn, showAgentThoughts);
  });

  document.querySelectorAll(".open-editor-btn").forEach(function(btn) {
    if (!btn) return;
    if (btn.classList && btn.classList.contains("share-nl2sql-btn")) return;
    if (!showOpenEditor) {
      setOpenEditorButtonVisibility(btn, false);
      return;
    }
    var responseId = String(
      (btn.getAttribute("data-response-id") || btn.getAttribute("data-id") || "")
    ).trim();
    if (!responseId) {
      var host = btn.closest(".speech-controls[data-id], .chart-sql-buttons[data-response-id], .ask-oracle-response-table-actions[data-response-id], .ask-oracle-sql-footer-actions[data-response-id]");
      if (host && typeof host.getAttribute === "function") {
        responseId = String(host.getAttribute("data-id") || host.getAttribute("data-response-id") || "").trim();
      }
    }
    var visible = responseId ? responseHasCodeContent(responseId) : true;
    setOpenEditorButtonVisibility(btn, visible);
  });

  document.querySelectorAll(".share-nl2sql-btn").forEach(function(btn) {
    setAskOracleActionIconVisibility(btn, false);
    setOpenEditorButtonVisibility(btn, false);
  });

  document.querySelectorAll(".export-pdf-response-btn").forEach(function(btn) {
    var responseId = getAskOracleResponseIdForActionNode(btn);
    var visible = showPdfExport && (responseId ? responseAllowsPdfExportActions(responseId) : true);
    setAskOracleActionIconVisibility(btn, visible);
  });

  document.querySelectorAll(".export-excel-response-btn").forEach(function(btn) {
    var responseId = getAskOracleResponseIdForActionNode(btn);
    var visible = showExcelExport && (responseId ? responseAllowsPromptExportActions(responseId) : true);
    setAskOracleActionIconVisibility(btn, visible);
  });

  document.querySelectorAll(".conversation-time-btn").forEach(function(btn) {
    setAskOracleActionIconVisibility(btn, showConversationTimer);
  });

  document.querySelectorAll(
    [
      ".speech-controls[data-id] button[onclick*='deletePrompt']",
      ".speech-controls[data-id] .speech-icon-button[data-tooltip='Delete']",
      ".speech-controls[data-id] .speech-icon-button[title='Delete']",
      ".response-footer[data-response-id] button[onclick*='deletePrompt']",
      ".response-footer[data-response-id] .speech-icon-button[data-tooltip='Delete']",
      ".response-footer[data-response-id] .speech-icon-button[title='Delete']",
      ".ask-oracle-sql-footer-actions[data-response-id] button[onclick*='deletePrompt']",
      ".ask-oracle-sql-footer-actions[data-response-id] .speech-icon-button[data-tooltip='Delete']",
      ".ask-oracle-sql-footer-actions[data-response-id] .speech-icon-button[title='Delete']",
      ".chart-sql-buttons[data-response-id] button[onclick*='deletePrompt']",
      ".chart-sql-buttons[data-response-id] .speech-icon-button[data-tooltip='Delete']",
      ".chart-sql-buttons[data-response-id] .speech-icon-button[title='Delete']",
      ".ask-oracle-response-table-actions[data-response-id] button[onclick*='deletePrompt']",
      ".ask-oracle-response-table-actions[data-response-id] .speech-icon-button[data-tooltip='Delete']",
      ".ask-oracle-response-table-actions[data-response-id] .speech-icon-button[title='Delete']"
    ].join(", ")
  ).forEach(function(btn) {
    setAskOracleActionIconVisibility(btn, showDeletePrompt);
  });
}

function applyAskOracleProfileAndStyleSwitchVisibility() {
  var showProfileAgentSwitch = isAskOracleEndUserProfileAgentSwitchEnabled();
  var showNl2sqlSwitch = isAskOracleEndUserNl2sqlProfileSwitchEnabled();
  var showRagSwitch = isAskOracleEndUserRagProfileSwitchEnabled();
  var showConvStyleSwitch = isAskOracleEndUserConvStyleSwitchEnabled();
  var showAgentSwitch = showProfileAgentSwitch;
  var showSharedProfileSwitch = showAgentSwitch || showNl2sqlSwitch || showRagSwitch;
  var showNl2sqlProfileControls = showNl2sqlSwitch;
  var showRagProfileControls = showRagSwitch;

  applyAskOracleActionControlBodyClasses({
    showAgentSwitch: showAgentSwitch,
    showNl2sqlSwitch: showNl2sqlSwitch,
    showRagSwitch: showRagSwitch,
    showConvStyleSwitch: showConvStyleSwitch,
    showSharedProfileSwitch: showSharedProfileSwitch
  });

  setAskOracleControlVisibilityById("P1_CURRENT_AI_PROFILE", showSharedProfileSwitch);

  [
    "P1_AGENT_PROFILE",
    "P1_AGENT_TEAM",
    "P1_AGENT_SERVICE"
  ].forEach(function(itemId) {
    setAskOracleControlVisibilityById(itemId, showAgentSwitch);
  });

  [
    "P1_SERVICE",
    "P1_PROFILE"
  ].forEach(function(itemId) {
    setAskOracleControlVisibilityById(itemId, showNl2sqlProfileControls);
  });

  [
    "P1_RAG_PROFILE",
    "P1_RAG_CHAT",
    "P1_RAG_SQL",
    "P1_RAGSERVICE"
  ].forEach(function(itemId) {
    setAskOracleControlVisibilityById(itemId, showRagProfileControls);
  });

  setAskOracleControlVisibilityById("P1_CONVERSATION_STYLE", showConvStyleSwitch);
  document.querySelectorAll("[data-conversation-style-switch], .ask-oracle-conversation-style-switch").forEach(function(node) {
    if (!node || !node.style) return;
    if (showConvStyleSwitch) {
      node.style.removeProperty("display");
    } else {
      node.style.setProperty("display", "none", "important");
    }
  });

  var plusBtn = document.getElementById("addPrompt");
  var plusMenu = document.getElementById("plusMenu");
  var promptWrapper = document.getElementById("promptWrapper");
  if (plusBtn) {
    if (showConvStyleSwitch) {
      plusBtn.style.removeProperty("display");
      plusBtn.style.removeProperty("visibility");
      plusBtn.style.removeProperty("pointer-events");
      plusBtn.removeAttribute("hidden");
      plusBtn.setAttribute("aria-hidden", "false");
    } else {
      plusBtn.style.setProperty("display", "none", "important");
      plusBtn.style.setProperty("visibility", "hidden", "important");
      plusBtn.style.setProperty("pointer-events", "none", "important");
      plusBtn.setAttribute("hidden", "hidden");
      plusBtn.setAttribute("aria-hidden", "true");
    }
  }
  if (!showConvStyleSwitch && plusMenu) {
    plusMenu.classList.remove("active");
  }
  if (!showConvStyleSwitch && promptWrapper) {
    promptWrapper.classList.remove("menu-open");
  }
  if (showConvStyleSwitch) {
    var effectiveMode = getAskOracleEffectiveConversationModeForChip();
    applyAskOracleConversationStyleMenuHighlight(effectiveMode);
    updateAskOracleConversationModeChip(effectiveMode);
  }
  applyAskOracleConversationModeControlVisibility(getAskOracleEffectiveConversationModeForChip());
}

function applyAskOracleConversationModeControlVisibility(modeValue) {
  var mode = normalizeAskOracleConversationMode(modeValue) || "CHAT_WITH_DB";
  var isNl2sql = mode === "CHAT_WITH_DB";
  var isRag = mode === "RAG_PROFILES";
  var isAgent = mode === "USER_AGENTS";
  var ragChatEnabled = String(readAskOracleApexItemCurrentValue("P1_RAG_CHAT") || "").trim().toUpperCase() === "Y";
  var askAdb = document.getElementById("P1_ASK_ADB");
  var showNarrate = isNl2sql && !!(askAdb && askAdb.checked);
  setAskOracleControlVisibilityById("P1_ASK_ADB", isNl2sql);
  setAskOracleControlVisibilityById("P1_SWITCH_NARRATE", showNarrate);
  setAskOracleControlVisibilityById("P1_PROFILE", isNl2sql);
  ["P1_RAG_CHAT", "P1_RAG_PROFILE"].forEach(function(id) {
    setAskOracleControlVisibilityById(id, isRag);
  });
  setAskOracleControlVisibilityById("P1_RAG_SQL", isRag && !ragChatEnabled);
  setAskOracleControlVisibilityById("P1_AGENT_PROFILE", isAgent);
  ["P1_CURRENT_AI_PROFILE", "P1_AGENT_TEAM", "P1_AGENT_SERVICE", "P1_SERVICE", "P1_RAGSERVICE"].forEach(function(id) {
    setAskOracleControlVisibilityById(id, false);
  });
  if (document.body) {
    document.body.classList.toggle("ask-oracle-hide-nl2sql-switch", !isNl2sql);
    document.body.classList.toggle("ask-oracle-hide-rag-switch", !isRag);
    document.body.classList.toggle("ask-oracle-hide-agent-switch", !isAgent);
  }
  alignAskOracleConversationModeControlLabel(isNl2sql ? "P1_PROFILE" : (isRag ? "P1_RAG_PROFILE" : (isAgent ? "P1_AGENT_PROFILE" : "")));
}

function alignAskOracleConversationModeControlLabel(itemId) {
  var id = String(itemId || "").trim();
  if (!id) return;
  var field = document.getElementById(id);
  var label = document.querySelector("label[for='" + id + "']");
  var container = getAskOracleControlContainer(field);
  if (container) {
    container.style.setProperty("align-items", "center", "important");
  }
  if (label) {
    label.style.setProperty("display", "inline-flex", "important");
    label.style.setProperty("align-items", "center", "important");
    label.style.setProperty("align-self", "center", "important");
    label.style.setProperty("min-height", "32px", "important");
    label.style.setProperty("margin-top", "0", "important");
    label.style.setProperty("margin-bottom", "0", "important");
  }
}

function applyAskOracleHomeSelectionSync() {
  var currentUiMode = normalizeAskOracleConversationMode(window.ASK_ORACLE_CURRENT_CONVERSATION_MODE || "");
  var syncedMode = normalizeAskOracleConversationMode(getAskOracleUiSyncValue(ASK_ORACLE_SYNC_DEFAULT_CONV_MODE));
  var cfg = getAskOracleAdminConfigSnapshot();
  var cfgMode = normalizeAskOracleConversationMode((cfg && cfg.DEFAULT_CONVERSATION_MODE) || "");
  var applyEndUserControls = shouldApplyAskOracleEndUserActionControls();
  var forceDefaultMode = applyEndUserControls &&
    cfgMode &&
    !isAskOracleEndUserConvStyleSwitchEnabled();
  var convMode = forceDefaultMode
    ? cfgMode
    : (currentUiMode || getAskOracleCurrentConversationMode() || cfgMode || syncedMode);
  if (forceDefaultMode) {
    window.ASK_ORACLE_CURRENT_CONVERSATION_MODE = "";
    persistAskOracleEndUserConversationStylePreference(cfgMode);
  }
  var defaultNl2sqlProfile = String((cfg && cfg.DEFAULT_NL2SQL_PROFILE) || "").trim();
  var defaultRagProfile = String((cfg && cfg.DEFAULT_RAG_PROFILE) || "").trim();
  var defaultAgentTeam = sanitizeAskOracleHomeAgentTeam(String((cfg && cfg.DEFAULT_AGENT_TEAM) || "").trim());
  var syncedAgentTeam = sanitizeAskOracleHomeAgentTeam(getAskOracleUiSyncValue(ASK_ORACLE_SYNC_SELECTED_AGENT));
  var nl2sqlProfile = (isAskOracleEndUserNl2sqlProfileSwitchEnabled() ? getAskOracleUiSyncValue(ASK_ORACLE_SYNC_SELECTED_NL2SQL) : "") || defaultNl2sqlProfile;
  var ragProfile = (isAskOracleEndUserRagProfileSwitchEnabled() ? getAskOracleUiSyncValue(ASK_ORACLE_SYNC_SELECTED_RAG) : "") || defaultRagProfile;
  var agentTeam = sanitizeAskOracleHomeAgentTeam(((isAskOracleEndUserProfileAgentSwitchEnabled() || convMode === "USER_AGENTS") ? syncedAgentTeam : "") || defaultAgentTeam);

  if (convMode) {
    setAskOracleApexItemValueIfPresent("P1_CONV_TYPE", convMode, false);
    setAskOracleApexItemValueIfPresent("P1_CONVERSATION_STYLE", convMode, false);
    applyAskOracleConversationStyleMenuHighlight(convMode);
  }

  var nl2sqlResolved = resolveAskOracleSelectValue("P1_PROFILE", nl2sqlProfile) ||
    resolveAskOracleSelectValue("P1_SERVICE", nl2sqlProfile);
  if (nl2sqlResolved) {
    setAskOracleApexItemValueIfPresent("P1_SERVICE", nl2sqlResolved, false);
    setAskOracleApexItemValueIfPresent("P1_PROFILE", nl2sqlResolved, false);
  }

  var ragResolved = resolveAskOracleSelectValue("P1_RAG_PROFILE", ragProfile) || resolveAskOracleSelectValue("P1_RAGSERVICE", ragProfile) || ragProfile;
  if (ragResolved) {
    setAskOracleApexItemValueIfPresent("P1_RAG_PROFILE", ragResolved, false);
    setAskOracleApexItemValueIfPresent("P1_RAGSERVICE", ragResolved, false);
  }

  var agentResolved = resolveAskOracleSelectValue("P1_AGENT_TEAM", agentTeam) || resolveAskOracleSelectValue("P1_AGENT_PROFILE", agentTeam) || agentTeam;
  if (agentResolved) {
    setAskOracleApexItemValueIfPresent("P1_AGENT_TEAM", agentResolved, false);
    setAskOracleApexItemValueIfPresent("P1_AGENT_PROFILE", agentResolved, false);
    setAskOracleApexItemValueIfPresent("P1_AGENT_SERVICE", agentResolved, false);
  } else {
    var currentAgentTeam = readAskOracleApexItemCurrentValue("P1_AGENT_TEAM");
    var currentAgentProfile = readAskOracleApexItemCurrentValue("P1_AGENT_PROFILE");
    var currentAgentService = readAskOracleApexItemCurrentValue("P1_AGENT_SERVICE");
    var currentProfileValue = readAskOracleApexItemCurrentValue("P1_CURRENT_AI_PROFILE");
    var hasSettingsOnlySelection =
      isAskOracleSettingsOnlyAgentTeam(currentAgentTeam) ||
      isAskOracleSettingsOnlyAgentTeam(currentAgentProfile) ||
      isAskOracleSettingsOnlyAgentTeam(currentAgentService) ||
      isAskOracleSettingsOnlyAgentTeam(currentProfileValue);
    if (hasSettingsOnlySelection) {
      clearAskOracleApexItemValueIfPresent("P1_AGENT_TEAM", false);
      clearAskOracleApexItemValueIfPresent("P1_AGENT_PROFILE", false);
      clearAskOracleApexItemValueIfPresent("P1_AGENT_SERVICE", false);
      clearAskOracleApexItemValueIfPresent("P1_CURRENT_AI_PROFILE", false);
    }
  }

  var activeProfile = "";
  if (convMode === "RAG_PROFILES") {
    activeProfile = ragResolved || nl2sqlResolved || agentResolved;
  } else if (convMode === "USER_AGENTS") {
    activeProfile = agentResolved || nl2sqlResolved || ragResolved;
  } else {
    activeProfile = nl2sqlResolved || ragResolved || agentResolved;
  }
  if (activeProfile) {
    var activeResolved = convMode === "USER_AGENTS"
      ? resolveAskOracleCurrentProfileForAgentTeam(activeProfile)
      : (resolveAskOracleSelectValue("P1_CURRENT_AI_PROFILE", activeProfile) || activeProfile);
    // Keep the display/profile item aligned without retriggering page-level agent/profile DAs.
    setAskOracleApexItemValueIfPresent("P1_CURRENT_AI_PROFILE", activeResolved, false);
  }
  try {
    if (window.jQuery && window.jQuery("#aoConvModeSelect").length) {
      window.jQuery("#aoConvModeSelect").val(convMode || getAskOracleCurrentConversationMode());
    }
  } catch (e) {}
  applyAskOracleConversationStyleMenuHighlight(convMode || getAskOracleCurrentConversationMode());
  updateAskOracleConversationModeChip(convMode || getAskOracleCurrentConversationMode());
}

function normalizeAskOracleAgentTeamName(value) {
  return String(value || "").trim().toUpperCase().replace(/[^A-Z0-9]+/g, "");
}

function isAskOracleSettingsOnlyAgentTeam(value) {
  var normalized = normalizeAskOracleAgentTeamName(value);
  return normalized === "SELECTAIAGENTBUILDER";
}

function sanitizeAskOracleHomeAgentTeam(value) {
  var team = String(value || "").trim();
  if (!team) return "";
  return isAskOracleSettingsOnlyAgentTeam(team) ? "" : team;
}

function applyAskOracleAdminUiState(options) {
  var syncState = readAskOracleUiSyncState();
  if (syncState && syncState.admin_config && typeof syncState.admin_config === "object") {
    window.ASK_ORACLE_ADMIN_CONFIG = mergeAskOracleAdminConfig(window.ASK_ORACLE_ADMIN_CONFIG || {}, syncState.admin_config);
  }
  if (syncState && syncState.default_conversation_mode) {
    window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
    if (!window.ASK_ORACLE_ADMIN_CONFIG.DEFAULT_CONVERSATION_MODE) {
      window.ASK_ORACLE_ADMIN_CONFIG.DEFAULT_CONVERSATION_MODE = String(syncState.default_conversation_mode).trim().toUpperCase();
    }
  }
  applyAskOracleHomeSelectionSync();
  applyAskOracleAppZoomScale();
  applyAskOracleRuntimeTitles();
  applyAskOracleProfileAndStyleSwitchVisibility();
  ensureResponseDownloadButtons();
  applyAskOracleAdminActionButtonVisibility();
  if (document && document.body) {
    setTimeout(showAskOracleAdminSetupModal, 0);
  }
}

var askOracleHomeAdminConfigLoadStarted = false;
var askOracleHomeAdminConfigLoadComplete = false;

function loadAskOracleHomeAdminConfig(callback) {
  var done = typeof callback === "function" ? callback : function() {};
  if (askOracleHomeAdminConfigLoadComplete) {
    done(true);
    return;
  }
  if (askOracleHomeAdminConfigLoadStarted) {
    done(false);
    return;
  }
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) {
    done(false);
    return;
  }
  askOracleHomeAdminConfigLoadStarted = true;
  var processNames = ["SETTINGS_GET_HOME_ADMIN_CONFIG", "SETTINGS_BOOTSTRAP"];
  var tryProcess = function(index) {
    if (index >= processNames.length) {
      askOracleHomeAdminConfigLoadStarted = false;
      done(false);
      return;
    }
    var processName = processNames[index];
    apex.server.process(processName, {}, {
      dataType: "json",
      success: function(pData) {
        var data = pData && typeof pData === "object" ? pData : {};
        if (data.success === false) {
          tryProcess(index + 1);
          return;
        }
        var config = buildAskOracleHomeAdminConfig(data);
        if (!config.ADMIN_OWNER_APP_USER && !config.DEVELOPER_OWNER_APP_USER && !config.USER_OWNER_APP_USER && index + 1 < processNames.length) {
          tryProcess(index + 1);
          return;
        }
      window.ASK_ORACLE_ADMIN_CONFIG = mergeAskOracleAdminConfig(config, {});
      askOracleHomeAdminConfigLoadComplete = true;
      persistAskOracleUiSyncState({
        admin_config: Object.assign({}, window.ASK_ORACLE_ADMIN_CONFIG)
      });
      done(true);
      applyAskOracleAdminUiState({ syncSelections: true });
      },
      error: function() {
        tryProcess(index + 1);
      }
    });
  };
  tryProcess(0);
}

function persistAskOracleConversationModePreference(convMode, onDone) {
  var mode = normalizeAskOracleConversationMode(convMode);
  var callback = typeof onDone === "function" ? onDone : function() {};
  if (!mode) {
    callback("", false, null);
    return;
  }
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) {
    callback(mode, false, null);
    return;
  }

  apex.server.process("SETTINGS_SAVE_CONV_MODE", { x01: mode }, {
    dataType: "json",
    success: function(pData) {
      var response = pData && typeof pData === "object" ? pData : {};
      if (response.success === false) {
        callback(mode, false, response);
        return;
      }
      callback(
        normalizeAskOracleConversationMode(response.conversation_mode || mode) || mode,
        true,
        response
      );
    },
    error: function(jqXHR, textStatus, errorThrown) {
      callback(mode, false, {
        error: jqXHR,
        textStatus: textStatus,
        errorThrown: errorThrown
      });
    }
  });
}

var askOracleLastForcedEndUserConversationMode = "";

function persistAskOracleEndUserConversationStylePreference(convMode) {
  var mode = normalizeAskOracleConversationMode(convMode);
  if (!mode) return;
  var userKey = getAskOracleRuntimeAppUser() || "UNKNOWN_USER";
  var cacheKey = userKey + ":" + mode;
  if (askOracleLastForcedEndUserConversationMode === cacheKey) return;
  askOracleLastForcedEndUserConversationMode = cacheKey;
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) return;

  apex.server.process("SET_CONVERSATION_STYLE", { x01: mode }, {
    dataType: "json",
    error: function(jqXHR, textStatus, errorThrown) {
      askOracleLastForcedEndUserConversationMode = "";
      console.warn("Unable to enforce end-user conversation style:", textStatus || errorThrown || jqXHR);
    }
  });
}

function setConversationStyle(style, options) {
  var convMode = normalizeAskOracleConversationMode(style);
  var opts = options || {};
  var requestedAgentTeam = sanitizeAskOracleHomeAgentTeam(String(opts.selectedAgentTeam || opts.selected_agent_team || "").trim());
  if (!convMode) return;

  if (shouldApplyAskOracleEndUserActionControls() && !isAskOracleEndUserConvStyleSwitchEnabled()) {
    var cfg = getAskOracleAdminConfigSnapshot();
    var cfgDefaultMode = normalizeAskOracleConversationMode((cfg && cfg.DEFAULT_CONVERSATION_MODE) || "");
    var defaultMode = cfgDefaultMode || getAskOracleCurrentConversationMode() || "CHAT_WITH_DB";
    window.ASK_ORACLE_CURRENT_CONVERSATION_MODE = "";
    setAskOracleApexItemValueIfPresent("P1_CONV_TYPE", defaultMode, false);
    setAskOracleApexItemValueIfPresent("P1_CONVERSATION_STYLE", defaultMode, false);
    applyAskOracleConversationStyleMenuHighlight(defaultMode);
    updateAskOracleConversationModeChip(defaultMode);
    applyAskOracleProfileAndStyleSwitchVisibility();
    if (cfgDefaultMode) persistAskOracleEndUserConversationStylePreference(cfgDefaultMode);
    return;
  }

  var closeMenu = function() {
    if (opts.keepMenuOpen === true) return;
    var plusMenu = document.getElementById("plusMenu");
    var promptWrapper = document.getElementById("promptWrapper");
    if (plusMenu) plusMenu.classList.remove("active");
    if (promptWrapper) promptWrapper.classList.remove("menu-open");
  };

  var applyClientState = function(nextMode, animateModeSwitch) {
    var resolvedMode = normalizeAskOracleConversationMode(nextMode || convMode) || convMode;
    window.ASK_ORACLE_CURRENT_CONVERSATION_MODE = resolvedMode;
    try {
      if (document && document.body) document.body.setAttribute("data-ask-oracle-conversation-mode", resolvedMode);
    } catch (e) {}
    setAskOracleApexItemValueIfPresent("P1_CONV_TYPE", resolvedMode, false);
    setAskOracleApexItemValueIfPresent("P1_CONVERSATION_STYLE", resolvedMode, false);
    applyAskOracleConversationStyleMenuHighlight(resolvedMode);
    updateAskOracleConversationModeChip(resolvedMode);
    applyAskOracleProfileAndStyleSwitchVisibility();
    window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
    persistAskOracleUiSyncState({
      default_conversation_mode: resolvedMode
    });
    if (resolvedMode === "USER_AGENTS" && requestedAgentTeam) {
      var resolvedAgentTeam = resolveAskOracleSelectValue("P1_AGENT_TEAM", requestedAgentTeam) ||
        resolveAskOracleSelectValue("P1_AGENT_PROFILE", requestedAgentTeam) ||
        requestedAgentTeam;
      setAskOracleApexItemValueIfPresent("P1_AGENT_TEAM", resolvedAgentTeam, false);
      setAskOracleApexItemValueIfPresent("P1_AGENT_PROFILE", resolvedAgentTeam, false);
      setAskOracleApexItemValueIfPresent("P1_AGENT_SERVICE", resolvedAgentTeam, false);
      setAskOracleApexItemValueIfPresent(
        "P1_CURRENT_AI_PROFILE",
        resolveAskOracleCurrentProfileForAgentTeam(resolvedAgentTeam),
        false
      );
      persistAskOracleUiSyncState({
        selected_agent_team: resolvedAgentTeam
      });
      try {
        if (typeof scheduleAskOracleAdminUiStateApply === "function") {
          scheduleAskOracleAdminUiStateApply(true);
        }
      } catch (e) {}
    }
    try {
      if (window.jQuery && window.jQuery("#aoConvModeSelect").length) {
        window.jQuery("#aoConvModeSelect").val(resolvedMode);
      }
    } catch (e) {}
    if (animateModeSwitch === true) playAskOracleModeSwitchTrace();
  };

  var showSuccess = function(nextMode) {
    if (opts.skipSuccess === true) return;
    var resolvedMode = normalizeAskOracleConversationMode(nextMode || convMode) || convMode;
    var displayName = resolvedMode === "CHAT_WITH_DB"
      ? "NL2SQL"
      : (resolvedMode === "RAG_PROFILES" ? "RAG" : "Agent Team");
    if (window.apex && apex.message && typeof apex.message.showPageSuccess === "function") {
      apex.message.showPageSuccess("Conversation Style Set To: " + displayName);
    }
  };

  var showError = function() {
    if (window.apex && apex.message && typeof apex.message.showErrors === "function") {
      apex.message.clearErrors();
      apex.message.showErrors([{
        type: "error",
        location: "page",
        message: "Failed to set conversation style.",
        unsafe: false
      }]);
    }
  };

  applyAskOracleConversationStyleMenuHighlight(convMode);
  window.ASK_ORACLE_CURRENT_CONVERSATION_MODE = convMode;
  applyAskOracleConversationModeControlVisibility(convMode);

  if (!(window.apex && apex.server && typeof apex.server.process === "function")) {
    applyClientState(convMode, true);
    closeMenu();
    return;
  }

  apex.server.process("SET_CONVERSATION_STYLE", { x01: convMode }, {
    dataType: "json",
    success: function() {
      applyClientState(convMode, true);
      closeMenu();
      showSuccess(convMode);
      if (opts.skipPreferencePersist === true || shouldApplyAskOracleEndUserActionControls()) return;
      persistAskOracleConversationModePreference(convMode, function(savedMode, didPersist, response) {
        if (!didPersist) {
          if (response && (response.message || response.textStatus || response.errorThrown)) {
            console.warn("Conversation mode app_config sync skipped:", response.message || response.textStatus || response.errorThrown);
          }
          return;
        }
        applyClientState(savedMode, false);
      });
    },
    error: function() {
      showError();
    }
  });
}

function installAskOracleConversationStyleOverride() {
  window.setConversationStyle = setConversationStyle;
}

installAskOracleConversationStyleOverride();

function installAskOraclePlusMenuModeInterceptor() {
  if (window.__askOraclePlusMenuModeInterceptorInstalled) return;
  window.__askOraclePlusMenuModeInterceptorInstalled = true;
  window.addEventListener("click", function(event) {
    var target = event && event.target;
    var button = target && typeof target.closest === "function"
      ? target.closest("#plusMenu button[data-style]")
      : null;
    if (!button) return;
    var mode = String(button.getAttribute("data-style") || "").trim();
    if (!mode) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    event.stopPropagation();
    window.setConversationStyle(mode, { skipSuccess: false });
  }, true);
}

installAskOraclePlusMenuModeInterceptor();

function installAskOracleSmoothProfileSwitching() {
  if (window.__askOracleSmoothProfileSwitchInstalled) return;
  window.__askOracleSmoothProfileSwitchInstalled = true;
  document.addEventListener("change", function(event) {
    var field = event && event.target;
    var id = String(field && field.id || "");
    if (id === "P1_RAG_CHAT") {
      event.stopImmediatePropagation();
      applyAskOracleConversationModeControlVisibility(getAskOracleEffectiveConversationModeForChip());
      return;
    }
    if (["P1_SERVICE", "P1_PROFILE", "P1_RAG_PROFILE", "P1_RAGSERVICE", "P1_AGENT_TEAM", "P1_AGENT_PROFILE", "P1_AGENT_SERVICE", "P1_CURRENT_AI_PROFILE"].indexOf(id) < 0) return;
    event.stopImmediatePropagation();
    var value = String(field.value || "").trim();
    if (!value) return;
    if (id === "P1_SERVICE" || id === "P1_PROFILE") {
      setAskOracleApexItemValueIfPresent("P1_SERVICE", value, false);
      setAskOracleApexItemValueIfPresent("P1_PROFILE", value, false);
      setAskOracleApexItemValueIfPresent(
        "P1_CURRENT_AI_PROFILE",
        resolveAskOracleSelectValue("P1_CURRENT_AI_PROFILE", value) || value,
        false
      );
      persistAskOracleUiSyncState({ selected_nl2sql_profile: value });
    } else if (id === "P1_RAG_PROFILE" || id === "P1_RAGSERVICE") {
      ["P1_RAG_PROFILE", "P1_RAGSERVICE"].forEach(function(name) { setAskOracleApexItemValueIfPresent(name, value, false); });
      persistAskOracleUiSyncState({ selected_rag_profile: value });
    } else {
      ["P1_AGENT_TEAM", "P1_AGENT_PROFILE", "P1_AGENT_SERVICE"].forEach(function(name) { setAskOracleApexItemValueIfPresent(name, value, false); });
      setAskOracleApexItemValueIfPresent("P1_CURRENT_AI_PROFILE", resolveAskOracleCurrentProfileForAgentTeam(value), false);
      persistAskOracleUiSyncState({ selected_agent_team: value });
    }
    if (window.apex && apex.server && typeof apex.server.process === "function") {
      apex.server.process("SET_CONVERSATION_STYLE", { x01: getAskOracleCurrentConversationMode() || "CHAT_WITH_DB" }, {
        pageItems: "#P1_SERVICE,#P1_PROFILE,#P1_RAG_PROFILE,#P1_AGENT_PROFILE,#P1_CURRENT_AI_PROFILE"
      });
    }
  }, true);
}

installAskOracleSmoothProfileSwitching();

function installAskOracleAskAdbNarrateSync() {
  if (window.__askOracleAskAdbNarrateSyncInstalled) return;
  window.__askOracleAskAdbNarrateSyncInstalled = true;
  document.addEventListener("change", function(event) {
    var field = event && event.target;
    if (!field || field.id !== "P1_ASK_ADB") return;
    applyAskOracleConversationModeControlVisibility(getAskOracleEffectiveConversationModeForChip());
  }, true);
}

installAskOracleAskAdbNarrateSync();
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", function() {
    [0, 200, 800].forEach(function(delay) {
      setTimeout(installAskOracleConversationStyleOverride, delay);
    });
  }, { once: true });
} else {
  [0, 200, 800].forEach(function(delay) {
    setTimeout(installAskOracleConversationStyleOverride, delay);
  });
}

function applyAskOracleRuntimeTitles() {
  var appDisplayName = getAskOracleAppDisplayName();
  var appLogoUrl = getAskOracleAppLogoUrl();
  var promptBarTitle = getAskOraclePromptBarTitle();
  var promptPlaceholder = getAskOraclePromptPlaceholder();
  var aiInfoMessage = getAskOracleAiInfoMessage();
  var centerTitle = document.getElementById("center-prompt-title");
  var promptInput = document.getElementById("P1_PROMPT1");
  var aiInfoText = document.querySelector("#static-region-footer .sr-footer-inner span");
  var headerTextNodes = document.querySelectorAll(
    ".t-Header-logo-link .t-Header-logo-text, .t-Header-logo .t-Header-logo-text, .apex-logo-text"
  );

  if (centerTitle) {
    centerTitle.textContent = promptBarTitle;
  }

  if (promptInput) {
    promptInput.setAttribute("placeholder", promptPlaceholder);
  }

  if (aiInfoText) {
    aiInfoText.textContent = aiInfoMessage;
  }

  headerTextNodes.forEach(function(node) {
    node.textContent = appDisplayName;
  });

  var headerLink = document.querySelector(".t-Header-logo-link");
  if (headerLink) {
    headerLink.setAttribute("title", appDisplayName);
    headerLink.setAttribute("aria-label", appDisplayName);
    applyAskOracleRuntimeLogo(headerLink, appLogoUrl, appDisplayName);
  }

  if (document && typeof document.title === "string" && appDisplayName) {
    document.title = appDisplayName;
  }
}

function applyAskOracleRuntimeLogo(headerLink, logoUrl, appDisplayName) {
  if (!headerLink || !headerLink.querySelector) return;
  ensureAskOracleRuntimeLogoCss();
  var url = String(logoUrl || "").trim();
  var existing = headerLink.querySelector(".ask-oracle-custom-app-logo");
  if (!url) {
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
    headerLink.classList.remove("ask-oracle-custom-logo-active");
    return;
  }
  if (!existing) {
    existing = document.createElement("img");
    existing.className = "ask-oracle-custom-app-logo";
    existing.alt = "";
    existing.setAttribute("aria-hidden", "true");
    existing.addEventListener("error", function() {
      this.style.display = "none";
    });
    existing.addEventListener("load", function() {
      this.style.removeProperty("display");
    });
    var textNode = headerLink.querySelector(".t-Header-logo-text, .apex-logo-text");
    if (textNode && textNode.parentNode === headerLink) {
      headerLink.insertBefore(existing, textNode);
    } else {
      headerLink.insertBefore(existing, headerLink.firstChild);
    }
  }
  if (existing.getAttribute("src") !== url) {
    existing.setAttribute("src", url);
  }
  existing.setAttribute("title", appDisplayName || "");
  headerLink.classList.add("ask-oracle-custom-logo-active");
}

function scheduleAskOracleAdminUiStateApply(syncSelections) {
  while (askOracleAdminUiStateTimerIds.length) {
    var timerId = askOracleAdminUiStateTimerIds.pop();
    clearTimeout(timerId);
  }
  // The successful configuration callback below performs the final pass.
  // Additional timed passes only flash the mode-specific labels and controls.
  [0].forEach(function(delay) {
    var timer = setTimeout(function() {
      if (!askOracleHomeAdminConfigLoadComplete) {
        applyAskOracleAdminUiState({ syncSelections: syncSelections === true });
        loadAskOracleHomeAdminConfig(function(loaded) {
          if (!loaded) applyAskOracleAdminUiState({ syncSelections: syncSelections === true });
        });
        return;
      }
      applyAskOracleAdminUiState({ syncSelections: syncSelections === true });
    }, delay);
    askOracleAdminUiStateTimerIds.push(timer);
  });
}

function refreshAskOracleProfileControlsAfterAdminSetup() {
  // The first admin save happens after the page's initial Dynamic Actions have
  // already evaluated the anonymous-user state. Reload the configuration and
  // replay the active mode change after the profile controls are available.
  askOracleHomeAdminConfigLoadComplete = false;
  loadAskOracleHomeAdminConfig(function() {
    [0, 250, 900, 1800, 3200].forEach(function(delay) {
      setTimeout(function() {
        applyAskOracleAdminUiState({ syncSelections: true });
        var mode = getAskOracleCurrentConversationMode() || "CHAT_WITH_DB";
        setAskOracleApexItemValueIfPresent("P1_CONV_TYPE", mode, false);
        setAskOracleApexItemValueIfPresent("P1_CONVERSATION_STYLE", mode, false);
        applyAskOracleProfileAndStyleSwitchVisibility();
      }, delay);
    });
  });
}

function scrollToBottom() {
    window.scrollTo({
        top: document.body.scrollHeight,
        behavior: 'smooth'  // use 'auto' if you don’t want smooth scroll
    });
}

//Text to Speech

// ================== VOICE LOADING ==================
var voices = [];
var selectedVoice = null;

function loadVoices() {
  voices = speechSynthesis.getVoices();
  // Pick a male voice if available
  selectedVoice = voices.find(v =>
    v.name === "Google UK English Male" ||
    v.name.includes("Microsoft David") ||
    v.name.includes("Alex") ||
    v.name.toLowerCase().includes("male")
  ) || voices.find(v => v.lang.startsWith("en")); // fallback English voice
}
speechSynthesis.onvoiceschanged = loadVoices;
loadVoices();

// ================== SPEECH STATE ==================
var speechState = {}; 
var currentSpeakingId = null; 

function splitSentences(text) {
  return text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
}

var APP_MODAL_CSS_ID = "ask-oracle-app-modal-css";
var activeAppConfirmDialog = null;
var ASK_ORACLE_PREF_KEY_PREFIX = "ask-oracle-pref";
var ASK_ORACLE_RUN_SQL_CONFIRM_PREF = "skip-run-sql-confirm-session-v1";
var ASK_ORACLE_SCROLL_STATE_SUFFIX = "scroll-state";
var ASK_ORACLE_SCROLL_PENDING_SUFFIX = "scroll-pending";
var ASK_ORACLE_CONV_NAV_ACTIVE_CSS_ID = "ask-oracle-conv-nav-active-css";
var ASK_ORACLE_CONV_NAV_ACTIVE_CLASS = "ask-oracle-conversation-active";
var ASK_ORACLE_SUPPRESS_APEX_LOADING_CSS_ID = "ask-oracle-suppress-apex-loading-css";
var ASK_ORACLE_SUPPRESS_APEX_LOADING_CLASS = "ask-oracle-suppress-apex-loading";
var ASK_ORACLE_HISTORY_NEW_ENTRY_CSS_ID = "ask-oracle-history-new-entry-css";
var ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS = "ask-oracle-history-new-entry";
var ASK_ORACLE_HISTORY_DELETE_ACTION_CSS_ID = "ask-oracle-history-delete-action-css";
var ASK_ORACLE_HISTORY_EDIT_BTN_CLASS = "ask-oracle-history-edit-btn";
var ASK_ORACLE_HISTORY_PIN_BTN_CLASS = "ask-oracle-history-pin-btn";
var ASK_ORACLE_HISTORY_DELETE_BTN_CLASS = "ask-oracle-history-delete-btn";
var ASK_ORACLE_HISTORY_MORE_BTN_CLASS = "ask-oracle-history-more-btn";
var ASK_ORACLE_HISTORY_ACTION_MENU_CLASS = "ask-oracle-history-action-menu";
var ASK_ORACLE_AGENTS_NAV_CSS_ID = "ask-oracle-agents-nav-css";
var ASK_ORACLE_AGENTS_NAV_SECTION_ID = "ask-oracle-agents-nav-section";
var ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL = "Recents";
var ASK_ORACLE_CONVERSATION_DOM_CACHE_MAX = 10;
var ASK_ORACLE_CONVERSATION_DOM_CACHE_ENABLED = false;
var DELETE_CONVERSATION_PROCESS_NAME = "DELETE_CONVERSATION";
var PIN_CONVERSATION_PROCESS_NAME = "PIN_CONV";
var UNPIN_CONVERSATION_PROCESS_NAME = "UNNPIN_CONV";
var UNPIN_CONVERSATION_PROCESS_NAME_LEGACY = "UNPIN_CONV";
var PINNED_CONVERSATION_RETENTION_PROCESS_NAME = "ASK_ORACLE_SET_PINNED_RETENTION";
var EDIT_CONVERSATION_TITLE_PROCESS_NAME = "EDIT_CONV_TITLE";
var askOracleAgentTeamChanged = false;
var askOracleConversationSwitchInProgress = false;
var askOracleQueuedConversationId = "";
var askOracleActiveNavConversationId = "";
var askOracleSuppressApexLoadingReleaseTimer = null;
var askOracleConversationNavRefreshInFlight = false;
var askOracleHistoryNavRefreshedByConversationId = Object.create(null);
var askOraclePendingHistoryNavByConversationId = Object.create(null);
var askOracleHistoryNavInsertedEntryByKey = Object.create(null);
var askOraclePendingHistoryNavEntryByKey = Object.create(null);
var askOracleHistoryNavEntryByKey = Object.create(null);
var askOracleHistoryNavEntryOrder = [];
var askOracleConversationDomCacheById = Object.create(null);
var askOracleConversationDomCacheOrder = [];
var askOracleActiveInlineTitleEditConversationId = "";
var askOracleActiveHistoryActionMenu = null;

function ensureAskOracleSuppressApexLoadingCss() {
  if (document.getElementById(ASK_ORACLE_SUPPRESS_APEX_LOADING_CSS_ID)) return;
  const style = document.createElement("style");
  style.id = ASK_ORACLE_SUPPRESS_APEX_LOADING_CSS_ID;
  style.textContent = `
    body.${ASK_ORACLE_SUPPRESS_APEX_LOADING_CLASS} #apex_wait_overlay,
    body.${ASK_ORACLE_SUPPRESS_APEX_LOADING_CLASS} #apex_wait_popup {
      display: none !important;
      visibility: hidden !important;
      opacity: 0 !important;
      pointer-events: none !important;
    }
  `;
  document.head.appendChild(style);
}

function hideAskOracleDefaultPageLoadingIndicators() {
  if (!document.body) return;
  ensureAskOracleSuppressApexLoadingCss();
  document.body.classList.add(ASK_ORACLE_SUPPRESS_APEX_LOADING_CLASS);
}

function suppressAskOracleDefaultPageLoadingIndicators(durationMs) {
  hideAskOracleDefaultPageLoadingIndicators();
  if (askOracleSuppressApexLoadingReleaseTimer) {
    clearTimeout(askOracleSuppressApexLoadingReleaseTimer);
    askOracleSuppressApexLoadingReleaseTimer = null;
  }

  const releaseDelay = Math.max(300, Number(durationMs) || 1800);
  askOracleSuppressApexLoadingReleaseTimer = setTimeout(function() {
    askOracleSuppressApexLoadingReleaseTimer = null;
    if (!document.body) return;
    document.body.classList.remove(ASK_ORACLE_SUPPRESS_APEX_LOADING_CLASS);
  }, releaseDelay);
}

function clearAskOracleSuppressedLoadingClass() {
  if (!document.body) return;
  document.body.classList.remove(ASK_ORACLE_SUPPRESS_APEX_LOADING_CLASS);
}

var askOracleSspViolationSuppressionInstalled = false;
var askOracleSspViolationDomObserver = null;

function shouldSuppressAskOracleSspViolationText(value) {
  const text = String(value || "").toLowerCase();
  if (!text) return false;
  return text.indexOf("session state protection violation") >= 0 && text.indexOf("p1_conv_id") >= 0;
}

function extractAskOracleErrorText(entry) {
  if (entry == null) return "";
  if (typeof entry === "string") return entry;
  if (typeof entry === "object") {
    return [
      entry.message,
      entry.unsafeMessage,
      entry.additionalInfo,
      entry.pageItem,
      entry.location
    ].filter(Boolean).join(" ");
  }
  return String(entry);
}

function hideAskOracleSuppressedErrorsInDom(root) {
  const scope = root && typeof root.querySelectorAll === "function" ? root : document;
  if (!scope || typeof scope.querySelectorAll !== "function") return;
  const selectors = [
    ".t-Alert",
    ".a-Notification",
    ".a-AlertMessage",
    ".apex-page-error",
    ".apex-error-message",
    "#APEX_ERROR_MESSAGE"
  ];
  scope.querySelectorAll(selectors.join(",")).forEach((node) => {
    const text = node && node.textContent ? node.textContent : "";
    if (!shouldSuppressAskOracleSspViolationText(text)) return;
    node.style.display = "none";
    node.setAttribute("data-ask-oracle-suppressed", "true");
  });
}

function installAskOracleSspViolationSuppression() {
  if (askOracleSspViolationSuppressionInstalled) return;
  askOracleSspViolationSuppressionInstalled = true;

  if (window.apex && apex.message && typeof apex.message.showErrors === "function") {
    const originalShowErrors = apex.message.showErrors.bind(apex.message);
    apex.message.showErrors = function(errors) {
      const list = Array.isArray(errors) ? errors : (errors == null ? [] : [errors]);
      const filtered = list.filter((entry) => {
        if (!entry) return false;
        return !shouldSuppressAskOracleSspViolationText(extractAskOracleErrorText(entry));
      });
      if (filtered.length === 0) {
        hideAskOracleSuppressedErrorsInDom(document);
        return;
      }
      const normalized = filtered.map((entry) => {
        if (typeof entry === "string") {
          return {
            type: "error",
            location: "page",
            message: entry,
            unsafe: false
          };
        }
        return entry;
      }).filter(Boolean);
      if (normalized.length === 0) {
        hideAskOracleSuppressedErrorsInDom(document);
        return;
      }
      return originalShowErrors(normalized);
    };
  }

  hideAskOracleSuppressedErrorsInDom(document);
  if (!window.MutationObserver || askOracleSspViolationDomObserver || !document.body) return;
  askOracleSspViolationDomObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (!mutation || !mutation.addedNodes || mutation.addedNodes.length === 0) return;
      mutation.addedNodes.forEach((node) => {
        if (!node || node.nodeType !== 1) return;
        hideAskOracleSuppressedErrorsInDom(node);
      });
    });
  });
  askOracleSspViolationDomObserver.observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", function() {
    clearAskOracleSuppressedLoadingClass();
    installAskOracleSspViolationSuppression();
  }, { once: true });
} else {
  clearAskOracleSuppressedLoadingClass();
  installAskOracleSspViolationSuppression();
}

function ensureAppModalCss() {
  if (document.getElementById(APP_MODAL_CSS_ID)) return;
  const style = document.createElement("style");
  style.id = APP_MODAL_CSS_ID;
  style.textContent = `
    .ask-oracle-modal-overlay {
      position: fixed;
      inset: 0;
      background: rgba(15, 23, 42, 0.45);
      backdrop-filter: blur(2px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
      z-index: 2147483300;
    }
    .ask-oracle-modal {
      width: min(560px, 95vw);
      background: #ffffff;
      border: 1px solid #dbe4ef;
      border-radius: 14px;
      box-shadow: 0 28px 60px rgba(2, 6, 23, 0.25);
      overflow: hidden;
    }
    .ask-oracle-modal-header {
      padding: 14px 18px;
      border-bottom: 1px solid #e2e8f0;
      font-size: 15px;
      font-weight: 700;
      color: #0f172a;
      background: #f8fafc;
    }
    .ask-oracle-modal-header-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .ask-oracle-modal-close {
      appearance: none;
      border: 0;
      background: transparent;
      color: #475569;
      cursor: pointer;
      font-size: 24px;
      line-height: 1;
      padding: 0 2px;
    }
    .ask-oracle-modal-close:hover,
    .ask-oracle-modal-close:focus-visible {
      color: #0f172a;
    }
    .ask-oracle-modal.ask-oracle-modal--admin .ask-oracle-modal-header {
      font-size: 18px;
      font-weight: 700;
      letter-spacing: 0.1px;
    }
    .ask-oracle-modal-body {
      padding: 18px;
      font-size: 14px;
      line-height: 1.5;
      color: #1f2937;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .ask-oracle-modal-body .ask-oracle-modal-copy {
      margin: 0 0 12px;
      white-space: normal;
      color: #334155;
    }
    .ask-oracle-modal.ask-oracle-modal--admin .ask-oracle-modal-body {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .ask-oracle-admin-info-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 10px;
    }
    .ask-oracle-admin-info-card {
      border: 1px solid #dbe4ef;
      border-radius: 10px;
      background: #f8fbff;
      padding: 10px 12px;
    }
    .ask-oracle-admin-info-title {
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.2px;
      text-transform: uppercase;
      color: #1d4ed8;
      margin: 0 0 4px;
    }
    .ask-oracle-admin-info-text {
      margin: 0;
      font-size: 13px;
      color: #334155;
      line-height: 1.45;
    }
    .ask-oracle-admin-label {
      font-size: 13px;
      font-weight: 600;
      color: #0f172a;
      margin: 2px 0 -4px;
    }
    .ask-oracle-modal-input {
      width: 100%;
      min-height: 96px;
      resize: vertical;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      padding: 11px 12px;
      font-size: 14px;
      line-height: 1.45;
      color: #0f172a;
      background: #ffffff;
      box-sizing: border-box;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ask-oracle-modal-input:focus {
      outline: none;
      border-color: #2563eb;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.18);
    }
    .ask-oracle-modal-inline-error {
      margin-top: 10px;
      font-size: 12px;
      color: #b91c1c;
      min-height: 18px;
      white-space: normal;
    }
    .ask-oracle-modal-help {
      margin-top: 4px;
      font-size: 12px;
      color: #64748b;
      white-space: normal;
    }
    .ask-oracle-admin-example {
      font-size: 12px;
      color: #475569;
      margin-top: -2px;
      white-space: normal;
    }
    .ask-oracle-admin-current-user {
      font-size: 12px;
      color: #334155;
      background: #f1f5f9;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 6px 8px;
    }
    .ask-oracle-modal-check {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 10px;
      font-size: 13px;
      color: #334155;
      line-height: 1.3;
      user-select: none;
    }
    .ask-oracle-modal-check input[type="checkbox"] {
      width: 14px;
      height: 14px;
      margin: 0;
      accent-color: #1d4ed8;
      cursor: pointer;
    }
    .ask-oracle-modal-check span {
      cursor: pointer;
    }
    .ask-oracle-modal-check-note {
      margin-top: 4px;
      margin-left: 22px;
      font-size: 12px;
      line-height: 1.3;
      color: #64748b;
    }
    .ask-oracle-modal-actions {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      padding: 14px 18px 18px;
      border-top: 1px solid #e2e8f0;
      background: #f8fafc;
    }
    .ask-oracle-modal-btn {
      border: 1px solid #cbd5e1;
      border-radius: 9px;
      min-height: 36px;
      padding: 8px 14px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      background: #ffffff;
      color: #1f2937;
      transition: background-color 0.12s ease, border-color 0.12s ease, color 0.12s ease, transform 0.05s ease;
    }
    .ask-oracle-modal-btn:hover {
      background: #f1f5f9;
    }
    .ask-oracle-modal-btn:active {
      transform: translateY(1px);
    }
    .ask-oracle-modal-btn:disabled {
      opacity: 0.7;
      cursor: not-allowed;
      transform: none;
    }
    .ask-oracle-modal-btn.confirm {
      background: #1d4ed8;
      border-color: #1d4ed8;
      color: #ffffff;
    }
    .ask-oracle-modal-btn.confirm:hover {
      background: #1e40af;
      border-color: #1e40af;
    }
    @media (max-width: 640px) {
      .ask-oracle-modal-overlay {
        padding: 14px;
      }
      .ask-oracle-modal {
        width: min(100%, 100vw);
      }
      .ask-oracle-modal-header {
        padding: 12px 14px;
      }
      .ask-oracle-modal-body {
        padding: 14px;
      }
      .ask-oracle-modal-actions {
        padding: 12px 14px 14px;
      }
      .ask-oracle-admin-info-grid {
        grid-template-columns: 1fr;
      }
    }
    .ask-oracle-toast-host {
      position: fixed;
      right: 14px;
      bottom: 18px;
      z-index: 2147483400;
      display: flex;
      flex-direction: column;
      gap: 8px;
      pointer-events: none;
    }
    .ask-oracle-toast {
      pointer-events: auto;
      max-width: min(420px, 90vw);
      background: #0f172a;
      color: #e2e8f0;
      border: 1px solid #334155;
      border-radius: 8px;
      padding: 9px 10px;
      box-shadow: 0 12px 24px rgba(2, 6, 23, 0.3);
      font-size: 13px;
      line-height: 1.35;
    }
    .ask-oracle-toast.success {
      border-color: #166534;
      background: #052e16;
      color: #dcfce7;
    }
    .ask-oracle-toast.error {
      border-color: #991b1b;
      background: #450a0a;
      color: #fee2e2;
    }
  `;
  document.head.appendChild(style);
}

function getAskOracleAppIdentity() {
  let appId = "";
  let appUser = "";
  try {
    if (window.apex && apex.env && apex.env.APP_ID) appId = String(apex.env.APP_ID);
    if (window.apex && apex.env && apex.env.APP_USER) appUser = String(apex.env.APP_USER);
  } catch (e) {}
  try {
    if (!appId && typeof window.$v === "function") appId = String(window.$v("pFlowId") || "");
    if (!appUser && typeof window.$v === "function") appUser = String(window.$v("APP_USER") || "");
  } catch (e) {}
  appId = appId.trim() || "app";
  appUser = appUser.trim() || "user";
  return { appId, appUser };
}

function getAskOracleScopedStorageKey(suffix) {
  const identity = getAskOracleAppIdentity();
  return `${ASK_ORACLE_PREF_KEY_PREFIX}:${identity.appId}:${identity.appUser}:${String(suffix || "").trim()}`;
}

function getAskOracleBooleanPreference(prefName, fallbackValue) {
  try {
    const raw = localStorage.getItem(getAskOracleScopedStorageKey(prefName));
    if (raw == null) return !!fallbackValue;
    const normalized = String(raw).trim().toLowerCase();
    if (normalized === "1" || normalized === "true" || normalized === "y" || normalized === "yes") return true;
    if (normalized === "0" || normalized === "false" || normalized === "n" || normalized === "no") return false;
  } catch (e) {}
  return !!fallbackValue;
}

function setAskOracleBooleanPreference(prefName, value) {
  try {
    localStorage.setItem(getAskOracleScopedStorageKey(prefName), value ? "1" : "0");
  } catch (e) {}
}

function getAskOracleSessionBooleanPreference(prefName, fallbackValue) {
  try {
    const raw = sessionStorage.getItem(getAskOracleScopedStorageKey(prefName));
    if (raw == null) return !!fallbackValue;
    const normalized = String(raw).trim().toLowerCase();
    if (normalized === "1" || normalized === "true" || normalized === "y" || normalized === "yes") return true;
    if (normalized === "0" || normalized === "false" || normalized === "n" || normalized === "no") return false;
  } catch (e) {}
  return !!fallbackValue;
}

function setAskOracleSessionBooleanPreference(prefName, value) {
  try {
    sessionStorage.setItem(getAskOracleScopedStorageKey(prefName), value ? "1" : "0");
  } catch (e) {}
}

function getAskOracleScrollStateKey() {
  return getAskOracleScopedStorageKey(ASK_ORACLE_SCROLL_STATE_SUFFIX);
}

function getAskOracleScrollPendingKey() {
  return getAskOracleScopedStorageKey(ASK_ORACLE_SCROLL_PENDING_SUFFIX);
}

function getAppToastHost() {
  ensureAppModalCss();
  let host = document.getElementById("ask-oracle-toast-host");
  if (host) return host;
  host = document.createElement("div");
  host.id = "ask-oracle-toast-host";
  host.className = "ask-oracle-toast-host";
  document.body.appendChild(host);
  return host;
}

function showAppToast(message, type, timeoutMs) {
  const text = String(message || "").trim();
  if (!text) return;
  const host = getAppToastHost();
  const toast = document.createElement("div");
  const safeType = type === "success" || type === "error" ? type : "";
  toast.className = `ask-oracle-toast${safeType ? ` ${safeType}` : ""}`;
  toast.textContent = text;
  host.appendChild(toast);
  setTimeout(() => {
    try { toast.remove(); } catch (e) {}
  }, Math.max(1200, Number(timeoutMs) || 2400));
}

function closeActiveAppConfirmDialog(result) {
  if (!activeAppConfirmDialog) return false;
  const dialog = activeAppConfirmDialog;
  activeAppConfirmDialog = null;
  try {
    if (dialog.keyHandler) {
      document.removeEventListener("keydown", dialog.keyHandler, true);
    }
    if (dialog.overlay && dialog.overlay.parentElement) {
      dialog.overlay.remove();
    }
  } catch (e) {}
  if (typeof dialog.resolve === "function") {
    const resolvedValue = result === undefined ? false : result;
    try { dialog.resolve(resolvedValue); } catch (e) {}
  }
  return true;
}

function showAppConfirmDialog(message, options) {
  ensureAppModalCss();
  closeActiveAppConfirmDialog(false);

  const opts = options || {};
  const title = String(opts.title || "Please confirm");
  const body = String(message || "");
  const confirmLabel = String(opts.confirmLabel || "Confirm");
  const cancelLabel = String(opts.cancelLabel || "Cancel");

  return new Promise((resolve) => {
    const overlay = document.createElement("div");
    overlay.className = "ask-oracle-modal-overlay";
    overlay.innerHTML = `
      <div class="ask-oracle-modal" role="dialog" aria-modal="true" aria-labelledby="ask-oracle-modal-title">
        <div id="ask-oracle-modal-title" class="ask-oracle-modal-header">${escapeHtml(title)}</div>
        <div class="ask-oracle-modal-body">${escapeHtml(body)}</div>
        <div class="ask-oracle-modal-actions">
          <button type="button" class="ask-oracle-modal-btn cancel">${escapeHtml(cancelLabel)}</button>
          <button type="button" class="ask-oracle-modal-btn confirm">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    function keyHandler(event) {
      if (event.key === "Escape") {
        event.preventDefault();
        closeActiveAppConfirmDialog(false);
      }
    }
    document.addEventListener("keydown", keyHandler, true);

    activeAppConfirmDialog = { overlay, resolve, keyHandler };

    const confirmBtn = overlay.querySelector(".ask-oracle-modal-btn.confirm");
    const cancelBtn = overlay.querySelector(".ask-oracle-modal-btn.cancel");
    if (confirmBtn) confirmBtn.addEventListener("click", () => closeActiveAppConfirmDialog(true));
    if (cancelBtn) cancelBtn.addEventListener("click", () => closeActiveAppConfirmDialog(false));
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) closeActiveAppConfirmDialog(false);
    });
    try { if (confirmBtn) confirmBtn.focus({ preventScroll: true }); } catch (e) {}
  });
}

function showAppConfirmDialogWithDoNotAsk(message, options) {
  ensureAppModalCss();
  closeActiveAppConfirmDialog({ confirmed: false, doNotAskAgain: false });

  const opts = options || {};
  const title = String(opts.title || "Please confirm");
  const body = String(message || "");
  const confirmLabel = String(opts.confirmLabel || "Confirm");
  const cancelLabel = String(opts.cancelLabel || "Cancel");
  const checkboxLabel = String(opts.checkboxLabel || "Do not ask again");
  const checkboxNote = String(opts.checkboxNote || "Saved for this session only.");

  return new Promise((resolve) => {
    const overlay = document.createElement("div");
    overlay.className = "ask-oracle-modal-overlay";
    const checkboxId = `ask-oracle-confirm-skip-${Date.now()}`;
    overlay.innerHTML = `
      <div class="ask-oracle-modal" role="dialog" aria-modal="true" aria-labelledby="ask-oracle-modal-title">
        <div id="ask-oracle-modal-title" class="ask-oracle-modal-header">${escapeHtml(title)}</div>
        <div class="ask-oracle-modal-body">
          ${escapeHtml(body)}
          <label class="ask-oracle-modal-check" for="${checkboxId}">
            <input id="${checkboxId}" type="checkbox" />
            <span>${escapeHtml(checkboxLabel)}</span>
          </label>
          <div class="ask-oracle-modal-check-note">${escapeHtml(checkboxNote)}</div>
        </div>
        <div class="ask-oracle-modal-actions">
          <button type="button" class="ask-oracle-modal-btn cancel">${escapeHtml(cancelLabel)}</button>
          <button type="button" class="ask-oracle-modal-btn confirm">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    function readResult(confirmed) {
      const checkboxEl = overlay.querySelector(`#${checkboxId}`);
      return {
        confirmed: !!confirmed,
        doNotAskAgain: !!(confirmed && checkboxEl && checkboxEl.checked)
      };
    }

    function keyHandler(event) {
      if (event.key === "Escape") {
        event.preventDefault();
        closeActiveAppConfirmDialog(readResult(false));
      }
    }
    document.addEventListener("keydown", keyHandler, true);

    activeAppConfirmDialog = { overlay, resolve, keyHandler };

    const confirmBtn = overlay.querySelector(".ask-oracle-modal-btn.confirm");
    const cancelBtn = overlay.querySelector(".ask-oracle-modal-btn.cancel");
    if (confirmBtn) confirmBtn.addEventListener("click", () => closeActiveAppConfirmDialog(readResult(true)));
    if (cancelBtn) cancelBtn.addEventListener("click", () => closeActiveAppConfirmDialog(readResult(false)));
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) closeActiveAppConfirmDialog(readResult(false));
    });
    try { if (confirmBtn) confirmBtn.focus({ preventScroll: true }); } catch (e) {}
  });
}

function normalizeAskOracleAdminOwnersCsv(rawValue) {
  var text = String(rawValue == null ? "" : rawValue).trim().toUpperCase();
  text = text.replace(/[\r\n]+/g, ",");
  text = text.replace(/[;]+/g, ",");
  text = text.replace(/\s*,\s*/g, ",");
  text = text.replace(/,+/g, ",");
  text = text.replace(/^,|,$/g, "");
  return text;
}

function isAskOracleAdminProcessMissingMessage(message) {
  var text = String(message || "");
  return /process\s+[a-z0-9_]+\s+not\s+found/i.test(text);
}

function readAskOracleAdminSetupDismissedFlag() {
  try {
    return sessionStorage.getItem(ASK_ORACLE_ADMIN_SETUP_DISMISS_KEY) === "Y";
  } catch (e) {
    return false;
  }
}

function markAskOracleAdminSetupDismissed() {
  try {
    sessionStorage.setItem(ASK_ORACLE_ADMIN_SETUP_DISMISS_KEY, "Y");
  } catch (e) {}
}

function clearAskOracleAdminSetupDismissed() {
  try {
    sessionStorage.removeItem(ASK_ORACLE_ADMIN_SETUP_DISMISS_KEY);
  } catch (e) {}
}

function getAskOracleAdminOwnerConfigValue() {
  var cfg = getAskOracleAdminConfigSnapshot();
  if (!cfg || typeof cfg !== "object") return "";
  var raw = "";
  if (Object.prototype.hasOwnProperty.call(cfg, "ADMIN_OWNER_APP_USER")) {
    raw = cfg.ADMIN_OWNER_APP_USER;
  } else if (Object.prototype.hasOwnProperty.call(cfg, "admin_owner_app_user")) {
    raw = cfg.admin_owner_app_user;
  }
  return normalizeAskOracleAdminOwnersCsv(raw);
}

function isAskOracleAdminOwnerSetupRequired() {
  var cfg = getAskOracleAdminConfigSnapshot();
  if (!cfg || typeof cfg !== "object") return false;
  var hasKey =
    Object.prototype.hasOwnProperty.call(cfg, "ADMIN_OWNER_APP_USER") ||
    Object.prototype.hasOwnProperty.call(cfg, "admin_owner_app_user");
  if (!hasKey) {
    // If admin config payload is loaded but admin-owner key is absent,
    // treat it as not configured.
    return Object.keys(cfg).length > 0;
  }
  return !getAskOracleAdminOwnerConfigValue();
}

function resolveAskOracleAdminOwnerSetupRequired() {
  if (askOracleAdminSetupCheckPromise) return askOracleAdminSetupCheckPromise;

  askOracleAdminSetupCheckPromise = new Promise(function(resolve) {
    if (!(window.apex && apex.server && typeof apex.server.process === "function")) {
      resolve(isAskOracleAdminOwnerSetupRequired());
      return;
    }

    apex.server.process("SETTINGS_GET_HOME_ADMIN_USERS", {}, {
      dataType: "json",
      success: function(pData) {
        var data = pData && typeof pData === "object" ? pData : {};
        if (data.success === false) {
          resolve(isAskOracleAdminOwnerSetupRequired());
          return;
        }
        var owners = normalizeAskOracleAdminOwnersCsv(data.config_value);
        window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
        window.ASK_ORACLE_ADMIN_CONFIG.ADMIN_OWNER_APP_USER = owners;
        persistAskOracleUiSyncState({
          admin_config: Object.assign({}, window.ASK_ORACLE_ADMIN_CONFIG)
        });
        if (owners) {
          clearAskOracleAdminSetupDismissed();
          resolve(false);
          return;
        }
        resolve(true);
      },
      error: function(jqXHR) {
        var msg = "";
        try { msg = String((jqXHR && (jqXHR.responseText || jqXHR.statusText)) || ""); } catch (e1) {}
        if (isAskOracleAdminProcessMissingMessage(msg)) {
          resolve(isAskOracleAdminOwnerSetupRequired());
          return;
        }
        resolve(isAskOracleAdminOwnerSetupRequired());
      }
    });
  }).finally(function() {
    askOracleAdminSetupCheckPromise = null;
  });

  return askOracleAdminSetupCheckPromise;
}

function saveAskOracleAdminOwnerUsers(adminUsersCsv) {
  var value = normalizeAskOracleAdminOwnersCsv(adminUsersCsv);
  if (!value) {
    return Promise.resolve({ success: false, message: "Please enter at least one admin user." });
  }
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) {
    return Promise.resolve({ success: false, message: "APEX runtime unavailable." });
  }

  function isProcessMissingMessage(message) {
    var text = String(message || "");
    return /process\s+[a-z0-9_]+\s+not\s+found/i.test(text);
  }

  function applySavedAdminValue(savedValue) {
    window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
    window.ASK_ORACLE_ADMIN_CONFIG.ADMIN_OWNER_APP_USER = String(savedValue || value).toUpperCase();
    persistAskOracleUiSyncState({
      admin_config: Object.assign({}, window.ASK_ORACLE_ADMIN_CONFIG)
    });
    return window.ASK_ORACLE_ADMIN_CONFIG.ADMIN_OWNER_APP_USER;
  }

  return new Promise(function(resolve) {
    var tryHomeFallbackSave = function() {
      apex.server.process("SETTINGS_SAVE_HOME_ADMIN_USERS", { x01: value }, {
        dataType: "json",
        success: function(fallbackDataRaw) {
          var fallbackData = fallbackDataRaw && typeof fallbackDataRaw === "object" ? fallbackDataRaw : {};
          if (fallbackData.success === false) {
            resolve({ success: false, message: String(fallbackData.message || "Unable to save admin users.") });
            return;
          }
          resolve({ success: true, value: applySavedAdminValue(fallbackData.config_value || value) });
        },
        error: function(fallbackErr) {
          var fallbackMsg = "";
          try { fallbackMsg = String((fallbackErr && (fallbackErr.responseText || fallbackErr.statusText)) || ""); } catch (e1) {}
          if (isProcessMissingMessage(fallbackMsg)) {
            resolve({ success: false, message: "Admin save process is unavailable on this page. Deploy SETTINGS_SAVE_HOME_ADMIN_USERS callback on Home page or open Settings > Admin Controls." });
            return;
          }
          resolve({ success: false, message: fallbackMsg || "Unable to save admin users." });
        }
      });
    };

    apex.server.process("SETTINGS_SAVE_ADMIN_CONFIG", { x01: "ADMIN_OWNER_APP_USER", x02: value }, {
      dataType: "json",
      success: function(pData) {
        var data = pData && typeof pData === "object" ? pData : {};
        if (data.success === false) {
          var msg = String(data.message || "Unable to save admin users.");
          if (isProcessMissingMessage(msg)) {
            tryHomeFallbackSave();
            return;
          }
          resolve({ success: false, message: msg });
          return;
        }
        resolve({ success: true, value: applySavedAdminValue(data.config_value || value) });
      },
      error: function(jqXHR) {
        var message = "";
        try { message = String((jqXHR && (jqXHR.responseText || jqXHR.statusText)) || ""); } catch (e2) {}
        if (isProcessMissingMessage(message)) {
          tryHomeFallbackSave();
          return;
        }
        resolve({ success: false, message: message || "Unable to save admin users." });
      }
    });
  });
}

function saveAskOracleCurrentUserAsAdminOwner() {
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) {
    return saveAskOracleAdminOwnerUsers(getAskOracleRuntimeAppUser());
  }

  function applySavedAdminValue(savedValue) {
    var fallbackValue = getAskOracleRuntimeAppUser();
    window.ASK_ORACLE_ADMIN_CONFIG = window.ASK_ORACLE_ADMIN_CONFIG || {};
    window.ASK_ORACLE_ADMIN_CONFIG.ADMIN_OWNER_APP_USER = String(savedValue || fallbackValue || "").toUpperCase();
    persistAskOracleUiSyncState({
      admin_config: Object.assign({}, window.ASK_ORACLE_ADMIN_CONFIG)
    });
    return window.ASK_ORACLE_ADMIN_CONFIG.ADMIN_OWNER_APP_USER;
  }

  return new Promise(function(resolve) {
    apex.server.process("SETTINGS_SKIP_HOME_ADMIN_USER", {}, {
      dataType: "json",
      success: function(pData) {
        var data = pData && typeof pData === "object" ? pData : {};
        if (data.success === false) {
          var msg = String(data.message || "Unable to save current user as admin.");
          if (isAskOracleAdminProcessMissingMessage(msg)) {
            saveAskOracleAdminOwnerUsers(getAskOracleRuntimeAppUser()).then(resolve);
            return;
          }
          resolve({ success: false, message: msg });
          return;
        }
        resolve({ success: true, value: applySavedAdminValue(data.config_value) });
      },
      error: function(jqXHR) {
        var message = "";
        try { message = String((jqXHR && (jqXHR.responseText || jqXHR.statusText)) || ""); } catch (e) {}
        if (isAskOracleAdminProcessMissingMessage(message)) {
          saveAskOracleAdminOwnerUsers(getAskOracleRuntimeAppUser()).then(resolve);
          return;
        }
        resolve({ success: false, message: message || "Unable to save current user as admin." });
      }
    });
  });
}

function showAskOracleAdminSetupModal() {
  if (askOracleAdminSetupModalOpen) return;
  if (askOracleAdminSetupCompleted) return;
  if (readAskOracleAdminSetupDismissedFlag()) return;

  resolveAskOracleAdminOwnerSetupRequired().then(function(shouldShow) {
    if (!shouldShow) {
      askOracleAdminSetupCompleted = true;
      return;
    }
    if (askOracleAdminSetupModalOpen || askOracleAdminSetupCompleted) return;
    if (readAskOracleAdminSetupDismissedFlag()) return;

    ensureAppModalCss();
    askOracleAdminSetupModalOpen = true;
    var currentAppUser = getAskOracleRuntimeAppUser();

    var overlay = document.createElement("div");
    overlay.className = "ask-oracle-modal-overlay";
    overlay.innerHTML = `
    <div class="ask-oracle-modal ask-oracle-modal--admin" role="dialog" aria-modal="true" aria-labelledby="ask-oracle-admin-setup-title">
      <div class="ask-oracle-modal-header ask-oracle-modal-header-row">
        <div id="ask-oracle-admin-setup-title">Set Admin Users</div>
        <button type="button" class="ask-oracle-modal-close" data-admin-setup-action="close" aria-label="Close admin setup">&times;</button>
      </div>
      <div class="ask-oracle-modal-body">
        <p class="ask-oracle-modal-copy">Admin users are required to manage application settings, AI profiles, agent teams, and governance controls.</p>
        <div class="ask-oracle-admin-info-grid">
          <div class="ask-oracle-admin-info-card">
            <div class="ask-oracle-admin-info-title">Who can be admin?</div>
            <p class="ask-oracle-admin-info-text">Enter usernames exactly as users sign in to this APEX app.</p>
          </div>
          <div class="ask-oracle-admin-info-card">
            <div class="ask-oracle-admin-info-title">Authentication note</div>
            <p class="ask-oracle-admin-info-text">For APEX, SSO, IAM, or custom auth, use the authenticated username value.</p>
          </div>
        </div>
        ${currentAppUser ? `<div class="ask-oracle-admin-current-user">Current signed-in user: <strong>${escapeHtml(currentAppUser)}</strong></div>` : ""}
        <label for="ask-oracle-admin-setup-input" class="ask-oracle-admin-label">Admin usernames (comma-separated)</label>
        <textarea id="ask-oracle-admin-setup-input" class="ask-oracle-modal-input" placeholder="APPSTOREUSER1, APPSTOREUSER2"></textarea>
        <div class="ask-oracle-admin-example">Examples: APPSTOREUSER1, JANE.DOE, FINANCE_ADMIN</div>
        <div class="ask-oracle-modal-help">You can update this later in Settings > Admin Controls.</div>
        <div class="ask-oracle-modal-help"><strong>Skip:</strong> saves the current signed-in user as an Admin. You can change admin access later in Settings > Access Control.</div>
        <div id="ask-oracle-admin-setup-error" class="ask-oracle-modal-inline-error"></div>
      </div>
      <div class="ask-oracle-modal-actions">
        <button type="button" class="ask-oracle-modal-btn skip" id="ask-oracle-admin-setup-skip" data-admin-setup-action="skip">Skip</button>
        <button type="button" class="ask-oracle-modal-btn confirm" id="ask-oracle-admin-setup-save" data-admin-setup-action="save" disabled>Save Admin Users</button>
      </div>
    </div>
  `;
    document.body.appendChild(overlay);

    var input = overlay.querySelector("#ask-oracle-admin-setup-input");
    var errorEl = overlay.querySelector("#ask-oracle-admin-setup-error");
    var saveBtn = overlay.querySelector("#ask-oracle-admin-setup-save");
    var skipBtn = overlay.querySelector("#ask-oracle-admin-setup-skip");
    var adminSetupActionInFlight = false;

    var hasAdminSetupValue = function() {
      return !!normalizeAskOracleAdminOwnersCsv(input && input.value);
    };
    var syncAdminSetupSaveButton = function() {
      if (!saveBtn) return;
      saveBtn.disabled = adminSetupActionInFlight || !hasAdminSetupValue();
    };

    var clearModal = function() {
      askOracleAdminSetupModalOpen = false;
      try { overlay.remove(); } catch (e) {}
      try {
        var staleOverlays = document.querySelectorAll(".ask-oracle-modal-overlay");
        staleOverlays.forEach(function(node) {
          if (node && node.querySelector && node.querySelector("#ask-oracle-admin-setup-save")) {
            try { node.remove(); } catch (e2) {}
          }
        });
      } catch (e3) {}
    };

    var dismissModal = function() {
      markAskOracleAdminSetupDismissed();
      clearModal();
    };

    var setAdminSetupBusy = function(isBusy, busyText) {
      if (saveBtn) {
        saveBtn.disabled = !!isBusy || !hasAdminSetupValue();
        saveBtn.textContent = isBusy ? (busyText || "Saving...") : "Save Admin Users";
      }
      if (skipBtn) {
        skipBtn.disabled = !!isBusy;
        skipBtn.textContent = isBusy ? "Saving..." : "Skip";
      }
    };

    if (input) {
      input.addEventListener("input", function() {
        if (errorEl) errorEl.textContent = "";
        syncAdminSetupSaveButton();
      });
    }
    syncAdminSetupSaveButton();

    var completeAdminSetupSave = function(result, buttonLabel) {
      if (!result || !result.success) {
        adminSetupActionInFlight = false;
        if (errorEl) {
          errorEl.textContent = (result && result.message) ? result.message : "Unable to save admin users.";
        }
        setAdminSetupBusy(false);
        if (saveBtn) saveBtn.textContent = buttonLabel || "Save Admin Users";
        return;
      }
      clearAskOracleAdminSetupDismissed();
      askOracleAdminSetupCompleted = true;
      clearModal();
      scheduleAskOracleAdminUiStateApply(true);
      refreshAskOracleProfileControlsAfterAdminSetup();
      showAppToast("Admin users saved.", "success", 2200);
    };

    var runAdminSetupSave = function(value, buttonLabel) {
      var normalized = normalizeAskOracleAdminOwnersCsv(value);
      if (!normalized) {
        if (errorEl) errorEl.textContent = "Unable to detect the current signed-in user. Please enter an admin user.";
        return;
      }
      if (adminSetupActionInFlight) return;
      adminSetupActionInFlight = true;

      setAdminSetupBusy(true, "Saving...");
      if (errorEl) errorEl.textContent = "";

      saveAskOracleAdminOwnerUsers(normalized).then(function(result) {
        completeAdminSetupSave(result, buttonLabel || "Save Admin Users");
      });
    };

    var saveCurrentUserAndCloseAdminSetup = function() {
      if (adminSetupActionInFlight) return;
      adminSetupActionInFlight = true;
      setAdminSetupBusy(true, "Saving...");
      if (errorEl) errorEl.textContent = "";
      saveAskOracleCurrentUserAsAdminOwner().then(function(result) {
        completeAdminSetupSave(result, "Save Admin Users");
      });
    };

    var handleAdminSetupAction = function(event) {
      var target = event && event.target && typeof event.target.closest === "function"
        ? event.target.closest("[data-admin-setup-action]")
        : null;
      if (!target || !overlay.contains(target)) return;

      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();

      var action = String(target.getAttribute("data-admin-setup-action") || "").toLowerCase();
      if (action === "close") {
        if (adminSetupActionInFlight) return;
        adminSetupActionInFlight = true;
        askOracleAdminSetupCompleted = true;
        clearModal();
        saveAskOracleCurrentUserAsAdminOwner().then(function(result) {
          if (result && result.success) {
            clearAskOracleAdminSetupDismissed();
            scheduleAskOracleAdminUiStateApply(true);
            refreshAskOracleProfileControlsAfterAdminSetup();
            showAppToast("Current user saved as an admin.", "success", 2200);
            return;
          }
          askOracleAdminSetupCompleted = false;
          showAppToast((result && result.message) || "Unable to save the current user as an admin.", "error", 3500);
        }).catch(function() {
          askOracleAdminSetupCompleted = false;
          showAppToast("Unable to save the current user as an admin.", "error", 3500);
        });
        return;
      }
      if (action === "skip") {
        saveCurrentUserAndCloseAdminSetup();
        return;
      }
      if (action === "save") {
        var typedValue = input ? input.value : "";
        runAdminSetupSave(typedValue || currentAppUser || getAskOracleRuntimeAppUser(), "Save Admin Users");
      }
    };

    if (input) {
      input.value = getAskOracleAdminOwnerConfigValue();
      try { input.focus({ preventScroll: true }); } catch (e) {}
    }

    overlay.addEventListener("pointerup", handleAdminSetupAction, true);
    overlay.addEventListener("touchend", handleAdminSetupAction, true);
    overlay.addEventListener("click", handleAdminSetupAction, true);
    overlay.addEventListener("click", function(event) {
      if (event.target === overlay) {
        event.preventDefault();
        event.stopPropagation();
      }
    });
    document.addEventListener("keydown", function escClose(evt) {
      if (!askOracleAdminSetupModalOpen) {
        document.removeEventListener("keydown", escClose, true);
        return;
      }
      if (evt && evt.key === "Escape") {
        evt.preventDefault();
        saveCurrentUserAndCloseAdminSetup();
        document.removeEventListener("keydown", escClose, true);
      }
    }, true);

  });
}

// ================== COPY FUNCTION ==================
function copyResponse(id) {
  const text = document.getElementById(`response-${id}`)?.textContent?.trim();
  if (!text) return;
  navigator.clipboard.writeText(text).then(() => {
    showAppToast("Copied to clipboard.", "success", 1800);
  }).catch(err => {
    console.error("Copy failed:", err);
    showAppToast("Copy failed.", "error", 2200);
  });
}

function copyResponseToClipboard(id) {
  copyResponse(id);
}

function normalizeShareSqlText(rawSql) {
  var sql = String(rawSql || "").trim();
  if (!sql) return "";
  sql = sql.replace(/```sql/gi, "").replace(/```/g, "").trim();
  sql = sql.replace(/;\s*$/, "").trim();
  return sql;
}

function normalizeAskOracleProfileToken(value) {
  return String(value || "").trim().toUpperCase().replace(/[^A-Z0-9]+/g, "");
}

function isNl2SqlDataRetrievalAgentProfileName(value) {
  var normalized = normalizeAskOracleProfileToken(value);
  return normalized.indexOf("NL2SQLDATARETRIEVALAGENT") >= 0 ||
    normalized.indexOf("NL2SQLDATARETRIEVALTEAM") >= 0 ||
    normalized.indexOf("NL2SQLDATARETRIEVAL") >= 0;
}

function resolveShareProfileName(responseId) {
  var rawProfile = getNl2SqlProfileNameForResponse(responseId);
  if (!rawProfile) return "";
  if (isNl2SqlDataRetrievalAgentProfileName(rawProfile)) {
    return "GENERIC_AI_PROFILE";
  }
  return rawProfile;
}

function isNl2SqlShareEligibleForResponse(responseId, responseEl) {
  var id = String(responseId || "").trim();
  if (!id) return false;
  var el = responseEl || document.getElementById("response-" + id);
  var profileName = String((el && el.getAttribute("data-profile-name")) || "").trim();
  var isSqlTypeRow = String((el && el.getAttribute("data-type")) || "").trim().toLowerCase() === "sql";
  var isAgentNl2SqlDataRetrieval = isNl2SqlDataRetrievalAgentProfileName(profileName);
  if (isAgentNl2SqlDataRetrieval) return true;
  return !!(isSqlTypeRow && (
    isAskAdbChatWithDbConversationStyle() ||
    isNl2SqlConversationStyleActive() ||
    looksLikeNl2SqlProfileName(profileName)
  ));
}

function extractBestTableHyperlinkFromText(rawText) {
  var text = String(rawText || "");
  if (!text) return "";
  var matches = text.match(/https?:\/\/[^\s<>"')\]]+/gi) || [];
  if (!matches.length) return "";

  var cleaned = matches.map(function(url) {
    return String(url || "").trim().replace(/[),.;]+$/g, "");
  }).filter(Boolean);
  if (!cleaned.length) return "";

  var preferred = cleaned.find(function(url) {
    return /(format=csv|view=table|table_hyperlink|preauth|dbms_data_access|dataaccess)/i.test(url);
  });
  return preferred || cleaned[0];
}

function getExistingAgentTableHyperlinkForResponse(responseId) {
  var id = String(responseId || "").trim();
  if (!id) return "";

  var responseEl = document.getElementById("response-" + id);
  var textFromResponse = String(responseEl && (responseEl.innerText || responseEl.textContent) || "");
  var fromResponse = extractBestTableHyperlinkFromText(textFromResponse);
  if (fromResponse) return fromResponse;

  var payload = buildResponseDownloadPayload(id);
  var fromPayload = extractBestTableHyperlinkFromText(payload && payload.content ? payload.content : "");
  if (fromPayload) return fromPayload;

  return "";
}

function getNl2SqlProfileNameForResponse(responseId) {
  var responseEl = document.getElementById("response-" + String(responseId || "").trim());
  var profileFromData = String((responseEl && responseEl.getAttribute("data-profile-name")) || "").trim();
  var profileLabel = responseEl && responseEl.parentElement
    ? responseEl.parentElement.querySelector(".profile-label")
    : null;
  var profileFromLabel = String((profileLabel && profileLabel.textContent) || "").trim();
  var profileName = profileFromData || profileFromLabel || "";
  if (profileName.indexOf("|") > -1) {
    profileName = String(profileName.split("|").pop() || "").trim();
  }
  return profileName;
}

function getNl2SqlSqlTextForShare(responseId) {
  function extractSqlFromResponseText(rawText) {
    var text = String(rawText || "");
    if (!text) return "";
    var fenced = text.match(/```sql\s*([\s\S]*?)\s*```/i);
    if (fenced && fenced[1]) return normalizeShareSqlText(fenced[1]);
    var selectStmt = text.match(/((?:select|with)\s[\s\S]*?)(?:;|\n\n|$)/i);
    if (selectStmt && selectStmt[1]) return normalizeShareSqlText(selectStmt[1]);
    return "";
  }

  var id = String(responseId || "").trim();
  if (!id) return "";

  var sqlCodeEl = document.querySelector("#sql-block-" + id + " code");
  var sqlFromBlock = normalizeShareSqlText(sqlCodeEl ? (sqlCodeEl.textContent || "") : "");
  if (sqlFromBlock && !/^-- SQL will be injected here --/i.test(sqlFromBlock)) return sqlFromBlock;

  var payload = buildResponseDownloadPayload(id);
  var sqlFromPayload = normalizeShareSqlText(payload && payload.content ? payload.content : "");
  if (sqlFromPayload) return sqlFromPayload;

  var responseEl = document.getElementById("response-" + id);
  var sqlFromResponseText = extractSqlFromResponseText(responseEl ? (responseEl.innerText || responseEl.textContent || "") : "");
  return sqlFromResponseText;
}

function getShareConversationKeysForResponse(responseId) {
  var id = String(responseId || "").trim();
  var responseEl = document.getElementById("response-" + id);
  return {
    conversationId: String((responseEl && responseEl.getAttribute("data-conversation-id")) || "").trim(),
    conversationPromptId: String((responseEl && responseEl.getAttribute("data-conversation-prompt-id")) || "").trim()
  };
}

function normalizeShareUrlForDraft(rawUrl) {
  var url = String(rawUrl || "").trim();
  if (!url) return "";
  if (!/^https?:\/\//i.test(url)) {
    url = "https://" + url.replace(/^\/+/, "");
  }
  return url;
}

function openShareLinkEmailDraft(rawUrl) {
  var normalizedUrl = normalizeShareUrlForDraft(rawUrl);
  if (!normalizedUrl) return false;
  var mailSubject = encodeURIComponent("Shared Data Link");
  var mailBody = encodeURIComponent(
    "Hi,\n\nPlease find the shared link below for the data.\n\nLink: " + normalizedUrl + "\n"
  );
  var mailtoUrl = "mailto:?subject=" + mailSubject + "&body=" + mailBody;
  try {
    var anchor = document.createElement("a");
    anchor.href = mailtoUrl;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    anchor.style.display = "none";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
  } catch (e) {
    window.open(mailtoUrl, "_blank", "noopener,noreferrer");
  }
  return true;
}

var askOracleShareActionMenuEl = null;
var askOracleShareActionMenuCloseHandler = null;

function closeAskOracleShareActionMenu() {
  if (askOracleShareActionMenuCloseHandler) {
    try { document.removeEventListener("mousedown", askOracleShareActionMenuCloseHandler, true); } catch (e) {}
    askOracleShareActionMenuCloseHandler = null;
  }
  if (askOracleShareActionMenuEl && askOracleShareActionMenuEl.parentNode) {
    try { askOracleShareActionMenuEl.parentNode.removeChild(askOracleShareActionMenuEl); } catch (e) {}
  }
  askOracleShareActionMenuEl = null;
}

function openShareLinkActionMenu(responseId, triggerEl) {
  closeAskOracleShareActionMenu();
  if (!triggerEl) {
    shareNl2SqlResponse(responseId, triggerEl, "copy");
    return;
  }

  var rect = triggerEl.getBoundingClientRect();
  var menu = document.createElement("div");
  menu.className = "ask-oracle-share-action-menu";
  menu.style.position = "absolute";
  menu.style.zIndex = "2147483000";
  menu.style.minWidth = "160px";
  menu.style.background = "#fff";
  menu.style.border = "1px solid #d7deea";
  menu.style.borderRadius = "10px";
  menu.style.boxShadow = "0 10px 30px rgba(15,23,42,0.18)";
  menu.style.padding = "6px";

  var createItem = function(label, action) {
    var btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = label;
    btn.style.display = "block";
    btn.style.width = "100%";
    btn.style.textAlign = "left";
    btn.style.border = "0";
    btn.style.background = "transparent";
    btn.style.padding = "8px 10px";
    btn.style.borderRadius = "8px";
    btn.style.cursor = "pointer";
    btn.style.fontSize = "12px";
    btn.style.color = "#1f2937";
    btn.addEventListener("mouseenter", function() { btn.style.background = "#f3f6fb"; });
    btn.addEventListener("mouseleave", function() { btn.style.background = "transparent"; });
    btn.addEventListener("click", function(e) {
      e.preventDefault();
      e.stopPropagation();
      closeAskOracleShareActionMenu();
      shareNl2SqlResponse(responseId, triggerEl, action);
    });
    return btn;
  };

  menu.appendChild(createItem("Copy Link", "copy"));
  menu.appendChild(createItem("Open Link", "open"));
  menu.appendChild(createItem("Email Link", "email"));

  document.body.appendChild(menu);
  var scrollX = window.scrollX || window.pageXOffset || 0;
  var scrollY = window.scrollY || window.pageYOffset || 0;
  var top = rect.bottom + scrollY + 6;
  var left = rect.left + scrollX;
  var viewportRight = scrollX + (window.innerWidth || document.documentElement.clientWidth || 0);
  if (left + menu.offsetWidth > viewportRight - 8) {
    left = Math.max(scrollX + 8, viewportRight - menu.offsetWidth - 8);
  }
  menu.style.top = top + "px";
  menu.style.left = left + "px";

  askOracleShareActionMenuEl = menu;
  askOracleShareActionMenuCloseHandler = function(ev) {
    if (!askOracleShareActionMenuEl) return;
    if (askOracleShareActionMenuEl.contains(ev.target)) return;
    if (triggerEl && triggerEl.contains && triggerEl.contains(ev.target)) return;
    closeAskOracleShareActionMenu();
  };
  window.setTimeout(function() {
    try { document.addEventListener("mousedown", askOracleShareActionMenuCloseHandler, true); } catch (e) {}
  }, 0);
}

function shareNl2SqlResponse(responseId, triggerEl, actionType) {
  var shareTrace = function(step, payload) {
    try {
      if (window.console && typeof window.console.log === "function") {
        window.console.log("[ShareLink][NL2SQL]", step, payload || {});
      }
    } catch (e) {}
  };
  var id = String(responseId || "").trim();
  var rawProfileName = getNl2SqlProfileNameForResponse(id);
  var currentConversationMode = String(
    normalizeAskOracleConversationMode(
      typeof getAskOracleCurrentConversationMode === "function" ? getAskOracleCurrentConversationMode() : ""
    ) || ""
  ).trim().toUpperCase();
  var isAgentConversationMode = currentConversationMode === "USER_AGENTS" || currentConversationMode === "AGENT";
  var isAgentDirectCopy = isNl2SqlDataRetrievalAgentProfileName(rawProfileName) || isAgentConversationMode;
  var agentShareLookupProfile = "NL2SQL_DATA_RETRIEVAL_AGENT";
  var profileName = resolveShareProfileName(id);
  var sqlText = getNl2SqlSqlTextForShare(id);
  var rawShareAction = String(actionType || "copy").trim().toLowerCase();
  var shareAction = rawShareAction === "email" || rawShareAction === "open" ? rawShareAction : "copy";
  var shareKeys = getShareConversationKeysForResponse(id);
  var conversationId = String((shareKeys && shareKeys.conversationId) || "").trim();
  var conversationPromptId = String((shareKeys && shareKeys.conversationPromptId) || "").trim();
  shareTrace("click", {
    responseId: id,
    rawProfileName: rawProfileName,
    profileName: profileName,
    mode: currentConversationMode,
    isAgentDirectCopy: isAgentDirectCopy,
    conversationId: conversationId,
    conversationPromptId: conversationPromptId,
    hasSqlText: !!sqlText,
    action: shareAction
  });
  if (!id) {
    showAppToast("Unable to generate share link.", "error", 2200);
    return;
  }

  if (isAgentDirectCopy) {
    var handleResolvedUrl = function(url) {
      if (!url) return;
      if (shareAction === "open") {
        window.open(url, "_blank", "noopener,noreferrer");
        showAppToast("Opened shared link.", "success", 2200);
        return;
      }
      if (shareAction === "email") {
        if (openShareLinkEmailDraft(url)) {
          showAppToast("Email draft opened.", "success", 2200);
        } else {
          showAppToast("Unable to prepare email draft.", "error", 2200);
        }
        return;
      }
      if (triggerEl) triggerEl.disabled = true;
      navigator.clipboard.writeText(url).then(function() {
        if (triggerEl) triggerEl.disabled = false;
        showAppToast("Share link copied.", "success", 2200);
      }).catch(function() {
        if (triggerEl) triggerEl.disabled = false;
        showAppToast("Share link copied. Copy from prompt.", "success", 2600);
        window.prompt("Copy share link:", url);
      });
    };

    if (!profileName && !conversationId && !conversationPromptId) {
      showAppToast("No table hyperlink found in this agent response.", "error", 2800);
      return;
    }

    if (triggerEl) triggerEl.disabled = true;
    shareTrace("lookup_only_request", {
      x01: id,
      x02: agentShareLookupProfile,
      x03: "LOOKUP_ONLY",
      x04: conversationId,
      x05: conversationPromptId || id,
      sqlPreview: String(sqlText || "").substring(0, 250)
    });
    apex.server.process("CREATE_NL2SQL_SHARE_URL", {
      x01: id,
      x02: agentShareLookupProfile,
      x03: "LOOKUP_ONLY",
      x04: conversationId,
      x05: conversationPromptId || id,
      p_clob_01: sqlText
    }, {
      dataType: "json",
      success: function(data) {
        if (triggerEl) triggerEl.disabled = false;
        shareTrace("lookup_only_success", data);
        var url = String((data && data.url) || "").trim();
        if (!url) {
          showAppToast("No table hyperlink found in this agent response.", "error", 2800);
          return;
        }
        handleResolvedUrl(url);
      },
      error: function(xhr, status, errorThrown) {
        if (triggerEl) triggerEl.disabled = false;
        shareTrace("lookup_only_error", {
          status: status,
          errorThrown: errorThrown,
          responseText: String((xhr && xhr.responseText) || "").substring(0, 800)
        });
        showAppToast("No table hyperlink found in this agent response.", "error", 2800);
      }
    });
    return;
  }

  if (!profileName) {
    showAppToast("Profile name not found for this response.", "error", 2400);
    return;
  }
  if (!sqlText) {
    showAppToast("SQL text not found for this response.", "error", 2400);
    return;
  }
  if (triggerEl) triggerEl.disabled = true;
  shareTrace("create_request", {
    x01: id,
    x02: profileName,
    x04: conversationId,
    x05: conversationPromptId || id,
    sqlPreview: String(sqlText || "").substring(0, 250)
  });
  apex.server.process("CREATE_NL2SQL_SHARE_URL", {
    x01: id,
    x02: profileName,
    x04: conversationId,
    x05: conversationPromptId || id,
    p_clob_01: sqlText
  }, {
    dataType: "json",
    success: function(data) {
      if (triggerEl) triggerEl.disabled = false;
      shareTrace("create_success", data);
      if (!data || data.success === false || !String(data.url || "").trim()) {
        var message = String((data && data.message) || "Unable to create share URL.");
        showAppToast(message, "error", 3000);
        return;
      }
      var url = String(data.url || "").trim();
      if (window.console && window.console.log) {
        window.console.log("[NL2SQL Share URL]", { responseId: id, profileName: profileName, url: url, sql: data.sql_statement || "" });
      }
      if (shareAction === "open") {
        window.open(url, "_blank", "noopener,noreferrer");
        showAppToast("Opened shared link.", "success", 2200);
      } else if (shareAction === "email") {
        if (openShareLinkEmailDraft(url)) {
          showAppToast("Email draft opened.", "success", 2200);
        } else {
          showAppToast("Unable to prepare email draft.", "error", 2200);
        }
      } else {
        navigator.clipboard.writeText(url).then(function() {
          showAppToast("Share link copied.", "success", 2200);
        }).catch(function() {
          showAppToast("Share link created. Copy from prompt.", "success", 2600);
          window.prompt("Copy share link:", url);
        });
      }
    },
    error: function(xhr) {
      if (triggerEl) triggerEl.disabled = false;
      shareTrace("create_error", {
        responseText: String((xhr && xhr.responseText) || "").substring(0, 800)
      });
      var msg = String((xhr && xhr.responseText) || "Unable to create share URL.");
      showAppToast(msg, "error", 3200);
    }
  });
}

function copyPromptToClipboard(id) {
  const key = String(id || "").trim();
  if (!key) return;

  const promptNode =
    document.querySelector(`#prompt-${key} .message-bubble`) ||
    document.querySelector(`#prompt-${key} span`) ||
    document.getElementById(`prompt-${key}`);
  const text = promptNode ? String(promptNode.textContent || promptNode.innerText || "").trim() : "";
  if (!text) {
    showAppToast("Prompt text not found.", "error", 1800);
    return;
  }

  navigator.clipboard.writeText(text).then(() => {
    const feedback = document.getElementById(`copy-feedback-${key}`);
    if (feedback) {
      feedback.style.display = "inline";
      setTimeout(() => { feedback.style.display = "none"; }, 1500);
    } else {
      showAppToast("Prompt copied to clipboard.", "success", 1800);
    }
  }).catch((err) => {
    console.error("Prompt copy failed:", err);
    showAppToast("Copy failed.", "error", 2200);
  });
}

function getResponseFileExtensionFromLanguage(language) {
  const lang = (language || "").toLowerCase();
  const extMap = {
    sql: "sql",
    plsql: "sql",
    javascript: "js",
    js: "js",
    python: "py",
    java: "java",
    r: "r",
    markup: "html",
    html: "html",
    xml: "xml",
    json: "json",
    bash: "sh",
    shell: "sh"
  };
  return extMap[lang] || "txt";
}

var responseDownloadPayloadCache = Object.create(null);
var ASK_ORACLE_RESPONSE_PAYLOAD_CACHE_ENABLED = false;
var responseDisplayNameById = Object.create(null);
var responseDisplayCounter = 0;
var askOraclePdfExportLoadPromise = null;
var askOraclePdfExportInFlightById = Object.create(null);
var askOracleConversationPdfExportInFlightById = Object.create(null);

function cacheResponseDownloadPayload(id, payload) {
  if (!ASK_ORACLE_RESPONSE_PAYLOAD_CACHE_ENABLED) return;
  const key = String(id || "").trim();
  if (!key || !payload || !payload.content) return;
  const ext = String(payload.ext || "txt").toLowerCase() || "txt";
  const hasCode =
    payload.hasCode === true ||
    ext !== "txt";
  responseDownloadPayloadCache[key] = {
    content: String(payload.content),
    ext: ext,
    hasCode: hasCode
  };
}

function getCachedResponseDownloadPayload(id) {
  if (!ASK_ORACLE_RESPONSE_PAYLOAD_CACHE_ENABLED) return null;
  const key = String(id || "").trim();
  if (!key) return null;
  const payload = responseDownloadPayloadCache[key];
  if (!payload || !payload.content) return null;
  return {
    content: String(payload.content),
    ext: String(payload.ext || "txt"),
    hasCode: payload.hasCode === true || String(payload.ext || "txt").toLowerCase() !== "txt"
  };
}

function hasPayloadCodeContent(payload) {
  if (!payload || !payload.content) return false;
  if (payload.hasCode === true) return true;
  const ext = String(payload.ext || "txt").toLowerCase();
  return ext !== "txt";
}

function getResponseDisplayIndex(id) {
  const key = String(id || "").trim();
  if (!key) return 0;
  if (!responseDisplayNameById[key]) {
    responseDisplayCounter += 1;
    responseDisplayNameById[key] = responseDisplayCounter;
  }
  return responseDisplayNameById[key];
}

function getResponseDisplayBaseName(id) {
  const idx = getResponseDisplayIndex(id);
  return idx > 0 ? `response-${idx}` : "response";
}

function ensureResponseCodeFenceClosure(rawText) {
  const raw = String(rawText || "");
  if (!raw.trim()) return raw;

  const lines = raw.split(/\r?\n/);
  let openFence = false;
  lines.forEach((line) => {
    if (/^\s*```/.test(line)) {
      openFence = !openFence;
    }
  });

  if (!openFence) return raw;

  const trailingQuoteMatch = raw.match(/(\r?\n\s*["']\s*)$/);
  if (trailingQuoteMatch) {
    const suffix = trailingQuoteMatch[1];
    const prefix = raw.slice(0, raw.length - suffix.length).replace(/\s+$/, "");
    return `${prefix}\n\`\`\`${suffix}`;
  }

  const trimmed = raw.replace(/\s+$/, "");
  return `${trimmed}\n\`\`\``;
}

function looksLikeExecutableCodeBlock(text) {
  const t = String(text || "").trim();
  if (!t) return false;
  return (
    /\bcreate\s+(or\s+replace\s+)?(package(\s+body)?|procedure|function|trigger|type(\s+body)?|view|table)\b/i.test(t) ||
    /\b(begin|declare|select|with|insert|update|delete|merge)\b/i.test(t) ||
    /\b(function|class|const|let|var|def|import|from)\b/i.test(t)
  );
}

function isAgentReasoningTraceNonCode(rawText, blocks, firstLang) {
  const raw = String(rawText || "");
  if (!raw.trim()) return false;
  const hasThought = /^\s*Thought\s*:/im.test(raw);
  const hasAction = /^\s*Action\s*:/im.test(raw);
  const hasActionInput = /^\s*Action\s*Input\s*:/im.test(raw);
  const hasHumanTool = /ORA\$HUMAN_TOOL/i.test(raw);
  if (!hasThought || !hasAction || !(hasActionInput || hasHumanTool)) return false;

  const lang = String(firstLang || "").toLowerCase();
  if (lang && lang !== "json") return false;

  const parts = Array.isArray(blocks) ? blocks : [];
  if (!parts.length) return true;
  return !parts.some((part) => looksLikeExecutableCodeBlock(part));
}

function inferCodeFileExtension(rawText, codeText, languageHint) {
  const lang = String(languageHint || "").trim().toLowerCase();
  const extFromLang = getResponseFileExtensionFromLanguage(lang);
  if (lang && extFromLang && extFromLang !== "txt") return extFromLang;

  const raw = String(rawText || "");
  const code = String(codeText || "");
  const combined = `${raw}\n${code}`;

  // Prefer explicit file-name hints in the narrative around the code block.
  if (/\.(?:sql|pks|pkb|pls|plsql)\b/i.test(combined)) return "sql";

  // Detect common SQL/PLSQL constructs when fence language is missing.
  if (
    /\bcreate\s+(or\s+replace\s+)?(package(\s+body)?|procedure|function|trigger|type(\s+body)?|view|table)\b/i.test(code) ||
    /\bbegin\b[\s\S]*\bend\s*;?/i.test(code) ||
    /\bdeclare\b[\s\S]*\bbegin\b/i.test(code) ||
    /\bselect\b[\s\S]*\bfrom\b/i.test(code) ||
    /\bmerge\s+into\b|\binsert\s+into\b|\bupdate\b|\bdelete\s+from\b/i.test(code)
  ) {
    return "sql";
  }

  return "txt";
}

function buildPayloadFromRawResponseText(rawText) {
  const raw = ensureResponseCodeFenceClosure(rawText);
  if (!raw.trim()) return null;

  const codeBlockRegex = /```([^\n\r`]*)\s*\r?\n([\s\S]*?)```/g;
  let firstLang = "";
  const blocks = [];
  let match;
  while ((match = codeBlockRegex.exec(raw)) !== null) {
    const lang = String(match[1] || "").trim().toLowerCase();
    const blockText = String(match[2] || "").trim();
    if (!blockText) continue;
    if (!firstLang) firstLang = lang;
    blocks.push(blockText);
  }

  if (blocks.length) {
    if (isAgentReasoningTraceNonCode(raw, blocks, firstLang)) {
      return { content: raw.trim(), ext: "txt", hasCode: false };
    }
    const joined = blocks.join("\n\n");
    const inferredExt = inferCodeFileExtension(raw, joined, firstLang);
    return {
      content: joined,
      ext: inferredExt,
      hasCode: true
    };
  }

  return { content: raw.trim(), ext: "txt", hasCode: false };
}

function fetchResponseDownloadPayload(id, callback) {
  const done = typeof callback === "function" ? callback : function() {};
  const targetId = String(id || "").trim();
  if (!targetId) {
    done(null);
    return;
  }

  const cached = getCachedResponseDownloadPayload(targetId);
  if (cached) {
    done(cached);
    return;
  }

  const responseEl = document.getElementById(`response-${targetId}`);
  const responseType = String(responseEl?.getAttribute("data-type") || "").toLowerCase();
  const maxAttempts = 4;
  const retryDelayMs = 450;
  let attempts = 0;

  function finish(payload) {
    done(payload && payload.content ? payload : null);
  }

  function scheduleRetryOrFinish() {
    if (attempts < maxAttempts) {
      setTimeout(requestAttempt, retryDelayMs);
      return;
    }
    finish(null);
  }

  function requestAttempt() {
    attempts += 1;

    const cachedPayload = getCachedResponseDownloadPayload(targetId);
    if (cachedPayload) {
      finish(cachedPayload);
      return;
    }

    if (responseType === "sql") {
      apex.server.process("GET_SQL_RESULTS", { x01: targetId }, {
        dataType: "json",
        success: function(pData) {
          const sqlText = String((pData && pData.sql) || "").trim();
          if (!sqlText) {
            scheduleRetryOrFinish();
            return;
          }
          const payload = { content: sqlText, ext: "sql", hasCode: true };
          cacheResponseDownloadPayload(targetId, payload);
          finish(payload);
        },
        error: function() {
          scheduleRetryOrFinish();
        }
      });
      return;
    }

    apex.server.process("GET_RESPONSE", { x01: targetId }, {
      dataType: "json",
      success: function(pData) {
        const payload = buildPayloadFromRawResponseText((pData && pData.response) || "");
        if (payload && payload.content) {
          cacheResponseDownloadPayload(targetId, payload);
          finish(payload);
          return;
        }
        scheduleRetryOrFinish();
      },
      error: function() {
        scheduleRetryOrFinish();
      }
    });
  }

  requestAttempt();
}

function buildResponseDownloadPayload(id) {
  const cachedPayload = getCachedResponseDownloadPayload(id);
  if (cachedPayload) return cachedPayload;

  const sqlCodeEl = document.querySelector(`#sql-block-${id} code`);
  if (sqlCodeEl) {
    const sqlText = (sqlCodeEl.textContent || "").trim();
    if (sqlText && !/^-- SQL will be injected here --/i.test(sqlText)) {
      const payload = { content: sqlText, ext: "sql", hasCode: true };
      cacheResponseDownloadPayload(id, payload);
      return payload;
    }
  }

  const responseEl = document.getElementById(`response-${id}`);
  if (!responseEl) return null;

  const codeEls = responseEl.querySelectorAll("pre code");
  if (codeEls.length > 0) {
    const blocks = Array.from(codeEls)
      .map((node) => (node.textContent || "").trim())
      .filter(Boolean);
    if (blocks.length > 0) {
      const firstCode = codeEls[0];
      const langClass = Array.from(firstCode.classList || []).find((name) => name.indexOf("language-") === 0);
      const lang = langClass ? langClass.replace("language-", "") : "";
      const joined = blocks.join("\n\n");
      let ext = getResponseFileExtensionFromLanguage(lang);
      if (!ext || ext === "txt") {
        ext = inferCodeFileExtension(responseEl.innerText || responseEl.textContent || "", joined, lang);
      }
      const payload = { content: joined, ext: ext || "txt", hasCode: true };
      cacheResponseDownloadPayload(id, payload);
      return payload;
    }
  }

  const text = (responseEl.innerText || responseEl.textContent || "").trim();
  if (!text) return null;
  const payload = buildPayloadFromRawResponseText(text) || { content: text, ext: "txt", hasCode: false };
  cacheResponseDownloadPayload(id, payload);
  return payload;
}

function normalizeResponseContentId(id) {
  return String(id || "").trim().replace(/^response-/, "");
}

function responseHasCodeContent(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return false;

  const payload = buildResponseDownloadPayload(responseId);
  if (hasPayloadCodeContent(payload)) return true;

  const sqlCodeEl = document.querySelector(`#sql-block-${responseId} code`);
  if (sqlCodeEl) {
    const sqlText = String(sqlCodeEl.textContent || "").trim();
    if (sqlText && !/^-- SQL will be injected here --/i.test(sqlText)) return true;
  }

  return false;
}

function responseHasAgentTextContent(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return false;
  const responseEl = document.getElementById(`response-${responseId}`);
  if (!responseEl) return false;
  const text = String(responseEl.innerText || responseEl.textContent || "").trim();
  if (!text) return false;

  const profileAttr = String(responseEl.getAttribute("data-profile-name") || "").trim().toUpperCase();
  if (profileAttr.startsWith("AGENT")) return true;

  const profileLabel = responseEl.nextElementSibling && responseEl.nextElementSibling.querySelector
    ? String((responseEl.nextElementSibling.querySelector(".profile-label") || {}).textContent || "").trim().toUpperCase()
    : "";
  if (profileLabel.startsWith("AGENT")) return true;

  if (typeof isUserAgentsConversationStyleActive === "function" && isUserAgentsConversationStyleActive()) return true;
  return false;
}

function setOpenEditorButtonVisibility(button, visible) {
  if (!button) return;
  const shouldShow = !!visible;
  button.disabled = !shouldShow;
  if (shouldShow) {
    button.removeAttribute("aria-disabled");
    button.removeAttribute("hidden");
    button.style.removeProperty("display");
    button.style.removeProperty("pointer-events");
    button.style.removeProperty("opacity");
  } else {
    button.setAttribute("aria-disabled", "true");
    button.setAttribute("hidden", "hidden");
    button.style.setProperty("display", "none", "important");
    button.style.setProperty("pointer-events", "none", "important");
    button.style.setProperty("opacity", "0", "important");
  }
}

function syncResponseOpenEditorButtonsForResponse(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return;
  const hasOpenableContent = isAskOracleOpenEditorEnabled() && (responseHasCodeContent(responseId) || responseHasAgentTextContent(responseId));
  const selectors = [
    `.speech-controls[data-id="${responseId}"] .open-editor-btn`,
    `.chart-sql-buttons[data-response-id="${responseId}"] .open-editor-btn`,
    `.ask-oracle-response-table-actions[data-response-id="${responseId}"] .open-editor-btn`,
    `.ask-oracle-sql-footer-actions[data-response-id="${responseId}"] .open-editor-btn`
  ];
  document.querySelectorAll(selectors.join(",")).forEach((btn) => {
    if (btn.classList && btn.classList.contains("share-nl2sql-btn")) return;
    setOpenEditorButtonVisibility(btn, hasOpenableContent);
  });
}

function triggerFileDownload(content, fileName) {
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function downloadResponseToFile(id) {
  const payload = buildResponseDownloadPayload(id);
  if (!payload || !payload.content) return;

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const fileName = `${getResponseDisplayBaseName(id)}-${timestamp}.${payload.ext}`;
  triggerFileDownload(payload.content, fileName);
}

function responseHasTableOutput(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return false;
  const responseEl = document.getElementById(`response-${responseId}`);
  if (!responseEl) return false;
  return !!responseEl.querySelector("table, .code-editor-run-output-table, .code-editor-run-output-table-wrap table");
}

function responseAllowsPromptExportActions(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return false;

  const responseEl = document.getElementById(`response-${responseId}`);
  if (responseEl) {
    const conversationPromptId = String(responseEl.getAttribute("data-conversation-prompt-id") || "").trim();
    if (conversationPromptId) return true;
  }

  const footerActions = document.querySelector(`.ask-oracle-sql-footer-actions[data-response-id="${responseId}"]`);
  if (footerActions) {
    return String(footerActions.getAttribute("data-has-prompt-actions") || "").trim().toLowerCase() === "true";
  }

  return false;
}

function responseAllowsPdfExportActions(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return false;
  if (responseAllowsPromptExportActions(responseId)) return true;

  try {
    if (typeof isRagConversationStyleActive === "function" && isRagConversationStyleActive()) {
      return true;
    }
    if (typeof isUserAgentsConversationStyleActive === "function" && isUserAgentsConversationStyleActive()) {
      return true;
    }
  } catch (e) {}

  const responseEl = document.getElementById(`response-${responseId}`);
  const profileName = String((responseEl && responseEl.getAttribute("data-profile-name")) || "").trim().toUpperCase();
  return profileName.startsWith("AGENT");
}

function escapeResponseTableCellForCsv(value) {
  const text = String(value == null ? "" : value).replace(/\r?\n/g, " ").trim();
  if (/[",\n]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

function buildResponseTableCsv(tableEl) {
  if (!tableEl || !tableEl.querySelectorAll) return "";
  const rows = Array.from(tableEl.querySelectorAll("tr"));
  if (!rows.length) return "";

  return rows.map((row) => {
    const cells = Array.from(row.querySelectorAll("th, td"));
    return cells.map((cell) => escapeResponseTableCellForCsv(cell.textContent || "")).join(",");
  }).join("\n");
}

function downloadResponseTableAsExcel(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return;

  const responseEl = document.getElementById(`response-${responseId}`);
  const tableEl = responseEl ? responseEl.querySelector(".code-editor-run-output-table, table") : null;
  if (!tableEl) {
    showAppToast("Table output not found.", "error", 1800);
    return;
  }

  const csv = buildResponseTableCsv(tableEl);
  if (!csv.trim()) {
    showAppToast("Table output is empty.", "error", 1800);
    return;
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const fileName = `${getResponseDisplayBaseName(responseId)}-${timestamp}.xls`;
  const blob = new Blob(["\uFEFF", csv], { type: "application/vnd.ms-excel;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function setExportExcelButtonVisibility(button, visible) {
  if (!button) return;
  button.style.display = visible ? "" : "none";
  button.disabled = !visible;
}

function syncResponseExportExcelButtonsForResponse(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return;
  const hasTableContent = responseHasTableOutput(responseId);
  setResponseExportExcelButtonsVisibility(responseId, hasTableContent);
}

function setResponseExportExcelButtonsVisibility(id, visible) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return;
  const selectors = [
    `.speech-controls[data-id="${responseId}"] .export-excel-response-btn`,
    `.chart-sql-buttons[data-response-id="${responseId}"] .export-excel-response-btn`,
    `.ask-oracle-response-table-actions[data-response-id="${responseId}"] .export-excel-response-btn`
  ];
  document.querySelectorAll(selectors.join(",")).forEach((btn) => {
    setExportExcelButtonVisibility(btn, visible);
  });
}

function loadAskOracleScript(scriptId, src, readyCheck, errorMessage) {
  if (typeof readyCheck === "function" && readyCheck()) {
    return Promise.resolve(true);
  }

  return new Promise((resolve, reject) => {
    const existingScript = document.getElementById(scriptId);
    const handleLoad = function() {
      if (typeof readyCheck === "function" && readyCheck()) {
        resolve(true);
        return;
      }
      reject(new Error(errorMessage || `Loaded script but ${scriptId} is unavailable.`));
    };
    const handleError = function() {
      reject(new Error(errorMessage || `Failed to load ${scriptId}.`));
    };

    if (existingScript) {
      if (typeof readyCheck === "function" && readyCheck()) {
        resolve(true);
        return;
      }
      existingScript.addEventListener("load", handleLoad, { once: true });
      existingScript.addEventListener("error", handleError, { once: true });
      return;
    }

    const script = document.createElement("script");
    script.id = scriptId;
    script.src = src;
    script.async = true;
    script.onload = handleLoad;
    script.onerror = handleError;
    document.head.appendChild(script);
  });
}

function ensurePdfExportLibrariesLoaded() {
  if (window.html2canvas && window.jspdf && window.jspdf.jsPDF) {
    return Promise.resolve({
      html2canvas: window.html2canvas,
      jsPDF: window.jspdf.jsPDF
    });
  }

  if (askOraclePdfExportLoadPromise) return askOraclePdfExportLoadPromise;

  askOraclePdfExportLoadPromise = Promise.all([
    loadAskOracleScript(
      "ask-oracle-html2canvas-script",
      "https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js",
      function() { return typeof window.html2canvas === "function"; },
      "Failed to load the PDF export renderer."
    ),
    loadAskOracleScript(
      "ask-oracle-jspdf-script",
      "https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js",
      function() { return !!(window.jspdf && window.jspdf.jsPDF); },
      "Failed to load the PDF generator."
    )
  ]).then(function() {
    return {
      html2canvas: window.html2canvas,
      jsPDF: window.jspdf.jsPDF
    };
  }).catch(function(err) {
    askOraclePdfExportLoadPromise = null;
    throw err;
  });

  return askOraclePdfExportLoadPromise;
}

function waitForAskOracleAnimationFrames(count) {
  const total = Math.max(1, Number(count) || 1);
  return new Promise((resolve) => {
    let remaining = total;
    function nextFrame() {
      remaining -= 1;
      if (remaining <= 0) {
        resolve();
        return;
      }
      requestAnimationFrame(nextFrame);
    }
    requestAnimationFrame(nextFrame);
  });
}

function waitForAskOracleFontsReady(timeoutMs) {
  if (!document.fonts || !document.fonts.ready) return Promise.resolve();
  return Promise.race([
    Promise.resolve(document.fonts.ready).catch(function() {}),
    new Promise((resolve) => setTimeout(resolve, Math.max(400, Number(timeoutMs) || 1800)))
  ]);
}

function waitForImagesInNode(node, timeoutMs) {
  if (!node) return Promise.resolve();
  const images = Array.from(node.querySelectorAll("img"));
  if (images.length === 0) return Promise.resolve();

  const waits = images.map((img) => {
    if (!img) return Promise.resolve();
    if (img.complete && img.naturalWidth > 0) return Promise.resolve();
    return new Promise((resolve) => {
      let finished = false;
      function done() {
        if (finished) return;
        finished = true;
        resolve();
      }
      img.addEventListener("load", done, { once: true });
      img.addEventListener("error", done, { once: true });
      setTimeout(done, Math.max(500, Number(timeoutMs) || 2500));
    });
  });

  return Promise.all(waits).then(function() {});
}

function canvasHasRenderableContent(canvasEl) {
  if (!canvasEl || typeof canvasEl.toDataURL !== "function") return false;
  const width = Math.max(0, Number(canvasEl.width) || Math.round(canvasEl.getBoundingClientRect().width) || 0);
  const height = Math.max(0, Number(canvasEl.height) || Math.round(canvasEl.getBoundingClientRect().height) || 0);
  if (!width || !height) return false;

  try {
    const dataUrl = canvasEl.toDataURL("image/png");
    if (!dataUrl) return false;
    const blankCanvas = document.createElement("canvas");
    blankCanvas.width = width;
    blankCanvas.height = height;
    return dataUrl !== blankCanvas.toDataURL("image/png");
  } catch (e) {
    return width > 0 && height > 0;
  }
}

function hasConversationExportContent(el) {
  if (!el) return false;

  if (el.querySelector("svg, img, table, pre, code, .ask-oracle-visual-panel")) {
    return true;
  }
  if (Array.from(el.querySelectorAll("canvas")).some(canvasHasRenderableContent)) {
    return true;
  }

  const clone = el.cloneNode(true);
  clone.querySelectorAll(".copy-btn, .speech-controls, .chart-sql-buttons, .ask-oracle-response-table-actions, .loading-spinner").forEach((node) => {
    try { node.remove(); } catch (e) {}
  });
  const text = String(clone.innerText || clone.textContent || "").trim();
  return text.length > 0;
}

function sanitizeConversationExportClone(clone, options) {
  if (!clone) return clone;
  const opts = options || {};

  try { clone.removeAttribute("id"); } catch (e) {}
  try {
    clone.removeAttribute("hidden");
    clone.hidden = false;
  } catch (e) {}

  const removableSelectors = [
    ".copy-btn",
    ".speech-controls",
    ".chart-sql-buttons",
    ".ask-oracle-response-table-actions",
    ".open-editor-btn",
    ".conversation-time-btn",
    ".view-agent-logs-btn",
    ".ask-oracle-visual-actions",
    ".ask-oracle-table-zoom-control",
    ".ask-oracle-table-zoom-label",
    ".loading-spinner",
    "[class^='llm-more-rows-']",
    "[class*=' llm-more-rows-']",
    "script"
  ];
  clone.querySelectorAll(removableSelectors.join(",")).forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  if (opts.kind === "prompt") {
    clone.classList.add("ask-oracle-pdf-export-prompt-copy");
  }

  if (opts.kind === "chart-block") {
    const controlsRow = clone.firstElementChild;
    if (controlsRow && controlsRow.querySelector("select.chart-type, select.chart-xaxis, select.chart-yaxis")) {
      try { controlsRow.remove(); } catch (e) {}
    }
    clone.querySelectorAll("select.chart-type, select.chart-xaxis, select.chart-yaxis").forEach((node) => {
      const row = node.closest("div");
      if (row && row.parentElement === clone) {
        try { row.remove(); } catch (e) {}
      } else {
        try { node.remove(); } catch (e) {}
      }
    });
  }

  if (opts.forceVisible) {
    clone.style.setProperty("display", "block", "important");
    clone.style.setProperty("visibility", "visible", "important");
    clone.style.setProperty("opacity", "1", "important");
    clone.style.setProperty("height", "auto", "important");
    clone.style.setProperty("max-height", "none", "important");
  }

  clone.querySelectorAll(".ask-oracle-visual-panel").forEach((panel) => {
    panel.style.setProperty("box-shadow", "none", "important");
    panel.style.setProperty("margin", "0 0 16px 0", "important");
  });
  clone.querySelectorAll(".ask-oracle-visual-body, .chart-wrapper").forEach((node) => {
    node.style.setProperty("overflow", "hidden", "important");
  });

  return clone;
}

function replaceCanvasContentInClone(sourceRoot, cloneRoot) {
  if (!sourceRoot || !cloneRoot) return;

  const sourceCanvases = sourceRoot.querySelectorAll("canvas");
  const cloneCanvases = cloneRoot.querySelectorAll("canvas");
  cloneCanvases.forEach((cloneCanvas, index) => {
    const sourceCanvas = sourceCanvases[index];
    if (!sourceCanvas || typeof sourceCanvas.toDataURL !== "function") return;

    try {
      const img = document.createElement("img");
      img.src = sourceCanvas.toDataURL("image/png");
      img.alt = "Chart";
      img.style.display = "block";
      img.style.maxWidth = "100%";
      img.style.width = "100%";
      img.style.objectFit = "contain";
      img.style.height = cloneCanvas.closest(".ask-oracle-visual-body, .chart-wrapper") ? "100%" : "auto";
      cloneCanvas.replaceWith(img);
    } catch (e) {
      console.warn("Unable to convert canvas for PDF export:", e);
    }
  });
}

function buildConversationExportSection(titleText, contentNode, sectionKind) {
  if (!contentNode) return null;

  const section = document.createElement("section");
  section.className = "ask-oracle-pdf-export-section";

  const label = document.createElement("div");
  label.className = "ask-oracle-pdf-export-label";
  label.textContent = String(titleText || "");
  section.appendChild(label);

  const card = document.createElement("div");
  card.className = `ask-oracle-pdf-export-card${sectionKind ? ` ${sectionKind}` : ""}`;
  card.appendChild(contentNode);
  section.appendChild(card);

  return section;
}

function getAskOraclePdfExportShellStyleText() {
  return `
    .ask-oracle-pdf-export-shell {
      width: 1000px;
      box-sizing: border-box;
      padding: 18px;
      background: #ffffff;
      color: #0f172a;
      font-family: Inter, Arial, sans-serif;
    }
    .ask-oracle-pdf-export-header {
      margin-bottom: 20px;
    }
    .ask-oracle-pdf-export-title {
      margin: 0;
      font-size: 24px;
      font-weight: 700;
      line-height: 1.2;
      color: #0f172a;
    }
    .ask-oracle-pdf-export-meta {
      margin-top: 6px;
      font-size: 12px;
      color: #64748b;
    }
    .ask-oracle-pdf-export-section {
      margin-top: 12px;
    }
    .ask-oracle-pdf-export-label {
      margin-bottom: 8px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: #64748b;
    }
    .ask-oracle-pdf-export-card {
      border: 1px solid #e2e8f0;
      border-radius: 18px;
      padding: 14px 16px;
      background: #ffffff;
      overflow: hidden;
      box-shadow: none;
    }
    .ask-oracle-pdf-export-card.prompt {
      background: #f8fafc;
      border-color: #cbd5e1;
    }
    .ask-oracle-pdf-export-card .response-box,
    .ask-oracle-pdf-export-card .response,
    .ask-oracle-pdf-export-card .llm-chat {
      background: transparent !important;
      border: 0 !important;
      box-shadow: none !important;
      margin: 0 !important;
      padding: 0 !important;
      color: #0f172a !important;
    }
    .ask-oracle-pdf-export-card .message-bubble {
      max-width: none !important;
      margin: 0 !important;
      padding: 0 !important;
      background: transparent !important;
      color: #0f172a !important;
      box-shadow: none !important;
    }
    .ask-oracle-pdf-export-card .profile-label,
    .ask-oracle-pdf-export-card .code-editor-run-output-meta,
    .ask-oracle-pdf-export-card .ask-oracle-visual-title {
      color: #0f172a !important;
    }
    .ask-oracle-pdf-export-card .code-editor-run-output-table-wrap,
    .ask-oracle-pdf-export-card .llm-graph-block {
      overflow: visible !important;
    }
    .ask-oracle-pdf-export-card .ask-oracle-visual-panel {
      border: 1px solid #e2e8f0 !important;
      box-shadow: none !important;
      background: #ffffff !important;
    }
    .ask-oracle-pdf-export-card .ask-oracle-visual-toolbar {
      margin-bottom: 12px;
    }
    .ask-oracle-pdf-export-card .ask-oracle-visual-actions {
      display: none !important;
    }
    .ask-oracle-pdf-export-card table {
      width: 100% !important;
      border-collapse: collapse !important;
      color: #0f172a !important;
    }
    .ask-oracle-pdf-export-card th,
    .ask-oracle-pdf-export-card td {
      border: 1px solid #cbd5e1 !important;
      padding: 8px 10px !important;
      vertical-align: top !important;
      background: #ffffff !important;
      color: #0f172a !important;
    }
    .ask-oracle-pdf-export-card pre,
    .ask-oracle-pdf-export-card code {
      white-space: pre-wrap !important;
      overflow-wrap: anywhere !important;
      color: #0f172a !important;
    }
    .ask-oracle-pdf-export-card img,
    .ask-oracle-pdf-export-card svg,
    .ask-oracle-pdf-export-card canvas {
      max-width: 100% !important;
    }
    .ask-oracle-pdf-export-card svg {
      height: auto !important;
    }
  `;
}

function appendConversationPdfExportSections(shell, id) {
  if (!shell) return 0;
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return 0;

  const promptEl = document.getElementById(`prompt-${responseId}`);
  const responseEl = document.getElementById(`response-${responseId}`);
  const chartContainerEl = document.getElementById(`chart-container-${responseId}`);
  const chartBlockEl = document.getElementById(`chart-block-${responseId}`);
  const sqlBlockEl = document.getElementById(`sql-block-${responseId}`);
  let sectionCount = 0;

  if (promptEl) {
    const promptSource = promptEl.querySelector(".message-bubble") || promptEl;
    if (hasConversationExportContent(promptSource)) {
      const promptClone = sanitizeConversationExportClone(promptSource.cloneNode(true), {
        kind: "prompt",
        forceVisible: true
      });
      const promptSection = buildConversationExportSection("Prompt", promptClone, "prompt");
      if (promptSection) {
        shell.appendChild(promptSection);
        sectionCount += 1;
      }
    }
  }

  if (responseEl && hasConversationExportContent(responseEl)) {
    const responseClone = sanitizeConversationExportClone(responseEl.cloneNode(true), {
      kind: "response",
      forceVisible: true
    });
    replaceCanvasContentInClone(responseEl, responseClone);
    const responseSection = buildConversationExportSection("Response", responseClone, "response");
    if (responseSection) {
      shell.appendChild(responseSection);
      sectionCount += 1;
    }
  }

  if (chartContainerEl && hasConversationExportContent(chartContainerEl)) {
    const chartContainerClone = sanitizeConversationExportClone(chartContainerEl.cloneNode(true), {
      kind: "visual",
      forceVisible: true
    });
    replaceCanvasContentInClone(chartContainerEl, chartContainerClone);
    const chartSection = buildConversationExportSection("Visualization", chartContainerClone, "visual");
    if (chartSection) {
      shell.appendChild(chartSection);
      sectionCount += 1;
    }
  }

  if (chartBlockEl && hasConversationExportContent(chartBlockEl)) {
    const chartBlockClone = sanitizeConversationExportClone(chartBlockEl.cloneNode(true), {
      kind: "chart-block",
      forceVisible: true
    });
    replaceCanvasContentInClone(chartBlockEl, chartBlockClone);
    const chartBlockSection = buildConversationExportSection("Visualization", chartBlockClone, "visual");
    if (chartBlockSection) {
      shell.appendChild(chartBlockSection);
      sectionCount += 1;
    }
  }

 
  if (sqlBlockEl && isElementVisible(sqlBlockEl) && hasConversationExportContent(sqlBlockEl)) {
    const sqlClone = sanitizeConversationExportClone(sqlBlockEl.cloneNode(true), {
      kind: "sql",
      forceVisible: true
    });
    const sqlSection = buildConversationExportSection("SQL", sqlClone, "sql");
    if (sqlSection) {
      shell.appendChild(sqlSection);
      sectionCount += 1;
    }
  }

  return sectionCount;
}

function getAskOracleConversationExportEntryIdsFromDom(root) {
  const scope = root && typeof root.querySelectorAll === "function" ? root : document;
  const ids = [];
  const seen = new Set();

  scope.querySelectorAll("[id^='prompt-'], [id^='response-'], .response[data-id], .response-box[data-id]").forEach((node) => {
    if (!node) return;

    const domId = String(node.id || "").trim();
    const dataId = String((typeof node.getAttribute === "function" && node.getAttribute("data-id")) || "").trim();
    const candidateId = normalizeResponseContentId(
      domId.replace(/^prompt-/, "").replace(/^response-/, "") || dataId
    );
    if (!candidateId || seen.has(candidateId)) return;
    seen.add(candidateId);
    ids.push(candidateId);
  });

  return ids;
}

function buildConversationPdfExportSnapshot(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return null;
  const mount = document.createElement("div");
  mount.style.position = "absolute";
  mount.style.left = "-20000px";
  mount.style.top = "0";
  mount.style.width = "1040px";
  mount.style.pointerEvents = "none";
  mount.style.opacity = "1";
  mount.style.zIndex = "-1";
  mount.style.background = "#ffffff";

  const style = document.createElement("style");
  style.textContent = getAskOraclePdfExportShellStyleText();
  mount.appendChild(style);

  const shell = document.createElement("div");
  shell.className = "ask-oracle-pdf-export-shell";
  const sectionCount = appendConversationPdfExportSections(shell, responseId);
  if (sectionCount === 0) {
    return null;
  }

  mount.appendChild(shell);
  document.body.appendChild(mount);

  return {
    mount: mount,
    node: shell,
    cleanup: function() {
      try { mount.remove(); } catch (e) {}
    }
  };
}

function sanitizeAskOracleFileNameSegment(value, fallbackValue) {
  const normalized = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
  return normalized || String(fallbackValue || "conversation");
}

function showAskOraclePdfExportError(err, fallbackMessage) {
  console.error("PDF export failed:", err);
  try { apex.message.clearErrors(); } catch (e) {}
  if (window.apex && apex.message && typeof apex.message.showErrors === "function") {
    apex.message.showErrors([{
      type: "error",
      location: "page",
      message: (err && err.message) ? err.message : String(fallbackMessage || "Failed to export PDF."),
      unsafe: false
    }]);
    return;
  }
  showAppToast(String(fallbackMessage || "Failed to export PDF."), "error", 2600);
}

function formatAskOraclePdfChromeTimestamp(dateValue) {
  try {
    return new Intl.DateTimeFormat("en-IN", {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    }).format(dateValue || new Date());
  } catch (e) {
    return String((dateValue || new Date()).toISOString().replace("T", " ").slice(0, 16));
  }
}

function drawAskOraclePdfPageChrome(pdf, pageNumber, totalPages, metrics, exportedAtLabel) {
  if (!pdf || !metrics) return;

  const pageWidth = Number(metrics.pageWidth) || 0;
  const pageHeight = Number(metrics.pageHeight) || 0;
  const sideMargin = Number(metrics.sideMargin) || 16;
  const topMargin = Number(metrics.topMargin) || 14;
  const bottomMargin = Number(metrics.bottomMargin) || 16;
  const headerHeight = Number(metrics.headerHeight) || 18;
  const footerHeight = Number(metrics.footerHeight) || 18;
  const headerBottomY = topMargin + headerHeight;
  const footerTopY = pageHeight - bottomMargin - footerHeight;
  const footerTextY = pageHeight - bottomMargin - 5;
  const safePageNumber = Math.max(1, Number(pageNumber) || 1);
  const safeTotalPages = Math.max(safePageNumber, Number(totalPages) || 1);

  pdf.setDrawColor(203, 213, 225);
  pdf.setLineWidth(0.6);
  pdf.line(sideMargin, headerBottomY, pageWidth - sideMargin, headerBottomY);
  pdf.line(sideMargin, footerTopY, pageWidth - sideMargin, footerTopY);

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8);
  pdf.setTextColor(100, 116, 139);

  if (exportedAtLabel) {
    pdf.text(String(exportedAtLabel), pageWidth - sideMargin, topMargin + 10, { align: "right" });
  }
  pdf.text(`Page ${safePageNumber} of ${safeTotalPages}`, pageWidth / 2, footerTextY, { align: "center" });
}

async function saveAskOracleSnapshotNodeAsPdf(node, fileName, options) {
  if (!node) throw new Error("No export content found.");

  const opts = options || {};
  const libs = await ensurePdfExportLibrariesLoaded();
  await waitForAskOracleFontsReady(1800);
  await waitForAskOracleAnimationFrames(2);
  await waitForImagesInNode(node, 2800);

  const canvas = await libs.html2canvas(node, {
    backgroundColor: "#ffffff",
    scale: Math.max(2, Math.min(3, (window.devicePixelRatio || 1) * 1.5)),
    useCORS: true,
    logging: false
  });

  const pdf = new libs.jsPDF("p", "pt", "a4");
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const sideMargin = Math.max(12, Number(opts.sideMargin) || 16);
  const topMargin = Math.max(10, Number(opts.topMargin) || 14);
  const bottomMargin = Math.max(10, Number(opts.bottomMargin) || 16);
  const headerHeight = Math.max(14, Number(opts.headerHeight) || 18);
  const footerHeight = Math.max(14, Number(opts.footerHeight) || 18);
  const headerGap = Math.max(4, Number(opts.headerGap) || 8);
  const footerGap = Math.max(4, Number(opts.footerGap) || 8);
  const printableWidth = pageWidth - (sideMargin * 2);
  const contentStartY = topMargin + headerHeight + headerGap;
  const contentEndY = pageHeight - bottomMargin - footerHeight - footerGap;
  const printableHeight = Math.max(80, contentEndY - contentStartY);
  const totalPages = Math.max(1, Math.ceil((canvas.height * printableWidth / canvas.width) / printableHeight));
  const imageData = canvas.toDataURL("image/png");
  const scaledHeight = canvas.height * printableWidth / canvas.width;
  const exportedAtLabel = String(opts.exportedAtLabel || `Exported ${formatAskOraclePdfChromeTimestamp(new Date())}`);

  for (let pageIndex = 0; pageIndex < totalPages; pageIndex += 1) {
    const currentOffset = pageIndex * printableHeight;
    if (pageIndex > 0) pdf.addPage();
    pdf.addImage(
      imageData,
      "PNG",
      sideMargin,
      contentStartY - currentOffset,
      printableWidth,
      scaledHeight,
      undefined,
      "MEDIUM"
    );
    drawAskOraclePdfPageChrome(pdf, pageIndex + 1, totalPages, {
      pageWidth: pageWidth,
      pageHeight: pageHeight,
      sideMargin: sideMargin,
      topMargin: topMargin,
      bottomMargin: bottomMargin,
      headerHeight: headerHeight,
      footerHeight: footerHeight
    }, exportedAtLabel);
  }

  pdf.save(String(fileName || `conversation-${Date.now()}.pdf`));
}

function getAskOracleConversationNavTitle(conversationId, sourceNode) {
  const targetConversationId = String(conversationId || "").trim();
  const contentNode = sourceNode && typeof sourceNode.closest === "function"
    ? (sourceNode.closest(".a-TreeView-content") || sourceNode)
    : sourceNode;

  const directLabel = contentNode && contentNode.querySelector
    ? contentNode.querySelector(".a-TreeView-label")
    : null;
  const directTitle = normalizeAskOracleHistoryNavLabel(directLabel ? directLabel.textContent : "");
  if (directTitle) return directTitle;

  if (targetConversationId) {
    const navNode = Array.from(document.querySelectorAll("#t_TreeNav .a-TreeView-content, #t_TreeNav .a-TreeView-label, #t_TreeNav li"))
      .find((node) => String(getAskOracleConversationIdFromNavNode(node) || "").trim() === targetConversationId);
    const labelNode = navNode && navNode.querySelector
      ? navNode.querySelector(".a-TreeView-label")
      : (navNode && navNode.classList && navNode.classList.contains("a-TreeView-label") ? navNode : null);
    const navTitle = normalizeAskOracleHistoryNavLabel(labelNode ? labelNode.textContent : "");
    if (navTitle) return navTitle;
  }

  const fallbackTitle = targetConversationId
    ? `Conversation ${targetConversationId.slice(0, 12)}`
    : "Conversation";
  return normalizeAskOracleHistoryNavLabel(fallbackTitle) || "Conversation";
}

function sanitizeConversationThreadExportClone(sourceRoot, cloneRoot) {
  if (!sourceRoot || !cloneRoot) return cloneRoot;

  replaceCanvasContentInClone(sourceRoot, cloneRoot);

  const removableSelectors = [
    ".copy-btn",
    ".speech-controls",
    ".chart-sql-buttons",
    ".ask-oracle-response-table-actions",
    ".open-editor-btn",
    ".conversation-time-btn",
    ".view-agent-logs-btn",
    ".ask-oracle-visual-actions",
    ".ask-oracle-table-zoom-control",
    ".ask-oracle-table-zoom-label",
    ".loading-spinner",
    '[id^="loading-indicator-"]',
    `[id="${NEW_PROMPT_SCROLL_SPACER_ID}"]`,
    "[class^='llm-more-rows-']",
    "[class*=' llm-more-rows-']",
    "script"
  ];
  cloneRoot.querySelectorAll(removableSelectors.join(",")).forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  const sourceVisualNodes = sourceRoot.querySelectorAll(".chart-container, .chart-block, .sql-block");
  const cloneVisualNodes = cloneRoot.querySelectorAll(".chart-container, .chart-block, .sql-block");
  cloneVisualNodes.forEach((cloneNode, index) => {
    const sourceNode = sourceVisualNodes[index];
    const isSqlBlock = cloneNode.classList && cloneNode.classList.contains("sql-block");
    const shouldKeep =
      !!sourceNode &&
      hasConversationExportContent(sourceNode) &&
      (!isSqlBlock || isElementVisible(sourceNode));

    if (!shouldKeep) {
      try { cloneNode.remove(); } catch (e) {}
      return;
    }

    cloneNode.style.setProperty("display", "block", "important");
    cloneNode.style.setProperty("visibility", "visible", "important");
    cloneNode.style.setProperty("opacity", "1", "important");
    cloneNode.style.setProperty("height", "auto", "important");
    cloneNode.style.setProperty("max-height", "none", "important");

    if (cloneNode.classList && cloneNode.classList.contains("chart-block")) {
      const controlsRow = cloneNode.firstElementChild;
      if (controlsRow && controlsRow.querySelector("select.chart-type, select.chart-xaxis, select.chart-yaxis")) {
        try { controlsRow.remove(); } catch (e) {}
      }
      cloneNode.querySelectorAll("select.chart-type, select.chart-xaxis, select.chart-yaxis").forEach((node) => {
        try { node.remove(); } catch (e) {}
      });
    }
  });

  cloneRoot.querySelectorAll(".ask-oracle-visual-panel").forEach((panel) => {
    panel.style.setProperty("box-shadow", "none", "important");
    panel.style.setProperty("margin", "0 0 16px 0", "important");
  });
  cloneRoot.querySelectorAll(".ask-oracle-visual-body, .chart-wrapper, .code-editor-run-output-table-wrap, .llm-graph-block").forEach((node) => {
    node.style.setProperty("overflow", "visible", "important");
  });

  return cloneRoot;
}

function buildConversationThreadPdfExportSnapshot(options) {
  const opts = options || {};
  const sourceRoot = opts.sourceNode || getAskOraclePromptListContainer();
  if (!sourceRoot) return null;

  const mount = document.createElement("div");
  mount.style.position = "absolute";
  mount.style.left = "-20000px";
  mount.style.top = "0";
  mount.style.width = "1040px";
  mount.style.pointerEvents = "none";
  mount.style.opacity = "1";
  mount.style.zIndex = "-1";
  mount.style.background = "#ffffff";

  const style = document.createElement("style");
  style.textContent = getAskOraclePdfExportShellStyleText();
  mount.appendChild(style);

  const shell = document.createElement("div");
  shell.className = "ask-oracle-pdf-export-shell";

  let sectionCount = 0;
  getAskOracleConversationExportEntryIdsFromDom(sourceRoot).forEach((entryId) => {
    sectionCount += appendConversationPdfExportSections(shell, entryId);
  });

  if (sectionCount === 0) {
    return null;
  }

  mount.appendChild(shell);
  document.body.appendChild(mount);
  return {
    mount: mount,
    node: shell,
    cleanup: function() {
      try { mount.remove(); } catch (e) {}
    }
  };
}

function hasAskOracleConversationReadyForThreadExport(conversationId) {
  const targetConversationId = String(conversationId || getAskOracleCurrentConversationId() || "").trim();
  const currentConversationId = String(getAskOracleCurrentConversationId() || "").trim();
  if (targetConversationId && currentConversationId && targetConversationId !== currentConversationId) {
    return false;
  }

  const container = getAskOraclePromptListContainer();
  if (!container) return false;

  const hasAnyConversationNodes = !!container.querySelector(".chat-message, .response-box, .chart-container, .chart-block, .sql-block");
  if (!hasAnyConversationNodes) {
    return String(container.innerText || container.textContent || "").trim().length > 0;
  }

  const responseIds = getAskOracleConversationResponseIdsFromDom();
  if (responseIds.length === 0) return true;

  return responseIds.every((id) => {
    const responseEl = document.getElementById(`response-${id}`);
    const chartContainerEl = document.getElementById(`chart-container-${id}`);
    const chartBlockEl = document.getElementById(`chart-block-${id}`);
    const sqlBlockEl = document.getElementById(`sql-block-${id}`);
    const hasSpinner = !!(responseEl && responseEl.querySelector(".loading-spinner"));
    if (hasSpinner) return false;

    return (
      hasConversationExportContent(responseEl) ||
      hasConversationExportContent(chartContainerEl) ||
      hasConversationExportContent(chartBlockEl) ||
      (!!sqlBlockEl && isElementVisible(sqlBlockEl) && hasConversationExportContent(sqlBlockEl))
    );
  });
}

function waitForAskOracleConversationReadyForPdfExport(conversationId, timeoutMs) {
  const targetConversationId = String(conversationId || getAskOracleCurrentConversationId() || "").trim();
  const maxWaitMs = Math.max(1200, Number(timeoutMs) || 10000);

  return new Promise((resolve, reject) => {
    const startedAt = Date.now();

    function finishFromCurrentDomIfPossible() {
      const container = getAskOraclePromptListContainer();
      const hasFallbackContent = !!(
        container &&
        (
          container.querySelector(".chat-message, .response-box, .chart-container, .chart-block, .sql-block") ||
          String(container.innerText || container.textContent || "").trim().length > 0
        )
      );
      if (hasFallbackContent) {
        resolve(false);
        return true;
      }
      return false;
    }

    function poll() {
      if (hasAskOracleConversationReadyForThreadExport(targetConversationId)) {
        resolve(true);
        return;
      }

      if ((Date.now() - startedAt) >= maxWaitMs) {
        if (finishFromCurrentDomIfPossible()) return;
        reject(new Error("Conversation content is still loading. Please try again in a moment."));
        return;
      }

      setTimeout(poll, 160);
    }

    poll();
  });
}

async function exportActiveConversationThreadToPdf(options) {
  const opts = options || {};
  const conversationId = String(opts.conversationId || getAskOracleCurrentConversationId() || "").trim();
  const inFlightKey = conversationId || "__current__";
  const manageInFlight = opts.manageInFlight !== false;
  let inFlightMarked = false;
  if (manageInFlight && askOracleConversationPdfExportInFlightById[inFlightKey]) return false;

  let snapshot = null;
  if (manageInFlight) {
    askOracleConversationPdfExportInFlightById[inFlightKey] = true;
    inFlightMarked = true;
  }

  try {
    const title = String(opts.title || getAskOracleConversationNavTitle(conversationId, opts.triggerNode) || "Conversation").trim();
    snapshot = buildConversationThreadPdfExportSnapshot({
      sourceNode: opts.sourceNode || getAskOraclePromptListContainer(),
      conversationId: conversationId,
      title: title,
      triggerNode: opts.triggerNode || null
    });
    if (!snapshot || !snapshot.node) {
      throw new Error("No conversation content found to export.");
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const baseName = sanitizeAskOracleFileNameSegment(title || conversationId || "conversation", "conversation");
    await saveAskOracleSnapshotNodeAsPdf(snapshot.node, `${baseName}-${timestamp}.pdf`);
    showAppToast(String(opts.successMessage || "Conversation PDF exported successfully."), "success", 2200);
    return true;
  } catch (err) {
    showAskOraclePdfExportError(err, "Failed to export the conversation as PDF.");
    return false;
  } finally {
    if (snapshot && typeof snapshot.cleanup === "function") snapshot.cleanup();
    if (inFlightMarked) {
      delete askOracleConversationPdfExportInFlightById[inFlightKey];
    }
  }
}

async function exportConversationHistoryThreadToPdf(conversationId, triggerNode) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return false;
  if (askOracleConversationPdfExportInFlightById[targetConversationId]) return false;
  askOracleConversationPdfExportInFlightById[targetConversationId] = true;

  closeAskOracleHistoryActionMenu();

  const currentConversationId = String(getAskOracleCurrentConversationId() || "").trim();
  const targetTitle = getAskOracleConversationNavTitle(targetConversationId, triggerNode);

  if (currentConversationId && currentConversationId === targetConversationId) {
    return exportActiveConversationThreadToPdf({
      conversationId: targetConversationId,
      title: targetTitle,
      triggerNode: triggerNode,
      manageInFlight: false,
      successMessage: "Conversation PDF exported successfully."
    });
  }

  if (askOracleConversationSwitchInProgress) {
    showAskOraclePdfExportError(
      new Error("Wait for the conversation to finish loading, then try again."),
      "Wait for the conversation to finish loading, then try again."
    );
    return false;
  }

  if (document.body.classList.contains("code-editor-mode")) {
    showAskOraclePdfExportError(
      new Error("Close the code editor before exporting another conversation."),
      "Close the code editor before exporting another conversation."
    );
    return false;
  }

  if (isPromptRequestRunning()) {
    showAskOraclePdfExportError(
      new Error("Wait for the current response to finish before exporting another conversation."),
      "Wait for the current response to finish before exporting another conversation."
    );
    return false;
  }

  let switched = false;
  try {
    showAppToast("Preparing conversation PDF...", "", 1800);
    switched = switchAskOracleConversationInPlace(targetConversationId, { forceRefresh: true });
    if (!switched) {
      throw new Error("Unable to load the selected conversation for export.");
    }

    await waitForAskOracleConversationReadyForPdfExport(targetConversationId, 10000);
    return await exportActiveConversationThreadToPdf({
      conversationId: targetConversationId,
      title: targetTitle,
      triggerNode: triggerNode,
      manageInFlight: false,
      successMessage: "Conversation PDF exported successfully."
    });
  } catch (err) {
    showAskOraclePdfExportError(err, "Failed to export the selected conversation as PDF.");
    return false;
  } finally {
    if (switched) {
      if (currentConversationId) {
        switchAskOracleConversationInPlace(currentConversationId, { forceRefresh: true });
      } else {
        askOracleStartNewChat();
      }
    }
    delete askOracleConversationPdfExportInFlightById[targetConversationId];
  }
}

function setResponsePdfButtonsBusy(id, busy) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId) return;
  document.querySelectorAll(`.export-pdf-response-btn[data-response-id="${responseId}"]`).forEach((btn) => {
    btn.disabled = !!busy;
    btn.setAttribute("aria-busy", busy ? "true" : "false");
    btn.style.opacity = busy ? "0.6" : "";
    btn.style.pointerEvents = busy ? "none" : "";
  });
}

function createSpeechPdfExportButton(id) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "speech-icon-button export-pdf-response-btn";
  btn.setAttribute("data-response-id", String(id || "").trim());
  btn.setAttribute("data-tooltip", "Export PDF");
  btn.setAttribute("aria-label", "Export conversation as PDF");
  btn.innerHTML = getAskOracleInlineSvgIcon("pdf", "ask-oracle-icon-pdf");
  btn.addEventListener("click", function() {
    exportConversationToPdf(id);
  });
  return btn;
}

function createSpeechExcelExportButton(id) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "speech-icon-button export-excel-response-btn";
  btn.setAttribute("data-tooltip", "Export Excel");
  btn.setAttribute("aria-label", "Export table to Excel");
  btn.innerHTML = getAskOracleInlineSvgIcon("excel", "ask-oracle-icon-excel");
  btn.addEventListener("click", function() {
    downloadResponseTableAsExcel(id);
  });
  return btn;
}

function createActionRowPdfExportButton(id) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "t-Button t-Button--icon t-Button--small export-pdf-response-btn";
  btn.setAttribute("data-response-id", String(id || "").trim());
  btn.setAttribute("aria-label", "Export conversation as PDF");
  btn.setAttribute("data-tooltip", "Export PDF");
  btn.title = "Export conversation as PDF";
  btn.innerHTML = getAskOracleInlineSvgIcon("pdf", "ask-oracle-icon-pdf");
  btn.addEventListener("click", function() {
    exportConversationToPdf(id);
  });
  return btn;
}

function createActionRowExcelExportButton(id) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "t-Button t-Button--icon t-Button--small export-excel-response-btn";
  btn.setAttribute("aria-label", "Export table to Excel");
  btn.setAttribute("data-tooltip", "Export Excel");
  btn.title = "Export table to Excel";
  btn.innerHTML = getAskOracleInlineSvgIcon("excel", "ask-oracle-icon-excel");
  btn.addEventListener("click", function() {
    downloadResponseTableAsExcel(id);
  });
  return btn;
}

async function exportConversationToPdf(id) {
  const responseId = normalizeResponseContentId(id);
  if (!responseId || askOraclePdfExportInFlightById[responseId]) return;

  let snapshot = null;
  askOraclePdfExportInFlightById[responseId] = true;
  setResponsePdfButtonsBusy(responseId, true);

  try {
    snapshot = buildConversationPdfExportSnapshot(responseId);
    if (!snapshot || !snapshot.node) {
      throw new Error("No conversation content found to export.");
    }
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    await saveAskOracleSnapshotNodeAsPdf(snapshot.node, `${getResponseDisplayBaseName(responseId)}-${timestamp}.pdf`);
    showAppToast("PDF exported successfully.", "success", 2200);
  } catch (err) {
    showAskOraclePdfExportError(err, "Failed to export the conversation as PDF.");
  } finally {
    if (snapshot && typeof snapshot.cleanup === "function") snapshot.cleanup();
    setResponsePdfButtonsBusy(responseId, false);
    delete askOraclePdfExportInFlightById[responseId];
  }
}

function ensureCodeEditorPanelCss() {
  if (document.getElementById(CODE_EDITOR_PANEL_CSS_ID)) return;

  const style = document.createElement("style");
  style.id = CODE_EDITOR_PANEL_CSS_ID;
  style.textContent = `
    :root {
      --code-editor-panel-width: clamp(${CODE_EDITOR_PANEL_MIN_WIDTH_PX}px, ${Math.round(CODE_EDITOR_PANEL_DEFAULT_WIDTH_RATIO * 100)}vw, ${CODE_EDITOR_PANEL_MAX_WIDTH_PX}px);
    }
    .open-editor-btn {
      padding: 0 10px !important;
      border-radius: 8px !important;
      width: auto !important;
      min-width: 104px;
      gap: 6px;
      font-size: 12px;
    }
    .open-editor-btn .open-editor-btn-label {
      white-space: nowrap;
      font-size: 13px;
      font-weight: 500;
    }
    .response-box.has-inline-open-editor {
      position: static !important;
      padding-top: 0 !important;
    }
    .response-open-editor-inline {
      display: none !important;
    }
    .response-open-editor-inline:hover {
      background: #f8fafc;
    }
    #${CODE_EDITOR_PANEL_ID} {
      position: fixed;
      top: 0;
      right: 0;
      width: var(--code-editor-panel-width);
      height: 100vh;
      background: #0f172a;
      border-left: 1px solid #273449;
      box-shadow: none;
      z-index: 1700;
      display: flex;
      flex-direction: column;
      opacity: 0;
      visibility: hidden;
      pointer-events: none;
      transform: translateX(24px);
      transition:
        transform 0.28s cubic-bezier(0.2, 0.75, 0.2, 1),
        opacity 0.22s ease,
        visibility 0s linear 0.28s;
    }
    body.code-editor-mode #${CODE_EDITOR_PANEL_ID} {
      opacity: 1;
      visibility: visible;
      pointer-events: auto;
      transform: translateX(0);
      transition:
        transform 0.28s cubic-bezier(0.2, 0.75, 0.2, 1),
        opacity 0.22s ease,
        visibility 0s linear 0s;
    }
    .t-Body-content {
      transition: padding-right 0.3s ease, padding-left 0.3s ease;
    }
    #${CODE_EDITOR_PANEL_ID}.diff-visible .code-editor-body {
      flex: 0 0 clamp(120px, 24%, 220px);
      min-height: 120px;
    }
    body.code-editor-mode .t-Body-content {
      padding-left: 20px !important;
      padding-right: calc(var(--code-editor-panel-width) + 22px) !important;
      transition: padding-right 0.3s ease;
    }
    body.code-editor-mode #PROMPTS,
    body.code-editor-mode #PROMPTS .t-Region-body,
    body.code-editor-mode #PROMPTS .prompt-list,
    body.code-editor-mode #PROMPTS_TemplateComponent,
    body.code-editor-mode #promptWrapper,
    body.code-editor-mode .t-Footer-body,
    body.code-editor-mode .t-Footer-content {
      width: 100% !important;
      max-width: none !important;
    }
    body.code-editor-mode #PROMPTS [id^="prompt-"],
    body.code-editor-mode #PROMPTS [id^="response-"],
    body.code-editor-mode #PROMPTS .chat-message,
    body.code-editor-mode #PROMPTS .message-bubble,
    body.code-editor-mode #PROMPTS .response,
    body.code-editor-mode #PROMPTS .response-box,
    body.code-editor-mode #PROMPTS .llm-chat,
    body.code-editor-mode #PROMPTS .chart-container,
    body.code-editor-mode #PROMPTS .chart-block,
    body.code-editor-mode #PROMPTS .sql-block {
      width: 100% !important;
      max-width: none !important;
    }
    body.code-editor-mode #PROMPTS .t-Region-body,
    body.code-editor-mode #PROMPTS .prompt-list {
      background: #f8fafc !important;
      border-radius: 10px !important;
    }
    body.code-editor-mode #PROMPTS .prompt-list {
      padding-top: 8px !important;
      padding-bottom: 8px !important;
    }
    body.code-editor-mode #PROMPTS .chat-message,
    body.code-editor-mode #PROMPTS .message-bubble,
    body.code-editor-mode #PROMPTS .response-box,
    body.code-editor-mode #PROMPTS .llm-chat,
    body.code-editor-mode #PROMPTS table,
    body.code-editor-mode #PROMPTS pre {
      font-size: 14px !important;
      line-height: 1.35 !important;
    }
    body.code-editor-mode #PROMPTS .message-bubble,
    body.code-editor-mode #PROMPTS .response-box,
    body.code-editor-mode #PROMPTS .llm-chat {
      border: 0 !important;
      box-shadow: none !important;
    }
    body.code-editor-mode #PROMPTS .chat-message {
      margin-bottom: 8px !important;
    }
    body.code-editor-mode .speech-controls[data-id] .speech-icon-button {
      display: none !important;
    }
    body.code-editor-mode .speech-controls[data-id] .speech-icon-button.open-editor-btn {
      display: inline-flex !important;
    }
    body.code-editor-mode .speech-controls[data-id] > div:first-child {
      gap: 0 !important;
    }
    body.code-editor-mode .t-Footer {
      opacity: 1 !important;
    }
    body.code-editor-mode label[for="P1_CURRENT_AI_PROFILE"],
    body.code-editor-mode #P1_CURRENT_AI_PROFILE,
    body.code-editor-mode #P1_CURRENT_AI_PROFILE_CONTAINER,
    body.code-editor-mode #P1_CURRENT_AI_PROFILE_DISPLAY,
    body.code-editor-mode label[for="P1_AGENT_PROFILE"],
    body.code-editor-mode #P1_AGENT_PROFILE,
    body.code-editor-mode #P1_AGENT_PROFILE_CONTAINER,
    body.code-editor-mode #P1_AGENT_PROFILE_DISPLAY,
    body.code-editor-mode label[for="P1_AGENT_TEAM"],
    body.code-editor-mode #P1_AGENT_TEAM,
    body.code-editor-mode #P1_AGENT_TEAM_CONTAINER,
    body.code-editor-mode #P1_AGENT_TEAM_DISPLAY,
    body.code-editor-mode label[for="P1_AGENT_SERVICE"],
    body.code-editor-mode #P1_AGENT_SERVICE,
    body.code-editor-mode #P1_AGENT_SERVICE_CONTAINER,
    body.code-editor-mode #P1_AGENT_SERVICE_DISPLAY,
    body.code-editor-mode label[for="P1_SERVICE"],
    body.code-editor-mode #P1_SERVICE,
    body.code-editor-mode #P1_SERVICE_CONTAINER,
    body.code-editor-mode #P1_SERVICE_DISPLAY,
    body.code-editor-mode label[for="P1_PROFILE"],
    body.code-editor-mode #P1_PROFILE,
    body.code-editor-mode #P1_PROFILE_CONTAINER,
    body.code-editor-mode #P1_PROFILE_DISPLAY,
    body.code-editor-mode label[for="P1_RAG_PROFILE"],
    body.code-editor-mode #P1_RAG_PROFILE,
    body.code-editor-mode #P1_RAG_PROFILE_CONTAINER,
    body.code-editor-mode #P1_RAG_PROFILE_DISPLAY,
    body.code-editor-mode label[for="P1_RAG_CHAT"],
    body.code-editor-mode #P1_RAG_CHAT,
    body.code-editor-mode #P1_RAG_CHAT_CONTAINER,
    body.code-editor-mode #P1_RAG_CHAT_DISPLAY,
    body.code-editor-mode label[for="P1_RAG_SQL"],
    body.code-editor-mode #P1_RAG_SQL,
    body.code-editor-mode #P1_RAG_SQL_CONTAINER,
    body.code-editor-mode #P1_RAG_SQL_DISPLAY,
    body.code-editor-mode label[for="P1_RAGSERVICE"],
    body.code-editor-mode #P1_RAGSERVICE,
    body.code-editor-mode #P1_RAGSERVICE_CONTAINER,
    body.code-editor-mode #P1_RAGSERVICE_DISPLAY {
      display: none !important;
    }
    body.code-editor-mode #t_Body_nav,
    body.code-editor-mode .t-Body-nav {
      width: auto !important;
      min-width: initial !important;
      max-width: initial !important;
      flex-basis: auto !important;
      overflow: visible !important;
      opacity: 1 !important;
      visibility: visible !important;
      pointer-events: auto !important;
      transition: none !important;
    }
    body.code-editor-mode #t_PageBody.t-PageBody--showLeft .t-Body-main,
    body.code-editor-mode #t_PageBody .t-Body-main {
      margin-left: initial !important;
      padding-left: initial !important;
    }
    .code-editor-resizer {
      position: absolute;
      left: -4px;
      top: 0;
      width: 8px;
      height: 100%;
      cursor: col-resize;
      z-index: 2;
    }
    .code-editor-resizer::before {
      content: "";
      position: absolute;
      left: 3px;
      top: 0;
      width: 2px;
      height: 100%;
      background: rgba(203, 213, 225, 0.2);
    }
    .code-editor-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      border-bottom: 1px solid #273449;
      background: #111827;
      gap: 10px;
    }
    .code-editor-tabs {
      border-bottom: 1px solid #273449;
      background: #0f172a;
      padding: 6px 8px 0;
      overflow-x: auto;
      overflow-y: hidden;
      scrollbar-width: thin;
    }
    .code-editor-tab-list {
      display: inline-flex;
      min-width: 100%;
      gap: 6px;
      padding-bottom: 6px;
    }
    .code-editor-tab {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      max-width: 240px;
      border: 1px solid #334155;
      border-bottom-color: #1f2937;
      border-radius: 8px 8px 0 0;
      background: #172033;
      color: #cbd5e1;
      padding: 6px 8px;
      cursor: pointer;
      font-size: 12px;
      line-height: 1;
      flex: 0 0 auto;
    }
    .code-editor-tab:hover {
      background: #1f2c44;
    }
    .code-editor-tab.is-active {
      background: #dbeafe;
      color: #1e3a8a;
      border-color: #93c5fd;
      border-bottom-color: #dbeafe;
    }
    .code-editor-tab-rename {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 16px;
      height: 16px;
      border-radius: 4px;
      color: #94a3b8;
      font-size: 11px;
      flex: 0 0 auto;
      user-select: none;
    }
    .code-editor-tab-rename:hover {
      background: rgba(148, 163, 184, 0.2);
      color: #e2e8f0;
    }
    .code-editor-tab-label {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-family: "Fira Code", Consolas, monospace;
    }
    .code-editor-tab-rename-input {
      width: 100%;
      min-width: 90px;
      border: 1px solid #60a5fa;
      border-radius: 5px;
      background: #0f172a;
      color: #e2e8f0;
      padding: 2px 6px;
      font-size: 12px;
      line-height: 1.3;
      font-family: "Fira Code", Consolas, monospace;
      outline: none;
    }
    .code-editor-tab-close {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 16px;
      height: 16px;
      border-radius: 4px;
      color: #94a3b8;
      font-size: 12px;
      flex: 0 0 auto;
      user-select: none;
    }
    .code-editor-tab-close:hover {
      background: rgba(148, 163, 184, 0.2);
      color: #e2e8f0;
    }
    .code-editor-file {
      color: #dbeafe;
      font-size: 12px;
      font-family: "Fira Code", Consolas, monospace;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 60%;
    }
    .code-editor-actions {
      display: inline-flex;
      gap: 8px;
      flex-wrap: wrap;
      justify-content: flex-end;
    }
    .code-editor-actions button {
      border: 1px solid #334155;
      border-radius: 6px;
      background: #1e293b;
      color: #e2e8f0;
      padding: 5px 9px;
      font-size: 12px;
      cursor: pointer;
    }
    .code-editor-actions button:hover {
      background: #334155;
    }
    #code-editor-run-btn {
      background: #14532d;
      border-color: #16a34a;
      color: #dcfce7;
    }
    #code-editor-run-btn:hover {
      background: #166534;
    }
    #code-editor-download-btn {
      background: #1d4ed8;
      border-color: #3b82f6;
      color: #dbeafe;
    }
    #code-editor-download-btn:hover {
      background: #1e40af;
    }
    #code-editor-close-btn {
      background: #991b1b;
      border-color: #ee3737;
      color: #fee2e2;
    }
    #code-editor-close-btn:hover {
      background: #7f1d1d;
    }
    #code-editor-diff-btn {
      background: #6b21a8;
      border-color: #a855f7;
      color: #f3e8ff;
    }
    #code-editor-diff-btn:hover {
      background: #581c87;
    }
    #code-editor-merge-btn {
      background: #0f766e;
      border-color: #14b8a6;
      color: #ccfbf1;
    }
    #code-editor-merge-btn:hover {
      background: #115e59;
    }
    .code-editor-actions button:disabled {
      opacity: 0.55;
      cursor: not-allowed;
      background: #172033;
      border-color: #253142;
      color: #94a3b8;
    }
    .code-editor-body {
      flex: 1;
      min-height: 0;
      position: relative;
      background: #0b1220;
    }
    .code-editor-run-status {
      display: none !important;
      position: relative;
      border-top: 1px solid #273449;
      background: #0f172a;
      padding: 10px 12px 10px 16px;
      color: #cbd5e1;
      font-size: 12px;
      line-height: 1.4;
      min-height: 48px;
      white-space: pre-wrap;
      word-break: break-word;
    }
    #${CODE_EDITOR_PANEL_ID}.run-status-visible .code-editor-run-status {
      display: block;
    }
    .code-editor-run-status::before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 4px;
      background: #64748b;
    }
    .code-editor-run-status.is-running::before {
      background: #38bdf8;
    }
    .code-editor-run-status.is-success::before {
      background: #22c55e;
    }
    .code-editor-run-status.is-error::before {
      background: #f43f5e;
    }
    .code-editor-run-status.is-warning::before {
      background: #f59e0b;
    }
    .code-editor-run-status-title {
      color: #e2e8f0;
      font-weight: 600;
      margin-bottom: 2px;
      font-size: 12px;
    }
    .code-editor-run-status-text {
      color: #cbd5e1;
      font-size: 12px;
    }
    .code-editor-run-output {
      display: none;
      border-top: 1px solid #273449;
      background: #0b1220;
      color: #e2e8f0;
      max-height: 36vh;
      overflow: auto;
    }
    #${CODE_EDITOR_PANEL_ID}.run-output-visible .code-editor-run-output {
      display: block;
    }
    .code-editor-run-output-title {
      position: sticky;
      top: 0;
      z-index: 1;
      padding: 8px 12px;
      border-bottom: 1px solid #273449;
      background: #111827;
      font-size: 12px;
      font-weight: 600;
      color: #dbeafe;
    }
    .code-editor-run-output-content {
      padding: 0;
      font-size: 12px;
      line-height: 1.45;
      font-family: "Fira Code", Consolas, "Courier New", monospace;
      color: #cbd5e1;
    }
    .code-editor-run-output-tabs {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 10px;
      border-bottom: 1px solid #273449;
      background: #0f172a;
    }
    .code-editor-run-output-tab {
      border: 1px solid #334155;
      border-radius: 6px;
      background: #111827;
      color: #cbd5e1;
      font-size: 11px;
      line-height: 1;
      padding: 5px 8px;
      cursor: pointer;
    }
    .code-editor-run-output-tab:hover {
      background: #1f2937;
    }
    .code-editor-run-output-tab.is-active {
      background: #2563eb;
      border-color: #3b82f6;
      color: #eff6ff;
    }
    .code-editor-run-output-pane {
      display: none;
      padding: 10px 12px 12px;
      font-size: 12px;
      line-height: 1.45;
      font-family: "Fira Code", Consolas, "Courier New", monospace;
      color: #cbd5e1;
    }
    .code-editor-run-output-pane.is-active {
      display: block;
    }
    .code-editor-run-output-meta {
      margin-bottom: 8px;
      color: #94a3b8;
      font-size: 11px;
      line-height: 1.35;
    }
    .code-editor-run-output-pre {
      margin: 0;
      white-space: pre-wrap;
      word-break: break-word;
      color: #e2e8f0;
    }
    .code-editor-run-output-table-wrap {
      overflow: auto;
      border: 1px solid #8da2c0;
      border-radius: 12px;
      background: #ffffff;
      box-shadow: 0 10px 26px rgba(30, 64, 175, 0.11);
    }
    .code-editor-run-output-table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
      font-size: 13px;
      line-height: 1.45;
      background: #ffffff;
    }
    .code-editor-run-output-table th,
    .code-editor-run-output-table td {
      border: 1px solid #d3ddea;
      padding: 10px 12px;
      text-align: left;
      vertical-align: top;
      white-space: pre-wrap;
      word-break: break-word;
      max-width: 360px;
      background: #ffffff;
      color: #0f172a;
    }
    .code-editor-run-output-table tbody tr:nth-child(even) td {
      background: #f8fafc;
    }
    .code-editor-run-output-table tbody tr:hover td {
      background: #eff6ff;
    }
    .code-editor-run-output-table thead th {
      position: sticky;
      top: 0;
      background: linear-gradient(135deg, #4f46e5 0%, #2563eb 55%, #0891b2 100%) !important;
      color: #ffffff !important;
      font-weight: 750;
      letter-spacing: 0.025em;
      z-index: 1;
      border: 1px solid rgba(255, 255, 255, 0.28) !important;
      box-shadow: inset 0 -2px 0 rgba(15, 23, 42, 0.2);
    }
    .code-editor-run-output-table thead th:last-child {
      border-right: 1px solid rgba(255, 255, 255, 0.28) !important;
    }
    .llm-conv-show-charts-btn,
    .llm-conv-show-sql-btn,
    .explore-btn,
    .explain-btn,
    [onclick*='redirectToExplorePage'],
    [onclick*='redirectToExplainPage'] {
      font-size: 10px !important;
      line-height: 1.2 !important;
      font-weight: 600;
      letter-spacing: 0;
      height: 24px !important;
      min-height: 24px !important;
      padding: 2px 6px !important;
    }
    .llm-conv-show-charts-btn .t-Button-label,
    .llm-conv-show-sql-btn .t-Button-label,
    .explore-btn .t-Button-label,
    .explain-btn .t-Button-label {
      font-size: 10px !important;
      line-height: 1.2 !important;
      font-weight: 600;
    }
    .ask-oracle-sql-footer-actions .open-editor-btn,
    .ask-oracle-response-table-actions .open-editor-btn,
    .chart-sql-buttons .open-editor-btn {
      height: 24px !important;
      min-height: 24px !important;
      min-width: 0 !important;
      padding: 2px 6px !important;
      gap: 4px !important;
      border-radius: 6px !important;
      font-size: 10px !important;
    }
    .ask-oracle-sql-footer-actions .open-editor-btn .t-Button-label,
    .ask-oracle-response-table-actions .open-editor-btn .t-Button-label,
    .chart-sql-buttons .open-editor-btn .t-Button-label,
    .ask-oracle-sql-footer-actions .open-editor-btn .open-editor-btn-label,
    .ask-oracle-response-table-actions .open-editor-btn .open-editor-btn-label,
    .chart-sql-buttons .open-editor-btn .open-editor-btn-label {
      font-size: 10px !important;
      line-height: 1.1 !important;
    }
    .ask-oracle-sql-footer-actions button[onclick*='redirectToExplorePage'],
    .ask-oracle-sql-footer-actions button[onclick*='redirectToExplainPage'],
    .ask-oracle-sql-footer-actions .llm-conv-show-charts-btn,
    .ask-oracle-sql-footer-actions .llm-conv-show-sql-btn,
    .ask-oracle-sql-footer-actions .open-editor-btn,
    .ask-oracle-sql-footer-actions .export-pdf-response-btn,
    .ask-oracle-sql-footer-actions .export-excel-response-btn,
    .ask-oracle-response-table-actions button[onclick*='redirectToExplorePage'],
    .ask-oracle-response-table-actions button[onclick*='redirectToExplainPage'],
    .ask-oracle-response-table-actions .llm-conv-show-charts-btn,
    .ask-oracle-response-table-actions .llm-conv-show-sql-btn,
    .ask-oracle-response-table-actions .open-editor-btn,
    .ask-oracle-response-table-actions .export-pdf-response-btn,
    .ask-oracle-response-table-actions .export-excel-response-btn {
      box-sizing: border-box !important;
      display: inline-flex !important;
      align-items: center !important;
      height: 22px !important;
      min-height: 22px !important;
      min-width: 0 !important;
      padding: 1px 5px !important;
      gap: 3px !important;
      font-size: 10px !important;
      line-height: 1 !important;
    }
    .ask-oracle-sql-footer-actions button[onclick*='redirectToExplorePage'] .ask-oracle-inline-icon,
    .ask-oracle-sql-footer-actions button[onclick*='redirectToExplainPage'] .ask-oracle-inline-icon,
    .ask-oracle-sql-footer-actions .open-editor-btn .ask-oracle-inline-icon,
    .ask-oracle-response-table-actions button[onclick*='redirectToExplorePage'] .ask-oracle-inline-icon,
    .ask-oracle-response-table-actions button[onclick*='redirectToExplainPage'] .ask-oracle-inline-icon,
    .ask-oracle-response-table-actions .open-editor-btn .ask-oracle-inline-icon {
      width: 10px !important;
      height: 10px !important;
      min-width: 10px !important;
    }
    .code-editor-run-output-table-wrap table,
    .llm-sql-table-wrap table {
      border-radius: 0;
    }
    .code-editor-run-output-note {
      margin-top: 8px;
      font-size: 11px;
      color: #94a3b8;
    }
    #${CODE_EDITOR_PANEL_ID} .ace_marker-layer .code-editor-ace-error-line {
      position: absolute;
      background: rgba(244, 63, 94, 0.22);
      border-left: 2px solid rgba(244, 63, 94, 0.9);
    }
    .code-editor-ace {
      position: absolute;
      inset: 0;
      display: none;
    }
    #${CODE_EDITOR_PANEL_ID}.ace-ready .code-editor-ace {
      display: block;
    }
    .code-editor-textarea {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      border: 0;
      outline: none;
      resize: none;
      background: #0b1220;
      color: #e5e7eb;
      padding: 12px;
      font-size: 13px;
      line-height: 1.45;
      font-family: "Fira Code", Consolas, "Courier New", monospace;
      tab-size: 2;
    }
    #${CODE_EDITOR_PANEL_ID}.ace-ready .code-editor-textarea {
      display: none;
    }
    .code-editor-diff-workbench {
      display: none;
      position: absolute;
      inset: 0;
      align-items: flex-start;
      justify-content: center;
      padding: 10px 12px;
      overflow: auto;
      background: linear-gradient(180deg, rgba(15, 23, 42, 0.96), rgba(11, 18, 32, 0.98));
    }
    #${CODE_EDITOR_PANEL_ID}.diff-workbench-mode .code-editor-diff-workbench {
      display: flex;
    }
    #${CODE_EDITOR_PANEL_ID}.diff-workbench-mode .code-editor-ace,
    #${CODE_EDITOR_PANEL_ID}.diff-workbench-mode .code-editor-textarea {
      display: none !important;
    }
    .code-editor-diff-workbench-card {
      width: min(620px, 100%);
      border: 1px solid #334155;
      border-radius: 12px;
      background: #0f172a;
      box-shadow: 0 18px 36px rgba(2, 6, 23, 0.32);
      padding: 10px;
      display: grid;
      gap: 8px;
    }
    .code-editor-diff-workbench-fields {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) auto;
      gap: 10px;
      align-items: end;
    }
    .code-editor-diff-workbench-field {
      display: grid;
      gap: 6px;
      min-width: 0;
    }
    .code-editor-diff-workbench-title {
      color: #dbeafe;
      font-size: 13px;
      font-weight: 600;
    }
    .code-editor-diff-workbench-row {
      display: grid;
      gap: 6px;
    }
    .code-editor-diff-workbench-label {
      color: #cbd5e1;
      font-size: 11px;
      font-weight: 500;
    }
    .code-editor-diff-workbench-select {
      width: 100%;
      border: 1px solid #334155;
      border-radius: 8px;
      background: #0b1220;
      color: #e2e8f0;
      padding: 7px 9px;
      font-size: 12px;
      font-family: "Fira Code", Consolas, monospace;
    }
    .code-editor-diff-workbench-show {
      min-width: 92px;
    }
    .code-editor-diff-workbench-actions {
      display: inline-flex;
      gap: 8px;
      flex-wrap: wrap;
    }
    .code-editor-diff-workbench-actions button {
      border: 1px solid #1d4ed8;
      border-radius: 7px;
      background: #2563eb;
      color: #eff6ff;
      padding: 6px 12px;
      font-size: 12px;
      cursor: pointer;
    }
    .code-editor-diff-workbench-actions button:hover {
      background: #1d4ed8;
    }
    #code-editor-diff-workbench-compare {
      min-width: 88px;
      font-weight: 600;
      height: 34px;
      white-space: nowrap;
    }
    .code-editor-diff-workbench-note {
      color: #94a3b8;
      font-size: 10px;
      line-height: 1.35;
    }
    .code-editor-diff-workbench-error {
      color: #fecaca;
      font-size: 12px;
      min-height: 16px;
      line-height: 1.3;
    }
    @media (max-width: 780px) {
      .code-editor-diff-workbench-fields {
        grid-template-columns: 1fr;
      }
    }
    .code-editor-diff-wrap {
      display: none;
      flex: 1;
      min-height: 0;
      border-top: 1px solid #273449;
      background: #0b1220;
      flex-direction: column;
    }
    #${CODE_EDITOR_PANEL_ID}.diff-visible .code-editor-diff-wrap {
      display: flex;
    }
    .code-editor-diff-toolbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 10px;
      padding: 8px 10px;
      border-bottom: 1px solid #273449;
      background: #111827;
      flex-wrap: wrap;
    }
    .code-editor-diff-summary {
      color: #cbd5e1;
      font-size: 12px;
      font-family: "Fira Code", Consolas, monospace;
    }
    .code-editor-diff-tab-controls {
      display: none;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
      color: #cbd5e1;
      font-size: 11px;
    }
    #${CODE_EDITOR_PANEL_ID}.diff-tabs-mode .code-editor-diff-tab-controls {
      display: inline-flex;
    }
    #${CODE_EDITOR_PANEL_ID}.diff-workbench-mode .code-editor-diff-tab-controls {
      display: none !important;
    }
    .code-editor-diff-tab-controls label {
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    .code-editor-diff-tab-controls select {
      min-width: 140px;
      border: 1px solid #334155;
      background: #0f172a;
      color: #e2e8f0;
      border-radius: 6px;
      padding: 4px 6px;
      font-size: 12px;
    }
    .code-editor-diff-actions {
      display: inline-flex;
      gap: 8px;
      flex-wrap: wrap;
    }
    #code-editor-diff-merge-btn {
      display: none;
      background: #0f766e;
      border-color: #14b8a6;
      color: #ccfbf1;
    }
    #code-editor-diff-merge-btn:hover {
      background: #115e59;
    }
    #${CODE_EDITOR_PANEL_ID}.diff-tabs-mode #code-editor-diff-merge-btn {
      display: inline-flex;
    }
    #${CODE_EDITOR_PANEL_ID}.diff-tabs-mode #code-editor-diff-accept-btn,
    #${CODE_EDITOR_PANEL_ID}.diff-tabs-mode #code-editor-diff-keep-btn {
      display: none;
    }
    .code-editor-diff-content {
      flex: 1;
      overflow: auto;
      font-family: "Fira Code", Consolas, "Courier New", monospace;
      font-size: 12px;
      line-height: 1.45;
      color: #e5e7eb;
      background: #0b1220;
    }
    .code-diff-row {
      display: grid;
      grid-template-columns: 52px 52px 1fr;
      border-bottom: 1px solid rgba(51, 65, 85, 0.38);
      min-height: 20px;
    }
    .code-diff-old,
    .code-diff-new {
      color: #94a3b8;
      text-align: right;
      padding: 2px 8px 2px 6px;
      user-select: none;
      border-right: 1px solid rgba(51, 65, 85, 0.32);
      background: rgba(15, 23, 42, 0.55);
    }
    .code-diff-text {
      white-space: pre;
      overflow-x: auto;
      padding: 2px 10px;
    }
    .code-diff-row.add .code-diff-text {
      background: rgba(22, 101, 52, 0.2);
      color: #bbf7d0;
    }
    .code-diff-row.del .code-diff-text {
      background: rgba(127, 29, 29, 0.2);
      color: #fecaca;
    }
    .code-diff-row.ctx .code-diff-text {
      background: transparent;
      color: #e5e7eb;
    }
  `;
  document.head.appendChild(style);
}

function getCodeEditorPanelMaxWidthPx() {
  const vw = window.innerWidth || document.documentElement.clientWidth || 1440;
  return Math.max(
    CODE_EDITOR_PANEL_MIN_WIDTH_PX,
    Math.min(CODE_EDITOR_PANEL_MAX_WIDTH_PX, Math.round(vw * CODE_EDITOR_PANEL_MAX_WIDTH_RATIO))
  );
}

function getCodeEditorPanelWidthPx(preferredWidthPx) {
  const vw = window.innerWidth || document.documentElement.clientWidth || 1440;
  const maxWidth = getCodeEditorPanelMaxWidthPx();
  const minWidth = Math.min(
    CODE_EDITOR_PANEL_MIN_WIDTH_PX,
    Math.max(320, maxWidth - 120)
  );
  const defaultWidth = Math.round(vw * CODE_EDITOR_PANEL_DEFAULT_WIDTH_RATIO);
  const preferred = Number(preferredWidthPx);
  const requestedWidth = Number.isFinite(preferred) ? Math.round(preferred) : defaultWidth;
  return Math.max(minWidth, Math.min(maxWidth, requestedWidth));
}

function getCodeEditorLayoutOffsetPx() {
  if (!document.body.classList.contains("code-editor-mode")) return 0;
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  if (!panel) return 0;
  const panelWidth = Math.round(panel.getBoundingClientRect().width || 0);
  if (panelWidth <= 0) return 0;
  return panelWidth + CODE_EDITOR_PANEL_GAP_PX;
}

function syncCodeEditorLayout() {
  const root = document.documentElement;
  const width = getCodeEditorPanelWidthPx(codeEditorPanelWidthPx);
  codeEditorPanelWidthPx = width;
  root.style.setProperty("--code-editor-panel-width", `${width}px`);
  positionCenterPromptBar();
  positionFooterPromptBar();
  scheduleFooterScrollDownRefresh();
  if (codeEditorAceInstance && typeof codeEditorAceInstance.resize === "function") {
    requestAnimationFrame(() => codeEditorAceInstance.resize());
  }
}

function resetCodeEditorPanelWidthForOpen() {
  codeEditorPanelWidthPx = getCodeEditorPanelWidthPx();
  document.documentElement.style.setProperty("--code-editor-panel-width", `${codeEditorPanelWidthPx}px`);
}

function getLeftNavigationToggleButton() {
  const selectors = [
    "#t_Button_navControl",
    "#t_Button_sidebarControl",
    "[data-action='nav-toggle']",
    ".t-Button--headerTree"
  ];
  let fallback = null;

  for (const selector of selectors) {
    const matches = Array.from(document.querySelectorAll(selector));
    if (!matches.length) continue;
    if (!fallback) fallback = matches[0];

    const visible = matches.find((el) => {
      const style = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
    });
    if (visible) return visible;
  }

  return fallback;
}

function isLeftNavigationToggleExpanded(btn) {
  const toggleBtn = btn || getLeftNavigationToggleButton();
  if (!toggleBtn) return null;
  const value = String(toggleBtn.getAttribute("aria-expanded") || "").toLowerCase();
  if (value === "true") return true;
  if (value === "false") return false;
  return null;
}

function getLeftNavPreferenceStorageKeys() {
  const keys = new Set();
  const appIds = new Set();

  try {
    if (window.apex && apex.env && apex.env.APP_ID) {
      appIds.add(String(apex.env.APP_ID));
    }
  } catch (e) {}
  try {
    if (typeof window.$v === "function") {
      const flowId = window.$v("pFlowId");
      if (flowId) appIds.add(String(flowId));
    }
  } catch (e) {}

  appIds.forEach((appId) => {
    keys.add(`ORA_WWV_apex.toggleCore.nav.${appId}.preferenceForExpanded`);
  });

  try {
    for (let i = 0; i < sessionStorage.length; i++) {
      const key = sessionStorage.key(i);
      if (!key) continue;
      if (/^ORA_WWV_apex\.toggleCore\.nav\..*\.preferenceForExpanded$/i.test(key)) {
        keys.add(key);
      }
    }
  } catch (e) {}

  return Array.from(keys);
}

function setLeftNavExpandedPreference(expanded) {
  const value = expanded ? "true" : "false";
  const keys = getLeftNavPreferenceStorageKeys();
  keys.forEach((key) => {
    try { sessionStorage.setItem(key, value); } catch (e) {}
  });
}

function triggerNavResponsiveReflow() {
  const fireResize = () => {
    try { window.dispatchEvent(new Event("resize")); } catch (e) {}
    try {
      if (window.apex && apex.jQuery) {
        apex.jQuery(window).trigger("apexwindowresized");
      }
    } catch (e) {}
  };

  fireResize();
  setTimeout(fireResize, 40);
  setTimeout(fireResize, 180);
}

function collapseLeftNavViaApexThemeApi() {
  const toggleWidgets = window.apex && apex.theme42 && apex.theme42.toggleWidgets;
  if (!toggleWidgets) return false;

  try {
    if (typeof toggleWidgets.collapseWidget === "function") {
      toggleWidgets.collapseWidget("nav");
      return true;
    }
  } catch (e) {}

  return false;
}

function expandLeftNavViaApexThemeApi() {
  const toggleWidgets = window.apex && apex.theme42 && apex.theme42.toggleWidgets;
  if (!toggleWidgets) return false;

  try {
    if (typeof toggleWidgets.expandWidget === "function") {
      toggleWidgets.expandWidget("nav");
      return true;
    }
  } catch (e) {}

  return false;
}

function getLeftNavigationClassTargets() {
  const targets = [];
  const pageBody = document.getElementById("t_PageBody");
  if (pageBody) targets.push(pageBody);
  if (document.body && document.body !== pageBody) targets.push(document.body);
  return targets;
}

function setLeftNavigationCollapsedState(collapsed) {
  const classTargets = getLeftNavigationClassTargets();
  classTargets.forEach((el) => {
    if (!el || !el.classList) return;
    el.classList.toggle("js-navCollapsed", collapsed);
    el.classList.toggle("t-PageBody--hideLeft", collapsed);
    if (collapsed) {
      el.classList.remove("js-navExpanded");
    }
  });

  const navEl = document.querySelector("#t_Body_nav, .t-Body-nav");
  if (navEl) {
    navEl.setAttribute("aria-hidden", collapsed ? "true" : "false");
  }

  const toggleBtn = getLeftNavigationToggleButton();
  if (toggleBtn) {
    toggleBtn.setAttribute("aria-expanded", collapsed ? "false" : "true");
  }
}

function isLeftNavigationCollapsedNow() {
  const navEl = document.querySelector("#t_Body_nav, .t-Body-nav");
  const navWidth = navEl ? Math.round(navEl.getBoundingClientRect().width || 0) : 0;
  const classText = getLeftNavigationClassTargets()
    .map((el) => el.className || "")
    .join(" ");
  const navAriaHidden = navEl ? navEl.getAttribute("aria-hidden") === "true" : false;
  return (
    /js-navCollapsed|t-PageBody--hideLeft|navCollapsed|is-collapsed|js-navCollapsed--hidden/i.test(classText) ||
    navAriaHidden ||
    (!!navEl && navWidth <= 64)
  );
}

function getApexTreeNavHandle() {
  const jq =
    (window.apex && apex.jQuery && apex.jQuery.fn && apex.jQuery.fn.treeView && apex.jQuery) ||
    (window.jQuery && window.jQuery.fn && window.jQuery.fn.treeView && window.jQuery);
  if (!jq) return null;
  const tree = jq("#t_TreeNav");
  return tree && tree.length ? tree : null;
}

function normalizeAskOracleHistoryNavLabel(rawValue) {
  const text = normalizeAskOracleHistoryNavFullLabel(rawValue);
  if (!text) return "";
  if (text.length <= 110) return text;
  return `${text.slice(0, 107).trim()}...`;
}

function normalizeAskOracleHistoryNavFullLabel(rawValue) {
  const text = String(rawValue || "").replace(/\s+/g, " ").trim();
  if (!text) return "";
  const lowered = text.toLowerCase();
  if (lowered === "undefined" || lowered === "null" || lowered === "n/a" || lowered === "na") return "";
  return text;
}

function getAskOracleHistoryNavPreferenceKey() {
  let appId = "";
  try {
    if (window.apex && apex.env && apex.env.APP_ID) appId = String(apex.env.APP_ID || "").trim();
  } catch (e) {}
  if (!appId) {
    try {
      if (typeof window.$v === "function") appId = String(window.$v("pFlowId") || "").trim();
    } catch (e2) {}
  }
  return `ASK_ORACLE_HISTORY_NAV_EXPANDED.${appId || "default"}`;
}

function readAskOracleHistoryNavExpandedPreference() {
  const key = getAskOracleHistoryNavPreferenceKey();
  let raw = "";
  try { raw = String(sessionStorage.getItem(key) || ""); } catch (e) {}
  if (!raw) {
    try { raw = String(localStorage.getItem(key) || ""); } catch (e2) {}
  }
  raw = raw.trim().toLowerCase();
  if (raw === "false" || raw === "0" || raw === "n") return false;
  if (raw === "true" || raw === "1" || raw === "y") return true;
  return true;
}

function writeAskOracleHistoryNavExpandedPreference(expanded) {
  const value = expanded ? "true" : "false";
  const key = getAskOracleHistoryNavPreferenceKey();
  try { sessionStorage.setItem(key, value); } catch (e) {}
  try { localStorage.setItem(key, value); } catch (e2) {}
}

function ensureAskOracleHistoryHoverTooltip() {
  let tooltip = document.getElementById("ask-oracle-history-hover-tooltip");
  if (tooltip) return tooltip;
  tooltip = document.createElement("div");
  tooltip.id = "ask-oracle-history-hover-tooltip";
  tooltip.style.position = "fixed";
  tooltip.style.zIndex = "10020";
  tooltip.style.maxWidth = "min(520px, calc(100vw - 64px))";
  tooltip.style.padding = "7px 10px";
  tooltip.style.borderRadius = "8px";
  tooltip.style.background = "rgba(15, 23, 42, 0.96)";
  tooltip.style.color = "#f8fafc";
  tooltip.style.fontSize = "12px";
  tooltip.style.lineHeight = "1.45";
  tooltip.style.boxShadow = "0 14px 28px rgba(15, 23, 42, 0.24)";
  tooltip.style.pointerEvents = "none";
  tooltip.style.opacity = "0";
  tooltip.style.visibility = "hidden";
  tooltip.style.transform = "translateY(2px)";
  tooltip.style.transition = "opacity 0.08s ease, transform 0.08s ease, visibility 0.08s ease";
  document.body.appendChild(tooltip);
  return tooltip;
}

function hideAskOracleHistoryHoverTooltip() {
  const tooltip = document.getElementById("ask-oracle-history-hover-tooltip");
  if (!tooltip) return;
  tooltip.style.opacity = "0";
  tooltip.style.visibility = "hidden";
  tooltip.style.transform = "translateY(2px)";
}

function positionAskOracleHistoryHoverTooltip(labelNode, tooltip) {
  if (!labelNode || !tooltip) return;
  const rect = labelNode.getBoundingClientRect();
  const margin = 8;
  const width = Math.min(520, Math.max(220, tooltip.offsetWidth || 220));
  let left = rect.left;
  if (left + width > window.innerWidth - 16) {
    left = Math.max(16, window.innerWidth - width - 16);
  }
  let top = rect.bottom + margin;
  const tooltipHeight = tooltip.offsetHeight || 0;
  if (top + tooltipHeight > window.innerHeight - 16) {
    top = Math.max(16, rect.top - tooltipHeight - margin);
  }
  tooltip.style.left = `${Math.round(left)}px`;
  tooltip.style.top = `${Math.round(top)}px`;
}

function showAskOracleHistoryHoverTooltip(labelNode) {
  if (!labelNode || !labelNode.classList || !labelNode.classList.contains("ask-oracle-history-label-truncated")) {
    return;
  }
  const fullLabel = String(labelNode.getAttribute("data-full-label") || "").trim();
  if (!fullLabel) return;
  const tooltip = ensureAskOracleHistoryHoverTooltip();
  const isDarkUi = !!document.body.classList.contains("ask-oracle-dark-ui");
  tooltip.textContent = fullLabel;
  tooltip.style.background = isDarkUi ? "rgba(2, 6, 23, 0.98)" : "rgba(15, 23, 42, 0.96)";
  tooltip.style.color = isDarkUi ? "#e2e8f0" : "#f8fafc";
  tooltip.style.boxShadow = isDarkUi
    ? "0 16px 34px rgba(2, 6, 23, 0.42)"
    : "0 14px 28px rgba(15, 23, 42, 0.24)";
  tooltip.style.visibility = "hidden";
  tooltip.style.opacity = "0";
  tooltip.style.display = "block";
  positionAskOracleHistoryHoverTooltip(labelNode, tooltip);
  tooltip.style.visibility = "visible";
  tooltip.style.opacity = "1";
  tooltip.style.transform = "translateY(0)";
}

function bindAskOracleHistoryQuickTooltip(labelNode) {
  if (!labelNode || labelNode.dataset.askOracleHistoryTooltipBound === "true") return;
  labelNode.dataset.askOracleHistoryTooltipBound = "true";
  labelNode.addEventListener("mouseenter", function() {
    showAskOracleHistoryHoverTooltip(labelNode);
  });
  labelNode.addEventListener("mouseleave", hideAskOracleHistoryHoverTooltip);
  labelNode.addEventListener("focus", function() {
    showAskOracleHistoryHoverTooltip(labelNode);
  }, true);
  labelNode.addEventListener("blur", hideAskOracleHistoryHoverTooltip, true);
}

function syncAskOracleHistoryLabelNode(labelNode, fullText) {
  if (!labelNode) return;
  const fullLabel = normalizeAskOracleHistoryNavFullLabel(
    fullText != null ? fullText : (labelNode.getAttribute("data-full-label") || labelNode.textContent || "")
  );
  const displayLabel = normalizeAskOracleHistoryNavLabel(fullLabel);
  if (displayLabel) {
    labelNode.textContent = displayLabel;
  }
  if (fullLabel) {
    labelNode.setAttribute("aria-label", fullLabel);
    labelNode.setAttribute("data-full-label", fullLabel);
    labelNode.classList.toggle("ask-oracle-history-label-truncated", fullLabel !== displayLabel);
    labelNode.setAttribute("title", fullLabel);
  } else if (displayLabel) {
    labelNode.setAttribute("aria-label", displayLabel);
    labelNode.classList.remove("ask-oracle-history-label-truncated");
    labelNode.setAttribute("title", displayLabel);
  }
  bindAskOracleHistoryQuickTooltip(labelNode);
}

function setAskOracleHistoryNavExpandedState(subtree, expanded) {
  const group = subtree || getAskOracleHistoryNavSubtree();
  if (!group) return;
  const historyLi = group.closest("li");
  if (!historyLi) return;
  const isExpanded = expanded !== false;

  try {
    historyLi.classList.toggle("is-expanded", isExpanded);
    historyLi.classList.toggle("a-TreeView-node--expanded", isExpanded);
    historyLi.classList.toggle("is-collapsed", !isExpanded);
    historyLi.classList.toggle("a-TreeView-node--collapsed", !isExpanded);
  } catch (e) {}

  const label = historyLi.querySelector(".a-TreeView-label");
  if (label) {
    label.setAttribute("aria-expanded", isExpanded ? "true" : "false");
  }
  const toggle = historyLi.querySelector(".a-TreeView-toggle");
  if (toggle) {
    toggle.setAttribute("aria-expanded", isExpanded ? "true" : "false");
  }
  group.hidden = !isExpanded;
  group.style.display = isExpanded ? "" : "none";
}

function toggleAskOracleHistoryNavExpanded(subtree, explicitExpanded) {
  const nextExpanded = typeof explicitExpanded === "boolean"
    ? explicitExpanded
    : !readAskOracleHistoryNavExpandedPreference();
  writeAskOracleHistoryNavExpandedPreference(nextExpanded);
  setAskOracleHistoryNavExpandedState(subtree, nextExpanded);
}

function bindAskOracleHistoryNavToggle(subtree) {
  const group = subtree || getAskOracleHistoryNavSubtree();
  if (!group) return;
  const historyLi = group.closest("li");
  if (!historyLi) return;
  if (historyLi.dataset.askOracleHistoryToggleBound === "true") return;
  historyLi.dataset.askOracleHistoryToggleBound = "true";

  const label = historyLi.querySelector(".a-TreeView-label");
  const toggle = historyLi.querySelector(".a-TreeView-toggle");
  const handler = function(event) {
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
    if (event && typeof event.stopPropagation === "function") event.stopPropagation();
    toggleAskOracleHistoryNavExpanded(group);
  };

  if (label) {
    label.addEventListener("click", handler, true);
    label.addEventListener("keydown", function(event) {
      if (!(event && (event.key === "Enter" || event.key === " "))) return;
      handler(event);
    }, true);
  }
  if (toggle) {
    toggle.style.cursor = "pointer";
    toggle.addEventListener("click", handler, true);
  }
}

function ensureAskOracleHistoryNewEntryCss() {
  if (document.getElementById(ASK_ORACLE_HISTORY_NEW_ENTRY_CSS_ID)) return;
  const style = document.createElement("style");
  style.id = ASK_ORACLE_HISTORY_NEW_ENTRY_CSS_ID;
  style.textContent = `
    @keyframes askOracleHistoryEntryFlash {
      0% { background: #fef3c7; box-shadow: inset 0 0 0 1px #f59e0b; }
      100% { background: transparent; box-shadow: none; }
    }
    #t_TreeNav li.${ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS} > .a-TreeView-content,
    #t_TreeNav .a-TreeView-content.${ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS},
    #t_TreeNav .a-TreeView-label.${ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS} {
      animation: askOracleHistoryEntryFlash 2.2s ease-out 1;
      border-radius: 8px;
    }
    body.ask-oracle-dark-ui #t_TreeNav li.${ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS} > .a-TreeView-content,
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-content.${ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS},
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-label.${ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS} {
      animation: none;
      background: rgba(245, 158, 11, 0.22) !important;
      box-shadow: inset 0 0 0 1px rgba(245, 158, 11, 0.55);
      border-radius: 8px;
    }
  `;
  document.head.appendChild(style);
}

function ensureAskOracleHistoryDeleteActionCss() {
  if (document.getElementById(ASK_ORACLE_HISTORY_DELETE_ACTION_CSS_ID)) return;
  const style = document.createElement("style");
  style.id = ASK_ORACLE_HISTORY_DELETE_ACTION_CSS_ID;
  style.textContent = `
    #t_TreeNav .a-TreeView-content {
      position: relative;
    }
    #t_TreeNav .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS},
    #t_TreeNav .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS} {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      width: 22px;
      height: 22px;
      border: 0;
      border-radius: 6px;
      background: transparent;
      color: #6b7280;
      opacity: 0;
      pointer-events: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      line-height: 1;
      font-size: 14px;
    }
    #t_TreeNav .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS} {
      right: 30px;
    }
    #t_TreeNav .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS} {
      right: 6px;
    }
    #t_TreeNav .a-TreeView-content:hover > .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS},
    #t_TreeNav .a-TreeView-content:hover > .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS},
    #t_TreeNav li.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .a-TreeView-row > .a-TreeView-content > .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS},
    #t_TreeNav li.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .a-TreeView-row > .a-TreeView-content > .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS},
    #t_TreeNav .a-TreeView-content.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS},
    #t_TreeNav .a-TreeView-content.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS} {
      opacity: 1;
      pointer-events: auto;
    }
    #t_TreeNav .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}.is-pinned {
      opacity: 1;
      pointer-events: auto;
      color: #2563eb;
    }
    #t_TreeNav .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}.is-pinned:hover {
      background: rgba(37, 99, 235, 0.16);
      color: #1d4ed8;
    }
    #t_TreeNav .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}:hover,
    #t_TreeNav .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS}:hover {
      background: rgba(15, 23, 42, 0.08);
      color: #111827;
    }
    body.ask-oracle-dark-ui #t_TreeNav .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS},
    body.ask-oracle-dark-ui #t_TreeNav .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS} {
      color: #93c5fd;
    }
    body.ask-oracle-dark-ui #t_TreeNav .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}:hover,
    body.ask-oracle-dark-ui #t_TreeNav .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS}:hover {
      background: rgba(59, 130, 246, 0.2);
      color: #dbeafe;
    }
    body.ask-oracle-dark-ui #t_TreeNav .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}.is-pinned {
      color: #bfdbfe;
    }
    #t_TreeNav .a-TreeView-content > .a-TreeView-label {
      padding-right: 54px;
      position: relative;
    }
    #t_TreeNav .a-TreeView-label.ask-oracle-history-label-truncated::after {
      content: attr(data-full-label);
      position: absolute;
      left: 0;
      top: calc(100% + 6px);
      z-index: 10020;
      min-width: max-content;
      max-width: min(520px, calc(100vw - 64px));
      padding: 7px 10px;
      border-radius: 8px;
      background: rgba(15, 23, 42, 0.96);
      color: #f8fafc;
      font-size: 12px;
      line-height: 1.45;
      white-space: normal;
      box-shadow: 0 14px 28px rgba(15, 23, 42, 0.24);
      opacity: 0;
      visibility: hidden;
      transform: translateY(2px);
      pointer-events: none;
      transition: opacity 0.08s ease, transform 0.08s ease, visibility 0.08s ease;
    }
    #t_TreeNav .a-TreeView-label.ask-oracle-history-label-truncated:hover::after,
    #t_TreeNav .a-TreeView-label.ask-oracle-history-label-truncated:focus-visible::after {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-label.ask-oracle-history-label-truncated::after {
      background: rgba(2, 6, 23, 0.98);
      color: #e2e8f0;
      box-shadow: 0 16px 34px rgba(2, 6, 23, 0.42);
    }
    #t_TreeNav .a-TreeView-content.ask-oracle-title-editing > .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS},
    #t_TreeNav .a-TreeView-content.ask-oracle-title-editing > .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS} {
      opacity: 0 !important;
      pointer-events: none !important;
    }
    #t_TreeNav .${ASK_ORACLE_HISTORY_EDIT_BTN_CLASS},
    #t_TreeNav .${ASK_ORACLE_HISTORY_DELETE_BTN_CLASS} {
      display: none !important;
    }
    #t_TreeNav .a-TreeView-content.ask-oracle-title-editing {
      padding-right: 2px !important;
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
      min-width: 0 !important;
    }
    #t_TreeNav .a-TreeView-content.ask-oracle-title-editing > .a-TreeView-label {
      display: none !important;
    }
    #t_TreeNav .ask-oracle-history-inline-title-input {
      display: block;
      flex: 1 1 auto;
      width: auto;
      min-width: 260px;
      max-width: none;
      height: 32px;
      margin-right: 30px;
      padding: 5px 10px 5px 12px;
      border: 1px solid #93c5fd;
      border-radius: 6px;
      background: #ffffff;
      color: #111827 !important;
      -webkit-text-fill-color: #111827;
      caret-color: #111827;
      opacity: 1 !important;
      box-sizing: border-box;
      font-size: 13px;
      line-height: 1.25;
      font-weight: 500;
      outline: none;
      box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.18);
      position: relative;
      z-index: 2;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    #t_TreeNav .ask-oracle-history-inline-title-save {
      position: absolute;
      right: 6px;
      top: 50%;
      transform: translateY(-50%);
      width: 24px;
      height: 24px;
      border: 0;
      border-radius: 6px;
      background: rgba(34, 197, 94, 0.14);
      color: #15803d;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 13px;
      line-height: 1;
      z-index: 3;
    }
    #t_TreeNav .ask-oracle-history-inline-title-save:hover {
      background: rgba(34, 197, 94, 0.24);
      color: #166534;
    }
    body.ask-oracle-dark-ui #t_TreeNav .ask-oracle-history-inline-title-input {
      border-color: #60a5fa;
      background: #0f172a;
      color: #e2e8f0 !important;
      -webkit-text-fill-color: #e2e8f0;
      caret-color: #e2e8f0;
      box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.28);
    }
    body.ask-oracle-dark-ui #t_TreeNav .ask-oracle-history-inline-title-save {
      background: rgba(74, 222, 128, 0.2);
      color: #86efac;
    }
    .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} {
      position: fixed;
      min-width: 180px;
      background: #ffffff;
      border: 1px solid #dbe3ee;
      border-radius: 10px;
      box-shadow: 0 16px 38px rgba(15, 23, 42, 0.18);
      padding: 6px;
      z-index: 10065;
      display: grid;
      gap: 2px;
    }
    .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} button {
      width: 100%;
      border: 0;
      border-radius: 8px;
      background: transparent;
      color: #0f172a;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 9px 10px;
      font-size: 13px;
      line-height: 1.2;
      cursor: pointer;
      text-align: left;
    }
    .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} button:hover {
      background: #f8fafc;
    }
    .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} button.danger {
      color: #b91c1c;
    }
    .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} button.danger:hover {
      background: #fef2f2;
    }
    .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} .menu-icon {
      width: 16px;
      text-align: center;
      color: inherit;
    }
    body.ask-oracle-dark-ui .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} {
      background: #0f172a;
      border-color: #334155;
      box-shadow: 0 18px 42px rgba(2, 6, 23, 0.42);
    }
    body.ask-oracle-dark-ui .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} button {
      color: #e2e8f0;
    }
    body.ask-oracle-dark-ui .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} button:hover {
      background: rgba(51, 65, 85, 0.68);
    }
    body.ask-oracle-dark-ui .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} button.danger {
      color: #fecaca;
    }
    body.ask-oracle-dark-ui .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS} button.danger:hover {
      background: rgba(127, 29, 29, 0.45);
    }
  `;
  document.head.appendChild(style);
}

function closeAskOracleHistoryActionMenu() {
  if (!askOracleActiveHistoryActionMenu) return false;
  const activeMenu = askOracleActiveHistoryActionMenu;
  askOracleActiveHistoryActionMenu = null;

  try {
    if (activeMenu.button) {
      activeMenu.button.setAttribute("aria-expanded", "false");
      activeMenu.button.removeAttribute("aria-controls");
    }
    if (activeMenu.cleanup && Array.isArray(activeMenu.cleanup)) {
      activeMenu.cleanup.forEach((fn) => {
        try { if (typeof fn === "function") fn(); } catch (e) {}
      });
    }
    if (activeMenu.menu && activeMenu.menu.parentElement) {
      activeMenu.menu.remove();
    }
  } catch (e) {}

  return true;
}

function positionAskOracleHistoryActionMenu(menuEl, triggerEl) {
  if (!menuEl || !triggerEl) return;
  const rect = triggerEl.getBoundingClientRect();
  const menuRect = menuEl.getBoundingClientRect();
  const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
  const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;

  let left = rect.right - Math.max(menuRect.width, 180);
  let top = rect.bottom + 6;

  if ((left + menuRect.width) > (viewportWidth - 8)) {
    left = Math.max(8, viewportWidth - menuRect.width - 8);
  }
  if (left < 8) left = 8;

  if ((top + menuRect.height) > (viewportHeight - 8)) {
    top = rect.top - menuRect.height - 6;
  }
  if (top < 8) top = 8;

  menuEl.style.left = `${Math.round(left)}px`;
  menuEl.style.top = `${Math.round(top)}px`;
}

function openAskOracleHistoryActionMenu(conversationId, triggerNode) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;

  ensureAskOracleHistoryDeleteActionCss();

  const button = triggerNode && typeof triggerNode.closest === "function"
    ? (triggerNode.closest(`.${ASK_ORACLE_HISTORY_MORE_BTN_CLASS}`) || triggerNode)
    : triggerNode;
  const contentNode = button && typeof button.closest === "function"
    ? (button.closest(".a-TreeView-content") || button)
    : button;
  if (!button || !contentNode) return;

  if (
    askOracleActiveHistoryActionMenu &&
    askOracleActiveHistoryActionMenu.button === button &&
    String(askOracleActiveHistoryActionMenu.conversationId || "") === targetConversationId
  ) {
    closeAskOracleHistoryActionMenu();
    return;
  }

  closeAskOracleHistoryActionMenu();

  const menu = document.createElement("div");
  const menuId = `ask-oracle-history-action-menu-${Date.now()}`;
  menu.id = menuId;
  menu.className = ASK_ORACLE_HISTORY_ACTION_MENU_CLASS;
  menu.setAttribute("role", "menu");
  menu.innerHTML = `
    <button type="button" data-action="rename" role="menuitem">
      <span>Rename</span>
      <span class="menu-icon fa fa-edit" aria-hidden="true"></span>
    </button>
    <button type="button" data-action="pdf" role="menuitem">
      <span>Save as PDF</span>
      <span class="menu-icon fa fa-file-pdf" aria-hidden="true"></span>
    </button>
    <button type="button" class="danger" data-action="delete" role="menuitem">
      <span>Delete</span>
      <span class="menu-icon fa fa-trash" aria-hidden="true"></span>
    </button>
  `;
  document.body.appendChild(menu);

  function closeMenu() {
    closeAskOracleHistoryActionMenu();
  }

  const renameBtn = menu.querySelector('[data-action="rename"]');
  const pdfBtn = menu.querySelector('[data-action="pdf"]');
  const deleteBtn = menu.querySelector('[data-action="delete"]');

  if (renameBtn) {
    renameBtn.addEventListener("click", function(event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }
      closeMenu();
      editAskOracleConversationTitle(targetConversationId, contentNode);
    });
  }
  if (pdfBtn) {
    pdfBtn.addEventListener("click", function(event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }
      closeMenu();
      exportConversationHistoryThreadToPdf(targetConversationId, contentNode);
    });
  }
  if (deleteBtn) {
    deleteBtn.addEventListener("click", function(event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }
      closeMenu();
      deleteAskOracleConversation(targetConversationId, contentNode);
    });
  }

  const outsideHandler = function(event) {
    const target = event && event.target;
    if (!target) return;
    if (menu.contains(target)) return;
    if (button.contains && button.contains(target)) return;
    closeMenu();
  };
  const keyHandler = function(event) {
    if (!event) return;
    if (event.key === "Escape") {
      event.preventDefault();
      closeMenu();
    }
  };
  const resizeHandler = function() {
    positionAskOracleHistoryActionMenu(menu, button);
  };
  const scrollHandler = function() {
    closeMenu();
  };

  document.addEventListener("mousedown", outsideHandler, true);
  document.addEventListener("keydown", keyHandler, true);
  window.addEventListener("resize", resizeHandler, { passive: true });
  document.addEventListener("scroll", scrollHandler, true);

  askOracleActiveHistoryActionMenu = {
    conversationId: targetConversationId,
    button: button,
    contentNode: contentNode,
    menu: menu,
    cleanup: [
      function() { document.removeEventListener("mousedown", outsideHandler, true); },
      function() { document.removeEventListener("keydown", keyHandler, true); },
      function() { window.removeEventListener("resize", resizeHandler, { passive: true }); },
      function() { document.removeEventListener("scroll", scrollHandler, true); }
    ]
  };

  button.setAttribute("aria-expanded", "true");
  button.setAttribute("aria-controls", menuId);
  positionAskOracleHistoryActionMenu(menu, button);

  const firstBtn = menu.querySelector("button");
  try { if (firstBtn) firstBtn.focus({ preventScroll: true }); } catch (e) {}
}

function buildAskOracleHistoryNavLabel(conversationData, conversationId) {
  const descriptionText = getAskOracleHistoryDescriptionText(conversationData);
  if (descriptionText) return descriptionText;
  const shortId = String(conversationId || "").trim().slice(0, 12);
  return shortId ? `Conversation ${shortId}` : "Conversation";
}

function getAskOracleHistoryDescriptionText(conversationData) {
  const source = conversationData && typeof conversationData === "object" ? conversationData : {};
  const candidates = [
    source.summary,
    source.conversation_title,
    source.conversationTitle,
    source.conversation_desc,
    source.conversation_description,
    source.description
  ];
  for (const candidate of candidates) {
    const label = normalizeAskOracleHistoryNavFullLabel(candidate);
    if (label) return label;
  }
  return "";
}

function getAskOracleHistoryFallbackText(conversationData) {
  const source = conversationData && typeof conversationData === "object" ? conversationData : {};
  const candidates = [
    source.prompt,
    source.prompt_text,
    source.user_prompt,
    source.latest_prompt,
    source.question
  ];
  for (const candidate of candidates) {
    const label = normalizeAskOracleHistoryNavFullLabel(candidate);
    if (!label) continue;
    if (String(label).toLowerCase() === "new conversation") continue;
    return label;
  }
  return "";
}

function isAskOracleHistoryPlaceholderLabel(label, conversationId) {
  const text = normalizeAskOracleHistoryNavLabel(label).toLowerCase();
  if (!text) return true;
  if (text === "new conversation") return true;

  const convId = String(conversationId || "").trim().toLowerCase();
  if (convId && text === convId) return true;

  if (text === "conversation") return true;
  if (/^conversation\s+[a-z0-9_-]{6,}$/i.test(text)) return true;
  return false;
}

function getAskOracleExistingHistoryNavSubtree() {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return null;

  const topLevelNodes = Array.from(treeRoot.querySelectorAll("li.a-TreeView-node--topLevel"));
  for (const topLevelNode of topLevelNodes) {
    const contentEl = topLevelNode.querySelector(".a-TreeView-content");
    if (!contentEl) continue;
    const labelEl = contentEl.querySelector(".a-TreeView-label");
    const labelText = String((labelEl && labelEl.textContent) || "").trim().toLowerCase();
    const hasHistoryIcon = !!contentEl.querySelector(".fa-history");
    const looksLikeHistory = hasHistoryIcon || labelText === "history" || labelText === "recents" || labelText.indexOf("history") >= 0;
    if (!looksLikeHistory) continue;
    const subtree = Array.from(topLevelNode.children || []).find((child) => {
      return !!(child && child.matches && child.matches("ul[role='group']"));
    }) || null;
    if (subtree) return subtree;
  }

  const historyLabel = Array.from(treeRoot.querySelectorAll(".a-TreeView-label")).find((node) => {
    const text = String((node && node.textContent) || "").trim().toLowerCase();
    return text === "history" || text === "recents";
  });
  if (!historyLabel) return null;

  const ownsId = String(historyLabel.getAttribute("aria-owns") || "").trim();
  if (ownsId) {
    const ownsSubtree = document.getElementById(ownsId);
    if (ownsSubtree && ownsSubtree.matches && ownsSubtree.matches("ul[role='group']")) return ownsSubtree;
  }
  const historyLi = historyLabel.closest("li");
  if (!historyLi) return null;
  return historyLi.querySelector("ul[role='group']");
}

function getAskOracleHistoryNavSubtree() {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return null;

  const treeList = treeRoot.matches("ul")
    ? treeRoot
    : (treeRoot.querySelector("ul[role='tree']") || treeRoot.querySelector("ul"));
  if (!treeList) return null;

  const topLevelNodes = Array.from(treeRoot.querySelectorAll("li.a-TreeView-node--topLevel"));
  const historyCandidates = topLevelNodes.map((topLevelNode) => {
    const contentEl = topLevelNode.querySelector(".a-TreeView-content");
    if (!contentEl) return null;
    const labelEl = contentEl.querySelector(".a-TreeView-label");
    const labelText = String((labelEl && labelEl.textContent) || "").trim();
    const lowered = labelText.toLowerCase();
    const hasHistoryIcon = !!contentEl.querySelector(".fa-history");
    const looksLikeHistory = hasHistoryIcon || lowered === "history" || lowered === "recents" || lowered.indexOf("history") >= 0;
    if (!looksLikeHistory) return null;
    const subtree = Array.from(topLevelNode.children || []).find((child) => {
      return !!(child && child.matches && child.matches("ul[role='group']"));
    }) || null;
    return { topLevelNode, contentEl, labelEl, labelText, subtree };
  }).filter(Boolean);

  if (historyCandidates.length > 0) {
    const exactHistoryLabel = historyCandidates.find((candidate) => {
      return normalizeAskOracleHistoryNavLabel(candidate.labelText || "").toLowerCase() === "history";
    });
    const primary = exactHistoryLabel || historyCandidates[0];
    let primarySubtree = primary.subtree;
    if (!primarySubtree) {
      const generatedId = String(
        (primary.labelEl && primary.labelEl.getAttribute("aria-owns")) || `ask-oracle-history-subtree-${Date.now()}`
      ).trim();
    if (primary.labelEl) {
        primary.labelEl.setAttribute("aria-expanded", readAskOracleHistoryNavExpandedPreference() ? "true" : "false");
        primary.labelEl.setAttribute("aria-owns", generatedId);
      }
      primarySubtree = document.createElement("ul");
      primarySubtree.id = generatedId;
      primarySubtree.className = "a-TreeView-nodeList";
      primarySubtree.setAttribute("role", "group");
      primary.topLevelNode.appendChild(primarySubtree);
    }
    if (primary.labelEl) {
      primary.labelEl.textContent = ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL;
      primary.labelEl.setAttribute("aria-label", ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL);
      primary.labelEl.classList.remove("ask-oracle-history-label-truncated");
    }

    historyCandidates.forEach((candidate) => {
      if (!candidate || candidate.topLevelNode === primary.topLevelNode) return;
      const candidateSubtree = candidate.subtree || Array.from(candidate.topLevelNode.children || []).find((child) => {
        return !!(child && child.matches && child.matches("ul[role='group']"));
      });
      if (candidateSubtree) {
        Array.from(candidateSubtree.children || []).forEach((child) => {
          primarySubtree.appendChild(child);
        });
      }
      try { candidate.topLevelNode.remove(); } catch (e) {}
    });
    bindAskOracleHistoryNavToggle(primarySubtree);
    setAskOracleHistoryNavExpandedState(primarySubtree, readAskOracleHistoryNavExpandedPreference());
    return primarySubtree;
  }

  const historyLabel = Array.from(treeRoot.querySelectorAll(".a-TreeView-label")).find((node) => {
    const text = String((node && node.textContent) || "").trim().toLowerCase();
    return text === "history" || text === "recents";
  });
  if (historyLabel) {
    const ownsId = String(historyLabel.getAttribute("aria-owns") || "").trim();
    if (ownsId) {
      const ownsSubtree = document.getElementById(ownsId);
      if (ownsSubtree) return ownsSubtree;
    }
    const historyLi = historyLabel.closest("li");
    if (historyLi) {
      const nested = historyLi.querySelector("ul[role='group']");
      if (nested) return nested;
    }
  }

  const historySubtreeId = `ask-oracle-history-subtree-${Date.now()}`;
  const historyLi = document.createElement("li");
  historyLi.className = "a-TreeView-node a-TreeView-node--topLevel is-expanded a-TreeView-node--expanded";
  historyLi.setAttribute("role", "none");

  const row = document.createElement("div");
  row.className = "a-TreeView-row";
  row.setAttribute("role", "none");

  const content = document.createElement("div");
  content.className = "a-TreeView-content";
  content.setAttribute("role", "none");

  const toggle = document.createElement("span");
  toggle.className = "a-TreeView-toggle";
  toggle.setAttribute("aria-hidden", "true");
  toggle.setAttribute("aria-expanded", "true");
  content.appendChild(toggle);

  const icon = document.createElement("span");
  icon.className = "fa fa-history";
  icon.setAttribute("aria-hidden", "true");
  content.appendChild(icon);

  const label = document.createElement("a");
  label.className = "a-TreeView-label";
  label.setAttribute("href", "javascript:void(0);");
  label.setAttribute("role", "treeitem");
  label.setAttribute("tabindex", "-1");
  label.setAttribute("aria-level", "1");
  label.setAttribute("aria-expanded", "true");
  label.setAttribute("aria-owns", historySubtreeId);
  label.textContent = ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL;
  label.setAttribute("aria-label", ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL);
  content.appendChild(label);

  row.appendChild(content);
  historyLi.appendChild(row);

  const historySubtree = document.createElement("ul");
  historySubtree.id = historySubtreeId;
  historySubtree.className = "a-TreeView-nodeList";
  historySubtree.setAttribute("role", "group");
  historyLi.appendChild(historySubtree);

  treeList.appendChild(historyLi);
  bindAskOracleHistoryNavToggle(historySubtree);
  setAskOracleHistoryNavExpandedState(historySubtree, readAskOracleHistoryNavExpandedPreference());
  return historySubtree;
}

function pruneAskOracleInvalidHistoryNavEntries(subtree) {
  const group = subtree || getAskOracleHistoryNavSubtree();
  if (!group) return;
  const invalidLis = [];
  group.querySelectorAll("li").forEach((li) => {
    if (!li || !li.querySelector) return;
    const labelNode = li.querySelector(".a-TreeView-label");
    if (!labelNode) return;
    const normalized = normalizeAskOracleHistoryNavLabel(labelNode.textContent || "");
    if (normalized) return;
    invalidLis.push(li);
  });
  invalidLis.forEach((li) => {
    try { li.remove(); } catch (e) {}
  });
}

function sanitizeAskOracleHistoryNavLabels(scope) {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return;
  const group = scope || treeRoot;
  if (!group || typeof group.querySelectorAll !== "function") return;

  const historySubtree = getAskOracleHistoryNavSubtree();
  Array.from(group.querySelectorAll(".a-TreeView-label")).forEach((labelNode) => {
    if (!labelNode) return;
    const rawText = String(labelNode.textContent || "").trim();
    const normalized = normalizeAskOracleHistoryNavLabel(rawText);
    const loweredRaw = rawText.toLowerCase();
    const li = labelNode.closest ? labelNode.closest("li") : null;
    const content = labelNode.closest ? labelNode.closest(".a-TreeView-content") : null;
    const isTopLevelHistoryLabel = !!(
      li &&
      li.classList &&
      li.classList.contains("a-TreeView-node--topLevel") &&
      content &&
      content.querySelector(".fa-history")
    );
    if (isTopLevelHistoryLabel) {
      if (rawText !== ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL) labelNode.textContent = ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL;
      labelNode.setAttribute("aria-label", ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL);
      labelNode.classList.remove("ask-oracle-history-label-truncated");
      return;
    }

    const invalidLiteral = loweredRaw === "undefined" || loweredRaw === "null" || loweredRaw === "n/a" || loweredRaw === "na";
    if (normalized && !invalidLiteral) {
      syncAskOracleHistoryLabelNode(labelNode);
      return;
    }
    if (!li) return;
    const withinHistory = !!(historySubtree && historySubtree.contains(li));
    if (!withinHistory && !invalidLiteral) return;
    try { li.remove(); } catch (e) {}
  });

  // Remove stray top-level "undefined/null" leaf nodes created by APEX nav fallback entries.
  Array.from(treeRoot.querySelectorAll("li.a-TreeView-node--topLevel.a-TreeView-node--leaf")).forEach((li) => {
    if (!li || !li.querySelector) return;
    const labelNode = li.querySelector(".a-TreeView-label");
    if (!labelNode) return;
    const rawText = String(labelNode.textContent || "").trim().toLowerCase();
    if (rawText !== "undefined" && rawText !== "null") return;
    if (li.id === ASK_ORACLE_AGENTS_NAV_SECTION_ID || (li.closest && li.closest("#" + ASK_ORACLE_AGENTS_NAV_SECTION_ID))) return;
    try { li.remove(); } catch (e) {}
  });
}

function ensureAskOracleHistoryNavExpanded(subtree) {
  const group = subtree || getAskOracleHistoryNavSubtree();
  if (!group) return;
  bindAskOracleHistoryNavToggle(group);
  setAskOracleHistoryNavExpandedState(group, readAskOracleHistoryNavExpandedPreference());
}

function getAskOracleHistoryLeafIconClass(subtree) {
  if (!subtree) return "fa fa-ai-prompt";
  const icon = subtree.querySelector("li .a-TreeView-content > span");
  if (!icon) return "fa fa-ai-prompt";
  const tokens = String(icon.className || "").split(/\s+/).filter(Boolean);
  const iconTokens = tokens.filter((token) => token === "fa" || token.indexOf("fa-") === 0);
  if (iconTokens.length >= 2) return iconTokens.join(" ");
  return "fa fa-ai-prompt";
}

function buildAskOracleHistoryEntryKey(conversationId, conversationData) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return "";
  const source = conversationData && typeof conversationData === "object" ? conversationData : {};
  let descriptionText = getAskOracleHistoryDescriptionText(source);
  if (!descriptionText || String(descriptionText).toLowerCase() === "new conversation") {
    descriptionText = getAskOracleHistoryFallbackText(source);
  }
  descriptionText = normalizeAskOracleHistoryNavLabel(descriptionText).toLowerCase();
  if (!descriptionText || descriptionText === "new conversation") return "";
  return `conv:${targetConversationId}:desc:${descriptionText}`;
}

function hasAskOracleHistoryEntryNode(entryKey, subtree) {
  const key = String(entryKey || "").trim();
  if (!key) return false;
  const scope = subtree || getAskOracleHistoryNavSubtree() || document;
  if (!scope || typeof scope.querySelectorAll !== "function") return false;
  return Array.from(scope.querySelectorAll("[data-ask-oracle-history-entry-key]")).some((node) => {
    return String(node.getAttribute("data-ask-oracle-history-entry-key") || "") === key;
  });
}

function rememberAskOracleHistoryNavEntry(entryKey, conversationId, conversationData) {
  const key = String(entryKey || "").trim();
  const convId = String(conversationId || "").trim();
  if (!key || !convId) return;
  askOracleHistoryNavEntryByKey[key] = {
    entryKey: key,
    conversationId: convId,
    conversationData: conversationData && typeof conversationData === "object" ? { ...conversationData } : {}
  };
  askOracleHistoryNavEntryOrder = askOracleHistoryNavEntryOrder.filter((item) => item !== key);
  askOracleHistoryNavEntryOrder.unshift(key);
}

function forgetAskOracleHistoryNavEntriesForConversation(conversationId) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;
  const keys = Object.keys(askOracleHistoryNavEntryByKey || {});
  keys.forEach((key) => {
    const entry = askOracleHistoryNavEntryByKey[key];
    if (!entry) return;
    if (String(entry.conversationId || "").trim() !== targetConversationId) return;
    delete askOracleHistoryNavEntryByKey[key];
    delete askOracleHistoryNavInsertedEntryByKey[key];
    delete askOraclePendingHistoryNavEntryByKey[key];
  });
  askOracleHistoryNavEntryOrder = askOracleHistoryNavEntryOrder.filter((key) => !!askOracleHistoryNavEntryByKey[key]);
}

function replayAskOracleHistoryNavEntries() {
  const orderedKeys = (askOracleHistoryNavEntryOrder || []).filter((key) => !!askOracleHistoryNavEntryByKey[key]);
  if (!orderedKeys.length) return;
  for (let index = orderedKeys.length - 1; index >= 0; index -= 1) {
    const key = orderedKeys[index];
    const storedEntry = askOracleHistoryNavEntryByKey[key];
    if (!storedEntry) continue;
    appendAskOracleConversationHistoryNavEntry(storedEntry.conversationId, storedEntry.conversationData);
  }
}

function getAskOraclePinnedNavSubtree() {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return null;
  const topLevelNodes = Array.from(treeRoot.querySelectorAll("li.a-TreeView-node--topLevel"));
  for (const topLevelNode of topLevelNodes) {
    const contentEl = topLevelNode.querySelector(".a-TreeView-content");
    if (!contentEl) continue;
    const labelEl = contentEl.querySelector(".a-TreeView-label");
    const labelText = String((labelEl && labelEl.textContent) || "").trim().toLowerCase();
    const looksPinned = labelText === "pinned" || labelText.indexOf("pinned") >= 0;
    if (!looksPinned) continue;
    const subtree = topLevelNode.querySelector("ul[role='group']");
    if (subtree) return subtree;
  }
  return null;
}

function ensureAskOraclePinnedNavExpanded(subtree) {
  const group = subtree || getAskOraclePinnedNavSubtree();
  if (!group) return;
  const pinnedLi = group.closest("li");
  if (!pinnedLi) return;
  try {
    pinnedLi.classList.add("is-expanded", "a-TreeView-node--expanded");
    pinnedLi.classList.remove("is-collapsed", "a-TreeView-node--collapsed");
  } catch (e) {}
  const label = pinnedLi.querySelector(".a-TreeView-label");
  if (label) label.setAttribute("aria-expanded", "true");
  const toggle = pinnedLi.querySelector(".a-TreeView-toggle");
  if (toggle) toggle.setAttribute("aria-expanded", "true");
  group.style.display = "";
}

function ensureAskOracleAgentsNavCss() {
  if (document.getElementById(ASK_ORACLE_AGENTS_NAV_CSS_ID)) return;
  const style = document.createElement("style");
  style.id = ASK_ORACLE_AGENTS_NAV_CSS_ID;
  style.textContent = `
    :root {
      scrollbar-gutter: stable both-edges;
    }
    body,
    .t-Body-content,
    .t-Body-contentInner {
      scrollbar-gutter: stable;
    }
    #t_Body_nav,
    .t-Body-nav {
      background: #ffffff !important;
      border-right: 1px solid #eeeeee !important;
      font-family: "Söhne", "Soehne", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
      animation: none !important;
    }
    .t-Body-side {
      animation: none !important;
    }
    #t_TreeNav,
    #t_TreeNav .a-TreeView,
    #t_TreeNav .a-TreeView-nodeList {
      background: transparent !important;
      font-family: "Söhne", "Soehne", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
    }
    #t_TreeNav {
      max-height: calc(100vh - 78px) !important;
      overflow-y: auto !important;
      overflow-x: hidden !important;
      overscroll-behavior: contain !important;
      scrollbar-width: thin !important;
      scrollbar-color: rgba(15, 23, 42, 0.24) transparent !important;
    }
    #t_TreeNav::-webkit-scrollbar {
      width: 7px !important;
      height: 7px !important;
    }
    #t_TreeNav::-webkit-scrollbar-track {
      background: transparent !important;
    }
    #t_TreeNav::-webkit-scrollbar-thumb {
      background-color: rgba(15, 23, 42, 0.2) !important;
      border-radius: 999px !important;
      border: 2px solid transparent !important;
      background-clip: padding-box !important;
    }
    #t_TreeNav:hover::-webkit-scrollbar-thumb {
      background-color: rgba(15, 23, 42, 0.3) !important;
    }
    #t_TreeNav .a-TreeView-node {
      margin: 0 !important;
    }
    #t_TreeNav .a-TreeView-row {
      min-height: 0 !important;
    }
    #t_TreeNav .a-TreeView-content {
      min-height: 32px !important;
      margin: 1px 0 !important;
      padding: 0 8px !important;
      border-radius: 8px !important;
      color: #0d0d0d !important;
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
      box-sizing: border-box !important;
      background: transparent !important;
      border: 0 !important;
      box-shadow: none !important;
    }
    #t_TreeNav .a-TreeView-content:hover,
    #t_TreeNav .a-TreeView-content.is-current,
    #t_TreeNav .a-TreeView-content.is-selected,
    #t_TreeNav li.is-current > .a-TreeView-row > .a-TreeView-content,
    #t_TreeNav li.is-selected > .a-TreeView-row > .a-TreeView-content {
      background: #f1f1f1 !important;
    }
    #t_TreeNav .a-TreeView-node--topLevel,
    #t_TreeNav .a-TreeView-node--topLevel > .a-TreeView-row,
    #t_TreeNav .a-TreeView-node--topLevel > .a-TreeView-content,
    #t_TreeNav .a-TreeView-node--topLevel > .a-TreeView-row > .a-TreeView-content {
      background: #ffffff !important;
    }
    #t_TreeNav .a-TreeView-node--topLevel > .a-TreeView-row > .a-TreeView-content:hover,
    #t_TreeNav .a-TreeView-node--topLevel.is-current > .a-TreeView-row > .a-TreeView-content,
    #t_TreeNav .a-TreeView-node--topLevel.is-selected > .a-TreeView-row > .a-TreeView-content {
      background: #f1f1f1 !important;
    }
    #t_TreeNav .a-TreeView-content .fa,
    #t_TreeNav .a-TreeView-content .t-Icon {
      width: 20px !important;
      min-width: 20px !important;
      margin: 0 !important;
      color: #111111 !important;
      font-size: 16px !important;
      line-height: 1 !important;
      text-align: center !important;
    }
    #t_TreeNav .a-TreeView-label {
      color: #0d0d0d !important;
      font-size: 15px !important;
      font-weight: 500 !important;
      line-height: 1.36 !important;
      letter-spacing: 0 !important;
      text-decoration: none !important;
    }
    #t_TreeNav .a-TreeView-content > .a-TreeView-label,
    #t_TreeNav .a-TreeView-label[aria-selected='true'],
    #t_TreeNav li.is-current > .a-TreeView-row > .a-TreeView-content > .a-TreeView-label,
    #t_TreeNav li.is-selected > .a-TreeView-row > .a-TreeView-content > .a-TreeView-label {
      font-weight: 500 !important;
    }
    #t_TreeNav .a-TreeView-toggle {
      margin-left: auto !important;
      color: #8a8a8a !important;
      opacity: 0.9 !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content {
      min-height: 28px !important;
      margin-top: 10px !important;
      margin-left: 0 !important;
      margin-right: 0 !important;
      padding: 0 16px !important;
      cursor: default !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content:hover,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content:hover {
      background: transparent !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content > .a-Icon,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content > .t-Icon,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-content > .a-Icon,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-content > .t-Icon,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row + .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row + .a-TreeView-content > .a-Icon,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row + .a-TreeView-content > .t-Icon,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content > .a-Icon,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content > .t-Icon,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-content > .a-Icon,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-content > .t-Icon,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row + .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row + .a-TreeView-content > .a-Icon,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row + .a-TreeView-content > .t-Icon,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content > .a-TreeView-toggle,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content > .a-TreeView-toggle {
      display: none !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content > .a-TreeView-label,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content > .a-TreeView-label {
      padding: 0 !important;
      color: #0d0d0d !important;
      font-size: 14px !important;
      font-family: "Söhne", "Soehne", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
      font-weight: 600 !important;
      letter-spacing: 0 !important;
      line-height: 1.32 !important;
      cursor: default !important;
    }
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content > .a-TreeView-label {
      font-weight: 700 !important;
    }
    #t_TreeNav .ask-oracle-pinned-nav-section {
      margin-bottom: 10px !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > ul[role='group'],
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-nodeList,
    #t_TreeNav .ask-oracle-pinned-nav-section > ul[role='group'],
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-nodeList {
      padding-top: 4px !important;
      padding-left: 0 !important;
      padding-right: 0 !important;
      max-height: none !important;
      overflow: visible !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > ul[role='group'] .a-TreeView-content,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-nodeList .a-TreeView-content,
    #t_TreeNav .ask-oracle-pinned-nav-section > ul[role='group'] .a-TreeView-content,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-nodeList .a-TreeView-content {
      min-height: 30px !important;
      margin: 0 !important;
      padding: 0 8px 0 10px !important;
      gap: 6px !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > ul[role='group'] .a-TreeView-label,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-nodeList .a-TreeView-label,
    #t_TreeNav .ask-oracle-pinned-nav-section > ul[role='group'] .a-TreeView-label,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-nodeList .a-TreeView-label {
      font-size: 13px !important;
      font-weight: 500 !important;
      line-height: 1.36 !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > ul[role='group'] .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-nodeList .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-pinned-nav-section > ul[role='group'] .a-TreeView-content > .fa,
    #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-nodeList .a-TreeView-content > .fa {
      display: none !important;
    }
    #t_TreeNav .ask-oracle-agents-nav-section {
      margin: 10px 0 16px;
      padding: 0;
      list-style: none;
    }
    #t_TreeNav .ask-oracle-agents-nav-heading {
      padding: 8px 16px 6px;
      color: #0d0d0d;
      font-size: 14px;
      font-weight: 700;
      line-height: 1.32;
      letter-spacing: 0;
    }
    #t_TreeNav .ask-oracle-agents-nav-list {
      margin: 0;
      padding: 0;
      list-style: none;
    }
    #t_TreeNav .ask-oracle-agents-nav-item > .a-TreeView-row > .a-TreeView-content {
      min-height: 34px;
      margin: 0 8px;
      padding: 0 10px;
      border-radius: 8px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    #t_TreeNav .ask-oracle-agents-nav-item > .a-TreeView-row > .a-TreeView-content:hover {
      background: rgba(15, 23, 42, 0.06);
    }
    #t_TreeNav .ask-oracle-agents-nav-icon {
      width: 18px;
      min-width: 18px;
      color: #111827;
      text-align: center;
      font-size: 14px;
      line-height: 1;
    }
    #t_TreeNav .ask-oracle-new-chat-icon {
      width: 22px;
      min-width: 22px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      color: inherit;
      text-align: center;
      line-height: 1;
      margin-right: 0;
      vertical-align: middle;
    }
    #t_TreeNav .ask-oracle-new-chat-icon svg {
      width: 19px;
      height: 19px;
      display: block;
      stroke: currentColor;
      fill: none;
      stroke-width: 2.25;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    #t_TreeNav .ask-oracle-agents-nav-link.a-TreeView-label {
      padding: 0 !important;
      color: #0d0d0d;
      font-size: 15px;
      font-weight: 500;
      line-height: 1.36;
      text-decoration: none;
      min-width: 0;
    }
    #t_TreeNav li.ask-oracle-sticky-nav-item {
      position: sticky !important;
      z-index: 40 !important;
      background: #ffffff !important;
      margin: 0 !important;
      border-bottom: 0 !important;
      height: 38px !important;
      min-height: 38px !important;
      overflow: hidden !important;
    }
    #t_TreeNav li.ask-oracle-sticky-nav-item > .a-TreeView-content,
    #t_TreeNav li.ask-oracle-sticky-nav-item > .a-TreeView-row + .a-TreeView-content {
      background: #ffffff !important;
    }
    #t_TreeNav li.ask-oracle-sticky-nav-item > .a-TreeView-row {
      margin: 0 !important;
      min-height: 38px !important;
      height: 38px !important;
    }
    #t_TreeNav li.ask-oracle-sticky-nav-item > .a-TreeView-row > .a-TreeView-content {
      margin: 0 !important;
      border-radius: 0 !important;
      min-height: 38px !important;
      height: 38px !important;
    }
    #t_TreeNav li.ask-oracle-sticky-nav-new-chat {
      top: 0 !important;
    }
    #t_TreeNav li.ask-oracle-sticky-nav-search {
      top: 38px !important;
    }
    #t_TreeNav li.ask-oracle-sticky-nav-delete {
      top: 76px !important;
    }
    #t_TreeNav li.ask-oracle-sticky-nav-new-chat > .a-TreeView-row > .a-TreeView-content,
    #t_TreeNav li.ask-oracle-sticky-nav-search > .a-TreeView-row > .a-TreeView-content,
    #t_TreeNav li.ask-oracle-sticky-nav-delete > .a-TreeView-row > .a-TreeView-content,
    #t_TreeNav li.ask-oracle-sticky-nav-new-chat > .a-TreeView-row > .a-TreeView-content:hover,
    #t_TreeNav li.ask-oracle-sticky-nav-search > .a-TreeView-row > .a-TreeView-content:hover,
    #t_TreeNav li.ask-oracle-sticky-nav-delete > .a-TreeView-row > .a-TreeView-content:hover,
    #t_TreeNav li.ask-oracle-sticky-nav-new-chat > .a-TreeView-row > .a-TreeView-content.is-current,
    #t_TreeNav li.ask-oracle-sticky-nav-search > .a-TreeView-row > .a-TreeView-content.is-current,
    #t_TreeNav li.ask-oracle-sticky-nav-delete > .a-TreeView-row > .a-TreeView-content.is-current,
    #t_TreeNav li.ask-oracle-sticky-nav-new-chat > .a-TreeView-row > .a-TreeView-content.is-selected,
    #t_TreeNav li.ask-oracle-sticky-nav-search > .a-TreeView-row > .a-TreeView-content.is-selected,
    #t_TreeNav li.ask-oracle-sticky-nav-delete > .a-TreeView-row > .a-TreeView-content.is-selected {
      background: #ffffff !important;
    }
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-content > .a-TreeView-label,
    #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row + .a-TreeView-content > .a-TreeView-label,
    #t_TreeNav .ask-oracle-recents-heading-label {
      font-family: "Söhne", "Soehne", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
      font-weight: 700 !important;
      letter-spacing: 0 !important;
      line-height: 1.32 !important;
    }
    body.ask-oracle-dark-ui #t_Body_nav,
    body.ask-oracle-dark-ui .t-Body-nav {
      background: #171717 !important;
      border-right-color: rgba(255, 255, 255, 0.08) !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav {
      scrollbar-color: rgba(226, 232, 240, 0.42) transparent !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav::-webkit-scrollbar-thumb {
      background-color: rgba(226, 232, 240, 0.34) !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav:hover::-webkit-scrollbar-thumb {
      background-color: rgba(226, 232, 240, 0.5) !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-content:hover,
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-content.is-current,
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-content.is-selected,
    body.ask-oracle-dark-ui #t_TreeNav li.is-current > .a-TreeView-row > .a-TreeView-content,
    body.ask-oracle-dark-ui #t_TreeNav li.is-selected > .a-TreeView-row > .a-TreeView-content {
      background: rgba(255, 255, 255, 0.08) !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-label,
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-content .fa,
    body.ask-oracle-dark-ui #t_TreeNav .a-TreeView-content .t-Icon,
    body.ask-oracle-dark-ui #t_TreeNav .ask-oracle-recents-nav-section > .a-TreeView-row > .a-TreeView-content > .a-TreeView-label,
    body.ask-oracle-dark-ui #t_TreeNav .ask-oracle-pinned-nav-section > .a-TreeView-row > .a-TreeView-content > .a-TreeView-label {
      color: #ececec !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav .ask-oracle-agents-nav-heading,
    body.ask-oracle-dark-ui #t_TreeNav .ask-oracle-agents-nav-icon,
    body.ask-oracle-dark-ui #t_TreeNav .ask-oracle-agents-nav-link.a-TreeView-label {
      color: #e5e7eb;
    }
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-item {
      background: #171717 !important;
      border-bottom: 0 !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-item > .a-TreeView-content,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-item > .a-TreeView-row + .a-TreeView-content {
      background: #171717 !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-new-chat > .a-TreeView-row > .a-TreeView-content,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-search > .a-TreeView-row > .a-TreeView-content,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-delete > .a-TreeView-row > .a-TreeView-content,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-new-chat > .a-TreeView-row > .a-TreeView-content:hover,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-search > .a-TreeView-row > .a-TreeView-content:hover,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-delete > .a-TreeView-row > .a-TreeView-content:hover,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-new-chat > .a-TreeView-row > .a-TreeView-content.is-current,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-search > .a-TreeView-row > .a-TreeView-content.is-current,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-delete > .a-TreeView-row > .a-TreeView-content.is-current,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-new-chat > .a-TreeView-row > .a-TreeView-content.is-selected,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-search > .a-TreeView-row > .a-TreeView-content.is-selected,
    body.ask-oracle-dark-ui #t_TreeNav li.ask-oracle-sticky-nav-delete > .a-TreeView-row > .a-TreeView-content.is-selected {
      background: #171717 !important;
    }
    body.ask-oracle-dark-ui #t_TreeNav .ask-oracle-agents-nav-item > .a-TreeView-row > .a-TreeView-content:hover {
      background: rgba(148, 163, 184, 0.16);
    }
  `;
  document.head.appendChild(style);
}

function getAskOracleTreeNavList() {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return null;
  if (treeRoot.matches && treeRoot.matches("ul")) return treeRoot;
  return treeRoot.querySelector("ul[role='tree']") ||
    treeRoot.querySelector(".a-TreeView-nodeList[role='tree']") ||
    treeRoot.querySelector(".a-TreeView-nodeList") ||
    treeRoot.querySelector("ul");
}

function getAskOracleBuilderSettingsUrl(hash) {
  const targetHash = String(hash || "").replace(/^#/, "").trim();
  let appId = "";
  let sessionId = "";
  try {
    if (typeof window.$v === "function") {
      appId = String(window.$v("pFlowId") || "").trim();
      sessionId = String(window.$v("pInstance") || "").trim();
    }
  } catch (e) {}
  try {
    if ((!appId || !sessionId) && window.apex && apex.env) {
      appId = appId || String(apex.env.APP_ID || "").trim();
      sessionId = sessionId || String(apex.env.APP_SESSION || apex.env.SESSION || "").trim();
    }
  } catch (e2) {}
  if (!appId) {
    const flowInput = document.querySelector("#pFlowId, input[name='pFlowId']");
    if (flowInput && typeof flowInput.value !== "undefined") appId = String(flowInput.value || "").trim();
  }
  if (!sessionId) {
    const sessionInput = document.querySelector("#pInstance, input[name='pInstance']");
    if (sessionInput && typeof sessionInput.value !== "undefined") sessionId = String(sessionInput.value || "").trim();
  }
  if ((!appId || !sessionId) && window.location && window.location.search) {
    const pMatch = window.location.search.match(/[?&]p=([^:&]+):[^:&]*:([^:&]*)/i);
    if (pMatch) {
      if (!appId) appId = String(pMatch[1] || "").trim();
      if (!sessionId) sessionId = String(pMatch[2] || "").trim();
    }
  }
  if (!appId) return targetHash ? `#${encodeURIComponent(targetHash)}` : "#";
  return `f?p=${encodeURIComponent(appId)}:20000:${encodeURIComponent(sessionId)}::::::${targetHash ? "#" + encodeURIComponent(targetHash) : ""}`;
}

function navigateAskOracleBuilderSettings(hash) {
  const url = getAskOracleBuilderSettingsUrl(hash);
  if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
    apex.navigation.redirect(url);
  } else {
    window.location.href = url;
  }
}

function findAskOracleTopLevelNavNodeByLabel(labelMatcher) {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot || typeof labelMatcher !== "function") return null;
  const treeList = getAskOracleTreeNavList();
  if (!treeList) return null;

  const labels = Array.from(treeRoot.querySelectorAll(".a-TreeView-label, a, button, [role='treeitem']"));
  for (const labelEl of labels) {
    if (!labelEl || (labelEl.closest && labelEl.closest("#" + ASK_ORACLE_AGENTS_NAV_SECTION_ID))) continue;
    const labelText = String((labelEl.textContent || "")).replace(/\s+/g, " ").trim();
    if (!labelMatcher(labelText.toLowerCase(), labelText)) continue;

    let node = labelEl;
    while (node && node.parentElement && node.parentElement !== treeList) {
      node = node.parentElement;
    }
    if (node && node.parentElement === treeList) return node;

    const fallbackLi = labelEl.closest ? labelEl.closest("li") : null;
    if (fallbackLi) return fallbackLi;
  }
  return null;
}

function createAskOracleAgentsNavItem(labelText, hashValue) {
  const li = document.createElement("li");
  li.className = "a-TreeView-node a-TreeView-node--leaf ask-oracle-agents-nav-item";
  li.setAttribute("role", "none");

  const row = document.createElement("div");
  row.className = "a-TreeView-row";
  row.setAttribute("role", "none");

  const content = document.createElement("div");
  content.className = "a-TreeView-content";
  content.setAttribute("role", "none");

  const iconClassByTarget = {
    "agent-builder": "fa fa-cogs",
    "prebuilt-agents": "fa fa-cubes",
    "profile-builder": "fa fa-id-badge"
  };
  const icon = document.createElement("span");
  const normalizedTarget = String(hashValue || "").trim().toLowerCase();
  icon.className = (iconClassByTarget[normalizedTarget] || "fa fa-cube") + " ask-oracle-agents-nav-icon";
  icon.setAttribute("aria-hidden", "true");
  content.appendChild(icon);

  const link = document.createElement("a");
  link.className = "a-TreeView-label ask-oracle-agents-nav-link";
  link.href = getAskOracleBuilderSettingsUrl(hashValue);
  link.setAttribute("role", "treeitem");
  link.setAttribute("tabindex", "-1");
  link.setAttribute("aria-level", "2");
  link.setAttribute("data-ask-oracle-agents-target", hashValue);
  link.textContent = labelText;
  link.setAttribute("aria-label", labelText);
  content.appendChild(link);

  row.appendChild(content);
  li.appendChild(row);
  return li;
}

function syncAskOracleChatGptNavLabels() {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return;
  const newChatIconSvg =
    "<svg viewBox='0 0 24 24' aria-hidden='true' focusable='false'>" +
    "<path d='M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7'></path>" +
    "<path d='M18.37 2.63a2.12 2.12 0 1 1 3 3L12 15l-4 1 1-4z'></path>" +
    "</svg>";
  const labelMap = {
    "+ new chat": "New chat",
    "new chat": "New chat",
    "search chats": "Search chats",
    "delete chats": "Delete chats",
    "pinned chats": "Pinned chats",
    "history": ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL,
    "recents": ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL
  };
  Array.from(treeRoot.querySelectorAll(".a-TreeView-label")).forEach(function(labelNode) {
    if (!labelNode || (labelNode.closest && labelNode.closest("#" + ASK_ORACLE_AGENTS_NAV_SECTION_ID))) return;
    const text = String(labelNode.textContent || "").replace(/\s+/g, " ").trim();
    const normalized = text.toLowerCase();
    const nextLabel = labelMap[normalized];
    if (!nextLabel) return;
    if (labelNode.textContent !== nextLabel) labelNode.textContent = nextLabel;
    labelNode.setAttribute("aria-label", nextLabel);
    const contentNode = labelNode.closest(".a-TreeView-content") || labelNode.parentElement;
    const navLi = contentNode && contentNode.closest ? contentNode.closest("li") : null;
    if (contentNode && contentNode.classList) {
      contentNode.classList.remove("ask-oracle-recents-heading-row");
    }
    if (labelNode.classList) {
      labelNode.classList.remove("ask-oracle-recents-heading-label");
    }
    if (navLi && navLi.classList) {
      navLi.classList.remove(
        "ask-oracle-sticky-nav-item",
        "ask-oracle-sticky-nav-new-chat",
        "ask-oracle-sticky-nav-search",
        "ask-oracle-sticky-nav-delete"
      );
    }
    if (navLi && navLi.classList) {
      if (nextLabel === "New chat") {
        navLi.classList.add("ask-oracle-sticky-nav-item", "ask-oracle-sticky-nav-new-chat");
      } else if (nextLabel === "Search chats") {
        navLi.classList.add("ask-oracle-sticky-nav-item", "ask-oracle-sticky-nav-search");
      } else if (nextLabel === "Delete chats") {
        navLi.classList.add("ask-oracle-sticky-nav-item", "ask-oracle-sticky-nav-delete");
      }
    }
    if (nextLabel === ASK_ORACLE_HISTORY_NAV_DISPLAY_LABEL) {
      const topLevelLi = navLi && navLi.classList && navLi.classList.contains("a-TreeView-node--topLevel")
        ? navLi
        : null;
      if (topLevelLi) {
        if (contentNode && contentNode.classList) {
          contentNode.classList.add("ask-oracle-recents-heading-row");
        }
        if (labelNode.classList) {
          labelNode.classList.add("ask-oracle-recents-heading-label");
        }
      }
    }
    if (normalized === "new chat" || normalized === "+ new chat") {
      if (contentNode) {
        let iconNode = contentNode.querySelector(".ask-oracle-new-chat-icon");
        if (!iconNode) {
          iconNode = contentNode.querySelector("span.fa, span.a-Icon, span.t-Icon, span[class*='icon-']");
        }
        if (!iconNode) {
          iconNode = document.createElement("span");
          if (labelNode.parentNode === contentNode) {
            contentNode.insertBefore(iconNode, labelNode);
          } else {
            contentNode.insertBefore(iconNode, contentNode.firstChild);
          }
        }
        iconNode.className = "ask-oracle-new-chat-icon";
        iconNode.innerHTML = newChatIconSvg;
        iconNode.setAttribute("aria-hidden", "true");
      }
    }
  });

  // Guardrail: keep custom section heading stable even if nav nodes are repainted.
  const agentsSection = document.getElementById(ASK_ORACLE_AGENTS_NAV_SECTION_ID);
  if (agentsSection) {
    const heading = agentsSection.querySelector(".ask-oracle-agents-nav-heading");
    if (heading && String(heading.textContent || "").trim().toLowerCase() !== "select ai") {
      heading.textContent = "Select AI";
    }
  }
  applyAskOracleStickyPrimaryNavClasses();
}

function stabilizeAskOracleStaticLeftNavBits() {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return;

  const newChatIconSvg =
    "<svg viewBox='0 0 24 24' aria-hidden='true' focusable='false'>" +
    "<path d='M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7'></path>" +
    "<path d='M18.37 2.63a2.12 2.12 0 1 1 3 3L12 15l-4 1 1-4z'></path>" +
    "</svg>";

  const agentsSection = document.getElementById(ASK_ORACLE_AGENTS_NAV_SECTION_ID);
  if (agentsSection) {
    let heading = agentsSection.querySelector(".ask-oracle-agents-nav-heading");
    if (!heading) {
      heading = document.createElement("div");
      heading.className = "ask-oracle-agents-nav-heading";
      agentsSection.insertBefore(heading, agentsSection.firstChild || null);
    }
    if (String(heading.textContent || "").trim() !== "Select AI") {
      heading.textContent = "Select AI";
    }
  }

  Array.from(treeRoot.querySelectorAll("li.a-TreeView-node--topLevel")).forEach((li) => {
    const labelNode = li.querySelector(".a-TreeView-content > .a-TreeView-label");
    if (!labelNode) return;
    const rawLabel = String(labelNode.textContent || "").replace(/\s+/g, " ").trim();
    const lowered = rawLabel.toLowerCase();

    if (lowered === "new chat" || lowered === "+ new chat") {
      if (rawLabel !== "New chat") labelNode.textContent = "New chat";
      labelNode.setAttribute("aria-label", "New chat");
      const contentNode = labelNode.closest(".a-TreeView-content") || labelNode.parentElement;
      if (contentNode) {
        let iconNode = contentNode.querySelector(".ask-oracle-new-chat-icon");
        if (!iconNode) {
          iconNode = contentNode.querySelector("span.fa, span.a-Icon, span.t-Icon, span[class*='icon-']");
        }
        if (!iconNode) {
          iconNode = document.createElement("span");
          if (labelNode.parentNode === contentNode) {
            contentNode.insertBefore(iconNode, labelNode);
          } else {
            contentNode.insertBefore(iconNode, contentNode.firstChild || null);
          }
        }
        iconNode.className = "ask-oracle-new-chat-icon";
        iconNode.innerHTML = newChatIconSvg;
        iconNode.setAttribute("aria-hidden", "true");
      }
      return;
    }

    if (lowered !== "undefined" && lowered !== "null") return;

    const subtree = li.querySelector("ul[role='group']");
    const subtreeText = String(subtree ? subtree.textContent || "" : "").toLowerCase();
    const hasAgentItems =
      !!li.querySelector("[data-ask-oracle-agents-target]") ||
      /\bagent builder\b|\bprebuilt agents\b|\bprofile builder\b/.test(subtreeText);

    if (hasAgentItems) {
      labelNode.textContent = "Select AI";
      labelNode.setAttribute("aria-label", "Select AI");
      if (subtree) {
        li.classList.add("is-expanded", "a-TreeView-node--expanded");
        li.classList.remove("is-collapsed", "a-TreeView-node--collapsed");
        labelNode.setAttribute("aria-expanded", "true");
        const toggle = li.querySelector(".a-TreeView-toggle");
        if (toggle) toggle.setAttribute("aria-expanded", "true");
        subtree.style.display = "";
      }
      return;
    }

    if (li.id === ASK_ORACLE_AGENTS_NAV_SECTION_ID || (li.closest && li.closest("#" + ASK_ORACLE_AGENTS_NAV_SECTION_ID))) {
      return;
    }
    try { li.remove(); } catch (e) {}
  });
}

function applyAskOracleStickyPrimaryNavClasses() {
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return;

  const classList = [
    "ask-oracle-sticky-nav-item",
    "ask-oracle-sticky-nav-new-chat",
    "ask-oracle-sticky-nav-search",
    "ask-oracle-sticky-nav-delete"
  ];
  Array.from(treeRoot.querySelectorAll("li.a-TreeView-node")).forEach((li) => {
    if (!li || !li.classList) return;
    classList.forEach((cls) => li.classList.remove(cls));
  });

  const stickyTargets = {
    "new chat": "ask-oracle-sticky-nav-new-chat",
    "search chats": "ask-oracle-sticky-nav-search",
    "delete chats": "ask-oracle-sticky-nav-delete"
  };

  const candidateNodes = Array.from(treeRoot.querySelectorAll("li.a-TreeView-node"));
  candidateNodes.forEach((li) => {
    const labelNode = li.querySelector(".a-TreeView-content > .a-TreeView-label");
    const labelText = String((labelNode && labelNode.textContent) || "").replace(/\s+/g, " ").trim().toLowerCase();
    const stickyClass = stickyTargets[labelText];
    if (!stickyClass || !li.classList) return;
    li.classList.add("ask-oracle-sticky-nav-item", stickyClass);
  });
}

function ensureAskOracleAgentsNavSection() {
  const treeList = getAskOracleTreeNavList();
  if (!treeList) return;
  ensureAskOracleAgentsNavCss();
  syncAskOracleChatGptNavLabels();

  let section = document.getElementById(ASK_ORACLE_AGENTS_NAV_SECTION_ID);
  if (!section) {
    section = document.createElement("li");
    section.id = ASK_ORACLE_AGENTS_NAV_SECTION_ID;
    section.className = "ask-oracle-agents-nav-section";
    section.setAttribute("role", "none");

    const heading = document.createElement("div");
    heading.className = "ask-oracle-agents-nav-heading";
    heading.textContent = "Select AI";
    section.appendChild(heading);

    const list = document.createElement("ul");
    list.className = "ask-oracle-agents-nav-list";
    list.setAttribute("role", "group");
    list.appendChild(createAskOracleAgentsNavItem("Agent Builder", "agent-builder"));
    list.appendChild(createAskOracleAgentsNavItem("Prebuilt Agents", "prebuilt-agents"));
    list.appendChild(createAskOracleAgentsNavItem("AI Profile Builder", "profile-builder"));
    section.appendChild(list);

    section.addEventListener("click", function(event) {
      const target = event.target && event.target.closest("[data-ask-oracle-agents-target]");
      if (!target) return;
      event.preventDefault();
      event.stopPropagation();
      navigateAskOracleBuilderSettings(target.getAttribute("data-ask-oracle-agents-target"));
    }, true);
  }

  // Re-assert heading and child labels every run (APEX can overwrite these while prompt is running).
  let heading = section.querySelector(".ask-oracle-agents-nav-heading");
  if (!heading) {
    heading = document.createElement("div");
    heading.className = "ask-oracle-agents-nav-heading";
    section.insertBefore(heading, section.firstChild || null);
  }
  heading.textContent = "Select AI";

  const requiredAgentItems = [
    { target: "agent-builder", label: "Agent Builder" },
    { target: "prebuilt-agents", label: "Prebuilt Agents" },
    { target: "profile-builder", label: "AI Profile Builder" }
  ];
  let list = section.querySelector(".ask-oracle-agents-nav-list");
  if (!list) {
    list = document.createElement("ul");
    list.className = "ask-oracle-agents-nav-list";
    list.setAttribute("role", "group");
    section.appendChild(list);
  }
  requiredAgentItems.forEach(function(item) {
    let link = list.querySelector("[data-ask-oracle-agents-target='" + item.target + "']");
    if (!link) {
      const li = createAskOracleAgentsNavItem(item.label, item.target);
      list.appendChild(li);
      link = li.querySelector("[data-ask-oracle-agents-target]");
    }
    if (!link) return;
    const currentText = String(link.textContent || "").trim().toLowerCase();
    if (!currentText || currentText === "undefined" || currentText === "null") {
      link.textContent = item.label;
    }
    link.setAttribute("aria-label", item.label);
  });

  section.querySelectorAll("[data-ask-oracle-agents-target]").forEach(function(link) {
    link.setAttribute("href", getAskOracleBuilderSettingsUrl(link.getAttribute("data-ask-oracle-agents-target")));
  });

  const pinnedTopLevel = findAskOracleTopLevelNavNodeByLabel(function(lowered) {
    return lowered === "pinned" || lowered.indexOf("pinned") >= 0;
  });
  const historyTopLevel = findAskOracleTopLevelNavNodeByLabel(function(lowered) {
    return lowered === "history" || lowered === "recents" || lowered.indexOf("history") >= 0;
  });
  if (pinnedTopLevel && pinnedTopLevel.classList) {
    pinnedTopLevel.classList.add("ask-oracle-pinned-nav-section");
  }
  if (historyTopLevel && historyTopLevel.classList) {
    historyTopLevel.classList.add("ask-oracle-recents-nav-section");
  }
  if (pinnedTopLevel && pinnedTopLevel.parentNode === treeList) {
    if (pinnedTopLevel.previousSibling !== section) {
      treeList.insertBefore(section, pinnedTopLevel);
    }
  } else if (historyTopLevel && historyTopLevel.parentNode === treeList) {
    if (historyTopLevel.previousSibling !== section) {
      treeList.insertBefore(section, historyTopLevel);
    }
  } else if (section.parentNode !== treeList) {
    treeList.appendChild(section);
  }
  applyAskOracleStickyPrimaryNavClasses();
}

function isAskOraclePinnedNavContentNode(contentNode) {
  if (!contentNode || !contentNode.closest) return false;
  const li = contentNode.closest("li");
  if (!li || !li.parentElement) return false;
  const topLevel = li.parentElement.closest("li.a-TreeView-node--topLevel");
  if (!topLevel) return false;
  const labelNode = topLevel.querySelector(".a-TreeView-content .a-TreeView-label");
  const text = String((labelNode && labelNode.textContent) || "").trim().toLowerCase();
  return text === "pinned" || text.indexOf("pinned") >= 0;
}

function moveAskOracleConversationNavNodeToPinned(contentNode) {
  const pinnedSubtree = getAskOraclePinnedNavSubtree();
  if (!pinnedSubtree || !contentNode || !contentNode.closest) return;
  const li = contentNode.closest("li");
  if (!li) return;
  if (pinnedSubtree.contains(li)) {
    if (pinnedSubtree.firstElementChild !== li) {
      pinnedSubtree.insertBefore(li, pinnedSubtree.firstElementChild);
    }
    ensureAskOraclePinnedNavExpanded(pinnedSubtree);
    return;
  }
  const conversationId = getAskOracleConversationIdFromNavNode(contentNode);
  if (conversationId) {
    const duplicate = Array.from(pinnedSubtree.querySelectorAll("li")).find((node) => {
      return getAskOracleConversationIdFromNavNode(node) === conversationId;
    });
    if (duplicate) {
      if (duplicate !== li) {
        try { li.remove(); } catch (e) {}
      }
      if (pinnedSubtree.firstElementChild !== duplicate) {
        pinnedSubtree.insertBefore(duplicate, pinnedSubtree.firstElementChild);
      }
      ensureAskOraclePinnedNavExpanded(pinnedSubtree);
      return;
    }
  }
  pinnedSubtree.insertBefore(li, pinnedSubtree.firstElementChild);
  ensureAskOraclePinnedNavExpanded(pinnedSubtree);
}

function moveAskOracleConversationNavNodeToHistory(contentNode) {
  const historySubtree = getAskOracleHistoryNavSubtree();
  if (!historySubtree || !contentNode || !contentNode.closest) return;
  const li = contentNode.closest("li");
  if (!li) return;
  if (historySubtree.contains(li)) {
    if (historySubtree.firstElementChild !== li) {
      historySubtree.insertBefore(li, historySubtree.firstElementChild);
    }
    ensureAskOracleHistoryNavExpanded(historySubtree);
    return;
  }
  const conversationId = getAskOracleConversationIdFromNavNode(contentNode);
  if (conversationId) {
    const duplicate = Array.from(historySubtree.querySelectorAll("li")).find((node) => {
      return getAskOracleConversationIdFromNavNode(node) === conversationId;
    });
    if (duplicate) {
      if (duplicate !== li) {
        try { li.remove(); } catch (e) {}
      }
      if (historySubtree.firstElementChild !== duplicate) {
        historySubtree.insertBefore(duplicate, historySubtree.firstElementChild);
      }
      ensureAskOracleHistoryNavExpanded(historySubtree);
      return;
    }
  }
  historySubtree.insertBefore(li, historySubtree.firstElementChild);
  ensureAskOracleHistoryNavExpanded(historySubtree);
}

function ensureAskOracleConversationVisibleInPinned(conversationId, fallbackNode) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;

  const tryMove = function() {
    const pinnedSubtree = getAskOraclePinnedNavSubtree();
    if (!pinnedSubtree) return false;

    let contentNode = null;
    if (fallbackNode && fallbackNode.nodeType === 1) {
      contentNode = fallbackNode.matches && fallbackNode.matches(".a-TreeView-content")
        ? fallbackNode
        : (fallbackNode.querySelector ? fallbackNode.querySelector(".a-TreeView-content") : null);
    }

    if (!contentNode) {
      const match = Array.from(document.querySelectorAll("#t_TreeNav li, #t_TreeNav .a-TreeView-content, #t_TreeNav .a-TreeView-label")).find((node) => {
        return getAskOracleConversationIdFromNavNode(node) === targetConversationId;
      });
      if (match) {
        contentNode = match.matches && match.matches(".a-TreeView-content")
          ? match
          : (match.closest ? match.closest(".a-TreeView-content") : null);
      }
    }

    if (!contentNode) return false;
    moveAskOracleConversationNavNodeToPinned(contentNode);
    return true;
  };

  if (tryMove()) return;
  [80, 180, 320, 600, 1000].forEach((delayMs) => {
    setTimeout(function() { tryMove(); }, delayMs);
  });
}

function removeAskOracleConversationNavNodes(conversationId) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;
  if (
    askOracleActiveHistoryActionMenu &&
    String(askOracleActiveHistoryActionMenu.conversationId || "") === targetConversationId
  ) {
    closeAskOracleHistoryActionMenu();
  }
  const subtree = getAskOracleHistoryNavSubtree() || document.getElementById("t_TreeNav");
  if (!subtree) return;
  const nodes = Array.from(subtree.querySelectorAll("[data-conv-id], [data-conversation-id], li"));
  const liToRemove = new Set();
  nodes.forEach((node) => {
    const nodeConversationId = getAskOracleConversationIdFromNavNode(node);
    if (!nodeConversationId || nodeConversationId !== targetConversationId) return;
    const li = node.closest ? node.closest("li") : null;
    if (li) liToRemove.add(li);
  });
  liToRemove.forEach((li) => {
    try { li.remove(); } catch (e) {}
  });
}

function deleteAskOracleConversation(conversationId, triggerNode) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;

  showAppConfirmDialog(
    "Are you sure you want to delete this chat?",
    { title: "Delete Chat", confirmLabel: "Delete", cancelLabel: "Cancel" }
  ).then((confirmed) => {
    if (!confirmed) return;
    if (!(window.apex && apex.server && typeof apex.server.process === "function")) return;

    apex.server.process(
      DELETE_CONVERSATION_PROCESS_NAME,
      { x01: targetConversationId },
      {
        dataType: "json",
        success: function(pData) {
          const status = String((pData && pData.status) || "").toLowerCase();
          if (status && status !== "success" && status !== "ok") {
            apex.message.clearErrors();
            apex.message.showErrors([{
              type: "error",
              location: "page",
              message: String((pData && pData.message) || "Unable to delete chat."),
              unsafe: false
            }]);
            return;
          }

          forgetAskOracleHistoryNavEntriesForConversation(targetConversationId);
          removeAskOracleConversationNavNodes(targetConversationId);
          if (triggerNode && triggerNode.closest) {
            const li = triggerNode.closest("li");
            if (li) {
              try { li.remove(); } catch (e) {}
            }
          }

          if (getAskOracleCurrentConversationId() === targetConversationId) {
            askOracleStartNewChat();
          } else {
            syncAskOracleConversationNavSelection();
          }
        },
        error: function(xhr) {
          const responseText = String((xhr && xhr.responseText) || "");
          const fallbackMessage = responseText || `Unable to delete chat. Ensure AJAX process '${DELETE_CONVERSATION_PROCESS_NAME}' exists.`;
          apex.message.clearErrors();
          apex.message.showErrors([{
            type: "error",
            location: "page",
            message: fallbackMessage.length > 260 ? `${fallbackMessage.slice(0, 260)}...` : fallbackMessage,
            unsafe: false
          }]);
        }
      }
    );
  });
}

function updateAskOracleConversationTitleInNav(conversationId, newTitle) {
  const targetConversationId = String(conversationId || "").trim();
  const fullNextTitle = normalizeAskOracleHistoryNavFullLabel(newTitle);
  const nextTitle = normalizeAskOracleHistoryNavLabel(fullNextTitle);
  if (!targetConversationId || !nextTitle) return;
  const treeRoot = document.getElementById("t_TreeNav");
  if (!treeRoot) return;
  treeRoot.querySelectorAll(".a-TreeView-content").forEach((content) => {
    const nodeConversationId = getAskOracleConversationIdFromNavNode(content);
    if (!nodeConversationId || nodeConversationId !== targetConversationId) return;
    const label = content.querySelector(".a-TreeView-label");
    if (!label) return;
    syncAskOracleHistoryLabelNode(label, fullNextTitle);
  });
}

function editAskOracleConversationTitle(conversationId, triggerNode) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) return;
  closeAskOracleHistoryActionMenu();
  const content = triggerNode && triggerNode.closest
    ? (triggerNode.closest(".a-TreeView-content") || triggerNode)
    : triggerNode;
  const labelNode = content && content.querySelector ? content.querySelector(".a-TreeView-label") : null;
  if (!content || !labelNode) return;

  const existingInput = document.querySelector("#t_TreeNav .ask-oracle-history-inline-title-input");
  if (existingInput && existingInput.getAttribute("data-conversation-id") === targetConversationId) {
    try {
      existingInput.focus({ preventScroll: true });
      const len = String(existingInput.value || "").length;
      if (typeof existingInput.setSelectionRange === "function") {
        existingInput.setSelectionRange(len, len);
      }
    } catch (e) {}
    return;
  }
  if (existingInput) {
    const existingContent = existingInput.closest(".a-TreeView-content");
    const existingLabel = existingContent ? existingContent.querySelector(".a-TreeView-label") : null;
    const existingSaveBtn = existingContent ? existingContent.querySelector(".ask-oracle-history-inline-title-save") : null;
    if (existingLabel) existingLabel.style.removeProperty("display");
    if (existingContent) existingContent.classList.remove("ask-oracle-title-editing");
    if (existingSaveBtn) {
      try { existingSaveBtn.remove(); } catch (e) {}
    }
    try { existingInput.remove(); } catch (e) {}
  }

  const rawCandidates = [
    labelNode.textContent,
    labelNode.innerText,
    labelNode.getAttribute("title"),
    labelNode.getAttribute("aria-label"),
    labelNode.getAttribute("data-label"),
    labelNode.getAttribute("data-title"),
    content.getAttribute("data-label"),
    content.getAttribute("data-title")
  ];
  const currentTitleRaw = rawCandidates
    .map((value) => String(value || "").replace(/\s+/g, " ").trim())
    .find((value) => !!value) || "";
  const fallbackTitle = targetConversationId
    ? `Conversation ${targetConversationId.slice(0, 12)}`
    : "Conversation";
  const currentTitle = currentTitleRaw || normalizeAskOracleHistoryNavLabel(labelNode.textContent || "") || fallbackTitle;
  labelNode.style.setProperty("display", "none", "important");
  content.classList.add("ask-oracle-title-editing");

  const input = document.createElement("input");
  input.type = "text";
  input.className = "ask-oracle-history-inline-title-input";
  input.value = currentTitleRaw || currentTitle;
  input.setAttribute("value", currentTitleRaw || currentTitle);
  input.setAttribute("maxlength", "110");
  input.setAttribute("aria-label", "Edit conversation title");
  input.setAttribute("data-conversation-id", targetConversationId);
  content.insertBefore(input, labelNode);
  const saveBtn = document.createElement("button");
  saveBtn.type = "button";
  saveBtn.className = "ask-oracle-history-inline-title-save";
  saveBtn.setAttribute("title", "Save title");
  saveBtn.setAttribute("aria-label", "Save title");
  saveBtn.innerHTML = '<span class="fa fa-check" aria-hidden="true"></span>';
  content.insertBefore(saveBtn, labelNode);
  askOracleActiveInlineTitleEditConversationId = targetConversationId;

  const convItem = (window.apex && typeof apex.item === "function") ? apex.item("P1_CONV_ID") : null;
  const previousConversationId = convItem && typeof convItem.getValue === "function"
    ? String(convItem.getValue() || "").trim()
    : "";
  if (convItem && typeof convItem.setValue === "function") convItem.setValue(targetConversationId);

  const restoreConversationItem = function() {
    if (!convItem || typeof convItem.setValue !== "function") return;
    if (!previousConversationId || previousConversationId === targetConversationId) return;
    if (getAskOracleCurrentConversationId() === targetConversationId) return;
    convItem.setValue(previousConversationId);
  };

  const restoreInlineUi = function(nextLabelText) {
    if (nextLabelText) labelNode.textContent = nextLabelText;
    content.classList.remove("ask-oracle-title-editing");
    labelNode.style.removeProperty("display");
    try { saveBtn.remove(); } catch (e) {}
    try { input.remove(); } catch (e) {}
    askOracleActiveInlineTitleEditConversationId = "";
  };

  const commitTitle = function() {
    if (input.dataset.state === "saving") return;
    const rawTitle = String(input.value || "");
    if (rawTitle.replace(/\s+/g, "") === "") {
      restoreInlineUi(currentTitle);
      restoreConversationItem();
      return;
    }
    const nextTitle = normalizeAskOracleHistoryNavLabel(rawTitle);
    if (!nextTitle || nextTitle === currentTitle) {
      restoreInlineUi(currentTitle);
      restoreConversationItem();
      return;
    }

    input.dataset.state = "saving";
    input.disabled = true;

    apex.server.process(
      EDIT_CONVERSATION_TITLE_PROCESS_NAME,
      { pageItems: "#P1_CONV_ID", x01: nextTitle },
      {
        dataType: "text",
        success: function() {
          restoreConversationItem();
          updateAskOracleConversationTitleInNav(targetConversationId, nextTitle);
          restoreInlineUi(nextTitle);
          if (window.apex && apex.message && typeof apex.message.showPageSuccess === "function") {
            apex.message.showPageSuccess("Conversation Title Updated");
          }
        },
        error: function(xhr) {
          restoreConversationItem();
          restoreInlineUi(currentTitle);
          const responseText = String((xhr && xhr.responseText) || "");
          const fallbackMessage = responseText || `Unable to edit title. Ensure AJAX process '${EDIT_CONVERSATION_TITLE_PROCESS_NAME}' exists.`;
          if (window.apex && apex.message && typeof apex.message.clearErrors === "function") {
            apex.message.clearErrors();
          }
          if (window.apex && apex.message && typeof apex.message.showErrors === "function") {
            apex.message.showErrors([{
              type: "error",
              location: "page",
              message: fallbackMessage.length > 260 ? `${fallbackMessage.slice(0, 260)}...` : fallbackMessage,
              unsafe: false
            }]);
          }
        }
      }
    );
  };

  const absorbInlineTitlePointerEvent = function(event) {
    if (!event) return;
    if (typeof event.stopImmediatePropagation === "function") {
      event.stopImmediatePropagation();
    } else if (typeof event.stopPropagation === "function") {
      event.stopPropagation();
    }
  };
  input.addEventListener("pointerdown", absorbInlineTitlePointerEvent, true);
  input.addEventListener("mousedown", absorbInlineTitlePointerEvent, true);
  input.addEventListener("click", absorbInlineTitlePointerEvent, true);

  input.addEventListener("keydown", function(event) {
    if (!event) return;
    if (event.key === "Enter") {
      event.preventDefault();
      event.stopPropagation();
      commitTitle();
      return;
    }
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      restoreInlineUi(currentTitle);
      restoreConversationItem();
    }
  });
  const handleSaveTrigger = function(event) {
    if (!event) return;
    event.preventDefault();
    event.stopPropagation();
    commitTitle();
  };
  saveBtn.addEventListener("pointerdown", function(event) {
    if (!event) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);
  saveBtn.addEventListener("mousedown", function(event) {
    if (!event) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);
  saveBtn.addEventListener("click", handleSaveTrigger, true);
  input.addEventListener("blur", function() {
    if (input.dataset.state === "saving") return;
  });

  setTimeout(() => {
    try {
      input.focus({ preventScroll: true });
      const len = String(input.value || "").length;
      if (typeof input.setSelectionRange === "function") {
        input.setSelectionRange(len, len);
      }
    } catch (e) {}
  }, 0);
}

function pinAskOracleConversation(conversationId, triggerNode) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) return;

  const convItem = (window.apex && typeof apex.item === "function") ? apex.item("P1_CONV_ID") : null;
  const previousConversationId = convItem && typeof convItem.getValue === "function"
    ? String(convItem.getValue() || "").trim()
    : "";
  if (convItem && typeof convItem.setValue === "function") {
    convItem.setValue(targetConversationId);
  }

  const restoreConversationItem = function() {
    if (!convItem || typeof convItem.setValue !== "function") return;
    if (!previousConversationId || previousConversationId === targetConversationId) return;
    if (getAskOracleCurrentConversationId() === targetConversationId) return;
    convItem.setValue(previousConversationId);
  };

  apex.server.process(
    PIN_CONVERSATION_PROCESS_NAME,
    { pageItems: "#P1_CONV_ID" },
    {
      dataType: "text",
      success: function() {
        restoreConversationItem();
        syncAskOraclePinnedConversationRetention(targetConversationId);
        if (triggerNode && triggerNode.querySelector) {
          const btn = triggerNode.querySelector(`.${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}`);
          if (btn) {
            btn.classList.add("is-pinned");
            btn.setAttribute("title", "Unpin chat");
            btn.setAttribute("aria-label", "Unpin chat");
            const icon = btn.querySelector(".fa");
            if (icon) icon.className = "fa fa-thumb-tack";
          }
        }
        moveAskOracleConversationNavNodeToPinned(triggerNode);
        ensureAskOracleConversationVisibleInPinned(targetConversationId, triggerNode);
        bindAskOracleConversationDeleteActions();
        if (window.apex && apex.message && typeof apex.message.showPageSuccess === "function") {
          apex.message.showPageSuccess("Conversation Pinned");
        }
      },
      error: function(xhr) {
        restoreConversationItem();
        const responseText = String((xhr && xhr.responseText) || "");
        if (/ORA-00001|unique constraint/i.test(responseText)) {
          syncAskOraclePinnedConversationRetention(targetConversationId);
          if (triggerNode && triggerNode.querySelector) {
            const btn = triggerNode.querySelector(`.${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}`);
            if (btn) {
              btn.classList.add("is-pinned");
              btn.setAttribute("title", "Unpin chat");
              btn.setAttribute("aria-label", "Unpin chat");
              const icon = btn.querySelector(".fa");
              if (icon) icon.className = "fa fa-thumb-tack";
            }
          }
          moveAskOracleConversationNavNodeToPinned(triggerNode);
          ensureAskOracleConversationVisibleInPinned(targetConversationId, triggerNode);
          bindAskOracleConversationDeleteActions();
          if (window.apex && apex.message && typeof apex.message.showPageSuccess === "function") {
            apex.message.showPageSuccess("Conversation Pinned");
          }
          return;
        }
        const fallbackMessage = responseText || `Unable to pin chat. Ensure AJAX process '${PIN_CONVERSATION_PROCESS_NAME}' exists.`;
        if (window.apex && apex.message && typeof apex.message.clearErrors === "function") {
          apex.message.clearErrors();
        }
        if (window.apex && apex.message && typeof apex.message.showErrors === "function") {
          apex.message.showErrors([{
            type: "error",
            location: "page",
            message: fallbackMessage.length > 260 ? `${fallbackMessage.slice(0, 260)}...` : fallbackMessage,
            unsafe: false
          }]);
        }
      }
    }
  );
}

function syncAskOraclePinnedConversationRetention(conversationId) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) return;
  try {
    apex.server.process(
      PINNED_CONVERSATION_RETENTION_PROCESS_NAME,
      { x01: targetConversationId, pageItems: "#P1_CONV_ID" },
      {
        dataType: "json",
        success: function() {},
        error: function() {}
      }
    );
  } catch (e) {}
}

function unpinAskOracleConversation(conversationId, triggerNode) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return;
  if (!(window.apex && apex.server && typeof apex.server.process === "function")) return;

  const convItem = (window.apex && typeof apex.item === "function") ? apex.item("P1_CONV_ID") : null;
  const previousConversationId = convItem && typeof convItem.getValue === "function"
    ? String(convItem.getValue() || "").trim()
    : "";
  if (convItem && typeof convItem.setValue === "function") {
    convItem.setValue(targetConversationId);
  }

  const restoreConversationItem = function() {
    if (!convItem || typeof convItem.setValue !== "function") return;
    if (!previousConversationId || previousConversationId === targetConversationId) return;
    if (getAskOracleCurrentConversationId() === targetConversationId) return;
    convItem.setValue(previousConversationId);
  };

  const unpinProcessCandidates = [
    String(UNPIN_CONVERSATION_PROCESS_NAME || "").trim(),
    String(UNPIN_CONVERSATION_PROCESS_NAME_LEGACY || "").trim()
  ].filter((name, index, list) => !!name && list.indexOf(name) === index);

  const runUnpinProcess = function(candidateIndex) {
    const processName = unpinProcessCandidates[candidateIndex] || UNPIN_CONVERSATION_PROCESS_NAME;
    apex.server.process(
      processName,
      { pageItems: "#P1_CONV_ID" },
      {
        dataType: "text",
        success: function() {
          restoreConversationItem();
          if (triggerNode && triggerNode.querySelector) {
            const btn = triggerNode.querySelector(`.${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}`);
            if (btn) {
              btn.classList.remove("is-pinned");
              btn.setAttribute("title", "Pin chat");
              btn.setAttribute("aria-label", "Pin chat");
              const icon = btn.querySelector(".fa");
              if (icon) icon.className = "fa fa-thumb-tack fa-rotate-90";
            }
          }
          moveAskOracleConversationNavNodeToHistory(triggerNode);
          bindAskOracleConversationDeleteActions();
          if (window.apex && apex.message && typeof apex.message.showPageSuccess === "function") {
            apex.message.showPageSuccess("Conversation Unpinned");
          }
        },
        error: function(xhr) {
          restoreConversationItem();
          const responseText = String((xhr && xhr.responseText) || "");
          const looksMissingProcess = /ajax process|not found|does not exist|unable to find|apex\.server\.process/i.test(responseText);
          if (looksMissingProcess && candidateIndex + 1 < unpinProcessCandidates.length) {
            runUnpinProcess(candidateIndex + 1);
            return;
          }
          const fallbackMessage = responseText || `Unable to unpin chat. Ensure AJAX process '${processName}' exists.`;
          if (window.apex && apex.message && typeof apex.message.clearErrors === "function") {
            apex.message.clearErrors();
          }
          if (window.apex && apex.message && typeof apex.message.showErrors === "function") {
            apex.message.showErrors([{
              type: "error",
              location: "page",
              message: fallbackMessage.length > 260 ? `${fallbackMessage.slice(0, 260)}...` : fallbackMessage,
              unsafe: false
            }]);
          }
        }
      }
    );
  };

  runUnpinProcess(0);
}

function wireAskOracleConversationPinAction(node) {
  if (!node || node.nodeType !== 1) return;
  const content = node.matches && node.matches(".a-TreeView-content")
    ? node
    : (node.querySelector ? node.querySelector(".a-TreeView-content") : null);
  if (!content) return;
  let conversationId = getAskOracleConversationIdFromNavNode(content);
  if (!conversationId) {
    const navLink = content.querySelector("a, button, .a-TreeView-label");
    conversationId = getAskOracleConversationIdFromNavNode(navLink);
  }
  if (!conversationId) return;
  if (isAskOracleNewChatNavLink(content)) return;
  Array.from(content.children || []).forEach((child) => {
    if (!child || !child.classList) return;
    if (!child.classList.contains("fa")) return;
    if (child.classList.contains("fa-history")) return;
    if (child.classList.contains("fa-map-pin-circle-o")) return;
    try { child.remove(); } catch (e) {}
  });

  ensureAskOracleHistoryDeleteActionCss();
  content.querySelectorAll(`.${ASK_ORACLE_HISTORY_EDIT_BTN_CLASS}, .${ASK_ORACLE_HISTORY_DELETE_BTN_CLASS}`).forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  let btn = content.querySelector(`.${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}`);
  if (!btn) {
    btn = document.createElement("button");
    btn.type = "button";
    btn.className = ASK_ORACLE_HISTORY_PIN_BTN_CLASS;
    btn.setAttribute("title", "Pin chat");
    btn.setAttribute("aria-label", "Pin chat");
    btn.innerHTML = '<span class="fa fa-thumb-tack fa-rotate-90" aria-hidden="true"></span>';
    const moreBtn = content.querySelector(`.${ASK_ORACLE_HISTORY_MORE_BTN_CLASS}`);
    if (moreBtn) {
      content.insertBefore(btn, moreBtn);
    } else {
      content.appendChild(btn);
    }
  }

  btn.setAttribute("data-conv-id", conversationId);
  const currentLi = content.closest ? content.closest("li") : null;
  const currentTopLevel = currentLi && currentLi.parentElement ? currentLi.parentElement.closest("li.a-TreeView-node--topLevel") : null;
  const currentTopLevelLabel = currentTopLevel ? currentTopLevel.querySelector(".a-TreeView-content .a-TreeView-label") : null;
  const currentTopLevelLabelText = String((currentTopLevelLabel && currentTopLevelLabel.textContent) || "").trim().toLowerCase();
  const isPinnedMenuEntry = currentTopLevelLabelText === "pinned" || currentTopLevelLabelText.indexOf("pinned") >= 0
    || isAskOraclePinnedNavContentNode(content);
  btn.classList.toggle("is-pinned", isPinnedMenuEntry);
  btn.setAttribute("title", isPinnedMenuEntry ? "Unpin chat" : "Pin chat");
  btn.setAttribute("aria-label", isPinnedMenuEntry ? "Unpin chat" : "Pin chat");
  const icon = btn.querySelector(".fa");
  if (icon) icon.className = isPinnedMenuEntry ? "fa fa-thumb-tack" : "fa fa-thumb-tack fa-rotate-90";
  if (btn.dataset.askOraclePinBound === "true") return;
  btn.dataset.askOraclePinBound = "true";
  btn.addEventListener("click", function(event) {
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
    if (event && typeof event.stopPropagation === "function") event.stopPropagation();
    if (btn.classList.contains("is-pinned")) {
      unpinAskOracleConversation(conversationId, content);
    } else {
      pinAskOracleConversation(conversationId, content);
    }
  }, true);
}

function wireAskOracleConversationDeleteAction(node) {
  if (!node || node.nodeType !== 1) return;
  const content = node.matches && node.matches(".a-TreeView-content")
    ? node
    : (node.querySelector ? node.querySelector(".a-TreeView-content") : null);
  if (!content) return;
  const conversationId = getAskOracleConversationIdFromNavNode(content);
  if (!conversationId) return;
  if (isAskOracleNewChatNavLink(content)) return;

  ensureAskOracleHistoryDeleteActionCss();
  content.querySelectorAll(`.${ASK_ORACLE_HISTORY_EDIT_BTN_CLASS}, .${ASK_ORACLE_HISTORY_DELETE_BTN_CLASS}`).forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  let btn = content.querySelector(`.${ASK_ORACLE_HISTORY_MORE_BTN_CLASS}`);
  if (!btn) {
    btn = document.createElement("button");
    btn.type = "button";
    btn.className = ASK_ORACLE_HISTORY_MORE_BTN_CLASS;
    btn.setAttribute("title", "Conversation actions");
    btn.setAttribute("aria-label", "Conversation actions");
    btn.setAttribute("aria-haspopup", "menu");
    btn.setAttribute("aria-expanded", "false");
    btn.innerHTML = '<span class="fa fa-ellipsis-h" aria-hidden="true"></span>';
    content.appendChild(btn);
  }

  btn.setAttribute("data-conv-id", conversationId);
  if (btn.dataset.askOracleMoreBound === "true") return;
  btn.dataset.askOracleMoreBound = "true";
  btn.addEventListener("click", function(event) {
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
    if (event && typeof event.stopPropagation === "function") event.stopPropagation();
    openAskOracleHistoryActionMenu(conversationId, btn);
  }, true);
}

function bindAskOracleConversationDeleteActions() {
  const subtree = document.getElementById("t_TreeNav");
  if (!subtree) return;
  subtree.querySelectorAll(".a-TreeView-content").forEach((content) => {
    wireAskOracleConversationPinAction(content);
    wireAskOracleConversationDeleteAction(content);
  });
}

function markAskOracleHistoryEntryAsNew(li, content, link) {
  return;
}

function appendAskOracleConversationHistoryNavEntry(conversationId, conversationData) {
  const targetConversationId = String(conversationId || "").trim();
  if (!targetConversationId) return false;
  const source = conversationData && typeof conversationData === "object" ? conversationData : {};

  const subtree = getAskOracleExistingHistoryNavSubtree();
  if (!subtree) return false;

  const existingLabelsForConversation = [];
  subtree.querySelectorAll(".a-TreeView-label").forEach((labelNode) => {
    if (!labelNode) return;
    const nodeConversationId = getAskOracleConversationIdFromNavNode(labelNode);
    if (!nodeConversationId || nodeConversationId !== targetConversationId) return;
    existingLabelsForConversation.push(normalizeAskOracleHistoryNavLabel(labelNode.textContent || ""));
  });

  let descriptionText = getAskOracleHistoryDescriptionText(source);
  if (!descriptionText || String(descriptionText).toLowerCase() === "new conversation") {
    const alreadyHasMeaningfulDescription = existingLabelsForConversation.some((value) => {
      return !isAskOracleHistoryPlaceholderLabel(value, targetConversationId);
    });
    if (alreadyHasMeaningfulDescription) return false;
    descriptionText = getAskOracleHistoryFallbackText(source);
  }
  if (!descriptionText || String(descriptionText).toLowerCase() === "new conversation") {
    return false;
  }

  const entryKey = buildAskOracleHistoryEntryKey(targetConversationId, { ...source, description: descriptionText });
  if (!entryKey) return false;
  if (askOracleHistoryNavInsertedEntryByKey[entryKey]) {
    if (hasAskOracleHistoryEntryNode(entryKey, subtree)) return true;
    delete askOracleHistoryNavInsertedEntryByKey[entryKey];
  }

  const normalizedDescription = normalizeAskOracleHistoryNavLabel(descriptionText).toLowerCase();
  const storedConversationData = { ...source, description: descriptionText };
  rememberAskOracleHistoryNavEntry(entryKey, targetConversationId, storedConversationData);

  const existingSameDescriptionNode = Array.from(
    subtree.querySelectorAll("[data-conv-id], [data-conversation-id], .a-TreeView-content, .a-TreeView-label, li")
  ).find((node) => {
    if (!node) return false;
    const nodeConversationId = getAskOracleConversationIdFromNavNode(node);
    if (!nodeConversationId || nodeConversationId !== targetConversationId) return false;
    const labelNode = node.matches && node.matches(".a-TreeView-label")
      ? node
      : (node.querySelector ? node.querySelector(".a-TreeView-label") : null);
    const labelValue = normalizeAskOracleHistoryNavLabel(labelNode ? labelNode.textContent : "");
    return String(labelValue || "").toLowerCase() === normalizedDescription;
  });
  if (existingSameDescriptionNode) {
    const existingLi = existingSameDescriptionNode.closest ? existingSameDescriptionNode.closest("li") : null;
    if (existingLi && subtree.firstElementChild !== existingLi) {
      subtree.insertBefore(existingLi, subtree.firstElementChild);
    }
    askOracleHistoryNavInsertedEntryByKey[entryKey] = true;
    return true;
  }

  const existingByKey = Array.from(
    subtree.querySelectorAll("[data-ask-oracle-history-entry-key]")
  ).find((node) => {
    return String(node.getAttribute("data-ask-oracle-history-entry-key") || "") === entryKey;
  });
  if (existingByKey) {
    const existingLi = existingByKey.closest ? existingByKey.closest("li") : null;
    if (existingLi && subtree.firstElementChild !== existingLi) {
      subtree.insertBefore(existingLi, subtree.firstElementChild);
    }
    askOracleHistoryNavInsertedEntryByKey[entryKey] = true;
    return true;
  }

  const labelText = normalizeAskOracleHistoryNavLabel(descriptionText);
  const fullLabelText = normalizeAskOracleHistoryNavFullLabel(descriptionText) || labelText;
  const safeIdSuffix = `${Date.now()}-${targetConversationId}`.replace(/[^a-zA-Z0-9_-]+/g, "-").slice(0, 100);
  const li = document.createElement("li");
  li.id = `ask-oracle-history-${safeIdSuffix}`;
  li.className = "a-TreeView-node a-TreeView-node--leaf";
  li.setAttribute("role", "none");
  li.setAttribute("data-conv-id", targetConversationId);
  li.setAttribute("data-conversation-id", targetConversationId);
  li.setAttribute("data-ask-oracle-history-entry-key", entryKey);

  const row = document.createElement("div");
  row.className = "a-TreeView-row";
  row.setAttribute("role", "none");
  row.setAttribute("data-conv-id", targetConversationId);
  row.setAttribute("data-conversation-id", targetConversationId);
  row.setAttribute("data-ask-oracle-history-entry-key", entryKey);

  const content = document.createElement("div");
  content.className = "a-TreeView-content";
  content.setAttribute("role", "none");
  content.setAttribute("data-conv-id", targetConversationId);
  content.setAttribute("data-conversation-id", targetConversationId);
  content.setAttribute("data-ask-oracle-history-entry-key", entryKey);

  const link = document.createElement("a");
  link.className = "a-TreeView-label";
  link.setAttribute("href", "javascript:void(0);");
  link.setAttribute("role", "treeitem");
  link.setAttribute("tabindex", "-1");
  link.setAttribute("aria-level", "2");
  link.setAttribute("aria-selected", "false");
  link.setAttribute("data-conv-id", targetConversationId);
  link.setAttribute("data-conversation-id", targetConversationId);
  link.setAttribute("data-ask-oracle-history-entry-key", entryKey);
  link.textContent = labelText;
  syncAskOracleHistoryLabelNode(link, fullLabelText);
  content.appendChild(link);

  row.appendChild(content);
  li.appendChild(row);
  subtree.insertBefore(li, subtree.firstElementChild);

  wireAskOracleConversationElement(li);
  wireAskOracleConversationElement(row);
  wireAskOracleConversationElement(content);
  wireAskOracleConversationElement(link);
  wireAskOracleConversationPinAction(content);
  wireAskOracleConversationDeleteAction(content);
  markAskOracleHistoryEntryAsNew(li, content, link);
  askOracleHistoryNavInsertedEntryByKey[entryKey] = true;
  return true;
}

function refreshAskOracleConversationHistoryNav(conversationId, conversationData) {
  const targetConversationId = String(conversationId || getAskOracleCurrentConversationId() || "").trim();
  if (!targetConversationId) return false;
  if (askOracleConversationNavRefreshInFlight) return false;

  askOracleConversationNavRefreshInFlight = true;
  let refreshed = false;

  try {
    refreshed = appendAskOracleConversationHistoryNavEntry(targetConversationId, conversationData);
    replayAskOracleHistoryNavEntries();
    ensureAskOracleHistoryNavExpanded();
    refreshed = hasAskOracleHistoryEntryNode(
      buildAskOracleHistoryEntryKey(targetConversationId, conversationData),
      getAskOracleExistingHistoryNavSubtree()
    ) || refreshed;
  } catch (e) {
    console.warn("Unable to refresh conversation history tree.", e);
  } finally {
    askOracleConversationNavRefreshInFlight = false;
    syncAskOracleConversationNavSelection(targetConversationId);
  }

  return refreshed;
}

function tryProcessPendingAskOracleHistoryNavRefreshes() {
  const keys = Object.keys(askOraclePendingHistoryNavEntryByKey || {});
  if (!keys.length) return;
  keys.forEach((entryKey) => {
    const pendingEntry = askOraclePendingHistoryNavEntryByKey[entryKey];
    if (!pendingEntry) return;
    if (askOracleHistoryNavInsertedEntryByKey[entryKey]) {
      delete askOraclePendingHistoryNavEntryByKey[entryKey];
      return;
    }
    const refreshed = refreshAskOracleConversationHistoryNav(
      pendingEntry.conversationId,
      pendingEntry.conversationData
    );
    if (refreshed) {
      askOracleHistoryNavInsertedEntryByKey[entryKey] = true;
      delete askOraclePendingHistoryNavEntryByKey[entryKey];
    }
  });
}

function scheduleAskOracleConversationHistoryNavRefresh(conversationId, conversationData) {
  const key = String(conversationId || "").trim();
  if (!key) return false;
  const entryKey = buildAskOracleHistoryEntryKey(key, conversationData);
  if (!entryKey) return false;
  if (askOracleHistoryNavInsertedEntryByKey[entryKey]) return false;

  askOraclePendingHistoryNavEntryByKey[entryKey] = {
    conversationId: key,
    conversationData: conversationData && typeof conversationData === "object" ? conversationData : {}
  };

  const delays = [80, 260, 640, 1300, 2200, 3600];
  delays.forEach((delay) => {
    setTimeout(function() {
      if (askOracleHistoryNavInsertedEntryByKey[entryKey]) return;
      const pendingEntry = askOraclePendingHistoryNavEntryByKey[entryKey];
      if (!pendingEntry) return;
      const refreshed = refreshAskOracleConversationHistoryNav(
        pendingEntry.conversationId,
        pendingEntry.conversationData
      );
      if (refreshed) {
        askOracleHistoryNavInsertedEntryByKey[entryKey] = true;
        delete askOraclePendingHistoryNavEntryByKey[entryKey];
      }
    }, delay);
  });
  return true;
}

function stabilizeAskOracleLeftNavStructure(conversationId) {
  const targetConversationId = String(conversationId || "").trim();
  const run = function(fn) {
    try { fn(); } catch (e) {}
  };

  const doStabilize = function() {
    run(bindAskOracleNewChatDirectHandlers);
    run(bindAskOracleConversationDirectHandlers);
    run(bindAskOracleConversationDeleteActions);
    if (targetConversationId) {
      run(function() { syncAskOracleConversationNavSelection(targetConversationId); });
    }
  };

  doStabilize();
  [90, 260, 640].forEach(function(delay) {
    setTimeout(doStabilize, delay);
  });
}

function collapseLeftNavigationForEditor() {
  if (CODE_EDITOR_PRESERVE_LEFT_NAV) return false;
  const strictNavBtn = document.getElementById("t_Button_navControl");
  if (strictNavBtn && String(strictNavBtn.getAttribute("aria-expanded") || "").toLowerCase() === "true") {
    try {
      strictNavBtn.click();
      codeEditorCollapsedLeftNav = true;
    } catch (e) {}
  }

  const navToggleBtn = getLeftNavigationToggleButton();
  const ariaExpanded = isLeftNavigationToggleExpanded(navToggleBtn);
  if (isLeftNavigationCollapsedNow()) return true;

  setLeftNavExpandedPreference(false);
  if (collapseLeftNavViaApexThemeApi()) {
    codeEditorCollapsedLeftNav = true;
  }

  if (navToggleBtn && ariaExpanded === true) {
    codeEditorCollapsedLeftNav = true;
    try { navToggleBtn.click(); } catch (e) {}
  } else if (navToggleBtn) {
    try { navToggleBtn.click(); } catch (e) {}
  }

  setTimeout(() => {
    const retryExpanded = isLeftNavigationToggleExpanded(navToggleBtn);
    if (retryExpanded === true || !isLeftNavigationCollapsedNow()) {
      if (navToggleBtn) {
        if (retryExpanded === true) {
          codeEditorCollapsedLeftNav = true;
        }
        try { navToggleBtn.click(); } catch (e) {}
      }
      setTimeout(() => {
        const fallbackExpanded = isLeftNavigationToggleExpanded(navToggleBtn);
        if (fallbackExpanded === true || !isLeftNavigationCollapsedNow()) {
          setLeftNavigationCollapsedState(true);
          triggerNavResponsiveReflow();
        }
        if (fallbackExpanded === false || isLeftNavigationCollapsedNow()) {
          codeEditorCollapsedLeftNav = true;
        }
      }, 120);
    } else {
      codeEditorCollapsedLeftNav = true;
    }
  }, 140);
  setTimeout(triggerNavResponsiveReflow, 0);
  return isLeftNavigationCollapsedNow();
}

function restoreLeftNavigationAfterEditor() {
  if (CODE_EDITOR_PRESERVE_LEFT_NAV) return;
  codeEditorCollapsedLeftNav = false;

  setLeftNavExpandedPreference(true);
  expandLeftNavViaApexThemeApi();

  const navToggleBtn = getLeftNavigationToggleButton();
  if (navToggleBtn && isLeftNavigationCollapsedNow()) {
    try { navToggleBtn.click(); } catch (e) {}
  }
  setTimeout(() => {
    if (isLeftNavigationCollapsedNow() && navToggleBtn) {
      try { navToggleBtn.click(); } catch (e) {}
    }
    setTimeout(() => {
      if (isLeftNavigationCollapsedNow()) {
        setLeftNavigationCollapsedState(false);
        triggerNavResponsiveReflow();
      }
    }, 120);
  }, 140);
  setTimeout(triggerNavResponsiveReflow, 0);
}

function clearCodeEditorNavCollapseTimers() {
  if (!Array.isArray(codeEditorNavCollapseTimers) || codeEditorNavCollapseTimers.length === 0) return;
  codeEditorNavCollapseTimers.forEach((timerId) => {
    try { clearTimeout(timerId); } catch (e) {}
  });
  codeEditorNavCollapseTimers = [];
}

function scheduleCodeEditorNavCollapseRetry(delayMs) {
  const timerId = setTimeout(() => {
    codeEditorNavCollapseTimers = codeEditorNavCollapseTimers.filter((id) => id !== timerId);
    if (!document.body.classList.contains("code-editor-mode")) return;
    collapseLeftNavigationForEditor();
  }, Math.max(0, Number(delayMs) || 0));
  codeEditorNavCollapseTimers.push(timerId);
}

function triggerExpandNavigationMenuAction() {
  try {
    if (window.apex && apex.event && typeof apex.event.trigger === "function") {
      apex.event.trigger(document, "ExpandNavigationMenu");
      apex.event.trigger(window, "ExpandNavigationMenu");
    }
  } catch (e) {}

  try {
    if (window.apex && apex.jQuery) {
      apex.jQuery(document).trigger("ExpandNavigationMenu");
      apex.jQuery(window).trigger("ExpandNavigationMenu");
    }
  } catch (e) {}
}

function forceExpandLeftNavigationAfterEditorClose() {
  if (document.body.classList.contains("code-editor-mode")) return;

  const navEl = document.querySelector("#t_Body_nav, .t-Body-nav");

  getLeftNavigationClassTargets().forEach((el) => {
    if (!el || !el.classList) return;
    el.classList.remove("js-navCollapsed", "t-PageBody--hideLeft");
    el.classList.add("js-navExpanded");
  });

  setLeftNavExpandedPreference(true);
  expandLeftNavViaApexThemeApi();
  setLeftNavigationCollapsedState(false);

  const navToggleBtn = getLeftNavigationToggleButton();
  const ensureToggleExpanded = () => {
    const expanded = isLeftNavigationToggleExpanded(navToggleBtn);
    if (navToggleBtn && expanded !== true) {
      try { navToggleBtn.click(); } catch (e) {}
    }
  };

  ensureToggleExpanded();
  if (isLeftNavigationCollapsedNow()) {
    expandLeftNavViaApexThemeApi();
    setLeftNavigationCollapsedState(false);
    ensureToggleExpanded();
  }

  if (isLeftNavigationCollapsedNow()) {
    expandLeftNavViaApexThemeApi();
    setLeftNavigationCollapsedState(false);
    ensureToggleExpanded();
  }

  if (navEl) navEl.setAttribute("aria-hidden", "false");
  if (navToggleBtn) navToggleBtn.setAttribute("aria-expanded", "true");
  triggerExpandNavigationMenuAction();
  triggerNavResponsiveReflow();
}

function collapseTreeNavigationForEditor() {
  if (CODE_EDITOR_PRESERVE_LEFT_NAV) return;
  const treeNav = getApexTreeNavHandle();
  if (!treeNav) return;
  const hasExpandedNodes = treeNav.find("[aria-expanded='true'], .is-expanded, .a-TreeView-node--expanded").length > 0;
  if (!hasExpandedNodes) return;
  codeEditorCollapsedTreeNav = true;
  try {
    treeNav.treeView("collapseAll");
  } catch (e) {}
}

function restoreTreeNavigationAfterEditor() {
  if (CODE_EDITOR_PRESERVE_LEFT_NAV) return;
  if (!codeEditorCollapsedTreeNav) return;
  codeEditorCollapsedTreeNav = false;

  const treeNav = getApexTreeNavHandle();
  if (!treeNav) return;
  try {
    treeNav.treeView("expandAll");
  } catch (e) {}
}

function applyNavigationStateForEditorOpen() {
  clearCodeEditorNavCollapseTimers();
  codeEditorCollapsedLeftNav = false;
  if (CODE_EDITOR_PRESERVE_LEFT_NAV) {
    setLeftNavExpandedPreference(true);
    setLeftNavigationCollapsedState(false);
    triggerNavResponsiveReflow();
    return;
  }
  collapseLeftNavigationForEditor();
  collapseTreeNavigationForEditor();
  scheduleCodeEditorNavCollapseRetry(180);
  scheduleCodeEditorNavCollapseRetry(360);
}

function scheduleNavigationStateForEditorOpen(delayMs) {
  if (codeEditorOpenNavTimerId) {
    try { clearTimeout(codeEditorOpenNavTimerId); } catch (e) {}
    codeEditorOpenNavTimerId = null;
  }
  codeEditorOpenNavTimerId = setTimeout(() => {
    codeEditorOpenNavTimerId = null;
    if (!document.body.classList.contains("code-editor-mode")) return;
    applyNavigationStateForEditorOpen();
  }, Math.max(0, Number(delayMs) || 0));
}

function ensureCodeEditorPanel() {
  ensureCodeEditorPanelCss();
  let panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  if (
    panel &&
    (
      !panel.querySelector(`#${CODE_EDITOR_DIFF_WORKBENCH_ID}`) ||
      !panel.querySelector("#code-editor-run-status") ||
      !panel.querySelector("#code-editor-run-output")
    )
  ) {
    try { panel.remove(); } catch (e) {}
    panel = null;
  }
  if (panel) {
    const diffBtnExisting = panel.querySelector("#code-editor-diff-btn");
    if (diffBtnExisting && diffBtnExisting.dataset.bound !== "true") {
      diffBtnExisting.dataset.bound = "true";
      diffBtnExisting.addEventListener("click", function(event) {
        event.preventDefault();
        event.stopImmediatePropagation();
        openCodeEditorTabDiffPanel();
      }, true);
    }
    return panel;
  }

  panel = document.createElement("aside");
  panel.id = CODE_EDITOR_PANEL_ID;
  panel.innerHTML = `
    <div id="code-editor-resizer" class="code-editor-resizer" title="Drag to resize editor"></div>
    <div class="code-editor-header">
      <div id="code-editor-file-name" class="code-editor-file">response.txt</div>
      <div class="code-editor-actions">
        <button type="button" id="code-editor-diff-btn" title="Compare open tabs">Diff Tabs</button>
        <button type="button" id="code-editor-merge-btn" title="Merge compared tabs">Merge Tabs</button>
        <button type="button" id="code-editor-run-btn" title="Run in database">Run</button>
        <button type="button" id="code-editor-download-btn">Download</button>
        <button type="button" id="code-editor-close-btn">Close</button>
      </div>
    </div>
    <div class="code-editor-tabs">
      <div id="${CODE_EDITOR_TAB_LIST_ID}" class="code-editor-tab-list"></div>
    </div>
    <div class="code-editor-body">
      <div id="${CODE_EDITOR_ACE_ID}" class="code-editor-ace"></div>
      <textarea id="code-editor-textarea" class="code-editor-textarea" spellcheck="false"></textarea>
      <div id="${CODE_EDITOR_DIFF_WORKBENCH_ID}" class="code-editor-diff-workbench">
        <div class="code-editor-diff-workbench-card">
          <div class="code-editor-diff-workbench-title">Diff Workbench</div>
          <div class="code-editor-diff-workbench-fields">
            <div class="code-editor-diff-workbench-field">
              <label class="code-editor-diff-workbench-label" for="${CODE_EDITOR_DIFF_WORKBENCH_LEFT_ID}">Left tab</label>
              <select id="${CODE_EDITOR_DIFF_WORKBENCH_LEFT_ID}" class="code-editor-diff-workbench-select"></select>
            </div>
            <div class="code-editor-diff-workbench-field">
              <label class="code-editor-diff-workbench-label" for="${CODE_EDITOR_DIFF_WORKBENCH_RIGHT_ID}">Right tab</label>
              <select id="${CODE_EDITOR_DIFF_WORKBENCH_RIGHT_ID}" class="code-editor-diff-workbench-select"></select>
            </div>
            <div class="code-editor-diff-workbench-field code-editor-diff-workbench-show">
              <label class="code-editor-diff-workbench-label" for="${CODE_EDITOR_DIFF_WORKBENCH_COMPARE_ID}">Action</label>
              <button type="button" id="${CODE_EDITOR_DIFF_WORKBENCH_COMPARE_ID}">Show</button>
            </div>
          </div>
          <div id="${CODE_EDITOR_DIFF_WORKBENCH_ERROR_ID}" class="code-editor-diff-workbench-error" aria-live="polite"></div>
          <div class="code-editor-diff-workbench-note">Pick two tabs and click Show to render diff below.</div>
        </div>
      </div>
    </div>
    <div id="code-editor-run-status" class="code-editor-run-status is-warning" aria-live="polite">
      <div id="code-editor-run-status-title" class="code-editor-run-status-title">Run Status</div>
      <div id="code-editor-run-status-text" class="code-editor-run-status-text">Open a response and click Run to execute in database.</div>
    </div>
    <div id="code-editor-run-output" class="code-editor-run-output" aria-live="polite">
      <div id="code-editor-run-output-title" class="code-editor-run-output-title">Execution Output</div>
      <div class="code-editor-run-output-tabs">
        <button type="button" id="${CODE_EDITOR_RUN_OUTPUT_TAB_RESULT_ID}" class="code-editor-run-output-tab is-active">Result</button>
        <button type="button" id="${CODE_EDITOR_RUN_OUTPUT_TAB_LOG_ID}" class="code-editor-run-output-tab">Log</button>
      </div>
      <div id="code-editor-run-output-content" class="code-editor-run-output-content">
        <div id="${CODE_EDITOR_RUN_OUTPUT_RESULT_ID}" class="code-editor-run-output-pane is-active">Execution result appears here.</div>
        <div id="${CODE_EDITOR_RUN_OUTPUT_LOG_ID}" class="code-editor-run-output-pane">Run logs appear here.</div>
      </div>
    </div>
    <div id="code-editor-diff-wrap" class="code-editor-diff-wrap">
      <div class="code-editor-diff-toolbar">
        <div id="code-editor-diff-summary" class="code-editor-diff-summary"></div>
        <div id="code-editor-diff-tab-controls" class="code-editor-diff-tab-controls">
          <label>Left <select id="code-editor-diff-left-tab"></select></label>
          <label>Right <select id="code-editor-diff-right-tab"></select></label>
        </div>
        <div class="code-editor-diff-actions">
          <button type="button" id="code-editor-diff-merge-btn">Merge Tabs</button>
          <button type="button" id="code-editor-diff-accept-btn">Accept Latest</button>
          <button type="button" id="code-editor-diff-keep-btn">Keep Original</button>
          <button type="button" id="code-editor-diff-hide-btn">Hide Diff</button>
        </div>
      </div>
      <div id="code-editor-diff-content" class="code-editor-diff-content"></div>
    </div>
  `;

  document.body.appendChild(panel);
  bindCodeEditorResizer(panel);

  const closeBtn = document.getElementById("code-editor-close-btn");
  if (closeBtn) {
    closeBtn.addEventListener("click", closeCodeEditorPanel);
  }

  const runBtn = document.getElementById("code-editor-run-btn");
  if (runBtn) {
    runBtn.addEventListener("click", runEditorSqlFromEditor);
  }

  const downloadBtn = document.getElementById("code-editor-download-btn");
  if (downloadBtn) {
    downloadBtn.addEventListener("click", downloadEditorContentToFile);
  }

  const diffBtn = document.getElementById("code-editor-diff-btn");
  if (diffBtn && diffBtn.dataset.bound !== "true") {
    diffBtn.dataset.bound = "true";
    diffBtn.addEventListener("click", function(event) {
      event.preventDefault();
      event.stopImmediatePropagation();
      openCodeEditorTabDiffPanel();
    }, true);
  }

  const mergeBtn = document.getElementById("code-editor-merge-btn");
  if (mergeBtn) {
    mergeBtn.addEventListener("click", mergeCodeEditorTabDiff);
  }

  const acceptDiffBtn = document.getElementById("code-editor-diff-accept-btn");
  if (acceptDiffBtn) {
    acceptDiffBtn.addEventListener("click", acceptPendingCodeDiff);
  }

  const keepDiffBtn = document.getElementById("code-editor-diff-keep-btn");
  if (keepDiffBtn) {
    keepDiffBtn.addEventListener("click", keepOriginalCodeFromDiff);
  }

  const mergeDiffBtn = document.getElementById("code-editor-diff-merge-btn");
  if (mergeDiffBtn) {
    mergeDiffBtn.addEventListener("click", mergeCodeEditorTabDiff);
  }

  const hideDiffBtn = document.getElementById("code-editor-diff-hide-btn");
  if (hideDiffBtn) {
    hideDiffBtn.addEventListener("click", hideCodeDiffPanel);
  }

  const outputResultTabBtn = document.getElementById(CODE_EDITOR_RUN_OUTPUT_TAB_RESULT_ID);
  if (outputResultTabBtn && outputResultTabBtn.dataset.bound !== "true") {
    outputResultTabBtn.dataset.bound = "true";
    outputResultTabBtn.addEventListener("click", function() {
      setEditorRunOutputActiveTab("result");
    });
  }

  const outputLogTabBtn = document.getElementById(CODE_EDITOR_RUN_OUTPUT_TAB_LOG_ID);
  if (outputLogTabBtn && outputLogTabBtn.dataset.bound !== "true") {
    outputLogTabBtn.dataset.bound = "true";
    outputLogTabBtn.addEventListener("click", function() {
      setEditorRunOutputActiveTab("log");
    });
  }

  const leftDiffSelect = document.getElementById("code-editor-diff-left-tab");
  if (leftDiffSelect && leftDiffSelect.dataset.bound !== "true") {
    leftDiffSelect.dataset.bound = "true";
    leftDiffSelect.addEventListener("change", renderCodeEditorTabDiffFromSelectors);
  }

  const rightDiffSelect = document.getElementById("code-editor-diff-right-tab");
  if (rightDiffSelect && rightDiffSelect.dataset.bound !== "true") {
    rightDiffSelect.dataset.bound = "true";
    rightDiffSelect.addEventListener("change", renderCodeEditorTabDiffFromSelectors);
  }

  const diffWorkbenchCompareBtn = document.getElementById(CODE_EDITOR_DIFF_WORKBENCH_COMPARE_ID);
  if (diffWorkbenchCompareBtn && diffWorkbenchCompareBtn.dataset.bound !== "true") {
    diffWorkbenchCompareBtn.dataset.bound = "true";
    diffWorkbenchCompareBtn.addEventListener("click", applyCodeEditorDiffFromWorkbenchSelection);
  }

  const diffWorkbenchLeftEl = document.getElementById(CODE_EDITOR_DIFF_WORKBENCH_LEFT_ID);
  if (diffWorkbenchLeftEl && diffWorkbenchLeftEl.dataset.bound !== "true") {
    diffWorkbenchLeftEl.dataset.bound = "true";
    diffWorkbenchLeftEl.addEventListener("change", function() {
      setCodeEditorDiffWorkbenchError("");
      const panelEl = document.getElementById(CODE_EDITOR_PANEL_ID);
      if (panelEl) panelEl.classList.remove("diff-visible");
      const summaryEl = document.getElementById("code-editor-diff-summary");
      if (summaryEl) summaryEl.textContent = "";
      const contentEl = document.getElementById("code-editor-diff-content");
      if (contentEl) contentEl.innerHTML = "";
    });
  }

  const diffWorkbenchRightEl = document.getElementById(CODE_EDITOR_DIFF_WORKBENCH_RIGHT_ID);
  if (diffWorkbenchRightEl && diffWorkbenchRightEl.dataset.bound !== "true") {
    diffWorkbenchRightEl.dataset.bound = "true";
    diffWorkbenchRightEl.addEventListener("change", function() {
      setCodeEditorDiffWorkbenchError("");
      const panelEl = document.getElementById(CODE_EDITOR_PANEL_ID);
      if (panelEl) panelEl.classList.remove("diff-visible");
      const summaryEl = document.getElementById("code-editor-diff-summary");
      if (summaryEl) summaryEl.textContent = "";
      const contentEl = document.getElementById("code-editor-diff-content");
      if (contentEl) contentEl.innerHTML = "";
    });
  }

  const tabListEl = getCodeEditorTabListEl();
  if (tabListEl && tabListEl.dataset.bound !== "true") {
    tabListEl.dataset.bound = "true";
    tabListEl.addEventListener("click", function(event) {
      const closeEl = event.target.closest("[data-action='close-tab']");
      if (closeEl) {
        event.preventDefault();
        event.stopPropagation();
        const tabId = closeEl.getAttribute("data-tab-id");
        closeCodeEditorTab(tabId);
        return;
      }

      const renameEl = event.target.closest("[data-action='rename-tab']");
      if (renameEl) {
        event.preventDefault();
        event.stopPropagation();
        const tabId = renameEl.getAttribute("data-tab-id");
        renameCodeEditorTab(tabId);
        return;
      }

      const tabBtn = event.target.closest(".code-editor-tab[data-tab-id]");
      if (!tabBtn) return;
      const tabId = tabBtn.getAttribute("data-tab-id");
      switchCodeEditorTab(tabId, { focus: true });
    });

  }

  const textareaEl = getEditorTextareaEl();
  if (textareaEl && textareaEl.dataset.tabSyncBound !== "true") {
    textareaEl.dataset.tabSyncBound = "true";
    textareaEl.addEventListener("input", function() {
      setActiveCodeEditorTabContent(textareaEl.value || "");
    });
  }

  if (!window.__codeEditorResizeBound) {
    window.__codeEditorResizeBound = true;
    window.addEventListener("resize", syncCodeEditorLayout, { passive: true });
  }
  if (!window.__codeEditorEscapeBound) {
    window.__codeEditorEscapeBound = true;
    document.addEventListener("keydown", function(e) {
      if (e.key === "Escape" && document.body.classList.contains("code-editor-mode")) {
        closeCodeEditorPanel();
      }
    });
  }

  refreshCodeEditorRunButtonState();
  renderCodeEditorTabs();
  return panel;
}

function bindCodeEditorResizer(panel) {
  if (!panel) return;
  const handle = panel.querySelector("#code-editor-resizer");
  if (!handle || handle.dataset.bound === "true") return;
  handle.dataset.bound = "true";

  let dragging = false;

  function onPointerMove(event) {
    if (!dragging) return;
    const pointerX = typeof event.clientX === "number" ? event.clientX : 0;
    const desiredWidth = window.innerWidth - pointerX;
    codeEditorPanelWidthPx = getCodeEditorPanelWidthPx(desiredWidth);
    document.documentElement.style.setProperty("--code-editor-panel-width", `${Math.round(codeEditorPanelWidthPx)}px`);
    syncCodeEditorLayout();
  }

  function stopDragging() {
    if (!dragging) return;
    dragging = false;
    try { document.body.style.userSelect = ""; } catch (e) {}
    window.removeEventListener("pointermove", onPointerMove);
    window.removeEventListener("pointerup", stopDragging);
    window.removeEventListener("pointercancel", stopDragging);
  }

  handle.addEventListener("pointerdown", function(event) {
    event.preventDefault();
    dragging = true;
    try { document.body.style.userSelect = "none"; } catch (e) {}
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", stopDragging);
    window.addEventListener("pointercancel", stopDragging);
  });
}

function normalizeCodeContent(text) {
  return String(text || "").replace(/\r\n/g, "\n");
}

function splitCodeLines(text) {
  return normalizeCodeContent(text).split("\n");
}

function buildFallbackDiffRows(oldLines, newLines) {
  const rows = [];
  let oldNo = 1;
  let newNo = 1;

  oldLines.forEach((line) => {
    rows.push({ type: "del", oldNo, newNo: "", text: line });
    oldNo++;
  });
  newLines.forEach((line) => {
    rows.push({ type: "add", oldNo: "", newNo, text: line });
    newNo++;
  });
  return rows;
}

function buildDiffRows(oldText, newText) {
  const oldLines = splitCodeLines(oldText);
  const newLines = splitCodeLines(newText);

  if (oldLines.length === 0 && newLines.length === 0) return [];

  const cells = oldLines.length * newLines.length;
  if (cells > CODE_DIFF_MAX_LCS_CELLS) {
    return buildFallbackDiffRows(oldLines, newLines);
  }

  const dp = Array.from({ length: oldLines.length + 1 }, () => new Uint16Array(newLines.length + 1));
  for (let i = oldLines.length - 1; i >= 0; i--) {
    for (let j = newLines.length - 1; j >= 0; j--) {
      if (oldLines[i] === newLines[j]) {
        dp[i][j] = dp[i + 1][j + 1] + 1;
      } else {
        dp[i][j] = dp[i + 1][j] >= dp[i][j + 1] ? dp[i + 1][j] : dp[i][j + 1];
      }
    }
  }

  const rows = [];
  let i = 0;
  let j = 0;
  let oldNo = 1;
  let newNo = 1;
  while (i < oldLines.length && j < newLines.length) {
    if (oldLines[i] === newLines[j]) {
      rows.push({ type: "ctx", oldNo, newNo, text: oldLines[i] });
      i++; j++; oldNo++; newNo++;
      continue;
    }

    if (dp[i + 1][j] >= dp[i][j + 1]) {
      rows.push({ type: "del", oldNo, newNo: "", text: oldLines[i] });
      i++; oldNo++;
    } else {
      rows.push({ type: "add", oldNo: "", newNo, text: newLines[j] });
      j++; newNo++;
    }
  }
  while (i < oldLines.length) {
    rows.push({ type: "del", oldNo, newNo: "", text: oldLines[i] });
    i++; oldNo++;
  }
  while (j < newLines.length) {
    rows.push({ type: "add", oldNo: "", newNo, text: newLines[j] });
    j++; newNo++;
  }

  return rows;
}

function escapeDiffHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function hideCodeDiffPanel() {
  clearPendingCodeDiff();
}

function clearPendingCodeDiff() {
  pendingCodeDiffState = null;
  codeEditorTabDiffState = null;
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  if (panel) {
    panel.classList.remove("diff-visible");
    panel.classList.remove("diff-tabs-mode");
  }

  const summaryEl = document.getElementById("code-editor-diff-summary");
  if (summaryEl) summaryEl.textContent = "";

  const contentEl = document.getElementById("code-editor-diff-content");
  if (contentEl) contentEl.innerHTML = "";
}

function hideEditorRunPanels() {
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  if (!panel) return;
  panel.classList.remove("run-status-visible");
  panel.classList.remove("run-output-visible");
}

function hideEditorRunStatusPanel() {
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  const statusEl = getEditorRunStatusEl();
  if (statusEl) statusEl.style.setProperty("display", "none", "important");
  if (!panel) return;
  panel.classList.remove("run-status-visible");
}

function resetEditorRunStatusText() {
  const statusEl = getEditorRunStatusEl();
  const titleEl = getEditorRunStatusTitleEl();
  const textEl = getEditorRunStatusTextEl();
  if (!statusEl || !titleEl || !textEl) return;
  statusEl.className = "code-editor-run-status is-warning";
  titleEl.textContent = "Run Status";
  textEl.textContent = "Open a response and click Run to execute in database.";
}

function resolveDiffStateRows(diffState) {
  if (Array.isArray(diffState?.rows) && diffState.rows.length) return diffState.rows;
  const oldCode = normalizeCodeContent((diffState && (diffState.oldCode || diffState.leftCode)) || "");
  const newCode = normalizeCodeContent((diffState && (diffState.newCode || diffState.rightCode)) || "");
  return buildDiffRows(oldCode, newCode);
}

function getDiffStateTitlePair(diffState) {
  const mode = String(diffState?.mode || "").toLowerCase();
  if (mode === "tabs") {
    return {
      left: String(diffState.leftTitle || "left-tab"),
      right: String(diffState.rightTitle || "right-tab")
    };
  }

  const leftId = String(diffState?.oldResponseId || "old");
  const rightId = String(diffState?.latestResponseId || "new");
  return {
    left: `response-${leftId}`,
    right: `response-${rightId}`
  };
}

function sanitizeCodeEditorTabNameSegment(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 36) || "code";
}

function buildUnifiedDiffText(diffState) {
  const rows = resolveDiffStateRows(diffState);
  const titlePair = getDiffStateTitlePair(diffState || {});
  const lines = [
    `--- ${titlePair.left}`,
    `+++ ${titlePair.right}`,
    ""
  ];

  rows.forEach((row) => {
    const line = String(row && row.text ? row.text : "");
    if (row && row.type === "add") {
      lines.push(`+${line}`);
      return;
    }
    if (row && row.type === "del") {
      lines.push(`-${line}`);
      return;
    }
    lines.push(` ${line}`);
  });

  return lines.join("\n");
}

function buildCodeDiffRowsHtml(rows) {
  const list = Array.isArray(rows) ? rows : [];
  if (!list.length) {
    return `<div class="code-diff-row ctx"><div class="code-diff-old"></div><div class="code-diff-new"></div><div class="code-diff-text">(No changes)</div></div>`;
  }

  return list.map((row) => {
    const cls = row && row.type === "add" ? "add" : row && row.type === "del" ? "del" : "ctx";
    const oldNo = row && row.oldNo === "" ? "" : String((row && row.oldNo) || "");
    const newNo = row && row.newNo === "" ? "" : String((row && row.newNo) || "");
    const text = escapeDiffHtml((row && row.text) || "");
    return `
      <div class="code-diff-row ${cls}">
        <div class="code-diff-old">${oldNo}</div>
        <div class="code-diff-new">${newNo}</div>
        <div class="code-diff-text">${text}</div>
      </div>
    `;
  }).join("");
}

function renderCodeDiffInCurrentPanel(diffState, rows) {
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  const summaryEl = document.getElementById("code-editor-diff-summary");
  const contentEl = document.getElementById("code-editor-diff-content");
  if (!panel || !summaryEl || !contentEl) return false;

  const diffRows = Array.isArray(rows) ? rows : [];
  const added = diffRows.filter((r) => r && r.type === "add").length;
  const removed = diffRows.filter((r) => r && r.type === "del").length;

  summaryEl.textContent = `Diff: +${added} / -${removed}`;
  contentEl.innerHTML = buildCodeDiffRowsHtml(diffRows);
  panel.classList.add("diff-visible");
  panel.classList.add("diff-tabs-mode");
  syncCodeEditorDiffTabSelectors(diffState && diffState.leftTabId, diffState && diffState.rightTabId);
  return true;
}

function openCodeDiffInTab(diffState) {
  const rows = resolveDiffStateRows(diffState);
  const titlePair = getDiffStateTitlePair(diffState || {});
  const leftSlug = sanitizeCodeEditorTabNameSegment(titlePair.left);
  const rightSlug = sanitizeCodeEditorTabNameSegment(titlePair.right);
  const diffText = buildUnifiedDiffText({ ...(diffState || {}), rows });
  const tab = createCodeEditorTab(`diff-${Date.now()}-${leftSlug}`, "diff", diffText);
  if (!tab) return;

  tab.customName = `diff-${leftSlug}-vs-${rightSlug}.diff`;
  tab.isDiff = true;
  switchCodeEditorTab(tab.id, { focus: true, preserveOutput: false });
}

function renderCodeDiff(diffState) {
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  pendingCodeDiffState = null;
  const normalizedState = diffState || {};
  const rows = resolveDiffStateRows(normalizedState);

  if (normalizedState && normalizedState.mode === "tabs") {
    codeEditorTabDiffState = { ...normalizedState, rows };
    const activeTab = getCodeEditorTabById(activeCodeEditorTabId);
    if (isCodeEditorDiffWorkbenchTab(activeTab)) {
      if (renderCodeDiffInCurrentPanel(codeEditorTabDiffState, rows)) {
        syncCodeEditorLayout();
        return;
      }
    }
  } else {
    codeEditorTabDiffState = null;
  }

  if (panel) {
    panel.classList.remove("diff-visible");
    panel.classList.remove("diff-tabs-mode");
  }
  const summaryEl = document.getElementById("code-editor-diff-summary");
  if (summaryEl) summaryEl.textContent = "";
  const contentEl = document.getElementById("code-editor-diff-content");
  if (contentEl) contentEl.innerHTML = "";

  openCodeDiffInTab({ ...normalizedState, rows });
  syncCodeEditorLayout();
}

function acceptPendingCodeDiff() {
  if (!pendingCodeDiffState) return;

  activeEditorResponseId = pendingCodeDiffState.latestResponseId || activeEditorResponseId;
  activeEditorFileExt = pendingCodeDiffState.newExt || activeEditorFileExt || "txt";
  setEditorFileName(activeEditorResponseId, activeEditorFileExt);
  setEditorContent(pendingCodeDiffState.newCode || "");
  updateActiveCodeEditorTabMeta({
    responseId: activeEditorResponseId,
    ext: activeEditorFileExt,
    content: pendingCodeDiffState.newCode || ""
  });
  setEditorLanguageMode(activeEditorFileExt);
  refreshCodeEditorRunButtonState();
  focusEditorSurface();

  clearPendingCodeDiff();
}

function keepOriginalCodeFromDiff() {
  if (!pendingCodeDiffState) return;

  activeEditorFileExt = pendingCodeDiffState.oldExt || activeEditorFileExt || "txt";
  setEditorContent(pendingCodeDiffState.oldCode || "");
  updateActiveCodeEditorTabMeta({
    ext: activeEditorFileExt,
    content: pendingCodeDiffState.oldCode || ""
  });
  setEditorLanguageMode(activeEditorFileExt);
  refreshCodeEditorRunButtonState();
  focusEditorSurface();
  clearPendingCodeDiff();
}

function isCodeChangeIntentPrompt(promptText) {
  const text = String(promptText || "").toLowerCase();
  if (!text) return false;

  const hasChangeVerb = /(change|modify|update|fix|refactor|rewrite|patch|adjust|improve|replace|add|remove|edit)/i.test(text);
  const hasCodeTarget = /(code|sql|query|script|procedure|function|package|response|above|existing|previous|current)/i.test(text);
  return hasChangeVerb && hasCodeTarget;
}

function capturePendingCodeChangeRequest(promptText) {
  pendingCodeChangeRequest = null;

  if (!isCodeChangeIntentPrompt(promptText)) return;
  if (!document.body.classList.contains("code-editor-mode")) return;
  if (!activeEditorResponseId) return;

  const baselineCode = getEditorContent();
  if (!String(baselineCode || "").trim()) return;

  pendingCodeChangeRequest = {
    baselineResponseId: activeEditorResponseId,
    baselineExt: activeEditorFileExt || "txt",
    baselineCode: normalizeCodeContent(baselineCode),
    promptText: String(promptText || ""),
    createdAt: Date.now()
  };

  clearPendingCodeDiff();
}

function handlePotentialCodeDiffForLatestResponse(latestResponseId) {
  if (!pendingCodeChangeRequest) return;
  const request = pendingCodeChangeRequest;
  pendingCodeChangeRequest = null;

  const payload = buildResponseDownloadPayload(latestResponseId);
  if (!payload || !String(payload.content || "").trim()) return;

  const oldCode = normalizeCodeContent(request.baselineCode || "");
  const newCode = normalizeCodeContent(payload.content || "");
  if (!oldCode.trim() || !newCode.trim()) return;

  const rows = buildDiffRows(oldCode, newCode);
  const hasChanges = rows.some((row) => row.type !== "ctx");
  if (!hasChanges) {
    return;
  }

  pendingCodeDiffState = {
    oldCode,
    newCode,
    oldExt: request.baselineExt || "txt",
    newExt: payload.ext || request.baselineExt || "txt",
    oldResponseId: request.baselineResponseId,
    latestResponseId: latestResponseId,
    rows
  };

  ensureCodeEditorPanel();
  resetCodeEditorPanelWidthForOpen();
  document.body.classList.add("code-editor-mode");
  applyFooterAppearance();
  scheduleNavigationStateForEditorOpen(140);

  activeEditorResponseId = request.baselineResponseId;
  activeEditorFileExt = request.baselineExt || "txt";
  setEditorFileName(activeEditorResponseId, activeEditorFileExt);
  setEditorContent(oldCode);
  updateActiveCodeEditorTabMeta({
    responseId: activeEditorResponseId,
    ext: activeEditorFileExt,
    content: oldCode
  });
  setEditorLanguageMode(activeEditorFileExt);
  refreshCodeEditorRunButtonState();
  renderCodeDiff(pendingCodeDiffState);
  focusEditorSurface();
}

function ensureAceEditorLoaded(callback) {
  if (window.ace) {
    if (typeof callback === "function") callback(true);
    return;
  }

  if (typeof callback === "function") {
    codeEditorAceCallbacks.push(callback);
  }

  if (codeEditorAceLoading) return;
  codeEditorAceLoading = true;

  const script = document.createElement("script");
  script.src = ACE_EDITOR_CDN_URL;
  script.async = true;
  script.onload = function() {
    codeEditorAceLoading = false;
    const callbacks = codeEditorAceCallbacks.slice();
    codeEditorAceCallbacks = [];
    callbacks.forEach((cb) => {
      try { cb(true); } catch (e) {}
    });
  };
  script.onerror = function() {
    codeEditorAceLoading = false;
    const callbacks = codeEditorAceCallbacks.slice();
    codeEditorAceCallbacks = [];
    callbacks.forEach((cb) => {
      try { cb(false); } catch (e) {}
    });
  };
  document.head.appendChild(script);
}

function ensureAceEditorInstance() {
  if (!window.ace) return null;

  const panel = ensureCodeEditorPanel();
  const host = panel ? panel.querySelector(`#${CODE_EDITOR_ACE_ID}`) : null;
  if (!host) return null;

  if (window.ace && window.ace.config) {
    try {
      window.ace.config.set("basePath", ACE_EDITOR_BASE_PATH);
    } catch (e) {}
  }

  if (codeEditorAceInstance && codeEditorAceInstance.container === host) {
    return codeEditorAceInstance;
  }

  if (codeEditorAceInstance && typeof codeEditorAceInstance.destroy === "function") {
    try { codeEditorAceInstance.destroy(); } catch (e) {}
  }

  codeEditorAceInstance = window.ace.edit(CODE_EDITOR_ACE_ID);
  codeEditorAceInstance.setTheme("ace/theme/one_dark");
  codeEditorAceInstance.setShowPrintMargin(false);
  codeEditorAceInstance.session.setUseWrapMode(false);
  codeEditorAceInstance.session.setTabSize(2);
  codeEditorAceInstance.setOptions({
    fontSize: "13px",
    enableBasicAutocompletion: true,
    enableLiveAutocompletion: false,
    highlightActiveLine: true
  });

  const textareaEl = getEditorTextareaEl();
  if (textareaEl) {
    // First-open fix: keep staged content when Ace initializes asynchronously.
    codeEditorAceInstance.setValue(String(textareaEl.value || ""), -1);
  }
  if (textareaEl && !textareaEl.dataset.aceSynced) {
    textareaEl.dataset.aceSynced = "true";
    codeEditorAceInstance.session.on("change", function() {
      const value = codeEditorAceInstance.getValue();
      textareaEl.value = value;
      setActiveCodeEditorTabContent(value);
    });
  }

  panel.classList.add("ace-ready");
  requestAnimationFrame(() => codeEditorAceInstance.resize());
  return codeEditorAceInstance;
}

function getEditorTextareaEl() {
  return document.getElementById("code-editor-textarea");
}

function getEditorFileNameEl() {
  return document.getElementById("code-editor-file-name");
}

function getCodeEditorTabListEl() {
  return document.getElementById(CODE_EDITOR_TAB_LIST_ID);
}

function getCodeEditorTabById(tabId) {
  if (!tabId) return null;
  return codeEditorTabs.find((tab) => tab && tab.id === tabId) || null;
}

function getCodeEditorFileName(responseId, ext) {
  const base = getResponseDisplayBaseName(responseId);
  return `${base}.${ext || "txt"}`;
}

function getCodeEditorTabTitle(tab) {
  if (!tab) return "response.txt";
  return String(tab.customName || tab.fileName || getCodeEditorFileName(tab.responseId, tab.ext));
}

function setActiveCodeEditorTabContent(content) {
  const tab = getCodeEditorTabById(activeCodeEditorTabId);
  if (!tab) return;
  tab.content = normalizeCodeContent(content || "");
}

function captureActiveCodeEditorTabContent() {
  const tab = getCodeEditorTabById(activeCodeEditorTabId);
  if (!tab) return;
  tab.content = normalizeCodeContent(getEditorContent() || "");
}

function renderCodeEditorTabs() {
  const listEl = getCodeEditorTabListEl();
  if (!listEl) return;

  listEl.innerHTML = "";
  codeEditorTabs.forEach((tab) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `code-editor-tab${tab.id === activeCodeEditorTabId ? " is-active" : ""}`;
    btn.setAttribute("data-tab-id", tab.id);
    btn.title = getCodeEditorTabTitle(tab);

    const label = document.createElement("span");
    label.className = "code-editor-tab-label";
    label.textContent = getCodeEditorTabTitle(tab);
    btn.appendChild(label);

    const rename = document.createElement("span");
    rename.className = "code-editor-tab-rename";
    rename.setAttribute("data-action", "rename-tab");
    rename.setAttribute("data-tab-id", tab.id);
    rename.setAttribute("title", "Rename tab");
    rename.textContent = "R";
    btn.appendChild(rename);

    const close = document.createElement("span");
    close.className = "code-editor-tab-close";
    close.setAttribute("data-action", "close-tab");
    close.setAttribute("data-tab-id", tab.id);
    close.setAttribute("title", "Close tab");
    close.textContent = "x";
    btn.appendChild(close);

    listEl.appendChild(btn);
  });

  syncCodeEditorDiffTabSelectors();
}

function createCodeEditorTab(responseId, ext, content) {
  const normalizedExt = String(ext || "txt").toLowerCase();
  const tab = {
    id: `code-tab-${Date.now()}-${++codeEditorTabSequence}`,
    responseId: String(responseId || ""),
    ext: normalizedExt || "txt",
    content: normalizeCodeContent(content || "")
  };
  tab.fileName = getCodeEditorFileName(tab.responseId || "response", tab.ext);
  codeEditorTabs.push(tab);
  return tab;
}

function resetCodeEditorTabs() {
  codeEditorTabs = [];
  activeCodeEditorTabId = null;
  codeEditorTabSequence = 0;
  renderCodeEditorTabs();
}

function getCodeEditorTabButtonEl(tabId) {
  const listEl = getCodeEditorTabListEl();
  if (!listEl || !tabId) return null;
  const safeTabId = String(tabId).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  return listEl.querySelector(`.code-editor-tab[data-tab-id="${safeTabId}"]`);
}

function renameCodeEditorTab(tabId) {
  const tab = getCodeEditorTabById(tabId);
  if (!tab) return;

  const tabBtn = getCodeEditorTabButtonEl(tabId);
  const labelEl = tabBtn ? tabBtn.querySelector(".code-editor-tab-label") : null;
  if (!tabBtn || !labelEl) return;

  const originalCustomName = tab.customName || null;
  const input = document.createElement("input");
  input.type = "text";
  input.className = "code-editor-tab-rename-input";
  input.value = getCodeEditorTabTitle(tab);
  input.setAttribute("aria-label", "Rename tab");
  labelEl.replaceWith(input);

  let finished = false;
  function finalizeRename(saveChanges) {
    if (finished) return;
    finished = true;

    if (saveChanges) {
      const normalized = String(input.value || "").trim();
      tab.customName = normalized || null;
    } else {
      tab.customName = originalCustomName;
    }

    renderCodeEditorTabs();
    if (tab.id === activeCodeEditorTabId) {
      const fileNameEl = getEditorFileNameEl();
      if (fileNameEl) fileNameEl.textContent = getCodeEditorTabTitle(tab);
    }
  }

  input.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      finalizeRename(true);
      return;
    }
    if (event.key === "Escape") {
      event.preventDefault();
      finalizeRename(false);
    }
  });
  input.addEventListener("blur", function() {
    finalizeRename(true);
  });

  try { input.focus({ preventScroll: true }); } catch (e) { input.focus(); }
  try { input.select(); } catch (e) {}
}

function getCodeEditorDiffLeftSelectEl() {
  return document.getElementById("code-editor-diff-left-tab");
}

function getCodeEditorDiffRightSelectEl() {
  return document.getElementById("code-editor-diff-right-tab");
}

function syncCodeEditorDiffTabSelectors(preferredLeftTabId, preferredRightTabId) {
  const leftEl = getCodeEditorDiffLeftSelectEl();
  const rightEl = getCodeEditorDiffRightSelectEl();
  if (!leftEl || !rightEl) return;

  const currentLeft = preferredLeftTabId || leftEl.value || activeCodeEditorTabId;
  const currentRight = preferredRightTabId || rightEl.value || "";

  const optionsHtml = codeEditorTabs.map((tab) => {
    const safeTitle = escapeHtml(getCodeEditorTabTitle(tab));
    return `<option value="${escapeHtml(String(tab.id))}">${safeTitle}</option>`;
  }).join("");

  leftEl.innerHTML = optionsHtml;
  rightEl.innerHTML = optionsHtml;

  const leftTab = getCodeEditorTabById(currentLeft) || getCodeEditorTabById(activeCodeEditorTabId) || codeEditorTabs[0] || null;
  let rightTab = getCodeEditorTabById(currentRight) || null;
  if (!rightTab || (leftTab && rightTab && rightTab.id === leftTab.id)) {
    rightTab = codeEditorTabs.find((tab) => !leftTab || tab.id !== leftTab.id) || leftTab;
  }

  if (leftTab) leftEl.value = leftTab.id;
  if (rightTab) rightEl.value = rightTab.id;
}

function getCodeEditorDiffWorkbenchEl() {
  return document.getElementById(CODE_EDITOR_DIFF_WORKBENCH_ID);
}

function getCodeEditorDiffWorkbenchLeftEl() {
  return document.getElementById(CODE_EDITOR_DIFF_WORKBENCH_LEFT_ID);
}

function getCodeEditorDiffWorkbenchRightEl() {
  return document.getElementById(CODE_EDITOR_DIFF_WORKBENCH_RIGHT_ID);
}

function getCodeEditorDiffWorkbenchErrorEl() {
  return document.getElementById(CODE_EDITOR_DIFF_WORKBENCH_ERROR_ID);
}

function setCodeEditorDiffWorkbenchError(message) {
  const errorEl = getCodeEditorDiffWorkbenchErrorEl();
  if (!errorEl) return;
  errorEl.textContent = String(message || "");
}

function isCodeEditorDiffWorkbenchTab(tab) {
  if (!tab) return false;
  if (tab.isDiffWorkbench) return true;
  return String(tab.ext || "").toLowerCase() === "diffselect";
}

function setCodeEditorDiffWorkbenchMode(enabled) {
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  if (!panel) return;
  panel.classList.toggle("diff-workbench-mode", !!enabled);
}

function getCodeEditorDiffEligibleTabs() {
  return codeEditorTabs.filter((tab) => {
    if (!tab) return false;
    if (isCodeEditorDiffWorkbenchTab(tab)) return false;
    const ext = String(tab.ext || "").toLowerCase();
    return ext !== "diff";
  });
}

function ensureCodeEditorDiffWorkbenchTab() {
  const existing = codeEditorTabs.find((tab) => isCodeEditorDiffWorkbenchTab(tab)) || null;
  if (existing) return existing;

  const tab = createCodeEditorTab("diff-workbench", "diffselect", "");
  if (!tab) return null;
  tab.customName = "diff";
  tab.isDiffWorkbench = true;
  return tab;
}

function populateCodeEditorDiffWorkbenchSelectors(preferredLeftTabId, preferredRightTabId) {
  const leftEl = getCodeEditorDiffWorkbenchLeftEl();
  const rightEl = getCodeEditorDiffWorkbenchRightEl();
  if (!leftEl || !rightEl) return;

  const tabs = getCodeEditorDiffEligibleTabs();
  const optionsHtml = tabs
    .map((tab) => `<option value="${escapeHtml(String(tab.id))}">${escapeHtml(getCodeEditorTabTitle(tab))}</option>`)
    .join("");
  leftEl.innerHTML = optionsHtml;
  rightEl.innerHTML = optionsHtml;

  function resolveEligibleTab(tabId) {
    return tabs.find((tab) => tab && tab.id === tabId) || null;
  }

  const activeTab = resolveEligibleTab(activeCodeEditorTabId);
  const fallbackLeft = resolveEligibleTab(preferredLeftTabId) || activeTab || tabs[0] || null;
  let fallbackRight = resolveEligibleTab(preferredRightTabId) || null;
  if (!fallbackRight || (fallbackLeft && fallbackRight.id === fallbackLeft.id)) {
    fallbackRight = tabs.find((tab) => !fallbackLeft || tab.id !== fallbackLeft.id) || null;
  }

  if (fallbackLeft) leftEl.value = fallbackLeft.id;
  if (fallbackRight) rightEl.value = fallbackRight.id;
  setCodeEditorDiffWorkbenchError("");
}

function applyCodeEditorDiffFromWorkbenchSelection() {
  const leftEl = getCodeEditorDiffWorkbenchLeftEl();
  const rightEl = getCodeEditorDiffWorkbenchRightEl();
  if (!leftEl || !rightEl) return;

  const leftTab = getCodeEditorTabById(leftEl.value);
  const rightTab = getCodeEditorTabById(rightEl.value);
  if (!leftTab || !rightTab) {
    setCodeEditorDiffWorkbenchError("Select both tabs.");
    return;
  }
  if (leftTab.id === rightTab.id) {
    setCodeEditorDiffWorkbenchError("Select two different tabs.");
    return;
  }

  const leftCode = normalizeCodeContent(leftTab.content || "");
  const rightCode = normalizeCodeContent(rightTab.content || "");
  const rows = buildDiffRows(leftCode, rightCode);
  codeEditorTabDiffState = {
    mode: "tabs",
    leftTabId: leftTab.id,
    rightTabId: rightTab.id,
    leftTitle: getCodeEditorTabTitle(leftTab),
    rightTitle: getCodeEditorTabTitle(rightTab),
    leftCode,
    rightCode,
    leftExt: leftTab.ext || "txt",
    rightExt: rightTab.ext || "txt",
    rows
  };
  setCodeEditorDiffWorkbenchError("");
  renderCodeDiff(codeEditorTabDiffState);
}

function openCodeEditorTabDiffPanel() {
  const tabs = getCodeEditorDiffEligibleTabs();
  if (tabs.length < 2) {
    apex.message.clearErrors();
    apex.message.showErrors([{
      type: "error",
      location: "page",
      message: "Open at least two editor tabs to compare and merge.",
      unsafe: false
    }]);
    return;
  }

  captureActiveCodeEditorTabContent();
  const previousActiveTabId = activeCodeEditorTabId;
  const tab = ensureCodeEditorDiffWorkbenchTab();
  if (!tab) return;

  switchCodeEditorTab(tab.id, { focus: false, preserveOutput: false });

  const preferredLeftTabId =
    codeEditorTabDiffState && codeEditorTabDiffState.mode === "tabs"
      ? codeEditorTabDiffState.leftTabId
      : previousActiveTabId;
  const preferredRightTabId =
    codeEditorTabDiffState && codeEditorTabDiffState.mode === "tabs"
      ? codeEditorTabDiffState.rightTabId
      : null;
  populateCodeEditorDiffWorkbenchSelectors(preferredLeftTabId, preferredRightTabId);

  const leftEl = getCodeEditorDiffWorkbenchLeftEl();
  if (leftEl) leftEl.focus();
}

function renderCodeEditorTabDiffFromSelectors() {
  const leftEl = getCodeEditorDiffLeftSelectEl();
  const rightEl = getCodeEditorDiffRightSelectEl();
  if (!leftEl || !rightEl) return;

  const leftTab = getCodeEditorTabById(leftEl.value);
  const rightTab = getCodeEditorTabById(rightEl.value);
  if (!leftTab || !rightTab) return;
  if (leftTab.id === rightTab.id) {
    setEditorRunStatus("warning", "Diff Unavailable", "Select two different tabs for diff.");
    return;
  }

  const oldCode = normalizeCodeContent(leftTab.content || "");
  const newCode = normalizeCodeContent(rightTab.content || "");
  const rows = buildDiffRows(oldCode, newCode);
  codeEditorTabDiffState = {
    mode: "tabs",
    leftTabId: leftTab.id,
    rightTabId: rightTab.id,
    leftTitle: getCodeEditorTabTitle(leftTab),
    rightTitle: getCodeEditorTabTitle(rightTab),
    leftCode: oldCode,
    rightCode: newCode,
    leftExt: leftTab.ext || "txt",
    rightExt: rightTab.ext || "txt",
    rows
  };
  renderCodeDiff(codeEditorTabDiffState);
}

function buildMergedCodeFromTabDiff(diffState) {
  return normalizeCodeContent((diffState && diffState.rightCode) || "");
}

function mergeCodeEditorTabDiff() {
  if (!codeEditorTabDiffState || codeEditorTabDiffState.mode !== "tabs") {
    apex.message.clearErrors();
    apex.message.showErrors([{
      type: "error",
      location: "page",
      message: "Run Diff Tabs first, then Merge Tabs.",
      unsafe: false
    }]);
    return;
  }

  const leftTab = getCodeEditorTabById(codeEditorTabDiffState.leftTabId);
  const rightTab = getCodeEditorTabById(codeEditorTabDiffState.rightTabId);
  if (!leftTab || !rightTab) return;

  const mergedCode = buildMergedCodeFromTabDiff(codeEditorTabDiffState);
  const mergedExt = rightTab.ext || leftTab.ext || "txt";
  const mergedResponseId = `${leftTab.responseId || "left"}_${rightTab.responseId || "right"}_merge`;
  const mergedTab = createCodeEditorTab(mergedResponseId, mergedExt, mergedCode);
  if (!mergedTab) return;

  mergedTab.customName = `merged-${codeEditorTabSequence}.${mergedExt}`;
  switchCodeEditorTab(mergedTab.id, { focus: true, preserveOutput: false });
  apex.message.clearErrors();
  if (window.apex && apex.message && typeof apex.message.showPageSuccess === "function") {
    apex.message.showPageSuccess("Merged output opened in a new tab.");
  }
}

function applyCodeEditorTabState(tab, options) {
  if (!tab) return false;
  const opts = options || {};
  const isDiffWorkbench = isCodeEditorDiffWorkbenchTab(tab);
  activeCodeEditorTabId = tab.id;
  activeEditorResponseId = tab.responseId;
  activeEditorFileExt = tab.ext || "txt";
  const fileNameEl = getEditorFileNameEl();
  if (fileNameEl) fileNameEl.textContent = getCodeEditorTabTitle(tab);
  setCodeEditorDiffWorkbenchMode(isDiffWorkbench);
  if (!isDiffWorkbench) {
    setEditorContent(tab.content || "");
    setEditorLanguageMode(activeEditorFileExt);
  } else {
    const preferredLeftTabId =
      codeEditorTabDiffState && codeEditorTabDiffState.mode === "tabs"
        ? codeEditorTabDiffState.leftTabId
        : null;
    const preferredRightTabId =
      codeEditorTabDiffState && codeEditorTabDiffState.mode === "tabs"
        ? codeEditorTabDiffState.rightTabId
        : null;
    populateCodeEditorDiffWorkbenchSelectors(preferredLeftTabId, preferredRightTabId);
  }
  if (!opts.preserveOutput) {
    clearEditorRunOutput();
    resetEditorRunStatusText();
    hideEditorRunPanels();
  }
  clearEditorSyntaxIssueMarkers();
  pendingCodeDiffState = null;
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  if (panel) {
    panel.classList.remove("diff-visible");
    panel.classList.remove("diff-tabs-mode");
  }
  const diffSummaryEl = document.getElementById("code-editor-diff-summary");
  if (diffSummaryEl) diffSummaryEl.textContent = "";
  const diffContentEl = document.getElementById("code-editor-diff-content");
  if (diffContentEl) diffContentEl.innerHTML = "";
  refreshCodeEditorRunButtonState();
  renderCodeEditorTabs();
  if (opts.focus !== false) {
    if (isDiffWorkbench) {
      const leftEl = getCodeEditorDiffWorkbenchLeftEl();
      if (leftEl) leftEl.focus();
    } else {
      focusEditorSurface();
    }
  }
  return true;
}

function switchCodeEditorTab(tabId, options) {
  const tab = getCodeEditorTabById(tabId);
  if (!tab) return false;

  const opts = options || {};
  if (!opts.skipCapture) {
    captureActiveCodeEditorTabContent();
  }
  return applyCodeEditorTabState(tab, opts);
}

function closeCodeEditorTab(tabId) {
  if (!tabId) return;
  const index = codeEditorTabs.findIndex((tab) => tab && tab.id === tabId);
  if (index < 0) return;

  const wasActive = codeEditorTabs[index].id === activeCodeEditorTabId;
  if (wasActive) {
    captureActiveCodeEditorTabContent();
  }

  codeEditorTabs.splice(index, 1);
  if (codeEditorTabs.length === 0) {
    closeCodeEditorPanel();
    return;
  }

  if (wasActive) {
    const nextIndex = Math.max(0, index - 1);
    const fallbackTab = codeEditorTabs[nextIndex] || codeEditorTabs[0];
    if (fallbackTab) {
      applyCodeEditorTabState(fallbackTab, { skipCapture: true, focus: true });
      return;
    }
  }
  renderCodeEditorTabs();
}

function updateActiveCodeEditorTabMeta(meta) {
  const tab = getCodeEditorTabById(activeCodeEditorTabId);
  if (!tab || !meta || typeof meta !== "object") return;

  if (Object.prototype.hasOwnProperty.call(meta, "responseId")) {
    tab.responseId = String(meta.responseId || tab.responseId || "");
  }
  if (Object.prototype.hasOwnProperty.call(meta, "ext")) {
    tab.ext = String(meta.ext || tab.ext || "txt").toLowerCase();
  }
  if (Object.prototype.hasOwnProperty.call(meta, "content")) {
    tab.content = normalizeCodeContent(meta.content || "");
  }
  tab.fileName = getCodeEditorFileName(tab.responseId || "response", tab.ext || "txt");
  if (tab.id === activeCodeEditorTabId) {
    activeEditorResponseId = tab.responseId;
    activeEditorFileExt = tab.ext || "txt";
    const fileNameEl = getEditorFileNameEl();
    if (fileNameEl) fileNameEl.textContent = getCodeEditorTabTitle(tab);
  }
  renderCodeEditorTabs();
}

function getEditorRunButtonEl() {
  return document.getElementById("code-editor-run-btn");
}

function getEditorRunStatusEl() {
  return document.getElementById("code-editor-run-status");
}

function getEditorRunStatusTitleEl() {
  return document.getElementById("code-editor-run-status-title");
}

function getEditorRunStatusTextEl() {
  return document.getElementById("code-editor-run-status-text");
}

function getEditorRunOutputEl() {
  return document.getElementById("code-editor-run-output");
}

function getEditorRunOutputTitleEl() {
  return document.getElementById("code-editor-run-output-title");
}

function getEditorRunOutputContentEl() {
  return document.getElementById("code-editor-run-output-content");
}

function getEditorRunOutputResultTabEl() {
  return document.getElementById(CODE_EDITOR_RUN_OUTPUT_TAB_RESULT_ID);
}

function getEditorRunOutputLogTabEl() {
  return document.getElementById(CODE_EDITOR_RUN_OUTPUT_TAB_LOG_ID);
}

function getEditorRunOutputResultEl() {
  return document.getElementById(CODE_EDITOR_RUN_OUTPUT_RESULT_ID);
}

function getEditorRunOutputLogEl() {
  return document.getElementById(CODE_EDITOR_RUN_OUTPUT_LOG_ID);
}

function setEditorRunOutputActiveTab(tabName) {
  const target = String(tabName || "result").toLowerCase() === "log" ? "log" : "result";
  const resultBtn = getEditorRunOutputResultTabEl();
  const logBtn = getEditorRunOutputLogTabEl();
  const resultPane = getEditorRunOutputResultEl();
  const logPane = getEditorRunOutputLogEl();

  if (resultBtn) resultBtn.classList.toggle("is-active", target === "result");
  if (logBtn) logBtn.classList.toggle("is-active", target === "log");
  if (resultPane) resultPane.classList.toggle("is-active", target === "result");
  if (logPane) logPane.classList.toggle("is-active", target === "log");
}

function isEditorSqlRunEnabled() {
  const tab = getCodeEditorTabById(activeCodeEditorTabId);
  if (tab) {
    const ext = String(tab.ext || "").toLowerCase();
    if (ext === "diff" || ext === "diffselect" || isCodeEditorDiffWorkbenchTab(tab)) return false;
  }
  return !!activeEditorResponseId;
}

function setEditorRunStatus(type, title, text) {
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  const statusEl = getEditorRunStatusEl();
  const titleEl = getEditorRunStatusTitleEl();
  const textEl = getEditorRunStatusTextEl();
  if (!statusEl || !titleEl || !textEl) return;
  statusEl.style.removeProperty("display");

  if (panel) panel.classList.add("run-status-visible");

  const safeType = ["running", "success", "error", "warning"].includes(type) ? type : "warning";
  statusEl.className = `code-editor-run-status is-${safeType}`;
  titleEl.textContent = title || "Run Status";
  textEl.textContent = text || "";
}

function setEditorRunOutputHtml(title, html, targetTab) {
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  const outputEl = getEditorRunOutputEl();
  const outputTitleEl = getEditorRunOutputTitleEl();
  const outputResultEl = getEditorRunOutputResultEl();
  const outputLogEl = getEditorRunOutputLogEl();
  if (!outputEl || !outputTitleEl) return;

  if (panel) panel.classList.add("run-output-visible");
  outputTitleEl.textContent = title || "Execution Output";
  const tab = String(targetTab || "result").toLowerCase() === "log" ? "log" : "result";
  if (tab === "log") {
    if (outputLogEl) outputLogEl.innerHTML = html || "";
  } else {
    if (outputResultEl) outputResultEl.innerHTML = html || "";
  }
  setEditorRunOutputActiveTab(tab);
}

function clearEditorRunOutput() {
  const panel = document.getElementById(CODE_EDITOR_PANEL_ID);
  const outputEl = getEditorRunOutputEl();
  const outputTitleEl = getEditorRunOutputTitleEl();
  const outputResultEl = getEditorRunOutputResultEl();
  const outputLogEl = getEditorRunOutputLogEl();
  if (!outputEl || !outputTitleEl) return;

  outputTitleEl.textContent = "Execution Output";
  if (outputResultEl) outputResultEl.textContent = "Execution result appears here.";
  if (outputLogEl) outputLogEl.textContent = "Run logs appear here.";
  setEditorRunOutputActiveTab("result");
  if (panel) panel.classList.remove("run-output-visible");
}

function clearEditorSyntaxIssueMarkers() {
  const instance = ensureAceEditorInstance();
  if (!instance || !instance.session) return;
  const session = instance.session;

  try {
    session.clearAnnotations();
  } catch (e) {}

  if (typeof codeEditorSyntaxErrorMarkerId === "number" && codeEditorSyntaxErrorMarkerId >= 0) {
    try { session.removeMarker(codeEditorSyntaxErrorMarkerId); } catch (e) {}
  }
  codeEditorSyntaxErrorMarkerId = null;
}

function applyEditorSyntaxIssueHighlight(message) {
  const instance = ensureAceEditorInstance();
  if (!instance || !instance.session || !message) return;

  const text = String(message);
  const patterns = [
    /ORA-06550:\s*line\s*(\d+),\s*column\s*(\d+)/i,
    /line\s*(\d+)\s*,\s*column\s*(\d+)/i,
    /at\s+line\s*(\d+)/i
  ];

  let lineNo = 1;
  let colNo = 1;
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      lineNo = Number(match[1] || 1) || 1;
      colNo = Number(match[2] || 1) || 1;
      break;
    }
  }

  const row = Math.max(0, lineNo - 1);
  const column = Math.max(0, colNo - 1);
  const session = instance.session;
  clearEditorSyntaxIssueMarkers();

  try {
    session.setAnnotations([{
      row,
      column,
      text: text.length > 400 ? `${text.slice(0, 400)}...` : text,
      type: "error"
    }]);
  } catch (e) {}

  try {
    const aceRange = window.ace && window.ace.require ? window.ace.require("ace/range").Range : null;
    if (aceRange) {
      codeEditorSyntaxErrorMarkerId = session.addMarker(
        new aceRange(row, 0, row, 1),
        "code-editor-ace-error-line",
        "fullLine"
      );
    }
  } catch (e) {}

  try {
    instance.scrollToLine(lineNo, true, true, function() {});
    instance.gotoLine(lineNo, colNo, true);
  } catch (e) {}
}

function refreshCodeEditorRunButtonState() {
  const runBtn = getEditorRunButtonEl();
  if (!runBtn) return;

  const runEnabled = isEditorSqlRunEnabled();
  runBtn.disabled = codeEditorSqlRunInFlight || !runEnabled;
  runBtn.textContent = codeEditorSqlRunInFlight ? "Running..." : "Run";
  runBtn.title = runEnabled ? "Run in database" : "Open a response in editor to run";
}

function showEditorRunSqlError(message) {
  const text = String(message || "Unable to run script right now.");
  const detailText = arguments.length > 1 ? String(arguments[1] || "").trim() : "";
  const combinedText = detailText ? `${text}\n\n${detailText}` : text;
  setEditorRunStatus("error", "Run Failed", text);
  setEditorRunOutputHtml(
    "Execution Output",
    `<pre class="code-editor-run-output-pre">${escapeHtml(combinedText)}</pre>`,
    "log"
  );
  applyEditorSyntaxIssueHighlight(combinedText);
  apex.message.clearErrors();
  apex.message.showErrors([{
    type: "error",
    location: "page",
    message: text,
    unsafe: false
  }]);
}

function normalizeEditorSqlRunPayload(payload) {
  if (payload && typeof payload === "object") return payload;
  if (typeof payload === "string") {
    const text = payload.trim();
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (e) {
      return { success: false, error: `Unable to parse server JSON response. Raw: ${text.slice(0, 500)}` };
    }
  }
  return null;
}

function normalizeEditorRunResultRows(results) {
  if (typeof results === "string") {
    const text = results.trim();
    if (!text) return [];
    try {
      const parsed = JSON.parse(text);
      if (parsed !== results) return normalizeEditorRunResultRows(parsed);
    } catch (e) {}
    return [];
  }

  if (Array.isArray(results)) {
    if (results.length === 0) return [];
    return results.map((row) => {
      if (row && typeof row === "object" && !Array.isArray(row)) {
        return row;
      }
      if (Array.isArray(row)) {
        const out = {};
        row.forEach((value, idx) => {
          out[`COL${idx + 1}`] = value;
        });
        return out;
      }
      return { VALUE: row };
    });
  }

  if (results && typeof results === "object" && Array.isArray(results.rows)) {
    const rows = results.rows;
    const rawColumns = Array.isArray(results.columns)
      ? results.columns
      : (Array.isArray(results.fields) ? results.fields : []);
    const columnNames = rawColumns
      .map((col, idx) => {
        if (typeof col === "string") return col;
        if (col && typeof col === "object") {
          return String(col.name || col.label || col.columnName || col.alias || "").trim() || `COL${idx + 1}`;
        }
        return `COL${idx + 1}`;
      })
      .filter(Boolean);

    if (rows.length > 0 && rows.every((row) => Array.isArray(row)) && columnNames.length > 0) {
      return rows.map((row) => {
        const out = {};
        row.forEach((value, idx) => {
          out[String(columnNames[idx] || `COL${idx + 1}`)] = value;
        });
        return out;
      });
    }
    return normalizeEditorRunResultRows(rows);
  }
  if (results && Array.isArray(results.items)) return results.items;
  if (results && Array.isArray(results.data)) return results.data;
  if (results && typeof results === "object" && Array.isArray(results.records)) return results.records;
  return [];
}

function extractEditorRunRowsFromUnknownShape(value, depth, visited) {
  const safeDepth = Number.isFinite(depth) ? depth : 0;
  if (safeDepth > 7) return [];
  if (value == null) return [];

  if (Array.isArray(value)) {
    return normalizeEditorRunResultRows(value);
  }

  if (typeof value !== "object") return [];
  if (visited && visited.has(value)) return [];
  if (visited) visited.add(value);

  const priorityKeys = ["results", "rows", "items", "data", "records", "values", "result", "rowset"];
  for (const key of priorityKeys) {
    if (!Object.prototype.hasOwnProperty.call(value, key)) continue;
    const rows = extractEditorRunRowsFromUnknownShape(value[key], safeDepth + 1, visited);
    if (rows.length > 0) return rows;
  }

  const keys = Object.keys(value);
  for (const key of keys) {
    const rows = extractEditorRunRowsFromUnknownShape(value[key], safeDepth + 1, visited);
    if (rows.length > 0) return rows;
  }
  return [];
}

function getEditorRunResultRowsFromPayload(pData) {
  const directRows = normalizeEditorRunResultRows(pData && pData.results);
  if (directRows.length > 0) return directRows;
  return extractEditorRunRowsFromUnknownShape(pData, 0, new Set());
}

function stripLeadingSqlComments(sqlText) {
  let value = String(sqlText || "");
  let previous = "";
  while (value !== previous) {
    previous = value;
    value = value.replace(/^\s+/, "");
    value = value.replace(/^--[^\n]*(?:\n|$)/, "");
    value = value.replace(/^\/\*[\s\S]*?\*\//, "");
  }
  return value.replace(/^\s+/, "");
}

function isLikelySelectSql(sqlText) {
  const normalized = stripLeadingSqlComments(sqlText).replace(/^\(+\s*/, "");
  if (!normalized) return false;
  return /^(select|with)\b/i.test(normalized);
}

function getEditorSqlPayloadMessage(pData) {
  if (!pData || typeof pData !== "object") return "";
  return String(
    pData.error ||
    pData.message ||
    pData.status_message ||
    pData.result_message ||
    pData.output_message ||
    pData.info ||
    ""
  ).trim();
}

function getEditorSqlPayloadDetailText(pData) {
  if (!pData || typeof pData !== "object") return "";

  const headline = getEditorSqlPayloadMessage(pData);
  const rawParts = [
    pData.errorStack,
    pData.error_stack,
    pData.errorBacktrace,
    pData.error_backtrace,
    pData.stack,
    pData.details,
    pData.detail
  ];

  const details = rawParts
    .map((part) => String(part || "").replace(/\r\n/g, "\n").trim())
    .filter(Boolean);

  if (Array.isArray(pData.compile_errors)) {
    pData.compile_errors.forEach((row) => details.push(String(row || "").trim()));
  }
  if (Array.isArray(pData.compilationErrors)) {
    pData.compilationErrors.forEach((row) => details.push(String(row || "").trim()));
  }

  const unique = [];
  details.forEach((item) => {
    if (!item) return;
    if (headline && item === headline) return;
    if (!unique.includes(item)) unique.push(item);
  });

  return unique.join("\n");
}

function isCompilationFailureMessage(text) {
  return /ORA-24344|compilation error occurred while creating an object/i.test(String(text || ""));
}

function isEditorSqlRunPayloadFailure(pData) {
  const explicitFailure =
    !pData ||
    pData.success === false ||
    pData.success === 0 ||
    String(pData.success || "").toLowerCase() === "false" ||
    String(pData.success || "").toUpperCase() === "N" ||
    !!pData.error;

  if (explicitFailure) return true;
  return isCompilationFailureMessage(
    `${getEditorSqlPayloadMessage(pData)}\n${getEditorSqlPayloadDetailText(pData)}`
  );
}

function splitEditorSqlIntoExecutableBlocks(sqlText) {
  const normalized = normalizeCodeContent(sqlText || "");
  if (!normalized.trim()) return [];

  const lines = normalized.split("\n");
  const blocks = [];
  let current = [];
  let sawSlashDelimiter = false;

  lines.forEach((line) => {
    if (/^\s*\/\s*(?:--.*)?$/.test(line)) {
      sawSlashDelimiter = true;
      const block = current.join("\n").trim();
      if (block) blocks.push(block);
      current = [];
      return;
    }
    current.push(line);
  });

  const tail = current.join("\n").trim();
  if (tail) blocks.push(tail);

  if (!sawSlashDelimiter) {
    return normalized.trim() ? [normalized.trim()] : [];
  }
  return blocks;
}

function extractEditorCompiledObjectFromSql(sqlText) {
  const source = normalizeCodeContent(sqlText || "");
  const match = source.match(
    /create\s+(?:or\s+replace\s+)?(?:editionable\s+|noneditionable\s+)?(package\s+body|package|procedure|function|trigger|type\s+body|type|view)\s+((?:"[^"]+"|[A-Za-z0-9_$#]+)(?:\.(?:"[^"]+"|[A-Za-z0-9_$#]+))?)/i
  );
  if (!match) return null;

  const objectType = String(match[1] || "").replace(/\s+/g, " ").trim().toUpperCase();
  const rawName = String(match[2] || "").trim();
  if (!objectType || !rawName) return null;

  const objectToken = rawName.split(".").pop() || rawName;
  const objectName = objectToken.replace(/^"(.*)"$/, "$1").replace(/"/g, "").trim();
  if (!objectName) return null;

  return { type: objectType, name: objectName };
}

function toEditorSqlLiteral(value) {
  return `'${String(value || "").replace(/'/g, "''")}'`;
}

function buildEditorCompilationErrorsQuery(blockSql, options) {
  const broadSearch = !!(options && options.broadSearch);
  const objectMeta = broadSearch ? null : extractEditorCompiledObjectFromSql(blockSql);
  let whereClause = "";
  if (objectMeta && objectMeta.name && objectMeta.type) {
    whereClause = `
      WHERE UPPER(name) = UPPER(${toEditorSqlLiteral(objectMeta.name)})
        AND UPPER(type) = UPPER(${toEditorSqlLiteral(objectMeta.type)})
    `;
  }

  return `
    SELECT
      name,
      type,
      line,
      position,
      text
    FROM user_errors
    ${whereClause}
    ORDER BY name, type, sequence
  `.trim();
}

function getEditorRowFieldValue(row, candidates) {
  if (!row || typeof row !== "object") return "";
  const keys = Object.keys(row);
  for (const candidate of candidates) {
    if (Object.prototype.hasOwnProperty.call(row, candidate)) {
      return row[candidate];
    }
    const foundKey = keys.find((key) => String(key).toLowerCase() === String(candidate).toLowerCase());
    if (foundKey) return row[foundKey];
  }
  return "";
}

function formatEditorCompilationErrorRows(rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  if (!safeRows.length) return null;

  const detailLines = [];
  let primaryMessage = "";

  safeRows.forEach((row) => {
    const objName = String(getEditorRowFieldValue(row, ["name"]) || "").trim();
    const objType = String(getEditorRowFieldValue(row, ["type"]) || "").trim();
    const lineNo = Number(getEditorRowFieldValue(row, ["line"]));
    const colNo = Number(getEditorRowFieldValue(row, ["position", "column", "col"]));
    const issue = String(getEditorRowFieldValue(row, ["text", "message", "error"]) || "").trim();

    const objectLabel = [objType, objName].filter(Boolean).join(" ").trim() || "Compilation issue";
    const locationParts = [];
    if (Number.isFinite(lineNo) && lineNo > 0) locationParts.push(`line ${lineNo}`);
    if (Number.isFinite(colNo) && colNo > 0) locationParts.push(`column ${colNo}`);
    const locationText = locationParts.length ? ` at ${locationParts.join(", ")}` : "";
    const issueText = issue || "Unknown compilation error.";
    const renderedLine = `${objectLabel}${locationText}: ${issueText}`;

    if (!primaryMessage) primaryMessage = renderedLine;
    detailLines.push(renderedLine);
  });

  if (!primaryMessage) return null;
  return {
    primaryMessage,
    detailsText: detailLines.join("\n")
  };
}

function getEditorSqlAjaxErrorMessage(jqXHR, textStatus, errorThrown) {
  let message = "Unable to run script right now.";
  const responseText = jqXHR && jqXHR.responseText ? String(jqXHR.responseText) : "";
  if (responseText) {
    try {
      const parsed = JSON.parse(responseText);
      message = parsed.error || parsed.message || message;
    } catch (e) {
      message = responseText.length > 420 ? `${responseText.slice(0, 420)}...` : responseText;
    }
  } else if (errorThrown) {
    message = String(errorThrown);
  } else if (textStatus) {
    message = String(textStatus);
  }
  return message;
}

function getEditorSqlAjaxErrorDetailText(jqXHR) {
  const responseText = jqXHR && jqXHR.responseText ? String(jqXHR.responseText) : "";
  if (!responseText) return "";
  try {
    const parsed = JSON.parse(responseText);
    return getEditorSqlPayloadDetailText(parsed);
  } catch (e) {
    return "";
  }
}

function executeEditorSqlRequest(responseId, sqlText, onSuccess, onError) {
  apex.server.process(
    RUN_EDITOR_SQL_PROCESS_NAME,
    { x01: responseId, x02: sqlText, p_clob_01: sqlText },
    {
      dataType: "json",
      success: function(rawPayload) {
        const pData = normalizeEditorSqlRunPayload(rawPayload);
        if (typeof onSuccess === "function") onSuccess(pData, rawPayload);
      },
      error: function(jqXHR, textStatus, errorThrown) {
        if (typeof onError === "function") onError(jqXHR, textStatus, errorThrown);
      }
    }
  );
}

function shouldSkipRunEditorSqlConfirmation() {
  return getAskOracleSessionBooleanPreference(ASK_ORACLE_RUN_SQL_CONFIRM_PREF, false);
}

function rememberSkipRunEditorSqlConfirmation() {
  setAskOracleSessionBooleanPreference(ASK_ORACLE_RUN_SQL_CONFIRM_PREF, true);
}

function buildEditorRunOutputTableHtml(rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  if (safeRows.length === 0) return "";

  const shownRows = safeRows.slice(0, CODE_EDITOR_RUN_OUTPUT_MAX_ROWS);
  const columnSet = new Set();
  shownRows.forEach((row) => {
    if (row && typeof row === "object") {
      Object.keys(row).forEach((key) => columnSet.add(key));
    }
  });
  const columns = Array.from(columnSet);

  if (columns.length === 0) {
    return `<pre class="code-editor-run-output-pre">${escapeHtml(JSON.stringify(shownRows, null, 2))}</pre>`;
  }

  const headerHtml = columns.map((col) => `<th>${escapeHtml(col)}</th>`).join("");
  const bodyHtml = shownRows.map((row) => {
    const cells = columns.map((col) => {
      const value = row && Object.prototype.hasOwnProperty.call(row, col) ? row[col] : "";
      if (value === null || typeof value === "undefined") return "<td></td>";
      if (typeof value === "object") return `<td>${escapeHtml(JSON.stringify(value))}</td>`;
      return `<td>${escapeHtml(String(value))}</td>`;
    }).join("");
    return `<tr>${cells}</tr>`;
  }).join("");

  return `
    <div class="llm-sql-table-wrap code-editor-run-output-table-wrap">
      <table class="llm-sql-table code-editor-run-output-table">
        <thead><tr>${headerHtml}</tr></thead>
        <tbody>${bodyHtml}</tbody>
      </table>
    </div>
    ${safeRows.length > shownRows.length
      ? `<div class="code-editor-run-output-note">Showing ${shownRows.length} of ${safeRows.length} rows in editor output.</div>`
      : ""
    }
  `;
}

function renderEditorSqlRunResult(responseId, pData, fallbackSql) {
  const targetId = String((pData && pData.id) || responseId || "");
  if (!targetId) return { hasResultRows: false, totalRows: NaN, rowsAffected: NaN, message: "", isQuery: false };

  console.log("[RUN_EDITOR_SQL] rendering result", {
    responseId,
    targetId,
    totalRowCount: pData && pData.totalRowCount
  });

  const resultRows = getEditorRunResultRowsFromPayload(pData);
  const hasResultRows = resultRows.length > 0;
  const totalRows = Number(pData && pData.totalRowCount);
  const rowsAffected = Number(
    pData && (pData.rowsAffected ?? pData.rows_affected ?? pData.rowCount ?? pData.row_count)
  );
  const querySql = String((pData && pData.sql) || fallbackSql || "");
  const isQuery = isLikelySelectSql(querySql);
  const backendMessage = String(
    (pData && (
      pData.message ||
      pData.status_message ||
      pData.result_message ||
      pData.output_message ||
      pData.info
    )) || ""
  ).trim();

  if (hasResultRows) {
    const metaParts = [];
    if (Number.isFinite(totalRows)) metaParts.push(`Total Rows: ${totalRows}`);
    metaParts.push(`Displayed: ${Math.min(resultRows.length, CODE_EDITOR_RUN_OUTPUT_MAX_ROWS)}`);
    if (!isQuery && Number.isFinite(rowsAffected)) metaParts.push(`Rows Affected: ${rowsAffected}`);
    if (backendMessage) metaParts.push(`Message: ${backendMessage}`);

    const tableHtml = buildEditorRunOutputTableHtml(resultRows);
    setEditorRunOutputHtml(
      "Execution Output",
      `
        <div class="code-editor-run-output-meta">${escapeHtml(metaParts.join(" | "))}</div>
        ${tableHtml}
      `,
      "result"
    );
  } else {
    const summaryLines = [];
    if (isQuery && Number.isFinite(totalRows)) {
      summaryLines.push(`Query executed successfully. Rows: ${Math.max(0, totalRows)}.`);
      if (backendMessage && !/query executed successfully/i.test(backendMessage)) {
        summaryLines.push(backendMessage);
      }
    } else if (isQuery) {
      summaryLines.push(backendMessage || "Query executed successfully.");
    } else if (!isQuery && Number.isFinite(rowsAffected)) {
      if (backendMessage) summaryLines.push(backendMessage);
      summaryLines.push(`Rows affected: ${rowsAffected}`);
    } else if (backendMessage) {
      summaryLines.push(backendMessage);
    }
    if (summaryLines.length === 0) summaryLines.push("Statement executed successfully.");
    setEditorRunOutputHtml(
      "Execution Output",
      `<pre class="code-editor-run-output-pre">${escapeHtml(summaryLines.join("\n"))}</pre>`,
      isQuery ? "result" : "log"
    );
  }

  return { hasResultRows, totalRows, rowsAffected, message: backendMessage, isQuery };
}

async function runEditorSqlFromEditor() {
  if (codeEditorSqlRunInFlight) return;
  if (!isEditorSqlRunEnabled()) {
    refreshCodeEditorRunButtonState();
    setEditorRunStatus("warning", "Run Unavailable", "Open a response in editor to run.");
    console.log("[RUN_EDITOR_SQL] blocked: missing editor context", {
      activeEditorFileExt,
      activeEditorResponseId
    });
    return;
  }

  const sqlText = normalizeCodeContent(getEditorContent()).trim();
  captureActiveCodeEditorTabContent();
  if (!sqlText) {
    setEditorRunStatus("warning", "Run Skipped", "SQL is empty. Add a query and run again.");
    showEditorRunSqlError("SQL is empty. Add a query and run again.");
    return;
  }

  if (!shouldSkipRunEditorSqlConfirmation()) {
    const confirmResult = await showAppConfirmDialogWithDoNotAsk(
      "Please confirm you have reviewed this code and it is safe to execute in the database.",
      {
        title: "Run SQL",
        confirmLabel: "Run",
        cancelLabel: "Cancel",
        checkboxLabel: "Don't ask this again",
        checkboxNote: "Saved for this session only."
      }
    );
    if (!confirmResult || !confirmResult.confirmed) {
      setEditorRunStatus("warning", "Run Cancelled", "Execution cancelled by user confirmation.");
      showAppToast("Execution cancelled.", "", 1800);
      return;
    }
    if (confirmResult.doNotAskAgain) {
      rememberSkipRunEditorSqlConfirmation();
    }
  }

  const responseId = activeEditorResponseId;
  console.groupCollapsed("[RUN_EDITOR_SQL] request start");
  console.log("responseId:", responseId);
  console.log("file extension:", activeEditorFileExt);
  console.log("sql length:", sqlText.length);
  console.log("sql preview:", sqlText.slice(0, 800));
  console.groupEnd();

  const executionBlocks = splitEditorSqlIntoExecutableBlocks(sqlText);
  if (!executionBlocks.length) {
    setEditorRunStatus("warning", "Run Skipped", "No executable SQL blocks found.");
    showEditorRunSqlError("No executable SQL blocks found.");
    return;
  }

  codeEditorSqlRunInFlight = true;
  refreshCodeEditorRunButtonState();
  clearEditorSyntaxIssueMarkers();
  setEditorRunStatus(
    "running",
    "Running Script",
    executionBlocks.length > 1
      ? `Detected ${executionBlocks.length} slash-delimited blocks. Executing sequentially...`
      : "Sending script to backend process RUN_EDITOR_SQL..."
  );
  setEditorRunOutputHtml(
    "Execution Output",
    `<pre class="code-editor-run-output-pre">${
      executionBlocks.length > 1
        ? `Executing ${executionBlocks.length} blocks sequentially...`
        : "Running script..."
    }</pre>`,
    "log"
  );
  apex.message.clearErrors();

  let lastSuccessPayload = null;
  let lastExecutedSql = sqlText;
  const totalBlocks = executionBlocks.length;

  function finalizeRunRequest() {
    codeEditorSqlRunInFlight = false;
    refreshCodeEditorRunButtonState();
  }

  function finishRunWithError(baseMessage, blockSql, blockIndex, detailText) {
    const blockPrefix = totalBlocks > 1
      ? `Block ${blockIndex + 1} of ${totalBlocks} failed.`
      : "";
    const initialMessage = [blockPrefix, String(baseMessage || "Script execution failed.")].filter(Boolean).join(" ");
    const extraDetails = String(detailText || "").trim();

    if (!isCompilationFailureMessage(`${initialMessage}\n${extraDetails}`)) {
      showEditorRunSqlError(initialMessage, extraDetails);
      finalizeRunRequest();
      return;
    }

    const lookupSql = buildEditorCompilationErrorsQuery(blockSql, { broadSearch: false });
    executeEditorSqlRequest(
      responseId,
      lookupSql,
      function(errorPayload) {
        const rows = normalizeEditorRunResultRows(errorPayload && errorPayload.results);
        const formatted = formatEditorCompilationErrorRows(rows);
        if (formatted && formatted.primaryMessage) {
          const finalMessage = [blockPrefix, formatted.primaryMessage].filter(Boolean).join(" ");
          const mergedDetails = [formatted.detailsText, extraDetails].filter(Boolean).join("\n");
          showEditorRunSqlError(finalMessage, mergedDetails);
        } else {
          const broadLookupSql = buildEditorCompilationErrorsQuery("", { broadSearch: true });
          executeEditorSqlRequest(
            responseId,
            broadLookupSql,
            function(broadPayload) {
              const broadRows = normalizeEditorRunResultRows(broadPayload && broadPayload.results);
              const broadFormatted = formatEditorCompilationErrorRows(broadRows);
              if (broadFormatted && broadFormatted.primaryMessage) {
                const broadMessage = [blockPrefix, broadFormatted.primaryMessage].filter(Boolean).join(" ");
                const mergedBroadDetails = [broadFormatted.detailsText, extraDetails].filter(Boolean).join("\n");
                showEditorRunSqlError(broadMessage, mergedBroadDetails);
              } else {
                showEditorRunSqlError(initialMessage, extraDetails);
              }
              finalizeRunRequest();
            },
            function() {
              showEditorRunSqlError(initialMessage, extraDetails);
              finalizeRunRequest();
            }
          );
          return;
        }
        finalizeRunRequest();
      },
      function() {
        showEditorRunSqlError(initialMessage, extraDetails);
        finalizeRunRequest();
      }
    );
  }

  function executeNextBlock(blockIndex) {
    if (blockIndex >= totalBlocks) {
      const runSummary = renderEditorSqlRunResult(responseId, lastSuccessPayload, lastExecutedSql);
      let successMessage = totalBlocks > 1
        ? `Executed ${totalBlocks} blocks successfully.`
        : "Script executed successfully.";
      if (runSummary && runSummary.hasResultRows && Number.isFinite(runSummary.totalRows)) {
        successMessage = totalBlocks > 1
          ? `Executed ${totalBlocks} blocks successfully. Last query rows: ${runSummary.totalRows}.`
          : `Query executed successfully. Rows: ${runSummary.totalRows}.`;
      } else if (runSummary && runSummary.isQuery && Number.isFinite(runSummary.totalRows)) {
        successMessage = totalBlocks > 1
          ? `Executed ${totalBlocks} blocks successfully. Last query rows: ${runSummary.totalRows}.`
          : `Query executed successfully. Rows: ${runSummary.totalRows}.`;
      } else if (runSummary && !runSummary.isQuery && Number.isFinite(runSummary.rowsAffected)) {
        successMessage = totalBlocks > 1
          ? `Executed ${totalBlocks} blocks successfully. Last statement affected ${runSummary.rowsAffected} rows.`
          : `Statement executed successfully. Rows affected: ${runSummary.rowsAffected}.`;
      } else if (runSummary && runSummary.message && totalBlocks === 1) {
        successMessage = runSummary.message;
      }
      clearEditorSyntaxIssueMarkers();
      setEditorRunStatus("success", "Run Succeeded", successMessage);
      // Keep only the output pane visible after success.
      hideEditorRunStatusPanel();
      showAppToast(successMessage, "success", 2600);
      finalizeRunRequest();
      return;
    }

    const blockSql = executionBlocks[blockIndex];
    setEditorRunStatus(
      "running",
      "Running Script",
      totalBlocks > 1
        ? `Executing block ${blockIndex + 1} of ${totalBlocks}...`
        : "Running script..."
    );
    if (totalBlocks > 1) {
      setEditorRunOutputHtml(
        "Execution Output",
        `<pre class="code-editor-run-output-pre">Executing block ${blockIndex + 1} of ${totalBlocks}...</pre>`,
        "log"
      );
    }

    executeEditorSqlRequest(
      responseId,
      blockSql,
      function(pData, rawPayload) {
        console.log("[RUN_EDITOR_SQL] success callback raw payload:", rawPayload);
        console.log("[RUN_EDITOR_SQL] normalized payload:", pData);

        if (isEditorSqlRunPayloadFailure(pData)) {
          finishRunWithError(
            getEditorSqlPayloadMessage(pData) || "Script execution failed.",
            blockSql,
            blockIndex,
            getEditorSqlPayloadDetailText(pData)
          );
          return;
        }

        lastSuccessPayload = pData;
        lastExecutedSql = blockSql;
        executeNextBlock(blockIndex + 1);
      },
      function(jqXHR, textStatus, errorThrown) {
        console.error("[RUN_EDITOR_SQL] error callback", {
          status: jqXHR && jqXHR.status,
          statusText: jqXHR && jqXHR.statusText,
          textStatus,
          errorThrown,
          responseText: jqXHR && jqXHR.responseText
        });
        const message = getEditorSqlAjaxErrorMessage(jqXHR, textStatus, errorThrown);
        const details = getEditorSqlAjaxErrorDetailText(jqXHR);
        finishRunWithError(message, blockSql, blockIndex, details);
      }
    );
  }

  executeNextBlock(0);
}

function setEditorFileName(responseId, ext) {
  const fileNameEl = getEditorFileNameEl();
  if (!fileNameEl) return;
  const activeTab = getCodeEditorTabById(activeCodeEditorTabId);
  if (
    activeTab &&
    String(activeTab.responseId || "") === String(responseId || "") &&
    String(activeTab.ext || "txt").toLowerCase() === String(ext || "txt").toLowerCase()
  ) {
    fileNameEl.textContent = getCodeEditorTabTitle(activeTab);
    return;
  }
  fileNameEl.textContent = getCodeEditorFileName(responseId, ext);
}

function getAceModeFromFileExtension(ext) {
  const value = (ext || "").toLowerCase();
  const map = {
    js: "javascript",
    json: "json",
    diff: "diff",
    diffselect: "text",
    sql: "sql",
    py: "python",
    java: "java",
    html: "html",
    xml: "xml",
    sh: "sh",
    txt: "text"
  };
  return map[value] || "text";
}

function setEditorLanguageMode(ext) {
  const instance = ensureAceEditorInstance();
  if (!instance) return;
  const mode = getAceModeFromFileExtension(ext);
  instance.session.setMode(`ace/mode/${mode}`);
}

function setEditorContent(value) {
  const text = value || "";
  setActiveCodeEditorTabContent(text);
  const textareaEl = getEditorTextareaEl();
  if (textareaEl) textareaEl.value = text;
  const instance = ensureAceEditorInstance();
  if (instance) {
    instance.setValue(text, -1);
  }
}

function getEditorContent() {
  const instance = ensureAceEditorInstance();
  if (instance) return instance.getValue();
  const textareaEl = getEditorTextareaEl();
  return textareaEl ? textareaEl.value : "";
}

function focusEditorSurface() {
  const instance = ensureAceEditorInstance();
  if (instance) {
    instance.focus();
    return;
  }
  const textareaEl = getEditorTextareaEl();
  if (!textareaEl) return;
  textareaEl.focus();
  const len = textareaEl.value.length;
  textareaEl.setSelectionRange(len, len);
}

function closeCodeEditorPanel() {
  captureActiveCodeEditorTabContent();
  clearCodeEditorNavCollapseTimers();
  if (codeEditorOpenNavTimerId) {
    try { clearTimeout(codeEditorOpenNavTimerId); } catch (e) {}
    codeEditorOpenNavTimerId = null;
  }
  document.body.classList.remove("code-editor-mode");
  restoreTreeNavigationAfterEditor();
  restoreLeftNavigationAfterEditor();
  forceExpandLeftNavigationAfterEditorClose();
  [40, 160, 320, 640, 1000].forEach((delay) => {
    setTimeout(forceExpandLeftNavigationAfterEditorClose, delay);
  });
  activeEditorResponseId = null;
  activeEditorFileExt = "txt";
  resetCodeEditorTabs();
  const fileNameEl = getEditorFileNameEl();
  if (fileNameEl) fileNameEl.textContent = "response.txt";
  codeEditorSqlRunInFlight = false;
  clearEditorSyntaxIssueMarkers();
  clearPendingCodeDiff();
  setCodeEditorDiffWorkbenchMode(false);
  clearEditorRunOutput();
  resetEditorRunStatusText();
  hideEditorRunPanels();
  refreshCodeEditorRunButtonState();
  applyFooterAppearance();
  syncCodeEditorLayout();
  focusPromptInputForCaret(20);
}

function applyEditorContentToResponse() {
  runEditorSqlFromEditor();
}

function downloadEditorContentToFile() {
  if (!activeEditorResponseId) return;
  captureActiveCodeEditorTabContent();
  const content = getEditorContent();

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const ext = activeEditorFileExt || "txt";
  const base = getResponseDisplayBaseName(activeEditorResponseId);
  const fileName = `${base}-${timestamp}.${ext}`;
  triggerFileDownload(content || "", fileName);
}

function openResponseInEditor(id) {
  const responseId = String(id || "").trim();
  if (!responseId) return;
  if (!isAskOracleOpenEditorEnabled()) {
    showAppToast("Code View is disabled by admin settings.", "error", 2200);
    return;
  }

  function showNoContentFoundError() {
    apex.message.clearErrors();
    apex.message.showErrors([{
      type: "error",
      location: "page",
      message: "No response content found for Code View.",
      unsafe: false
    }]);
  }

  function openWithPayload(payload) {
    const content = String((payload && payload.content) || "");
    if (!content.trim()) {
      showNoContentFoundError();
      return;
    }
    const normalizedPayload = {
      content: content,
      ext: String((payload && payload.ext) || "txt").toLowerCase() || "txt",
      hasCode:
        payload && Object.prototype.hasOwnProperty.call(payload, "hasCode")
          ? payload.hasCode === true
          : String((payload && payload.ext) || "txt").toLowerCase() !== "txt"
    };
    if (!String(normalizedPayload.content || "").trim()) {
      showNoContentFoundError();
      syncResponseOpenEditorButtonsForResponse(responseId);
      return;
    }

    cacheResponseDownloadPayload(responseId, normalizedPayload);

    const panel = ensureCodeEditorPanel();
    if (!panel) return;

    const wasEditorModeOpen = document.body.classList.contains("code-editor-mode");
    if (!wasEditorModeOpen) {
      resetCodeEditorPanelWidthForOpen();
    }
    document.body.classList.add("code-editor-mode");
    applyFooterAppearance();
    syncCodeEditorLayout();
    if (!wasEditorModeOpen) {
      scheduleNavigationStateForEditorOpen(140);
    }

    const tab = createCodeEditorTab(responseId, normalizedPayload.ext || "txt", normalizedPayload.content);
    if (!tab) return;

    switchCodeEditorTab(tab.id, { focus: false, preserveOutput: false });
    clearEditorSyntaxIssueMarkers();
    refreshCodeEditorRunButtonState();

    setTimeout(() => {
      focusEditorSurface();
      syncCodeEditorLayout();
    }, 20);

    ensureAceEditorLoaded(function(loaded) {
      if (!loaded || !document.body.classList.contains("code-editor-mode")) return;
      switchCodeEditorTab(tab.id, { focus: false, preserveOutput: true, skipCapture: true });
      refreshCodeEditorRunButtonState();
      focusEditorSurface();
      syncCodeEditorLayout();
    });
  }

  const cachedPayload = getCachedResponseDownloadPayload(responseId);
  if (cachedPayload && String(cachedPayload.content || "").trim()) {
    openWithPayload(cachedPayload);
    return;
  }

  fetchResponseDownloadPayload(responseId, function(serverPayload) {
    if (serverPayload && String(serverPayload.content || "").trim()) {
      openWithPayload(serverPayload);
      return;
    }
    const domPayload = buildResponseDownloadPayload(responseId);
    if (domPayload && String(domPayload.content || "").trim()) {
      openWithPayload(domPayload);
      return;
    }
    showNoContentFoundError();
  });
}

function ensureInlineOpenEditorButtons() {
  const responseNodes = document.querySelectorAll(".response-box[id^='response-']");
  responseNodes.forEach((responseEl) => {
    responseEl.classList.remove("has-inline-open-editor");
    responseEl.querySelectorAll(".response-open-editor-inline").forEach((btn) => {
      try { btn.remove(); } catch (e) {}
    });
  });
}

function ensureResponseDownloadButtons() {
  ensureCodeEditorPanelCss();
  const allowPdfExportByAdmin = isAskOraclePdfExportButtonEnabled();
  const allowExcelExportByAdmin = isAskOracleExcelExportButtonEnabled();
  document.querySelectorAll(".response-box[id^='response-']").forEach((responseEl) => {
    ensureResponseTableInlineActionsForElement(responseEl);
  });
  const controls = document.querySelectorAll(".speech-controls[data-id]");
  controls.forEach((control) => {
    const id = control.getAttribute("data-id");
    if (!id) return;
    const responseEl = document.getElementById(`response-${id}`);
    const isNl2SqlShareEligible = isNl2SqlShareEligibleForResponse(id, responseEl);

    const leftGroup = control.firstElementChild;
    if (!leftGroup) return;
    const allowPdfExportActions = allowPdfExportByAdmin && responseAllowsPdfExportActions(id);
    const allowExcelExportActions = allowExcelExportByAdmin && responseAllowsPromptExportActions(id);

    if (!control.querySelector(".download-response-btn")) {
      const downloadBtn = document.createElement("button");
      downloadBtn.type = "button";
      downloadBtn.className = "speech-icon-button download-response-btn";
      downloadBtn.setAttribute("data-tooltip", "Download");
      downloadBtn.setAttribute("aria-label", "Download response");
      downloadBtn.innerHTML = getAskOracleInlineSvgIcon("download");
      downloadBtn.addEventListener("click", function() {
        downloadResponseToFile(id);
      });

      const copyBtn = leftGroup.querySelector(".speech-icon-button");
      if (copyBtn && copyBtn.nextSibling) {
        leftGroup.insertBefore(downloadBtn, copyBtn.nextSibling);
      } else {
        leftGroup.appendChild(downloadBtn);
      }
    }

    if (!allowPdfExportActions) {
      control.querySelectorAll(".export-pdf-response-btn").forEach((btn) => {
        try { btn.remove(); } catch (e) {}
      });
    } else if (!control.querySelector(".export-pdf-response-btn")) {
      const pdfBtn = createSpeechPdfExportButton(id);
      const downloadBtn = leftGroup.querySelector(".download-response-btn");
      if (downloadBtn && downloadBtn.nextSibling) {
        leftGroup.insertBefore(pdfBtn, downloadBtn.nextSibling);
      } else if (downloadBtn) {
        leftGroup.appendChild(pdfBtn);
      } else {
        leftGroup.appendChild(pdfBtn);
      }
    }

    if (!allowExcelExportActions) {
      control.querySelectorAll(".export-excel-response-btn").forEach((btn) => {
        try { btn.remove(); } catch (e) {}
      });
    } else if (!control.querySelector(".export-excel-response-btn")) {
      const excelBtn = createSpeechExcelExportButton(id);
      const pdfBtn = control.querySelector(".export-pdf-response-btn");
      if (pdfBtn && pdfBtn.nextSibling) {
        leftGroup.insertBefore(excelBtn, pdfBtn.nextSibling);
      } else if (pdfBtn) {
        leftGroup.appendChild(excelBtn);
      } else {
        leftGroup.appendChild(excelBtn);
      }
    }

    const hasOpenableContent = isAskOracleOpenEditorEnabled() && (responseHasCodeContent(id) || responseHasAgentTextContent(id));
    const existingOpenEditorBtn = control.querySelector(".open-editor-btn:not(.share-nl2sql-btn)");
    if (hasOpenableContent && !existingOpenEditorBtn) {
      const openEditorBtn = document.createElement("button");
      openEditorBtn.type = "button";
      openEditorBtn.className = "speech-icon-button open-editor-btn";
      openEditorBtn.setAttribute("data-tooltip", "Code View");
      openEditorBtn.setAttribute("aria-label", "Open code view");
      openEditorBtn.innerHTML = getAskOracleInlineSvgIcon("code") + `<span class="open-editor-btn-label">Code View</span>`;
      openEditorBtn.addEventListener("click", function() {
        openResponseInEditor(id);
      });
      leftGroup.appendChild(openEditorBtn);
    } else if (!hasOpenableContent && existingOpenEditorBtn) {
      setOpenEditorButtonVisibility(existingOpenEditorBtn, false);
    }

    const speechShareButtons = control.querySelectorAll(".share-nl2sql-btn");
    if (speechShareButtons.length > 1) {
      speechShareButtons.forEach((btn, idx) => {
        if (idx > 0) {
          try { btn.remove(); } catch (e) {}
        }
      });
    }
    if (shouldShowAskOracleShareLinkButtons() && isNl2SqlShareEligible && !control.querySelector(".share-nl2sql-btn")) {
      const shareBtn = document.createElement("button");
      shareBtn.type = "button";
      shareBtn.className = "speech-icon-button open-editor-btn share-nl2sql-btn";
      shareBtn.title = "Copy Table HyperLink";
      shareBtn.setAttribute("aria-label", "Copy Table HyperLink");
      shareBtn.setAttribute("data-tooltip", "Copy Table HyperLink");
      shareBtn.innerHTML = getAskOracleInlineSvgIcon("share", "ask-oracle-icon-share") + `<span class="open-editor-btn-label">Share Link</span>`;
      shareBtn.addEventListener("click", function() { openShareLinkActionMenu(id, shareBtn); });
      const openEditorBtn = control.querySelector(".open-editor-btn:not(.share-nl2sql-btn)");
      if (openEditorBtn && openEditorBtn.nextSibling) {
        leftGroup.insertBefore(shareBtn, openEditorBtn.nextSibling);
      } else if (openEditorBtn) {
        leftGroup.appendChild(shareBtn);
      } else {
        leftGroup.appendChild(shareBtn);
      }
    } else if (control.querySelector(".share-nl2sql-btn")) {
      control.querySelectorAll(".share-nl2sql-btn").forEach((btn) => {
        try { btn.remove(); } catch (e) {}
      });
    }
    syncResponseOpenEditorButtonsForResponse(id);
    syncResponseExportExcelButtonsForResponse(id);
  });

  document.querySelectorAll(".chart-sql-buttons[data-response-id], .ask-oracle-response-table-actions[data-response-id], .ask-oracle-sql-footer-actions[data-response-id]").forEach((row) => {
    const rowId = row.getAttribute("data-response-id");
    const responseEl = rowId ? document.getElementById(`response-${rowId}`) : null;
    const isNl2SqlShareEligible = !!(rowId && isNl2SqlShareEligibleForResponse(rowId, responseEl));
    const allowPdfExportActions = allowPdfExportByAdmin && responseAllowsPdfExportActions(rowId);
    const allowExcelExportActions = allowExcelExportByAdmin && responseAllowsPromptExportActions(rowId);
    if (!allowPdfExportActions) {
      row.querySelectorAll(".export-pdf-response-btn").forEach((btn) => {
        try { btn.remove(); } catch (e) {}
      });
    }
    if (!allowExcelExportActions) {
      row.querySelectorAll(".export-excel-response-btn").forEach((btn) => {
        try { btn.remove(); } catch (e) {}
      });
    }
    if (rowId && allowPdfExportActions && !row.querySelector(".export-pdf-response-btn")) {
      const pdfBtn = createActionRowPdfExportButton(rowId);
      const openEditorBtn = row.querySelector(".open-editor-btn");
      if (openEditorBtn && openEditorBtn.nextSibling) {
        row.insertBefore(pdfBtn, openEditorBtn.nextSibling);
      } else if (openEditorBtn) {
        row.appendChild(pdfBtn);
      } else {
        row.insertBefore(pdfBtn, row.firstChild);
      }
    }
    if (rowId && allowExcelExportActions && !row.querySelector(".export-excel-response-btn")) {
      const excelBtn = createActionRowExcelExportButton(rowId);
      const pdfBtn = row.querySelector(".export-pdf-response-btn");
      if (pdfBtn && pdfBtn.nextSibling) {
        row.insertBefore(excelBtn, pdfBtn.nextSibling);
      } else if (pdfBtn) {
        row.appendChild(excelBtn);
      } else if (row.firstChild) {
        row.insertBefore(excelBtn, row.firstChild);
      } else {
        row.appendChild(excelBtn);
      }
    }
    const shareButtons = row.querySelectorAll(".share-nl2sql-btn");
    if (shareButtons.length > 1) {
      shareButtons.forEach((btn, idx) => {
        if (idx > 0) {
          try { btn.remove(); } catch (e) {}
        }
      });
    }
    if (shouldShowAskOracleShareLinkButtons() && isNl2SqlShareEligible && !row.querySelector(".share-nl2sql-btn")) {
      const shareBtn = document.createElement("button");
      shareBtn.type = "button";
      shareBtn.className = "t-Button t-Button--icon t-Button--small share-nl2sql-btn";
      shareBtn.title = "Copy Table HyperLink";
      shareBtn.setAttribute("aria-label", "Copy Table HyperLink");
      shareBtn.setAttribute("data-tooltip", "Copy Table HyperLink");
      shareBtn.innerHTML = getAskOracleInlineSvgIcon("share", "ask-oracle-icon-share") + `<span class="t-Button-label">Share Link</span>`;
      shareBtn.addEventListener("click", function() { openShareLinkActionMenu(rowId, shareBtn); });
      const openEditorBtn = row.querySelector(".open-editor-btn");
      if (openEditorBtn && openEditorBtn.nextSibling) {
        row.insertBefore(shareBtn, openEditorBtn.nextSibling);
      } else if (openEditorBtn) {
        row.appendChild(shareBtn);
      } else {
        row.appendChild(shareBtn);
      }
    } else if (row.querySelector(".share-nl2sql-btn")) {
      row.querySelectorAll(".share-nl2sql-btn").forEach((btn) => {
        try { btn.remove(); } catch (e) {}
      });
    }
    syncResponseOpenEditorButtonsForResponse(rowId);
    syncResponseExportExcelButtonsForResponse(rowId);
  });

  ensureInlineOpenEditorButtons();
  applyAskOracleAdminActionButtonVisibility();
}

// ================== SPEECH FUNCTIONS ==================
function toggleSpeech(id, button) {
  // Stop other active speech
  if (currentSpeakingId && currentSpeakingId !== id) {
    const oldState = speechState[currentSpeakingId];
    if (oldState) {
      stopSpeech(oldState);
      updatePlayIcon(oldState.button, "play");
    }
  }

  let state = speechState[id] || { sentences: [], index: 0, isSpeaking: false, isPaused: false };
  const responseText = document.getElementById(`response-${id}`)?.textContent?.trim();
  if (!responseText) return;

  // Resume if paused
  if (state.isPaused) {
    window.speechSynthesis.resume();
    state.isPaused = false;
    updatePlayIcon(button, "pause");
    currentSpeakingId = id;
    return;
  }

  // Pause if speaking
  if (state.isSpeaking) {
    window.speechSynthesis.pause();
    state.isPaused = true;
    updatePlayIcon(button, "resume");
    return;
  }

  // New speech
  state.sentences = splitSentences(responseText);
  state.index = 0;
  state.button = button;
  state.id = id;
  state.isPaused = false;
  speechState[id] = state;

  currentSpeakingId = id;
  speakSentence(state);
  updatePlayIcon(button, "pause");
}

function speakSentence(state) {
  if (state.index >= state.sentences.length) {
    stopSpeech(state);
    updatePlayIcon(state.button, "play");
    return;
  }

  const utterance = new SpeechSynthesisUtterance(state.sentences[state.index]);

  if (selectedVoice) utterance.voice = selectedVoice;

  utterance.onend = () => {
    if (!state.isPaused) {
      state.index++;
      speakSentence(state);
    }
  };

  state.isSpeaking = true;
  window.speechSynthesis.speak(utterance);
}

function skipSentence(direction, id) {
  const state = speechState[id];
  if (!state) return;

  window.speechSynthesis.cancel();
  state.isPaused = false;
  state.index += direction;

  if (state.index < 0) state.index = 0;
  if (state.index >= state.sentences.length) {
    stopSpeech(state);
    updatePlayIcon(state.button, "play");
    return;
  }

  currentSpeakingId = id;
  speakSentence(state);
  updatePlayIcon(state.button, "pause");
}

function stopSpeech(state) {
  window.speechSynthesis.cancel();
  state.isSpeaking = false;
  state.isPaused = false;
  state.index = 0;
}

function updatePlayIcon(button, mode) {
  if (!button) return;
  const iconName =
    mode === "pause" ? "pause" :
    mode === "resume" ? "play-circle" :
    "play";
  button.innerHTML = getAskOracleInlineSvgIcon(iconName);
}

// ================== ERROR HANDLER ==================
var promptRequestInFlight = false;
var promptErrorHandled = false;
var activeExecutePromptRequest = null;
var activeAgentThoughtsStopFn = null;
var activeAgentTempPromptId = null;
var forceRunButtonStopMode = false;
var userStopRequested = false;
var PROMPT_ERROR_CARD_CSS_ID = "ask-oracle-prompt-error-css";

function parseServerErrorMessage(raw) {
  if (!raw) return "";
  try {
    const parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (parsed && typeof parsed.message === "string") return parsed.message;
    if (parsed && typeof parsed.error === "string") return parsed.error;
  } catch (e) {}
  return typeof raw === "string" ? raw : "";
}

function getFriendlyErrorDetails(source) {
  const status = Number(source?.status || source?.jqXHR?.status || 0);
  const responseText = source?.responseText || source?.jqXHR?.responseText || "";
  const serverMessage = parseServerErrorMessage(responseText);
  const technicalGatewayPattern = /(504\s+gateway\s+time-?out|gateway\s+time-?out|upstream\s+request\s+timeout)/i;
  const hasTechnicalGatewayMessage = technicalGatewayPattern.test(serverMessage || "");

  if (serverMessage && !hasTechnicalGatewayMessage) {
    return {
      title: "Request failed",
      message: serverMessage
    };
  }

  if (status === 504 || status === 524) {
    return {
      title: "Response delayed",
      message: "It took longer than expected to get a response from the AI model. Please try again in a moment."
    };
  }
  if (hasTechnicalGatewayMessage) {
    return {
      title: "Response delayed",
      message: "It took longer than expected to get a response from the AI model. Please try again in a moment."
    };
  }
  if (status === 502 || status === 503 || status === 522) {
    return {
      title: "Service temporarily unavailable",
      message: "The AI service is currently unavailable. Please try again shortly."
    };
  }
  if (status >= 500) {
    return {
      title: "Server error",
      message: "We could not complete this request due to a server-side error. Please retry."
    };
  }
  if (status === 0) {
    return {
      title: "Network error",
      message: "Connection was interrupted while processing your request."
    };
  }
  return {
    title: "Request failed",
    message: "Unable to process your request right now. Please try again."
  };
}

function normalizePromptErrorTitle(title) {
  const normalized = String(title || "Request failed").replace(/\s*-\s*$/, "").trim();
  return normalized || "Request failed";
}

function ensurePromptErrorCardCss() {
  if (document.getElementById(PROMPT_ERROR_CARD_CSS_ID)) return;

  const style = document.createElement("style");
  style.id = PROMPT_ERROR_CARD_CSS_ID;
  style.textContent = `
    .system-error-message {
      margin: 12px 0 16px;
      padding: 0;
      border: 1px solid #f3c4c6;
      border-radius: 12px;
      background: linear-gradient(180deg, #fff8f8 0%, #fff3f3 100%);
      color: #7f1d1d;
      box-shadow: 0 8px 18px rgba(127, 29, 29, 0.08);
      overflow: hidden;
    }
    .system-error-layout {
      display: grid;
      grid-template-columns: 34px minmax(0, 1fr);
      gap: 10px;
      align-items: flex-start;
      padding: 12px 14px;
    }
    .system-error-icon {
      width: 34px;
      height: 34px;
      border-radius: 999px;
      background: #fee2e2;
      color: #b91c1c;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      font-weight: 700;
      line-height: 1;
      user-select: none;
    }
    .system-error-content {
      min-width: 0;
    }
    .system-error-title {
      margin: 0 0 4px;
      font-size: 14px;
      line-height: 1.35;
      font-weight: 700;
      color: #991b1b;
    }
    .system-error-text {
      margin: 0;
      font-size: 13px;
      line-height: 1.5;
      color: #7f1d1d;
      white-space: pre-wrap;
      word-break: break-word;
    }
    body.ask-oracle-dark-ui .system-error-message,
    body.t-Body--dark .system-error-message,
    body.u-Theme--dark .system-error-message {
      border-color: #7f1d1d;
      background: linear-gradient(180deg, rgba(127, 29, 29, 0.35) 0%, rgba(69, 10, 10, 0.45) 100%);
      color: #fecaca;
      box-shadow: none;
    }
    body.ask-oracle-dark-ui .system-error-icon,
    body.t-Body--dark .system-error-icon,
    body.u-Theme--dark .system-error-icon {
      background: #7f1d1d;
      color: #fee2e2;
    }
    body.ask-oracle-dark-ui .system-error-title,
    body.t-Body--dark .system-error-title,
    body.u-Theme--dark .system-error-title {
      color: #fee2e2;
    }
    body.ask-oracle-dark-ui .system-error-text,
    body.t-Body--dark .system-error-text,
    body.u-Theme--dark .system-error-text {
      color: #fecaca;
    }
  `;
  document.head.appendChild(style);
}

function renderPromptErrorCard(details) {
  ensurePromptErrorCardCss();
  const container = getChatContainer();
  const titleText = normalizePromptErrorTitle(details && details.title);
  const messageText = String((details && details.message) || "Unable to process your request right now. Please try again.");

  if (!container) {
    apex.message.clearErrors();
    apex.message.showErrors([{
      type: "error",
      location: "page",
      message: `${titleText}: ${messageText}`,
      unsafe: false
    }]);
    return;
  }

  const lastLoaderId = apex.item("P1_LATEST_LOADER_ID").getValue();
  const loaderEl = lastLoaderId ? document.getElementById(lastLoaderId) : null;
  if (loaderEl) loaderEl.remove();

  const card = document.createElement("div");
  card.className = "chat-message system-error-message";
  card.setAttribute("role", "alert");
  card.setAttribute("aria-live", "assertive");
  card.innerHTML = `
    <div class="system-error-layout">
      <div class="system-error-icon" aria-hidden="true">!</div>
      <div class="system-error-content">
        <div class="system-error-title">${escapeHtml(titleText)}</div>
        <div class="system-error-text">${escapeHtml(messageText)}</div>
      </div>
    </div>
  `;

  container.insertAdjacentElement("beforeend", card);
  scrollToEndFor(card, { smooth: true });
}

function showPromptRequestError(source) {
  if (promptErrorHandled) return;
  promptErrorHandled = true;

  const details = getFriendlyErrorDetails(source || {});
  hideLoadingUI(apex.item("P1_LATEST_LOADER_ID").getValue());
  removeNewPromptScrollSpacer();
  renderPromptErrorCard(details);
  promptRequestInFlight = false;
  forceRunButtonStopMode = false;
  userStopRequested = false;
  activeExecutePromptRequest = null;
  activeAgentThoughtsStopFn = null;
  activeAgentTempPromptId = null;
  pendingCodeChangeRequest = null;
  refreshRunPromptButtonState();
}

function showPromptValidationError(message, title = "Missing information") {
  promptRequestInFlight = false;
  promptErrorHandled = false;
  forceRunButtonStopMode = false;
  userStopRequested = false;
  refreshRunPromptButtonState();
  showPromptRequestError({ responseText: JSON.stringify({ error: `${title}: ${message}` }) });
}

function ensureStyleGuidanceCss() {
  if (document.getElementById("style-guidance-css")) return;
  const style = document.createElement("style");
  style.id = "style-guidance-css";
  style.textContent = `
    @keyframes stylePulse {
      0%   { box-shadow: 0 0 0 0 rgba(74, 144, 226, 0.55); }
      70%  { box-shadow: 0 0 0 12px rgba(74, 144, 226, 0); }
      100% { box-shadow: 0 0 0 0 rgba(74, 144, 226, 0); }
    }
    .style-attention-ring {
      border-radius: 50% !important;
      animation: stylePulse 1.4s infinite;
      outline: 2px solid rgba(74, 144, 226, 0.7);
      outline-offset: 2px;
    }
    #style-guidance-hint {
      margin-top: 8px;
      margin-bottom: 4px;
      padding: 8px 10px;
      border: 1px solid #b9d6ff;
      background: #eef6ff;
      color: #163b66;
      border-radius: 8px;
      font-size: 13px;
      line-height: 1.35;
    }
  `;
  document.head.appendChild(style);
}

function clearConversationStyleGuidance() {
  const plusBtn = document.getElementById("addPrompt");
  if (plusBtn) plusBtn.classList.remove("style-attention-ring");

  const hint = document.getElementById("style-guidance-hint");
  if (hint) hint.remove();
}

function showConversationStyleGuidance() {
  ensureStyleGuidanceCss();

  const plusBtn = document.getElementById("addPrompt");
  if (plusBtn) {
    plusBtn.classList.add("style-attention-ring");
    plusBtn.addEventListener("click", clearConversationStyleGuidance, { once: true });
  }

  const existingHint = document.getElementById("style-guidance-hint");
  if (existingHint) return;

  const promptWrapper = document.getElementById("promptWrapper");
  if (!promptWrapper || !promptWrapper.parentElement) return;

  const hint = document.createElement("div");
  hint.id = "style-guidance-hint";
  hint.textContent = 'Select a conversational style by clicking the "+" button here.';
  promptWrapper.insertAdjacentElement("afterend", hint);
}

apex.jQuery(document).on("apexafterajaxerror", function(event, data) {
  if (!promptRequestInFlight) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  showPromptRequestError(data && (data.jqXHR || data));
});


//Prompt
var promptInput = document.querySelector("#P1_PROMPT1"); // Replace with your actual item
var runButton = document.querySelector("#RUN"); // Button or enter key
var CENTER_PROMPT_INSET_PX = 0; // Horizontal inset in center mode.
var CENTER_PROMPT_LEFT_MARGIN_PX = 286; // Mirrors ChatGPT-like content center with left nav open.
var CENTER_PROMPT_RIGHT_MARGIN_PX = 34; // Balances right-side viewport spacing.
var CENTER_PROMPT_MAX_WIDTH_PX = 780; // ChatGPT-like center prompt bar width.
var CENTER_PROMPT_TOP_RATIO = 45; // Vertical anchor for center prompt composition row.
var CENTER_PROMPT_TOP_OFFSET_PX = 0; // Fine-tune center prompt bar vertical offset in px.
var CENTER_PROMPT_TITLE_MARGIN_BOTTOM_PX = 18; // Space below the title in center prompt mode.
var FOOTER_PROMPT_LEFT_MARGIN_PX = 0; // Increase for more left margin in bottom prompt bar mode.
var FOOTER_PROMPT_RIGHT_MARGIN_PX = -25; // Increase for more right margin in bottom prompt bar mode.
var FOOTER_PROMPT_BOTTOM_MARGIN_PX = 0; // Increase to lift bottom prompt bar upward.
var RUN_PROMPT_IDLE_COLOR = "#121313";
var RUN_PROMPT_DISABLED_COLOR = "#c7c8cc";
var RUN_PROMPT_STOP_COLOR = "#c0392b";
var ASK_ORACLE_DARK_SURFACE_COLOR = "#252729";
var NEW_PROMPT_TOP_OFFSET_PX = 12;
var TOP_NAV_EXTRA_CLEARANCE_PX = 8;
var NEW_PROMPT_VISUAL_DOWN_SHIFT_PX = 10;
var NEW_PROMPT_SCROLL_SPACER_ID = "new-prompt-scroll-spacer";
var AUTO_SCROLL_BEFORE_RESPONSE_APPEND = true;
var AUTO_SCROLL_DURING_RESPONSE_RENDER = false;
var FOOTER_SCROLL_DOWN_BTN_ID = "footer-scroll-down-btn";
var FOOTER_SCROLL_DOWN_CSS_ID = "footer-scroll-down-css";
var CENTER_PROMPT_BAR_HEIGHT_DEFAULT_PX = 46; // Controls center prompt textarea height.
var CENTER_PROMPT_BAR_HEIGHT_PX = 46;
if (!Number.isFinite(CENTER_PROMPT_BAR_HEIGHT_PX) || CENTER_PROMPT_BAR_HEIGHT_PX <= 0) {
  CENTER_PROMPT_BAR_HEIGHT_PX = CENTER_PROMPT_BAR_HEIGHT_DEFAULT_PX;
}
window.CENTER_PROMPT_BAR_HEIGHT_PX = CENTER_PROMPT_BAR_HEIGHT_PX;
var PROMPT_INPUT_CENTER_BASE_HEIGHT_PX = CENTER_PROMPT_BAR_HEIGHT_PX;
var CENTER_PROMPT_INPUT_LINE_HEIGHT_PX = 24;
var CENTER_PROMPT_VERTICAL_PADDING_PX = 8;
var CENTER_PROMPT_TEXT_BASELINE_OFFSET_PX = 1; // Nudge typed text + placeholder down for visual center balance.
var CENTER_PROMPT_PLACEHOLDER_Y_OFFSET_PX = 0; // Keep placeholder baseline aligned with typed text.
var CENTER_PROMPT_PLACEHOLDER_MARGIN_TOP_PX = 0; // Extra top spacing for center prompt placeholder.
var CENTER_PROMPT_PLACEHOLDER_MARGIN_BOTTOM_PX = 0; // Extra bottom spacing for center prompt placeholder.
var ASK_ORACLE_CENTER_PROMPT_REFOCUS_DELAYS_MS = [0, 90, 220, 480, 900, 1400];
var ASK_ORACLE_CENTER_PROMPT_BLINK_CLASS = "ask-oracle-center-prompt-blink";
var askOracleCenterPromptBlinkTimer = null;
var PROMPT_INPUT_FOOTER_DESKTOP_BASE_HEIGHT_PX = 46;
var PROMPT_INPUT_FOOTER_MOBILE_BASE_HEIGHT_PX = 40;
var PROMPT_INPUT_MAX_HEIGHT_PX = 480;
var GEMINI_PROCESSING_SPINNER_CSS_ID = "gemini-processing-spinner-css";
var CODE_EDITOR_PANEL_CSS_ID = "code-editor-panel-css";
var CODE_EDITOR_PANEL_ID = "code-editor-panel";
var CODE_EDITOR_PANEL_DEFAULT_WIDTH_RATIO = 0.65;
var CODE_EDITOR_PANEL_DEFAULT_WIDTH_PX = 760;
var CODE_EDITOR_PANEL_MIN_WIDTH_PX = 420;
var CODE_EDITOR_PANEL_MAX_WIDTH_PX = 2800;
var CODE_EDITOR_PANEL_GAP_PX = 10;
var CODE_EDITOR_ACE_ID = "code-editor-ace";
var CODE_EDITOR_TAB_LIST_ID = "code-editor-tab-list";
var CODE_EDITOR_DIFF_WORKBENCH_ID = "code-editor-diff-workbench";
var CODE_EDITOR_DIFF_WORKBENCH_LEFT_ID = "code-editor-diff-workbench-left";
var CODE_EDITOR_DIFF_WORKBENCH_RIGHT_ID = "code-editor-diff-workbench-right";
var CODE_EDITOR_DIFF_WORKBENCH_COMPARE_ID = "code-editor-diff-workbench-compare";
var CODE_EDITOR_DIFF_WORKBENCH_ERROR_ID = "code-editor-diff-workbench-error";
var ACE_EDITOR_BASE_PATH = "https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.3";
var ACE_EDITOR_CDN_URL = `${ACE_EDITOR_BASE_PATH}/ace.min.js`;
var CODE_DIFF_MAX_LCS_CELLS = 180000;
var CODE_EDITOR_PANEL_MAX_WIDTH_RATIO = 0.88;
var CODE_EDITOR_RUN_OUTPUT_MAX_ROWS = 150;
var RUN_EDITOR_SQL_PROCESS_NAME = "RUN_EDITOR_SQL";
var CODE_EDITOR_RUN_OUTPUT_TAB_RESULT_ID = "code-editor-run-output-tab-result";
var CODE_EDITOR_RUN_OUTPUT_TAB_LOG_ID = "code-editor-run-output-tab-log";
var CODE_EDITOR_RUN_OUTPUT_RESULT_ID = "code-editor-run-output-result";
var CODE_EDITOR_RUN_OUTPUT_LOG_ID = "code-editor-run-output-log";
var RESPONSE_TABLE_ZOOM_MIN = 0.6;
var RESPONSE_TABLE_ZOOM_MAX = 2.0;
var RESPONSE_TABLE_ZOOM_STEP = 0.1;
var RESPONSE_TABLE_ZOOM_DEFAULT = 1.0;

var footerScrollDownObserver = null;
var footerScrollDownBoundScroller = null;
var footerScrollDownRefreshQueued = false;
var activeEditorResponseId = null;
var activeEditorFileExt = "txt";
var codeEditorAceInstance = null;
var codeEditorAceLoading = false;
var codeEditorAceCallbacks = [];
var pendingCodeChangeRequest = null;
var pendingCodeDiffState = null;
var codeEditorSqlRunInFlight = false;
var codeEditorPanelWidthPx = null;
var codeEditorSyntaxErrorMarkerId = null;
var codeEditorCollapsedTreeNav = false;
var codeEditorCollapsedLeftNav = false;
var codeEditorNavCollapseTimers = [];
var codeEditorOpenNavTimerId = null;
var CODE_EDITOR_PRESERVE_LEFT_NAV = true;
var codeEditorTabs = [];
var activeCodeEditorTabId = null;
var codeEditorTabSequence = 0;
var codeEditorTabDiffState = null;
var responseTableZoomById = Object.create(null);
var agentAutoVisualByPromptId = Object.create(null);
var askOracleMicBlockerBound = false;
var askOracleMicStopState = false;
var askOracleMicStopHeartbeatId = null;
var askOraclePromptInputBindRetryTimer = null;
var askOraclePromptInputBindRetryCount = 0;
var ASK_ORACLE_PROMPT_INPUT_BIND_MAX_RETRIES = 60;
var askOracleRunButtonBindRetryTimer = null;
var askOracleRunButtonBindRetryCount = 0;
var ASK_ORACLE_RUN_BUTTON_BIND_MAX_RETRIES = 60;

function getCenterPromptTopCssValue() {
  return `calc(${CENTER_PROMPT_TOP_RATIO}% + ${CENTER_PROMPT_TOP_OFFSET_PX}px)`;
}

function getRunPromptButtonEl() {
  return document.getElementById("runPrompt");
}

function getPromptInputValue() {
  const inputEl = document.getElementById("P1_PROMPT1");
  return inputEl ? inputEl.value : "";
}

function refreshRunPromptButtonState() {
  const btn = getRunPromptButtonEl();
  if (!btn) return;

  const icon = btn.querySelector("i");
  const hasText = getPromptInputValue().trim().length > 0;
  const shouldShowStop = promptRequestInFlight || forceRunButtonStopMode;
  const darkUi = document.body.classList.contains("ask-oracle-dark-ui");
  const surfaceColor = String(
    document.documentElement.style.getPropertyValue("--ask-oracle-footer-surface") || ""
  ).trim();
  const darkInactiveRunBg = "#6b7280";
  const darkActiveRunBg = "#ffffff";

  function setBtnStyle(property, value) {
    if (!btn) return;
    if (value === "" || value == null) {
      btn.style.removeProperty(property);
      return;
    }
    btn.style.setProperty(property, value, "important");
  }

  function setIconStyle(property, value) {
    if (!icon) return;
    if (value === "" || value == null) {
      icon.style.removeProperty(property);
      return;
    }
    icon.style.setProperty(property, value, "important");
  }

  if (shouldShowStop) {
    btn.disabled = false;
    setBtnStyle("background-color", RUN_PROMPT_STOP_COLOR);
    setBtnStyle("color", "#ffffff");
    setBtnStyle("border", darkUi ? "0" : "");
    btn.style.opacity = "1";
    btn.style.visibility = "visible";
    btn.style.cursor = "pointer";
    btn.title = "Stop response";
    if (icon) icon.className = "fa fa-stop";
    if (icon) {
      setIconStyle("color", "#ffffff");
      icon.style.opacity = "1";
      icon.style.visibility = "visible";
    }
    setPromptMicInteractionDisabled(true);
    stopPromptMicrophoneCapture();
    setAskOracleMicStopState(true);
    return;
  }

  btn.title = "Run Prompt";
  if (icon) icon.className = "fa fa-arrow-up";

  if (hasText) {
    btn.disabled = false;
    setBtnStyle("background-color", darkUi ? darkActiveRunBg : RUN_PROMPT_IDLE_COLOR);
    setBtnStyle("color", darkUi ? "#111827" : "");
    setBtnStyle("border", darkUi ? "0" : "");
    btn.style.opacity = "1";
    btn.style.visibility = "visible";
    btn.style.cursor = "pointer";
    if (icon) {
      setIconStyle("color", darkUi ? "#111827" : "");
      icon.style.opacity = "1";
      icon.style.visibility = "visible";
    }
  } else {
    btn.disabled = true;
    setBtnStyle("background-color", darkUi ? darkInactiveRunBg : RUN_PROMPT_DISABLED_COLOR);
    setBtnStyle("color", darkUi ? "#f3f4f6" : "");
    setBtnStyle("border", darkUi ? "0" : "");
    btn.style.opacity = "1";
    btn.style.visibility = "visible";
    btn.style.cursor = "not-allowed";
    if (icon) {
      setIconStyle("color", darkUi ? "#f3f4f6" : "");
      icon.style.opacity = "1";
      icon.style.visibility = "visible";
    }
  }
  setPromptMicInteractionDisabled(false);
  setAskOracleMicStopState(false);
  flushPendingAskOracleSidebarRebind();
}

function setRunPromptStopMode(enabled) {
  const stopMode = !!enabled;
  forceRunButtonStopMode = stopMode;
  setAskOracleMicStopState(stopMode);
  setPromptMicInteractionDisabled(stopMode);
  if (stopMode) {
    stopPromptMicrophoneCapture();
  }
  refreshRunPromptButtonState();
}

function focusPromptInputForCaret(delayMs = 0) {
  const doFocus = () => {
    const inputEl = document.getElementById("P1_PROMPT1");
    if (!inputEl || inputEl.disabled) return;
    inputEl.focus({ preventScroll: true });
    const len = inputEl.value.length;
    if (typeof inputEl.setSelectionRange === "function") {
      inputEl.setSelectionRange(len, len);
    } else {
      inputEl.selectionStart = len;
      inputEl.selectionEnd = len;
    }
  };

  if (delayMs > 0) {
    setTimeout(doFocus, delayMs);
  } else {
    requestAnimationFrame(doFocus);
  }
}

function shouldAutoFocusCenterPromptBar() {
  if (!document.body) return false;
  if (!document.body.classList.contains("prompt-center-mode")) return false;
  if (document.body.classList.contains("code-editor-mode")) return false;
  if (isPromptRequestRunning()) return false;
  const inputEl = document.getElementById("P1_PROMPT1");
  if (!inputEl || inputEl.disabled) return false;
  return true;
}

function triggerCenterPromptBarBlink() {
  if (!document.body || !document.body.classList.contains("prompt-center-mode")) return;
  const promptWrapper = document.getElementById("promptWrapper");
  if (!promptWrapper) return;

  promptWrapper.classList.remove(ASK_ORACLE_CENTER_PROMPT_BLINK_CLASS);
  void promptWrapper.offsetWidth;
  promptWrapper.classList.add(ASK_ORACLE_CENTER_PROMPT_BLINK_CLASS);

  if (askOracleCenterPromptBlinkTimer) {
    clearTimeout(askOracleCenterPromptBlinkTimer);
  }
  askOracleCenterPromptBlinkTimer = setTimeout(() => {
    try { promptWrapper.classList.remove(ASK_ORACLE_CENTER_PROMPT_BLINK_CLASS); } catch (e) {}
  }, 1500);
}

function focusCenterPromptBarAfterReload() {
  if (!shouldAutoFocusCenterPromptBar()) return;
  triggerCenterPromptBarBlink();

  ASK_ORACLE_CENTER_PROMPT_REFOCUS_DELAYS_MS.forEach((delayMs) => {
    setTimeout(() => {
      if (!shouldAutoFocusCenterPromptBar()) return;
      positionCenterPromptBar();
      focusPromptInputForCaret();
    }, delayMs);
  });
}

function getPromptInputBaseHeightPx() {
  if (document.body && document.body.classList.contains("prompt-center-mode")) {
    return PROMPT_INPUT_CENTER_BASE_HEIGHT_PX;
  }
  return window.innerWidth <= 768
    ? PROMPT_INPUT_FOOTER_MOBILE_BASE_HEIGHT_PX
    : PROMPT_INPUT_FOOTER_DESKTOP_BASE_HEIGHT_PX;
}

function syncCenterPromptShellHeight(inputEl) {
  if (!inputEl) return;
  if (!(document.body && document.body.classList.contains("prompt-center-mode"))) return;

  const promptWrapper = document.getElementById("promptWrapper");
  const shells = [
    promptWrapper,
    inputEl.closest(".prompt-wrapper"),
    document.querySelector(".prompt-wrapper"),
    document.getElementById("P1_PROMPT2"),
    document.getElementById("P1_PROMPT2_CONTAINER"),
    document.getElementById("P1_PROMPT2_display")
  ].filter(Boolean);

  const contentHeight = Math.max(PROMPT_INPUT_CENTER_BASE_HEIGHT_PX, inputEl.offsetHeight || 0);
  const shellHeight = Math.max(52, contentHeight + 20);
  shells.forEach((el) => {
    el.style.setProperty("min-height", `${shellHeight}px`, "important");
    el.style.setProperty("height", `${shellHeight}px`, "important");
    el.style.setProperty("overflow", "visible", "important");
  });
}

function autoGrowPromptInput() {
  const inputEl = document.getElementById("P1_PROMPT1");
  if (!inputEl) return;

  // Normalize any static-region inline offsets so typed/pasted text stays vertically centered.
  inputEl.style.setProperty("margin", "0", "important");
  inputEl.style.setProperty("margin-top", "0", "important");
  inputEl.style.setProperty("margin-right", "0", "important");
  inputEl.style.setProperty("margin-bottom", "0", "important");
  inputEl.style.setProperty("margin-left", "0", "important");
  inputEl.style.setProperty("position", "relative", "important");
  inputEl.style.setProperty("top", "auto", "important");
  inputEl.style.setProperty("bottom", "auto", "important");
  inputEl.style.setProperty("transform", "none", "important");

  const isCenterMode = !!(document.body && document.body.classList.contains("prompt-center-mode"));
  const css = window.getComputedStyle(inputEl);
  const fontSizePx = Math.max(12, parseFloat(css.fontSize) || 16);
  const centerLineHeightPx = Math.max(20, Math.round(fontSizePx * 1.35));
  const footerLineHeightPx = window.innerWidth <= 768
    ? Math.max(18, Math.round(fontSizePx * 1.2))
    : Math.max(20, Math.round(fontSizePx * 1.35));
  const baseHeight = getPromptInputBaseHeightPx();

  if (isCenterMode) {
    const centerHeight = Math.max(baseHeight, centerLineHeightPx + 10);
    const centerPadTop = Math.max(
      4,
      Math.floor((centerHeight - centerLineHeightPx) / 2) + CENTER_PROMPT_TEXT_BASELINE_OFFSET_PX
    );
    const centerPadBottom = Math.max(4, centerHeight - centerLineHeightPx - centerPadTop);
    inputEl.style.setProperty("padding-top", `${centerPadTop}px`, "important");
    inputEl.style.setProperty("padding-bottom", `${centerPadBottom}px`, "important");
    inputEl.style.setProperty("padding-left", "8px", "important");
    inputEl.style.setProperty("padding-right", "8px", "important");
    inputEl.style.setProperty("line-height", `${centerLineHeightPx}px`, "important");
    inputEl.style.setProperty("text-align", "left", "important");
    inputEl.style.setProperty("vertical-align", "middle", "important");
  } else {
    const footerHeight = Math.max(baseHeight, footerLineHeightPx + 8);
    const footerVerticalPaddingPx = Math.max(2, Math.floor((footerHeight - footerLineHeightPx) / 2));
    inputEl.style.setProperty("padding-top", `${footerVerticalPaddingPx}px`, "important");
    inputEl.style.setProperty("padding-bottom", `${footerVerticalPaddingPx}px`, "important");
    inputEl.style.setProperty("line-height", `${footerLineHeightPx}px`, "important");
  }

  inputEl.style.setProperty("height", "auto", "important");
  const manualHeight = Number(inputEl.dataset.manualPromptHeight || 0);
  const nextHeight = Math.min(
    PROMPT_INPUT_MAX_HEIGHT_PX,
    Math.max(baseHeight, manualHeight, inputEl.scrollHeight)
  );
  inputEl.style.setProperty("height", `${nextHeight}px`, "important");
  inputEl.style.overflowY = inputEl.scrollHeight > PROMPT_INPUT_MAX_HEIGHT_PX ? "auto" : "hidden";
  if (!String(inputEl.value || "").includes("\n")) {
    inputEl.scrollTop = 0;
  }
  syncCenterPromptShellHeight(inputEl);
}

function bindPromptInputResizeBehavior() {
  ensureAskOraclePromptCoreElements();
  const inputEl = document.getElementById("P1_PROMPT1");
  if (!inputEl) {
    if (askOraclePromptInputBindRetryCount < ASK_ORACLE_PROMPT_INPUT_BIND_MAX_RETRIES) {
      askOraclePromptInputBindRetryCount += 1;
      if (askOraclePromptInputBindRetryTimer) clearTimeout(askOraclePromptInputBindRetryTimer);
      askOraclePromptInputBindRetryTimer = setTimeout(bindPromptInputResizeBehavior, 200);
    }
    return;
  }
  askOraclePromptInputBindRetryCount = 0;
  if (askOraclePromptInputBindRetryTimer) {
    clearTimeout(askOraclePromptInputBindRetryTimer);
    askOraclePromptInputBindRetryTimer = null;
  }
  if (inputEl.dataset.multilineResizeBound === "true") return;
  inputEl.dataset.multilineResizeBound = "true";

  const refreshPromptInputUi = () => {
    if (!String(inputEl.value || "").includes("\n")) {
      delete inputEl.dataset.shiftEnterExpand;
    }
    autoGrowPromptInput();
    refreshRunPromptButtonState();
  };

  inputEl.addEventListener("input", refreshPromptInputUi);
  inputEl.addEventListener("change", refreshPromptInputUi);
  inputEl.addEventListener("keyup", refreshPromptInputUi);
  inputEl.addEventListener("paste", () => setTimeout(refreshPromptInputUi, 0));
  inputEl.addEventListener("cut", () => setTimeout(refreshPromptInputUi, 0));
  inputEl.addEventListener("drop", () => setTimeout(refreshPromptInputUi, 0));
  inputEl.addEventListener("mouseup", function() {
    inputEl.dataset.manualPromptHeight = String(inputEl.offsetHeight || getPromptInputBaseHeightPx());
    syncCenterPromptShellHeight(inputEl);
  });
  inputEl.addEventListener("keydown", function(e) {
    if (e.key === "Enter" && e.shiftKey) {
      inputEl.dataset.shiftEnterExpand = "true";
      setTimeout(refreshPromptInputUi, 0);
    } else if (e.key === "Enter" && !e.shiftKey) {
      // Keep Enter-submit path visually in sync with RUN click behavior.
      delete inputEl.dataset.shiftEnterExpand;
      setTimeout(refreshPromptInputUi, 0);
    }
  });

  refreshPromptInputUi();
}

function schedulePromptFreshScreenUiRefresh() {
  // Unified hook so keyboard Enter and RUN click can trigger the same async UI refresh timing.
  setTimeout(function() {
    autoGrowPromptInput();
    refreshRunPromptButtonState();
    scheduleFooterScrollDownRefresh();
  }, 0);
}

function ensureGeminiProcessingSpinnerCss() {
  if (document.getElementById(GEMINI_PROCESSING_SPINNER_CSS_ID)) return;

  const style = document.createElement("style");
  style.id = GEMINI_PROCESSING_SPINNER_CSS_ID;
  style.textContent = `
    @keyframes geminiRingSpin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    @keyframes geminiPulse {
      0%, 100% { opacity: 0.55; transform: scale(0.95); }
      50% { opacity: 1; transform: scale(1); }
    }
    @keyframes geminiDots {
      0% { width: 0ch; }
      100% { width: 3ch; }
    }
    .gemini-loader-host {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      padding: 8px 2px;
      min-height: 36px;
    }
    .gemini-processing-indicator {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      color: #4b5563;
      font-size: 13px;
      line-height: 1;
      font-weight: 500;
    }
    .gemini-processing-ring {
      width: 22px;
      height: 22px;
      border-radius: 999px;
      border: 3.5px solid rgba(99, 102, 241, 0.2);
      border-top-color: #6366f1;
      border-right-color: #22d3ee;
      box-shadow: 0 0 0 1px rgba(99, 102, 241, 0.08), 0 2px 8px rgba(99, 102, 241, 0.22);
      animation: geminiRingSpin 0.8s linear infinite;
      position: relative;
    }
    .gemini-processing-ring::after {
      content: "";
      position: absolute;
      inset: 4px;
      border-radius: 999px;
      background: radial-gradient(circle at 35% 35%, #7dd3fc 0%, #22d3ee 45%, #6366f1 100%);
      animation: geminiPulse 1s ease-in-out infinite;
    }
    .gemini-processing-label {
      letter-spacing: 0.01em;
    }
    .gemini-processing-dots {
      display: inline-block;
      width: 0ch;
      overflow: hidden;
      vertical-align: bottom;
      animation: geminiDots 1s steps(4, end) infinite;
    }
  `;
  document.head.appendChild(style);
}

function applyGeminiProcessingIndicator(loaderEl) {
  if (!loaderEl) return;
  ensureGeminiProcessingSpinnerCss();
  loaderEl.classList.add("gemini-loader-host");
  loaderEl.innerHTML = `
    <div class="gemini-processing-indicator" role="status" aria-live="polite">
      <span class="gemini-processing-ring" aria-hidden="true"></span>
      <span class="gemini-processing-label">Processing your prompt<span class="gemini-processing-dots">...</span></span>
    </div>
  `;
}

function createAskOracleInlinePromptLoader(promptEl, loaderId) {
  const normalizedId = String(loaderId || "").trim();
  if (!normalizedId) return null;

  let loaderEl = document.getElementById(normalizedId);
  if (!loaderEl) {
    loaderEl = document.createElement("div");
    loaderEl.id = normalizedId;
    loaderEl.className = "loading-indicator ask-oracle-inline-loader";
    loaderEl.style.display = "none";
    if (promptEl && promptEl.insertAdjacentElement) {
      promptEl.insertAdjacentElement("afterend", loaderEl);
    } else {
      const container = getChatContainer();
      if (container) {
        container.appendChild(loaderEl);
      }
    }
  }

  applyGeminiProcessingIndicator(loaderEl);
  return loaderEl;
}

function ensureAskOracleRunPromptLoader(tempPromptId) {
  let latestLoaderId = "";
  let latestPromptId = "";

  try {
    latestLoaderId = String(apex.item("P1_LATEST_LOADER_ID").getValue() || "").trim();
  } catch (e) {}
  try {
    latestPromptId = String(apex.item("P1_LATEST_PROMPT_ID").getValue() || "").trim();
  } catch (e) {}

  if (latestLoaderId && document.getElementById(latestLoaderId)) {
    showLoadingUI(latestLoaderId);
    return latestLoaderId;
  }

  let promptEl = latestPromptId ? document.getElementById(latestPromptId) : null;
  if (!promptEl) {
    const promptContainer = getChatContainer();
    if (promptContainer && typeof promptContainer.querySelectorAll === "function") {
      const prompts = promptContainer.querySelectorAll(".chat-message.user-message[id]");
      if (prompts.length > 0) {
        promptEl = prompts[prompts.length - 1];
        latestPromptId = String(promptEl.id || "").trim();
      }
    }
  }

  if (!latestLoaderId) {
    latestLoaderId = latestPromptId
      ? `loading-indicator-${latestPromptId}`
      : `loading-indicator-${tempPromptId}`;
  }

  const loaderEl = createAskOracleInlinePromptLoader(promptEl, latestLoaderId);
  if (loaderEl) {
    try {
      if (latestPromptId) {
        apex.item("P1_LATEST_PROMPT_ID").setValue(latestPromptId);
      }
      apex.item("P1_LATEST_LOADER_ID").setValue(latestLoaderId);
    } catch (e) {}
    showLoadingUI(latestLoaderId);
    return latestLoaderId;
  }

  showLoadingUI();
  return "";
}

function isPromptRequestRunning() {
  return !!(promptRequestInFlight || forceRunButtonStopMode);
}

function stopActivePromptRequest() {
  if (!isPromptRequestRunning()) return;

  userStopRequested = true;
  forceRunButtonStopMode = false;

  if (activeExecutePromptRequest && typeof activeExecutePromptRequest.abort === "function") {
    try { activeExecutePromptRequest.abort(); } catch (e) {}
  }
  activeExecutePromptRequest = null;

  if (typeof activeAgentThoughtsStopFn === "function") {
    try { activeAgentThoughtsStopFn(); } catch (e) {}
  }
  activeAgentThoughtsStopFn = null;

  if (activeAgentTempPromptId) {
    finishedPrompts.add(activeAgentTempPromptId);
    removePonderingContainer(activeAgentTempPromptId);
  }
  activeAgentTempPromptId = null;

  hideLoadingUI(apex.item("P1_LATEST_LOADER_ID").getValue());
  removeNewPromptScrollSpacer();
  promptRequestInFlight = false;
  promptErrorHandled = false;
  pendingCodeChangeRequest = null;
  refreshRunPromptButtonState();

  const inputEl = document.getElementById("P1_PROMPT1");
  if (inputEl) {
    inputEl.disabled = false;
    inputEl.focus({ preventScroll: true });
  }
}

function clearAskOracleConversationDom() {
  const promptsRoot = document.getElementById("PROMPTS");
  if (promptsRoot) {
    const promptList = promptsRoot.querySelector(".prompt-list");
    if (promptList) {
      promptList.innerHTML = "";
    }

    const selector = [
      ".chat-message",
      ".agent-thoughts",
      ".response-box",
      ".llm-chat",
      ".prompt-box",
      ".speech-controls",
      ".open-editor-btn",
      ".profile-label",
      '[class^="llm-more-rows-"]',
      '[class*=" llm-more-rows-"]',
      ".chart-sql-buttons",
      ".ask-oracle-sql-footer-actions",
      ".ask-oracle-response-table-actions",
      ".chart-container",
      ".chart-block",
      ".sql-block",
      `[id^="prompt-"]`,
      `[id^="response-"]`,
      `[id^="chart-container-"]`,
      `[id^="chart-block-"]`,
      `[id^="sql-block-"]`,
      `[id^="loading-indicator-"]`,
      `#${NEW_PROMPT_SCROLL_SPACER_ID}`
    ].join(", ");

    promptsRoot.querySelectorAll(selector).forEach((node) => {
      try { node.remove(); } catch (e) {}
    });
  }

  document.querySelectorAll(
    ".speech-controls[data-id], .chart-sql-buttons, .ask-oracle-sql-footer-actions, .ask-oracle-response-table-actions, .open-editor-btn, [class^='llm-more-rows-'], [class*=' llm-more-rows-']"
  ).forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  const orphanSelector = [
    ".chat-message",
    ".agent-thoughts",
    ".response-box",
    ".llm-chat",
    ".prompt-box",
    ".open-editor-btn",
    ".chart-sql-buttons",
    ".ask-oracle-sql-footer-actions",
    ".ask-oracle-response-table-actions",
    '[class^="llm-more-rows-"]',
    '[class*=" llm-more-rows-"]',
    `[id^="prompt-"]`,
    `[id^="response-"]`,
    `[id^="chart-container-"]`,
    `[id^="chart-block-"]`,
    `[id^="sql-block-"]`,
    `[id^="loading-indicator-"]`
  ].join(", ");
  document.querySelectorAll(orphanSelector).forEach((node) => {
    if (promptsRoot && promptsRoot.contains(node)) return;
    try { node.remove(); } catch (e) {}
  });
}

function clearAskOracleResponseActionControls() {
  const root = document.getElementById("PROMPTS") || document;
  const selector = [
    ".chart-sql-buttons",
    ".ask-oracle-sql-footer-actions",
    ".ask-oracle-response-table-actions",
    ".toggle-charts",
    ".toggle-sql",
    ".explore-btn",
    ".explain-btn",
    ".export-pdf-response-btn",
    ".export-excel-response-btn",
    ".conversation-time-btn",
    "[onclick*='redirectToExplorePage']",
    "[onclick*='redirectToExplainPage']"
  ].join(", ");
  root.querySelectorAll(selector).forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  root.querySelectorAll("a,button,.t-Button").forEach((node) => {
    const text = String(node.textContent || "").trim().toLowerCase();
    if (!text) return;
    if (
      text === "explore" ||
      text === "explain" ||
      text === "show charts" ||
      text === "customize charts" ||
      text === "show sql"
    ) {
      try { node.remove(); } catch (e) {}
    }
  });
}

function pruneAskOracleOrphanedResponseActionControls() {
  const promptsRoot = document.getElementById("PROMPTS");
  const hasLiveResponseNode = function(responseId) {
    const normalizedId = String(responseId || "").trim().replace(/^response-/, "");
    if (!normalizedId) return false;
    const responseEl = document.getElementById(`response-${normalizedId}`) || document.getElementById(normalizedId);
    if (!responseEl) return false;
    return !promptsRoot || promptsRoot.contains(responseEl);
  };

  [
    [".speech-controls[data-id]", "data-id"],
    [".chart-sql-buttons[data-response-id]", "data-response-id"],
    [".ask-oracle-sql-footer-actions[data-response-id]", "data-response-id"],
    [".ask-oracle-response-table-actions[data-response-id]", "data-response-id"]
  ].forEach(function(entry) {
    const selector = entry[0];
    const attributeName = entry[1];
    document.querySelectorAll(selector).forEach(function(node) {
      const responseId = String(node.getAttribute(attributeName) || "").trim();
      if (hasLiveResponseNode(responseId)) return;
      try { node.remove(); } catch (e) {}
    });
  });

  document.querySelectorAll(".export-pdf-response-btn, .export-excel-response-btn").forEach(function(node) {
    const host = node.closest(
      ".speech-controls[data-id], .chart-sql-buttons[data-response-id], .ask-oracle-sql-footer-actions[data-response-id], .ask-oracle-response-table-actions[data-response-id]"
    );
    if (host) return;

    const responseId = String(
      node.getAttribute("data-response-id") ||
      node.getAttribute("data-id") ||
      ""
    ).trim();
    if (hasLiveResponseNode(responseId)) return;
    try { node.remove(); } catch (e) {}
  });
}

function getAskOraclePromptActionButtonSelector() {
  return [
    ".explore-btn",
    ".explain-btn",
    ".export-pdf-response-btn",
    ".export-excel-response-btn",
    ".llm-conv-show-charts-btn",
    ".llm-conv-show-sql-btn",
    ".toggle-charts",
    ".toggle-sql",
    "[onclick*='redirectToExplorePage']",
    "[onclick*='redirectToExplainPage']"
  ].join(", ");
}

function clearAskOraclePromptActionButtons(scope) {
  const root = scope && typeof scope.querySelectorAll === "function"
    ? scope
    : (document.getElementById("PROMPTS") || document);

  root.querySelectorAll(getAskOraclePromptActionButtonSelector()).forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  root.querySelectorAll(".ask-oracle-sql-footer-actions").forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  root.querySelectorAll("a,button,.t-Button").forEach((node) => {
    const text = String(node.textContent || "").trim().toLowerCase();
    if (!text) return;
    if (
      text === "explore" ||
      text === "explain" ||
      text === "show charts" ||
      text === "customize charts" ||
      text === "show sql"
    ) {
      try { node.remove(); } catch (e) {}
    }
  });
}

function enforceCenterPromptBarForFreshChat() {
  if (!document.body) return;
  if (document.body.classList.contains("code-editor-mode")) return;
  if (isPromptRequestRunning()) return;
  setPromptBarMode("center");
}

function scheduleCenterPromptBarForFreshChat() {
  [0, 60, 180, 360].forEach((delay) => {
    setTimeout(() => {
      enforceCenterPromptBarForFreshChat();
    }, delay);
  });
}

function resetAskOracleConversationStateForNewChat() {
  if (document.body.classList.contains("code-editor-mode")) {
    try { closeCodeEditorPanel(); } catch (e) {}
  }

  if (isPromptRequestRunning()) {
    stopActivePromptRequest();
  }

  activeExecutePromptRequest = null;
  activeAgentThoughtsStopFn = null;
  activeAgentTempPromptId = null;
  promptRequestInFlight = false;
  promptErrorHandled = false;
  forceRunButtonStopMode = false;
  userStopRequested = false;
  pendingCodeChangeRequest = null;

  removeNewPromptScrollSpacer();
  clearAskOracleConversationDom();
  clearAskOraclePromptActionButtons();
  clearAskOracleResponseActionControls();
  [0, 80, 220, 500].forEach((delay) => {
    setTimeout(pruneAskOracleOrphanedResponseActionControls, delay);
  });

  window.pendingPrompts = {};
  finishedPrompts = new Set();
  if (window.thoughtHistory && typeof window.thoughtHistory === "object") {
    window.thoughtHistory = {};
  }
  responseDownloadPayloadCache = Object.create(null);
  responseDisplayNameById = Object.create(null);
  responseDisplayCounter = 0;
  responseTableZoomById = Object.create(null);
  agentAutoVisualByPromptId = Object.create(null);
  promptHistory = [];
  currentIndex = -1;

  ["P1_CONV_ID", "P1_PROMPT", "P1_PROMPT1", "P1_LATEST_PROMPT_ID", "P1_LATEST_LOADER_ID", "P1_DELETE_PROMPT_ID"].forEach((itemName) => {
    try {
      const item = apex.item(itemName);
      if (item) item.setValue("");
    } catch (e) {}
  });

  const welcomeRegion = document.getElementById("welcome_region");
  if (welcomeRegion) {
    welcomeRegion.style.display = "";
  }

  try { apex.message.clearErrors(); } catch (e) {}
  try {
    if (apex.message && typeof apex.message.hidePageSuccess === "function") {
      apex.message.hidePageSuccess();
    }
  } catch (e) {}

  clearConversationStyleGuidance();
  setAskOracleMicStopState(false);
  setPromptMicInteractionDisabled(false);
  enforceCenterPromptBarForFreshChat();
  scheduleCenterPromptBarForFreshChat();
  resetPromptInputHeight();
  autoGrowPromptInput();
  refreshRunPromptButtonState();
  scheduleFooterScrollDownRefresh();
  focusPromptInputForCaret(20);
}

function askOracleStartNewChat() {
  closeAskOracleHistoryActionMenu();
  askOracleActiveNavConversationId = "";
  clearAskOracleConversationNavSelection();
  document.querySelectorAll(`#t_TreeNav .${ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS}`).forEach((node) => {
    try { node.classList.remove(ASK_ORACLE_HISTORY_NEW_ENTRY_CLASS); } catch (e) {}
  });
  syncAskOracleConversationNavSelection("");
  resetAskOracleConversationStateForNewChat();
  scheduleCenterPromptBarForFreshChat();
  window.setTimeout(function() { scheduleAskOraclePromptBorderAnimation(0); }, 80);
  loadPromptHistory(function() {
    scheduleCenterPromptBarForFreshChat();
  });
}

function getAskOracleCurrentPageId() {
  try {
    if (window.apex && apex.env && apex.env.APP_PAGE_ID != null) {
      return String(apex.env.APP_PAGE_ID);
    }
  } catch (e) {}
  try {
    if (typeof window.$v === "function") {
      const pageId = window.$v("pFlowStepId");
      if (pageId != null && String(pageId).trim() !== "") return String(pageId);
    }
  } catch (e) {}
  return "";
}

function isAskOraclePageOne() {
  if (getAskOracleCurrentPageId() === "1") return true;

  const href = normalizeAskOracleNavHref(window.location && window.location.href ? window.location.href : "");
  if (!href) return false;

  if (/\/ords\/r\/[^/]+\/[^/]+\/home(?:[/?#]|$)/i.test(href)) return true;
  if (/[?&]pFlowStepId=1(?:[&#]|$)/i.test(href)) return true;
  if (/f\?p=[^:]*:1:/i.test(href)) return true;
  return false;
}

function normalizeAskOracleNavHref(rawUrl) {
  return String(rawUrl || "").replace(/&amp;/gi, "&").trim();
}

function decodeAskOracleNavValue(rawValue) {
  const text = String(rawValue || "").trim();
  if (!text) return "";
  try {
    return decodeURIComponent(text.replace(/\+/g, "%20")).trim();
  } catch (e) {
    return text;
  }
}

function extractAskOracleRedirectUrlFromJavascriptHref(rawHref) {
  const href = normalizeAskOracleNavHref(rawHref);
  if (!/^javascript:/i.test(href)) return "";
  const redirectCall = href.match(/apex\.navigation\.redirect\((['"])([\s\S]*?)\1\)/i);
  return redirectCall && redirectCall[2] ? normalizeAskOracleNavHref(redirectCall[2]) : "";
}

function isAskOracleNewChatUrl(url) {
  const href = normalizeAskOracleNavHref(url);
  if (!href) return false;

  if (/^javascript:/i.test(href)) {
    if (/\b(?:askOracleStartNewChat|startAskOracleNewChat)\s*\(/i.test(href)) return true;
    const redirectedHref = extractAskOracleRedirectUrlFromJavascriptHref(href);
    if (redirectedHref && redirectedHref !== href) {
      return isAskOracleNewChatUrl(redirectedHref);
    }
    return false;
  }

  // ORDS-style URL support:
  // /ords/r/.../home?p1_conv_id=&session=...&cs=...
  const queryConvIdMatch = href.match(/[?&]P1_CONV_ID=([^&#]*)/i);
  if (queryConvIdMatch) {
    let convIdValue = "";
    try {
      convIdValue = decodeURIComponent(String(queryConvIdMatch[1] || "").replace(/\+/g, "%20")).trim();
    } catch (e) {
      convIdValue = String(queryConvIdMatch[1] || "").trim();
    }
    if (convIdValue) return false;

    const hasPageOneHint = /(?:\/home(?:[/?#]|$)|\/1(?:[/?#]|$)|f\?p=[^:]*:1:)/i.test(href);
    const hasSessionHint = /(?:[?&](?:session|app_session|cs)=)/i.test(href);
    if (hasPageOneHint || hasSessionHint) return true;
  }

  // Legacy f?p URL support
  if (!/f\?p=/i.test(href)) return false;
  if (!/f\?p=[^:]*:1:/i.test(href)) return false;
  if (/P1_CONV_ID:[^:&]+/i.test(href)) return false;
  if (/P1_CONV_ID::/i.test(href)) return true;
  return !/P1_CONV_ID:/i.test(href);
}

function extractAskOracleConversationIdFromLegacyFspUrl(href) {
  if (!/f\?p=/i.test(href)) return "";
  const fpMatch = href.match(/f\?p=([^#]*)/i);
  if (!fpMatch || !fpMatch[1]) return "";
  const payload = String(fpMatch[1]).split("&")[0];
  if (!payload) return "";

  const parts = payload.split(":");
  if (parts.length >= 8) {
    const itemNames = decodeAskOracleNavValue(parts[6]);
    const itemValues = decodeAskOracleNavValue(parts[7]);
    if (itemNames) {
      const names = itemNames.split(",").map((name) => String(name || "").trim().toUpperCase());
      const values = itemValues.split(",");
      const convIndex = names.indexOf("P1_CONV_ID");
      if (convIndex >= 0) {
        return decodeAskOracleNavValue(values[convIndex] || "");
      }
    }
  }

  const directMatch = payload.match(/(?:^|:)P1_CONV_ID:([^:&?#]*)/i);
  return directMatch && directMatch[1] ? decodeAskOracleNavValue(directMatch[1]) : "";
}

function extractAskOracleConversationIdFromUrl(url) {
  const href = normalizeAskOracleNavHref(url);
  if (!href) return "";

  if (/^javascript:/i.test(href)) {
    const redirectedHref = extractAskOracleRedirectUrlFromJavascriptHref(href);
    if (redirectedHref && redirectedHref !== href) {
      return extractAskOracleConversationIdFromUrl(redirectedHref);
    }
    return "";
  }

  const queryMatch = href.match(/[?&]P1_CONV_ID=([^&#]*)/i);
  if (queryMatch) return decodeAskOracleNavValue(queryMatch[1]);

  return extractAskOracleConversationIdFromLegacyFspUrl(href);
}

function getAskOracleCurrentConversationId() {
  try {
    if (window.apex && apex.item) {
      const item = apex.item("P1_CONV_ID");
      if (item && typeof item.getValue === "function") {
        return String(item.getValue() || "").trim();
      }
    }
  } catch (e) {}
  try {
    if (typeof window.$v === "function") {
      return String(window.$v("P1_CONV_ID") || "").trim();
    }
  } catch (e) {}
  return "";
}

function setAskOracleConversationIdValue(conversationId) {
  const value = String(conversationId || "").trim();
  if (!value) return false;
  try {
    if (window.apex && apex.item) {
      const item = apex.item("P1_CONV_ID");
      if (item && typeof item.setValue === "function") {
        item.setValue(value);
        return true;
      }
    }
  } catch (e) {}
  try {
    if (typeof window.$s === "function") {
      window.$s("P1_CONV_ID", value);
      return true;
    }
  } catch (e) {}
  return false;
}

function getAskOracleConversationIdFromNavNode(node) {
  if (!node) return "";
  const candidates = [];
  const pushNode = function(candidate) {
    if (!candidate) return;
    if (!candidates.includes(candidate)) candidates.push(candidate);
  };

  pushNode(node);
  try { if (typeof node.closest === "function") pushNode(node.closest("[data-conv-id]")); } catch (e) {}
  try { if (typeof node.closest === "function") pushNode(node.closest("a, button")); } catch (e) {}
  try { if (typeof node.closest === "function") pushNode(node.closest("li")); } catch (e) {}

  for (const candidate of candidates) {
    if (!candidate || typeof candidate.getAttribute !== "function") continue;
    const directAttrValue = decodeAskOracleNavValue(candidate.getAttribute("data-conv-id"));
    if (directAttrValue) return directAttrValue;
    const altAttrValue = decodeAskOracleNavValue(candidate.getAttribute("data-conversation-id"));
    if (altAttrValue) return altAttrValue;
    const dataConvId = decodeAskOracleNavValue(candidate.dataset ? candidate.dataset.convId : "");
    if (dataConvId) return dataConvId;
    const dataConversationId = decodeAskOracleNavValue(candidate.dataset ? candidate.dataset.conversationId : "");
    if (dataConversationId) return dataConversationId;
  }

  for (const candidate of candidates) {
    const href = getAskOracleNavNodeHref(candidate);
    const hrefConversationId = extractAskOracleConversationIdFromUrl(href);
    if (hrefConversationId) return hrefConversationId;
    const onclickText = normalizeAskOracleNavHref(
      (candidate && typeof candidate.getAttribute === "function") ? candidate.getAttribute("onclick") : ""
    );
    const onclickConversationId = extractAskOracleConversationIdFromUrl(onclickText);
    if (onclickConversationId) return onclickConversationId;
  }

  return "";
}

function ensureAskOracleConversationNavSelectionCss() {
  if (document.getElementById(ASK_ORACLE_CONV_NAV_ACTIVE_CSS_ID)) return;
  const style = document.createElement("style");
  style.id = ASK_ORACLE_CONV_NAV_ACTIVE_CSS_ID;
  style.textContent = `
    .${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS}.a-TreeView-content,
    li.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .a-TreeView-content,
    li.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .a-TreeView-content .a-TreeView-label,
    a.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS},
    button.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} {
      background: #e0ecff !important;
      color: #0f2f66 !important;
      border-radius: 8px !important;
    }
    li.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .a-TreeView-content .a-TreeView-label {
      font-weight: 400 !important;
    }
    body.ask-oracle-dark-ui .${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS}.a-TreeView-content,
    body.ask-oracle-dark-ui li.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .a-TreeView-content,
    body.ask-oracle-dark-ui li.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} > .a-TreeView-content .a-TreeView-label,
    body.ask-oracle-dark-ui a.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS},
    body.ask-oracle-dark-ui button.${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS} {
      background: rgba(59, 130, 246, 0.28) !important;
      color: #dbeafe !important;
    }
  `;
  document.head.appendChild(style);
}

function getAskOracleConversationNavSelectionTargets(node) {
  if (!node) return [];
  const targets = [];
  const push = function(candidate) {
    if (!candidate || !candidate.classList) return;
    if (!targets.includes(candidate)) targets.push(candidate);
  };

  push(node);
  try { if (typeof node.closest === "function") push(node.closest(".a-TreeView-content")); } catch (e) {}
  try { if (typeof node.closest === "function") push(node.closest("li")); } catch (e) {}
  try { if (typeof node.closest === "function") push(node.closest("a, button")); } catch (e) {}
  return targets;
}

function clearAskOracleConversationNavSelection() {
  document.querySelectorAll("#t_TreeNav .a-TreeView-label[aria-selected='true']").forEach((node) => {
    try { node.setAttribute("aria-selected", "false"); } catch (e) {}
  });
  document.querySelectorAll(`[data-ask-oracle-conv-selected='true'], .${ASK_ORACLE_CONV_NAV_ACTIVE_CLASS}`).forEach((node) => {
    try {
      node.classList.remove(ASK_ORACLE_CONV_NAV_ACTIVE_CLASS);
      node.setAttribute("data-ask-oracle-conv-selected", "false");
      if (node.matches && node.matches("a, button")) {
        node.removeAttribute("aria-current");
      }
      if (node.matches && node.matches(".a-TreeView-label")) {
        node.setAttribute("aria-selected", "false");
      }
    } catch (e) {}
  });
}

function applyAskOracleConversationNavSelection(node) {
  if (!node) return;
  ensureAskOracleConversationNavSelectionCss();
  getAskOracleConversationNavSelectionTargets(node).forEach((target) => {
    try {
      target.classList.add(ASK_ORACLE_CONV_NAV_ACTIVE_CLASS);
      target.setAttribute("data-ask-oracle-conv-selected", "true");
      if (target.matches && target.matches("a, button")) {
        target.setAttribute("aria-current", "page");
      }
      if (target.matches && target.matches(".a-TreeView-label")) {
        target.setAttribute("aria-selected", "true");
      }
    } catch (e) {}
  });
}

function syncAskOracleConversationNavSelection(conversationId, sourceNode) {
  const targetConversationId = String(
    conversationId != null ? conversationId : askOracleActiveNavConversationId || getAskOracleCurrentConversationId()
  ).trim();
  askOracleActiveNavConversationId = targetConversationId;
  clearAskOracleConversationNavSelection();
  if (!targetConversationId) return false;

  let matched = false;
  if (sourceNode) {
    const sourceConversationId = getAskOracleConversationIdFromNavNode(sourceNode);
    if (sourceConversationId && sourceConversationId === targetConversationId) {
      applyAskOracleConversationNavSelection(sourceNode);
      matched = true;
    }
  }
  if (matched) return true;

  const selectors = [
    "[data-conv-id]",
    "[data-conversation-id]",
    "a[href]",
    "button",
    "#t_TreeNav li",
    "#t_TreeNav .a-TreeView-content",
    "#t_TreeNav .a-TreeView-label"
  ];
  document.querySelectorAll(selectors.join(",")).forEach((node) => {
    if (matched) return;
    const nodeConversationId = getAskOracleConversationIdFromNavNode(node);
    if (!nodeConversationId || nodeConversationId !== targetConversationId) return;
    applyAskOracleConversationNavSelection(node);
    matched = true;
  });

  return matched;
}

function isAskOracleConversationUrl(url) {
  const href = normalizeAskOracleNavHref(url);
  if (!href) return false;
  if (isAskOracleNewChatUrl(href)) return false;
  const conversationId = extractAskOracleConversationIdFromUrl(href);
  if (!conversationId) return false;
  if (/f\?p=/i.test(href) && !/f\?p=[^:]*:1:/i.test(href)) return false;
  return true;
}

function getAskOracleNavNodeHref(node) {
  if (!node) return "";
  let href = "";
  try {
    if (typeof node.getAttribute === "function") {
      href = String(node.getAttribute("href") || "").trim();
    }
  } catch (e) {}
  if (href) return normalizeAskOracleNavHref(href);
  try {
    if (typeof node.closest === "function") {
      const parentAnchor = node.closest("a[href]");
      if (parentAnchor) href = String(parentAnchor.getAttribute("href") || "").trim();
    }
  } catch (e) {}
  if (href) return normalizeAskOracleNavHref(href);
  try {
    if (typeof node.querySelector === "function") {
      const childAnchor = node.querySelector("a[href]");
      if (childAnchor) href = String(childAnchor.getAttribute("href") || "").trim();
    }
  } catch (e) {}
  return normalizeAskOracleNavHref(href);
}

function getAskOracleNavNodeLabel(node) {
  if (!node) return "";
  const parts = [];
  try { parts.push(String(node.textContent || "")); } catch (e) {}
  try { parts.push(String(node.getAttribute && node.getAttribute("title") || "")); } catch (e) {}
  try { parts.push(String(node.getAttribute && node.getAttribute("aria-label") || "")); } catch (e) {}
  try {
    if (typeof node.closest === "function") {
      const parentAnchor = node.closest("a");
      if (parentAnchor) {
        parts.push(String(parentAnchor.textContent || ""));
        parts.push(String(parentAnchor.getAttribute("title") || ""));
      }
    }
  } catch (e) {}
  return parts.join(" ").toLowerCase();
}

function isAskOracleNewChatNavLink(linkEl) {
  if (!linkEl) return false;

  const explicitFlag = String(
    linkEl.getAttribute("data-ask-oracle-new-chat") ||
    (linkEl.dataset ? linkEl.dataset.askOracleNewChat : "") ||
    ""
  ).trim().toLowerCase();
  if (["y", "yes", "true", "1"].includes(explicitFlag)) {
    return true;
  }

  const href = getAskOracleNavNodeHref(linkEl);
  const onclickText = normalizeAskOracleNavHref(
    linkEl.getAttribute("onclick") ||
    (typeof linkEl.closest === "function" && linkEl.closest("a, button")
      ? linkEl.closest("a, button").getAttribute("onclick")
      : "")
  );
  const labelText = getAskOracleNavNodeLabel(linkEl);
  const looksLikeNewChat = /\bnew\s*chat\b/i.test(labelText);
  const hasNewChatJsHandler =
    /\b(?:askOracleStartNewChat|startAskOracleNewChat)\s*\(/i.test(href) ||
    /\b(?:askOracleStartNewChat|startAskOracleNewChat)\s*\(/i.test(onclickText);
  if (hasNewChatJsHandler) return true;

  const looksLikePageOneConvTarget = isAskOracleNewChatUrl(href) || isAskOracleNewChatUrl(onclickText);
  return looksLikeNewChat && looksLikePageOneConvTarget;
}

function isAskOracleConversationNavLink(linkEl) {
  if (!linkEl) return false;
  if (
    (linkEl.classList && (
      linkEl.classList.contains(ASK_ORACLE_HISTORY_EDIT_BTN_CLASS) ||
      linkEl.classList.contains(ASK_ORACLE_HISTORY_PIN_BTN_CLASS) ||
      linkEl.classList.contains(ASK_ORACLE_HISTORY_DELETE_BTN_CLASS) ||
      linkEl.classList.contains(ASK_ORACLE_HISTORY_MORE_BTN_CLASS) ||
      linkEl.classList.contains(ASK_ORACLE_HISTORY_ACTION_MENU_CLASS) ||
      linkEl.classList.contains("ask-oracle-history-inline-title-save") ||
      linkEl.classList.contains("ask-oracle-history-inline-title-input")
    )) ||
    (typeof linkEl.closest === "function" &&
      linkEl.closest(`.${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS}, .ask-oracle-history-inline-title-save, .ask-oracle-history-inline-title-input`))
  ) return false;
  if (isAskOracleNewChatNavLink(linkEl)) return false;
  const conversationId = getAskOracleConversationIdFromNavNode(linkEl);
  return !!conversationId;
}

function refreshAskOraclePromptsRegionInPlace(callback) {
  const done = typeof callback === "function" ? callback : function() {};
  const docJq = (window.apex && apex.jQuery) ? apex.jQuery(document) : null;
  const regionEl = document.getElementById("PROMPTS");
  const region = (window.apex && apex.region) ? apex.region("PROMPTS") : null;
  const eventNs = `.askOraclePromptsRefresh${Date.now()}${Math.floor(Math.random() * 100000)}`;
  let completed = false;
  let fallbackTimer = null;

  function finish() {
    if (completed) return;
    completed = true;
    if (fallbackTimer) clearTimeout(fallbackTimer);
    if (docJq) docJq.off(eventNs);
    done();
  }

  if (docJq && regionEl) {
    docJq.on(`apexafterrefresh${eventNs}`, function(event) {
      const target = event && event.target;
      if (!target) return;
      if (target === regionEl || (typeof regionEl.contains === "function" && regionEl.contains(target))) {
        finish();
      }
    });
  }

  fallbackTimer = setTimeout(finish, 1800);

  try {
    if (region && typeof region.refresh === "function") {
      region.refresh();
      return;
    }
  } catch (e) {}

  setTimeout(finish, 80);
}

function getAskOraclePromptListContainer() {
  return document.querySelector("#PROMPTS .prompt-list") || document.getElementById("PROMPTS");
}

function touchAskOracleConversationDomCacheKey(cacheKey) {
  if (!ASK_ORACLE_CONVERSATION_DOM_CACHE_ENABLED) return;
  const key = String(cacheKey || "").trim();
  if (!key) return;
  askOracleConversationDomCacheOrder = askOracleConversationDomCacheOrder.filter((item) => item !== key);
  askOracleConversationDomCacheOrder.unshift(key);
  while (askOracleConversationDomCacheOrder.length > ASK_ORACLE_CONVERSATION_DOM_CACHE_MAX) {
    const evicted = askOracleConversationDomCacheOrder.pop();
    if (evicted) delete askOracleConversationDomCacheById[evicted];
  }
}

function storeAskOracleConversationDomCache(conversationId) {
  if (!ASK_ORACLE_CONVERSATION_DOM_CACHE_ENABLED) return false;
  const cacheKey = String(conversationId || getAskOracleCurrentConversationId() || "").trim();
  if (!cacheKey) return false;
  const container = getAskOraclePromptListContainer();
  if (!container) return false;
  const html = String(container.innerHTML || "");
  if (!html.trim()) return false;
  if (!askOracleConversationCacheHtmlLooksHydrated(html)) return false;

  askOracleConversationDomCacheById[cacheKey] = {
    html: html,
    cachedAt: Date.now()
  };
  touchAskOracleConversationDomCacheKey(cacheKey);
  return true;
}

function restoreAskOracleConversationDomCache(conversationId) {
  if (!ASK_ORACLE_CONVERSATION_DOM_CACHE_ENABLED) return false;
  const cacheKey = String(conversationId || "").trim();
  if (!cacheKey) return false;
  const cached = askOracleConversationDomCacheById[cacheKey];
  if (!cached || typeof cached.html !== "string") return false;
  if (!askOracleConversationCacheHtmlLooksHydrated(cached.html)) {
    delete askOracleConversationDomCacheById[cacheKey];
    askOracleConversationDomCacheOrder = askOracleConversationDomCacheOrder.filter((item) => item !== cacheKey);
    return false;
  }
  const container = getAskOraclePromptListContainer();
  if (!container) return false;
  container.innerHTML = cached.html;
  touchAskOracleConversationDomCacheKey(cacheKey);
  return true;
}

function scheduleAskOracleConversationDomCacheSnapshot(conversationId) {
  if (!ASK_ORACLE_CONVERSATION_DOM_CACHE_ENABLED) return;
  const cacheKey = String(conversationId || getAskOracleCurrentConversationId() || "").trim();
  if (!cacheKey) return;
  [0, 150, 540, 1200, 2200, 3600].forEach((delay) => {
    setTimeout(() => {
      storeAskOracleConversationDomCache(cacheKey);
    }, delay);
  });
}

function prepareAskOracleUiForConversationSwitch() {
  if (document.body.classList.contains("code-editor-mode")) {
    try { closeCodeEditorPanel(); } catch (e) {}
  }
  if (isPromptRequestRunning()) {
    stopActivePromptRequest();
  }

  activeExecutePromptRequest = null;
  activeAgentThoughtsStopFn = null;
  activeAgentTempPromptId = null;
  promptRequestInFlight = false;
  promptErrorHandled = false;
  forceRunButtonStopMode = false;
  userStopRequested = false;
  pendingCodeChangeRequest = null;

  removeNewPromptScrollSpacer();
  clearAskOracleConversationDom();
  clearAskOraclePromptActionButtons();
  clearAskOracleResponseActionControls();
  [0, 80, 220, 500].forEach((delay) => {
    setTimeout(pruneAskOracleOrphanedResponseActionControls, delay);
  });

  window.pendingPrompts = {};
  finishedPrompts = new Set();
  if (window.thoughtHistory && typeof window.thoughtHistory === "object") {
    window.thoughtHistory = {};
  }
  responseDownloadPayloadCache = Object.create(null);
  responseDisplayNameById = Object.create(null);
  responseDisplayCounter = 0;
  responseTableZoomById = Object.create(null);
  agentAutoVisualByPromptId = Object.create(null);
  promptHistory = [];
  currentIndex = -1;

  ["P1_PROMPT", "P1_PROMPT1", "P1_LATEST_PROMPT_ID", "P1_LATEST_LOADER_ID", "P1_DELETE_PROMPT_ID"].forEach((itemName) => {
    try {
      const item = apex.item(itemName);
      if (item) item.setValue("");
    } catch (e) {}
  });

  const welcomeRegion = document.getElementById("welcome_region");
  if (welcomeRegion) {
    welcomeRegion.style.display = "none";
  }

  try { apex.message.clearErrors(); } catch (e) {}
  try {
    if (apex.message && typeof apex.message.hidePageSuccess === "function") {
      apex.message.hidePageSuccess();
    }
  } catch (e) {}

  clearConversationStyleGuidance();
  setAskOracleMicStopState(false);
  setPromptMicInteractionDisabled(false);
  setPromptBarMode("footer");
  resetPromptInputHeight();
  autoGrowPromptInput();
  refreshRunPromptButtonState();
  scheduleFooterScrollDownRefresh();
}

function canHandleAskOracleConversationSwitchInPlace() {
  if (!canHandleAskOracleNewChatInPlace()) return false;
  if (!document.getElementById("PROMPTS")) return false;
  try {
    if (window.apex && apex.item && apex.item("P1_CONV_ID")) return true;
  } catch (e) {}
  return typeof window.$s === "function";
}

function getAskOracleConversationResponseIdsFromDom() {
  const ids = [];
  const seen = new Set();
  document.querySelectorAll(".response[data-id], .response-box[data-id], .response-box[id^='response-']").forEach((node) => {
    const fromData = String(node.getAttribute("data-id") || "").trim();
    const fromId = String(node.id || "").replace(/^response-/, "").trim();
    const key = fromData || fromId;
    if (!key || seen.has(key)) return;
    seen.add(key);
    ids.push(key);
  });
  return ids;
}

function askOracleConversationCacheHtmlLooksHydrated(html) {
  const markup = String(html || "");
  if (!markup.trim()) return false;

  const temp = document.createElement("div");
  temp.innerHTML = markup;
  const responseNodes = Array.from(
    temp.querySelectorAll(".response[data-id], .response-box[data-id], .response-box[id^='response-']")
  );
  if (!responseNodes.length) return true;

  return responseNodes.every((node) => {
    if (!node) return false;
    if (node.querySelector(".loading-spinner")) return false;
    if (String(node.textContent || "").trim()) return true;

    let sibling = node.nextElementSibling;
    let hop = 0;
    while (sibling && hop < 8) {
      if (sibling.classList) {
        if (sibling.classList.contains("chart-container")) return true;
        if (sibling.classList.contains("response-footer")) return true;
        if (sibling.classList.contains("speech-controls")) return true;
        if (sibling.classList.contains("ask-oracle-sql-footer-actions")) return true;
      }
      sibling = sibling.nextElementSibling;
      hop += 1;
    }

    return false;
  });
}

function hydrateAskOracleConversationResponsesAfterSwitch() {
  let started = false;
  try {
    if (window.LLMPlugin && typeof window.LLMPlugin.init === "function") {
      window.LLMPlugin.init();
      started = true;
    }
  } catch (e) {
    console.error("LLMPlugin.init failed after conversation switch:", e);
  }

  if (started) return true;
  if (typeof initSingleLLMResponse !== "function") return false;

  const responseIds = getAskOracleConversationResponseIdsFromDom();
  if (!responseIds.length) return false;
  responseIds.forEach((id) => {
    try { initSingleLLMResponse(id); } catch (e) {}
  });
  return true;
}

function scheduleAskOracleConversationResponseHydration() {
  let done = false;
  [0, 80, 220, 460].forEach((delay) => {
    setTimeout(() => {
      if (done) return;
      done = hydrateAskOracleConversationResponsesAfterSwitch();
    }, delay);
  });
}

function scheduleAskOracleFooterPromptRealign() {
  const realign = function() {
    setPromptBarMode("footer");
    positionFooterPromptBar();
    applyFooterAppearance();
    scheduleFooterScrollDownRefresh();
  };
  realign();
  [0, 40, 120, 260, 420].forEach((delay) => {
    setTimeout(realign, delay);
  });
}

function finalizeAskOracleConversationSwitchInPlace() {
  const activeConversationId = getAskOracleCurrentConversationId();
  syncAskOracleConversationNavSelection(activeConversationId);
  loadPromptHistory();
  scheduleAskOracleConversationResponseHydration();
  scheduleAskOracleFooterPromptRealign();
  autoGrowPromptInput();
  refreshRunPromptButtonState();
  ensureResponseDownloadButtons();
  scheduleFooterScrollDownRefresh();
  scheduleAskOracleConversationDomCacheSnapshot(activeConversationId);
  focusPromptInputForCaret(80);
}

function switchAskOracleConversationInPlace(conversationId, options) {
  const conversationKey = String(conversationId || "").trim();
  if (!conversationKey) return false;
  if (!canHandleAskOracleConversationSwitchInPlace()) return false;
  closeAskOracleHistoryActionMenu();
  suppressAskOracleDefaultPageLoadingIndicators(2100);
  askOracleActiveNavConversationId = conversationKey;
  syncAskOracleConversationNavSelection(conversationKey);

  const opts = options || {};
  const currentConversationId = getAskOracleCurrentConversationId();
  if (currentConversationId && currentConversationId !== conversationKey) {
    storeAskOracleConversationDomCache(currentConversationId);
  }
  if (!opts.forceRefresh && currentConversationId && currentConversationId === conversationKey) {
    finalizeAskOracleConversationSwitchInPlace();
    return true;
  }

  if (askOracleConversationSwitchInProgress) {
    askOracleQueuedConversationId = conversationKey;
    return true;
  }

  if (!setAskOracleConversationIdValue(conversationKey)) {
    return false;
  }

  askOracleConversationSwitchInProgress = true;
  askOracleQueuedConversationId = "";
  prepareAskOracleUiForConversationSwitch();

  const restoredFromCache = !opts.forceRefresh && restoreAskOracleConversationDomCache(conversationKey);
  if (restoredFromCache) {
    try {
      finalizeAskOracleConversationSwitchInPlace();
    } finally {
      askOracleConversationSwitchInProgress = false;
      const queuedFromCache = String(askOracleQueuedConversationId || "").trim();
      askOracleQueuedConversationId = "";
      if (queuedFromCache && queuedFromCache !== getAskOracleCurrentConversationId()) {
        switchAskOracleConversationInPlace(queuedFromCache, { forceRefresh: true });
      }
    }
    return true;
  }

  refreshAskOraclePromptsRegionInPlace(function() {
    try {
      storeAskOracleConversationDomCache(conversationKey);
      finalizeAskOracleConversationSwitchInPlace();
    } finally {
      askOracleConversationSwitchInProgress = false;
      const queuedId = String(askOracleQueuedConversationId || "").trim();
      askOracleQueuedConversationId = "";
      if (queuedId && queuedId !== getAskOracleCurrentConversationId()) {
        switchAskOracleConversationInPlace(queuedId, { forceRefresh: true });
      }
    }
  });

  return true;
}

function triggerAskOracleConversationSwitchFromEvent(event, sourceNode) {
  if (!canHandleAskOracleConversationSwitchInPlace()) return false;
  const node = sourceNode || (event ? event.target : null);
  const conversationId = getAskOracleConversationIdFromNavNode(node);
  if (!conversationId) return false;
  suppressAskOracleDefaultPageLoadingIndicators(2100);
  askOracleActiveNavConversationId = conversationId;
  syncAskOracleConversationNavSelection(conversationId, node);

  if (event) {
    if (typeof event.preventDefault === "function") event.preventDefault();
    if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
    if (typeof event.stopPropagation === "function") event.stopPropagation();
  }

  return switchAskOracleConversationInPlace(conversationId, { forceRefresh: true });
}

function patchAskOracleNavigationRedirectForNewChat() {
  if (window.__askOracleNewChatRedirectPatched) return;
  if (!(window.apex && apex.navigation && typeof apex.navigation.redirect === "function")) return;

  const originalRedirect = apex.navigation.redirect.bind(apex.navigation);
  window.__askOracleNewChatRedirectPatched = true;

  apex.navigation.redirect = function(url) {
    if (isAskOraclePageOne()) {
      if (isAskOracleNewChatUrl(url)) {
        askOracleStartNewChat();
        return;
      }
      if (isAskOracleConversationUrl(url)) {
        const conversationId = extractAskOracleConversationIdFromUrl(url);
        if (conversationId) {
          switchAskOracleConversationInPlace(conversationId, { forceRefresh: true });
          return;
        }
      }
    }
    return originalRedirect(url);
  };
}

function canHandleAskOracleNewChatInPlace() {
  if (isAskOraclePageOne()) return true;
  return !!document.getElementById("P1_PROMPT1");
}

function triggerAskOracleNewChatFromEvent(event) {
  if (!canHandleAskOracleNewChatInPlace()) return false;
  if (event) {
    if (typeof event.preventDefault === "function") event.preventDefault();
    if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
    if (typeof event.stopPropagation === "function") event.stopPropagation();
  }
  askOracleStartNewChat();
  return true;
}

function wireAskOracleNewChatElement(node) {
  if (!node || node.nodeType !== 1) return;
  if (node.dataset && node.dataset.askOracleNewChatBound === "true") return;
  if (node.dataset) node.dataset.askOracleNewChatBound = "true";

  if (String(node.tagName || "").toUpperCase() === "A") {
    const currentHref = normalizeAskOracleNavHref(node.getAttribute("href") || "");
    const originalHref = normalizeAskOracleNavHref(node.getAttribute("data-ask-oracle-original-href") || "");
    if (/^javascript:void\(0\)/i.test(currentHref) && originalHref) {
      node.setAttribute("href", originalHref);
    }
  }

  node.addEventListener("click", function(event) {
    triggerAskOracleNewChatFromEvent(event);
  }, true);
  node.addEventListener("keydown", function(event) {
    if (!(event && (event.key === "Enter" || event.key === " "))) return;
    triggerAskOracleNewChatFromEvent(event);
  }, true);
}

function wireAskOracleConversationElement(node) {
  if (!node || node.nodeType !== 1) return;
  if (node.dataset && node.dataset.askOracleConversationBound === "true") return;
  if (node.dataset) node.dataset.askOracleConversationBound = "true";

  const preSuppressLoader = function() {
    suppressAskOracleDefaultPageLoadingIndicators(2100);
  };
  node.addEventListener("pointerdown", preSuppressLoader, true);
  node.addEventListener("mousedown", preSuppressLoader, true);
  node.addEventListener("click", function(event) {
    const activeInlineEdit = document.querySelector("#t_TreeNav .a-TreeView-content.ask-oracle-title-editing");
    if (activeInlineEdit) return;
    const target = event && event.target;
    if (
      target &&
      typeof target.closest === "function" &&
      target.closest(`.${ASK_ORACLE_HISTORY_EDIT_BTN_CLASS}, .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}, .${ASK_ORACLE_HISTORY_DELETE_BTN_CLASS}, .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS}, .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS}, .ask-oracle-history-inline-title-input, .ask-oracle-history-inline-title-save`)
    ) {
      return;
    }
    triggerAskOracleConversationSwitchFromEvent(event, node);
  }, true);
  node.addEventListener("keydown", function(event) {
    if (!(event && (event.key === "Enter" || event.key === " "))) return;
    const activeInlineEdit = document.querySelector("#t_TreeNav .a-TreeView-content.ask-oracle-title-editing");
    if (activeInlineEdit) return;
    const target = event && event.target;
    if (
      target &&
      typeof target.closest === "function" &&
      target.closest(`.${ASK_ORACLE_HISTORY_EDIT_BTN_CLASS}, .${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}, .${ASK_ORACLE_HISTORY_DELETE_BTN_CLASS}, .${ASK_ORACLE_HISTORY_MORE_BTN_CLASS}, .${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS}, .ask-oracle-history-inline-title-input, .ask-oracle-history-inline-title-save`)
    ) {
      return;
    }
    triggerAskOracleConversationSwitchFromEvent(event, node);
  }, true);
}

function bindAskOracleNewChatDirectHandlers() {
  const selectors = [
    "a[href]",
    "button",
    "#t_TreeNav .a-TreeView-label",
    "#t_TreeNav .a-TreeView-content"
  ];
  document.querySelectorAll(selectors.join(",")).forEach((node) => {
    if (!isAskOracleNewChatNavLink(node)) return;
    wireAskOracleNewChatElement(node);
  });
}

function bindAskOracleConversationDirectHandlers() {
  sanitizeAskOracleHistoryNavLabels();
  if (!isPromptRequestRunning()) {
    ensureAskOracleAgentsNavSection();
    stabilizeAskOracleStaticLeftNavBits();
  }
  const selectors = [
    "[data-conv-id]",
    "a[href]",
    "button",
    "#t_TreeNav .a-TreeView-label",
    "#t_TreeNav .a-TreeView-content"
  ];
  document.querySelectorAll(selectors.join(",")).forEach((node) => {
    if (!isAskOracleConversationNavLink(node)) return;
    wireAskOracleConversationElement(node);
  });
  bindAskOracleConversationDeleteActions();
  syncAskOracleConversationNavSelection();
}

function flushPendingAskOracleSidebarRebind() {
  if (isPromptRequestRunning()) return;
  if (!window.__askOracleNavRebindPending) return;
  window.__askOracleNavRebindPending = false;
  bindAskOracleNewChatDirectHandlers();
  bindAskOracleConversationDirectHandlers();
  replayAskOracleHistoryNavEntries();
  ensureAskOracleHistoryNavExpanded();
  sanitizeAskOracleHistoryNavLabels();
  ensureAskOracleAgentsNavSection();
  stabilizeAskOracleStaticLeftNavBits();
  bindAskOracleConversationDeleteActions();
  syncAskOracleConversationNavSelection();
  tryProcessPendingAskOracleHistoryNavRefreshes();
}

function startAskOracleNewChatDomObserver() {
  if (window.__askOracleNewChatObserverBound) return;
  window.__askOracleNewChatObserverBound = true;
  const navHost =
    document.getElementById("t_Body_nav") ||
    document.querySelector(".t-Body-nav") ||
    document.getElementById("t_TreeNav");
  if (!(window.MutationObserver && navHost)) return;

  let rebindTimer = null;
  let inFlightAgentsNavRepairTimer = null;
  const scheduleInFlightAgentsNavRepair = function() {
    if (inFlightAgentsNavRepairTimer) {
      clearTimeout(inFlightAgentsNavRepairTimer);
      inFlightAgentsNavRepairTimer = null;
    }
    [0, 80, 180, 320].forEach(function(delayMs) {
      inFlightAgentsNavRepairTimer = setTimeout(function() {
        ensureAskOracleAgentsNavSection();
        sanitizeAskOracleHistoryNavLabels();
        stabilizeAskOracleStaticLeftNavBits();
      }, delayMs);
    });
  };
  const scheduleRebind = function() {
    if (rebindTimer) {
      clearTimeout(rebindTimer);
    }
    rebindTimer = setTimeout(function() {
      rebindTimer = null;
      if (isPromptRequestRunning()) {
        ensureAskOracleAgentsNavSection();
        sanitizeAskOracleHistoryNavLabels();
        stabilizeAskOracleStaticLeftNavBits();
        scheduleInFlightAgentsNavRepair();
        window.__askOracleNavRebindPending = true;
        return;
      }
      bindAskOracleNewChatDirectHandlers();
      bindAskOracleConversationDirectHandlers();
      replayAskOracleHistoryNavEntries();
      ensureAskOracleHistoryNavExpanded();
      sanitizeAskOracleHistoryNavLabels();
      ensureAskOracleAgentsNavSection();
      stabilizeAskOracleStaticLeftNavBits();
      bindAskOracleConversationDeleteActions();
      syncAskOracleConversationNavSelection();
      tryProcessPendingAskOracleHistoryNavRefreshes();
    }, 80);
  };

  const observer = new MutationObserver(scheduleRebind);
  observer.observe(navHost, { childList: true, subtree: true });
  window.__askOracleNewChatObserver = observer;
}

function bindAskOracleNewChatNavInterception() {
  if (window.__askOracleNewChatNavBound) return;
  window.__askOracleNewChatNavBound = true;

  function maybeHandle(event) {
    const target = event && event.target;
    if (!target || typeof target.closest !== "function") return;
    if (document.querySelector("#t_TreeNav .a-TreeView-content.ask-oracle-title-editing")) {
      if (!target.closest(".ask-oracle-history-inline-title-input, .ask-oracle-history-inline-title-save")) {
        return;
      }
    }
    if (target.closest(`.${ASK_ORACLE_HISTORY_ACTION_MENU_CLASS}`)) return;
    if (target.closest(".ask-oracle-history-inline-title-input")) return;
    if (target.closest(".ask-oracle-history-inline-title-save")) return;

    const candidateNodes = [
      target.closest(`.${ASK_ORACLE_HISTORY_EDIT_BTN_CLASS}`),
      target.closest(`.${ASK_ORACLE_HISTORY_PIN_BTN_CLASS}`),
      target.closest(`.${ASK_ORACLE_HISTORY_DELETE_BTN_CLASS}`),
      target.closest(`.${ASK_ORACLE_HISTORY_MORE_BTN_CLASS}`),
      target.closest("[data-conv-id]"),
      target.closest("a, button"),
      target.closest("#t_TreeNav .a-TreeView-label"),
      target.closest("#t_TreeNav .a-TreeView-content"),
      target.closest("#t_TreeNav li")
    ].filter(Boolean);

    const editNode = candidateNodes.find((node) => {
      return !!(node && node.classList && node.classList.contains(ASK_ORACLE_HISTORY_EDIT_BTN_CLASS));
    });
    if (editNode) {
      const conversationId = getAskOracleConversationIdFromNavNode(editNode);
      if (conversationId) {
        if (event && typeof event.preventDefault === "function") event.preventDefault();
        if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        if (event && typeof event.stopPropagation === "function") event.stopPropagation();
        editAskOracleConversationTitle(conversationId, editNode.closest(".a-TreeView-content") || editNode);
      }
      return;
    }

    const pinNode = candidateNodes.find((node) => {
      return !!(node && node.classList && node.classList.contains(ASK_ORACLE_HISTORY_PIN_BTN_CLASS));
    });
    if (pinNode) {
      const conversationId = getAskOracleConversationIdFromNavNode(pinNode);
      if (conversationId) {
        if (event && typeof event.preventDefault === "function") event.preventDefault();
        if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        if (event && typeof event.stopPropagation === "function") event.stopPropagation();
        const pinContentNode = pinNode.closest(".a-TreeView-content") || pinNode;
        if (pinNode.classList && pinNode.classList.contains("is-pinned")) {
          unpinAskOracleConversation(conversationId, pinContentNode);
        } else {
          pinAskOracleConversation(conversationId, pinContentNode);
        }
      }
      return;
    }

    const moreNode = candidateNodes.find((node) => {
      return !!(node && node.classList && node.classList.contains(ASK_ORACLE_HISTORY_MORE_BTN_CLASS));
    });
    if (moreNode) {
      const conversationId = getAskOracleConversationIdFromNavNode(moreNode);
      if (conversationId) {
        if (event && typeof event.preventDefault === "function") event.preventDefault();
        if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        if (event && typeof event.stopPropagation === "function") event.stopPropagation();
        openAskOracleHistoryActionMenu(conversationId, moreNode);
      }
      return;
    }

    const deleteNode = candidateNodes.find((node) => {
      return !!(node && node.classList && node.classList.contains(ASK_ORACLE_HISTORY_DELETE_BTN_CLASS));
    });
    if (deleteNode) {
      const conversationId = getAskOracleConversationIdFromNavNode(deleteNode);
      if (conversationId) {
        if (event && typeof event.preventDefault === "function") event.preventDefault();
        if (event && typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        if (event && typeof event.stopPropagation === "function") event.stopPropagation();
        deleteAskOracleConversation(conversationId, deleteNode);
      }
      return;
    }

    const newChatNode = candidateNodes.find((node) => isAskOracleNewChatNavLink(node));
    if (newChatNode) {
      triggerAskOracleNewChatFromEvent(event);
      return;
    }

    const conversationNode = candidateNodes.find((node) => isAskOracleConversationNavLink(node));
    if (!conversationNode) return;
    triggerAskOracleConversationSwitchFromEvent(event, conversationNode);
  }

  document.addEventListener("click", maybeHandle, true);
  document.addEventListener("keydown", function(event) {
    if (!(event && (event.key === "Enter" || event.key === " "))) return;
    maybeHandle(event);
  }, true);
  bindAskOracleNewChatDirectHandlers();
  bindAskOracleConversationDirectHandlers();
  ensureAskOracleAgentsNavSection();
  stabilizeAskOracleStaticLeftNavBits();
  syncAskOracleConversationNavSelection();
  startAskOracleNewChatDomObserver();
}

window.refreshRunPromptButtonState = refreshRunPromptButtonState;
window.setRunPromptStopMode = setRunPromptStopMode;
window.isPromptRequestRunning = isPromptRequestRunning;
window.stopActivePromptRequest = stopActivePromptRequest;
window.askOracleStartNewChat = askOracleStartNewChat;
window.startAskOracleNewChat = askOracleStartNewChat;
window.switchAskOracleConversationInPlace = switchAskOracleConversationInPlace;
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", function() {
    ensureAskOracleAgentsNavCss();
    bindAskOracleMicStopModeGuards();
    patchAskOracleNavigationRedirectForNewChat();
    bindAskOracleNewChatNavInterception();
    bindAskOracleNewChatDirectHandlers();
    bindAskOracleConversationDirectHandlers();
    ensureAskOracleAgentsNavSection();
    stabilizeAskOracleStaticLeftNavBits();
    startAskOracleNewChatDomObserver();
    syncAskOracleConversationNavSelection();
    refreshRunPromptButtonState();
  }, { once: true });
} else {
  ensureAskOracleAgentsNavCss();
  bindAskOracleMicStopModeGuards();
  patchAskOracleNavigationRedirectForNewChat();
  bindAskOracleNewChatNavInterception();
  bindAskOracleNewChatDirectHandlers();
  bindAskOracleConversationDirectHandlers();
  ensureAskOracleAgentsNavSection();
  stabilizeAskOracleStaticLeftNavBits();
  startAskOracleNewChatDomObserver();
  syncAskOracleConversationNavSelection();
  refreshRunPromptButtonState();
}

function ensurePromptBarModeCss() {
  if (document.getElementById("prompt-bar-mode-css")) return;
  const style = document.createElement("style");
  style.id = "prompt-bar-mode-css";
  style.textContent = `
    body.prompt-center-mode {
      --prompt-center-inset: ${CENTER_PROMPT_INSET_PX}px;
      --prompt-center-left-margin: ${CENTER_PROMPT_LEFT_MARGIN_PX}px;
      --prompt-center-right-margin: ${CENTER_PROMPT_RIGHT_MARGIN_PX}px;
      --prompt-center-max-width: ${CENTER_PROMPT_MAX_WIDTH_PX}px;
      background: #ffffff !important;
    }

    body.prompt-center-mode .t-Body-content,
    body.prompt-center-mode .t-Body-contentInner,
    body.prompt-center-mode #PROMPTS {
      background: #ffffff !important;
    }

    body.prompt-center-mode .t-Footer {
      position: fixed !important;
      top: ${getCenterPromptTopCssValue()} !important;
      bottom: auto !important;
      left: calc((100vw + var(--prompt-center-left-margin, 200px) - var(--prompt-center-right-margin, 30px)) / 2) !important;
      right: auto !important;
      transform: translate(-50%, -50%) !important;
      width: min(var(--prompt-center-max-width, 780px), calc(100vw - var(--prompt-center-left-margin, 200px) - var(--prompt-center-right-margin, 30px) - (2 * var(--prompt-center-inset, 0px)))) !important;
      max-width: var(--prompt-center-max-width, 780px) !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      gap: 14px !important;
      padding: 0 !important;
      background: transparent !important;
      box-shadow: none !important;
      border: 0 !important;
      z-index: 1000 !important;
    }

    body.prompt-center-mode #center-prompt-title {
      font-weight: 600;
      font-size: clamp(22px, 3vw, 30px);
      line-height: 1.1;
      text-align: center;
      margin-bottom: ${CENTER_PROMPT_TITLE_MARGIN_BOTTOM_PX}px;
      color: #161616;
      letter-spacing: -0.01em;
      width: 100%;
      display: block;
    }
    body.t-Body--dark.prompt-center-mode #center-prompt-title,
    body.u-Theme--dark.prompt-center-mode #center-prompt-title,
    body.prompt-center-mode.dark-mode #center-prompt-title,
    body.ask-oracle-dark-ui.prompt-center-mode #center-prompt-title,
    html.t-Body--dark body.prompt-center-mode #center-prompt-title,
    html.u-Theme--dark body.prompt-center-mode #center-prompt-title,
    html.ask-oracle-dark-ui body.prompt-center-mode #center-prompt-title {
      color: #f8fafc;
    }

    #${ASK_ORACLE_MODE_CHIP_ID},
    .ask-oracle-mode-chip {
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      height: 20px !important;
      min-height: 20px !important;
      max-height: 20px !important;
      padding: 0 8px !important;
      margin: 0 8px 0 0 !important;
      border-radius: 999px !important;
      border: 1px solid #e5e7eb !important;
      background: #f4f5f6 !important;
      color: #3f3f46 !important;
      font-family: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      line-height: 1 !important;
      letter-spacing: 0 !important;
      text-transform: uppercase !important;
      white-space: nowrap !important;
      flex: 0 0 auto !important;
      box-sizing: border-box !important;
      pointer-events: none !important;
    }

    body.prompt-center-mode .t-Footer-body,
    body.prompt-center-mode .t-Footer-content,
    body.prompt-center-mode #promptWrapper {
      width: 100% !important;
      max-width: var(--prompt-center-max-width, 780px) !important;
    }

    body.prompt-center-mode #promptWrapper {
      min-height: 52px !important;
      height: auto !important;
      padding: 0 12px !important;
      border-radius: 26px !important;
      border: 1px solid #111111 !important;
      background: #ffffff !important;
      overflow: visible !important;
      box-sizing: border-box !important;
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
      box-shadow: none !important;
    }

    @keyframes askOracleCenterPromptBlinkPulse {
      0% {
        box-shadow: 0 0 0 0 rgba(37, 99, 235, 0.34);
      }
      50% {
        box-shadow: 0 0 0 8px rgba(37, 99, 235, 0);
      }
      100% {
        box-shadow: 0 0 0 0 rgba(37, 99, 235, 0);
      }
    }

    body.prompt-center-mode #promptWrapper.${ASK_ORACLE_CENTER_PROMPT_BLINK_CLASS} {
      animation: askOracleCenterPromptBlinkPulse 0.72s ease-in-out 2;
    }

    body.prompt-center-mode #PROMPTS {
      width: 100% !important;
      max-width: none !important;
      padding-top: 4vh !important;
    }

    body.prompt-center-mode #PROMPTS_TemplateComponent,
    body.prompt-center-mode #P1_PROMPT1 {
      width: 100% !important;
      max-width: none !important;
    }

    body.prompt-center-mode #PROMPTS_TemplateComponent {
      min-height: ${CENTER_PROMPT_BAR_HEIGHT_PX}px !important;
    }

    body.prompt-center-mode #P1_PROMPT1 {
      height: ${CENTER_PROMPT_BAR_HEIGHT_PX}px !important;
      min-height: ${CENTER_PROMPT_BAR_HEIGHT_PX}px !important;
      max-height: ${PROMPT_INPUT_MAX_HEIGHT_PX}px !important;
      padding-top: ${CENTER_PROMPT_VERTICAL_PADDING_PX}px !important;
      padding-bottom: ${CENTER_PROMPT_VERTICAL_PADDING_PX}px !important;
      line-height: ${CENTER_PROMPT_INPUT_LINE_HEIGHT_PX}px !important;
      overflow-y: auto !important;
      resize: vertical !important;
      box-sizing: border-box !important;
      margin: 0 !important;
      margin-top: 0 !important;
      margin-right: 0 !important;
      margin-bottom: 0 !important;
      margin-left: 0 !important;
      display: block !important;
      align-self: center !important;
      position: relative !important;
      top: auto !important;
      bottom: auto !important;
      transform: none !important;
      vertical-align: middle !important;
    }

    body.prompt-center-mode #promptWrapper #P1_PROMPT1,
    body.prompt-center-mode #promptWrapper textarea#P1_PROMPT1 {
      margin: 0 !important;
      margin-top: 0 !important;
      margin-right: 0 !important;
      margin-bottom: 0 !important;
      margin-left: 0 !important;
      transform: none !important;
      position: relative !important;
      top: auto !important;
      bottom: auto !important;
    }

    body.prompt-center-mode #addPrompt,
    body.prompt-center-mode #startSpeechButton,
    body.prompt-center-mode #runPrompt {
      width: 30px !important;
      height: 30px !important;
      min-width: 30px !important;
      min-height: 30px !important;
      padding: 0 !important;
      border-radius: 50% !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      box-sizing: border-box !important;
    }

    body.prompt-center-mode #static-region-footer {
      display: none !important;
    }

    #P1_PROMPT1::placeholder {
      color: var(--ask-oracle-prompt-placeholder, #6b7280) !important;
      opacity: 1;
    }
    body.prompt-center-mode #P1_PROMPT1::placeholder {
      display: block !important;
      line-height: inherit !important;
      transform: translateY(${CENTER_PROMPT_PLACEHOLDER_Y_OFFSET_PX}px) !important;
      margin-top: ${CENTER_PROMPT_PLACEHOLDER_MARGIN_TOP_PX}px !important;
      margin-bottom: ${CENTER_PROMPT_PLACEHOLDER_MARGIN_BOTTOM_PX}px !important;
    }
    .ask-oracle-borderless-response {
      border: 0 !important;
      box-shadow: none !important;
      background: transparent !important;
    }
    .response-box .llm-md-h1,
    .llm-md-h1 {
      margin: 14px 0 0;
      font-size: 1.46rem;
      font-weight: 800;
      line-height: 1.2;
      color: #1d4ed8;
      border-left: 4px solid #3b82f6;
      padding-left: 10px;
    }
    .response-box .llm-md-h2,
    .llm-md-h2 {
      margin: 12px 0 0;
      font-size: 1.28rem;
      font-weight: 750;
      line-height: 1.25;
      color: #1d4ed8;
      border-left: 3px solid #3b82f6;
      padding-left: 9px;
    }
    .response-box .llm-md-h3,
    .llm-md-h3 {
      margin: 10px 0 0;
      font-size: 1.24rem;
      font-weight: 700;
      line-height: 1.3;
      color: #1d4ed8;
      border-left: 2px solid #3b82f6;
      padding-left: 8px;
    }
    .response-box strong,
    .llm-chat strong {
      color: #000000;
      font-weight: 700;
    }
    body.ask-oracle-dark-ui .response-box .llm-md-h1,
    body.ask-oracle-dark-ui .llm-md-h1 {
      color: #93c5fd;
      border-left-color: #93c5fd;
    }
    body.ask-oracle-dark-ui .response-box .llm-md-h2,
    body.ask-oracle-dark-ui .llm-md-h2 {
      color: #93c5fd;
      border-left-color: #93c5fd;
    }
    body.ask-oracle-dark-ui .response-box .llm-md-h3,
    body.ask-oracle-dark-ui .llm-md-h3 {
      color: #93c5fd;
      border-left-color: #93c5fd;
    }
    body.ask-oracle-dark-ui .response-box strong,
    body.ask-oracle-dark-ui .llm-chat strong {
      color: #000000;
    }
    .response-box table thead th,
    .response-box table thead td {
      background: #dbeafe !important;
      background-color: #dbeafe !important;
      color: #1e3a8a !important;
      border: 1px solid #bfdbfe !important;
      border-color: #bfdbfe !important;
    }
    .response-box table tbody td,
    .response-box table tbody th {
      border: 0 !important;
      border-color: transparent !important;
    }
    .response-box.ask-oracle-nl2sql-full-grid table th,
    .response-box.ask-oracle-nl2sql-full-grid table td {
      border: 1px solid rgba(51, 65, 85, 0.55) !important;
      border-color: rgba(51, 65, 85, 0.55) !important;
    }
    .response-box.ask-oracle-nl2sql-full-grid table thead th,
    .response-box.ask-oracle-nl2sql-full-grid table thead td {
      background: #dbeafe !important;
      background-color: #dbeafe !important;
      color: #1e3a8a !important;
    }
    body.ask-oracle-dark-ui .response-box table thead th,
    body.ask-oracle-dark-ui .response-box table thead td {
      background: #dbeafe !important;
      background-color: #dbeafe !important;
      color: #1e3a8a !important;
      border: 1px solid #93c5fd !important;
      border-color: #93c5fd !important;
    }
    body.ask-oracle-dark-ui .response-box table tbody td,
    body.ask-oracle-dark-ui .response-box table tbody th {
      border: 0 !important;
      border-color: transparent !important;
    }
    body.ask-oracle-dark-ui .response-box.ask-oracle-nl2sql-full-grid table th,
    body.ask-oracle-dark-ui .response-box.ask-oracle-nl2sql-full-grid table td {
      border: 1px solid rgba(51, 65, 85, 0.55) !important;
      border-color: rgba(51, 65, 85, 0.55) !important;
    }
    body.ask-oracle-dark-ui .response-box.ask-oracle-nl2sql-full-grid table thead th,
    body.ask-oracle-dark-ui .response-box.ask-oracle-nl2sql-full-grid table thead td {
      background: #dbeafe !important;
      background-color: #dbeafe !important;
      color: #1e3a8a !important;
    }
    .ask-oracle-mic-disabled,
    .ask-oracle-mic-disabled i,
    .ask-oracle-mic-disabled svg {
      pointer-events: none !important;
      opacity: 0.45 !important;
      filter: grayscale(1) !important;
      cursor: not-allowed !important;
    }
    #promptWrapper #P1_PROMPT1,
    #promptWrapper #P1_PROMPT1:focus,
    #promptWrapper #P1_PROMPT1:hover,
    #promptWrapper #P1_PROMPT1_CONTAINER,
    #promptWrapper #P1_PROMPT1_display,
    #promptWrapper #P1_PROMPT1_CONTAINER input,
    #promptWrapper #P1_PROMPT1_CONTAINER textarea,
    #promptWrapper .t-Form-inputContainer,
    #promptWrapper .t-Form-textarea,
    #promptWrapper .apex-item-text,
    #promptWrapper .apex-item-textarea {
      border: 0 !important;
      box-shadow: none !important;
      outline: none !important;
      background-image: none !important;
    }
    #promptWrapper textarea#P1_PROMPT1,
    textarea#P1_PROMPT1 {
      min-height: ${PROMPT_INPUT_FOOTER_DESKTOP_BASE_HEIGHT_PX}px !important;
      max-height: ${PROMPT_INPUT_MAX_HEIGHT_PX}px !important;
      resize: vertical !important;
      overflow-y: auto !important;
    }

    body.ask-oracle-dark-ui .t-Footer,
    body.ask-oracle-dark-ui .t-Footer-body,
    body.ask-oracle-dark-ui .t-Footer-content,
    body.ask-oracle-dark-ui #PROMPTS_TemplateComponent {
      background-color: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
      color: #e2e8f0 !important;
      border: 0 !important;
      box-shadow: none !important;
    }
    body.ask-oracle-dark-ui #promptWrapper,
    body.ask-oracle-dark-ui .prompt-wrapper,
    body.ask-oracle-dark-ui #P1_PROMPT2,
    body.ask-oracle-dark-ui #P1_PROMPT2_CONTAINER,
    body.ask-oracle-dark-ui #P1_PROMPT2_display {
      background-color: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
      border: 1px solid rgba(148, 163, 184, 0.6) !important;
      box-shadow: none !important;
    }

    body.ask-oracle-dark-ui #P1_PROMPT1 {
      background-color: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
      color: #f8fafc !important;
      caret-color: #f8fafc !important;
      border: 0 !important;
      box-shadow: none !important;
      outline: none !important;
    }
    body.ask-oracle-dark-ui #P1_PROMPT1_CONTAINER,
    body.ask-oracle-dark-ui #P1_PROMPT1_display,
    body.ask-oracle-dark-ui #P1_PROMPT1_CONTAINER input,
    body.ask-oracle-dark-ui #P1_PROMPT1_CONTAINER textarea {
      background-color: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
      border: 0 !important;
      box-shadow: none !important;
      outline: none !important;
      color: #f8fafc !important;
    }
    body.ask-oracle-dark-ui #P1_PROMPT1:focus {
      border: 0 !important;
      box-shadow: none !important;
      outline: none !important;
    }

    body.ask-oracle-dark-ui.prompt-center-mode .t-Footer,
    body.ask-oracle-dark-ui.prompt-center-mode .t-Footer-body,
    body.ask-oracle-dark-ui.prompt-center-mode .t-Footer-content,
    body.ask-oracle-dark-ui.prompt-center-mode #promptWrapper,
    body.ask-oracle-dark-ui.prompt-center-mode #PROMPTS_TemplateComponent {
      background-color: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
    }
    body.ask-oracle-dark-ui.prompt-center-mode #promptWrapper {
      border: 1px solid #111111 !important;
      box-shadow: none !important;
    }
    body.ask-oracle-dark-ui.prompt-center-mode #promptWrapper input,
    body.ask-oracle-dark-ui.prompt-center-mode #promptWrapper textarea,
    body.ask-oracle-dark-ui.prompt-center-mode #promptWrapper .t-Form-inputContainer,
    body.ask-oracle-dark-ui.prompt-center-mode #promptWrapper .apex-item-text,
    body.ask-oracle-dark-ui.prompt-center-mode #promptWrapper .apex-item-textarea {
      background-color: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
      border: 0 !important;
      box-shadow: none !important;
      outline: none !important;
      color: #f8fafc !important;
    }
    body.ask-oracle-dark-ui.prompt-center-mode #P1_PROMPT1 {
      border: 0 !important;
      box-shadow: none !important;
      outline: none !important;
    }

    body.ask-oracle-dark-ui #addPrompt,
    body.ask-oracle-dark-ui #startSpeechButton {
      background-color: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
      border: 0 !important;
      color: #f8fafc !important;
      box-shadow: none !important;
      background-image: none !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    body.ask-oracle-dark-ui #addPrompt i,
    body.ask-oracle-dark-ui #startSpeechButton i,
    body.ask-oracle-dark-ui #runPrompt i {
      color: #f8fafc !important;
    }
    body.ask-oracle-dark-ui #runPrompt {
      border: 0 !important;
      color: #f8fafc !important;
      box-shadow: none !important;
      background-image: none !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    body.ask-oracle-dark-ui #startSpeechButton,
    body.ask-oracle-dark-ui #startSpeechButton i,
    body.ask-oracle-dark-ui #runPrompt,
    body.ask-oracle-dark-ui #runPrompt i {
      color: #f8fafc !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    body.ask-oracle-dark-ui #startSpeechButton svg,
    body.ask-oracle-dark-ui #runPrompt svg {
      fill: currentColor !important;
      stroke: currentColor !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    body.ask-oracle-dark-ui #startSpeechButton::before,
    body.ask-oracle-dark-ui #startSpeechButton::after,
    body.ask-oracle-dark-ui #runPrompt::before,
    body.ask-oracle-dark-ui #runPrompt::after {
      color: #f8fafc !important;
      border-color: transparent !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    body.ask-oracle-dark-ui #promptWrapper button,
    body.ask-oracle-dark-ui #promptWrapper .t-Button {
      background-color: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
      border: 0 !important;
      color: #f8fafc !important;
      box-shadow: none !important;
      background-image: none !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    body.ask-oracle-dark-ui #promptWrapper button i,
    body.ask-oracle-dark-ui #promptWrapper .t-Button i,
    body.ask-oracle-dark-ui #promptWrapper button svg,
    body.ask-oracle-dark-ui #promptWrapper .t-Button svg {
      color: #f8fafc !important;
      fill: currentColor !important;
      stroke: currentColor !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    body.ask-oracle-dark-ui #promptWrapper [aria-label*="mic" i],
    body.ask-oracle-dark-ui #promptWrapper [aria-label*="voice" i],
    body.ask-oracle-dark-ui #promptWrapper [title*="mic" i],
    body.ask-oracle-dark-ui #promptWrapper [title*="voice" i],
    body.ask-oracle-dark-ui #promptWrapper [id*="speech" i],
    body.ask-oracle-dark-ui #promptWrapper [class*="speech" i] {
      color: #f8fafc !important;
      opacity: 1 !important;
      visibility: visible !important;
    }

    body.ask-oracle-dark-ui .speech-controls .speech-icon-button {
      background: var(--ask-oracle-footer-surface, ${ASK_ORACLE_DARK_SURFACE_COLOR}) !important;
      border: 0 !important;
      color: #e2e8f0 !important;
      box-shadow: none !important;
    }
    body.ask-oracle-dark-ui .speech-controls .speech-icon-button i {
      color: inherit !important;
    }
    body.ask-oracle-dark-ui .speech-controls .speech-icon-button:hover {
      background: rgba(30, 41, 59, 0.95) !important;
      border: 0 !important;
      color: #ffffff !important;
    }
    .speech-controls .speech-icon-button {
      border: 0 !important;
      box-shadow: none !important;
    }
    .speech-controls .speech-icon-button:hover {
      border: 0 !important;
    }
    body.ask-oracle-dark-ui .speech-controls .profile-label {
      color: #cbd5e1 !important;
    }
  `;
  document.head.appendChild(style);
}

function ensureCenterPromptTitle() {
  const footer = document.querySelector(".t-Footer");
  if (!footer) return;
  if (document.getElementById("center-prompt-title")) return;

  const title = document.createElement("div");
  title.id = "center-prompt-title";
  title.textContent = getAskOraclePromptBarTitle();

  const promptWrapper = document.getElementById("promptWrapper");
  if (promptWrapper && promptWrapper.parentElement === footer) {
    footer.insertBefore(title, promptWrapper);
  } else {
    footer.prepend(title);
  }
}

function removeCenterPromptTitle() {
  const title = document.getElementById("center-prompt-title");
  if (title) title.remove();
}

function positionCenterPromptBar() {
  if (!document.body.classList.contains("prompt-center-mode")) return;

  const footer = document.querySelector(".t-Footer");
  if (!footer) return;
  footer.style.setProperty("--prompt-center-inset", `${CENTER_PROMPT_INSET_PX}px`);
  footer.style.setProperty("--prompt-center-left-margin", `${CENTER_PROMPT_LEFT_MARGIN_PX}px`);
  footer.style.setProperty("--prompt-center-right-margin", `${CENTER_PROMPT_RIGHT_MARGIN_PX}px`);
  const matchedCenter = "calc((100vw + var(--prompt-center-left-margin, 200px) - var(--prompt-center-right-margin, 30px)) / 2)";
  const matchedWidth = "calc(100vw - var(--prompt-center-left-margin, 200px) - var(--prompt-center-right-margin, 30px) - (2 * var(--prompt-center-inset, 0px)))";
  const matchedTop = getCenterPromptTopCssValue();
  // Footer mode writes inline !important top/bottom styles; center mode must overwrite them explicitly.
  footer.style.setProperty("position", "fixed", "important");
  footer.style.setProperty("top", matchedTop, "important");
  footer.style.setProperty("bottom", "auto", "important");
  footer.style.setProperty("left", matchedCenter, "important");
  footer.style.setProperty("right", "auto", "important");
  footer.style.setProperty("transform", "translate(-50%, -50%)", "important");
  footer.style.setProperty("width", matchedWidth, "important");
  footer.style.setProperty("max-width", "none", "important");
  footer.style.setProperty("z-index", "1000", "important");
}

function positionFooterPromptBar() {
  if (document.body.classList.contains("prompt-center-mode")) return;

  const footer = document.querySelector(".t-Footer");
  if (!footer) return;

  function hasUsableRect(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  const isEditorMode = document.body.classList.contains("code-editor-mode");
  const bodyContent = document.querySelector(".t-Body-content");
  const promptRegionBody = document.querySelector("#PROMPTS .t-Region-body");
  const promptRegion = document.getElementById("PROMPTS");
  const promptList = document.querySelector("#PROMPTS .prompt-list");
  let alignTarget = null;
  if (hasUsableRect(promptRegionBody)) {
    alignTarget = promptRegionBody;
  } else if (hasUsableRect(promptRegion)) {
    alignTarget = promptRegion;
  } else if (hasUsableRect(promptList)) {
    alignTarget = promptList;
  } else if (hasUsableRect(bodyContent)) {
    alignTarget = bodyContent;
  } else {
    alignTarget = bodyContent || promptRegionBody || promptRegion || promptList;
  }
  if (!alignTarget) {
    footer.style.left = "";
    footer.style.right = "";
    footer.style.width = "";
    footer.style.maxWidth = "";
    return;
  }

  const rect = alignTarget.getBoundingClientRect();
  const effectiveLeftMargin = isEditorMode ? 0 : FOOTER_PROMPT_LEFT_MARGIN_PX;
  const effectiveRightMargin = isEditorMode ? 0 : FOOTER_PROMPT_RIGHT_MARGIN_PX;
  const leftPx = Math.max(0, Math.round(rect.left) + effectiveLeftMargin);
  const baseRightPx = Math.max(
    0,
    Math.round(window.innerWidth - rect.right) + effectiveRightMargin
  );
  const editorOffsetPx = isEditorMode ? getCodeEditorLayoutOffsetPx() : 0;
  const rightPx = isEditorMode
    ? Math.max(baseRightPx, editorOffsetPx)
    : baseRightPx;

  footer.style.setProperty("position", "fixed", "important");
  footer.style.setProperty("transform", "none", "important");
  footer.style.setProperty("left", `${leftPx}px`, "important");
  footer.style.setProperty("right", `${rightPx}px`, "important");
  footer.style.setProperty("bottom", `${Math.max(0, FOOTER_PROMPT_BOTTOM_MARGIN_PX)}px`, "important");
  footer.style.setProperty("top", "auto", "important");
  footer.style.setProperty("width", "auto", "important");
  footer.style.setProperty("max-width", "none", "important");
}

function hasConversationMessages() {
  const container = getChatContainer();
  if (!container) return false;

  function isActuallyVisible(node) {
    if (!node || !node.isConnected) return false;
    let current = node;
    while (current && current.nodeType === 1) {
      if (current.hidden) return false;
      if (current.getAttribute && current.getAttribute("aria-hidden") === "true") return false;
      const style = window.getComputedStyle(current);
      if (style.display === "none" || style.visibility === "hidden") return false;
      if (current === container || current === document.body || current === document.documentElement) break;
      current = current.parentElement;
    }
    return true;
  }

  const nodes = container.querySelectorAll(
    ".chat-message, .response-box, .llm-chat, [id^='prompt-'], [id^='response-']"
  );
  if (!nodes || nodes.length === 0) return false;

  return Array.from(nodes).some((node) => {
    if (!isActuallyVisible(node)) return false;

    const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
    if (text.length > 0) return true;
    return !!node.querySelector("table, pre, code, canvas, svg, img");
  });
}

function syncCenterFooterDisclaimer(mode) {
  const footerNote = document.getElementById("static-region-footer");
  if (!footerNote) return;
  footerNote.style.display = mode === "center" ? "none" : "";
}

function setPromptBarMode(mode) {
  const body = document.body;
  if (!body) return;
  ensurePromptBarModeCss();
  syncCenterFooterDisclaimer(mode);

  if (mode === "center") {
    body.classList.add("prompt-center-mode");
    ensureCenterPromptTitle();
    positionCenterPromptBar();
  } else {
    body.classList.remove("prompt-center-mode");
    removeCenterPromptTitle();
    positionFooterPromptBar();
  }

  applyFooterAppearance();
  scheduleFooterScrollDownRefresh();
  if (!isPromptRequestRunning()) {
    focusPromptInputForCaret();
  }
  if (getPromptInputValue().length > 0) {
    autoGrowPromptInput();
  } else {
    resetPromptInputHeight();
  }
}

function syncPromptBarMode() {
  setPromptBarMode(hasConversationMessages() ? "footer" : "center");
}

function schedulePromptBarAlignmentResync() {
  const delays = [0, 120, 360, 900];
  delays.forEach((delayMs) => {
    setTimeout(() => {
      try {
        syncPromptBarMode();
        const inputEl = document.getElementById("P1_PROMPT1");
        if (!inputEl) return;
        if (getPromptInputValue().length > 0) {
          autoGrowPromptInput();
        } else {
          resetPromptInputHeight();
        }
        applyFooterAppearance();
      } catch (e) {}
    }, delayMs);
  });
}

function ensureFooterScrollDownCss() {
  if (document.getElementById(FOOTER_SCROLL_DOWN_CSS_ID)) return;

  const style = document.createElement("style");
  style.id = FOOTER_SCROLL_DOWN_CSS_ID;
  style.textContent = `
    #${FOOTER_SCROLL_DOWN_BTN_ID} {
      position: absolute;
      left: 50%;
      top: 0;
      transform: translate(-50%, -135%);
      width: 34px;
      height: 34px;
      border-radius: 999px;
      border: 1px solid #d0d7de;
      background: #ffffff;
      color: #1f2328;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      box-shadow: 0 6px 18px rgba(31, 35, 40, 0.18);
      z-index: 6;
      font-size: 16px;
      line-height: 1;
    }
    #${FOOTER_SCROLL_DOWN_BTN_ID}:hover {
      background: #f6f8fa;
    }
    #${FOOTER_SCROLL_DOWN_BTN_ID}:focus-visible {
      outline: 2px solid #4a90e2;
      outline-offset: 2px;
    }
  `;
  document.head.appendChild(style);
}

function getFooterScrollDownButton() {
  return document.getElementById(FOOTER_SCROLL_DOWN_BTN_ID);
}

function getFooterScrollTarget() {
  const chatContainer = getChatContainer();
  return getScrollParent(chatContainer || document.body);
}

function getScrollerMetrics(scroller) {
  if (scroller === window) {
    const top = window.pageYOffset || document.documentElement.scrollTop || 0;
    const maxTop = Math.max(
      0,
      Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) - window.innerHeight
    );
    return { top, maxTop };
  }

  return {
    top: scroller.scrollTop,
    maxTop: Math.max(0, scroller.scrollHeight - scroller.clientHeight)
  };
}

function scrollFooterTargetToBottom() {
  const scroller = getFooterScrollTarget();
  if (scroller === window) {
    const maxTop = Math.max(
      0,
      Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) - window.innerHeight
    );
    window.scrollTo({ top: maxTop, behavior: "smooth" });
  } else {
    scroller.scrollTo({ top: scroller.scrollHeight, behavior: "smooth" });
  }
}

function bindFooterScrollDownTarget(scroller) {
  if (footerScrollDownBoundScroller === scroller) return;

  if (footerScrollDownBoundScroller) {
    footerScrollDownBoundScroller.removeEventListener("scroll", scheduleFooterScrollDownRefresh);
  }
  footerScrollDownBoundScroller = scroller;
  if (footerScrollDownBoundScroller) {
    footerScrollDownBoundScroller.addEventListener("scroll", scheduleFooterScrollDownRefresh, { passive: true });
  }
}

function ensureFooterScrollDownButton() {
  ensureFooterScrollDownCss();
  const footer = document.querySelector(".t-Footer");
  if (!footer) return null;

  let btn = getFooterScrollDownButton();
  if (btn && btn.parentElement !== footer) {
    btn.remove();
    btn = null;
  }

  if (!btn) {
    btn = document.createElement("button");
    btn.type = "button";
    btn.id = FOOTER_SCROLL_DOWN_BTN_ID;
    btn.setAttribute("aria-label", "Scroll down");
    btn.title = "Scroll to bottom";
    btn.innerHTML = "&#8595;";
    btn.addEventListener("click", function() {
      scrollFooterTargetToBottom();
    });
    footer.appendChild(btn);
  }

  return btn;
}

function scheduleFooterScrollDownRefresh() {
  if (footerScrollDownRefreshQueued) return;
  footerScrollDownRefreshQueued = true;
  requestAnimationFrame(() => {
    footerScrollDownRefreshQueued = false;
    refreshFooterScrollDownButton();
  });
}

function refreshFooterScrollDownButton() {
  const btn = ensureFooterScrollDownButton();
  if (!btn) return;

  const footerMode = !document.body.classList.contains("prompt-center-mode");
  const footer = document.querySelector(".t-Footer");
  const footerVisible = !!footer && window.getComputedStyle(footer).visibility !== "hidden" && window.getComputedStyle(footer).display !== "none";

  if (!footerMode || !footerVisible) {
    btn.style.display = "none";
    return;
  }

  const scroller = getFooterScrollTarget();
  bindFooterScrollDownTarget(scroller);

  const { top, maxTop } = getScrollerMetrics(scroller);
  const canScrollDown = maxTop > 2 && (maxTop - top) > 2;
  btn.style.display = canScrollDown ? "inline-flex" : "none";
}

function initFooterScrollDownArrow() {
  ensureFooterScrollDownButton();

  window.addEventListener("resize", scheduleFooterScrollDownRefresh, { passive: true });
  window.addEventListener("scroll", scheduleFooterScrollDownRefresh, { passive: true });

  const chatContainer = getChatContainer();
  if (chatContainer && "MutationObserver" in window) {
    footerScrollDownObserver = new MutationObserver(scheduleFooterScrollDownRefresh);
    footerScrollDownObserver.observe(chatContainer, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  scheduleFooterScrollDownRefresh();
}

function resetPromptInputHeight() {
  const inputEl = document.getElementById("P1_PROMPT1");
  if (!inputEl) return;
  delete inputEl.dataset.manualPromptHeight;
  inputEl.style.setProperty("height", `${getPromptInputBaseHeightPx()}px`, "important");
  if (document.body && document.body.classList.contains("prompt-center-mode")) {
    inputEl.style.setProperty("min-height", `${PROMPT_INPUT_CENTER_BASE_HEIGHT_PX}px`, "important");
    inputEl.style.setProperty("overflow-y", "hidden", "important");
  } else {
    inputEl.style.overflowY = "hidden";
  }
  syncCenterPromptShellHeight(inputEl);
}

function showLoadingUI() {
  const loaderRegion = document.querySelector("#LOADER_REGION");
  const loaderIndicator = document.querySelector("#loading-indicator");
  if (loaderRegion) loaderRegion.style.display = "block";
  promptInput.disabled = true;
  runButton.disabled = true;
  if (loaderIndicator) loaderIndicator.style.display = "flex";
  refreshRunPromptButtonState();
}

function hideLoadingUI() {
  console.log('Hiding the spinner');
  const loaderIndicator = document.querySelector("#loading-indicator");
  const loaderRegion = document.querySelector("#LOADER_REGION");
  promptInput.disabled = false;
  runButton.disabled = false;
  if (loaderIndicator) loaderIndicator.style.display = "none";
  if (loaderRegion) loaderRegion.style.display = "none";
  refreshRunPromptButtonState();
}

function isPromptMicButtonActive(btn) {
  if (!btn) return false;
  const ariaPressed = String(btn.getAttribute("aria-pressed") || "").toLowerCase() === "true";
  if (ariaPressed) return true;

  const stateText = `${btn.getAttribute("data-state") || ""} ${btn.getAttribute("data-status") || ""}`.toLowerCase();
  if (/(recording|listening|active|on|running|stop)/i.test(stateText)) return true;

  const classList = Array.from(btn.classList || []);
  const activeClassNames = [
    "is-recording",
    "is-listening",
    "mic-active",
    "recording-active",
    "active-recording",
    "is-active"
  ];
  if (activeClassNames.some((name) => classList.includes(name))) return true;

  const icon = btn.querySelector("i");
  const iconClassList = Array.from(icon && icon.classList ? icon.classList : []);
  const activeIconClasses = ["fa-stop", "fa-circle-stop", "fa-stop-circle", "fa-microphone-slash"];
  return activeIconClasses.some((name) => iconClassList.includes(name));
}

function setPromptMicInteractionDisabled(disabled) {
  const shouldDisable = !!disabled;
  const micCandidates = Array.from(new Set([
    document.getElementById("startSpeechButton"),
    document.querySelector("#promptWrapper .llm-recording"),
    document.querySelector("#promptWrapper [aria-label*='mic' i]"),
    document.querySelector("#promptWrapper [aria-label*='voice' i]"),
    document.querySelector("#promptWrapper [id*='speech' i]"),
    document.querySelector("#promptWrapper [class*='speech' i]")
  ].filter(Boolean)));

  micCandidates.forEach((btn) => {
    try {
      if ("disabled" in btn) btn.disabled = shouldDisable;
      if (shouldDisable) {
        btn.classList.add("ask-oracle-mic-disabled");
        btn.setAttribute("aria-disabled", "true");
        btn.style.setProperty("pointer-events", "none", "important");
        btn.style.setProperty("opacity", "0.45", "important");
        btn.style.setProperty("filter", "grayscale(1)", "important");
        btn.style.setProperty("cursor", "not-allowed", "important");
      } else {
        btn.classList.remove("ask-oracle-mic-disabled");
        btn.removeAttribute("aria-disabled");
        btn.style.removeProperty("pointer-events");
        btn.style.removeProperty("opacity");
        btn.style.removeProperty("filter");
        btn.style.removeProperty("cursor");
      }
    } catch (e) {}
  });
}

function isAskOracleMicUiElement(target) {
  if (!target || typeof target.closest !== "function") return false;
  return !!target.closest(
    "#startSpeechButton, #promptWrapper .llm-recording, #promptWrapper [aria-label*='mic' i], #promptWrapper [aria-label*='voice' i], #promptWrapper [title*='mic' i], #promptWrapper [title*='voice' i], #promptWrapper [id*='speech' i], #promptWrapper [class*='speech' i]"
  );
}

function bindAskOracleMicStopModeGuards() {
  if (askOracleMicBlockerBound) return;
  askOracleMicBlockerBound = true;

  function blockMicIfNeeded(event) {
    if (!askOracleMicStopState) return;
    const target = event && event.target;
    const runBtn = document.getElementById("runPrompt");
    if (runBtn && target && typeof target.closest === "function" && target.closest("#runPrompt")) return;

    const insidePromptWrapper = !!(target && typeof target.closest === "function" && target.closest("#promptWrapper"));
    if (!isAskOracleMicUiElement(target) && !insidePromptWrapper) return;
    try { event.preventDefault(); } catch (e) {}
    try { event.stopImmediatePropagation(); } catch (e) {}
    try { event.stopPropagation(); } catch (e) {}
    stopPromptMicrophoneCapture();
  }

  ["click", "mousedown", "mouseup", "touchstart", "pointerdown", "keydown", "keyup"].forEach((evtName) => {
    document.addEventListener(evtName, blockMicIfNeeded, true);
  });
}

function setAskOracleMicStopState(enabled) {
  askOracleMicStopState = !!enabled;
  if (askOracleMicStopState) {
    stopPromptMicrophoneCapture();
    if (!askOracleMicStopHeartbeatId) {
      askOracleMicStopHeartbeatId = setInterval(() => {
        if (!askOracleMicStopState) return;
        stopPromptMicrophoneCapture();
      }, 250);
    }
  } else if (askOracleMicStopHeartbeatId) {
    clearInterval(askOracleMicStopHeartbeatId);
    askOracleMicStopHeartbeatId = null;
  }
}

function stopPromptMicrophoneCapture() {
  const globalMicActive = !!(
    window.isRecording ||
    window.isListening ||
    window.speechRecognitionActive ||
    window.__askOracleMicActive
  );

  try {
    if (window.speechRecognition && typeof window.speechRecognition.stop === "function") {
      window.speechRecognition.stop();
    }
  } catch (e) {}
  try {
    if (window.recognition && typeof window.recognition.stop === "function") {
      window.recognition.stop();
    }
  } catch (e) {}
  try {
    if (window.__askOracleSpeechRecognition && typeof window.__askOracleSpeechRecognition.stop === "function") {
      window.__askOracleSpeechRecognition.stop();
    }
  } catch (e) {}
  try {
    if (typeof window.stopSpeechRecognition === "function") {
      window.stopSpeechRecognition();
    }
  } catch (e) {}

  const micCandidates = Array.from(new Set([
    document.getElementById("startSpeechButton"),
    document.querySelector("#promptWrapper .llm-recording"),
    document.querySelector("#promptWrapper [aria-label*='mic' i]"),
    document.querySelector("#promptWrapper [aria-label*='voice' i]"),
    document.querySelector("#promptWrapper [id*='speech' i]"),
    document.querySelector("#promptWrapper [class*='speech' i]")
  ].filter(Boolean)));

  micCandidates.forEach((btn) => {
    if (!globalMicActive && !isPromptMicButtonActive(btn)) return;
    try { btn.click(); } catch (e) {}
  });
}


function bindRunPromptClickHandler() {
  ensureAskOraclePromptCoreElements();
  const runPromptBtn = document.getElementById("runPrompt");
  if (!runPromptBtn) {
    if (askOracleRunButtonBindRetryCount < ASK_ORACLE_RUN_BUTTON_BIND_MAX_RETRIES) {
      askOracleRunButtonBindRetryCount += 1;
      if (askOracleRunButtonBindRetryTimer) clearTimeout(askOracleRunButtonBindRetryTimer);
      askOracleRunButtonBindRetryTimer = setTimeout(bindRunPromptClickHandler, 200);
    }
    return;
  }
  askOracleRunButtonBindRetryCount = 0;
  if (askOracleRunButtonBindRetryTimer) {
    clearTimeout(askOracleRunButtonBindRetryTimer);
    askOracleRunButtonBindRetryTimer = null;
  }
  if (runPromptBtn.dataset.askOracleRunBound === "true") return;
  runPromptBtn.dataset.askOracleRunBound = "true";

  runPromptBtn.addEventListener("click", function (e) {
      console.log("🔹 runPrompt button clicked");
      e.preventDefault(); // stop form submit

      // If voice dictation is active, stop it before submitting prompt.
      stopPromptMicrophoneCapture();

      if (isPromptRequestRunning()) {
        stopActivePromptRequest();
        return;
      }

      const promptItem = apex.item('P1_PROMPT1');
      const promptInputEl = document.getElementById("P1_PROMPT1");
      const promptRaw =
        promptItem && typeof promptItem.getValue === "function"
          ? promptItem.getValue()
          : (promptInputEl ? promptInputEl.value : "");
      const promptText = String(promptRaw || "").trim();
      if (!promptText) {
        refreshRunPromptButtonState();
        return;
      }
      document.querySelectorAll(".llm-graph-block").forEach(function (graph) {
  graph.style.display = "none";
});

      capturePendingCodeChangeRequest(promptText);

      apex.item('P1_PROMPT').setValue(promptText);
      if (promptItem && typeof promptItem.setValue === "function") {
        promptItem.setValue("");
      } else if (promptInputEl) {
        promptInputEl.value = "";
      }
      if (promptInputEl) {
        delete promptInputEl.dataset.shiftEnterExpand;
      }
      schedulePromptFreshScreenUiRefresh();
      // console.log("Prompt value:", document.getElementById("P1_PROMPT").value);
      // appendUserPrompt();
      //showLoadingUI();

      const appended = appendUserPrompt();
      if (!appended) {
        pendingCodeChangeRequest = null;
        refreshRunPromptButtonState();
        return;
      }
      const { promptId, loaderId } = appended;

      apex.item("P1_LATEST_PROMPT_ID").setValue(promptId);
      apex.item("P1_LATEST_LOADER_ID").setValue(loaderId);

      if (AUTO_SCROLL_BEFORE_RESPONSE_APPEND) {
        const promptEl = document.getElementById(promptId);
        if (promptEl) {
          setTimeout(function() {
            ensureNewPromptScrollSpacer();
            scrollPromptToTopForResponse(promptEl, { smooth: true });
            scheduleFooterScrollDownRefresh();
          }, 0);
        }
      }

      setRunPromptStopMode(true);
      userStopRequested = false;

      console.log("Triggering custom event: da-run-prompt");
      apex.event.trigger(document, "da-run-prompt");
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bindRunPromptClickHandler, { once: true });
} else {
  bindRunPromptClickHandler();
}




// Find the nearest scrollable ancestor (falls back to window)
function getScrollParent(el) {
  let p = el && el.parentElement;
  while (p) {
    const style = getComputedStyle(p);
    const canScroll = /(auto|scroll)/.test(style.overflowY) && p.scrollHeight > p.clientHeight;
    if (canScroll) return p;
    p = p.parentElement;
  }
  return window;
}

function saveAskOracleScrollState() {
  const scroller = getFooterScrollTarget();
  const state = {
    ts: Date.now(),
    winY: Math.max(0, Math.round(window.pageYOffset || document.documentElement.scrollTop || 0)),
    useWindowScroller: scroller === window,
    innerTop: scroller === window ? null : Math.max(0, Math.round(scroller.scrollTop || 0))
  };
  try {
    sessionStorage.setItem(getAskOracleScrollStateKey(), JSON.stringify(state));
    sessionStorage.setItem(getAskOracleScrollPendingKey(), "1");
  } catch (e) {}
}

function clearAskOracleScrollRestoreState() {
  try { sessionStorage.removeItem(getAskOracleScrollPendingKey()); } catch (e) {}
  try { sessionStorage.removeItem(getAskOracleScrollStateKey()); } catch (e) {}
}

function restoreAskOracleScrollStateIfPending() {
  let pending = "";
  try {
    pending = String(sessionStorage.getItem(getAskOracleScrollPendingKey()) || "");
  } catch (e) {}
  if (pending !== "1") return;

  let state = null;
  try {
    state = JSON.parse(sessionStorage.getItem(getAskOracleScrollStateKey()) || "null");
  } catch (e) {
    state = null;
  }
  if (!state || !Number.isFinite(state.ts)) {
    clearAskOracleScrollRestoreState();
    return;
  }

  if ((Date.now() - state.ts) > 120000) {
    clearAskOracleScrollRestoreState();
    return;
  }

  function applySavedScroll() {
    try {
      const winY = Number(state.winY);
      if (Number.isFinite(winY)) {
        window.scrollTo({ top: Math.max(0, winY), behavior: "auto" });
      }
    } catch (e) {}
    if (!state.useWindowScroller) {
      try {
        const scroller = getFooterScrollTarget();
        if (scroller && scroller !== window && Number.isFinite(Number(state.innerTop))) {
          scroller.scrollTop = Math.max(0, Number(state.innerTop));
        }
      } catch (e) {}
    }
  }

  [0, 80, 260, 520].forEach((delay) => {
    setTimeout(applySavedScroll, delay);
  });
  setTimeout(clearAskOracleScrollRestoreState, 1200);
}

function bindAgentTeamScrollPreserve() {
  const profileEl = document.getElementById("P1_CURRENT_AI_PROFILE");
  const teamEl = document.getElementById("P1_AGENT_TEAM");
  const agentProfileEl = document.getElementById("P1_AGENT_PROFILE");
  const targets = [profileEl, teamEl, agentProfileEl].filter(Boolean);
  if (targets.length === 0) return;

  targets.forEach((el) => {
    if (el.dataset.askOracleScrollBound === "true") return;
    el.dataset.askOracleScrollBound = "true";
    el.addEventListener("change", function() {
      var selectedAgent = String(
        (agentProfileEl && agentProfileEl.value) ||
        (teamEl && teamEl.value) ||
        ""
      ).trim();
      if (selectedAgent) {
        persistAskOracleUiSyncState({
          selected_agent_team: selectedAgent
        });
      }
      askOracleAgentTeamChanged = true;
      saveAskOracleScrollState();
    });
  });

  if (window.apex && apex.jQuery && !window.__askOracleScrollPreserveBound) {
    window.__askOracleScrollPreserveBound = true;
    apex.jQuery(document).on("change", "#P1_CURRENT_AI_PROFILE, #P1_AGENT_TEAM, #P1_AGENT_PROFILE", function() {
      var selectedAgent = String(
        apex.jQuery("#P1_AGENT_PROFILE").val() ||
        apex.jQuery("#P1_AGENT_TEAM").val() ||
        ""
      ).trim();
      if (selectedAgent) {
        persistAskOracleUiSyncState({
          selected_agent_team: selectedAgent
        });
      }
      askOracleAgentTeamChanged = true;
      saveAskOracleScrollState();
    });
    apex.jQuery(document).on("apexbeforepagesubmit", function() {
      if (!askOracleAgentTeamChanged) return;
      saveAskOracleScrollState();
    });
  }
}

function isElementActuallyVisible(el) {
  if (!el) return false;
  if (el.hidden) return false;
  const style = getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function getTopNavigationOffsetPx() {
  const selectors = [
    ".t-Header",
    "#t_Header",
    "header.t-Header",
    ".a-Header"
  ];

  let maxBottom = 0;
  selectors.forEach((selector) => {
    document.querySelectorAll(selector).forEach((el) => {
      if (!isElementActuallyVisible(el)) return;
      const style = getComputedStyle(el);
      const isOverlayHeader = style.position === "fixed" || style.position === "sticky";
      if (!isOverlayHeader) return;

      const rect = el.getBoundingClientRect();
      if (rect.bottom > maxBottom && rect.top <= rect.bottom) {
        maxBottom = rect.bottom;
      }
    });
  });

  return Math.max(0, Math.ceil(maxBottom + TOP_NAV_EXTRA_CLEARANCE_PX));
}

// Dynamically calculate extra scroll space so prompt positioning scales by screen size.
function getNewPromptScrollExtraPx(scroller = window) {
  const viewportHeight = scroller === window
    ? window.innerHeight
    : Math.max(0, scroller.clientHeight || 0);
  const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 1366;
  const topNavOffset = getTopNavigationOffsetPx();

  let ratio;
  if (viewportWidth >= 2200) ratio = 0.72;
  else if (viewportWidth >= 1700) ratio = 0.66;
  else if (viewportWidth >= 1300) ratio = 0.60;
  else if (viewportWidth >= 992) ratio = 0.54;
  else ratio = 0.46;

  const minPx = 180;
  const maxPx = Math.max(minPx, Math.round(viewportHeight * 0.85));
  const preferred = Math.round((viewportHeight * ratio) - topNavOffset);

  return Math.max(minPx, Math.min(maxPx, preferred));
}

// Scroll the correct scroller to bottom after layout settles
function scrollToEndFor(el, { smooth = true, offset = 0 } = {}) {
  if (!el) return;
  const scroller = getScrollParent(el);

  // wait for layout/paint so heights are correct
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      if (scroller === window) {
        const h = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
        window.scrollTo({ top: h - offset, behavior: smooth ? "smooth" : "auto" });
      } else {
        scroller.scrollTo({ top: scroller.scrollHeight - offset, behavior: smooth ? "smooth" : "auto" });
      }
    });
  });
}

function ensureNewPromptScrollSpacer() {
  const container = getChatContainer();
  if (!container) return null;
  const scroller = getScrollParent(container);
  const extraScroll = getNewPromptScrollExtraPx(scroller);

  let spacer = document.getElementById(NEW_PROMPT_SCROLL_SPACER_ID);
  if (!spacer) {
    spacer = document.createElement("div");
    spacer.id = NEW_PROMPT_SCROLL_SPACER_ID;
    spacer.setAttribute("aria-hidden", "true");
    spacer.style.width = "100%";
    container.insertAdjacentElement("beforeend", spacer);
  } else {
    container.insertAdjacentElement("beforeend", spacer);
  }

  spacer.style.height = `${Math.max(0, extraScroll)}px`;
  return spacer;
}

function removeNewPromptScrollSpacer() {
  const spacer = document.getElementById(NEW_PROMPT_SCROLL_SPACER_ID);
  if (spacer) spacer.remove();
}

// Keep the newly submitted prompt near the top of the view so response has room below.
function scrollPromptToTopForResponse(el, { smooth = true } = {}) {
  if (!el) return;
  const scroller = getScrollParent(el);
  const viewportSafeTop = Math.max(NEW_PROMPT_TOP_OFFSET_PX, getTopNavigationOffsetPx()) + NEW_PROMPT_VISUAL_DOWN_SHIFT_PX;

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      if (scroller === window) {
        const currentTop = window.pageYOffset || document.documentElement.scrollTop || 0;
        const rect = el.getBoundingClientRect();
        const maxTop = Math.max(
          0,
          Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) - window.innerHeight
        );
        // Anchor prompt just below top navigation. Spacer already provides extra room below.
        const targetTop = Math.min(maxTop, Math.max(0, currentTop + rect.top - viewportSafeTop));
        window.scrollTo({ top: targetTop, behavior: smooth ? "smooth" : "auto" });
      } else {
        const scrollerRect = scroller.getBoundingClientRect();
        const rect = el.getBoundingClientRect();
        const currentTop = scroller.scrollTop;
        const safeTopInsideScroller = Math.max(
          NEW_PROMPT_TOP_OFFSET_PX,
          viewportSafeTop - scrollerRect.top
        );
        const relativeTop = currentTop + (rect.top - scrollerRect.top);
        const maxTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
        // Anchor prompt just below top navigation. Spacer already provides extra room below.
        const targetTop = Math.min(maxTop, Math.max(0, relativeTop - safeTopInsideScroller));
        scroller.scrollTo({ top: targetTop, behavior: smooth ? "smooth" : "auto" });
      }
    });
  });
}



// Unified getter for your chat container
function getChatContainer() {
  return document.querySelector("#PROMPTS .prompt-list") || document.getElementById("PROMPTS");
}



// Helper to escape HTML special chars
function escapeHtml(text) {
  if (!text) return "";
  return text.replace(/[&<>"']/g, function(m) {
    return ({
      '&': "&amp;",
      '<': "&lt;",
      '>': "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[m];
  });
}



// Global map to track prompt texts by their temporary frontend IDs
window.pendingPrompts = window.pendingPrompts || {};
window.askOraclePerfTracker = window.askOraclePerfTracker || { active: null, runs: {} };

function askOraclePerfNowMs() {
  return (window.performance && typeof window.performance.now === "function")
    ? window.performance.now()
    : Date.now();
}

function askOraclePerfRoundMs(value) {
  const n = Number(value);
  if (!isFinite(n)) return null;
  return Math.round(n * 100) / 100;
}

function askOraclePerfStartRun(runId, meta) {
  const id = String(runId || "").trim();
  if (!id) return null;
  const startedAt = askOraclePerfNowMs();
  const ctx = {
    runId: id,
    startedAt,
    meta: meta && typeof meta === "object" ? meta : {},
    marks: { runPromptAsync_start: startedAt }
  };
  window.askOraclePerfTracker.runs[id] = ctx;
  window.askOraclePerfTracker.active = ctx;
  console.log("[ASK_ORACLE_PERF] run started", { runId: id, meta: ctx.meta });
  return ctx;
}

function askOraclePerfGetActiveRun() {
  const tracker = window.askOraclePerfTracker || {};
  const active = tracker.active;
  if (active && active.runId && tracker.runs && tracker.runs[active.runId]) return tracker.runs[active.runId];
  return null;
}

function askOraclePerfMark(stage, extra) {
  const ctx = askOraclePerfGetActiveRun();
  if (!ctx) return;
  const now = askOraclePerfNowMs();
  ctx.marks[stage] = now;
  console.log("[ASK_ORACLE_PERF] mark", {
    runId: ctx.runId,
    stage,
    elapsedMsFromStart: askOraclePerfRoundMs(now - ctx.startedAt),
    extra: extra && typeof extra === "object" ? extra : {}
  });
}

function askOraclePerfFinishRun(status, extra) {
  const ctx = askOraclePerfGetActiveRun();
  if (!ctx) return;
  const now = askOraclePerfNowMs();
  ctx.marks.run_finished = now;
  const marks = ctx.marks || {};
  const summary = {
    runId: ctx.runId,
    status: String(status || "unknown"),
    totalMs: askOraclePerfRoundMs(now - ctx.startedAt),
    executePromptMs: (marks.execute_prompt_end && marks.execute_prompt_start)
      ? askOraclePerfRoundMs(marks.execute_prompt_end - marks.execute_prompt_start)
      : null,
    fetchLatestRowMs: (marks.get_latest_row_end && marks.get_latest_row_start)
      ? askOraclePerfRoundMs(marks.get_latest_row_end - marks.get_latest_row_start)
      : null,
    renderResponseMs: (marks.response_render_end && marks.response_render_start)
      ? askOraclePerfRoundMs(marks.response_render_end - marks.response_render_start)
      : null,
    extra: extra && typeof extra === "object" ? extra : {}
  };
  console.log("[ASK_ORACLE_PERF] run finished", summary);
  window.askOraclePerfTracker.active = null;
}

// Helper: Normalize prompt text by trimming and collapsing whitespace (incl newlines)
function normalizePromptText(text) {
  return text
    .trim()
    .replace(/\s+/g, ' ')  // Replace all whitespace sequences with a single space
    .toLowerCase();        // Optional: lowercase for case-insensitive matching
}

//Show loader by ID or default region
function showLoadingUI(loaderId) {
  promptInput.disabled = true;
  runButton.disabled = true;

  if (loaderId) {
    const el = document.getElementById(loaderId);
    if (el) {
      applyGeminiProcessingIndicator(el);
      el.style.display = "flex";
    }
  } else {
    const loaderRegion = document.querySelector("#LOADER_REGION");
    if (loaderRegion) loaderRegion.style.display = "block";
    const defaultLoader = document.querySelector("#loading-indicator");
    if (defaultLoader) {
      applyGeminiProcessingIndicator(defaultLoader);
      defaultLoader.style.display = "flex";
    }
  }
  refreshRunPromptButtonState();
}


// Hide loader by ID or default region
function hideLoadingUI(loaderId) {
  promptInput.disabled = false;
  runButton.disabled = false;

  if (loaderId) {
    const el = document.getElementById(loaderId);
    if (el) el.style.display = "none";
  } else {
    const defaultLoader = document.querySelector("#loading-indicator");
    const loaderRegion = document.querySelector("#LOADER_REGION");
    if (defaultLoader) defaultLoader.style.display = "none";
    if (loaderRegion) loaderRegion.style.display = "none";
  }
  refreshRunPromptButtonState();
}

function clearAskOracleProcessingIndicators(promptId, responseId) {
  const normalizedPromptId = String(promptId || "").trim().replace(/^prompt-/, "");
  const normalizedResponseId = String(responseId || "").trim().replace(/^response-/, "");
  const candidateIds = [
    normalizedPromptId ? `loading-indicator-${normalizedPromptId}` : "",
    normalizedResponseId ? `loading-indicator-${normalizedResponseId}` : "",
    String($v("P1_LATEST_LOADER_ID") || "").trim(),
    "loading-indicator"
  ].filter(Boolean);
  const seen = new Set();

  candidateIds.forEach(function(loaderId) {
    if (seen.has(loaderId)) return;
    seen.add(loaderId);
    hideLoadingUI(loaderId);
  });

  hideLoadingUI();
}


// Use event delegation for dynamically added buttons
document.addEventListener("click", function(e) {
  const btn = e.target.closest(".copy-btn");
  if (!btn) return;

  e.preventDefault(); // prevent form submit

  // find the message bubble relative to the clicked button
  const bubble = btn.parentElement.querySelector(".message-bubble");
  if (!bubble) return;

  const text = bubble.textContent || bubble.innerText;

  navigator.clipboard.writeText(text).then(() => {
    btn.innerHTML = getAskOracleInlineSvgIcon("check");
    setTimeout(() => {
      btn.innerHTML = getAskOracleInlineSvgIcon("copy");
    }, 1500);
  }).catch(err => {
    console.error("Copy failed:", err);
  });
});





function appendUserPrompt() {
  let promptText = apex.item("P1_PROMPT").getValue().trim();
  if (!promptText) return;
  const conversationStyle = getAskOracleCurrentConversationMode();
  const isUserAgentsPrompt = conversationStyle === "USER_AGENTS";

  // First submit switches prompt bar from centered mode to footer mode.
  setPromptBarMode("footer");

  // ✅ Generate a unique prompt ID
  let promptId = "prompt-local-" + Date.now();

  // ✅ Store prompt text in pendingPrompts
  window.pendingPrompts[promptId] = normalizePromptText(promptText);

  // ✅ Escape HTML and replace newlines with <br>
  const safePromptText = escapeHtml(promptText).replace(/\n/g, "<br>");

    const template = `
    <div style="height:9px; width:100%;" aria-hidden="true"></div>
    <div class="chat-message user-message" id="${promptId}" style="padding-top: 16px; position: relative;">
        <div class="message-bubble">${safePromptText}</div>
        <button type="button" class="copy-btn">
        ${getAskOracleInlineSvgIcon("copy")}
        </button>
    </div>
    `;

  let loaderId = null;

  // ✅ Find container to insert the prompt
  const container =
    document.querySelector("#PROMPTS .prompt-list") ||
    document.getElementById("PROMPTS");

  if (container) {
    container.insertAdjacentHTML("beforeend", template);

    // ✅ Add loader after the prompt
    const promptEl = document.getElementById(promptId);
    if (promptEl) {
      const loaderRegion = document.getElementById("loading-indicator");
      if (loaderRegion && !isUserAgentsPrompt) {
        const loaderClone = loaderRegion.cloneNode(true);
        loaderClone.style.display = "flex";
        loaderId = "loading-indicator-" + promptId;
        loaderClone.id = loaderId;
        promptEl.insertAdjacentElement("afterend", loaderClone);
        showLoadingUI(loaderId);
      }
    }

    if (AUTO_SCROLL_BEFORE_RESPONSE_APPEND) {
      // Add temporary space so old conversation can move up for a fresh-screen feel.
      ensureNewPromptScrollSpacer();

      // Keep the new prompt near top so the response can stream below it.
      scrollPromptToTopForResponse(promptEl, { smooth: true });
    }
    scheduleFooterScrollDownRefresh();
  }

  // ✅ Store prompt in localStorage
  let existingPrompts = [];
  try {
    existingPrompts = parseAskOracleJsonArraySafe(localStorage.getItem("chat_prompts"));
  } catch (e) {
    existingPrompts = [];
  }
  existingPrompts.push({ id: promptId, text: promptText });
  localStorage.setItem("chat_prompts", JSON.stringify(existingPrompts));

  // Reset prompt box height after submit so it returns to the base size.
  resetPromptInputHeight();

  return { promptId, loaderId };
}




var cnt = 0;

function scrollToLast(){
    if ($(".prompt-box").length > 0 && cnt == $(".prompt-box").length){
         $([document.documentElement, document.body]).animate({
        scrollTop: $('.prompt-box').last().offset().top-120
    }, 2000);
    }
}

//To print the data in table format.
function convertMarkdownTableToHTML(md) {
  const lines = md.split('\n');
  let tableStarted = false;
  let html = '';

  lines.forEach((line) => {
    if (line.trim().startsWith('|')) {
      const cells = line.split('|').slice(1, -1).map(c => c.trim());
      
      if (!tableStarted) {
        html += '<table style="border-collapse: collapse; width: 100%; margin: 0.5rem 0;">';
        html += '<thead><tr>';
        cells.forEach(cell => {
          html += `<th style="border: 1px solid #ddd; padding: 6px; text-align: left;">${cell}</th>`;
        });
        html += '</tr></thead><tbody>';
        tableStarted = true;
      } else if (!line.includes('---')) {
        html += '<tr>';
        cells.forEach(cell => {
          html += `<td style="border: 1px solid #ddd; padding: 6px;">${cell}</td>`;
        });
        html += '</tr>';
      }
    } else if (tableStarted) {
      html += '</tbody></table>';
      tableStarted = false;
      html += line + '\n'; // append the normal text after table
    } else {
      html += line + '\n';
    }
  });

  if (tableStarted) html += '</tbody></table>'; // close table if last line
  return html;
}


function renderLLMResponseWithHTML(el, htmlContent, onComplete) {
    // Clear existing content
    el.innerHTML = "";

    // Create a temporary container to parse HTML
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = htmlContent;

    // Move all non-script nodes into the actual container
    Array.from(tempDiv.childNodes).forEach(node => {
        if (node.tagName !== "SCRIPT") {
            el.appendChild(node);
        }
    });

    // Execute safe scripts only
    Array.from(tempDiv.querySelectorAll("script")).forEach(oldScript => {
        const srcText = String(oldScript.getAttribute("src") || oldScript.src || "").toLowerCase();
        const inlineText = String(oldScript.textContent || "").toLowerCase();
        if (srcText.includes("chartjs-plugin-funnel") || inlineText.includes("chartjs-plugin-funnel")) {
            console.warn("[ASK_ORACLE] blocked chartjs-plugin-funnel script from response payload");
            return;
        }

        const newScript = document.createElement("script");
        if (oldScript.src) {
            newScript.src = oldScript.src; // external script
        } else {
            newScript.textContent = oldScript.textContent; // inline script
        }
        document.body.appendChild(newScript);
        setTimeout(() => {
            try { document.body.removeChild(newScript); } catch (e) {}
        }, 0);
    });
}

  // Markdown Table → HTML (unchanged)
  function convertMarkdownTableToHTML(md) {
    const lines = md.split('\n');
    let tableStarted = false;
    let html = '';

    lines.forEach((line) => {
      if (line.trim().startsWith('|')) {
        const cells = line.split('|').slice(1, -1).map(c => c.trim());

        if (!tableStarted) {
          html += '<table style="border-collapse: collapse; width: 100%; margin: 0.5rem 0;">';
          html += '<thead><tr>';
          cells.forEach(cell => {
            html += `<th style="border: 1px solid #ddd; padding: 6px; text-align: left;">${cell}</th>`;
          });
          html += '</tr></thead><tbody>';
          tableStarted = true;
        } else if (!line.includes('---')) {
          html += '<tr>';
          cells.forEach(cell => {
            html += `<td style="border: 1px solid #ddd; padding: 6px;">${cell}</td>`;
          });
          html += '</tr>';
        }
      } else if (tableStarted) {
        html += '</tbody></table>';
        tableStarted = false;
        html += line + '\n';
      } else {
        html += line + '\n';
      }
    });

    if (tableStarted) html += '</tbody></table>';
    return html;
  }



//   function typeWriterSmart(el, html, speed, onComplete) {
//     let parser = new DOMParser();
//     let doc = parser.parseFromString(html, "text/html");
//     let nodes = Array.from(doc.body.childNodes);
//     let index = 0;

//     function scrollToBottom() {
//       el.scrollTop = el.scrollHeight;
//     }


//     function typeNode(node, container, callback) {
//       if (node.nodeType === Node.TEXT_NODE) {
//         let text = node.nodeValue;
//         let i = 0;
//         let textNode = document.createTextNode('');
//         container.appendChild(textNode);

//         function typeText() {
//           if (i < text.length) {
//             textNode.nodeValue += text.charAt(i);
//             scrollToBottom();
//             i++;
//             setTimeout(typeText, speed);
//           } else callback();
//         }
//         typeText();
//       } else if (node.nodeType === Node.ELEMENT_NODE) {
//         let tag = document.createElement(node.nodeName.toLowerCase());
//         for (let attr of node.attributes) tag.setAttribute(attr.name, attr.value);
//         container.appendChild(tag);

//         let childNodes = Array.from(node.childNodes);
//         let childIndex = 0;
//         function nextChild() {
//           if (childIndex < childNodes.length) {
//             typeNode(childNodes[childIndex], tag, () => {
//               childIndex++;
//               nextChild();
//             });
//           } else callback();
//         }
//         nextChild();
//       } else callback();
//     }

//     function nextNode() {
//       if (index < nodes.length) {
//         typeNode(nodes[index], el, () => {
//           index++;
//           nextNode();
//         });
//       } else askOraclePerfMark("response_finalize_end", { id });
//     }

//     nextNode();
// }


function typeWriterSmart(el, html, speed = 10, onComplete, onProgress) {
  // Parse the HTML into a DOM tree
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  let lastProgressAt = 0;

  function emitProgress(force = false) {
    if (typeof onProgress !== "function") return;
    const now = Date.now();
    if (!force && now - lastProgressAt < 120) return;
    lastProgressAt = now;
    onProgress(el);
  }

  // Recursive typing for any DOM node
  function typeNode(node, container, done) {
    if (node.nodeType === Node.TEXT_NODE) {
      // Typing text nodes character-by-character
      const text = node.nodeValue || "";
      const textNode = document.createTextNode("");
      container.appendChild(textNode);

      let i = 0;
      function typeChar() {
        if (i < text.length) {
          textNode.nodeValue += text.charAt(i);
          container.scrollTop = container.scrollHeight; // auto-scroll
          emitProgress();
          i++;
          setTimeout(typeChar, speed);
        } else {
          emitProgress(true);
          done && done();
        }
      }
      typeChar();

    } else if (node.nodeType === Node.ELEMENT_NODE) {
      // Create element and type its children
      const newEl = document.createElement(node.nodeName.toLowerCase());
      for (let attr of node.attributes) newEl.setAttribute(attr.name, attr.value);
      container.appendChild(newEl);
      emitProgress();

      const children = Array.from(node.childNodes);
      typeChildren(children, newEl, done);

    } else {
      done && done();
    }
  }

  // Recursive traversal through a list of nodes
  function typeChildren(nodes, container, done) {
    let index = 0;
    function next() {
      if (index < nodes.length) {
        typeNode(nodes[index], container, () => {
          index++;
          next();
        });
      } else {
        emitProgress(true);
        done && done();
      }
    }
    next();
  }

  // Start typing everything in <body>
  const bodyNodes = Array.from(doc.body.childNodes);
  el.innerHTML = ""; // clear previous content
  emitProgress(true);
  typeChildren(bodyNodes, el, onComplete);
}


// ---------------------------
// Global sanitizeJsonLikeString helper
// ---------------------------
function sanitizeJsonLikeString(s) {
  if (!s || typeof s !== "string") return s;
  let t = s.trim();

  // Remove any leading code fence like ```chartjs
  t = t.replace(/^```(?:chartjs|json)?\s*/i, '').replace(/```$/i, '');

  // Strip anything before the first JSON object/array.
  const firstObject = t.indexOf("{");
  const firstArray = t.indexOf("[");
  const first =
    firstObject === -1 ? firstArray :
    firstArray === -1 ? firstObject :
    Math.min(firstObject, firstArray);
  if (first > 0) t = t.substring(first);

  // Remove trailing commas before } or ]
  t = t.replace(/,\s*(?=[}\]])/g, '');

  // Balance braces and brackets
  const opensBrace = (t.match(/{/g) || []).length;
  const closesBrace = (t.match(/}/g) || []).length;
  const opensSq = (t.match(/\[/g) || []).length;
  const closesSq = (t.match(/]/g) || []).length;

  if (closesBrace < opensBrace) {
    t = t + "}".repeat(opensBrace - closesBrace);
    console.log(`sanitizeJsonLikeString: added ${opensBrace - closesBrace} missing '}'`);
  }
  if (closesSq < opensSq) {
    t = t + "]".repeat(opensSq - closesSq);
    console.log(`sanitizeJsonLikeString: added ${opensSq - closesSq} missing ']'`);
  }

  return t;
}

function normalizeJsObjectLiteralJsonCompat(rawText) {
  if (!rawText || typeof rawText !== "string") return rawText;
  let t = rawText;

  // Remove JS comments that can break JSON.parse
  t = t.replace(/\/\*[\s\S]*?\*\//g, "");
  t = t.replace(/(^|[^\:])\/\/.*$/gm, "$1");

  // JSON doesn't support undefined.
  t = t.replace(/:\s*undefined\b/g, ": null");

  // Convert function-valued properties into string literals so reviveFunctions can restore them later.
  t = t.replace(
    /:\s*function\s*\(([^)]*)\)\s*\{([\s\S]*?)\}(?=\s*[,}\]])/g,
    function(_m, args, body) {
      const fnText = `function(${String(args || "").trim()}){${String(body || "")}}`;
      return ": " + JSON.stringify(fnText);
    }
  );

  t = t.replace(
    /:\s*\(([^)]*)\)\s*=>\s*\{([\s\S]*?)\}(?=\s*[,}\]])/g,
    function(_m, args, body) {
      const fnText = `(${String(args || "").trim()}) => {${String(body || "")}}`;
      return ": " + JSON.stringify(fnText);
    }
  );

  t = t.replace(
    /:\s*([A-Za-z_$][\w$]*)\s*=>\s*([^,\]}]+)(?=\s*[,}\]])/g,
    function(_m, arg, expr) {
      const fnText = `${String(arg || "").trim()} => ${String(expr || "").trim()}`;
      return ": " + JSON.stringify(fnText);
    }
  );

  return t;
}


function tryParseJsonRobust(raw) {
    if (!raw) throw new Error("No JSON content provided to parser");

    // 1. raw attempt
    try { return JSON.parse(raw); } catch (e1) {}

    // 2. sanitized attempt
    let sanitized = sanitizeJsonLikeString(raw);
    try { return JSON.parse(sanitized); } catch (e2) {}

    // 2b. JS-object compatibility normalization (function values, comments, undefined)
    sanitized = normalizeJsObjectLiteralJsonCompat(sanitized);
    try { return JSON.parse(sanitized); } catch (e2b) {}

    // 3. cut at last object/array close then parse
    const lastCloseBrace = sanitized.lastIndexOf("}");
    const lastCloseBracket = sanitized.lastIndexOf("]");
    const lastClose = Math.max(lastCloseBrace, lastCloseBracket);
    if (lastClose !== -1) {
    const cut = sanitized.substring(0, lastClose + 1);
    try { return JSON.parse(cut); } catch (e3) {}
    }

    // 4. final attempts
    sanitized = sanitized.replace(/,\s*(?=[}\]])/g, '');
    const opensBrace = (sanitized.match(/{/g) || []).length;
    const closesBrace = (sanitized.match(/}/g) || []).length;
    const opensSq = (sanitized.match(/\[/g) || []).length;
    const closesSq = (sanitized.match(/]/g) || []).length;
    if (closesBrace < opensBrace) sanitized += "}".repeat(opensBrace - closesBrace);
    if (closesSq < opensSq) sanitized += "]".repeat(opensSq - closesSq);
    try { return JSON.parse(sanitized); } catch (finalErr) {
    finalErr.message = finalErr.message + " | attempted sanitized JSON preview: " + (sanitized.length > 1000 ? sanitized.slice(0,1000) + "..." : sanitized);
    throw finalErr;
    }
}


// -------------------------
// reviveFunctions: convert stringified function bodies into real JS functions
// -------------------------
function reviveFunctions(obj) {
    const fnRegex = /^\s*function\s*\(([^)]*)\)\s*\{([\s\S]*)\}\s*$/m;
    const arrowBlockRegex = /^\s*\(?([^)]*)\)?\s*=>\s*\{([\s\S]*)\}\s*$/m;
    const arrowExprRegex = /^\s*\(?([^)]*)\)?\s*=>\s*([^{};]+)\s*$/m;

    function revive(value) {
    if (typeof value === 'string') {
        let m;
        if ((m = value.match(fnRegex))) {
        const args = m[1].trim();
        const body = m[2];
        try {
            const argList = args ? args.split(',').map(a => a.trim()) : [];
            return Function(...argList.concat([body]));
        } catch (e) {
            console.warn("reviveFunctions: failed to revive function string (fn):", e, value);
            return value;
        }
        }
        if ((m = value.match(arrowBlockRegex))) {
        const args = m[1].trim();
        const body = m[2];
        try {
            const argList = args ? args.split(',').map(a => a.trim()) : [];
            return Function(...argList.concat([body]));
        } catch (e) {
            console.warn("reviveFunctions: failed to revive arrow-block fn:", e, value);
            return value;
        }
        }
        if ((m = value.match(arrowExprRegex))) {
        const args = m[1].trim();
        const expr = m[2];
        try {
            const argList = args ? args.split(',').map(a => a.trim()) : [];
            return Function(...argList.concat([ 'return (' + expr + ');' ]));
        } catch (e) {
            console.warn("reviveFunctions: failed to revive arrow-expr fn:", e, value);
            return value;
        }
        }
        return value;
    } else if (Array.isArray(value)) {
        return value.map(revive);
    } else if (value && typeof value === 'object') {
        const out = Array.isArray(value) ? [] : {};
        for (const k of Object.keys(value)) {
        out[k] = revive(value[k]);
        }
        return out;
    } else {
        return value;
    }
    }

    return revive(obj);
}

// helper to escape HTML for UI messages
function escapeHtml(str) {
    if (!str) return "";
    return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}


function postProcessResponse(el) {
  let html = el.innerText;
  html = html.replace(/^\s*---+\s*$/gm, "");

  // Markdown headings
  html = html.replace(/^\s*(#{1,6})\s+(.+)$/gm, function(_match, hashes, text) {
    var headingLevel = Math.min(3, String(hashes || "").length);
    return '<div class="llm-md-h' + headingLevel + '">' + text + '</div>';
  });
  // Add separation before a heading only; content follows it immediately.
  html = html.replace(/(?:\r?\n[ \t]*)*(<div class="llm-md-h[123]">[\s\S]*?<\/div>)(?:[ \t]*\r?\n)*/g, '\n\n$1');
  html = html.replace(/^\n+/, "");

  // Bold
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  // Links
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, `<a href="$2" target="_blank">$1</a>`);
  html = html.replace(/(^|[^"'>])(https?:\/\/[^\s<]+)/g, '$1<a href="$2" target="_blank" rel="noopener noreferrer">$2</a>');

  // Convert Markdown tables → HTML
  html = convertMarkdownTableToHTML(html);

  el.innerHTML = html;
  ensureResponseTableInlineActionsForElement(el);
}

function isRagConversationStyleActive() {
  const styleValue = String(getAskOracleCurrentConversationMode() || "").trim().toUpperCase();
  if (!styleValue) return false;
  return styleValue === "RAG_PROFILES" || styleValue === "RAG" || styleValue.indexOf("RAG") >= 0;
}

function isNl2SqlConversationStyleActive() {
  const styleValue = String(getAskOracleCurrentConversationMode() || "").trim().toUpperCase();
  if (!styleValue) return false;
  return styleValue === "CHAT_WITH_DB" || styleValue === "NL2SQL" || styleValue.indexOf("CHAT_WITH_DB") >= 0;
}

function isUserAgentsConversationStyleActive() {
  const styleValue = String(getAskOracleCurrentConversationMode() || "").trim().toUpperCase();
  if (!styleValue) return false;
  return styleValue === "USER_AGENTS" || styleValue === "AGENT" || styleValue.indexOf("USER_AGENTS") >= 0;
}

function parseAgentLabelSuffix(rawProfileName) {
  const text = String(rawProfileName || "").trim();
  if (!/^AGENT\s*\|/i.test(text)) return "";
  const suffix = text.replace(/^AGENT\s*\|\s*/i, "").trim();
  if (!suffix || /^PROFILE_DROPPED$/i.test(suffix)) return "";
  return suffix;
}

function getPreferredAgentTeamName(latestRow) {
  const rowAgentSuffix = parseAgentLabelSuffix(latestRow && latestRow.profile_name);
  const currentProfile = String($v("P1_CURRENT_AI_PROFILE") || "").trim();
  const candidates = [
    String($v("P1_AGENT_PROFILE") || "").trim(),
    String($v("P1_AGENT_TEAM") || "").trim(),
    rowAgentSuffix,
    /^AGENT\s*\|/i.test(currentProfile) ? currentProfile : ""
  ];
  for (let i = 0; i < candidates.length; i += 1) {
    const value = candidates[i];
    if (!value) continue;
    return value.replace(/\s*\|\s*.*$/, "").trim();
  }
  return "";
}

function shouldAttemptAgentAutoVisual(latestRow) {
  return getAgentAutoVisualAttemptDecision(latestRow).shouldAttempt;
}

function getAgentAutoVisualAttemptDecision(latestRow) {
  const conversationStyle = String(getAskOracleCurrentConversationMode() || "").trim();
  const conversationStyleNormalized = conversationStyle.toUpperCase();
  const styleIsUserAgents = isUserAgentsConversationStyleActive();

  if (!latestRow) {
    return {
      shouldAttempt: false,
      reason: "missing-latest-row",
      conversationStyle,
      conversationStyleNormalized,
      responseType: "",
      profileName: "",
      promptLength: 0
    };
  }

  const responseType = String(latestRow.response_type || "").trim();
  const responseTypeNormalized = responseType.toUpperCase();
  const profileName = String(latestRow.profile_name || "").trim();
  const profileNameNormalized = profileName.toUpperCase();
  const rowLooksLikeAgent = profileNameNormalized.startsWith("AGENT");
  const hasValidAgentSuffix = !!parseAgentLabelSuffix(profileName);
  const promptText = String(latestRow.prompt || "").trim();

  if (!styleIsUserAgents && !rowLooksLikeAgent) {
    return {
      shouldAttempt: false,
      reason: "conversation-style-not-user-agents",
      conversationStyle,
      conversationStyleNormalized,
      responseType,
      profileName,
      promptLength: promptText.length
    };
  }
  if (responseTypeNormalized !== "CHAT") {
    return {
      shouldAttempt: false,
      reason: "response-type-not-chat",
      conversationStyle,
      conversationStyleNormalized,
      responseType,
      profileName,
      promptLength: promptText.length
    };
  }
  if (!rowLooksLikeAgent && !styleIsUserAgents) {
    return {
      shouldAttempt: false,
      reason: "profile-not-agent",
      conversationStyle,
      conversationStyleNormalized,
      responseType,
      profileName,
      promptLength: promptText.length
    };
  }
  if (!promptText) {
    return {
      shouldAttempt: false,
      reason: "prompt-empty",
      conversationStyle,
      conversationStyleNormalized,
      responseType,
      profileName,
      promptLength: 0
    };
  }

  return {
    shouldAttempt: true,
    reason: hasValidAgentSuffix ? "ok" : "ok-agent-fallback",
    conversationStyle,
    conversationStyleNormalized,
    responseType,
    profileName,
    promptLength: promptText.length
  };
}

function stripCodeFence(rawText) {
  let value = String(rawText || "").trim();
  if (!value) return "";
  value = value.replace(/^```[a-z0-9_+-]*\s*/i, "");
  value = value.replace(/\s*```$/, "");
  return value.trim();
}

function isSourcesSectionHeading(lineText) {
  const text = String(lineText || "").trim();
  return /^(#{1,6}\s*)?sources\s*:?\s*$/i.test(text) || /^\*\*sources:?\*\*$/i.test(text);
}

function isLikelySectionHeading(lineText) {
  const text = String(lineText || "").trim();
  if (!text) return false;
  return /^(#{1,6}\s+\S.*|\*\*[^*]+\*\*:?\s*|[A-Z][A-Za-z0-9 /_-]{1,40}:\s*)$/i.test(text);
}

function lineHasDashboardLink(lineText) {
  const text = String(lineText || "");
  if (!text.trim()) return false;
  return /(\[[^\]]+\]\([^)]+(?:dashboard|f\?p=|\/ords\/r\/|\/apex\/)[^)]+\)|https?:\/\/[^\s<)]*(?:dashboard|f\?p=|\/ords\/r\/|\/apex\/)[^\s<)]*)/i.test(text);
}

function sanitizeDashboardResponseText(rawText) {
  let text = String(rawText || "");
  if (!text.trim()) return text;

  text = text
    .replace(/\[([^\]]+)\]\(([^)]+)\)/gi, function(match, label, url) {
      return /(dashboard|f\?p=|\/ords\/r\/|\/apex\/)/i.test(`${label} ${url}`) ? "" : match;
    })
    .replace(/https?:\/\/[^\s<)]+/gi, function(match) {
      return /(dashboard|f\?p=|\/ords\/r\/|\/apex\/)/i.test(match) ? "" : match;
    });

  const lines = text.split(/\r?\n/);
  const output = [];
  let inSources = false;
  let sourcesHeading = "";
  let sourcesLines = [];

  function flushSources() {
    if (!inSources) return;
    const keptLines = sourcesLines.filter((line) => !lineHasDashboardLink(line));
    const hasContent = keptLines.some((line) => String(line || "").trim());
    if (hasContent) {
      output.push(sourcesHeading);
      output.push(...keptLines);
    }
    inSources = false;
    sourcesHeading = "";
    sourcesLines = [];
  }

  lines.forEach((line) => {
    if (isSourcesSectionHeading(line)) {
      flushSources();
      inSources = true;
      sourcesHeading = line;
      sourcesLines = [];
      return;
    }
    if (inSources && isLikelySectionHeading(line)) {
      flushSources();
      output.push(line);
      return;
    }
    if (inSources) {
      sourcesLines.push(line);
      return;
    }
    output.push(line);
  });
  flushSources();

  text = output.join("\n");
  text = text.replace(/^\s*For more details,\s*check these inbuilt dashboards\.\s*$/gim, "");
  return text.replace(/\n{3,}/g, "\n\n").trim();
}

function formatAgentAutoVisualBlock(visualType, visualPayload) {
  const payload = stripCodeFence(visualPayload);
  if (!payload) return "";

  const type = String(visualType || "").trim().toLowerCase();
  if (type === "chartjs" || type === "chart") {
    return `\`\`\`chartjs\n${payload}\n\`\`\``;
  }
  if (type === "mermaid" || type === "graph") {
    return `\`\`\`mermaid\n${payload}\n\`\`\``;
  }
  if (type === "html_tree" || type === "html") {
    return `\`\`\`html\n${payload}\n\`\`\``;
  }
  return "";
}

function responseAlreadyHasRenderableVisual(responseText) {
  const text = String(responseText || "");
  if (!text.trim()) return false;
  if (/```(chartjs|mermaid)\b/i.test(text)) return true;
  if (/```json\b[\s\S]*?(\"type\"\s*:|\"datasets\"\s*:)/i.test(text)) return true;
  if (/"chart"\s*:\s*\{[\s\S]*?("x_axis"\s*:|"y_axis"\s*:|"type"\s*:)/i.test(text)) return true;
  if (
    /"type"\s*:\s*"(bar|line|pie|doughnut|radar|scatter|bubble|polararea|boxplot|sunburst|heatmap|bar_race|treemap|sankey|gauge|kpi_card|gantt|candlestick|ohlc|waterfall|calendar_heatmap|streamgraph|themeriver|network_graph|chord|column|grouped_bar|stacked_bar|histogram)"/i.test(text) &&
    /"data"\s*:\s*\{[\s\S]*?"(labels|datasets)"\s*:/i.test(text)
  ) {
    return true;
  }
  try {
    const parsed = tryParseJsonRobust(text);
    const cfg = coerceRenderableChartConfig(parsed);
    if (cfg) return true;
  } catch (e) {}
  if (/<div[^>]*class\s*=\s*["'][^"']*\b(db-tree|tree)\b/i.test(text)) return true;
  return false;
}

function queueAgentAutoVisualPayload(promptId, payloadData) {
  const key = String(promptId || "").trim();
  if (!key) return;
  agentAutoVisualByPromptId[key] = payloadData || null;
}

function consumeAgentAutoVisualPayload(promptId) {
  const key = String(promptId || "").trim();
  if (!key || !Object.prototype.hasOwnProperty.call(agentAutoVisualByPromptId, key)) return null;
  const payloadData = agentAutoVisualByPromptId[key];
  delete agentAutoVisualByPromptId[key];
  return payloadData;
}

function clearAgentAutoVisualPayload(promptId) {
  const key = String(promptId || "").trim();
  if (!key) return;
  if (Object.prototype.hasOwnProperty.call(agentAutoVisualByPromptId, key)) {
    delete agentAutoVisualByPromptId[key];
  }
}

function shouldUseStoredAutoVisualResponse() {
  return true;
}

function releasePromptInputAfterAutoVisual() {
  try {
    if (typeof promptInput !== "undefined" && promptInput) {
      promptInput.disabled = false;
    }
    if (typeof runButton !== "undefined" && runButton) {
      runButton.disabled = false;
    }
    if (typeof refreshRunPromptButtonState === "function") {
      refreshRunPromptButtonState();
    }

    const inputEl = document.getElementById("P1_PROMPT1") || (typeof promptInput !== "undefined" ? promptInput : null);
    if (inputEl) {
      setTimeout(function() {
        try { inputEl.focus({ preventScroll: true }); } catch (e) { try { inputEl.focus(); } catch (ignore) {} }
        try {
          const len = String(inputEl.value || "").length;
          inputEl.selectionStart = len;
          inputEl.selectionEnd = len;
        } catch (ignoreSel) {}
      }, 0);
    }
  } catch (e) {
    console.warn("Failed to re-enable prompt input after auto-visual:", e);
  }
}

function showPreparingFinalResponseDuringAutoVisual(promptId) {
  const activeThoughtId = String(activeAgentTempPromptId || "").trim();
  if (activeThoughtId && document.getElementById(activeThoughtId)) {
    try {
      renderThoughts(activeThoughtId, [{
        text: "Preparing the final result",
        created: new Date().toLocaleTimeString()
      }]);
      return;
    } catch (e) {}
  }

  const normalizedPromptId = String(promptId || "").trim();
  const candidateIds = [
    normalizedPromptId ? `loading-indicator-${normalizedPromptId}` : "",
    String($v("P1_LATEST_LOADER_ID") || "").trim(),
    "loading-indicator"
  ].filter(Boolean);
  const seen = new Set();
  let shown = false;

  candidateIds.forEach(function(id) {
    if (seen.has(id)) return;
    seen.add(id);
    const loaderEl = document.getElementById(id);
    if (!loaderEl) return;
    applyGeminiProcessingIndicator(loaderEl);
    const labelEl = loaderEl.querySelector(".gemini-processing-label");
    if (labelEl) {
      labelEl.innerHTML = '✅ Preparing the final response<span class="gemini-processing-dots">...</span>';
    } else {
      loaderEl.textContent = "✅ Preparing the final response...";
    }
    loaderEl.style.display = "flex";
    shown = true;
  });

  const loaderRegion = document.querySelector("#LOADER_REGION");
  if (loaderRegion && shown) {
    loaderRegion.style.display = "block";
  }
  if (shown) {
    promptInput.disabled = true;
    runButton.disabled = true;
    refreshRunPromptButtonState();
  }
}

function setAutoVisualGenerationNotice(responseId, status, message) {
  const normalizedId = String(responseId || "").trim().replace(/^response-/, "");
  if (!normalizedId) return;
  const responseEl = document.getElementById(`response-${normalizedId}`) || document.getElementById(normalizedId);
  if (!responseEl || !responseEl.parentElement) return;
  const noticeId = `auto-visual-notice-${normalizedId}`;
  let noticeEl = document.getElementById(noticeId);
  if (!noticeEl) {
    noticeEl = document.createElement("div");
    noticeEl.id = noticeId;
    noticeEl.className = "ask-oracle-auto-visual-notice";
    noticeEl.style.cssText = "margin-top:6px;padding:6px 10px;border-radius:8px;font-size:12px;line-height:1.35;background:#f1f5f9;color:#334155;border:1px solid #dbeafe;";
    responseEl.insertAdjacentElement("afterend", noticeEl);
  }
  if (status === "hide") {
    noticeEl.remove();
    releasePromptInputAfterAutoVisual();
    return;
  }
  if (status === "done") {
    noticeEl.style.background = "#ecfdf5";
    noticeEl.style.color = "#065f46";
    noticeEl.style.borderColor = "#a7f3d0";
    clearPreparingFinalResultThoughts();
    releasePromptInputAfterAutoVisual();
  } else if (status === "error") {
    noticeEl.style.background = "#fef2f2";
    noticeEl.style.color = "#991b1b";
    noticeEl.style.borderColor = "#fecaca";
    releasePromptInputAfterAutoVisual();
  } else {
    noticeEl.style.background = "#eff6ff";
    noticeEl.style.color = "#1e3a8a";
    noticeEl.style.borderColor = "#bfdbfe";
  }
  noticeEl.textContent = String(message || "").trim();
}

function requestAgentAutoVisual(latestRow, done, options) {
  const finish = typeof done === "function" ? done : function() {};
  const opts = options && typeof options === "object" ? options : {};
  const backgroundMode = opts.backgroundMode === true;
  const decision = getAgentAutoVisualAttemptDecision(latestRow);
  const shouldAttempt = decision.shouldAttempt;
  const promptId = String(latestRow && latestRow.id ? latestRow.id : "").trim();
  const teamName = getPreferredAgentTeamName(latestRow);
  const rowAgentSuffix = parseAgentLabelSuffix(latestRow && latestRow.profile_name);
  const currentProfile = String($v("P1_CURRENT_AI_PROFILE") || "").trim();
  const profileName = rowAgentSuffix || currentProfile;
  const conversationStyle = decision.conversationStyle;
  const conversationStyleNormalized = decision.conversationStyleNormalized;
  const requestStartTs = Date.now();
  const timeoutMsRaw = Number(window.ASK_ORACLE_AUTO_VISUAL_TIMEOUT_MS);
  const timeoutMs =
    Number.isFinite(timeoutMsRaw) && timeoutMsRaw >= 1000
      ? Math.round(timeoutMsRaw)
      : 30000;
  const sourceResponseText = String(
    (latestRow && (latestRow.response || latestRow.prompt_response || latestRow.promptResponse)) || ""
  );

  console.log("[AUTO_VISUAL] gate check", {
    promptId,
    shouldAttempt,
    reason: decision.reason,
    conversationStyle,
    conversationStyleNormalized,
    responseType: decision.responseType,
    profileNameFromRow: decision.profileName,
    promptLength: decision.promptLength,
    selectedTeam: teamName,
    currentProfile: profileName,
    timeoutMs
  });

  if (!shouldAttempt) {
    console.log("[AUTO_VISUAL] skipped", {
      promptId,
      reason: decision.reason,
      conversationStyle,
      conversationStyleNormalized,
      responseType: decision.responseType,
      profileName: decision.profileName,
      promptLength: decision.promptLength
    });
    finish();
    return;
  }

  if (!promptId) {
    console.warn("[AUTO_VISUAL] skipped due to empty prompt id");
    finish();
    return;
  }

  if (!backgroundMode) {
    showPreparingFinalResponseDuringAutoVisual(promptId);
    console.log("[AUTO_VISUAL] preparing-final-response indicator shown", { promptId });
  } else {
    console.log("[AUTO_VISUAL] background mode enabled; skip blocking loader", { promptId });
  }

  console.log("[AUTO_VISUAL] source response before request", {
    promptId,
    responseLength: sourceResponseText.length,
    responseText: sourceResponseText
  });

  let completed = false;
  let timedOut = false;
  let hasVisualResult = false;
  const timeoutId = setTimeout(function() {
    timedOut = true;
    console.warn("[AUTO_VISUAL] timed out", {
      promptId,
      timeoutMs,
      elapsedMs: Date.now() - requestStartTs
    });
    completeOnce();
  }, timeoutMs);

  function completeOnce(meta) {
    if (completed) return;
    completed = true;
    clearTimeout(timeoutId);
    finish(meta && typeof meta === "object" ? meta : { hasVisual: hasVisualResult });
  }

  console.log("[AUTO_VISUAL] invoking GET_AGENT_AUTO_VISUAL", {
    promptId,
    x01: promptId,
    x02: teamName,
    x03: profileName
  });
  console.log(
    "[AUTO_VISUAL] PL/SQL call shape",
    "BEGIN ask_oracle_get_agent_auto_visual(p_prompt_id => apex_application.g_x01, p_agent_team_name => apex_application.g_x02, p_current_profile_name => apex_application.g_x03); END;",
    {
      g_x01: promptId,
      g_x02: teamName,
      g_x03: profileName
    }
  );

  apex.server.process(
    "GET_AGENT_AUTO_VISUAL",
    {
      x01: promptId,
      x02: teamName,
      x03: profileName
    },
    {
      dataType: "json",
      success: function (pData) {
        if (timedOut) {
          console.warn("[AUTO_VISUAL] late backend success after timeout", {
            promptId,
            elapsedMs: Date.now() - requestStartTs
          });
        }
        console.log("[AUTO_VISUAL] backend success", {
          promptId,
          chart_intent: pData && pData.chart_intent,
          visual_type: pData && pData.visual_type,
          visual_payload_length: pData && pData.visual_payload ? String(pData.visual_payload).length : 0,
          agent_team_name: pData && pData.agent_team_name,
          agent_profile_name: pData && pData.agent_profile_name,
          error: pData && pData.error,
          elapsedMs: Date.now() - requestStartTs
        });
        console.log("[AUTO_VISUAL] process response after request", {
          promptId,
          processResponse: pData
        });
        try {
          const chartIntent = String(pData && pData.chart_intent ? pData.chart_intent : "N").toUpperCase();
          const visualPayload = String(pData && pData.visual_payload ? pData.visual_payload : "").trim();
          hasVisualResult = chartIntent === "Y";
          if (shouldUseStoredAutoVisualResponse()) {
            clearAgentAutoVisualPayload(promptId);
            console.log("[AUTO_VISUAL] relying on GET_RESPONSE stored output", {
              promptId,
              chartIntent,
              hasPayload: !!visualPayload
            });
          } else if (chartIntent === "Y" && visualPayload) {
            queueAgentAutoVisualPayload(promptId, {
              chartIntent,
              visualType: String(pData.visual_type || "chartjs"),
              visualPayload
            });
            console.log("[AUTO_VISUAL] queued visual payload", {
              promptId,
              chartIntent,
              visualType: String(pData.visual_type || "chartjs"),
              payloadLength: visualPayload.length
            });
          } else {
            console.log("[AUTO_VISUAL] no visual payload queued", {
              promptId,
              chartIntent,
              hasPayload: !!visualPayload
            });
          }
        } catch (e) {
          console.warn("GET_AGENT_AUTO_VISUAL parse warning:", e);
        }
        completeOnce({ hasVisual: hasVisualResult });
      },
      error: function (jqXHR, textStatus, errorThrown) {
        const errorResponseText =
          jqXHR && typeof jqXHR.responseText !== "undefined" && jqXHR.responseText !== null
            ? String(jqXHR.responseText)
            : "";
        if (timedOut) {
          console.warn("[AUTO_VISUAL] late backend error after timeout", {
            promptId,
            elapsedMs: Date.now() - requestStartTs
          });
          completeOnce({ hasVisual: false, timedOut: true });
          return;
        }
        if (completed) {
          return;
        }

        // Some environments return HTTP 500 with a valid JSON payload.
        // Treat that as a soft-success when success=true.
        try {
          const parsed = errorResponseText ? JSON.parse(errorResponseText) : null;
          if (parsed && parsed.success === true) {
            const chartIntent = String(parsed.chart_intent || "N").toUpperCase();
            const visualPayload = String(parsed.visual_payload || "").trim();
            hasVisualResult = chartIntent === "Y";
            if (!shouldUseStoredAutoVisualResponse() && hasVisualResult && visualPayload) {
              queueAgentAutoVisualPayload(promptId, {
                chartIntent,
                visualType: String(parsed.visual_type || "chartjs"),
                visualPayload
              });
            } else if (shouldUseStoredAutoVisualResponse()) {
              clearAgentAutoVisualPayload(promptId);
            }
            console.warn("[AUTO_VISUAL] backend returned success payload via error callback", {
              promptId,
              status: jqXHR && jqXHR.status,
              chartIntent,
              hasPayload: !!visualPayload
            });
            completeOnce({ hasVisual: hasVisualResult, softSuccess: true });
            return;
          }
        } catch (ignoreParse) {}

        console.error("[AUTO_VISUAL] backend error", {
          promptId,
          status: jqXHR && jqXHR.status,
          statusText: jqXHR && jqXHR.statusText,
          textStatus,
          errorThrown,
          responseText: errorResponseText,
          elapsedMs: Date.now() - requestStartTs
        });
        console.log("[AUTO_VISUAL] process response after request (error)", {
          promptId,
          responseText: errorResponseText
        });
        completeOnce({ hasVisual: false, error: true });
      }
    }
  );
}

function isAskDbModeEnabled() {
  const askDb = String($v("P1_ASK_DB") || "").trim().toUpperCase();
  const askAdb = String($v("P1_ASK_ADB") || "").trim().toUpperCase();
  return askDb === "Y" || askAdb === "Y";
}

function isAskAdbChatWithDbConversationStyle() {
  const askAdb = String($v("P1_ASK_ADB") || "").trim().toUpperCase();
  const styleValue = String(getAskOracleCurrentConversationMode() || "").trim().toUpperCase();
  return askAdb === "Y" && styleValue === "CHAT_WITH_DB";
}

function buildAskOraclePageRedirectUrl(targetPage, targetItem, value) {
  const pageId = String(targetPage || "").trim();
  const itemNamesRaw = Array.isArray(targetItem) ? targetItem : [targetItem];
  const itemValuesRaw = Array.isArray(value) ? value : [value];
  const itemNames = itemNamesRaw.map((name) => String(name || "").trim()).filter(Boolean);
  if (!pageId || itemNames.length === 0) return "";
  if (itemValuesRaw.length !== itemNames.length) return "";

  const itemValues = itemValuesRaw.map((itemValue) => {
    if (itemValue == null) return "";
    return String(itemValue).trim();
  });
  if (!itemValues.some((v) => v !== "")) return "";

  let appId = "";
  let sessionId = "";
  try {
    if (typeof window.$v === "function") {
      appId = String($v("pFlowId") || "").trim();
      sessionId = String($v("pInstance") || "").trim();
    }
  } catch (e) {}
  if ((!appId || !sessionId) && window.apex && apex.env) {
    appId = appId || String(apex.env.APP_ID || "").trim();
    sessionId = sessionId || String(apex.env.APP_SESSION || apex.env.SESSION || "").trim();
  }
  if (!appId) {
    const flowInput = document.querySelector("#pFlowId, input[name='pFlowId']");
    if (flowInput && typeof flowInput.value !== "undefined") appId = String(flowInput.value || "").trim();
  }
  if (!sessionId) {
    const sessionInput = document.querySelector("#pInstance, input[name='pInstance']");
    if (sessionInput && typeof sessionInput.value !== "undefined") sessionId = String(sessionInput.value || "").trim();
  }
  if ((!appId || !sessionId) && window.location && window.location.search) {
    const pMatch = window.location.search.match(/[?&]p=([^:&]+):[^:&]*:([^:&]*)/i);
    if (pMatch) {
      if (!appId) appId = String(pMatch[1] || "").trim();
      if (!sessionId) sessionId = String(pMatch[2] || "").trim();
    }
  }
  if (!appId || !sessionId) return "";
  const itemNameSegment = itemNames.join(",");
  const itemValueSegment = itemValues.map((v) => encodeURIComponent(v)).join(",");
  const fallbackUrl = `f?p=${appId}:${pageId}:${sessionId}::NO::${itemNameSegment}:${itemValueSegment}`;
  try {
    if (window.apex && apex.util && typeof apex.util.prepareURL === "function") {
      const preparedUrl = String(apex.util.prepareURL(fallbackUrl) || "").trim();
      if (preparedUrl) return preparedUrl;
    }
  } catch (e) {}
  return fallbackUrl;
}

function escapeAskOracleAttributeSelectorValue(value) {
  const raw = String(value == null ? "" : value);
  if (window.CSS && typeof window.CSS.escape === "function") {
    try { return window.CSS.escape(raw); } catch (e) {}
  }
  return raw.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function findAskOracleResponseElementByPromptId(promptId) {
  const normalizedPromptId = String(promptId || "").trim();
  if (!normalizedPromptId) return null;
  try {
    return document.querySelector(`[data-conversation-prompt-id="${escapeAskOracleAttributeSelectorValue(normalizedPromptId)}"]`);
  } catch (e) {
    return null;
  }
}

function getAskOraclePromptActionResponseId(explicitResponseId) {
  const explicitId = String(explicitResponseId || "").trim().replace(/^response-/, "");
  if (explicitId) return explicitId;

  const trigger = window.event && (window.event.currentTarget || window.event.target)
    ? (window.event.currentTarget || window.event.target)
    : document.activeElement;
  if (!trigger || typeof trigger.closest !== "function") return "";

  const host = trigger.closest(".speech-controls[data-id], .chart-sql-buttons[data-response-id], .ask-oracle-response-table-actions[data-response-id], .ask-oracle-sql-footer-actions[data-response-id], .response-footer[data-response-id], [id^='response-'][data-id]");
  let rawId = host
    ? String(host.getAttribute("data-response-id") || host.getAttribute("data-id") || host.id || "").trim()
    : "";
  if (rawId) return rawId.replace(/^response-/, "");

  const footer = trigger.closest(".speech-controls, .chart-sql-buttons, .ask-oracle-response-table-actions, .ask-oracle-sql-footer-actions, .response-footer");
  let node = footer;
  let hop = 0;
  while (node && hop < 12) {
    node = node.previousElementSibling;
    if (node && /^response-/.test(String(node.id || ""))) {
      rawId = String(node.id || "").trim();
      break;
    }
    hop += 1;
  }
  return String(rawId || "").replace(/^response-/, "");
}

function getAskOraclePromptActionMetaFromResponse(responseId) {
  const normalizedId = String(responseId || "").trim().replace(/^response-/, "");
  if (!normalizedId) return {};
  const responseEl = document.getElementById(`response-${normalizedId}`) || document.getElementById(normalizedId);
  if (!responseEl) return {};
  return {
    conversation_prompt_id: String(responseEl.getAttribute("data-conversation-prompt-id") || "").trim(),
    explore_link: String(responseEl.getAttribute("data-explore-link") || "").trim(),
    explain_link: String(responseEl.getAttribute("data-explain-link") || "").trim(),
    conversation_id: String(responseEl.getAttribute("data-conversation-id") || "").trim()
  };
}

function applyAskOraclePromptActionMetaToResponse(responseId, meta) {
  const normalizedId = String(responseId || "").trim().replace(/^response-/, "");
  if (!normalizedId) return;
  const responseEl = document.getElementById(`response-${normalizedId}`) || document.getElementById(normalizedId);
  if (!responseEl) return;
  const payload = meta && typeof meta === "object" ? meta : {};
  const conversationPromptId = String(payload.conversation_prompt_id || "").trim();
  const exploreLink = String(payload.explore_link || "").trim();
  const explainLink = String(payload.explain_link || "").trim();
  const conversationId = String(payload.conversation_id || "").trim();
  if (conversationPromptId) responseEl.setAttribute("data-conversation-prompt-id", conversationPromptId);
  if (exploreLink) responseEl.setAttribute("data-explore-link", exploreLink);
  if (explainLink) responseEl.setAttribute("data-explain-link", explainLink);
  if (conversationId) responseEl.setAttribute("data-conversation-id", conversationId);
}

function fetchAskOraclePromptActionMeta(responseId, onDone) {
  const normalizedId = String(responseId || "").trim().replace(/^response-/, "");
  const callback = typeof onDone === "function" ? onDone : function() {};
  const domMeta = getAskOraclePromptActionMetaFromResponse(normalizedId);
  if (String(domMeta.conversation_prompt_id || "").trim() || String(domMeta.explore_link || "").trim() || String(domMeta.explain_link || "").trim()) {
    callback(domMeta);
    return;
  }
  if (!normalizedId || !(window.apex && apex.server && typeof apex.server.process === "function")) {
    callback(domMeta);
    return;
  }
  apex.server.process("GET_RESPONSE", { x01: normalizedId }, {
    dataType: "json",
    success: function(pData) {
      const serverMeta = {
        conversation_prompt_id: String((pData && (pData.conversation_prompt_id || pData.id)) || normalizedId).trim(),
        explore_link: String((pData && pData.explore_link) || "").trim(),
        explain_link: String((pData && pData.explain_link) || "").trim(),
        conversation_id: String((pData && (pData.conversation_id || pData.conv_id || pData.conversationId)) || domMeta.conversation_id || "").trim()
      };
      applyAskOraclePromptActionMetaToResponse(normalizedId, serverMeta);
      callback(serverMeta);
    },
    error: function() {
      callback(domMeta);
    }
  });
}

function resolveAskOraclePromptActionRedirectMeta(conversationPromptId, serverUrl, responseId, linkKey, onDone) {
  const normalizedId = getAskOraclePromptActionResponseId(responseId);
  const domMeta = getAskOraclePromptActionMetaFromResponse(normalizedId);
  const initialMeta = {
    conversation_prompt_id: String(conversationPromptId || domMeta.conversation_prompt_id || "").trim(),
    explore_link: String(domMeta.explore_link || "").trim(),
    explain_link: String(domMeta.explain_link || "").trim(),
    conversation_id: String(domMeta.conversation_id || "").trim()
  };
  if (linkKey === "explore_link") initialMeta.explore_link = String(serverUrl || initialMeta.explore_link || "").trim();
  if (linkKey === "explain_link") initialMeta.explain_link = String(serverUrl || initialMeta.explain_link || "").trim();

  if (String(initialMeta.conversation_prompt_id || "").trim() || String(initialMeta[linkKey] || "").trim()) {
    onDone(initialMeta);
    return;
  }

  fetchAskOraclePromptActionMeta(normalizedId, function(serverMeta) {
    const resolvedMeta = {
      conversation_prompt_id: String((serverMeta && serverMeta.conversation_prompt_id) || initialMeta.conversation_prompt_id || "").trim(),
      explore_link: String((serverMeta && serverMeta.explore_link) || initialMeta.explore_link || "").trim(),
      explain_link: String((serverMeta && serverMeta.explain_link) || initialMeta.explain_link || "").trim(),
      conversation_id: String((serverMeta && serverMeta.conversation_id) || initialMeta.conversation_id || "").trim()
    };
    applyAskOraclePromptActionMetaToResponse(normalizedId, resolvedMeta);
    onDone(resolvedMeta);
  });
}

function redirectToExplorePage(conversationPromptId, serverUrl, responseId) {
  resolveAskOraclePromptActionRedirectMeta(conversationPromptId, serverUrl, responseId, "explore_link", function(meta) {
    const promptId = String((meta && meta.conversation_prompt_id) || "").trim();
    const fallback = String((meta && meta.explore_link) || "").trim();
    let conversationId = String((typeof window.$v === "function" ? $v("P1_CONV_ID") : "") || "").trim();
    if (!conversationId) conversationId = String((meta && meta.conversation_id) || "").trim();
    if (!conversationId && promptId) {
      const responseEl = findAskOracleResponseElementByPromptId(promptId);
      conversationId = String((responseEl && responseEl.getAttribute("data-conversation-id")) || "").trim();
    }
    const url = buildAskOraclePageRedirectUrl(
      "2",
      ["P2_CURRENT_ID", "P2_CONVERSATION_ID", "P2_CONV_ID", "P2_RETURN_CONV_ID", "P1_CONV_ID"],
      [promptId, conversationId, conversationId, conversationId, conversationId]
    );
    if (url) {
      if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
        apex.navigation.redirect(url);
      } else {
        window.location.href = url;
      }
      return;
    }
    if (fallback) {
      if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
        apex.navigation.redirect(fallback);
      } else {
        window.location.href = fallback;
      }
      return;
    }
    if (window.apex && apex.message && typeof apex.message.showErrors === "function") {
      apex.message.clearErrors();
      apex.message.showErrors([{
        type: "error",
        location: "page",
        message: "Unable to navigate to Explore.",
        unsafe: false
      }]);
    }
  });
}

function redirectToExplainPage(conversationPromptId, serverUrl, responseId) {
  resolveAskOraclePromptActionRedirectMeta(conversationPromptId, serverUrl, responseId, "explain_link", function(meta) {
    const promptId = String((meta && meta.conversation_prompt_id) || "").trim();
    const fallback = String((meta && meta.explain_link) || "").trim();
    let conversationId = String((typeof window.$v === "function" ? $v("P1_CONV_ID") : "") || "").trim();
    if (!conversationId) conversationId = String((meta && meta.conversation_id) || "").trim();
    if (!conversationId && promptId) {
      const responseEl = findAskOracleResponseElementByPromptId(promptId);
      conversationId = String((responseEl && responseEl.getAttribute("data-conversation-id")) || "").trim();
    }
    const url = buildAskOraclePageRedirectUrl(
      "3",
      ["P3_CURRENT_ID", "P3_CONVERSATION_ID", "P3_CONV_ID", "P3_RETURN_CONV_ID", "P1_CONV_ID"],
      [promptId, conversationId, conversationId, conversationId, conversationId]
    );
    if (url) {
      if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
        apex.navigation.redirect(url);
      } else {
        window.location.href = url;
      }
      return;
    }
    if (fallback) {
      if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
        apex.navigation.redirect(fallback);
      } else {
        window.location.href = fallback;
      }
      return;
    }
    if (window.apex && apex.message && typeof apex.message.showErrors === "function") {
      apex.message.clearErrors();
      apex.message.showErrors([{
        type: "error",
        location: "page",
        message: "Unable to navigate to Explain.",
        unsafe: false
      }]);
    }
  });
}

function getAskOracleReturnConversationIdFromDetailPage() {
  const candidates = [];
  const pushValue = function(v) {
    const text = String(v == null ? "" : v).trim();
    if (text) candidates.push(text);
  };

  try {
    if (typeof window.$v === "function") {
      pushValue($v("P2_RETURN_CONV_ID"));
      pushValue($v("P2_CONV_ID"));
      pushValue($v("P2_CONVERSATION_ID"));
      pushValue($v("P3_RETURN_CONV_ID"));
      pushValue($v("P3_CONV_ID"));
      pushValue($v("P3_CONVERSATION_ID"));
      pushValue($v("P1_CONV_ID"));
    }
  } catch (e) {}

  const href = String((window.location && window.location.href) || "");
  const urlMatch = href.match(/[?&](?:P2_RETURN_CONV_ID|P2_CONV_ID|P2_CONVERSATION_ID|P3_RETURN_CONV_ID|P3_CONV_ID|P3_CONVERSATION_ID|P1_CONV_ID)=([^&#]*)/i);
  if (urlMatch && urlMatch[1]) {
    try {
      pushValue(decodeURIComponent(String(urlMatch[1]).replace(/\+/g, "%20")));
    } catch (e) {
      pushValue(urlMatch[1]);
    }
  }

  for (let i = 0; i < candidates.length; i += 1) {
    if (candidates[i]) return candidates[i];
  }
  return "";
}

function redirectAskOracleDetailPageBackToConversation() {
  const conversationId = getAskOracleReturnConversationIdFromDetailPage();
  const url = buildAskOraclePageRedirectUrl("1", "P1_CONV_ID", conversationId || "");
  if (url) {
    if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
      apex.navigation.redirect(url);
    } else {
      window.location.href = url;
    }
    return true;
  }
  return false;
}

function shouldHandleAskOracleDetailBackButton(targetEl) {
  if (!targetEl) return false;
  const pageId = String(getAskOracleCurrentPageId() || "").trim();
  if (pageId !== "2" && pageId !== "3") return false;

  const el = targetEl.closest
    ? targetEl.closest("#CLOSE_SQL, [id$='CLOSE_SQL'], [data-button-name='CLOSE_SQL'], .fa-chevron-left")
    : null;
  if (!el) return false;
  return true;
}

function bindAskOracleDetailBackButtonOverride() {
  if (window.__askOracleDetailBackOverrideBound) return;
  window.__askOracleDetailBackOverrideBound = true;

  document.addEventListener("click", function(event) {
    const target = event && event.target ? event.target : null;
    if (!shouldHandleAskOracleDetailBackButton(target)) return;
    if (redirectAskOracleDetailPageBackToConversation()) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") {
        event.stopImmediatePropagation();
      }
    }
  }, true);
}

bindAskOracleDetailBackButtonOverride();

function looksLikeNl2SqlProfileName(value) {
  const text = String(value || "").trim().toUpperCase();
  if (!text) return false;
  return text.indexOf("NL2SQL") >= 0 || text.indexOf("CHAT_WITH_DB") >= 0;
}

function isAgentResponseForBorder(responseEl) {
  if (isUserAgentsConversationStyleActive()) return true;
  if (!responseEl) return false;
  var profileFromData = String(responseEl.getAttribute("data-profile-name") || "").trim();
  if (/^AGENT\b/i.test(profileFromData)) return true;
  var profileLabel = responseEl.parentElement
    ? responseEl.parentElement.querySelector(".profile-label")
    : null;
  return /^AGENT\b/i.test(String(profileLabel && profileLabel.textContent || "").trim());
}

function shouldHideNl2SqlResponseBorder(responseEl) {
  if (isAgentResponseForBorder(responseEl)) return false;
  if (String($v("P1_SWITCH_NARRATE") || "").trim().toUpperCase() === "Y") return false;
  if (isNl2SqlConversationStyleActive()) return true;
  if (!responseEl) return false;

  if (String(responseEl.getAttribute("data-type") || "").toLowerCase() === "sql") return true;

  const profileFromData = String(responseEl.getAttribute("data-profile-name") || "");
  if (looksLikeNl2SqlProfileName(profileFromData)) return true;

  const profileLabel = responseEl.parentElement
    ? responseEl.parentElement.querySelector(".profile-label")
    : null;
  const profileFromLabel = String(profileLabel && profileLabel.textContent ? profileLabel.textContent : "");
  if (looksLikeNl2SqlProfileName(profileFromLabel)) return true;

  return false;
}

function isAskOracleDarkUiActive() {
  const classes = `${document.documentElement.className || ""} ${document.body.className || ""}`.toLowerCase();
  return /(?:^|\s)(ask-oracle-dark-ui|t-body--dark|u-theme--dark|dark-mode|theme-dark|is-dark)(?:\s|$)/.test(classes) || classes.indexOf("dark") >= 0;
}

function scheduleResponseTableLayoutRefresh(responseElementId) {
  const id = String(responseElementId || "").trim();
  if (!id) return;

  [0, 120, 280, 520, 900, 1400].forEach((delayMs) => {
    setTimeout(() => {
      applyResponseTableLayoutForConversationStyle(id);
    }, delayMs);
  });
}

function applyResponseTableLayoutForConversationStyle(responseElementId) {
  const responseEl = document.getElementById(String(responseElementId || ""));
  if (!responseEl) return;

  const nl2SqlBorderless = shouldHideNl2SqlResponseBorder(responseEl);
  const tables = responseEl.querySelectorAll("table");
  const hasTables = !!tables && tables.length > 0;
  const agentResponse = isAgentResponseForBorder(responseEl);
  const narrateResponse = String($v("P1_SWITCH_NARRATE") || "").trim().toUpperCase() === "Y";
  const hideResponseBorder = !agentResponse && !narrateResponse && (nl2SqlBorderless || hasTables);

  if (agentResponse) {
    responseEl.classList.remove("ask-oracle-borderless-response");
    responseEl.style.setProperty("border", "1px solid #cbd5e1", "important");
    responseEl.style.removeProperty("box-shadow");
    responseEl.style.removeProperty("background");
  } else if (hideResponseBorder) {
    responseEl.classList.add("ask-oracle-borderless-response");
    responseEl.style.setProperty("border", "0", "important");
    responseEl.style.setProperty("box-shadow", "none", "important");
    responseEl.style.setProperty("background", "transparent", "important");
  } else {
    responseEl.classList.remove("ask-oracle-borderless-response");
    responseEl.style.removeProperty("border");
    responseEl.style.removeProperty("box-shadow");
    responseEl.style.removeProperty("background");
  }

  if (nl2SqlBorderless) {
    responseEl.classList.add("ask-oracle-nl2sql-full-grid");
  } else {
    responseEl.classList.remove("ask-oracle-nl2sql-full-grid");
  }

  if (!hasTables) return;

  responseEl.style.setProperty("overflow-x", "auto", "important");
  responseEl.style.setProperty("overflow-y", "hidden", "important");

  const ragMode = isRagConversationStyleActive();
  const darkUi = isAskOracleDarkUiActive();
  const tableHeaderBg = "linear-gradient(135deg, #4f46e5 0%, #2563eb 55%, #0891b2 100%)";
  const tableHeaderColor = "#ffffff";
  const tableHeaderBorder = "rgba(255, 255, 255, 0.28)";
  const tableCellBorder = nl2SqlBorderless
    ? "#d3ddea"
    : (darkUi ? "rgba(148, 163, 184, 0.45)" : "#d1d5db");

  tables.forEach((table) => {
    if (!table) return;
    if (nl2SqlBorderless) {
      table.querySelectorAll("th, td").forEach((cell) => {
        try {
          cell.style.setProperty("max-width", "none", "important");
        } catch (e) {}
      });
    }

    table.querySelectorAll("thead th, thead td").forEach((th) => {
      try {
        th.style.setProperty("background", tableHeaderBg, "important");
        th.style.setProperty("background-color", "#2563eb", "important");
        th.style.setProperty("color", tableHeaderColor, "important");
        th.style.setProperty("border", `1px solid ${tableHeaderBorder}`, "important");
        th.style.setProperty("border-color", tableHeaderBorder, "important");
        th.style.setProperty("box-shadow", "inset 0 -2px 0 rgba(15, 23, 42, 0.2)", "important");
      } catch (e) {}
    });

    table.querySelectorAll("thead td, thead th").forEach((cell) => {
      try {
        cell.style.setProperty("border", `1px solid ${tableHeaderBorder}`, "important");
        cell.style.setProperty("border-color", tableHeaderBorder, "important");
      } catch (e) {}
    });
    table.querySelectorAll("tbody td, tbody th").forEach((cell) => {
      try {
        cell.style.setProperty("background", "transparent", "important");
        cell.style.setProperty("background-color", "transparent", "important");
        cell.style.setProperty("color", "inherit", "important");
        if (nl2SqlBorderless) {
          cell.style.setProperty("max-width", "none", "important");
        }
        if (nl2SqlBorderless) {
          cell.style.setProperty("border", `1px solid ${tableCellBorder}`, "important");
          cell.style.setProperty("border-color", tableCellBorder, "important");
        } else {
          cell.style.setProperty("border", "0", "important");
          cell.style.setProperty("border-color", "transparent", "important");
        }
      } catch (e) {}
    });

    // Auto-fit columns and allow horizontal scroll when many columns exist.
    table.style.setProperty("table-layout", "auto", "important");
    table.style.setProperty("width", "max-content", "important");
    table.style.setProperty("min-width", "100%", "important");
    table.style.setProperty("max-width", "none", "important");
    table.style.setProperty("border-collapse", "collapse", "important");

    table.querySelectorAll("colgroup col").forEach((col) => {
      try {
        col.style.setProperty("width", "auto", "important");
        col.style.setProperty("min-width", "0", "important");
        col.style.setProperty("max-width", "none", "important");
        col.removeAttribute("width");
      } catch (e) {}
    });

    table.querySelectorAll("thead th, thead td, tbody th, tbody td").forEach((cell) => {
      try {
        cell.style.setProperty("width", "auto", "important");
        cell.style.setProperty("min-width", "0", "important");
        cell.style.setProperty("max-width", ragMode ? "360px" : "none", "important");
        cell.style.setProperty("white-space", "normal", "important");
        cell.style.setProperty("word-break", "break-word", "important");
        cell.style.setProperty("overflow-wrap", "anywhere", "important");
        cell.style.setProperty("line-break", "anywhere", "important");
        cell.removeAttribute("width");
      } catch (e) {}

      cell.querySelectorAll("pre, code").forEach((nested) => {
        try {
          nested.style.setProperty("white-space", "pre-wrap", "important");
          nested.style.setProperty("word-break", "break-word", "important");
          nested.style.setProperty("overflow-wrap", "anywhere", "important");
          nested.style.setProperty("max-width", "100%", "important");
        } catch (e) {}
      });
    });
  });
}


function hasChartConfigHints(raw) {
  return /("type"\s*:|type\s*:|"datasets"\s*:|datasets\s*:|"labels"\s*:|labels\s*:|"chart"\s*:|"x_axis"\s*:|"y_axis"\s*:)/i.test(raw || "");
}

function normalizeChartConfigObject(cfg) {
  if (Array.isArray(cfg)) return cfg.length > 0 ? cfg[0] : null;
  return cfg;
}

function getChartObjectCandidate(cfg) {
  const normalized = normalizeChartConfigObject(cfg);
  if (!normalized || typeof normalized !== "object") return null;
  if (normalized.chart && typeof normalized.chart === "object") return normalized.chart;
  return normalized;
}

function normalizeChartTypeToken(typeValue) {
  const value = String(typeValue || "").trim().toLowerCase();
  if (!value) return "";
  const normalizedText = value.replace(/\s+/g, " ").trim();
  if (normalizedText === "sun burst") return "sunburst";
  if (normalizedText === "donut chart" || normalizedText === "doughnut chart") return "donut";
  if (normalizedText === "heat map") return "heatmap";
  if (normalizedText === "bar race" || normalizedText === "race bar" || normalizedText === "animated race chart" || normalizedText === "animated bar race") {
    return "bar_race";
  }
  if (normalizedText === "bar-race") return "bar_race";
  if (normalizedText === "column" || normalizedText === "column chart") return "column";
  if (normalizedText === "grouped bar" || normalizedText === "grouped bar chart" || normalizedText === "clustered bar" || normalizedText === "clustered bar chart") return "grouped_bar";
  if (normalizedText === "stacked bar" || normalizedText === "stacked bar chart" || normalizedText === "stacked column" || normalizedText === "stacked column chart") return "stacked_bar";
  if (normalizedText === "diverging bar" || normalizedText === "diverging bar chart") return "diverging_bar";
  if (normalizedText === "lollipop" || normalizedText === "lollipop chart") return "lollipop";
  if (normalizedText === "dot plot") return "dot_plot";
  if (normalizedText === "spider chart") return "radar";
  if (normalizedText === "kpi" || normalizedText === "kpi card" || normalizedText === "kpi cards") return "kpi_card";
  if (normalizedText === "gantt" || normalizedText === "gantt chart" || normalizedText === "timeline chart") return "gantt";
  if (normalizedText === "candlestick chart") return "candlestick";
  if (normalizedText === "network" || normalizedText === "network chart") return "network_graph";
  if (normalizedText === "force-directed graph") return "network_graph";
  if (normalizedText === "dependency graph") return "network_graph";
  if (normalizedText === "knowledge graph") return "network_graph";
  if (normalizedText === "chord" || normalizedText === "chord chart" || normalizedText === "chord diagram") return "chord";
  if (normalizedText === "circos" || normalizedText === "circos chart" || normalizedText === "circos diagram") return "chord";
  if (normalizedText === "calendar heat map") return "calendar_heatmap";
  if (normalizedText === "stream graph") return "streamgraph";
  return normalizedText.replace(/\s+/g, "_");
}

function isHeatmapChartType(typeValue) {
  const value = normalizeChartTypeToken(typeValue);
  return value === "heatmap" || value === "correlation_matrix" || value === "calendar_heatmap";
}

function isBarRaceChartType(typeValue) {
  const value = normalizeChartTypeToken(typeValue);
  return value === "bar_race" || value === "race_chart" || value === "animated_race_chart";
}

function normalizeChartTypeForChartJs(typeValue) {
  const value = normalizeChartTypeToken(typeValue);
  if (!value) return "bar";
  if (value === "column") return "bar";
  if (value === "grouped_bar") return "bar";
  if (value === "stacked_bar") return "bar";
  if (value === "diverging_bar") return "bar";
  if (value === "lollipop") return "bar";
  if (value === "dot_plot") return "scatter";
  if (value === "histogram") return "bar";
  if (value === "donut") return "doughnut";
  if (value === "polararea") return "polarArea";
  if (value === "spider" || value === "spider_chart") return "radar";
  if (/^box[\s_-]*plot$/.test(value) || value === "boxandwhisker" || value === "box-and-whisker") return "boxplot";
  if (value === "area") return "line";
  if (isHeatmapChartType(value)) return "heatmap";
  if (isBarRaceChartType(value)) return "bar_race";
  if (value === "kpi_card") return "kpi_card";
  if (value === "gauge") return "gauge";
  if (value === "gantt") return "gantt";
  if (value === "treemap") return "treemap";
  if (value === "sankey") return "sankey";
  if (value === "candlestick" || value === "ohlc") return "candlestick";
  if (value === "waterfall") return "waterfall";
  if (value === "calendar_heatmap") return "calendar_heatmap";
  if (value === "streamgraph" || value === "themeriver") return "streamgraph";
  if (value === "network_graph") return "network_graph";
  if (value === "chord") return "chord";
  return value;
}

function convertAxisChartSpecToChartJsConfig(rawCfg) {
  const chartObj = getChartObjectCandidate(rawCfg);
  if (!chartObj || typeof chartObj !== "object") return null;

  const labels = Array.isArray(chartObj.x_axis)
    ? chartObj.x_axis
    : (Array.isArray(chartObj.labels) ? chartObj.labels : (Array.isArray(chartObj.xAxis) ? chartObj.xAxis : []));
  const values = Array.isArray(chartObj.y_axis)
    ? chartObj.y_axis
    : (Array.isArray(chartObj.data) ? chartObj.data : (Array.isArray(chartObj.yAxis) ? chartObj.yAxis : []));
  if (!labels.length || !values.length) return null;

  const chartType = normalizeChartTypeForChartJs(chartObj.type);
  const numericValues = values.map((value) => {
    const num = Number(value);
    return Number.isFinite(num) ? num : value;
  });

  const datasetLabel = String(
    chartObj.series_name ||
    chartObj.dataset_label ||
    chartObj.y_axis_label ||
    chartObj.title ||
    "Value"
  ).trim() || "Value";

  const cfg = {
    type: chartType,
    data: {
      labels: labels.map((label) => String(label)),
      datasets: [{
        label: datasetLabel,
        data: numericValues
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: !!String(chartObj.title || "").trim(),
          text: String(chartObj.title || "").trim()
        }
      }
    }
  };

  if (chartType === "line" && String(chartObj.type || "").trim().toLowerCase() === "area") {
    cfg.data.datasets[0].fill = true;
  }

  if (![
    "pie", "doughnut", "polarArea", "sunburst", "heatmap", "bar_race",
    "treemap", "sankey", "gauge", "kpi_card", "gantt", "candlestick",
    "waterfall", "calendar_heatmap", "streamgraph", "network_graph", "chord"
  ].includes(chartType)) {
    cfg.options.scales = {
      x: {
        title: {
          display: !!String(chartObj.x_axis_label || "").trim(),
          text: String(chartObj.x_axis_label || "").trim()
        }
      },
      y: {
        title: {
          display: !!String(chartObj.y_axis_label || "").trim(),
          text: String(chartObj.y_axis_label || "").trim()
        }
      }
    };
  }

  return cfg;
}

function coerceRenderableChartConfig(rawCfg) {
  let cfg = normalizeChartConfigObject(rawCfg);
  cfg = reviveFunctions(cfg);
  if (isRenderableChartConfig(cfg)) return cfg;

  const converted = convertAxisChartSpecToChartJsConfig(cfg);
  if (converted && isRenderableChartConfig(converted)) {
    return converted;
  }
  return null;
}

function getRenderableChartCandidates(rawCfg) {
  if (Array.isArray(rawCfg)) return rawCfg;
  if (!rawCfg || typeof rawCfg !== "object") return [rawCfg];

  const arrayKeys = ["charts", "chartConfigs", "configs", "visuals"];
  for (let i = 0; i < arrayKeys.length; i++) {
    const value = rawCfg[arrayKeys[i]];
    if (Array.isArray(value)) return value;
  }

  return [rawCfg];
}

function coerceRenderableChartConfigs(rawCfg) {
  const candidates = getRenderableChartCandidates(rawCfg);
  const configs = [];

  candidates.forEach((candidate) => {
    const cfg = coerceRenderableChartConfig(candidate);
    if (cfg) configs.push(cfg);
  });

  return configs;
}

function isRenderableChartConfig(cfg) {
  const normalized = normalizeChartConfigObject(cfg);
  if (!normalized || typeof normalized !== "object") return false;
  if (typeof normalized.type !== "string" || !normalized.type.trim()) return false;
  if (!normalized.data || typeof normalized.data !== "object") return false;

  if (Array.isArray(normalized.data.datasets) && normalized.data.datasets.length > 0) return true;
  return Array.isArray(normalized.data.labels) || Object.keys(normalized.data).length > 0;
}

function detectRequestedChartTypeFromPrompt(promptText) {
  const promptLower = String(promptText || "").toLowerCase();
  if (!promptLower) return "";
  if (promptLower.includes("calendar heatmap") || promptLower.includes("calendar heat map")) return "calendar_heatmap";
  if (promptLower.includes("correlation matrix") || promptLower.includes("heatmap") || promptLower.includes("heat map")) return "heatmap";
  if (promptLower.includes("bar race") || promptLower.includes("bar-race") || promptLower.includes("race bar") || promptLower.includes("animated race chart")) return "bar_race";
  if (promptLower.includes("gantt")) return "gantt";
  if (promptLower.includes("kpi card") || promptLower.includes("kpi cards") || promptLower.includes("kpi")) return "kpi_card";
  if (promptLower.includes("gauge chart") || promptLower.includes("gauge")) return "gauge";
  if (promptLower.includes("candlestick") || promptLower.includes("ohlc")) return "candlestick";
  if (promptLower.includes("waterfall")) return "waterfall";
  if (promptLower.includes("sankey")) return "sankey";
  if (promptLower.includes("treemap") || promptLower.includes("tree map")) return "treemap";
  if (promptLower.includes("streamgraph") || promptLower.includes("stream graph")) return "streamgraph";
  if (promptLower.includes("network graph") || promptLower.includes("force-directed") || promptLower.includes("dependency graph") || promptLower.includes("knowledge graph")) return "network_graph";
  if (promptLower.includes("chord diagram") || promptLower.includes("chord chart") || promptLower.includes("circos")) return "chord";
  if (promptLower.includes("histogram")) return "histogram";
  if (promptLower.includes("bubble")) return "bubble";
  if (promptLower.includes("scatter")) return "scatter";
  if (promptLower.includes("radar") || promptLower.includes("spider chart")) return "radar";
  if (promptLower.includes("box plot") || promptLower.includes("boxplot") || promptLower.includes("box-and-whisker")) {
    return isBoxPlotChartSupported() ? "boxplot" : "bar";
  }
  if (promptLower.includes("funnel chart") || promptLower.includes("funnel")) {
    return isFunnelChartSupported() ? "funnel" : "bar";
  }
  if (promptLower.includes("sunburst") || promptLower.includes("sun burst")) return "sunburst";
  if (promptLower.includes("stacked bar") || promptLower.includes("stacked column")) return "stacked_bar";
  if (promptLower.includes("grouped bar") || promptLower.includes("clustered bar")) return "grouped_bar";
  if (promptLower.includes("column chart") || promptLower.includes("column")) return "column";
  if (promptLower.includes("donut chart") || promptLower.includes("doughnut chart")) return "donut";
  if (promptLower.includes("area chart")) return "area";
  if (promptLower.includes("line chart")) return "line";
  if (promptLower.includes("pie chart")) return "pie";
  if (promptLower.includes("bar chart") || promptLower.includes("bar graph")) return "bar";
  if (/\b(log(?:arithmic)?\s+(?:scale|y[\s-]*axis)|log scale)\b/i.test(promptLower)) return "bar";
  if (/(plot|chart|graph|visuali[sz]e)/i.test(promptLower)) return "bar";
  return "";
}

function parseNumericCellValue(rawValue) {
  const text = String(rawValue == null ? "" : rawValue).replace(/,/g, "").trim();
  if (!text) return null;
  const normalized = text.replace(/%$/, "");
  const num = Number(normalized);
  return Number.isFinite(num) ? num : null;
}

function buildChartConfigFromHtmlTable(responseText, promptText) {
  const source = String(responseText || "");
  const tableMatch = source.match(/<table[\s\S]*?<\/table>/i);
  if (!tableMatch || !tableMatch[0]) return null;

  let tableEl = null;
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(tableMatch[0], "text/html");
    tableEl = doc.querySelector("table");
  } catch (e) {
    tableEl = null;
  }
  if (!tableEl) return null;

  const rows = Array.from(tableEl.querySelectorAll("tr"));
  if (!rows.length) return null;

  const headerCells = Array.from(rows[0].querySelectorAll("th,td"));
  const headerLabels = headerCells.map((cell) => String(cell.textContent || "").trim());
  if (headerLabels.length < 2) return null;

  const dataRows = rows.slice(1).map((row) =>
    Array.from(row.querySelectorAll("td,th")).map((cell) => String(cell.textContent || "").trim())
  );
  if (!dataRows.length) return null;

  let valueColIndex = 1;
  for (let c = 1; c < headerLabels.length; c++) {
    const numericCount = dataRows.reduce((count, row) => (parseNumericCellValue(row[c]) != null ? count + 1 : count), 0);
    if (numericCount > 0) {
      valueColIndex = c;
      break;
    }
  }

  const labels = [];
  const values = [];
  dataRows.forEach((row) => {
    const label = String((row[0] == null ? "" : row[0])).trim();
    const value = parseNumericCellValue(row[valueColIndex]);
    if (!label || value == null) return;
    labels.push(label);
    values.push(value);
  });

  if (!labels.length || !values.length) return null;

  const chartType = normalizeChartTypeForChartJs(detectRequestedChartTypeFromPrompt(promptText) || "bar");
  const datasetLabel = String(headerLabels[valueColIndex] || "Value").trim() || "Value";
  const palette = [
    "#007bff", "#6c757d", "#28a745", "#ffc107", "#dc3545",
    "#20c997", "#6610f2", "#e83e8c", "#fd7e14", "#17a2b8"
  ];
  const colors = labels.map((_, index) => palette[index % palette.length]);

  return {
    type: chartType,
    data: {
      labels,
      datasets: [
        {
          label: datasetLabel,
          data: values,
          backgroundColor: colors,
          borderColor: colors,
          borderWidth: 1
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: { display: false, text: "" }
      }
    }
  };
}

function parseMarkdownTableCells(lineText) {
  const line = String(lineText || "").trim();
  if (!line.startsWith("|")) return [];
  const core = line.replace(/^\|/, "").replace(/\|$/, "");
  return core.split("|").map((cell) => String(cell || "").trim());
}

function buildChartConfigFromMarkdownTable(responseText, promptText) {
  const source = String(responseText || "");
  const tableBlockRegex = /(?:^|\n)(\|[^\n]*\|\s*\n\|[\s:\-|]+\|\s*\n(?:\|[^\n]*\|\s*(?:\n|$))+)/m;
  const match = source.match(tableBlockRegex);
  if (!match || !match[1]) return null;

  const lines = String(match[1] || "")
    .split(/\r?\n/)
    .map((line) => String(line || "").trim())
    .filter(Boolean);
  if (lines.length < 3) return null;

  const headerLabels = parseMarkdownTableCells(lines[0]);
  if (headerLabels.length < 2) return null;

  const dataLines = lines.slice(2);
  const dataRows = dataLines.map(parseMarkdownTableCells).filter((cells) => cells.length >= 2);
  if (!dataRows.length) return null;

  let valueColIndex = 1;
  for (let c = 1; c < headerLabels.length; c++) {
    const numericCount = dataRows.reduce((count, row) => (parseNumericCellValue(row[c]) != null ? count + 1 : count), 0);
    if (numericCount > 0) {
      valueColIndex = c;
      break;
    }
  }

  const labels = [];
  const values = [];
  dataRows.forEach((row) => {
    const label = String((row[0] == null ? "" : row[0])).trim();
    const value = parseNumericCellValue(row[valueColIndex]);
    if (!label || value == null) return;
    labels.push(label);
    values.push(value);
  });

  if (!labels.length || !values.length) return null;

  const chartType = normalizeChartTypeForChartJs(detectRequestedChartTypeFromPrompt(promptText) || "bar");
  const datasetLabel = String(headerLabels[valueColIndex] || "Value").trim() || "Value";
  const palette = [
    "#007bff", "#6c757d", "#28a745", "#ffc107", "#dc3545",
    "#20c997", "#6610f2", "#e83e8c", "#fd7e14", "#17a2b8"
  ];
  const colors = labels.map((_, index) => palette[index % palette.length]);

  return {
    type: chartType,
    data: {
      labels,
      datasets: [
        {
          label: datasetLabel,
          data: values,
          backgroundColor: colors,
          borderColor: colors,
          borderWidth: 1
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: { display: false, text: "" }
      }
    }
  };
}

function extractRenderableChartConfigs(responseText, promptText) {
  const source = String(responseText || "");
  const blockRegex = /```(chartjs|json)\s*([\s\S]*?)(```|$)/gi;
  const chartConfigs = [];

  let rebuiltText = "";
  let lastIndex = 0;
  let match;

  while ((match = blockRegex.exec(source)) !== null) {
    const fullBlock = match[0];
    const lang = (match[1] || "").toLowerCase();
    const blockBody = (match[2] || "").trim();
    const blockStart = match.index;
    const blockEnd = blockStart + fullBlock.length;

    rebuiltText += source.slice(lastIndex, blockStart);
    lastIndex = blockEnd;

    let keepAsText = true;
    const isChartCandidate = lang === "chartjs" || (lang === "json" && hasChartConfigHints(blockBody));

    if (isChartCandidate && blockBody) {
      try {
        const configs = coerceRenderableChartConfigs(tryParseJsonRobust(blockBody));
        if (configs.length > 0) {
          chartConfigs.push(...configs);
          keepAsText = false;
          console.log("[CHART_PARSE] extracted renderable chart config from fenced block", {
            language: lang,
            source: "fenced",
            chartCount: configs.length,
            hasDatasets: configs.some((cfg) => !!(cfg && cfg.data && Array.isArray(cfg.data.datasets) && cfg.data.datasets.length))
          });
        }
      } catch (e) {
        console.warn("Skipping non-renderable chart candidate block:", e);
      }
    }

    if (keepAsText) rebuiltText += fullBlock;
  }

  rebuiltText += source.slice(lastIndex);

  if (chartConfigs.length === 0) {
    const trimmed = String(source || "").trim();
    if (trimmed && (trimmed.startsWith("{") || trimmed.startsWith("["))) {
      try {
        const configs = coerceRenderableChartConfigs(tryParseJsonRobust(trimmed));
        if (configs.length > 0) {
          chartConfigs.push(...configs);
          rebuiltText = "";
          console.log("[CHART_PARSE] extracted renderable chart config from full JSON response", {
            source: "full-response-json",
            chartCount: configs.length,
            hasDatasets: configs.some((cfg) => !!(cfg && cfg.data && Array.isArray(cfg.data.datasets) && cfg.data.datasets.length))
          });
        }
      } catch (e) {
        console.warn("[CHART_PARSE] full-response JSON parse skipped:", e);
      }
    }
  }

  if (chartConfigs.length === 0) {
    const tableDerivedConfig = buildChartConfigFromHtmlTable(source, promptText);
    if (tableDerivedConfig && isRenderableChartConfig(tableDerivedConfig)) {
      chartConfigs.push(tableDerivedConfig);
      console.log("[CHART_PARSE] derived chart config from HTML table fallback", {
        source: "html-table-fallback",
        chartType: tableDerivedConfig.type,
        labelsCount: Array.isArray(tableDerivedConfig.data && tableDerivedConfig.data.labels)
          ? tableDerivedConfig.data.labels.length
          : 0
      });
    }
  }

  if (chartConfigs.length === 0) {
    const mdTableDerivedConfig = buildChartConfigFromMarkdownTable(source, promptText);
    if (mdTableDerivedConfig && isRenderableChartConfig(mdTableDerivedConfig)) {
      chartConfigs.push(mdTableDerivedConfig);
      console.log("[CHART_PARSE] derived chart config from Markdown table fallback", {
        source: "markdown-table-fallback",
        chartType: mdTableDerivedConfig.type,
        labelsCount: Array.isArray(mdTableDerivedConfig.data && mdTableDerivedConfig.data.labels)
          ? mdTableDerivedConfig.data.labels.length
          : 0
      });
    }
  }

  return { chartConfigs, textOnlyResponse: rebuiltText.trim() };
}

function looksLikeMermaidDiagram(raw) {
  return /^\s*(flowchart|graph|sequenceDiagram|classDiagram|stateDiagram|erDiagram|journey|gantt|pie|gitGraph|mindmap|timeline|quadrantChart)\b/im
    .test(String(raw || ""));
}

function looksLikeHtmlTree(raw) {
  const text = String(raw || "");
  if (!text.trim()) return false;
  if (/<script[\s\S]*?>/i.test(text)) return false;
  if (/<div[^>]*class\s*=\s*["'][^"']*\b(db-tree|tree)\b[^"']*["']/i.test(text)) return true;
  return /<style[\s\S]*<\/style>/i.test(text) && /<ul[\s\S]*<li/i.test(text);
}

function normalizeHtmlTreeMarkup(raw) {
  const source = String(raw || "").trim();
  if (!source) return "";

  let styleText = "";
  let bodyHtml = "";

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(source, "text/html");

    doc.querySelectorAll("style").forEach((styleEl) => {
      const css = String(styleEl.textContent || "").trim();
      if (css) styleText += (styleText ? "\n" : "") + css;
    });

    if (doc.body) {
      const clone = doc.body.cloneNode(true);
      clone.querySelectorAll("script, style").forEach((node) => node.remove());
      bodyHtml = String(clone.innerHTML || "").trim();
    }
  } catch (e) {}

  if (!bodyHtml) {
    bodyHtml = source
      .replace(/<!doctype[^>]*>/ig, "")
      .replace(/<\/?(html|head|body)[^>]*>/ig, "")
      .trim();
  }

  if (styleText) {
    return `<style>${styleText}</style>${bodyHtml}`;
  }
  return bodyHtml;
}

function sanitizeHtmlTreeMarkup(raw) {
  let safe = String(raw || "").trim();
  if (!safe) return "";
  safe = safe.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "");
  safe = safe.replace(/\son\w+\s*=\s*"[^"]*"/gi, "");
  safe = safe.replace(/\son\w+\s*=\s*'[^']*'/gi, "");
  safe = safe.replace(/\son\w+\s*=\s*[^\s>]+/gi, "");
  safe = safe.replace(/javascript:/gi, "");
  return safe;
}

function extractRenderableGraphBlocks(responseText) {
  const source = String(responseText || "");
  const blockRegex = /```(mermaid|html)\s*([\s\S]*?)(```|$)/gi;
  const graphBlocks = [];

  let rebuiltText = "";
  let lastIndex = 0;
  let match;

  while ((match = blockRegex.exec(source)) !== null) {
    const fullBlock = match[0];
    const lang = String(match[1] || "").toLowerCase();
    const blockBody = String(match[2] || "").trim();
    const blockStart = match.index;
    const blockEnd = blockStart + fullBlock.length;

    rebuiltText += source.slice(lastIndex, blockStart);
    lastIndex = blockEnd;

    let keepAsText = true;
    if (blockBody) {
      if (lang === "mermaid" && looksLikeMermaidDiagram(blockBody)) {
        graphBlocks.push({ type: "mermaid", content: blockBody });
        keepAsText = false;
      } else if (lang === "html" && looksLikeHtmlTree(blockBody)) {
        graphBlocks.push({ type: "html_tree", content: blockBody });
        keepAsText = false;
      }
    }

    if (keepAsText) rebuiltText += fullBlock;
  }

  rebuiltText += source.slice(lastIndex);

  const inlineHtmlTreeRegex =
    /<style[\s\S]*?<\/style>\s*<div[^>]*class\s*=\s*["'][^"']*\b(db-tree|tree)\b[^"']*["'][\s\S]*?<\/div>/i;
  const inlineHtmlMatch = rebuiltText.match(inlineHtmlTreeRegex);
  if (inlineHtmlMatch && inlineHtmlMatch[0] && looksLikeHtmlTree(inlineHtmlMatch[0])) {
    graphBlocks.push({ type: "html_tree", content: inlineHtmlMatch[0] });
    rebuiltText = rebuiltText.replace(inlineHtmlMatch[0], "");
  }

  const trimmedRemainder = rebuiltText.trim();
  if (trimmedRemainder && looksLikeHtmlTree(trimmedRemainder)) {
    graphBlocks.push({ type: "html_tree", content: trimmedRemainder });
    rebuiltText = "";
  }

  return { graphBlocks, textOnlyResponse: rebuiltText.trim() };
}

var askOracleMermaidLoadPromise = null;
var askOracleMermaidInitialized = false;
var ASK_ORACLE_VISUAL_BOX_CSS_ID = "ask-oracle-visual-box-css";
var ASK_ORACLE_VISUAL_HEIGHT_DEFAULT = 340;
var ASK_ORACLE_VISUAL_HEIGHT_MIN = 340;
var ASK_ORACLE_VISUAL_HEIGHT_MAX = 1800;
var askOracleChartJsLoadPromise = null;
var askOracleEchartsLoadPromise = null;

function ensureVisualBoxCss() {
  if (document.getElementById(ASK_ORACLE_VISUAL_BOX_CSS_ID)) return;
  const style = document.createElement("style");
  style.id = ASK_ORACLE_VISUAL_BOX_CSS_ID;
  style.textContent = `
    .ask-oracle-visual-panel {
      margin-top: 14px;
      border: 1px solid #d1d5db;
      border-radius: 10px;
      background: #f8fafc;
      overflow: hidden;
      min-width: 0;
    }
    .ask-oracle-visual-toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 8px 10px;
      background: #eef2ff;
      border-bottom: 1px solid #cbd5e1;
      flex-wrap: wrap;
    }
    .ask-oracle-visual-title {
      font-size: 12px;
      font-weight: 600;
      color: #1e3a8a;
      white-space: nowrap;
    }
    .ask-oracle-visual-actions {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }
    .ask-oracle-visual-btn {
      border: 1px solid #94a3b8;
      background: #ffffff;
      color: #1f2937;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 11px;
      line-height: 1.1;
      cursor: pointer;
    }
    .ask-oracle-visual-btn:hover {
      background: #f1f5f9;
    }
    .ask-oracle-visual-height-label {
      min-width: 56px;
      text-align: center;
      font-size: 11px;
      color: #334155;
      font-weight: 600;
    }
    .ask-oracle-visual-body {
      position: relative;
      width: 100%;
      min-height: ${ASK_ORACLE_VISUAL_HEIGHT_MIN}px;
      height: ${ASK_ORACLE_VISUAL_HEIGHT_DEFAULT}px;
      max-height: ${ASK_ORACLE_VISUAL_HEIGHT_MAX}px;
      overflow: auto;
      resize: vertical;
      padding: 8px;
      background: #ffffff;
      box-sizing: border-box;
    }
    .ask-oracle-visual-body canvas {
      width: 100% !important;
      height: 100% !important;
      display: block;
    }
    .ask-oracle-visual-body svg {
      width: 100% !important;
      height: auto !important;
      min-height: 100%;
      display: block;
    }
    .chart-container.ask-oracle-dashboard-grid {
      display: grid !important;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 16px;
      align-items: start;
      width: 100%;
    }
    .chart-container.ask-oracle-dashboard-grid .ask-oracle-visual-panel {
      margin-top: 0;
    }
    .chart-container.ask-oracle-dashboard-grid .ask-oracle-dashboard-span-full {
      grid-column: 1 / -1;
    }
    @media (max-width: 1100px) {
      .chart-container.ask-oracle-dashboard-grid {
        grid-template-columns: minmax(0, 1fr);
      }
      .chart-container.ask-oracle-dashboard-grid .ask-oracle-dashboard-span-full {
        grid-column: auto;
      }
    }
  `;
  document.head.appendChild(style);
}

function clampVisualHeight(heightPx) {
  const value = Number(heightPx);
  if (!Number.isFinite(value)) return ASK_ORACLE_VISUAL_HEIGHT_DEFAULT;
  return Math.max(ASK_ORACLE_VISUAL_HEIGHT_MIN, Math.min(ASK_ORACLE_VISUAL_HEIGHT_MAX, Math.round(value)));
}

function triggerVisualDownload(blob, fileName) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function downloadTextContentAsFile(content, fileName, mimeType) {
  const blob = new Blob([String(content || "")], { type: String(mimeType || "text/plain;charset=utf-8") });
  triggerVisualDownload(blob, fileName);
}

function downloadCanvasAsPng(canvasEl, fileName) {
  if (!canvasEl || typeof canvasEl.toDataURL !== "function") return;
  const pngUrl = canvasEl.toDataURL("image/png");
  const a = document.createElement("a");
  a.href = pngUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function downloadSvgElementAsSvg(svgEl, fileName) {
  if (!svgEl) return;
  const serializer = new XMLSerializer();
  const rawSvg = serializer.serializeToString(svgEl);
  const svgBlob = new Blob([rawSvg], { type: "image/svg+xml;charset=utf-8" });
  triggerVisualDownload(svgBlob, fileName);
}

function downloadSvgElementAsPng(svgEl, fileName) {
  if (!svgEl) return;
  const serializer = new XMLSerializer();
  const rawSvg = serializer.serializeToString(svgEl);
  const svgBlob = new Blob([rawSvg], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(svgBlob);
  const img = new Image();
  img.onload = function() {
    const width = Math.max(600, Math.round(svgEl.getBoundingClientRect().width || img.width || 1200));
    const height = Math.max(420, Math.round(svgEl.getBoundingClientRect().height || img.height || 700));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);
      downloadCanvasAsPng(canvas, fileName);
    }
    URL.revokeObjectURL(url);
  };
  img.onerror = function() {
    URL.revokeObjectURL(url);
  };
  img.src = url;
}

function createVisualPanel(titleText, options) {
  ensureVisualBoxCss();
  const opts = options || {};
  const panel = document.createElement("div");
  panel.className = "ask-oracle-visual-panel";

  const toolbar = document.createElement("div");
  toolbar.className = "ask-oracle-visual-toolbar";

  const title = document.createElement("div");
  title.className = "ask-oracle-visual-title";
  title.textContent = String(titleText || "Visualization");
  toolbar.appendChild(title);

  const actions = document.createElement("div");
  actions.className = "ask-oracle-visual-actions";

  const minusBtn = document.createElement("button");
  minusBtn.type = "button";
  minusBtn.className = "ask-oracle-visual-btn";
  minusBtn.textContent = "-";

  const heightLabel = document.createElement("span");
  heightLabel.className = "ask-oracle-visual-height-label";
  heightLabel.textContent = `${ASK_ORACLE_VISUAL_HEIGHT_DEFAULT}px`;

  const plusBtn = document.createElement("button");
  plusBtn.type = "button";
  plusBtn.className = "ask-oracle-visual-btn";
  plusBtn.textContent = "+";

  const resetBtn = document.createElement("button");
  resetBtn.type = "button";
  resetBtn.className = "ask-oracle-visual-btn";
  resetBtn.textContent = "Reset";

  actions.appendChild(minusBtn);
  actions.appendChild(heightLabel);
  actions.appendChild(plusBtn);
  actions.appendChild(resetBtn);

  if (opts.extraButtons && Array.isArray(opts.extraButtons)) {
    opts.extraButtons.forEach((btnConfig) => {
      if (!btnConfig || !btnConfig.label || typeof btnConfig.onClick !== "function") return;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "ask-oracle-visual-btn";
      btn.textContent = String(btnConfig.label);
      btn.addEventListener("click", btnConfig.onClick);
      actions.appendChild(btn);
    });
  }

  toolbar.appendChild(actions);
  panel.appendChild(toolbar);

  const body = document.createElement("div");
  body.className = "ask-oracle-visual-body";
  panel.appendChild(body);

  function applyHeight(nextHeight) {
    const clamped = clampVisualHeight(nextHeight);
    body.style.height = `${clamped}px`;
    heightLabel.textContent = `${clamped}px`;
    return clamped;
  }

  minusBtn.addEventListener("click", function() {
    applyHeight((body.getBoundingClientRect().height || ASK_ORACLE_VISUAL_HEIGHT_DEFAULT) - 120);
    if (typeof opts.onResize === "function") opts.onResize();
  });
  plusBtn.addEventListener("click", function() {
    applyHeight((body.getBoundingClientRect().height || ASK_ORACLE_VISUAL_HEIGHT_DEFAULT) + 120);
    if (typeof opts.onResize === "function") opts.onResize();
  });
  resetBtn.addEventListener("click", function() {
    applyHeight(ASK_ORACLE_VISUAL_HEIGHT_DEFAULT);
    if (typeof opts.onResize === "function") opts.onResize();
  });

  if (typeof ResizeObserver !== "undefined" && typeof opts.onResize === "function") {
    const observer = new ResizeObserver(function() {
      const h = clampVisualHeight(body.getBoundingClientRect().height || ASK_ORACLE_VISUAL_HEIGHT_DEFAULT);
      heightLabel.textContent = `${h}px`;
      opts.onResize();
    });
    observer.observe(body);
  }

  const initialHeight = clampVisualHeight(
    opts && Number.isFinite(Number(opts.initialHeight))
      ? Number(opts.initialHeight)
      : ASK_ORACLE_VISUAL_HEIGHT_DEFAULT
  );
  applyHeight(initialHeight);
  return { panel, body };
}

function initializeMermaidOnce() {
  if (askOracleMermaidInitialized || !window.mermaid || typeof window.mermaid.initialize !== "function") {
    return;
  }
  window.mermaid.initialize({
    startOnLoad: false,
    securityLevel: "strict",
    theme: "default",
    flowchart: {
      useMaxWidth: false,
      nodeSpacing: 70,
      rankSpacing: 90,
      padding: 14
    }
  });
  askOracleMermaidInitialized = true;
}

function ensureMermaidLoaded() {
  if (window.mermaid) {
    initializeMermaidOnce();
    return Promise.resolve(window.mermaid);
  }
  if (askOracleMermaidLoadPromise) return askOracleMermaidLoadPromise;

  askOracleMermaidLoadPromise = new Promise((resolve, reject) => {
    const existingScript = document.querySelector('script[src*="mermaid"]');
    if (existingScript) {
      existingScript.addEventListener("load", function onLoad() {
        existingScript.removeEventListener("load", onLoad);
        if (window.mermaid) {
          initializeMermaidOnce();
          resolve(window.mermaid);
        } else {
          reject(new Error("Mermaid loaded but window.mermaid is unavailable."));
        }
      }, { once: true });
      existingScript.addEventListener("error", function onError() {
        existingScript.removeEventListener("error", onError);
        reject(new Error("Failed to load Mermaid library."));
      }, { once: true });
      return;
    }

    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js";
    script.async = true;
    script.onload = function() {
      if (!window.mermaid) {
        reject(new Error("Mermaid script loaded but window.mermaid is undefined."));
        return;
      }
      initializeMermaidOnce();
      resolve(window.mermaid);
    };
    script.onerror = function() {
      reject(new Error("Failed to load Mermaid library."));
    };
    document.head.appendChild(script);
  }).catch((err) => {
    askOracleMermaidLoadPromise = null;
    throw err;
  });

  return askOracleMermaidLoadPromise;
}

function renderMermaidGraphIntoContainer(targetEl, definition, id, index) {
  if (!targetEl) return;
  if (!window.mermaid || typeof window.mermaid.render !== "function") {
    targetEl.innerHTML = `<pre style="white-space:pre-wrap;">${escapeHtml(definition)}</pre>`;
    return;
  }

  const renderId = `ask-oracle-mermaid-${id}-${index}-${Date.now()}`;

  try {
    const renderResult = window.mermaid.render(renderId, definition);
    if (renderResult && typeof renderResult.then === "function") {
      renderResult.then((output) => {
        const svg = output && output.svg ? output.svg : String(output || "");
        if (!svg.trim()) {
          throw new Error("Empty Mermaid output.");
        }
        targetEl.innerHTML = svg;
        if (output && typeof output.bindFunctions === "function") {
          try { output.bindFunctions(targetEl); } catch (e) {}
        }
      }).catch((err) => {
        targetEl.innerHTML =
          `<pre style="color:darkred; white-space:pre-wrap;">${escapeHtml("Mermaid render failed: " + (err && err.message ? err.message : String(err)))}</pre>`;
      });
      return;
    }

    if (typeof renderResult === "string") {
      targetEl.innerHTML = renderResult;
      return;
    }

    window.mermaid.render(renderId, definition, function(svgCode, bindFunctions) {
      targetEl.innerHTML = svgCode || "";
      if (typeof bindFunctions === "function") {
        try { bindFunctions(targetEl); } catch (e) {}
      }
    });
  } catch (err) {
    targetEl.innerHTML =
      `<pre style="color:darkred; white-space:pre-wrap;">${escapeHtml("Mermaid render failed: " + (err && err.message ? err.message : String(err)))}</pre>`;
  }
}

function getChartPanelTitle(cfg, fallbackIndex) {
  const chartCfg = cfg && typeof cfg === "object" ? cfg : {};
  const pluginTitle = chartCfg.options && chartCfg.options.plugins && chartCfg.options.plugins.title
    ? chartCfg.options.plugins.title.text
    : "";
  if (Array.isArray(pluginTitle)) {
    const joinedTitle = pluginTitle.map((part) => String(part || "").trim()).filter(Boolean).join(" - ");
    if (joinedTitle) return joinedTitle;
  }
  const explicitTitle = String(pluginTitle || "").trim();
  if (explicitTitle) return explicitTitle;

  const datasets = chartCfg.data && Array.isArray(chartCfg.data.datasets) ? chartCfg.data.datasets : [];
  const datasetLabel = datasets.length > 0 ? String(datasets[0].label || "").trim() : "";
  if (datasetLabel) return datasetLabel;

  return `Chart ${fallbackIndex}`;
}

function applyDashboardChartLayout(chartContainer, chartCount) {
  if (!chartContainer) return;
  chartContainer.classList.remove("ask-oracle-dashboard-grid");
  chartContainer.style.width = "100%";
  chartContainer.style.gap = "";
  chartContainer.style.display = chartCount > 0 ? "block" : "none";

  if (chartCount > 1) {
    chartContainer.classList.add("ask-oracle-dashboard-grid");
    chartContainer.style.display = "grid";
  }
}

function stabilizeChartJsAfterLayout(chartInstance, canvasEl) {
  if (!chartInstance || !canvasEl) return;

  let attempts = 0;
  const refresh = function() {
    if (!canvasEl.isConnected) return;
    attempts++;

    const rect = canvasEl.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      try { chartInstance.resize(); } catch (e) {}
      try { chartInstance.update("none"); } catch (e) {}
    }

    if (attempts < 3) {
      window.requestAnimationFrame(refresh);
    }
  };

  // The NL2SQL response and its chart container are revealed in this same
  // rendering turn. Wait for layout/paint before asking Chart.js to size its
  // backing canvas; otherwise some browsers intermittently paint it black.
  window.requestAnimationFrame(function() {
    window.requestAnimationFrame(refresh);
  });
  window.setTimeout(refresh, 150);
  window.setTimeout(refresh, 400);
}

function renderAllCharts(chartConfigs, id) {
  if (!chartConfigs || chartConfigs.length === 0) {
    console.log("📊 No charts found.");
    return;
  }

  const chartContainer = document.getElementById(`chart-container-${id}`);
  if (!chartContainer) {
    console.error("Chart container not found:", `chart-container-${id}`);
    return;
  }

  chartContainer.innerHTML = "";
  applyDashboardChartLayout(chartContainer, chartConfigs.length);
  let renderedCount = 0;
  const removePanelIfEmpty = function(panelNode) {
    if (panelNode && panelNode.parentNode) {
      try { panelNode.parentNode.removeChild(panelNode); } catch (e) {}
    }
    if (!chartContainer.children.length) {
      chartContainer.innerHTML = "";
      chartContainer.style.display = "none";
    }
  };

  chartConfigs.forEach((cfg, index) => {
    let panel = null;
    try {
      const chartIndex = renderedCount + 1;
      const canvasId = `chart-canvas-${id}-${chartIndex}`;
      let chartInstance = null;
      let canvasEl = null;
      let echartsEl = null;

      const resolvedCfg = cfg && typeof cfg === "object" ? cfg : {};
      const resolvedType = normalizeChartTypeForChartJs(resolvedCfg.type);
      const cfgOptions = resolvedCfg.options && typeof resolvedCfg.options === "object" ? resolvedCfg.options : {};
      const chartConfig = resolvedType ? { ...resolvedCfg, type: resolvedType } : resolvedCfg;
      const echartsType = getEchartsRendererType(resolvedType || (chartConfig && chartConfig.type));

      panel = createVisualPanel(getChartPanelTitle(chartConfig, chartIndex), {
        initialHeight: echartsType ? 780 : ASK_ORACLE_VISUAL_HEIGHT_DEFAULT,
        onResize: function() {
          if (chartInstance && typeof chartInstance.resize === "function") {
            chartInstance.resize();
          } else if (echartsEl && window.echarts && typeof window.echarts.getInstanceByDom === "function") {
            try {
              const instance = window.echarts.getInstanceByDom(echartsEl);
              if (instance && typeof instance.resize === "function") instance.resize();
            } catch (e) {}
          }
        },
        extraButtons: [
          {
            label: "PNG",
            onClick: function() {
              if (canvasEl) {
                downloadCanvasAsPng(canvasEl, `ask-oracle-chart-${id}-${chartIndex}.png`);
                return;
              }
              if (echartsEl) {
                downloadEchartsDivAsPng(echartsEl, `ask-oracle-chart-${id}-${chartIndex}.png`);
              }
            }
          },
          {
            label: "JSON",
            onClick: function() {
              downloadTextContentAsFile(
                JSON.stringify(chartConfig, null, 2),
                `ask-oracle-chart-${id}-${chartIndex}.json`,
                "application/json;charset=utf-8"
              );
            }
          }
        ]
      });
      if (chartConfigs.length > 1 && chartConfigs.length % 2 === 1 && index === chartConfigs.length - 1) {
        panel.panel.classList.add("ask-oracle-dashboard-span-full");
      }
      chartContainer.appendChild(panel.panel);

      const useEchartsRenderer = !!(
        (echartsType === "sunburst" && !isSunburstChartSupported()) ||
        echartsType === "heatmap" ||
        echartsType === "bar_race" ||
        echartsType === "treemap" ||
        echartsType === "sankey" ||
        echartsType === "gauge" ||
        echartsType === "kpi_card" ||
        echartsType === "gantt" ||
        echartsType === "candlestick" ||
        echartsType === "waterfall" ||
        echartsType === "calendar_heatmap" ||
        echartsType === "streamgraph" ||
        echartsType === "network_graph" ||
        echartsType === "chord"
      );

      if (useEchartsRenderer) {
        echartsEl = document.createElement("div");
        echartsEl.id = `echarts-${echartsType}-${id}-${chartIndex}-${Date.now()}`;
        echartsEl.style.width = "100%";
        echartsEl.style.height = "100%";
        panel.body.appendChild(echartsEl);
        renderedCount++;

        ensureEchartsLoaded()
          .then(() => renderChartWithEcharts(echartsEl, chartConfig, echartsType))
          .catch((err) => {
            console.warn(`Skipping invalid chart config ${index + 1}:`, err);
            removePanelIfEmpty(panel.panel);
          });
        console.log(`✅ Chart ${renderedCount} rendered successfully`);
        return;
      }

      canvasEl = document.createElement("canvas");
      canvasEl.id = canvasId;
      panel.body.appendChild(canvasEl);

      const ctx = canvasEl.getContext("2d");
      if (resolvedType === "boxplot" && !isBoxPlotChartSupported()) {
        throw new Error("Box plot plugin is unavailable.");
      }
      chartInstance = new Chart(ctx, {
        ...chartConfig,
        options: {
          ...cfgOptions,
          responsive: true,
          maintainAspectRatio: false
        }
      });
      stabilizeChartJsAfterLayout(chartInstance, canvasEl);
      renderedCount++;
      console.log(`✅ Chart ${renderedCount} rendered successfully`);
    } catch (e) {
      console.warn(`Skipping invalid chart config ${index + 1}:`, e);
      removePanelIfEmpty(panel && panel.panel);
    }
  });

  chartContainer.style.display = renderedCount > 0 ? "block" : "none";
}

function renderGraphBlocks(graphBlocks, id) {
  if (!graphBlocks || graphBlocks.length === 0) return;

  const chartContainer = document.getElementById(`chart-container-${id}`);
  if (!chartContainer) {
    console.error("Graph container not found:", `chart-container-${id}`);
    return;
  }

  chartContainer.style.display = "block";
  chartContainer.style.height = "auto";

  graphBlocks.forEach((block, index) => {
    if (!block || !block.content) return;
    const graphIndex = index + 1;
    let wrapper = null;

    if (block.type === "mermaid") {
      const panel = createVisualPanel(`Graph ${graphIndex} (Mermaid)`, {
        extraButtons: [
          {
            label: "SVG",
            onClick: function() {
              const svgEl = wrapper ? wrapper.querySelector("svg") : null;
              if (!svgEl) return;
              downloadSvgElementAsSvg(svgEl, `ask-oracle-graph-${id}-${graphIndex}.svg`);
            }
          },
          {
            label: "PNG",
            onClick: function() {
              const svgEl = wrapper ? wrapper.querySelector("svg") : null;
              if (!svgEl) return;
              downloadSvgElementAsPng(svgEl, `ask-oracle-graph-${id}-${graphIndex}.png`);
            }
          },
          {
            label: "Source",
            onClick: function() {
              downloadTextContentAsFile(block.content, `ask-oracle-graph-${id}-${graphIndex}.mmd`, "text/plain;charset=utf-8");
            }
          }
        ]
      });
      wrapper = panel.body;
      chartContainer.appendChild(panel.panel);
    } else if (block.type === "html_tree") {
      const panel = createVisualPanel(`Graph ${graphIndex} (HTML Tree)`, {
        extraButtons: [
          {
            label: "HTML",
            onClick: function() {
              downloadTextContentAsFile(block.content, `ask-oracle-graph-${id}-${graphIndex}.html`, "text/html;charset=utf-8");
            }
          }
        ]
      });
      wrapper = panel.body;
      chartContainer.appendChild(panel.panel);
    } else {
      const panel = createVisualPanel(`Graph ${graphIndex}`, {});
      wrapper = panel.body;
      chartContainer.appendChild(panel.panel);
    }
    if (chartContainer.classList.contains("ask-oracle-dashboard-grid")) {
      wrapper.parentElement.classList.add("ask-oracle-dashboard-span-full");
    }
    wrapper.classList.add("llm-graph-block");
    wrapper.style.overflowX = "auto";

    if (block.type === "html_tree") {
      const normalized = normalizeHtmlTreeMarkup(block.content);
      const safeHtml = sanitizeHtmlTreeMarkup(normalized);
      wrapper.innerHTML = safeHtml || `<pre style="white-space:pre-wrap;">${escapeHtml(block.content)}</pre>`;
      return;
    }

    if (block.type === "mermaid") {
      wrapper.innerHTML = '<div style="font-size:12px;color:#64748b;">Rendering Mermaid diagram...</div>';
      ensureMermaidLoaded()
        .then(() => renderMermaidGraphIntoContainer(wrapper, block.content, id, index))
        .catch((err) => {
          wrapper.innerHTML =
            `<pre style="color:darkred; white-space:pre-wrap;">${escapeHtml("Mermaid render failed: " + (err && err.message ? err.message : String(err)))}</pre>`;
        });
      return;
    }

    wrapper.innerHTML = `<pre style="white-space:pre-wrap;">${escapeHtml(block.content)}</pre>`;
  });
}

function isFunnelChartSupported() {
  if (!window.Chart) return false;
  try {
    // Chart.js v3/v4 registry path
    if (Chart.registry && typeof Chart.registry.getController === "function") {
      return !!Chart.registry.getController("funnel");
    }
  } catch (e) {}

  try {
    // Older Chart.js plugin path
    if (Chart.controllers) {
      return !!(Chart.controllers.funnel || Chart.controllers.Funnel);
    }
  } catch (e) {}

  return false;
}

function toFiniteNumber(value) {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function normalizeSunburstText(value) {
  return String(value == null ? "" : value).trim();
}

function splitSunburstPathTokens(labelText) {
  const text = normalizeSunburstText(labelText);
  if (!text) return [];
  if (/[/>]|->|→|\|/.test(text)) {
    return text
      .split(/\s*(?:\/|>|->|→|\|)\s*/g)
      .map((token) => normalizeSunburstText(token))
      .filter(Boolean);
  }
  return [text];
}

function buildDelimitedSunburstHierarchy(labelsInput, valuesInput) {
  const labels = Array.isArray(labelsInput) ? labelsInput : [];
  const values = Array.isArray(valuesInput) ? valuesInput : [];
  const nodeMap = new Map();

  function ensureNode(id, label, parentId) {
    if (!id) return;
    if (!nodeMap.has(id)) {
      nodeMap.set(id, {
        id: String(id),
        label: String(label || id),
        parent: parentId ? String(parentId) : "",
        value: 0
      });
      return;
    }
    const existing = nodeMap.get(id);
    if (label && !existing.label) existing.label = String(label);
    if (parentId != null && parentId !== "" && !existing.parent) {
      existing.parent = String(parentId);
    }
  }

  labels.forEach((rawLabel, index) => {
    const pathTokens = splitSunburstPathTokens(rawLabel);
    if (!pathTokens.length) return;
    const numericValue = toFiniteNumber(values[index]);
    const leafValue = numericValue == null ? 0 : numericValue;

    let parentId = "";
    pathTokens.forEach((token, tokenIndex) => {
      const id = pathTokens.slice(0, tokenIndex + 1).join("::");
      ensureNode(id, token, parentId);
      parentId = id;
    });

    const leafId = pathTokens.join("::");
    const leafNode = nodeMap.get(leafId);
    if (leafNode) leafNode.value += leafValue;
  });

  const nodes = Array.from(nodeMap.values());
  nodes
    .slice()
    .sort((a, b) => b.id.split("::").length - a.id.split("::").length)
    .forEach((node) => {
      if (!node.parent) return;
      const parentNode = nodeMap.get(node.parent);
      if (parentNode) parentNode.value += node.value;
    });

  const materialized = nodes.filter((node) => node.value > 0);
  if (!materialized.length) return null;

  return {
    ids: materialized.map((node) => node.id),
    labels: materialized.map((node) => node.label),
    parents: materialized.map((node) => node.parent || ""),
    values: materialized.map((node) => node.value)
  };
}

function normalizeSunburstKey(value) {
  return normalizeSunburstText(value).toLowerCase().replace(/[^a-z0-9]/g, "");
}

function isSunburstMeasureKey(keyName) {
  const key = normalizeSunburstKey(keyName);
  if (!key) return false;
  return /(value|values|amount|total|sales|revenue|count|metric|size|qty|quantity|measure|sum|y)$/.test(key);
}

function buildSunburstHierarchyFromRows(rowsInput) {
  const rows = Array.isArray(rowsInput)
    ? rowsInput.filter((row) => row && typeof row === "object" && !Array.isArray(row))
    : [];
  if (!rows.length) return null;

  if (rows.some((row) => Array.isArray(row.children) || Array.isArray(row.childNodes))) {
    return null;
  }

  const preferredPathKeys = [
    "region", "continent", "country", "state", "province", "city",
    "projecttype", "requirement", "category", "subcategory", "segment",
    "type", "group", "team", "agent", "task", "tool",
    "level1", "level2", "level3", "level4", "level5",
    "label", "name"
  ];
  const keyAliasRank = new Map(preferredPathKeys.map((key, idx) => [key, idx]));

  function pickPathTokens(row) {
    if (Array.isArray(row.path)) {
      const pathTokens = row.path.map((v) => normalizeSunburstText(v)).filter(Boolean);
      if (pathTokens.length > 1) return pathTokens;
    }

    if (Array.isArray(row.labels)) {
      const labelTokens = row.labels.map((v) => normalizeSunburstText(v)).filter(Boolean);
      if (labelTokens.length > 1) return labelTokens;
    }

    const entryMeta = Object.entries(row).map(([key, rawValue]) => {
      const text = normalizeSunburstText(rawValue);
      const numberValue = toFiniteNumber(rawValue);
      return {
        key,
        rank: keyAliasRank.has(normalizeSunburstKey(key)) ? keyAliasRank.get(normalizeSunburstKey(key)) : 9999,
        isMeasure: isSunburstMeasureKey(key),
        isScalar: rawValue == null || ["string", "number", "boolean"].includes(typeof rawValue),
        text,
        hasText: !!text,
        hasNumber: numberValue != null
      };
    });

    const prioritized = entryMeta
      .filter((entry) => entry.rank < 9999 && !entry.isMeasure && entry.hasText)
      .sort((a, b) => a.rank - b.rank)
      .map((entry) => entry.text);
    if (prioritized.length > 1) return prioritized;

    const fallback = entryMeta
      .filter((entry) => entry.isScalar && !entry.isMeasure && entry.hasText && !entry.hasNumber)
      .map((entry) => entry.text);
    if (fallback.length > 1) return fallback.slice(0, 5);

    const maybePath = splitSunburstPathTokens(row.label || row.name || "");
    if (maybePath.length > 1) return maybePath;

    return [];
  }

  function pickValue(row) {
    const entries = Object.entries(row);
    for (let i = 0; i < entries.length; i++) {
      const [key, value] = entries[i];
      if (!isSunburstMeasureKey(key)) continue;
      const numeric = toFiniteNumber(value);
      if (numeric != null) return numeric;
    }
    return null;
  }

  const nodeMap = new Map();
  function ensureNode(id, label, parentId) {
    if (!id) return;
    if (!nodeMap.has(id)) {
      nodeMap.set(id, {
        id: String(id),
        label: String(label || id),
        parent: parentId ? String(parentId) : "",
        value: 0
      });
      return;
    }
    const existing = nodeMap.get(id);
    if (label && !existing.label) existing.label = String(label);
    if (parentId != null && parentId !== "" && !existing.parent) existing.parent = String(parentId);
  }

  let processed = 0;
  rows.forEach((row) => {
    const pathTokens = pickPathTokens(row);
    if (pathTokens.length < 2) return;

    const value = pickValue(row);
    if (value == null || value <= 0) return;

    let parentId = "";
    pathTokens.forEach((token, tokenIdx) => {
      const id = pathTokens.slice(0, tokenIdx + 1).join("::");
      ensureNode(id, token, parentId);
      parentId = id;
    });

    const leafId = pathTokens.join("::");
    const leaf = nodeMap.get(leafId);
    if (leaf) leaf.value += value;
    processed += 1;
  });

  if (!processed) return null;

  const nodes = Array.from(nodeMap.values());
  nodes
    .slice()
    .sort((a, b) => b.id.split("::").length - a.id.split("::").length)
    .forEach((node) => {
      if (!node.parent) return;
      const parentNode = nodeMap.get(node.parent);
      if (parentNode) parentNode.value += node.value;
    });

  const materialized = nodes.filter((node) => node.value > 0);
  if (!materialized.length) return null;

  return {
    ids: materialized.map((node) => node.id),
    labels: materialized.map((node) => node.label),
    parents: materialized.map((node) => node.parent || ""),
    values: materialized.map((node) => node.value)
  };
}

function buildSunburstTraceFromChartConfig(chartConfig) {
  const cfg = chartConfig && typeof chartConfig === "object" ? chartConfig : {};
  const data = cfg.data && typeof cfg.data === "object" ? cfg.data : {};
  const datasets = Array.isArray(data.datasets) ? data.datasets : [];
  const dataset = datasets.length && datasets[0] && typeof datasets[0] === "object" ? datasets[0] : {};

  let labels = Array.isArray(data.labels) ? data.labels : null;
  let parents = Array.isArray(data.parents) ? data.parents : null;
  let values = Array.isArray(data.values) ? data.values : null;
  let ids = Array.isArray(data.ids) ? data.ids : null;

  if ((!labels || !parents) && Array.isArray(dataset.labels) && Array.isArray(dataset.parents)) {
    labels = dataset.labels;
    parents = dataset.parents;
    if (!values && Array.isArray(dataset.values)) values = dataset.values;
    if (!values && Array.isArray(dataset.data)) values = dataset.data;
    if (!ids && Array.isArray(dataset.ids)) ids = dataset.ids;
  }

  if (labels && parents) {
    const normalizedLabels = labels.map((value, idx) => {
      const labelText = normalizeSunburstText(value);
      return labelText || `Node ${idx + 1}`;
    });
    const normalizedParents = parents.map((value) => normalizeSunburstText(value));
    let normalizedValues = Array.isArray(values)
      ? values.map((value) => {
          const num = toFiniteNumber(value);
          return num == null ? 0 : num;
        })
      : normalizedLabels.map(() => 1);

    if (normalizedValues.length !== normalizedLabels.length) {
      normalizedValues = normalizedLabels.map((_, idx) => {
        const num = toFiniteNumber(values && values[idx]);
        return num == null ? 1 : num;
      });
    }

    const normalizedIds = Array.isArray(ids) && ids.length === normalizedLabels.length
      ? ids.map((value, idx) => normalizeSunburstText(value) || `node-${idx + 1}`)
      : normalizedLabels.map((label, idx) => {
          const parent = normalizedParents[idx];
          return parent ? `${parent}::${label}::${idx}` : `${label}::${idx}`;
        });

    return {
      ids: normalizedIds,
      labels: normalizedLabels,
      parents: normalizedParents,
      values: normalizedValues
    };
  }

  const hierarchicalDatasetData = Array.isArray(dataset.data) &&
    dataset.data.some(
      (entry) =>
        entry &&
        typeof entry === "object" &&
        !Array.isArray(entry) &&
        (Array.isArray(entry.children) || Array.isArray(entry.childNodes))
    )
      ? dataset.data
      : null;
  const treeSource = dataset.tree || data.tree || hierarchicalDatasetData;
  if (treeSource && typeof treeSource === "object") {
    const nodes = [];
    function walkTree(node, parentId, indexPrefix) {
      if (!node || typeof node !== "object") return;
      const label =
        normalizeSunburstText(node.label) ||
        normalizeSunburstText(node.name) ||
        normalizeSunburstText(node.id) ||
        `Node ${nodes.length + 1}`;
      const id = normalizeSunburstText(node.id) || `${indexPrefix}-${label}`;
      const resolvedValue =
        toFiniteNumber(node.value) ??
        toFiniteNumber(node.v) ??
        toFiniteNumber(node.size) ??
        toFiniteNumber(node.count);
      const value = resolvedValue == null ? 0 : resolvedValue;

      nodes.push({
        id,
        label,
        parent: parentId || "",
        value,
        hasOwnValue: resolvedValue != null,
        depth: String(indexPrefix || "").split(".").length
      });

      const children = Array.isArray(node.children)
        ? node.children
        : (Array.isArray(node.childNodes) ? node.childNodes : []);
      children.forEach((child, childIdx) => walkTree(child, id, `${indexPrefix}.${childIdx + 1}`));
    }

    const roots = Array.isArray(treeSource) ? treeSource : [treeSource];
    roots.forEach((root, rootIdx) => walkTree(root, "", `r${rootIdx + 1}`));

    if (nodes.length) {
      const nodeById = new Map(nodes.map((node) => [node.id, node]));
      const byDepth = nodes.slice().sort((a, b) => (b.depth || 0) - (a.depth || 0));
      byDepth.forEach((node) => {
        if (!node.parent) return;
        const parentNode = nodeById.get(node.parent);
        if (!parentNode) return;
        if (!parentNode.hasOwnValue) {
          parentNode.value += Math.max(0, toFiniteNumber(node.value) || 0);
        }
      });
      return {
        ids: nodes.map((node) => node.id),
        labels: nodes.map((node) => node.label),
        parents: nodes.map((node) => node.parent),
        values: nodes.map((node) => node.value)
      };
    }
  }

  const rowHierarchy = buildSunburstHierarchyFromRows(
    Array.isArray(data.rows)
      ? data.rows
      : (Array.isArray(dataset.data) ? dataset.data : (Array.isArray(dataset.rows) ? dataset.rows : null))
  );
  if (rowHierarchy) return rowHierarchy;

  const fallbackLabels = Array.isArray(data.labels) ? data.labels : (Array.isArray(dataset.labels) ? dataset.labels : []);
  const fallbackValues = Array.isArray(dataset.data)
    ? dataset.data
    : (Array.isArray(data.values) ? data.values : (Array.isArray(dataset.values) ? dataset.values : []));

  const hierarchy = buildDelimitedSunburstHierarchy(fallbackLabels, fallbackValues);
  if (hierarchy) return hierarchy;

  throw new Error("Sunburst config must provide labels/parents/values or hierarchical labels.");
}

function formatSunburstNumber(value, maxFractionDigits) {
  const numericValue = toFiniteNumber(value);
  if (numericValue == null) return "";
  return numericValue.toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: Number.isFinite(maxFractionDigits) ? maxFractionDigits : 2
  });
}

function formatSunburstPercent(value, totalValue) {
  const valueNum = toFiniteNumber(value);
  const totalNum = toFiniteNumber(totalValue);
  if (valueNum == null || totalNum == null || totalNum <= 0) return "";
  return `(${((valueNum / totalNum) * 100).toFixed(2)}%)`;
}

function parseHexColor(hex) {
  const raw = String(hex || "").trim().replace("#", "");
  const normalized = raw.length === 3
    ? raw.split("").map((c) => c + c).join("")
    : raw;
  if (!/^[0-9a-fA-F]{6}$/.test(normalized)) {
    return null;
  }
  return {
    r: parseInt(normalized.slice(0, 2), 16),
    g: parseInt(normalized.slice(2, 4), 16),
    b: parseInt(normalized.slice(4, 6), 16)
  };
}

function toHexChannel(channel) {
  const clamped = Math.max(0, Math.min(255, Math.round(channel)));
  return clamped.toString(16).padStart(2, "0");
}

function blendHexColor(sourceHex, targetHex, ratio) {
  const from = parseHexColor(sourceHex);
  const to = parseHexColor(targetHex);
  if (!from || !to) return sourceHex || targetHex || "#999999";
  const safeRatio = Math.max(0, Math.min(1, Number(ratio) || 0));
  const r = from.r + ((to.r - from.r) * safeRatio);
  const g = from.g + ((to.g - from.g) * safeRatio);
  const b = from.b + ((to.b - from.b) * safeRatio);
  return `#${toHexChannel(r)}${toHexChannel(g)}${toHexChannel(b)}`;
}

function getSunburstRootColor(label, index, fallbackPalette) {
  const text = String(label || "").toLowerCase();
  const themeMap = [
    { keys: ["americas", "america", "north america", "south america"], color: "#2f80ed" },
    { keys: ["europe", "eu"], color: "#36b66a" },
    { keys: ["asia", "apac"], color: "#f5a623" },
    { keys: ["oceania", "australia", "anz"], color: "#8a63d2" },
    { keys: ["middle east", "mea"], color: "#e25578" },
    { keys: ["africa"], color: "#b86a2a" }
  ];
  for (let i = 0; i < themeMap.length; i++) {
    if (themeMap[i].keys.some((k) => text.includes(k))) {
      return themeMap[i].color;
    }
  }
  return fallbackPalette[index % fallbackPalette.length];
}

function buildSunburstDisplayTree(nodes, rootColor, depth) {
  const list = Array.isArray(nodes) ? nodes : [];
  const safeDepth = Math.max(1, Number(depth) || 1);
  const siblings = Math.max(1, list.length);

  return list.map((node, idx) => {
    const depthRatio = safeDepth <= 1
      ? 0
      : Math.min(
          0.74,
          (safeDepth - 1) * 0.17 + (siblings > 1 ? (idx / (siblings - 1)) * 0.14 : 0.08)
        );
    const fillColor = safeDepth === 1
      ? rootColor
      : blendHexColor(rootColor, "#ffffff", depthRatio);
    const borderColor = blendHexColor(fillColor, "#ffffff", 0.2);

    return {
      name: node.name,
      value: node.value,
      itemStyle: {
        color: fillColor,
        borderColor,
        borderWidth: 2
      },
      children: buildSunburstDisplayTree(node.children, rootColor, safeDepth + 1)
    };
  });
}

function renderSunburstWithEcharts(targetEl, chartConfig) {
  if (!targetEl) throw new Error("Sunburst target container not found.");
  if (!window.echarts || typeof window.echarts.init !== "function") {
    throw new Error("Apache ECharts library is unavailable.");
  }

  const trace = buildSunburstTraceFromChartConfig(chartConfig);
  const nodeMap = new Map();
  const labelToId = new Map();

  for (let i = 0; i < trace.ids.length; i++) {
    const id = String(trace.ids[i]);
    const label = String(trace.labels[i] || `Node ${i + 1}`);
    const parent = String(trace.parents[i] || "");
    const value = toFiniteNumber(trace.values[i]) || 0;
    nodeMap.set(id, {
      id,
      parent,
      name: label,
      value,
      children: []
    });
    if (!labelToId.has(label)) labelToId.set(label, id);
  }

  const roots = [];
  nodeMap.forEach((node) => {
    const parentById = node.parent && nodeMap.has(node.parent) ? nodeMap.get(node.parent) : null;
    const parentByLabel = !parentById && node.parent && labelToId.has(node.parent)
      ? nodeMap.get(labelToId.get(node.parent))
      : null;
    const parentNode = parentById || parentByLabel;
    if (parentNode && parentNode.id !== node.id) {
      parentNode.children.push(node);
    } else {
      roots.push(node);
    }
  });

  function computeDepth(nodes, depth) {
    const list = Array.isArray(nodes) ? nodes : [];
    if (!list.length) return depth;
    let maxDepth = depth;
    list.forEach((node) => {
      const childDepth = computeDepth(node.children, depth + 1);
      if (childDepth > maxDepth) maxDepth = childDepth;
    });
    return maxDepth;
  }

  function buildSunburstLevels(maxDepth) {
    const levels = [{}];
    const safeDepth = Math.max(1, Number(maxDepth || 1));
    const inner = 22;
    const outer = 98;
    const span = outer - inner;

    for (let depth = 1; depth <= safeDepth; depth++) {
      const r0 = inner + ((depth - 1) * span / safeDepth);
      const r = inner + (depth * span / safeDepth);
      const fontSize = depth === 1
        ? 14
        : (depth === 2 ? 11 : Math.max(8, 10 - (depth - 3) * 0.7));
      levels.push({
        r0: `${r0.toFixed(2)}%`,
        r: `${r.toFixed(2)}%`,
        itemStyle: { borderColor: "#ffffff", borderWidth: depth <= 2 ? 3 : 2 },
        label: {
          rotate: 0,
          color: depth <= 2 ? "#ffffff" : "#1f2937",
          fontSize: Math.round(fontSize),
          fontWeight: depth <= 2 ? 700 : 600,
          lineHeight: Math.round(fontSize * 1.0),
          minAngle: depth >= safeDepth ? 0.6 : 0.8,
          overflow: "break"
        }
      });
    }
    return levels;
  }

  const maxDepth = computeDepth(roots, 1);
  const totalValue = roots.reduce((sum, node) => sum + (toFiniteNumber(node.value) || 0), 0);
  if (!roots.length || totalValue <= 0) {
    throw new Error("No valid numeric measure found for sunburst chart.");
  }
  const palette = [
    "#2f80ed", "#36b66a", "#f5a623", "#8a63d2", "#e25578",
    "#17a2b8", "#fd7e14", "#6c757d", "#007bff", "#8bc34a"
  ];
  const themedRoots = roots.map((node, idx) => {
    const rootColor = getSunburstRootColor(node.name, idx, palette);
    return buildSunburstDisplayTree([node], rootColor, 1)[0];
  });
  const levels = buildSunburstLevels(maxDepth);
  const titleText =
    (chartConfig && chartConfig.options && chartConfig.options.plugins &&
      chartConfig.options.plugins.title && chartConfig.options.plugins.title.text) ||
    (chartConfig && chartConfig.options && chartConfig.options.title &&
      chartConfig.options.title.text) ||
    "";

  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    backgroundColor: "#ffffff",
    color: palette,
    tooltip: {
      trigger: "item",
      formatter: function(params) {
        const nodeValue = toFiniteNumber(params && params.value);
        const pct = formatSunburstPercent(nodeValue, totalValue);
        const amount = formatSunburstNumber(nodeValue, 2);
        return `<b>${escapeHtml(params.name || "")}</b><br/>${escapeHtml(amount)} ${escapeHtml(pct)}`;
      }
    },
    graphic: [
      {
        type: "text",
        left: "center",
        top: "46.5%",
        style: {
          text: "Total",
          fill: "#333333",
          font: "700 12px Inter, Segoe UI, Arial, sans-serif",
          textAlign: "center"
        }
      },
      {
        type: "text",
        left: "center",
        top: "51.2%",
        style: {
          text: formatSunburstNumber(totalValue, 2),
          fill: "#222222",
          font: "700 20px Inter, Segoe UI, Arial, sans-serif",
          textAlign: "center"
        }
      }
    ],
    series: [{
      type: "sunburst",
      radius: ["30%", "94%"],
      center: ["50%", "52%"],
      sort: "desc",
      nodeClick: false,
      minAngle: 1.2,
      emphasis: { focus: "ancestor" },
      itemStyle: { borderColor: "#ffffff", borderWidth: 1 },
      label: {
        show: true,
        rotate: 0,
        overflow: "break",
        lineHeight: 10,
        minAngle: 1.2,
        color: "#1f2937",
        formatter: function(params) {
          const name = String((params && params.name) || "");
          const nodeValue = toFiniteNumber(params && params.value);
          if (nodeValue == null || !name) return name;

          const path = Array.isArray(params && params.treePathInfo) ? params.treePathInfo : [];
          const depth = Math.max(1, path.length - 1);
          const pct = totalValue > 0 ? (nodeValue / totalValue) * 100 : 0;
          const amount = formatSunburstNumber(nodeValue, 2);
          const pctText = formatSunburstPercent(nodeValue, totalValue);

          if (depth === 1) {
            return `${name}\n${amount}`;
          }
          if (depth === 2) {
            if (pct >= 8) return `${name}\n${amount}`;
            if (pct >= 4) return name;
            return "";
          }
          if (pct >= 6) return `${name}\n${pctText}`;
          if (pct >= 4) return name;
          return "";
        }
      },
      labelLayout: { hideOverlap: true },
      levels: levels,
      data: themedRoots
    }]
  });

  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function getEchartsRendererType(typeValue) {
  const type = normalizeChartTypeToken(typeValue);
  if (!type) return "";
  if (type === "sunburst") return "sunburst";
  if (isHeatmapChartType(type)) return "heatmap";
  if (isBarRaceChartType(type)) return "bar_race";
  if (type === "treemap") return "treemap";
  if (type === "sankey") return "sankey";
  if (type === "gauge") return "gauge";
  if (type === "kpi_card") return "kpi_card";
  if (type === "gantt") return "gantt";
  if (type === "candlestick" || type === "ohlc") return "candlestick";
  if (type === "waterfall") return "waterfall";
  if (type === "calendar_heatmap") return "calendar_heatmap";
  if (type === "streamgraph" || type === "themeriver") return "streamgraph";
  if (type === "network_graph") return "network_graph";
  if (type === "chord") return "chord";
  return "";
}

function disposeEchartsInstance(targetEl) {
  if (!targetEl || !window.echarts || typeof window.echarts.getInstanceByDom !== "function") return;
  if (targetEl.__askOracleRaceTimerId) {
    clearInterval(targetEl.__askOracleRaceTimerId);
    targetEl.__askOracleRaceTimerId = null;
  }
  try {
    const chart = window.echarts.getInstanceByDom(targetEl);
    if (chart && typeof chart.dispose === "function") chart.dispose();
  } catch (e) {}
}

function buildHeatmapSeriesFromChartConfig(chartConfig) {
  const cfg = chartConfig && typeof chartConfig === "object" ? chartConfig : {};
  const data = cfg.data && typeof cfg.data === "object" ? cfg.data : {};
  const fields = data.fields && typeof data.fields === "object" ? data.fields : {};

  const xLabels = [];
  const yLabels = [];
  const xIndex = Object.create(null);
  const yIndex = Object.create(null);
  const points = [];

  function ensureX(value) {
    const text = String(value == null ? "" : value).trim();
    if (!text) return -1;
    if (!Object.prototype.hasOwnProperty.call(xIndex, text)) {
      xIndex[text] = xLabels.length;
      xLabels.push(text);
    }
    return xIndex[text];
  }

  function ensureY(value) {
    const text = String(value == null ? "" : value).trim();
    if (!text) return -1;
    if (!Object.prototype.hasOwnProperty.call(yIndex, text)) {
      yIndex[text] = yLabels.length;
      yLabels.push(text);
    }
    return yIndex[text];
  }

  function addPoint(xValue, yValue, rawValue) {
    const x = ensureX(xValue);
    const y = ensureY(yValue);
    const value = toFiniteNumber(rawValue);
    if (x < 0 || y < 0 || value == null) return;
    points.push([x, y, value]);
  }

  const matrix = Array.isArray(data.matrix) ? data.matrix : (Array.isArray(data.values) ? data.values : null);
  const matrixX = Array.isArray(data.x_labels) ? data.x_labels : (Array.isArray(data.xLabels) ? data.xLabels : null);
  const matrixY = Array.isArray(data.y_labels) ? data.y_labels : (Array.isArray(data.yLabels) ? data.yLabels : null);
  if (matrix && matrixX && matrixY) {
    matrixY.forEach((yLabel, rowIdx) => {
      const row = Array.isArray(matrix[rowIdx]) ? matrix[rowIdx] : [];
      matrixX.forEach((xLabel, colIdx) => addPoint(xLabel, yLabel, row[colIdx]));
    });
  }

  const labels = Array.isArray(data.labels) ? data.labels : [];
  const datasets = Array.isArray(data.datasets) ? data.datasets : [];
  if (!points.length && labels.length && datasets.length) {
    datasets.forEach((dataset, idx) => {
      const yLabel = String((dataset && (dataset.label || dataset.name)) || `Row ${idx + 1}`).trim();
      const rowValues = Array.isArray(dataset && dataset.data) ? dataset.data : [];
      labels.forEach((xLabel, colIdx) => addPoint(xLabel, yLabel, rowValues[colIdx]));
    });
  }

  const rows = Array.isArray(data.rows)
    ? data.rows
    : (Array.isArray(data.points) ? data.points : (Array.isArray(cfg.rows) ? cfg.rows : null));
  if (!points.length && Array.isArray(rows) && rows.length) {
    if (Array.isArray(rows[0])) {
      rows.forEach((row) => addPoint(row[0], row[1], row[2]));
    } else if (rows[0] && typeof rows[0] === "object") {
      const sample = rows[0];
      const keys = Object.keys(sample);
      const explicitX = String(fields.x || fields.x_field || data.x_field || "").trim();
      const explicitY = String(fields.y || fields.y_field || data.y_field || "").trim();
      const explicitValue = String(fields.value || fields.value_field || data.value_field || "").trim();

      if (explicitX && explicitY && explicitValue) {
        rows.forEach((row) => addPoint(row[explicitX], row[explicitY], row[explicitValue]));
      } else {
        const firstKey = keys[0];
        const remainingKeys = keys.slice(1);
        const isWide = remainingKeys.length >= 2 &&
          remainingKeys.some((key) => toFiniteNumber(sample[key]) != null);
        if (isWide) {
          rows.forEach((row) => {
            const yLabel = row[firstKey];
            remainingKeys.forEach((xKey) => addPoint(xKey, yLabel, row[xKey]));
          });
        } else {
          const valueKey = keys.find((key) => toFiniteNumber(sample[key]) != null) || keys[keys.length - 1];
          const dims = keys.filter((key) => key !== valueKey);
          const xKey = dims[0] || keys[0];
          const yKey = dims[1] || dims[0] || keys[1] || keys[0];
          rows.forEach((row) => addPoint(row[xKey], row[yKey], row[valueKey]));
        }
      }
    }
  }

  if (!points.length) {
    throw new Error("Heatmap config needs matrix, datasets, or rows with x/y/value.");
  }
  return { xLabels, yLabels, points };
}

function renderHeatmapWithEcharts(targetEl, chartConfig) {
  if (!targetEl) throw new Error("Heatmap target container not found.");
  if (!window.echarts || typeof window.echarts.init !== "function") {
    throw new Error("Apache ECharts library is unavailable.");
  }

  const heatmapData = buildHeatmapSeriesFromChartConfig(chartConfig);
  const maxValue = heatmapData.points.reduce((max, point) => Math.max(max, point[2]), 0);
  const titleText =
    (chartConfig && chartConfig.options && chartConfig.options.plugins &&
      chartConfig.options.plugins.title && chartConfig.options.plugins.title.text) ||
    (chartConfig && chartConfig.options && chartConfig.options.title &&
      chartConfig.options.title.text) ||
    "";

  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    backgroundColor: "#ffffff",
    title: {
      text: String(titleText || ""),
      left: "center",
      top: 4,
      textStyle: { fontSize: 16, fontWeight: 700, color: "#1f2937" }
    },
    tooltip: {
      position: "top",
      formatter: function(params) {
        const value = params && params.data ? params.data[2] : "";
        const xValue = params && params.name ? params.name : "";
        const yValue = params && params.seriesName ? params.seriesName : "";
        return yValue
          ? `<b>${escapeHtml(yValue)}</b><br/>${escapeHtml(xValue)}: ${escapeHtml(value)}`
          : `${escapeHtml(xValue)}: ${escapeHtml(value)}`;
      }
    },
    grid: { left: 120, right: 36, top: 46, bottom: 70 },
    xAxis: {
      type: "category",
      data: heatmapData.xLabels,
      splitArea: { show: true },
      axisLabel: {
        color: "#334155",
        interval: 0,
        rotate: heatmapData.xLabels.length > 8 ? 40 : 0
      }
    },
    yAxis: {
      type: "category",
      data: heatmapData.yLabels,
      splitArea: { show: true },
      axisLabel: { color: "#334155" }
    },
    visualMap: {
      min: 0,
      max: Math.max(1, maxValue),
      calculable: true,
      orient: "vertical",
      right: 2,
      top: "center",
      textStyle: { color: "#334155" }
    },
    series: [{
      name: "",
      type: "heatmap",
      data: heatmapData.points,
      label: {
        show: heatmapData.points.length <= 60,
        color: "#0f172a",
        formatter: function(params) {
          const value = params && params.data ? params.data[2] : "";
          return value == null ? "" : String(value);
        }
      },
      emphasis: {
        itemStyle: {
          shadowBlur: 12,
          shadowColor: "rgba(15, 23, 42, 0.35)"
        }
      }
    }]
  });

  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function buildBarRaceFramesFromChartConfig(chartConfig) {
  const cfg = chartConfig && typeof chartConfig === "object" ? chartConfig : {};
  const data = cfg.data && typeof cfg.data === "object" ? cfg.data : {};
  const fields = data.fields && typeof data.fields === "object" ? data.fields : {};

  const framesByTime = Object.create(null);
  const times = [];
  const categories = new Set();

  function ensureFrame(timeValue) {
    const key = String(timeValue == null ? "" : timeValue).trim() || "Current";
    if (!Object.prototype.hasOwnProperty.call(framesByTime, key)) {
      framesByTime[key] = { time: key, values: Object.create(null) };
      times.push(key);
    }
    return framesByTime[key];
  }

  function addValue(timeValue, categoryValue, rawValue) {
    const category = String(categoryValue == null ? "" : categoryValue).trim();
    const value = toFiniteNumber(rawValue);
    if (!category || value == null) return;
    const frame = ensureFrame(timeValue);
    frame.values[category] = value;
    categories.add(category);
  }

  const explicitFrames = Array.isArray(data.frames) ? data.frames : (Array.isArray(cfg.frames) ? cfg.frames : null);
  if (explicitFrames && explicitFrames.length) {
    explicitFrames.forEach((frame, idx) => {
      const timeLabel = String((frame && (frame.time || frame.period || frame.name)) || `Frame ${idx + 1}`).trim();
      const valuesMap = frame && frame.values && typeof frame.values === "object" ? frame.values : null;
      if (valuesMap) {
        Object.keys(valuesMap).forEach((category) => addValue(timeLabel, category, valuesMap[category]));
        return;
      }
      const rows = Array.isArray(frame && frame.rows) ? frame.rows : [];
      rows.forEach((row) => {
        if (Array.isArray(row)) addValue(timeLabel, row[0], row[1]);
        else if (row && typeof row === "object") {
          const keys = Object.keys(row);
          const valueKey = keys.find((key) => toFiniteNumber(row[key]) != null) || keys[keys.length - 1];
          const categoryKey = keys.find((key) => key !== valueKey) || keys[0];
          addValue(timeLabel, row[categoryKey], row[valueKey]);
        }
      });
    });
  }

  const timeline = Array.isArray(data.timeline) ? data.timeline : (Array.isArray(data.periods) ? data.periods : null);
  const timelineSeries = data.series && typeof data.series === "object" && !Array.isArray(data.series) ? data.series : null;
  if (times.length === 0 && timeline && timelineSeries) {
    timeline.forEach((timeLabel, idx) => {
      Object.keys(timelineSeries).forEach((category) => {
        const seriesValues = timelineSeries[category];
        const value = Array.isArray(seriesValues) ? seriesValues[idx] : (seriesValues && seriesValues[timeLabel]);
        addValue(timeLabel, category, value);
      });
    });
  }

  const rows = Array.isArray(data.rows)
    ? data.rows
    : (Array.isArray(cfg.rows) ? cfg.rows : (Array.isArray(data.points) ? data.points : null));
  if (times.length === 0 && Array.isArray(rows) && rows.length) {
    if (Array.isArray(rows[0])) {
      rows.forEach((row) => addValue(row[0], row[1], row[2]));
    } else if (rows[0] && typeof rows[0] === "object") {
      const sample = rows[0];
      const keys = Object.keys(sample);
      const timeKey = String(fields.time || fields.time_field || data.time_field || "").trim() ||
        keys.find((key) => /time|date|period|month|year/i.test(key)) ||
        keys[0];
      const valueKey = String(fields.value || fields.value_field || data.value_field || "").trim() ||
        keys.find((key) => key !== timeKey && toFiniteNumber(sample[key]) != null) ||
        keys[keys.length - 1];
      const categoryKey = String(fields.category || fields.category_field || data.category_field || "").trim() ||
        keys.find((key) => key !== timeKey && key !== valueKey) ||
        keys[1] ||
        keys[0];
      rows.forEach((row) => addValue(row[timeKey], row[categoryKey], row[valueKey]));
    }
  }

  const labels = Array.isArray(data.labels) ? data.labels : [];
  const values = Array.isArray(data.values)
    ? data.values
    : (Array.isArray(data.datasets) && data.datasets[0] && Array.isArray(data.datasets[0].data)
      ? data.datasets[0].data
      : []);
  if (times.length === 0 && labels.length && values.length) {
    labels.forEach((label, idx) => addValue("Current", label, values[idx]));
  }

  if (times.length === 0) {
    throw new Error("Bar race config needs frames, timeline series, or rows with time/category/value.");
  }

  return {
    categories: Array.from(categories),
    frames: times.map((time) => framesByTime[time])
  };
}

function renderBarRaceWithEcharts(targetEl, chartConfig) {
  if (!targetEl) throw new Error("Bar race target container not found.");
  if (!window.echarts || typeof window.echarts.init !== "function") {
    throw new Error("Apache ECharts library is unavailable.");
  }

  disposeEchartsInstance(targetEl);

  const race = buildBarRaceFramesFromChartConfig(chartConfig);
  const maxBars = Math.max(3, Math.min(12, Number(
    chartConfig && chartConfig.options && chartConfig.options.maxBars
  ) || 8));

  const frames = race.frames.map((frame) => {
    const ranked = race.categories
      .slice()
      .sort((a, b) => (frame.values[b] || 0) - (frame.values[a] || 0))
      .slice(0, maxBars);
    return {
      time: frame.time,
      categories: ranked,
      values: ranked.map((name) => frame.values[name] || 0)
    };
  });
  const maxValue = frames.reduce((max, frame) => {
    const frameMax = frame.values.length ? Math.max.apply(null, frame.values) : 0;
    return Math.max(max, frameMax);
  }, 0);

  const titleText =
    (chartConfig && chartConfig.options && chartConfig.options.plugins &&
      chartConfig.options.plugins.title && chartConfig.options.plugins.title.text) ||
    (chartConfig && chartConfig.options && chartConfig.options.title &&
      chartConfig.options.title.text) ||
    "";

  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    backgroundColor: "#ffffff",
    grid: { top: 58, right: 38, bottom: 24, left: 132 },
    xAxis: {
      type: "value",
      max: Math.max(1, Math.ceil(maxValue * 1.12)),
      axisLabel: { color: "#334155" }
    },
    yAxis: {
      type: "category",
      inverse: true,
      data: frames[0].categories,
      axisLabel: { color: "#0f172a", fontWeight: 600 }
    },
    tooltip: {
      trigger: "item",
      formatter: function(params) {
        return `${escapeHtml(params.name || "")}: <b>${escapeHtml(params.value)}</b>`;
      }
    },
    title: {
      text: String(titleText || ""),
      left: "center",
      top: 6,
      textStyle: { fontSize: 16, fontWeight: 700, color: "#1f2937" }
    },
    graphic: [{
      type: "text",
      right: 12,
      bottom: 6,
      style: {
        text: String(frames[0].time || ""),
        fill: "#334155",
        font: "600 16px Segoe UI, Arial, sans-serif"
      }
    }],
    series: [{
      realtimeSort: true,
      name: "",
      type: "bar",
      data: frames[0].values,
      label: {
        show: true,
        position: "right",
        valueAnimation: true,
        color: "#0f172a"
      },
      itemStyle: {
        borderRadius: [0, 8, 8, 0]
      }
    }],
    animationDuration: 600,
    animationDurationUpdate: 900,
    animationEasing: "linear",
    animationEasingUpdate: "linear"
  });

  if (frames.length > 1) {
    let frameIndex = 0;
    const intervalMs = Math.max(900, Number(
      chartConfig && chartConfig.options && chartConfig.options.playInterval
    ) || 1400);
    targetEl.__askOracleRaceTimerId = setInterval(() => {
      frameIndex = (frameIndex + 1) % frames.length;
      const frame = frames[frameIndex];
      chart.setOption({
        yAxis: { data: frame.categories },
        series: [{ data: frame.values }],
        graphic: [{ style: { text: String(frame.time || "") } }]
      });
    }, intervalMs);
  }

  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function getEchartsChartConfigTitle(chartConfig, fallback) {
  const title =
    (chartConfig && chartConfig.options && chartConfig.options.plugins &&
      chartConfig.options.plugins.title && chartConfig.options.plugins.title.text) ||
    (chartConfig && chartConfig.options && chartConfig.options.title &&
      chartConfig.options.title.text) ||
    fallback ||
    "";
  return String(title || "").trim();
}

function getEchartsTabularRowsFromChartConfig(chartConfig) {
  const cfg = chartConfig && typeof chartConfig === "object" ? chartConfig : {};
  const data = cfg.data && typeof cfg.data === "object" ? cfg.data : {};
  if (Array.isArray(data.rows)) return data.rows;
  if (Array.isArray(data.points)) return data.points;
  if (Array.isArray(cfg.rows)) return cfg.rows;
  if (Array.isArray(cfg.points)) return cfg.points;

  const labels = Array.isArray(data.labels) ? data.labels : [];
  const datasets = Array.isArray(data.datasets) ? data.datasets : [];
  if (!labels.length || !datasets.length) return [];

  if (datasets.length === 1) {
    const first = datasets[0];
    const values = Array.isArray(first && first.data) ? first.data : [];
    return labels.map((label, idx) => ({ label: label, value: values[idx] }));
  }

  return labels.map((label, idx) => {
    const row = { label: label };
    datasets.forEach((ds, dsIdx) => {
      const key = String((ds && ds.label) || `series_${dsIdx + 1}`).trim() || `series_${dsIdx + 1}`;
      row[key] = Array.isArray(ds && ds.data) ? ds.data[idx] : null;
    });
    return row;
  });
}

function buildEchartsCategoryValuePairs(chartConfig) {
  const rows = getEchartsTabularRowsFromChartConfig(chartConfig);
  const pairs = [];
  if (!Array.isArray(rows) || !rows.length) return pairs;

  if (Array.isArray(rows[0])) {
    rows.forEach((row) => {
      if (!Array.isArray(row) || row.length < 2) return;
      const name = String(row[0] == null ? "" : row[0]).trim();
      const value = toFiniteNumber(row[1]);
      if (!name || value == null) return;
      pairs.push({ name, value });
    });
    return pairs;
  }

  const sample = rows[0];
  const keys = Object.keys(sample || {});
  const numericKey = keys.find((key) => toFiniteNumber(sample[key]) != null) || "value";
  const categoryKey = keys.find((key) => key !== numericKey) || "label";

  rows.forEach((row, idx) => {
    const category = String((row && row[categoryKey]) == null ? "" : row[categoryKey]).trim() || `Item ${idx + 1}`;
    const value = toFiniteNumber(row && row[numericKey]);
    if (value == null) return;
    pairs.push({ name: category, value });
  });
  return pairs;
}

function toEchartsTimestamp(value) {
  if (value == null || value === "") return null;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const parsed = Date.parse(String(value));
  return Number.isFinite(parsed) ? parsed : null;
}

function formatEchartsNumber(value) {
  const numeric = toFiniteNumber(value);
  if (numeric == null) return "";
  return numeric.toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: Math.abs(numeric) >= 1000 ? 1 : 2
  });
}

function renderTreemapWithEcharts(targetEl, chartConfig) {
  const pairs = buildEchartsCategoryValuePairs(chartConfig);
  if (!pairs.length) throw new Error("Treemap needs category + value data.");
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: {
      text: getEchartsChartConfigTitle(chartConfig, "Treemap"),
      left: "center",
      top: 6
    },
    tooltip: {
      formatter: function(params) {
        return `${escapeHtml(params.name || "")}: ${escapeHtml(params.value)}`;
      }
    },
    series: [{
      type: "treemap",
      roam: true,
      breadcrumb: { show: true },
      data: pairs.map((item) => ({ name: item.name, value: item.value }))
    }]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderSankeyWithEcharts(targetEl, chartConfig) {
  const rows = getEchartsTabularRowsFromChartConfig(chartConfig);
  const links = [];
  const nodeSet = new Set();

  rows.forEach((row) => {
    if (Array.isArray(row) && row.length >= 3) {
      const source = String(row[0] == null ? "" : row[0]).trim();
      const target = String(row[1] == null ? "" : row[1]).trim();
      const value = toFiniteNumber(row[2]);
      if (!source || !target || value == null) return;
      links.push({ source, target, value });
      nodeSet.add(source);
      nodeSet.add(target);
      return;
    }
    if (!row || typeof row !== "object") return;
    const keys = Object.keys(row);
    const sourceKey = keys.find((k) => /^(source|from|src|origin)$/i.test(k)) || keys[0];
    const targetKey = keys.find((k) => /^(target|to|dest|destination)$/i.test(k)) || keys[1];
    const valueKey = keys.find((k) => /^(value|amount|weight|count|flow)$/i.test(k)) || keys[2];
    const source = String(row[sourceKey] == null ? "" : row[sourceKey]).trim();
    const target = String(row[targetKey] == null ? "" : row[targetKey]).trim();
    const value = toFiniteNumber(row[valueKey]);
    if (!source || !target || value == null) return;
    links.push({ source, target, value });
    nodeSet.add(source);
    nodeSet.add(target);
  });

  if (!links.length) throw new Error("Sankey needs source/target/value rows.");
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: {
      text: getEchartsChartConfigTitle(chartConfig, "Sankey"),
      left: "center",
      top: 6
    },
    tooltip: { trigger: "item" },
    series: [{
      type: "sankey",
      emphasis: { focus: "adjacency" },
      data: Array.from(nodeSet).map((name) => ({ name })),
      links: links,
      lineStyle: { curveness: 0.45 }
    }]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderGaugeWithEcharts(targetEl, chartConfig) {
  const pairs = buildEchartsCategoryValuePairs(chartConfig);
  const value = pairs.length ? pairs[0].value : toFiniteNumber(chartConfig && chartConfig.value);
  if (value == null) throw new Error("Gauge needs a numeric value.");
  const name = pairs.length ? pairs[0].name : "";
  const titleText = getEchartsChartConfigTitle(chartConfig, "");
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: titleText ? { text: titleText, left: "center", top: 6 } : undefined,
    series: [{
      type: "gauge",
      progress: { show: true, width: 18 },
      axisLine: { lineStyle: { width: 18 } },
      detail: { valueAnimation: true, formatter: "{value}" },
      data: [{ value, name }]
    }]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderKpiCardWithEcharts(targetEl, chartConfig) {
  const pairs = buildEchartsCategoryValuePairs(chartConfig);
  const value = pairs.length ? pairs[0].value : toFiniteNumber(chartConfig && chartConfig.value);
  if (value == null) throw new Error("KPI card needs a numeric value.");
  const metricName = pairs.length ? pairs[0].name : "";
  const title = getEchartsChartConfigTitle(chartConfig, "");
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    backgroundColor: "#ffffff",
    title: title ? { text: title, left: "center", top: 6 } : undefined,
    graphic: [
      {
        type: "text",
        left: "center",
        top: "40%",
        style: {
          text: metricName,
          fill: "#64748b",
          font: "600 14px Segoe UI, Arial, sans-serif",
          textAlign: "center"
        }
      },
      {
        type: "text",
        left: "center",
        top: "50%",
        style: {
          text: formatEchartsNumber(value),
          fill: "#0f172a",
          font: "700 36px Segoe UI, Arial, sans-serif",
          textAlign: "center"
        }
      }
    ]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderCandlestickWithEcharts(targetEl, chartConfig) {
  const rows = getEchartsTabularRowsFromChartConfig(chartConfig);
  const categories = [];
  const values = [];
  rows.forEach((row, idx) => {
    if (Array.isArray(row) && row.length >= 5) {
      const open = toFiniteNumber(row[1]);
      const close = toFiniteNumber(row[2]);
      const low = toFiniteNumber(row[3]);
      const high = toFiniteNumber(row[4]);
      if (open == null || close == null || low == null || high == null) return;
      categories.push(String(row[0] == null ? `P${idx + 1}` : row[0]));
      values.push([open, close, low, high]);
      return;
    }
    if (!row || typeof row !== "object") return;
    const keys = Object.keys(row);
    const labelKey = keys.find((k) => /(date|time|label|period|day|month)/i.test(k)) || keys[0];
    const openKey = keys.find((k) => /^open$/i.test(k));
    const closeKey = keys.find((k) => /^close$/i.test(k));
    const lowKey = keys.find((k) => /^low$/i.test(k));
    const highKey = keys.find((k) => /^high$/i.test(k));
    if (!openKey || !closeKey || !lowKey || !highKey) return;
    const open = toFiniteNumber(row[openKey]);
    const close = toFiniteNumber(row[closeKey]);
    const low = toFiniteNumber(row[lowKey]);
    const high = toFiniteNumber(row[highKey]);
    if (open == null || close == null || low == null || high == null) return;
    categories.push(String(row[labelKey] == null ? `P${idx + 1}` : row[labelKey]));
    values.push([open, close, low, high]);
  });

  if (!values.length) throw new Error("Candlestick/OHLC needs open, close, low, high data.");
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: { text: getEchartsChartConfigTitle(chartConfig, "Candlestick"), left: "center", top: 6 },
    tooltip: { trigger: "axis" },
    xAxis: { type: "category", data: categories, scale: true },
    yAxis: { scale: true },
    series: [{ type: "candlestick", data: values }]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderWaterfallWithEcharts(targetEl, chartConfig) {
  const pairs = buildEchartsCategoryValuePairs(chartConfig);
  if (!pairs.length) throw new Error("Waterfall needs category + value data.");
  let cumulative = 0;
  const base = [];
  const delta = [];
  pairs.forEach((item) => {
    base.push(cumulative);
    delta.push(item.value);
    cumulative += item.value;
  });
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: { text: getEchartsChartConfigTitle(chartConfig, "Waterfall"), left: "center", top: 6 },
    tooltip: { trigger: "axis", axisPointer: { type: "shadow" } },
    xAxis: { type: "category", data: pairs.map((p) => p.name) },
    yAxis: { type: "value" },
    series: [
      {
        type: "bar",
        stack: "total",
        silent: true,
        itemStyle: { borderColor: "transparent", color: "transparent" },
        emphasis: { itemStyle: { borderColor: "transparent", color: "transparent" } },
        data: base
      },
      {
        type: "bar",
        stack: "total",
        data: delta,
        label: {
          show: true,
          position: "top",
          formatter: function(params) {
            return formatEchartsNumber(params.value);
          }
        }
      }
    ]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderCalendarHeatmapWithEcharts(targetEl, chartConfig) {
  const rows = getEchartsTabularRowsFromChartConfig(chartConfig);
  const points = [];
  rows.forEach((row) => {
    if (Array.isArray(row) && row.length >= 2) {
      const dateText = String(row[0] == null ? "" : row[0]).trim();
      const value = toFiniteNumber(row[1]);
      if (!dateText || value == null) return;
      points.push([dateText, value]);
      return;
    }
    if (!row || typeof row !== "object") return;
    const keys = Object.keys(row);
    const dateKey = keys.find((k) => /(date|day|time)/i.test(k)) || keys[0];
    const valueKey = keys.find((k) => /(value|count|total|amount|metric)/i.test(k)) || keys[1];
    const dateText = String(row[dateKey] == null ? "" : row[dateKey]).trim();
    const value = toFiniteNumber(row[valueKey]);
    if (!dateText || value == null) return;
    points.push([dateText, value]);
  });

  if (!points.length) throw new Error("Calendar heatmap needs date + value rows.");
  const timestamps = points.map((item) => toEchartsTimestamp(item[0])).filter((v) => v != null);
  const minTs = timestamps.length ? Math.min.apply(null, timestamps) : Date.now();
  const maxTs = timestamps.length ? Math.max.apply(null, timestamps) : Date.now();
  const rangeStart = new Date(minTs);
  const rangeEnd = new Date(maxTs);
  const range = [
    `${rangeStart.getFullYear()}-${String(rangeStart.getMonth() + 1).padStart(2, "0")}-${String(rangeStart.getDate()).padStart(2, "0")}`,
    `${rangeEnd.getFullYear()}-${String(rangeEnd.getMonth() + 1).padStart(2, "0")}-${String(rangeEnd.getDate()).padStart(2, "0")}`
  ];
  const maxValue = points.reduce((max, item) => Math.max(max, item[1]), 0);

  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: { text: getEchartsChartConfigTitle(chartConfig, "Calendar Heatmap"), left: "center", top: 6 },
    tooltip: {},
    visualMap: {
      min: 0,
      max: Math.max(1, maxValue),
      orient: "horizontal",
      left: "center",
      top: 36
    },
    calendar: {
      top: 90,
      left: 40,
      right: 40,
      cellSize: ["auto", 18],
      range: range
    },
    series: [{
      type: "heatmap",
      coordinateSystem: "calendar",
      data: points
    }]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderStreamgraphWithEcharts(targetEl, chartConfig) {
  const rows = getEchartsTabularRowsFromChartConfig(chartConfig);
  const source = [];
  rows.forEach((row) => {
    if (Array.isArray(row) && row.length >= 3) {
      const timeValue = String(row[0] == null ? "" : row[0]).trim();
      const value = toFiniteNumber(row[1]);
      const seriesName = String(row[2] == null ? "" : row[2]).trim();
      if (!timeValue || !seriesName || value == null) return;
      source.push([timeValue, value, seriesName]);
      return;
    }
    if (!row || typeof row !== "object") return;
    const keys = Object.keys(row);
    const timeKey = keys.find((k) => /(date|time|period|month|year)/i.test(k)) || keys[0];
    const valueKey = keys.find((k) => /(value|amount|count|metric|total)/i.test(k)) || keys[1];
    const nameKey = keys.find((k) => /(series|group|category|type|name)/i.test(k) && k !== timeKey && k !== valueKey) || keys[2];
    const timeValue = String(row[timeKey] == null ? "" : row[timeKey]).trim();
    const value = toFiniteNumber(row[valueKey]);
    const seriesName = String(row[nameKey] == null ? "" : row[nameKey]).trim();
    if (!timeValue || !seriesName || value == null) return;
    source.push([timeValue, value, seriesName]);
  });

  if (!source.length) throw new Error("Streamgraph needs time/value/series rows.");
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: { text: getEchartsChartConfigTitle(chartConfig, "Streamgraph"), left: "center", top: 6 },
    tooltip: { trigger: "axis" },
    singleAxis: { type: "time", top: 48, bottom: 30 },
    series: [{ type: "themeRiver", coordinateSystem: "singleAxis", data: source }]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderNetworkWithEcharts(targetEl, chartConfig) {
  const rows = getEchartsTabularRowsFromChartConfig(chartConfig);
  const edges = [];
  const nodeSet = new Set();
  rows.forEach((row) => {
    if (Array.isArray(row) && row.length >= 2) {
      const source = String(row[0] == null ? "" : row[0]).trim();
      const target = String(row[1] == null ? "" : row[1]).trim();
      const value = toFiniteNumber(row[2]);
      if (!source || !target) return;
      edges.push({ source, target, value: value == null ? 1 : value });
      nodeSet.add(source);
      nodeSet.add(target);
      return;
    }
    if (!row || typeof row !== "object") return;
    const keys = Object.keys(row);
    const sourceKey = keys.find((k) => /^(source|from|src|origin)$/i.test(k)) || keys[0];
    const targetKey = keys.find((k) => /^(target|to|dest|destination)$/i.test(k)) || keys[1];
    const valueKey = keys.find((k) => /^(value|weight|count|strength)$/i.test(k)) || keys[2];
    const source = String(row[sourceKey] == null ? "" : row[sourceKey]).trim();
    const target = String(row[targetKey] == null ? "" : row[targetKey]).trim();
    const value = toFiniteNumber(row[valueKey]);
    if (!source || !target) return;
    edges.push({ source, target, value: value == null ? 1 : value });
    nodeSet.add(source);
    nodeSet.add(target);
  });

  if (!edges.length) throw new Error("Network graph needs source/target rows.");
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: { text: getEchartsChartConfigTitle(chartConfig, "Network Graph"), left: "center", top: 6 },
    tooltip: {},
    series: [{
      type: "graph",
      layout: "force",
      roam: true,
      edgeSymbol: ["none", "arrow"],
      label: { show: true },
      force: { repulsion: 180, edgeLength: [60, 180] },
      data: Array.from(nodeSet).map((name) => ({ id: name, name: name, value: 1 })),
      links: edges
    }]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function buildChordGraphFromChartConfig(chartConfig) {
  const cfg = chartConfig && typeof chartConfig === "object" ? chartConfig : {};
  const data = cfg.data && typeof cfg.data === "object" ? cfg.data : {};
  const rows = getEchartsTabularRowsFromChartConfig(chartConfig);
  const linkMap = Object.create(null);
  const nodeTotals = Object.create(null);

  function addNodeWeight(name, amount) {
    if (!name || amount == null || amount <= 0) return;
    nodeTotals[name] = (nodeTotals[name] || 0) + amount;
  }

  function addLink(sourceValue, targetValue, weightValue) {
    const sourceText = String(sourceValue == null ? "" : sourceValue).trim();
    const targetText = String(targetValue == null ? "" : targetValue).trim();
    let weight = toFiniteNumber(weightValue);
    if (weight == null) weight = 1;
    if (!sourceText || !targetText || sourceText === targetText || weight <= 0) return;
    const pair = sourceText <= targetText ? [sourceText, targetText] : [targetText, sourceText];
    const key = `${pair[0]}||${pair[1]}`;
    if (!Object.prototype.hasOwnProperty.call(linkMap, key)) {
      linkMap[key] = { source: pair[0], target: pair[1], value: 0 };
    }
    linkMap[key].value += weight;
    addNodeWeight(pair[0], weight);
    addNodeWeight(pair[1], weight);
  }

  rows.forEach((row) => {
    if (Array.isArray(row) && row.length >= 2) {
      addLink(row[0], row[1], row[2]);
      return;
    }
    if (!row || typeof row !== "object") return;
    const keys = Object.keys(row);
    const sourceKey = keys.find((k) => /^(source|from|src|origin|category_?a|node_?a|node1|left)$/i.test(k)) || keys[0];
    const targetKey = keys.find((k) => /^(target|to|dest|destination|category_?b|node_?b|node2|right)$/i.test(k)) || keys[1];
    const valueKey = keys.find((k) => /(value|amount|weight|count|flow|strength|volume|customer|purchase|total)/i.test(k)) || keys[2];
    addLink(row[sourceKey], row[targetKey], row[valueKey]);
  });

  const directLinks = Array.isArray(data.links) ? data.links : [];
  directLinks.forEach((link) => {
    if (Array.isArray(link) && link.length >= 2) {
      addLink(link[0], link[1], link[2]);
      return;
    }
    if (!link || typeof link !== "object") return;
    addLink(link.source, link.target, link.value);
  });

  const matrix = Array.isArray(data.matrix) ? data.matrix : null;
  const matrixLabels = Array.isArray(data.labels)
    ? data.labels
    : (Array.isArray(data.nodes) ? data.nodes.map((node) => String((node && node.name) || node || "").trim()) : []);
  if (matrix && matrixLabels.length) {
    matrix.forEach((matrixRow, rowIndex) => {
      if (!Array.isArray(matrixRow)) return;
      matrixRow.forEach((cellValue, colIndex) => {
        if (rowIndex === colIndex) return;
        addLink(matrixLabels[rowIndex], matrixLabels[colIndex], cellValue);
      });
    });
  }

  const links = Object.keys(linkMap)
    .map((key) => linkMap[key])
    .filter((item) => item && toFiniteNumber(item.value) != null && item.value > 0);
  const nodes = Object.keys(nodeTotals).map((name) => ({
    name: name,
    value: nodeTotals[name]
  }));

  return { nodes, links };
}

function renderChordWithEcharts(targetEl, chartConfig) {
  const chordData = buildChordGraphFromChartConfig(chartConfig);
  if (!chordData.links.length || !chordData.nodes.length) {
    throw new Error("Chord diagram needs source/target/value relationships.");
  }

  const maxNodeValue = chordData.nodes.reduce((max, node) => Math.max(max, node.value || 0), 0);
  const maxLinkValue = chordData.links.reduce((max, link) => Math.max(max, link.value || 0), 0);
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);

  chart.setOption({
    title: { text: getEchartsChartConfigTitle(chartConfig, "Chord Diagram"), left: "center", top: 6 },
    tooltip: {
      trigger: "item",
      formatter: function(params) {
        if (params && params.dataType === "edge") {
          return `${escapeHtml(params.data.source)} ↔ ${escapeHtml(params.data.target)}<br/><b>${escapeHtml(formatEchartsNumber(params.data.value))}</b>`;
        }
        const value = params && params.data ? params.data.value : null;
        return `${escapeHtml(params && params.name ? params.name : "")}: ${escapeHtml(formatEchartsNumber(value))}`;
      }
    },
    series: [{
      type: "graph",
      layout: "circular",
      circular: { rotateLabel: false },
      roam: true,
      emphasis: { focus: "adjacency" },
      label: { show: true, color: "#0f172a", fontWeight: 600 },
      edgeSymbol: ["none", "none"],
      lineStyle: { opacity: 0.74, curveness: 0.52, color: "source" },
      data: chordData.nodes.map((node) => {
        const ratio = maxNodeValue > 0 ? (node.value || 0) / maxNodeValue : 0;
        const symbolSize = 22 + (ratio * 42);
        return {
          id: node.name,
          name: node.name,
          value: node.value,
          symbolSize: Math.max(16, Math.min(72, symbolSize))
        };
      }),
      links: chordData.links.map((link) => {
        const ratio = maxLinkValue > 0 ? link.value / maxLinkValue : 0;
        return {
          source: link.source,
          target: link.target,
          value: link.value,
          lineStyle: {
            width: Math.max(1.2, Math.min(16, 1.2 + (ratio * 14)))
          }
        };
      })
    }]
  });

  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderGanttWithEcharts(targetEl, chartConfig) {
  const rows = getEchartsTabularRowsFromChartConfig(chartConfig);
  const tasks = [];
  rows.forEach((row, idx) => {
    if (Array.isArray(row) && row.length >= 3) {
      const taskName = String(row[0] == null ? "" : row[0]).trim() || `Task ${idx + 1}`;
      const start = toEchartsTimestamp(row[1]);
      const end = toEchartsTimestamp(row[2]);
      if (start == null || end == null || end < start) return;
      tasks.push({ taskName, start, end });
      return;
    }
    if (!row || typeof row !== "object") return;
    const keys = Object.keys(row);
    const taskKey = keys.find((k) => /(task|name|activity|item)/i.test(k)) || keys[0];
    const startKey = keys.find((k) => /(start|from|begin)/i.test(k)) || keys[1];
    const endKey = keys.find((k) => /(end|to|finish|due)/i.test(k)) || keys[2];
    const taskName = String(row[taskKey] == null ? "" : row[taskKey]).trim() || `Task ${idx + 1}`;
    const start = toEchartsTimestamp(row[startKey]);
    const end = toEchartsTimestamp(row[endKey]);
    if (start == null || end == null || end < start) return;
    tasks.push({ taskName, start, end });
  });

  if (!tasks.length) throw new Error("Gantt chart needs task/start/end rows.");
  const categories = tasks.map((task) => task.taskName);
  const data = tasks.map((task, idx) => [idx, task.start, task.end, task.taskName]);
  const minStart = Math.min.apply(null, tasks.map((task) => task.start));
  const maxEnd = Math.max.apply(null, tasks.map((task) => task.end));
  const chart = window.echarts.getInstanceByDom(targetEl) || window.echarts.init(targetEl);
  chart.setOption({
    title: { text: getEchartsChartConfigTitle(chartConfig, "Gantt"), left: "center", top: 6 },
    tooltip: {
      formatter: function(params) {
        const val = params && params.value ? params.value : [];
        const start = new Date(val[1]);
        const end = new Date(val[2]);
        return `${escapeHtml(val[3] || "")}<br/>${escapeHtml(start.toLocaleDateString())} - ${escapeHtml(end.toLocaleDateString())}`;
      }
    },
    grid: { top: 60, left: 120, right: 30, bottom: 30 },
    xAxis: { type: "time", min: minStart, max: maxEnd },
    yAxis: { type: "category", data: categories },
    series: [{
      type: "custom",
      renderItem: function(params, api) {
        const categoryIndex = api.value(0);
        const startCoord = api.coord([api.value(1), categoryIndex]);
        const endCoord = api.coord([api.value(2), categoryIndex]);
        const height = api.size([0, 1])[1] * 0.6;
        const rectShape = window.echarts.graphic.clipRectByRect({
          x: startCoord[0],
          y: startCoord[1] - (height / 2),
          width: endCoord[0] - startCoord[0],
          height: height
        }, {
          x: params.coordSys.x,
          y: params.coordSys.y,
          width: params.coordSys.width,
          height: params.coordSys.height
        });
        return rectShape && {
          type: "rect",
          shape: rectShape,
          style: api.style({ fill: "#3b82f6" })
        };
      },
      encode: { x: [1, 2], y: 0, tooltip: [3, 1, 2] },
      data: data
    }]
  });
  window.requestAnimationFrame(() => {
    try { chart.resize(); } catch (e) {}
  });
}

function renderChartWithEcharts(targetEl, chartConfig, fallbackType) {
  const chartType = getEchartsRendererType((chartConfig && chartConfig.type) || fallbackType);
  if (!chartType) throw new Error("No ECharts renderer type resolved.");
  if (chartType === "sunburst") {
    renderSunburstWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "heatmap") {
    renderHeatmapWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "bar_race") {
    renderBarRaceWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "treemap") {
    renderTreemapWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "sankey") {
    renderSankeyWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "gauge") {
    renderGaugeWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "kpi_card") {
    renderKpiCardWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "gantt") {
    renderGanttWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "candlestick") {
    renderCandlestickWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "waterfall") {
    renderWaterfallWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "calendar_heatmap") {
    renderCalendarHeatmapWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "streamgraph") {
    renderStreamgraphWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "network_graph") {
    renderNetworkWithEcharts(targetEl, chartConfig);
    return;
  }
  if (chartType === "chord") {
    renderChordWithEcharts(targetEl, chartConfig);
    return;
  }
  throw new Error(`Unsupported ECharts renderer type: ${chartType}`);
}

function downloadEchartsDivAsPng(targetEl, fileName) {
  if (!targetEl || !window.echarts || typeof window.echarts.getInstanceByDom !== "function") return;
  const chart = window.echarts.getInstanceByDom(targetEl);
  if (!chart || typeof chart.getDataURL !== "function") return;
  try {
    const dataUrl = chart.getDataURL({
      type: "png",
      pixelRatio: 2,
      backgroundColor: "#ffffff"
    });
    if (!dataUrl) return;
    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch (err) {
    console.warn("ECharts PNG export failed:", err);
  }
}

function isBoxPlotChartSupported() {
  if (!window.Chart) return false;
  try {
    if (Chart.registry && typeof Chart.registry.getController === "function") {
      return !!Chart.registry.getController("boxplot");
    }
  } catch (e) {}

  try {
    if (Chart.controllers) {
      return !!(Chart.controllers.boxplot || Chart.controllers.BoxPlot);
    }
  } catch (e) {}

  return false;
}

function isSunburstChartSupported() {
  if (!window.Chart) return false;
  try {
    if (Chart.registry && typeof Chart.registry.getController === "function") {
      return !!Chart.registry.getController("sunburst");
    }
  } catch (e) {}
  try {
    if (Chart.controllers) {
      return !!(Chart.controllers.sunburst || Chart.controllers.Sunburst);
    }
  } catch (e) {}
  return false;
}

function normalizeResponseTableZoomId(id) {
  const raw = String(id || "").trim();
  if (!raw) return "";
  return raw.replace(/^response-/, "");
}

function getResponseTableZoomValue(id) {
  return RESPONSE_TABLE_ZOOM_DEFAULT;
}

function setResponseTableZoomLabel(id, zoomValue) {
  return;
}

function applyResponseTableZoom(id, zoomValue) {
  const normalizedId = normalizeResponseTableZoomId(id);
  if (!normalizedId) return RESPONSE_TABLE_ZOOM_DEFAULT;
  responseTableZoomById[normalizedId] = RESPONSE_TABLE_ZOOM_DEFAULT;

  const responseEl = document.getElementById(`response-${normalizedId}`);
  if (!responseEl) return RESPONSE_TABLE_ZOOM_DEFAULT;
  responseEl.querySelectorAll(".code-editor-run-output-table-wrap, table").forEach((node) => {
    try { node.style.removeProperty("zoom"); } catch (e) {}
  });
  return RESPONSE_TABLE_ZOOM_DEFAULT;
}

function adjustResponseTableZoom(id, deltaOrAction) {
  return applyResponseTableZoom(id, RESPONSE_TABLE_ZOOM_DEFAULT);
}

function setResponseTableZoomControlsVisibility(id, visible) {
  return;
}

function bindResponseTableZoomHover(id) {
  return;
}

function buildSqlResponseInlineActionsHtml(responseId) {
  return "";
}

function ensureResponseTableInlineActionsForElement(responseEl) {
  if (!responseEl || !responseEl.id) return;
  const responseId = normalizeResponseTableZoomId(responseEl.id);
  if (!responseId) return;

  responseEl.querySelectorAll('.ask-oracle-response-table-actions').forEach((node) => {
    try { node.remove(); } catch (e) {}
  });
}

function renderSqlResponseTableLikeEditor(results, responseElementId, totalRowCount) {
  const responseEl = document.getElementById(String(responseElementId || ""));
  if (!responseEl) return;
  const responseId = normalizeResponseTableZoomId(responseElementId);

  let rows = normalizeEditorRunResultRows(results);
  if ((!Array.isArray(rows) || rows.length === 0) && results && typeof results === "object") {
    rows = extractEditorRunRowsFromUnknownShape(results, 0, new Set());
  }
  const normalizedRows = Array.isArray(rows) ? rows : [];

  if (normalizedRows.length === 0) {
    responseEl.innerHTML = `<div class="code-editor-run-output-note">No rows returned.</div>`;
    setResponseExportExcelButtonsVisibility(responseId, false);
    return;
  }

  const metaParts = [];
  const totalRows = Number(totalRowCount);
  if (Number.isFinite(totalRows)) metaParts.push(`Total Rows: ${Math.max(0, totalRows)}`);
  metaParts.push(`Displayed: ${Math.min(normalizedRows.length, CODE_EDITOR_RUN_OUTPUT_MAX_ROWS)}`);

  const tableHtml = buildEditorRunOutputTableHtml(normalizedRows);
  responseEl.innerHTML = `
    <div class="code-editor-run-output-meta">${escapeHtml(metaParts.join(" | "))}</div>
    ${tableHtml}
  `;
  applyResponseTableZoom(responseId, getResponseTableZoomValue(responseId));
  bindResponseTableZoomHover(responseId);
  setResponseExportExcelButtonsVisibility(responseId, true);
}



var askOracleResponseRenderTokens = window.askOracleResponseRenderTokens || (window.askOracleResponseRenderTokens = Object.create(null));

function renderNl2SqlResultsChart(results, targetId, chartType, promptText) {
  const toChartNumber = function(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    const normalized = String(value == null ? "" : value).replace(/,/g, "").replace(/%$/, "").trim();
    if (!normalized) return null;
    const numberValue = Number(normalized);
    return Number.isFinite(numberValue) ? numberValue : null;
  };
  const target = document.getElementById(targetId);
  let normalizedRows = normalizeEditorRunResultRows(results);
  if ((!Array.isArray(normalizedRows) || normalizedRows.length === 0) && results && typeof results === "object") {
    normalizedRows = extractEditorRunRowsFromUnknownShape(results, 0, new Set());
  }
  const rows = Array.isArray(normalizedRows)
    ? normalizedRows.filter((row) => row && typeof row === "object" && !Array.isArray(row))
    : [];
  if (!target || !rows.length || !window.Chart) return false;

  const columns = Object.keys(rows[0]);
  if (columns.length < 2) return false;

  const palette = [
    "#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0",
    "#EA3546", "#4CAF50", "#662E9B", "#F9A3A4", "#17A2B8"
  ];
  const normalizedType = normalizeChartTypeForChartJs(chartType || "bar");
  const labelColumn = columns[0];
  const numericColumns = columns.slice(1).filter((column) =>
    rows.some((row) => toChartNumber(row[column]) != null)
  );
  const dimensionColumns = columns.slice(1).filter((column) => !numericColumns.includes(column));
  if (!numericColumns.length) return false;

  let labels = [];
  let datasets = [];
  if (dimensionColumns.length && numericColumns.length === 1) {
    // Long-form result: group, category, measure. Pivot it into one dataset
    // per group, so repeated categories are plotted only once on the x-axis
    // (for example INCOME_LEVEL + REGION + CUSTOMER_COUNT).
    const groupColumn = labelColumn;
    const categoryColumn = dimensionColumns[0];
    const valueColumn = numericColumns[0];
    labels = Array.from(new Set(rows.map((row) => String(row[categoryColumn] == null ? "" : row[categoryColumn]).trim()).filter(Boolean)));
    const groups = Array.from(new Set(rows.map((row) => String(row[groupColumn] == null ? "" : row[groupColumn]).trim()).filter(Boolean)));
    datasets = groups.map((group, groupIndex) => ({
      label: group,
      data: labels.map((label) => rows.reduce((sum, row) => {
        if (String(row[categoryColumn] == null ? "" : row[categoryColumn]).trim() !== label) return sum;
        if (String(row[groupColumn] == null ? "" : row[groupColumn]).trim() !== group) return sum;
        return sum + (toChartNumber(row[valueColumn]) || 0);
      }, 0)),
      backgroundColor: palette[groupIndex % palette.length],
      borderColor: palette[groupIndex % palette.length],
      borderWidth: 1
    }));
  } else {
    // Wide-form result: category followed by one or more numeric measures.
    labels = rows.map((row) => String(row[labelColumn] == null ? "" : row[labelColumn]).trim());
    datasets = numericColumns.map((column, columnIndex) => ({
      label: column,
      data: rows.map((row) => toChartNumber(row[column]) || 0),
      backgroundColor: ["pie", "doughnut", "polarArea"].includes(normalizedType)
        ? labels.map((_, index) => palette[index % palette.length])
        : palette[columnIndex % palette.length],
      borderColor: normalizedType === "line" ? palette[columnIndex % palette.length] : "#ffffff",
      borderWidth: normalizedType === "line" ? 2 : 1
    }));
  }
  const hasPlottableValue = datasets.some((dataset) =>
    Array.isArray(dataset.data) && dataset.data.some((value) => Number.isFinite(value) && value !== 0)
  );
  if (!labels.length || !datasets.length || !hasPlottableValue) {
    console.warn("[NL2SQL_CHART] No plottable chart values; rendering results as a table instead.");
    return false;
  }

  const useLogScale = /\b(log(?:arithmic)?(?:ally)?\s*(?:y[\s-]*axis\s*)?scale|log(?:arithmic)?\s+y[\s-]*axis)\b/i.test(String(promptText || ""));
  const supportsCartesianScale = !["pie", "doughnut", "polarArea", "radar"].includes(normalizedType);
  const wrapper = document.createElement("div");
  wrapper.className = "ask-oracle-nl2sql-chart";
  wrapper.style.position = "relative";
  wrapper.style.width = "100%";
  wrapper.style.height = "450px";
  wrapper.style.background = "#ffffff";
  const canvas = document.createElement("canvas");
  wrapper.appendChild(canvas);
  target.innerHTML = "";
  target.appendChild(wrapper);

  try {
    const chart = new window.Chart(canvas.getContext("2d"), {
      type: normalizedType,
      data: {
        labels,
        datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: ["pie", "doughnut", "polarArea"].includes(normalizedType) ? "right" : "top" }
        },
        scales: supportsCartesianScale ? {
          x: { stacked: false },
          y: {
            type: useLogScale ? "logarithmic" : "linear",
            beginAtZero: !useLogScale,
            stacked: false
          }
        } : undefined
      }
    });
    let chartFallbackApplied = false;
    const fallbackToResultsTable = function(reason) {
      if (chartFallbackApplied || !canvas.isConnected) return;
      chartFallbackApplied = true;
      try { chart.destroy(); } catch (e) {}
      target.innerHTML = "";
      console.warn("[NL2SQL_CHART] " + reason + "; rendering results as a table instead.");
      renderSqlResponseTableLikeEditor(results, targetId);
      setResponseExportExcelButtonsVisibility(normalizeResponseTableZoomId(targetId), true);
    };
    const validatePaintedChart = function(attempt) {
      if (chartFallbackApplied || !canvas.isConnected) return;
      const chartArea = chart.chartArea || {};
      const rect = canvas.getBoundingClientRect();
      const hasUsableArea =
        Number(chartArea.right) > Number(chartArea.left) &&
        Number(chartArea.bottom) > Number(chartArea.top) &&
        rect.width > 1 &&
        rect.height > 1;
      if (!hasUsableArea) {
        if (attempt < 3) {
          window.requestAnimationFrame(function() { validatePaintedChart(attempt + 1); });
          return;
        }
        fallbackToResultsTable("Chart did not receive a usable drawing area");
        return;
      }

      try {
        const context = canvas.getContext("2d");
        const pixels = context && context.getImageData(0, 0, canvas.width, canvas.height).data;
        let paintedPixels = 0;
        for (let index = 3; pixels && index < pixels.length; index += 32) {
          if (pixels[index] !== 0) paintedPixels += 1;
        }
        if (paintedPixels === 0) {
          fallbackToResultsTable("Chart canvas was not painted");
        }
      } catch (e) {
        // Some browser/canvas configurations do not allow pixel inspection.
      }
    };
    try { chart.resize(); } catch (e) {}
    if (!(Number(chart.width) > 0) || !(Number(chart.height) > 0)) {
      fallbackToResultsTable("Chart canvas has no usable size");
      return false;
    }
    stabilizeChartJsAfterLayout(chart, canvas);
    window.requestAnimationFrame(function() {
      window.requestAnimationFrame(function() { validatePaintedChart(0); });
    });
    window.setTimeout(function() { validatePaintedChart(0); }, 350);
    return true;
  } catch (err) {
    console.error("[NL2SQL_CHART] render failed", err);
    target.innerHTML = "";
    return false;
  }
}

if (!window.__askOracleNl2SqlAggregateChartControlsInstalled) {
  window.__askOracleNl2SqlAggregateChartControlsInstalled = true;
  window.__askOracleNl2SqlChartRows = window.__askOracleNl2SqlChartRows || {};

  window.renderAskOracleNl2SqlAggregateChart = function(id) {
    var rows = window.__askOracleNl2SqlChartRows[String(id)] || [];
    var block = document.getElementById("chart-block-" + id);
    var canvas = document.getElementById("chart-canvas-" + id);
    if (!block || !canvas || !Array.isArray(rows) || !rows.length || !window.Chart) return;
    var xSelect = block.querySelector(".chart-xaxis");
    var ySelect = block.querySelector(".chart-yaxis");
    var seriesSelect = block.querySelector(".chart-series");
    var aggregationSelect = block.querySelector(".chart-aggregation");
    var typeSelect = block.querySelector(".chart-type");
    if (!xSelect || !ySelect) return;
    var xCol = xSelect.value;
    var yCol = ySelect.value;
    var aggregation = String((aggregationSelect && aggregationSelect.value) || "sum").toLowerCase();
    var type = String((typeSelect && typeSelect.value) || "bar").toLowerCase();
    var columns = Object.keys(rows[0] || {});
    var isNumber = function(value) { return Number.isFinite(Number(String(value == null ? "" : value).replace(/,/g, "").trim())); };
    var numericColumns = columns.filter(function(column) { return rows.some(function(row) { return isNumber(row[column]); }); });
    var groupCol = seriesSelect ? String(seriesSelect.value || "") : "";
    var labels = Array.from(new Set(rows.map(function(row) { return String(row[xCol] == null ? "" : row[xCol]).trim(); }).filter(Boolean)));
    var groups = groupCol ? Array.from(new Set(rows.map(function(row) { return String(row[groupCol] == null ? "" : row[groupCol]).trim(); }).filter(Boolean))) : [""];
    var aggregate = function(values) {
      if (aggregation === "count") return values.length;
      var numbers = values.map(function(value) { return Number(String(value == null ? "" : value).replace(/,/g, "").trim()); }).filter(Number.isFinite);
      if (!numbers.length) return 0;
      if (aggregation === "avg") return numbers.reduce(function(sum, value) { return sum + value; }, 0) / numbers.length;
      if (aggregation === "min") return Math.min.apply(null, numbers);
      if (aggregation === "max") return Math.max.apply(null, numbers);
      return numbers.reduce(function(sum, value) { return sum + value; }, 0);
    };
    var palette = ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0", "#EA3546", "#4CAF50"];
    var datasets = groups.map(function(group, groupIndex) {
      return {
        label: group || yCol,
        data: labels.map(function(label) {
          return aggregate(rows.filter(function(row) {
            return String(row[xCol] == null ? "" : row[xCol]).trim() === label &&
              (!groupCol || String(row[groupCol] == null ? "" : row[groupCol]).trim() === group);
          }).map(function(row) { return row[yCol]; }));
        }),
        backgroundColor: groupCol ? palette[groupIndex % palette.length] : palette,
        borderColor: palette[groupIndex % palette.length],
        borderWidth: 1,
        fill: type === "area"
      };
    });
    if (canvas.__askOracleNl2SqlChart) canvas.__askOracleNl2SqlChart.destroy();
    var finalType = type === "area" ? "line" : (type === "donut" ? "doughnut" : type);
    if (["bar", "line", "pie", "doughnut"].indexOf(finalType) < 0) finalType = "bar";
    canvas.__askOracleNl2SqlChart = new window.Chart(canvas.getContext("2d"), {
      type: finalType,
      data: { labels: labels, datasets: datasets },
      options: { responsive: true, maintainAspectRatio: false, scales: ["bar", "line"].indexOf(finalType) >= 0 ? { y: { beginAtZero: true } } : {} }
    });
  };

  document.addEventListener("click", function(event) {
    var button = event.target && event.target.closest ? event.target.closest(".toggle-charts") : null;
    if (!button) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    var id = String(button.getAttribute("data-id") || "").trim();
    var block = document.getElementById("chart-block-" + id);
    if (!id || !block) return;
    if (!block.querySelector(".chart-series")) {
      var xAxisSelect = block.querySelector(".chart-xaxis");
      if (xAxisSelect && xAxisSelect.parentNode) {
        var seriesLabel = document.createElement("label");
        seriesLabel.style.color = "black";
        seriesLabel.textContent = "Series:";
        var seriesSelect = document.createElement("select");
        seriesSelect.className = "chart-series";
        seriesSelect.setAttribute("data-id", id);
        seriesSelect.style.height = "28px";
        seriesSelect.style.fontSize = "12px";
        seriesSelect.add(new Option("None", ""));
        xAxisSelect.insertAdjacentElement("afterend", seriesLabel);
        seriesLabel.insertAdjacentElement("afterend", seriesSelect);
      }
    }
    if (!block.querySelector(".chart-aggregation")) {
      var yAxisSelect = block.querySelector(".chart-yaxis");
      if (yAxisSelect && yAxisSelect.parentNode) {
        var aggregateLabel = document.createElement("label");
        aggregateLabel.style.color = "black";
        aggregateLabel.textContent = "Aggregate:";
        var aggregateSelect = document.createElement("select");
        aggregateSelect.className = "chart-aggregation";
        aggregateSelect.setAttribute("data-id", id);
        aggregateSelect.style.height = "28px";
        aggregateSelect.style.fontSize = "12px";
        [["sum", "Sum"], ["avg", "Average"], ["count", "Count"], ["min", "Minimum"], ["max", "Maximum"]].forEach(function(item) {
          aggregateSelect.add(new Option(item[1], item[0]));
        });
        yAxisSelect.insertAdjacentElement("afterend", aggregateLabel);
        aggregateLabel.insertAdjacentElement("afterend", aggregateSelect);
      }
    }
    var optionalSeriesSelect = block.querySelector(".chart-series");
    var optionalSeriesLabel = optionalSeriesSelect && optionalSeriesSelect.previousElementSibling;
    var aggregateControl = block.querySelector(".chart-aggregation");
    if (optionalSeriesSelect && optionalSeriesLabel && optionalSeriesLabel.tagName === "LABEL" && aggregateControl) {
      aggregateControl.insertAdjacentElement("afterend", optionalSeriesLabel);
      optionalSeriesLabel.insertAdjacentElement("afterend", optionalSeriesSelect);
    }
    if (block.style.display !== "none" && block.style.display !== "") {
      block.style.display = "none";
      button.textContent = "Show Charts";
      return;
    }
    block.style.display = "block";
    button.textContent = "Hide Charts";
    var render = function(rows) {
      var columns = Object.keys(rows[0] || {});
      var xSelect = block.querySelector(".chart-xaxis");
      var ySelect = block.querySelector(".chart-yaxis");
      var seriesSelect = block.querySelector(".chart-series");
      [xSelect, ySelect].filter(Boolean).forEach(function(select) {
        select.innerHTML = "";
        columns.forEach(function(column) { select.add(new Option(column, column)); });
      });
      if (seriesSelect) {
        seriesSelect.innerHTML = "";
        seriesSelect.add(new Option("None", ""));
        columns.forEach(function(column) { seriesSelect.add(new Option(column, column)); });
      }
      var numeric = columns.filter(function(column) { return rows.some(function(row) { return Number.isFinite(Number(String(row[column] == null ? "" : row[column]).replace(/,/g, "").trim())); }); });
      var dimensions = columns.filter(function(column) { return numeric.indexOf(column) < 0; });
      xSelect.value = dimensions.length > 1 ? dimensions[1] : (dimensions[0] || columns[0]);
      ySelect.value = numeric[0] || columns[1];
      if (seriesSelect) seriesSelect.value = "";
      window.renderAskOracleNl2SqlAggregateChart(id);
    };
    var cached = window.__askOracleNl2SqlChartRows[id];
    if (cached) { render(cached); return; }
    apex.server.process("GET_SQL_RESULTS", { x01: id }, { dataType: "json", success: function(data) {
      var rows = Array.isArray(data && data.results) ? data.results : [];
      window.__askOracleNl2SqlChartRows[id] = rows;
      if (rows.length) render(rows);
    } });
  }, true);
  document.addEventListener("change", function(event) {
    if (!event.target || !event.target.matches(".chart-type, .chart-xaxis, .chart-series, .chart-yaxis, .chart-aggregation")) return;
    event.stopImmediatePropagation();
    window.renderAskOracleNl2SqlAggregateChart(event.target.getAttribute("data-id"));
  }, true);
}

function initSingleLLMResponse(id, onComplete) {
  const responseId = String(id || "");
  const renderToken = (askOracleResponseRenderTokens[responseId] || 0) + 1;
  askOracleResponseRenderTokens[responseId] = renderToken;

  function isStaleRender() {
    return askOracleResponseRenderTokens[responseId] !== renderToken;
  }

  const el = document.getElementById("response-" + id);
  if (!el) {
    if (onComplete) onComplete();
    return;
  }

  const type = String(el.getAttribute("data-type") || "").trim().toLowerCase();
  const responseType = String(el.getAttribute("data-response-type") || "").trim().toUpperCase();
  const renderType = responseType === "CHAT" ? "response" : type;
  console.log("Printing the type of", type, "response_type:", responseType, "renderType:", renderType);

  if (renderType === "response") {
    console.log("[GET_RESPONSE] request start", { id, type, responseType, renderType });
    askOraclePerfMark("response_get_response_start", { id, type: renderType });
    apex.server.process("GET_RESPONSE", { x01: id }, {
      dataType: "json",
      success: function (pData) {
        if (isStaleRender()) return;

        let response = ensureResponseCodeFenceClosure(pData.response || "");
        response = sanitizeDashboardResponseText(response);
        console.log("[GET_RESPONSE] success", {
          id,
          hasError: !!(pData && pData.error),
          responseLength: String(response || "").length,
          profileName: pData && pData.profile_name
        });
        askOraclePerfMark("response_get_response_end", {
          id,
          hasError: !!(pData && pData.error),
          responseLength: String(response || "").length
        });

        if (shouldUseStoredAutoVisualResponse()) {
          clearAgentAutoVisualPayload(id);
        } else {
          const autoVisual = consumeAgentAutoVisualPayload(id);
          console.log("[AUTO_VISUAL] consume payload", {
            id,
            hasPayload: !!autoVisual,
            chartIntent: autoVisual && autoVisual.chartIntent,
            visualType: autoVisual && autoVisual.visualType,
            payloadLength: autoVisual && autoVisual.visualPayload ? String(autoVisual.visualPayload).length : 0
          });
          if (autoVisual && String(autoVisual.chartIntent || "").toUpperCase() === "Y") {
            const responseHasVisual = responseAlreadyHasRenderableVisual(response);
            console.log("[AUTO_VISUAL] response visual presence before append", { id, responseHasVisual });
            if (!responseHasVisual) {
              const autoVisualBlock = formatAgentAutoVisualBlock(autoVisual.visualType, autoVisual.visualPayload);
              if (autoVisualBlock) {
                response = `${response}\n\n${autoVisualBlock}`;
                console.log("[AUTO_VISUAL] appended backend visual block to response", {
                  id,
                  visualType: autoVisual.visualType,
                  appendedLength: autoVisualBlock.length
                });
              }
            }
          }
        }

        if (isStaleRender()) return;

        askOraclePerfMark("response_visual_extract_start", { id });
        const inferredPayload = buildPayloadFromRawResponseText(response);
        if (inferredPayload && inferredPayload.content) {
          cacheResponseDownloadPayload(id, inferredPayload);
        }

        const promptTextForResponse = String($("#prompt-" + id).text() || "");
        const chartExtraction = extractRenderableChartConfigs(response, promptTextForResponse);
        const graphExtraction = extractRenderableGraphBlocks(chartExtraction.textOnlyResponse);
        const chartConfigs = chartExtraction.chartConfigs;
        const graphBlocks = graphExtraction.graphBlocks;
        const textOnlyResponse = graphExtraction.textOnlyResponse;
        const hasVisualBlocks = chartConfigs.length > 0 || graphBlocks.length > 0;
        askOraclePerfMark("response_visual_extract_end", {
          id,
          chartConfigCount: chartConfigs.length,
          graphBlockCount: graphBlocks.length
        });
        const exceedsTypewriterLimit = response.length > ASK_ORACLE_TYPEWRITER_DIRECT_RENDER_THRESHOLD;
        const shouldBypassTypewriter = hasVisualBlocks || exceedsTypewriterLimit;

        function finalizeResponseRender() {
          if (isStaleRender()) return;

          askOraclePerfMark("response_finalize_start", { id, hasVisualBlocks });
          askOraclePerfMark("response_postprocess_start", { id });
          postProcessResponse(el);
          askOraclePerfMark("response_postprocess_end", { id });
          highlightLanguageCodes(el);
          scheduleResponseTableLayoutRefresh("response-" + id);

          const visualContainer = document.getElementById(`chart-container-${id}`);
          if (visualContainer && hasVisualBlocks) {
            visualContainer.innerHTML = "";
            visualContainer.style.display = "none";
          }

          askOraclePerfMark("response_visual_render_start", {
            id,
            chartConfigCount: chartConfigs.length,
            graphBlockCount: graphBlocks.length
          });
          renderAllCharts(chartConfigs, id);
          renderGraphBlocks(graphBlocks, id);
          askOraclePerfMark("response_visual_render_end", { id });
          ensureResponseDownloadButtons();
          syncResponseOpenEditorButtonsForResponse(id);
          askOraclePerfMark("response_buttons_sync_end", { id });

          let conversationTime = pData.conversation_time || "0 Min 0 Sec";
          $("#response-" + pData.id)
            .nextAll("div")
            .find(".conversation-time-btn")
            .first()
            .attr("data-tooltip", conversationTime)
            .attr("data-time", conversationTime)
            .attr("title", conversationTime);

          askOraclePerfMark("response_finalize_end", { id });
          if (onComplete) onComplete();
        }

        if (shouldBypassTypewriter) {
          if (isStaleRender()) return;
          el.textContent = textOnlyResponse;
          finalizeResponseRender();
        } else {
          el.innerHTML = "";
          typeWriterSmart(el, textOnlyResponse, ASK_ORACLE_TYPEWRITER_DELAY, () => {
            if (isStaleRender()) return;
            finalizeResponseRender();
          });
        }
      }
    });
  } else if (renderType === "sql") {
    askOraclePerfMark("sql_get_results_start", { id, type: renderType });
    apex.server.process("GET_SQL_RESULTS", { x01: id }, {
      dataType: "json",
      success: function(pData) {
        if (isStaleRender()) return;

        askOraclePerfMark("sql_get_results_end", {
          id,
          rows: Array.isArray(pData && pData.results) ? pData.results.length : 0,
          totalRowCount: pData && pData.totalRowCount
        });
        askOraclePerfMark("sql_render_start", { id });

        el.innerHTML = "";
        let promptText = $("#prompt-" + pData.id).text() || "";
        const requestedChartType = detectRequestedChartTypeFromPrompt(promptText);
        let chartType = normalizeChartTypeForChartJs(requestedChartType || "");
        if (chartType === "funnel" && !isFunnelChartSupported()) chartType = "bar";
        if (chartType === "boxplot" && !isBoxPlotChartSupported()) chartType = "bar";

        let chartRendered = false;
        if (chartType) {
          // The Chart.js canvas can remain blank in some APEX page layouts even
          // when valid SQL rows are returned. Keep NL2SQL results visible by
          // using the reliable table renderer rather than showing an empty chart.
          console.warn("[NL2SQL_CHART] Using table fallback for chart-requested SQL results.");
          renderSqlResponseTableLikeEditor(pData.results, "response-" + pData.id, pData.totalRowCount);
          setResponseExportExcelButtonsVisibility(pData.id, true);
        } else {
          renderSqlResponseTableLikeEditor(pData.results, "response-" + pData.id, pData.totalRowCount);
        }
        scheduleResponseTableLayoutRefresh("response-" + pData.id);
        askOraclePerfMark("sql_render_end", { id, chartType: chartRendered ? chartType : "table" });

        cnt++;
        if (AUTO_SCROLL_DURING_RESPONSE_RENDER) scrollToLast();
        if (pData.totalRowCount > 10) $(".llm-more-rows-" + id).show();
        $(".llm-load-message-" + pData.id).hide();

        let profileLabel = pData.profile_name || "Default";
        $("#response-" + pData.id).nextAll("div").find(".profile-label").first().text(profileLabel);
        try {
          const responseNode = document.getElementById("response-" + pData.id);
          if (responseNode) {
            responseNode.setAttribute("data-profile-name", profileLabel);
          }
        } catch (e) {}

        let conversationTime = pData.conversation_time || "0 Min 0 Sec";
        $("#response-" + pData.id).nextAll("div").find(".conversation-time-btn").first()
          .attr("data-time", conversationTime)
          .attr("title", conversationTime);

        if (pData.sql) {
          cacheResponseDownloadPayload(id, { content: pData.sql, ext: "sql", hasCode: true });
          const sqlBlock = document.querySelector("#sql-block-" + pData.id + " code");
          if (sqlBlock) {
            sqlBlock.textContent = pData.sql;
            askOraclePerfMark("sql_prism_highlight_start", { id });
            Prism.highlightElement(sqlBlock);
            askOraclePerfMark("sql_prism_highlight_end", { id });
          }
        }
        ensureResponseDownloadButtons();
        syncResponseOpenEditorButtonsForResponse(id);
        askOraclePerfMark("sql_buttons_sync_end", { id });

        askOraclePerfMark("sql_finalize_end", { id });
        if (onComplete) onComplete();
      }
    });
  } else {
    if (onComplete) onComplete();
  }
}
function loadExternalScriptOnce(selector, src) {
  return new Promise((resolve, reject) => {
    const existingScript = document.querySelector(selector);
    if (existingScript) {
      if (
        existingScript.getAttribute("data-loaded") === "true" ||
        existingScript.readyState === "loaded" ||
        existingScript.readyState === "complete"
      ) {
        existingScript.setAttribute("data-loaded", "true");
        resolve();
        return;
      }
      existingScript.addEventListener("load", function onLoad() {
        existingScript.removeEventListener("load", onLoad);
        existingScript.setAttribute("data-loaded", "true");
        resolve();
      }, { once: true });
      existingScript.addEventListener("error", function onError() {
        existingScript.removeEventListener("error", onError);
        reject(new Error(`Failed to load script: ${src}`));
      }, { once: true });
      return;
    }

    const script = document.createElement("script");
    script.src = src;
    script.async = true;
    script.onload = function() {
      script.setAttribute("data-loaded", "true");
      resolve();
    };
    script.onerror = function() {
      reject(new Error(`Failed to load script: ${src}`));
    };
    document.head.appendChild(script);
  });
}

function ensureEchartsLoaded() {
  if (window.echarts && typeof window.echarts.init === "function") {
    return Promise.resolve(window.echarts);
  }
  if (askOracleEchartsLoadPromise) return askOracleEchartsLoadPromise;

  askOracleEchartsLoadPromise = loadExternalScriptOnce(
    'script[src*="echarts"]',
    "https://cdn.jsdelivr.net/npm/echarts/dist/echarts.min.js"
  )
    .then(() => {
      if (!window.echarts || typeof window.echarts.init !== "function") {
        throw new Error("ECharts loaded but window.echarts is unavailable.");
      }
      return window.echarts;
    })
    .catch((err) => {
      askOracleEchartsLoadPromise = null;
      throw err;
    });

  return askOracleEchartsLoadPromise;
}

// Ensure Chart.js and required extensions are loaded only once
function ensureChartJsLoaded(callback) {
  const done = typeof callback === "function" ? callback : function() {};

  if (window.Chart && isBoxPlotChartSupported()) {
    done();
    return;
  }

  if (!askOracleChartJsLoadPromise) {
    askOracleChartJsLoadPromise = Promise.resolve()
      .then(() => {
        if (window.Chart) return null;
        return loadExternalScriptOnce('script[src*="chart.js"]', "https://cdn.jsdelivr.net/npm/chart.js").then(() => {
          console.log("Chart.js loaded");
        });
      })
      .then(() => {
        if (isBoxPlotChartSupported()) return null;
        return loadExternalScriptOnce(
          'script[src*="chartjs-chart-boxplot"]',
          "https://cdn.jsdelivr.net/npm/@sgratzl/chartjs-chart-boxplot/build/index.umd.min.js"
        ).then(() => {
          console.log("Chart.js boxplot plugin loaded");
        }).catch((err) => {
          console.warn("Chart.js boxplot plugin could not be loaded.", err);
        });
      })
      .catch((err) => {
        console.error("Chart.js load failed", err);
      })
      .finally(() => {
        askOracleChartJsLoadPromise = null;
      });
  }

  askOracleChartJsLoadPromise.then(() => done()).catch(() => done());
}




function highlightLanguageCodes(el) {
  if (!el) return;
  const responseContextText = ensureResponseCodeFenceClosure(el.textContent || el.innerText || "");

  // --- Helpers
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }
  function escapeHtmlAttr(str) {
    return String(str).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function decodeHtmlEntities(str) {
    let value = String(str || "");
    const decodeMap = {
      "&lt;": "<",
      "&gt;": ">",
      "&amp;": "&",
      "&quot;": "\"",
      "&#39;": "'",
      "&#x27;": "'",
      "&#96;": "`"
    };

    // Decode at most twice so inputs like "&amp;lt;" normalize to "<" before re-escaping.
    for (let i = 0; i < 2; i++) {
      const next = value.replace(/&(lt|gt|amp|quot);|&#39;|&#x27;|&#96;/gi, (entity) => {
        const key = entity.toLowerCase();
        return decodeMap[key] || entity;
      });
      if (next === value) break;
      value = next;
    }

    return value;
  }

  // --- Step 1: Convert Markdown-style code blocks to <pre><code>
  // Only treat fences as markdown when they start at line-beginning.
  const codeBlockRegex = /(^|\n)```([^\n\r`]*)[ \t]*\r?\n([\s\S]*?)(?:\r?\n```(?=\r?\n|$)|$)/g;
    el.innerHTML = el.innerHTML.replace(codeBlockRegex, (match, lineStart, langRaw, code) => {
    const lang = (langRaw || "").trim().toLowerCase();
    const aliasMap = {
        "js": "javascript",
        "javascript": "javascript",
        "py": "python",
        "python": "python",
        "c#": "csharp",
        "c++": "cpp",
        "plsql": "sql",
        "sql": "sql",
        "sh": "bash",
        "bash": "bash",
        "html": "markup",
        "xml": "markup",
        "json": "json"
    };
    const normalizedCode = decodeHtmlEntities(code);
    const inferredExt = inferCodeFileExtension(responseContextText, normalizedCode, lang);
    const inferredLang = inferredExt === "sql" ? "sql" : "";
    const safeLang = aliasMap[lang] || inferredLang || (lang || "none");
    return `${lineStart}<pre><code class="language-${escapeHtmlAttr(safeLang)}">${escapeHtml(normalizedCode)}</code></pre>`;
    });

  // --- Step 1b: Convert single-backtick inline code spans to <code>
  const inlineCodeSpanRegex = /(^|[^`])`([^`\n]+?)`(?=[^`]|$)/g;
  el.innerHTML = el.innerHTML.replace(inlineCodeSpanRegex, (match, prefix, codeText) => {
    const normalizedCode = decodeHtmlEntities(codeText);
    return `${prefix}<code class="inline-code-highlight">${escapeHtml(normalizedCode)}</code>`;
  });


  // --- Step 2: Inline keyword highlighting (text nodes outside code/pre)
  const walker = document.createTreeWalker(
    el,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        let p = node.parentNode;
        while (p) {
          const name = p.nodeName;
          if (["CODE", "PRE", "SCRIPT", "STYLE"].includes(name)) return NodeFilter.FILTER_REJECT;
          p = p.parentNode;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    },
    false
  );

  const textNodes = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode);

  // Define JSON of inline "code terms" to highlight
  const inlineCodeTerms = [
    "parseFloat\\(\\)",
    "parseInt\\(\\)",
    "\\+"
  ];
  const inlineRegex = new RegExp(`\\b(${inlineCodeTerms.join("|")})\\b`, "g");

  textNodes.forEach(node => {
    const value = node.nodeValue;
    if (!inlineRegex.test(value)) return;

    let lastIndex = 0;
    const frag = document.createDocumentFragment();
    value.replace(inlineRegex, (match, p1, offset) => {
      const before = value.slice(lastIndex, offset);
      if (before) frag.appendChild(document.createTextNode(before));

      const span = document.createElement("span");
      span.className = "inline-code-highlight";
      span.textContent = match;
      frag.appendChild(span);

      lastIndex = offset + match.length;
    });

    const after = value.slice(lastIndex);
    if (after) frag.appendChild(document.createTextNode(after));

    node.parentNode.replaceChild(frag, node);
  });

  // --- Step 3: Run Prism on <pre><code> blocks
  if (typeof Prism !== "undefined" && typeof Prism.highlightAllUnder === "function") {
    Prism.highlightAllUnder(el);
    el.querySelectorAll("pre code[class^='language-']").forEach(cb => {
      try { Prism.highlightElement(cb); } catch (e) {}
    });
  } else {
    console.warn("Prism not detected. Inline highlights added, but syntax highlighting requires Prism.js.");
  }
}




// ===============================
// Fetch latest conversation
// ===============================
function fetchAndAppendLatestConversation(options) {
  const opts = options && typeof options === "object" ? options : {};
  const autoVisualEnabled = opts.autoVisualEnabled === true;
  const fetchSource = String(opts.source || "unspecified");
  const refreshConversationNavHistory = opts.refreshConversationNavHistory === true;

  console.log("Starting fetchAndAppendLatestConversation...", {
    autoVisualEnabled,
    source: fetchSource
  });
  askOraclePerfMark("fetch_and_append_start", {
    source: fetchSource,
    autoVisualEnabled,
    refreshConversationNavHistory
  });
  askOraclePerfMark("get_latest_row_start", { convId: $v("P1_CONV_ID") });

  apex.server.process(
    "GET_LATEST_CONV_ROW",
    { pageItems: "#P1_CONV_ID" },
    {
      dataType: "json",
      success: function (data) {
        askOraclePerfMark("get_latest_row_end", { rows: Array.isArray(data) ? data.length : 0 });
        console.log("GET_LATEST_CONV_ROW success callback fired");
        console.log("[POST_EXEC_DEBUG] GET_LATEST_CONV_ROW payload summary", {
          payloadType: typeof data,
          isArray: Array.isArray(data),
          length: Array.isArray(data) ? data.length : null
        });
        // console.log("Raw data received from server:", data);

        if (!data || data.length === 0) {
          removeNewPromptScrollSpacer();
          console.warn("No conversation data returned from server.");
          console.warn("[POST_EXEC_DEBUG] GET_LATEST_CONV_ROW returned no data", {
            convId: $v("P1_CONV_ID"),
            latestPromptId: $v("P1_LATEST_PROMPT_ID"),
            latestLoaderId: $v("P1_LATEST_LOADER_ID"),
            source: fetchSource
          });
          return;
        }

        const latest = data[0];
        console.log("[POST_EXEC_DEBUG] latest row basic fields", {
          id: latest && latest.id,
          conversation_prompt_id: latest && latest.conversation_prompt_id,
          conv_id: latest && latest.conv_id,
          response_type: latest && latest.response_type,
          profile_name: latest && latest.profile_name,
          promptLength: String(latest && latest.prompt || "").length,
          responseLength: String(latest && latest.response || "").length
        });
        // console.log("Latest conversation row:", latest);

        const container =
          document.querySelector("#PROMPTS .prompt-list") ||
          document.getElementById("PROMPTS");
        // console.log("Prompt container element:", container);

        if (!container) {
          removeNewPromptScrollSpacer();
          console.error("Container element not found. Cannot append prompt.");
          return;
        }

        // Normalize server prompt text for matching
        const normalizedServerPrompt = normalizePromptText(latest.prompt || "");
        // console.log("Normalized server prompt:", normalizedServerPrompt);

        // Try to find the existing frontend prompt div with matching normalized prompt text
        let matchedPromptId = null;
        for (const tempPromptId in window.pendingPrompts) {
          if (window.pendingPrompts[tempPromptId] === normalizedServerPrompt) {
            matchedPromptId = tempPromptId;
            break;
          }
        }
        console.log("Matched frontend prompt ID:", matchedPromptId);

        // If matched, update the prompt div ID to the real backend ID
        if (matchedPromptId) {
          const promptDiv = document.getElementById(matchedPromptId);
        //   console.log("Frontend prompt div found:", promptDiv);

          if (promptDiv) {
            promptDiv.id = `prompt-${latest.id}`;
            // console.log(`Updated prompt div ID to backend ID: prompt-${latest.id}`);

            // Remove old loader clone with temporary ID
            const oldLoader = document.getElementById("loading-indicator-" + matchedPromptId);
            if (oldLoader) {
              oldLoader.remove();
            //   console.log("Removed old loader with temporary ID:", matchedPromptId);
            }

            // Append new loader clone with backend ID
            const loaderRegion = document.getElementById("loading-indicator");
            if (loaderRegion) {
              const loaderClone = loaderRegion.cloneNode(true);
              loaderClone.style.display = "flex";
              loaderClone.id = "loading-indicator-" + latest.id;
              promptDiv.insertAdjacentElement("afterend", loaderClone);
            //   console.log("Appended new loader with backend ID:", loaderClone.id);

              showLoadingUI(loaderClone.id);
            }

            // Clean up mapping
            delete window.pendingPrompts[matchedPromptId];
            // console.log("Deleted temporary pendingPrompts entry for:", matchedPromptId);
          }
        }

        const responseTypeValue = String(latest.response_type || "").trim().toUpperCase();
        const rawProfileNameValue = String(latest.profile_name || "");
        const inferredAgentTeamForLabel = getPreferredAgentTeamName(latest);
        const profileNameValue =
          /^AGENT\s*\|\s*PROFILE_DROPPED\s*$/i.test(rawProfileNameValue) && inferredAgentTeamForLabel
            ? `AGENT | ${inferredAgentTeamForLabel}`
            : rawProfileNameValue;
        const isChatLayout = responseTypeValue === "CHAT";
        const isNl2SqlProfile = looksLikeNl2SqlProfileName(profileNameValue);
        const isAskAdbChatWithDb = isAskAdbChatWithDbConversationStyle();
        const conversationIdValue = String(
          latest.conv_id ||
          latest.conversation_id ||
          latest.conversationId ||
          getAskOracleCurrentConversationId() ||
          $v("P1_CONV_ID") ||
          ""
        ).trim();
        const rawConversationPromptIdValue = String(latest.conversation_prompt_id || latest.id || "").trim();
        const conversationPromptIdValue = String(rawConversationPromptIdValue || latest.id || "").trim();
        const safeExploreLinkJs = String(latest.explore_link || "").replace(/\\/g, "\\\\").replace(/'/g, "\\'");
        const safeExplainLinkJs = String(latest.explain_link || "").replace(/\\/g, "\\\\").replace(/'/g, "\\'");
        const hasSqlFooterPromptActions = !!(
          String(conversationPromptIdValue || "").trim() ||
          String(latest.explore_link || "").trim() ||
          String(latest.explain_link || "").trim()
        );
        const sqlTopButtonsHtml = "";
        const useSqlLayout = !isChatLayout;
        const sqlFooterActionButtonsHtml = isAskAdbChatWithDb ? `
                        ${hasSqlFooterPromptActions ? `
                        <button type="button" onclick="redirectToExplorePage('${conversationPromptIdValue}','${safeExploreLinkJs}','${latest.id}')"
                            class="t-Button t-Button--icon t-Button--small">
                            ${getAskOracleInlineSvgIcon("search")}
                            <span class="t-Button-label">Explore</span>
                        </button>
                        <button type="button" onclick="redirectToExplainPage('${conversationPromptIdValue}','${safeExplainLinkJs}','${latest.id}')"
                            class="t-Button t-Button--icon t-Button--small">
                            ${getAskOracleInlineSvgIcon("lightbulb")}
                            <span class="t-Button-label">Explain</span>
                        </button>
                        <button type="button" onclick="downloadResponseTableAsExcel('${latest.id}')"
                            class="t-Button t-Button--icon t-Button--small export-excel-response-btn"
                            title="Export table to Excel"
                            aria-label="Export table to Excel"
                            data-tooltip="Export Excel">
                            ${getAskOracleInlineSvgIcon("excel", "ask-oracle-icon-excel")}
                        </button>
                        ` : ""}
                        <button type="button" onclick="openResponseInEditor('${latest.id}')"
                            class="t-Button t-Button--icon t-Button--small open-editor-btn"
                            title="Code View">
                            ${getAskOracleInlineSvgIcon("code")}
                            <span class="t-Button-label">Code View</span>
                        </button>
                        ${hasSqlFooterPromptActions ? `
                        <button type="button" class="t-Button t-Button--small llm-conv-show-charts-btn toggle-charts" data-id="${latest.id}">Show Charts</button>
                        <button type="button" class="t-Button t-Button--small llm-conv-show-sql-btn toggle-sql" data-id="${latest.id}">Show SQL</button>
                        ` : ""}
        ` : `
                        ${hasSqlFooterPromptActions ? `
                        <button type="button" onclick="redirectToExplorePage('${conversationPromptIdValue}','${safeExploreLinkJs}','${latest.id}')"
                            class="t-Button t-Button--icon t-Button--small">
                            ${getAskOracleInlineSvgIcon("search")}
                            <span class="t-Button-label">Explore</span>
                        </button>
                        <button type="button" onclick="redirectToExplainPage('${conversationPromptIdValue}','${safeExplainLinkJs}','${latest.id}')"
                            class="t-Button t-Button--icon t-Button--small">
                            ${getAskOracleInlineSvgIcon("lightbulb")}
                            <span class="t-Button-label">Explain</span>
                        </button>
                        <button type="button" onclick="downloadResponseTableAsExcel('${latest.id}')"
                            class="t-Button t-Button--icon t-Button--small export-excel-response-btn"
                            title="Export table to Excel"
                            aria-label="Export table to Excel"
                            data-tooltip="Export Excel">
                            ${getAskOracleInlineSvgIcon("excel", "ask-oracle-icon-excel")}
                        </button>
                        ` : ""}
                        <button type="button" onclick="openResponseInEditor('${latest.id}')"
                            class="t-Button t-Button--icon t-Button--small open-editor-btn"
                            title="Code View">
                            ${getAskOracleInlineSvgIcon("code")}
                            <span class="t-Button-label">Code View</span>
                        </button>
                        ${hasSqlFooterPromptActions ? `
                        <button type="button" class="t-Button t-Button--small llm-conv-show-charts-btn toggle-charts" data-id="${latest.id}">Show Charts</button>
                        <button type="button" class="t-Button t-Button--small llm-conv-show-sql-btn toggle-sql" data-id="${latest.id}">Show SQL</button>
                        ` : ""}
                        <button type="button" 
                            class="speech-icon-button conversation-time-btn" 
                            data-time="${latest.conversation_time || '0 Min 0 Sec'}"
                            style="cursor: pointer;">
                            ${getAskOracleInlineSvgIcon("clock")}
                        </button>
        `;
        // Template for response
        const template = `
        <link href="https://fonts.googleapis.com/css2?family=Fira+Code&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

        ${!useSqlLayout ? `
            <div id="response-${latest.id}" data-id="${latest.id}" data-profile-name="${escapeHtml(profileNameValue)}" data-type="response" data-response-type="${escapeHtml(responseTypeValue)}" data-conversation-id="${escapeHtml(conversationIdValue)}" data-conversation-prompt-id="${escapeHtml(conversationPromptIdValue)}" class="llm-chat response response-box "></div>

            <!-- 📊 Hidden chart container (only shown when JSON data is found) -->
            <div id="chart-container-${latest.id}" 
                class="chart-container" 
                style="width:100%; margin-top:20px; display:none;"></div>

            <div class="speech-controls" data-id="${latest.id}" 
                style="display: flex; justify-content: space-between; align-items: center; padding: 6px; border-radius: 6px; margin-top: 6px; gap: 6px;">
                
                <!-- LEFT: Buttons -->
                <div style="display: inline-flex; gap: 6px;">
                    <button type="button" class="speech-icon-button" onclick="copyResponseToClipboard('${latest.id}')" data-tooltip="Copy">
                        ${getAskOracleInlineSvgIcon("copy")}
                    </button>

                    <button type="button" class="speech-icon-button" onclick="toggleSpeech('${latest.id}', this)" data-tooltip="Read Aloud">
                        ${getAskOracleInlineSvgIcon("volume")}
                    </button>

                    <button type="button" class="speech-icon-button" onclick="deletePrompt('${latest.id}', this)" data-tooltip="Delete">
                        ${getAskOracleInlineSvgIcon("trash")}
                    </button>

                    <button 
                    type="button" 
                    class="speech-icon-button conversation-time-btn" 
                    data-tooltip="${latest.conversation_time || '0 Min 0 Sec'}" 
                    style="cursor: pointer;">
                    ${getAskOracleInlineSvgIcon("clock")}
                    </button>

                    ${profileNameValue && profileNameValue.startsWith('AGENT') ? `
                    <button 
                        type="button" 
                        class="speech-icon-button view-agent-logs-btn" 
                        onclick="if('${latest.agent_link}') apex.navigation.redirect('${latest.agent_link}')" 
                        data-tooltip="View Agent Logs"
                        style="cursor: pointer;">
                        ${getAskOracleInlineSvgIcon("lightbulb")}
                    </button>
                    ` : ''}
                </div>

                <!-- RIGHT: Profile name -->
                <div style="display: inline-flex; align-items: center; gap: 8px;">
                    <span class="profile-label" 
                        style="font-size: 12px; color: #666; white-space: nowrap;">
                        ${profileNameValue || "Default"}
                    </span>
                </div>
            </div>
        ` : `
            <!-- SQL response block (unchanged) -->
            <div id="response-${latest.id}" data-id="${latest.id}" data-profile-name="${escapeHtml(profileNameValue)}" data-type="sql" data-response-type="${escapeHtml(responseTypeValue)}"
                data-conversation-id="${escapeHtml(conversationIdValue)}"
                data-conversation-prompt-id="${escapeHtml(conversationPromptIdValue)}"
                class="response response-box"
                style="margin-bottom:0;">
                <div class="loading-spinner llm-load-message-${latest.id}" style="text-align:center; padding: 10px;">
                <i class="fa fa-spinner fa-spin fa-2x"></i>
                </div>
            </div>

            ${sqlTopButtonsHtml}

            <div id="chart-block-${latest.id}" class="chart-block" style="display:none;">
            <div style="display:flex; gap:6px; margin-bottom:20px; align-items:center; flex-wrap:wrap; font-size:12px;">
                <label style="color:black;">Chart Type:</label>
                <select class="chart-type" data-id="${latest.id}" style="height:28px; font-size:12px;">
                <option value="bar">Bar</option>
                <option value="column">Column</option>
                <option value="line">Line</option>
                <option value="area">Area</option>
                <option value="pie">Pie</option>
                <option value="donut">Donut</option>
                <option value="stacked_bar">Stacked Bar</option>
                <option value="grouped_bar">Grouped Bar</option>
                <option value="scatter">Scatter</option>
                <option value="histogram">Histogram</option>
                <option value="treemap">Treemap</option>
                <option value="funnel">Funnel</option>
                <option value="gauge">Gauge</option>
                <option value="kpi_card">KPI Card</option>
                <option value="gantt">Gantt</option>
                <option value="boxplot">Box Plot</option>
                <option value="bubble">Bubble</option>
                <option value="candlestick">Candlestick / OHLC</option>
                <option value="sankey">Sankey</option>
                <option value="sunburst">Sunburst</option>
                <option value="radar">Radar</option>
                <option value="waterfall">Waterfall</option>
                <option value="heatmap">Heatmap</option>
                <option value="calendar_heatmap">Calendar Heatmap</option>
                <option value="streamgraph">Streamgraph</option>
                <option value="network_graph">Network Graph</option>
                <option value="chord">Chord Diagram</option>
                <option value="bar_race">Bar Race</option>
                </select>

                <label style="color:black;">X Axis:</label>
                <select class="chart-xaxis" data-id="${latest.id}" style="height:28px; font-size:12px;"></select>

                <label style="color:black;">Y Axis:</label>
                <select class="chart-yaxis" data-id="${latest.id}" style="height:28px; font-size:12px;"></select>

                <label style="color:black;">Aggregate:</label>
                <select class="chart-aggregation" data-id="${latest.id}" aria-label="Chart aggregation" style="height:28px; font-size:12px;">
                <option value="sum" selected>Sum</option>
                <option value="avg">Average</option>
                <option value="count">Count</option>
                <option value="min">Minimum</option>
                <option value="max">Maximum</option>
                </select>

                <label style="color:black;">Series:</label>
                <select class="chart-series" data-id="${latest.id}" style="height:28px; font-size:12px;">
                <option value="">None</option>
                </select>
            </div>

            <div class="chart-wrapper">
                <canvas id="chart-canvas-${latest.id}"></canvas>
            </div>
            </div>

            <div id="sql-block-${latest.id}" class="sql-block" style="display:none; margin-top: 8px;">
            <pre><code class="language-sql">-- SQL will be injected here --</code></pre>
            </div>

            <div style="padding:6px; border-radius:6px; margin-top:4px; margin-bottom:4px; display:flex; justify-content:space-between; align-items:flex-start;">
                <div style="display:flex; flex-direction:column; gap:4px;">
                    <span class="llm-more-rows-${latest.id}" 
                        style="display:none; font-size:12px; color:#0073e6; font-weight:500;">
                        More Rows Available
                    </span>

                    <div class="ask-oracle-sql-footer-actions" data-response-id="${latest.id}" data-has-prompt-actions="${hasSqlFooterPromptActions ? "true" : "false"}" style="display:flex; gap:4px; margin-top:4px; flex-wrap:wrap;">
                        ${sqlFooterActionButtonsHtml}
                    </div>
                </div>

                <span class="profile-label" style="font-size:12px; color:#666; white-space:nowrap;">
                    ${profileNameValue || "Default"}
                </span>
            </div>
        `}
        `;



        // console.log("Generated HTML template for latest response.");

        // Keep response attached to the prompt even while spacer is active.
        const spacer = document.getElementById(NEW_PROMPT_SCROLL_SPACER_ID);
        if (spacer && spacer.parentElement === container) {
          spacer.insertAdjacentHTML("beforebegin", template);
        } else {
          container.insertAdjacentHTML("beforeend", template);
        }
        // console.log("Appended template to container.");
        scheduleFooterScrollDownRefresh();
        ensureResponseDownloadButtons();
        const navConversationId = String(
          latest.conv_id ||
          latest.conversation_id ||
          latest.conversationId ||
          getAskOracleCurrentConversationId() ||
          $v("P1_CONV_ID") ||
          ""
        ).trim();
        const applyLatestConversationNavUpdates = function(targetConversationId) {
          const resolvedConversationId = String(targetConversationId || "").trim();
          if (!resolvedConversationId) return false;
          setAskOracleConversationIdValue(resolvedConversationId);
          askOracleActiveNavConversationId = resolvedConversationId;
          scheduleAskOracleConversationHistoryNavRefresh(resolvedConversationId, latest);
          scheduleAskOracleConversationDomCacheSnapshot(resolvedConversationId);
          stabilizeAskOracleLeftNavStructure(resolvedConversationId);
          return true;
        };
        if (!applyLatestConversationNavUpdates(navConversationId)) {
          [120, 360, 900].forEach((delay) => {
            setTimeout(function() {
              const delayedConversationId = String(
                getAskOracleCurrentConversationId() || $v("P1_CONV_ID") || ""
              ).trim();
              applyLatestConversationNavUpdates(delayedConversationId);
            }, delay);
          });
        }

        // Keep the prompt anchored near the top when response gets appended.
        // Do not auto-scroll to bottom here.

        console.log("[GET_LATEST_CONV_ROW] latest row render context", {
          id: latest.id,
          response_type: latest.response_type,
          profile_name: latest.profile_name,
          prompt_length: String(latest.prompt || "").length,
          response_length: String(latest.response || "").length
        });

        console.log("[AUTO_VISUAL] pre-request row snapshot", {
          id: latest.id,
          response_type: String(latest.response_type || ""),
          profile_name: String(latest.profile_name || ""),
          prompt_preview: String(latest.prompt || "").slice(0, 160),
          conversation_style: String(getAskOracleCurrentConversationMode() || ""),
          current_ai_profile: String($v("P1_CURRENT_AI_PROFILE") || ""),
          p1_agent_profile: String($v("P1_AGENT_PROFILE") || ""),
          p1_agent_team: String($v("P1_AGENT_TEAM") || "")
        });

        const latestResponseText = String(
          latest.response || latest.prompt_response || latest.promptResponse || ""
        );
        const latestAlreadyHasVisual = responseAlreadyHasRenderableVisual(latestResponseText);
        console.log("[AUTO_VISUAL] latest row visual check", {
          id: latest.id,
          responseLength: latestResponseText.length,
          latestAlreadyHasVisual
        });

        function continueLatestRenderPipeline() {
          askOraclePerfMark("response_render_start", { latestId: latest.id });
          // Ensure Chart.js is loaded before handling response
          ensureChartJsLoaded(() => {
            console.log("Chart.js loaded, initializing single LLM response for ID:", latest.id);

            initSingleLLMResponse(latest.id, function() {
              clearAskOracleProcessingIndicators(matchedPromptId || latest.id, latest.id);
              removeNewPromptScrollSpacer();
              hideLoadingUI("loading-indicator-" + latest.id);
              hideLoadingUI(apex.item("P1_LATEST_LOADER_ID").getValue());
              if (activeAgentTempPromptId) {
                finishedPrompts.add(activeAgentTempPromptId);
                removePonderingContainer(activeAgentTempPromptId);
                activeAgentTempPromptId = null;
                activeAgentThoughtsStopFn = null;
              }
              clearPreparingFinalResultThoughts();
              clearAllAgentThoughtContainers();

              const respEl = document.getElementById(`response-${latest.id}`);
              if (respEl) {
                highlightLanguageCodes(respEl);
                console.log("Finished processing response syntax highlighting with Prism:", {
                  id: latest.id,
                  dataType: respEl.getAttribute("data-type") || ""
                });
              } else {
                console.log("Skipping highlightLanguageCodes because response element was not found:", latest.id);
              }

              handlePotentialCodeDiffForLatestResponse(latest.id);
              if (navConversationId) {
                scheduleAskOracleConversationDomCacheSnapshot(navConversationId);
              }
              askOraclePerfMark("response_render_end", { latestId: latest.id });
              askOraclePerfFinishRun("success", { latestId: latest.id, convId: navConversationId });
            });
          });
        }

        if (autoVisualEnabled) {
          console.log("[AUTO_VISUAL] non-blocking mode: render now, auto-visual in background", {
            id: latest.id,
            source: fetchSource
          });
          continueLatestRenderPipeline();
          requestAgentAutoVisual(latest, function(meta) {
            console.log("[AUTO_VISUAL] background callback complete", { id: latest.id });
            var rerenderForVisual = !!(meta && meta.hasVisual);
            var finishBackgroundVisualCheck = function() {
              clearAskOracleProcessingIndicators(matchedPromptId || latest.id, latest.id);
              clearPreparingFinalResultThoughts();
              clearAllAgentThoughtContainers();
              if (rerenderForVisual) {
                setAutoVisualGenerationNotice(latest.id, "done", "Chart generated and attached.");
                setTimeout(function() {
                  setAutoVisualGenerationNotice(latest.id, "hide");
                }, 2500);
              } else {
                setAutoVisualGenerationNotice(latest.id, "hide");
              }
            };
            // Do not clear and type the identical agent response again when
            // auto-visual returns no chart. That caused visible restarts.
            if (rerenderForVisual) initSingleLLMResponse(latest.id, finishBackgroundVisualCheck);
            else finishBackgroundVisualCheck();
          }, { backgroundMode: true });
        } else {
          console.log("[AUTO_VISUAL] skipped for fetch context", {
            id: latest.id,
            source: fetchSource,
            reason: "autoVisualEnabled=false"
          });
          continueLatestRenderPipeline();
        }


        loadPromptHistory();

        // Restore focus to P1_PROMPT1 (retry to handle refresh timing)
        setTimeout(() => {
          const promptTextareaEl = document.getElementById("P1_PROMPT1");
          if (promptTextareaEl) {
            promptTextareaEl.focus({ preventScroll: true });
            // move cursor to end
            promptTextareaEl.selectionStart = promptTextareaEl.selectionEnd = promptTextareaEl.value.length;
            // console.log("Focus restored to P1_PROMPT1");
          } else {
            console.warn("Could not find P1_PROMPT1 to restore focus");
          }
        }, 150); // small delay so refresh completes

      },
      error: function (jqXHR, textStatus, errorThrown) {
        askOraclePerfMark("get_latest_row_error", {
          textStatus,
          status: jqXHR && jqXHR.status
        });
        askOraclePerfFinishRun("get_latest_row_error", {
          textStatus,
          status: jqXHR && jqXHR.status
        });
        console.error("GET_LATEST_CONV_ROW AJAX error:", textStatus, errorThrown);
        console.error("[POST_EXEC_DEBUG] GET_LATEST_CONV_ROW error details", {
          textStatus,
          errorThrown,
          status: jqXHR && jqXHR.status,
          statusText: jqXHR && jqXHR.statusText,
          responseTextPreview: String(jqXHR && jqXHR.responseText || "").slice(0, 500),
          convId: $v("P1_CONV_ID"),
          latestLoaderId: $v("P1_LATEST_LOADER_ID")
        });
        removeNewPromptScrollSpacer();
        if (activeAgentTempPromptId) {
          finishedPrompts.add(activeAgentTempPromptId);
          removePonderingContainer(activeAgentTempPromptId);
          activeAgentTempPromptId = null;
          activeAgentThoughtsStopFn = null;
        }

            hideLoadingUI(apex.item("P1_LATEST_LOADER_ID").getValue());

            apex.message.showErrors([
                {
                type: "error",
                location: "page",
                message: "Unexpected error occurred.",
                unsafe: false
                }
            ]);
      }
    }
  );
}


function explorePrompt(url) {
    apex.navigation.redirect(url);
}
function explainPrompt(url) {
    apex.navigation.redirect(url);
}
function deletePromptNavigation(url) {
    apex.navigation.redirect(url);
}
function agentPrompt(url) {
    apex.navigation.redirect(url);
}

function isSessionStateProtectionViolationMessage(message) {
  const text = String(message || "");
  if (!text) return false;
  return /session state protection violation/i.test(text) ||
    /manual alteration of protected page item/i.test(text);
}

function removeDeletedPromptFromBody(promptId, triggerEl) {
  const rawId = String(promptId || "").trim();
  if (!rawId) return;

  const normalizedId = rawId.replace(/^prompt-/, "").replace(/^response-/, "");
  const nodesToRemove = new Set();
  const promptEl = document.getElementById(`prompt-${normalizedId}`) || document.getElementById(rawId);
  const responseEl = document.getElementById(`response-${normalizedId}`);

  if (promptEl) {
    nodesToRemove.add(promptEl);

    const spacerEl = promptEl.previousElementSibling;
    if (
      spacerEl &&
      spacerEl.getAttribute("aria-hidden") === "true" &&
      /\bheight\s*:\s*9px\b/i.test(String(spacerEl.getAttribute("style") || ""))
    ) {
      nodesToRemove.add(spacerEl);
    }

    const promptContainer = promptEl.closest(".prompt-container");
    if (promptContainer) nodesToRemove.add(promptContainer);
  }

  if (responseEl) {
    nodesToRemove.add(responseEl);
    const responseContainer = responseEl.closest(".prompt-container");
    if (responseContainer) nodesToRemove.add(responseContainer);
  }

  if (triggerEl && typeof triggerEl.closest === "function") {
    const triggerContainer = triggerEl.closest(".prompt-container");
    if (triggerContainer) nodesToRemove.add(triggerContainer);
  }

  document.querySelectorAll(`.speech-controls[data-id="${normalizedId}"]`).forEach((node) => {
    nodesToRemove.add(node);
  });
  document.querySelectorAll(`.chart-sql-buttons[data-response-id="${normalizedId}"], .ask-oracle-response-table-actions[data-response-id="${normalizedId}"]`).forEach((node) => {
    nodesToRemove.add(node);
  });

  [
    `chart-container-${normalizedId}`,
    `chart-block-${normalizedId}`,
    `sql-block-${normalizedId}`,
    `loading-indicator-${normalizedId}`
  ].forEach((elementId) => {
    const node = document.getElementById(elementId);
    if (node) nodesToRemove.add(node);
  });

  nodesToRemove.forEach((node) => {
    try { node.remove(); } catch (e) {}
  });

  if (responseTableZoomById && typeof responseTableZoomById === "object") {
    delete responseTableZoomById[normalizedId];
  }

  scheduleFooterScrollDownRefresh();
}

async function deletePrompt(promptId, triggerEl) {
  console.log("🗑️ Delete button clicked. Prompt ID:", promptId);

  const confirmed = await showAppConfirmDialog(
    "Are you sure you want to delete this prompt?",
    { title: "Delete Prompt", confirmLabel: "Delete", cancelLabel: "Cancel" }
  );
  if (!confirmed) {
    console.log("Delete cancelled by user.");
    return; // exit if user cancels
  }

  apex.server.process(
    "DELETE_PROMPT",      // AJAX process name
    { x01: promptId },    // pass promptId as x01
    {
      dataType: "json",   // expecting JSON response
      success: function(pData) {
        console.log("AJAX call SUCCESS. Server response:", pData);

        if (pData.status === "success") {
          try { apex.message.clearErrors(); } catch (e) {}
          apex.message.showPageSuccess("Prompt Deleted Successfully");
          removeDeletedPromptFromBody(promptId, triggerEl);
        } else {
          console.error("Server returned error:", pData.message);
          const serverMessage = String(pData.message || "");
          if (isSessionStateProtectionViolationMessage(serverMessage)) {
            try { apex.message.clearErrors(); } catch (e) {}
            return;
          }
          apex.message.clearErrors();
          apex.message.showErrors([{
            type: "error",
            location: "page",
            message: "Failed to delete prompt: " + (serverMessage || "Unknown error"),
            unsafe: false
          }]);
        }
      },
      error: function(xhr, status, error) {
        console.error("AJAX request FAILED");
        console.error("Status:", status);
        console.error("Error:", error);
        console.error("Response Text:", xhr.responseText);
        const responseText = String((xhr && xhr.responseText) || "");
        if (isSessionStateProtectionViolationMessage(responseText)) {
          try { apex.message.clearErrors(); } catch (e) {}
          return;
        }
        apex.message.clearErrors();
        apex.message.showErrors([{
          type: "error",
          location: "page",
          message: "Failed to delete prompt. Check console for details.",
          unsafe: false
        }]);
      }
    }
  );
}



$(document).on("click", ".conversation-time-btn", function() {
    let time = $(this).attr("data-time") || "0 Min 0 Sec"; // get updated value
    let $tooltip = $('<div class="temp-tooltip"></div>').text(time)
        .css({
            position: 'absolute',
            background: '#333',
            color: '#fff',
            padding: '4px 8px',
            borderRadius: '4px',
            fontSize: '12px',
            zIndex: 9999,
            whiteSpace: 'nowrap'
        });

    $('body').append($tooltip);

    let offset = $(this).offset();
    $tooltip.css({
        top: offset.top - $tooltip.outerHeight() - 6,
        left: offset.left + $(this).outerWidth()/2 - $tooltip.outerWidth()/2
    });

    setTimeout(() => {
        $tooltip.fadeOut(300, () => $tooltip.remove());
    }, 2000);
});




// function addFullScreenScroll() {
//   // Remove old spacer if exists
//   let spacer = document.getElementById("fullScreenScrollSpacer");
//   if (!spacer) {
//     spacer = document.createElement("div");
//     spacer.id = "fullScreenScrollSpacer";
//     document.body.appendChild(spacer);
//   }

//   // Always set spacer height so that total = viewport height
//   const contentHeight = document.body.scrollHeight - spacer.offsetHeight;
//   const needed = window.innerHeight - contentHeight;
//   spacer.style.height = (needed > 0 ? needed : 0) + "px";
// }

// window.addEventListener("load", addFullScreenScroll);
// window.addEventListener("resize", addFullScreenScroll);



function adjustPadding() {
  const content = document.querySelector('.t-Body-content');
  if (!content) return;

  // Use viewport width for stable in-page layout decisions.
  const screenWidth = window.innerWidth || document.documentElement.clientWidth;

  if (screenWidth > 1900) {   // external monitor
    content.style.paddingLeft = "296px";
    content.style.paddingRight = "296px";
  } else if (screenWidth > 1200) { // laptop
    content.style.paddingLeft = "156px";
    content.style.paddingRight = "156px";
  } else if (screenWidth > 768) {
    content.style.paddingLeft = "100px";
    content.style.paddingRight = "100px";
  } else {
    content.style.paddingLeft = "20px";
    content.style.paddingRight = "20px";
  }
}

// Run once after DOM is ready to avoid repeated visual reflow.
document.addEventListener("DOMContentLoaded", adjustPadding, { once: true });

function applyFooterAppearance() {
  const footer = document.querySelector(".t-Footer");
  if (!footer) return;

  function isTransparentColor(value) {
    const v = String(value || "").trim().toLowerCase();
    return !v || v === "transparent" || v === "rgba(0, 0, 0, 0)" || v === "rgba(0,0,0,0)";
  }

  function parseRgbColor(value) {
    const match = String(value || "").match(
      /rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)(?:\s*,\s*([0-9.]+))?\s*\)/i
    );
    if (!match) return null;
    return {
      r: Number(match[1]) || 0,
      g: Number(match[2]) || 0,
      b: Number(match[3]) || 0,
      a: match[4] === undefined ? 1 : Number(match[4])
    };
  }

  function isDarkColor(value) {
    const rgb = parseRgbColor(value);
    if (!rgb) return false;
    if (Number.isFinite(rgb.a) && rgb.a <= 0) return false;
    const luminance = (0.2126 * rgb.r + 0.7152 * rgb.g + 0.0722 * rgb.b) / 255;
    return luminance < 0.58;
  }

  function hasApexDarkThemeClass() {
    const classes = `${document.documentElement.className || ""} ${document.body.className || ""}`.toLowerCase();
    if (/(?:^|\s)(t-body--dark|u-theme--dark|dark-mode|theme-dark|is-dark)(?:\s|$)/.test(classes)) return true;
    if (/\bdark\b/.test(classes) || classes.indexOf("dark") >= 0) return true;

    const dataTheme = `${document.documentElement.getAttribute("data-theme") || ""} ${document.body.getAttribute("data-theme") || ""}`.toLowerCase();
    if (dataTheme.indexOf("dark") >= 0) return true;

    const rootColorScheme = String(window.getComputedStyle(document.documentElement).colorScheme || "").toLowerCase();
    const bodyColorScheme = String(window.getComputedStyle(document.body).colorScheme || "").toLowerCase();
    return rootColorScheme.indexOf("dark") >= 0 || bodyColorScheme.indexOf("dark") >= 0;
  }

  function isAnyDarkSurfacePresent() {
    const candidates = [
      document.querySelector(".t-Body-content"),
      document.getElementById("t_Body_content"),
      document.querySelector(".t-Body-main"),
      document.getElementById("t_PageBody"),
      document.querySelector("#PROMPTS"),
      document.querySelector("#PROMPTS .prompt-list"),
      document.querySelector("#PROMPTS .t-Region-body"),
      document.body
    ];
    return candidates.some((el) => {
      if (!el) return false;
      const bg = window.getComputedStyle(el).backgroundColor;
      return !isTransparentColor(bg) && isDarkColor(bg);
    });
  }

  function setStyle(el, property, value, important) {
    if (!el) return;
    if (value === "" || value == null) {
      el.style.removeProperty(property);
      return;
    }
    el.style.setProperty(property, value, important ? "important" : "");
  }

  function safeQuery(selector) {
    try {
      return document.querySelector(selector);
    } catch (e) {
      return null;
    }
  }

  function getPromptSurfaceBackgroundColor() {
    const candidates = [
      document.querySelector(".t-Body-content"),
      document.getElementById("t_Body_content"),
      document.querySelector(".t-Body-main"),
      document.body,
      document.querySelector("#PROMPTS .llm-chat.response-box"),
      document.querySelector("#PROMPTS .response-box"),
      document.querySelector("#PROMPTS .llm-chat"),
      document.querySelector("#PROMPTS .prompt-list"),
      document.querySelector("#PROMPTS .t-Region-body"),
      document.querySelector("#PROMPTS")
    ];

    for (const el of candidates) {
      if (!el) continue;
      const bg = window.getComputedStyle(el).backgroundColor;
      if (!isTransparentColor(bg)) return bg;
    }
    return window.getComputedStyle(document.body).backgroundColor;
  }

  function isElementVisible(el) {
    if (!el) return false;
    if (el.hidden) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
    if (el.getAttribute("aria-hidden") === "true") return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isAnyDialogOpen() {
    if (document.querySelector("dialog[open]")) return true;

    const candidates = document.querySelectorAll(
      ".ui-dialog, .ui-widget-overlay, .a-DialogRegion, .t-Dialog-page, .a-PopupLOV, .js-regionDialog, .modal.show, .modal-backdrop.show"
    );
    return Array.from(candidates).some(isElementVisible);
  }

  const dialogOpen = isAnyDialogOpen();
  const isCenterMode = document.body.classList.contains("prompt-center-mode");
  const isEditorMode = document.body.classList.contains("code-editor-mode");
  const directAddPromptBtn = document.getElementById("addPrompt");
  const directRunPromptBtn = document.getElementById("runPrompt");

  if (dialogOpen && !isEditorMode) {
    footer.style.visibility = "hidden";
    footer.style.pointerEvents = "none";
    [directAddPromptBtn, directRunPromptBtn].forEach((btn) => {
      if (!btn) return;
      btn.style.setProperty("display", "none", "important");
      btn.style.setProperty("visibility", "hidden", "important");
      btn.style.setProperty("pointer-events", "none", "important");
    });
    return;
  }

  footer.style.visibility = "";
  footer.style.pointerEvents = "";
  footer.style.display = "";
  [directAddPromptBtn, directRunPromptBtn].forEach((btn) => {
    if (!btn) return;
    btn.style.removeProperty("display");
    btn.style.removeProperty("visibility");
    btn.style.removeProperty("pointer-events");
  });
  const footerSurfaceBg = getPromptSurfaceBackgroundColor();
  const darkUi = false;
  const appliedSurfaceBg = footerSurfaceBg;
  document.body.classList.remove("ask-oracle-dark-ui");
  document.documentElement.style.setProperty("--ask-oracle-footer-surface", appliedSurfaceBg || "");

  const footerBody = footer.querySelector(".t-Footer-body");
  const footerContent = footer.querySelector(".t-Footer-content");
  const promptWrapper = document.getElementById("promptWrapper");
  const promptTemplate = document.getElementById("PROMPTS_TemplateComponent");
  const promptInput = document.getElementById("P1_PROMPT1");
  const outerPromptShells = [
    promptWrapper,
    promptInput ? promptInput.closest(".prompt-wrapper") : null,
    document.querySelector(".prompt-wrapper"),
    document.getElementById("P1_PROMPT2"),
    document.getElementById("P1_PROMPT2_CONTAINER"),
    document.getElementById("P1_PROMPT2_display")
  ].filter(Boolean);
  const innerPromptShells = [
    document.getElementById("P1_PROMPT1_CONTAINER"),
    document.getElementById("P1_PROMPT1_display")
  ].filter(Boolean);
  const addPromptBtn = document.getElementById("addPrompt");
  const micPromptBtn = document.getElementById("startSpeechButton");
  const runPromptBtn = document.getElementById("runPrompt");
  const centerTitle = document.getElementById("center-prompt-title");
  updateAskOracleConversationModeChip();
  const promptWrapperInputs = promptWrapper
    ? Array.from(
        promptWrapper.querySelectorAll(
          "textarea, input, .apex-item-text, .apex-item-textarea, .t-Form-inputContainer, .t-Form-textarea"
        )
      )
    : [];
  const promptWrapperButtons = promptWrapper
    ? Array.from(promptWrapper.querySelectorAll("button, .t-Button, [role='button']")).filter((btn) => {
        return !(btn && typeof btn.closest === "function" && btn.closest("#plusMenu"));
      })
    : [];
  const promptWrapperIcons = promptWrapper
    ? Array.from(promptWrapper.querySelectorAll("i, svg, .t-Icon")).filter((iconEl) => {
        return !(iconEl && typeof iconEl.closest === "function" && iconEl.closest("#plusMenu"));
      })
    : [];
  const addPromptButtons = Array.from(
    new Set(
      [addPromptBtn, safeQuery("#promptWrapper #addPrompt"), safeQuery("#promptWrapper [aria-label*='add' i]")]
        .filter(Boolean)
    )
  );
  const micPromptButtons = Array.from(
    new Set(
      [
        micPromptBtn,
        safeQuery("#promptWrapper #startSpeechButton"),
        safeQuery("#promptWrapper [aria-label*='mic']"),
        safeQuery("#promptWrapper [aria-label*='voice']"),
        safeQuery("#promptWrapper [title*='mic']"),
        safeQuery("#promptWrapper [title*='voice']"),
        safeQuery("#promptWrapper [id*='speech']"),
        safeQuery("#promptWrapper [class*='speech']")
      ].filter(Boolean)
    )
  );

  const applyFooterSurface = true;
  [footerBody, footerContent, promptWrapper, promptTemplate].forEach((el) => {
    setStyle(el, "background-color", applyFooterSurface ? appliedSurfaceBg : "", true);
    setStyle(el, "width", isEditorMode ? "100%" : "", true);
    setStyle(el, "max-width", isEditorMode ? "none" : "", true);
  });

  setStyle(promptInput, "--ask-oracle-prompt-placeholder", darkUi ? "#cbd5e1" : "#6b7280", false);
  setStyle(promptInput, "width", isEditorMode ? "100%" : "", true);
  setStyle(promptInput, "max-width", isEditorMode ? "none" : "", true);
  setStyle(promptInput, "margin", "0", true);
  setStyle(promptInput, "margin-top", "0", true);
  setStyle(promptInput, "margin-bottom", "0", true);
  setStyle(promptInput, "margin-left", "0", true);
  setStyle(promptInput, "margin-right", "0", true);
  if (darkUi) {
    setStyle(promptInput, "background-color", appliedSurfaceBg, true);
    setStyle(promptInput, "color", "#f8fafc", true);
    setStyle(promptInput, "caret-color", "#f8fafc", true);
    setStyle(promptInput, "border-color", "transparent", true);
    setStyle(promptInput, "border", "0", true);
    setStyle(promptInput, "box-shadow", "none", true);
    setStyle(promptInput, "outline", "none", true);
    [footer, footerBody, footerContent, promptTemplate].forEach((el) => {
      setStyle(el, "border", "0", true);
      setStyle(el, "box-shadow", "none", true);
      setStyle(el, "background-image", "none", true);
    });
    outerPromptShells.forEach((el) => {
      setStyle(el, "background-color", appliedSurfaceBg, true);
      setStyle(el, "border", "1px solid rgba(148, 163, 184, 0.6)", true);
      setStyle(el, "box-shadow", "none", true);
      setStyle(el, "background-image", "none", true);
      setStyle(el, "width", isEditorMode ? "100%" : "", true);
      setStyle(el, "max-width", isEditorMode ? "none" : "", true);
    });
    innerPromptShells.forEach((el) => {
      setStyle(el, "background-color", appliedSurfaceBg, true);
      setStyle(el, "border", "0", true);
      setStyle(el, "box-shadow", "none", true);
      setStyle(el, "outline", "none", true);
      setStyle(el, "background-image", "none", true);
      setStyle(el, "width", isEditorMode ? "100%" : "", true);
      setStyle(el, "max-width", isEditorMode ? "none" : "", true);
    });
    promptWrapperInputs.forEach((el) => {
      setStyle(el, "background-color", appliedSurfaceBg, true);
      setStyle(el, "color", "#f8fafc", true);
      setStyle(el, "border", "0", true);
      setStyle(el, "box-shadow", "none", true);
      setStyle(el, "outline", "none", true);
    });
    promptWrapperButtons.forEach((btn) => {
      setStyle(btn, "background-color", appliedSurfaceBg, true);
      setStyle(btn, "background-image", "none", true);
      setStyle(btn, "border", "0", true);
      setStyle(btn, "box-shadow", "none", true);
      setStyle(btn, "color", "#f8fafc", true);
      setStyle(btn, "opacity", "1", true);
      setStyle(btn, "visibility", "visible", true);
    });
    promptWrapperIcons.forEach((iconEl) => {
      setStyle(iconEl, "color", "#f8fafc", true);
      setStyle(iconEl, "fill", "currentColor", true);
      setStyle(iconEl, "stroke", "currentColor", true);
      setStyle(iconEl, "opacity", "1", true);
      setStyle(iconEl, "visibility", "visible", true);
    });
    [...addPromptButtons, ...micPromptButtons].forEach((btn) => {
      setStyle(btn, "color", "#f8fafc", true);
      setStyle(btn, "border", "0", true);
      setStyle(btn, "background-color", appliedSurfaceBg, true);
      setStyle(btn, "background-image", "none", true);
      setStyle(btn, "opacity", "1", true);
      setStyle(btn, "visibility", "visible", true);
    });
    setStyle(runPromptBtn, "border", "0", true);
    setStyle(runPromptBtn, "color", "#f8fafc", true);
    setStyle(runPromptBtn, "opacity", "1", true);
    setStyle(runPromptBtn, "visibility", "visible", true);
    setStyle(runPromptBtn, "background-image", "none", true);
    if (runPromptBtn) runPromptBtn.style.backgroundColor = appliedSurfaceBg;
    setStyle(centerTitle, "color", "#f8fafc", true);
  } else {
    setStyle(promptInput, "background-color", "", true);
    setStyle(promptInput, "color", "", true);
    setStyle(promptInput, "caret-color", "", true);
    setStyle(promptInput, "border-color", "transparent", true);
    setStyle(promptInput, "border", "0", true);
    setStyle(promptInput, "box-shadow", "none", true);
    setStyle(promptInput, "outline", "none", true);
    [...addPromptButtons, ...micPromptButtons, runPromptBtn].forEach((btn) => {
      setStyle(btn, "color", "", true);
      setStyle(btn, "border-color", "", true);
      setStyle(btn, "border", "", true);
      setStyle(btn, "background-color", "", true);
      setStyle(btn, "background-image", "", true);
      setStyle(btn, "opacity", "", true);
      setStyle(btn, "visibility", "", true);
    });
    promptWrapperInputs.forEach((el) => {
      setStyle(el, "background-color", "", true);
      setStyle(el, "color", "", true);
      setStyle(el, "border", "0", true);
      setStyle(el, "box-shadow", "none", true);
      setStyle(el, "outline", "none", true);
    });
    outerPromptShells.forEach((el) => {
      setStyle(el, "background-color", "", true);
      setStyle(el, "border", "", true);
      setStyle(el, "box-shadow", "", true);
      setStyle(el, "background-image", "", true);
      setStyle(el, "width", isEditorMode ? "100%" : "", true);
      setStyle(el, "max-width", isEditorMode ? "none" : "", true);
    });
    innerPromptShells.forEach((el) => {
      setStyle(el, "background-color", "", true);
      setStyle(el, "border", "0", true);
      setStyle(el, "box-shadow", "none", true);
      setStyle(el, "outline", "none", true);
      setStyle(el, "background-image", "", true);
      setStyle(el, "width", isEditorMode ? "100%" : "", true);
      setStyle(el, "max-width", isEditorMode ? "none" : "", true);
    });
    setStyle(centerTitle, "color", "", true);
  }
  if (isCenterMode && !isEditorMode) {
    const centerShellBorder = darkUi ? "1px solid rgba(148, 163, 184, 0.6)" : "1px solid #d1d5db";
    outerPromptShells.forEach((el) => {
      setStyle(el, "border", centerShellBorder, true);
      setStyle(el, "border-radius", "26px", true);
      setStyle(el, "min-height", "52px", true);
      setStyle(el, "height", "auto", true);
      setStyle(el, "padding", "0 12px", true);
      setStyle(el, "overflow", "visible", true);
      setStyle(el, "box-shadow", "none", true);
    });
  }
  const showAddPromptInCurrentMode = !!isCenterMode && isAskOracleEndUserConvStyleSwitchEnabled();
  const plusMenu = document.getElementById("plusMenu");
  if (!showAddPromptInCurrentMode && plusMenu) {
    plusMenu.classList.remove("active");
    if (promptWrapper) promptWrapper.classList.remove("menu-open");
  }
  addPromptButtons.forEach((btn) => {
    setStyle(btn, "display", showAddPromptInCurrentMode ? "inline-flex" : "none", true);
    setStyle(btn, "visibility", showAddPromptInCurrentMode ? "visible" : "hidden", true);
    setStyle(btn, "pointer-events", showAddPromptInCurrentMode ? "auto" : "none", true);
  });
  refreshRunPromptButtonState();

  if (isEditorMode) {
    footer.style.setProperty("background-color", appliedSurfaceBg, "important");
    footer.style.opacity = "1";
    setStyle(footer, "border", darkUi ? "0" : "", true);
    return;
  }
  setStyle(footer, "background-color", darkUi ? appliedSurfaceBg : (isCenterMode ? "transparent" : appliedSurfaceBg), true);
  setStyle(footer, "border", darkUi ? "0" : "", true);
}

function initFooterAppearanceSync() {
  let syncQueued = false;
  function scheduleFooterSync() {
    if (syncQueued) return;
    syncQueued = true;
    requestAnimationFrame(() => {
      syncQueued = false;
      applyFooterAppearance();
      positionCenterPromptBar();
      positionFooterPromptBar();
      scheduleFooterScrollDownRefresh();
    });
  }

  applyFooterAppearance();
  window.addEventListener("resize", scheduleFooterSync);

  if (window.apex && apex.jQuery) {
    apex.jQuery(document).on("dialogopen dialogclose apexafterclosedialog apexaftershowdialog", scheduleFooterSync);
  }

  const navToggleBtn =
    document.querySelector("#t_Button_navControl") ||
    document.querySelector("#t_Button_sidebarControl") ||
    document.querySelector("[data-action='nav-toggle']");
  if (navToggleBtn) {
    navToggleBtn.addEventListener("click", () => {
      setTimeout(scheduleFooterSync, 30);
      setTimeout(scheduleFooterSync, 260);
    });
  }

  const dialogMutationObserver = new MutationObserver(scheduleFooterSync);
  dialogMutationObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "style", "open", "aria-hidden"]
  });

  // Fallback polling for popup frameworks that do not emit dialog events.
  setInterval(scheduleFooterSync, 250);
}

document.addEventListener("DOMContentLoaded", initFooterAppearanceSync, { once: true });
document.addEventListener("DOMContentLoaded", syncPromptBarMode, { once: true });
document.addEventListener("DOMContentLoaded", schedulePromptBarAlignmentResync, { once: true });
document.addEventListener("DOMContentLoaded", initFooterScrollDownArrow, { once: true });
document.addEventListener("DOMContentLoaded", () => focusPromptInputForCaret(120), { once: true });
document.addEventListener("DOMContentLoaded", () => focusCenterPromptBarAfterReload(), { once: true });
document.addEventListener("DOMContentLoaded", bindPromptInputResizeBehavior, { once: true });
document.addEventListener("DOMContentLoaded", ensureResponseDownloadButtons, { once: true });
document.addEventListener("DOMContentLoaded", bindAgentTeamScrollPreserve, { once: true });
document.addEventListener("DOMContentLoaded", restoreAskOracleScrollStateIfPending, { once: true });
window.addEventListener("load", schedulePromptBarAlignmentResync, { once: true });
window.addEventListener("load", focusCenterPromptBarAfterReload, { once: true });
window.addEventListener("pageshow", function(event) {
  if (event && event.persisted) {
    focusCenterPromptBarAfterReload();
  }
});
document.addEventListener("DOMContentLoaded", function() {
  scheduleAskOracleAdminUiStateApply(true);
}, { once: true });

if (window.apex && apex.jQuery) {
  apex.jQuery(document).on("apexafterrefresh", function() {
    bootstrapAskOraclePromptCoreElementsWithRetry();
    bindRunPromptClickHandler();
    focusPromptInputForCaret(80);
    focusCenterPromptBarAfterReload();
    bindPromptInputResizeBehavior();
    autoGrowPromptInput();
    ensureResponseDownloadButtons();
    bindAgentTeamScrollPreserve();
    restoreAskOracleScrollStateIfPending();
    scheduleAskOracleAdminUiStateApply(false);
  });
  apex.jQuery(document).on("apexafterclosedialog", function() {
    scheduleAskOracleAdminUiStateApply(true);
  });
}

window.addEventListener("storage", function(event) {
  if (!event || event.key !== ASK_ORACLE_UI_SYNC_KEY) return;
  scheduleAskOracleAdminUiStateApply(true);
});
window.addEventListener("askoracleuisyncchange", function() {
  scheduleAskOracleAdminUiStateApply(true);
});


function adjustLineHeight() {
  document.querySelectorAll(".message-bubble").forEach(el => {
    // Check if text takes more than one line
    if (el.scrollHeight > el.clientHeight + 1) {
      el.classList.add("multi-line");
    } else {
      el.classList.remove("multi-line");
    }
  });
}

// Run on load and when window resizes
window.addEventListener("load", adjustLineHeight);
window.addEventListener("resize", adjustLineHeight);



// Global variables
var promptHistory = [];
var currentIndex = -1;

function toPromptHistoryList(raw) {
  const source = Array.isArray(raw) ? raw : [];
  return source
    .map((entry) => {
      if (typeof entry === "string") return entry.trim();
      if (entry && typeof entry === "object") {
        return String(
          entry.prompt ??
          entry.PROMPT ??
          entry.text ??
          entry.TEXT ??
          entry.value ??
          entry.VALUE ??
          ""
        ).trim();
      }
      return "";
    })
    .filter(Boolean);
}

function parsePromptHistoryResponse(response) {
  if (Array.isArray(response)) return toPromptHistoryList(response);

  if (typeof response === "string") {
    try {
      return toPromptHistoryList(JSON.parse(response));
    } catch (e) {
      return [];
    }
  }

  if (response && typeof response === "object") {
    if (Array.isArray(response.data)) return toPromptHistoryList(response.data);
    if (Array.isArray(response.rows)) return toPromptHistoryList(response.rows);
    if (Array.isArray(response.prompts)) return toPromptHistoryList(response.prompts);

    if (typeof response.data === "string") {
      try {
        return toPromptHistoryList(JSON.parse(response.data));
      } catch (e) {}
    }
    if (typeof response.prompts === "string") {
      try {
        return toPromptHistoryList(JSON.parse(response.prompts));
      } catch (e) {}
    }
  }

  return [];
}

function loadPromptHistory(callback) {
  apex.server.process("GET_PROMPT_HISTORY", { pageItems: "#P1_CONV_ID" }, {
    success: function(response) {
      if (response.error) {
        console.error("Error loading prompts:", response.error);
        return;
      }
      try {
        promptHistory = parsePromptHistoryResponse(response);
        currentIndex = -1;
        if (typeof callback === "function") {
          callback(promptHistory);
        }
      } catch (e) {
        console.error("Failed to parse JSON:", e);
      }
    }
  });
}

function attachPromptHistoryNavigation(inputId) {
  ensureAskOraclePromptCoreElements();
  const input = document.getElementById(inputId);
  if (!input) {
    const retryKey = `promptHistoryRetry:${inputId}`;
    window.__askOraclePromptHistoryRetryCount = window.__askOraclePromptHistoryRetryCount || {};
    const retries = Number(window.__askOraclePromptHistoryRetryCount[retryKey] || 0);
    if (retries < 20) {
      window.__askOraclePromptHistoryRetryCount[retryKey] = retries + 1;
      setTimeout(() => attachPromptHistoryNavigation(inputId), 250);
    }
    return;
  }
  if (window.__askOraclePromptHistoryRetryCount) {
    delete window.__askOraclePromptHistoryRetryCount[`promptHistoryRetry:${inputId}`];
  }

  if (input.dataset.promptHistoryBound === "true") return;
  input.dataset.promptHistoryBound = "true";

  input.addEventListener("keydown", function(e) {
    const value = String(this.value || "");
    const hasSelection = this.selectionStart !== this.selectionEnd;
    const firstNewLine = value.indexOf("\n");
    const lastNewLine = value.lastIndexOf("\n");
    const useHistoryShortcut = !!(e.ctrlKey || e.metaKey || e.altKey);
    const canUseHistoryUp = useHistoryShortcut || (!hasSelection && (
      value === "" || (firstNewLine >= 0 && this.selectionStart <= firstNewLine)
    ));
    const canUseHistoryDown = useHistoryShortcut || (!hasSelection && (
      value === "" || (lastNewLine >= 0 && this.selectionStart > lastNewLine)
    ));
    if (e.key === "ArrowUp") {
      if (!canUseHistoryUp) return;
      e.preventDefault();
      if (promptHistory.length > 0 && currentIndex > 0) {
        currentIndex--;
        this.value = promptHistory[currentIndex];
        autoGrowPromptInput();
        refreshRunPromptButtonState();
      } else if (currentIndex === -1 && promptHistory.length > 0) {
        // First press of ArrowUp starts at last item
        currentIndex = promptHistory.length - 1;
        this.value = promptHistory[currentIndex];
        autoGrowPromptInput();
        refreshRunPromptButtonState();
      }
      // Do nothing if already at first item
    } else if (e.key === "ArrowDown") {
      if (!canUseHistoryDown) return;
      e.preventDefault();
      if (promptHistory.length > 0 && currentIndex >= 0 && currentIndex < promptHistory.length - 1) {
        currentIndex++;
        this.value = promptHistory[currentIndex];
        autoGrowPromptInput();
        refreshRunPromptButtonState();
      }
      // Move back to blank input after the latest history item.
      else if (currentIndex === promptHistory.length - 1) {
        currentIndex = -1;
        this.value = "";
        autoGrowPromptInput();
        refreshRunPromptButtonState();
      }
    }
  });
}

function initPromptHistoryNavigation() {
  attachPromptHistoryNavigation("P1_PROMPT1");
  loadPromptHistory();
}

function rebindPromptHistoryNavigation() {
  attachPromptHistoryNavigation("P1_PROMPT1");
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initPromptHistoryNavigation, { once: true });
} else {
  initPromptHistoryNavigation();
}

if (window.apex && apex.jQuery) {
  apex.jQuery(document).on("apexafterrefresh", function() {
    rebindPromptHistoryNavigation();
  });
}

window.loadPromptHistory = loadPromptHistory;
window.attachPromptHistoryNavigation = attachPromptHistoryNavigation;
window.initPromptHistoryNavigation = initPromptHistoryNavigation;
window.copyResponseToClipboard = copyResponseToClipboard;
window.copyPromptToClipboard = copyPromptToClipboard;
window.shareNl2SqlResponse = shareNl2SqlResponse;
window.downloadResponseToFile = downloadResponseToFile;
window.downloadResponseTableAsExcel = downloadResponseTableAsExcel;
window.exportConversationToPdf = exportConversationToPdf;
window.exportConversationHistoryThreadToPdf = exportConversationHistoryThreadToPdf;
window.openResponseInEditor = openResponseInEditor;



var finishedPrompts = new Set();

// ===================================================
// Helper: Remove Placeholder Container
// ===================================================
function removePonderingContainer(tempPromptId) {
    const container = document.getElementById(tempPromptId);
    if (!container) return;

    // Stop all intervals safely
    if (container._dotInterval) {
        clearInterval(container._dotInterval);
        container._dotInterval = null;
    }
    if (container._localDotInterval) {
        clearInterval(container._localDotInterval);
        container._localDotInterval = null;
    }

    // Remove any thinking element inside
    const thinkingEl = container.querySelector(".thinking");
    if (thinkingEl) thinkingEl.remove();

    // Remove container itself
    container.remove();
}

function clearPreparingFinalResultThoughts() {
    try {
        const containers = document.querySelectorAll(".agent-thoughts");
        containers.forEach((container) => {
            if (!container) return;
            const thinkingEl = container.querySelector(".thinking");
            const thinkingText = String(thinkingEl ? (thinkingEl.textContent || "") : "").toLowerCase();
            const hasPreparingFinal =
                /prepar(ing|e|ed)\s+(the\s+)?final\s+result/.test(thinkingText) ||
                /preparting\s+(the\s+)?final\s+result/.test(thinkingText);
            if (!hasPreparingFinal) return;

            if (container._dotInterval) {
                clearInterval(container._dotInterval);
                container._dotInterval = null;
            }
            if (container._localDotInterval) {
                clearInterval(container._localDotInterval);
                container._localDotInterval = null;
            }
            if (thinkingEl) thinkingEl.remove();

            const hasOtherContent = Array.from(container.children || []).some((child) => {
                if (!child) return false;
                return String(child.className || "").indexOf("thought-step-collapsible") >= 0;
            });
            if (!hasOtherContent) container.remove();
        });
    } catch (e) {
        console.warn("Failed to clear stale final-result thought rows:", e);
  }
}

function clearAllAgentThoughtContainers() {
  try {
    document.querySelectorAll(".agent-thoughts").forEach((container) => {
      if (!container) return;
      if (container._dotInterval) {
        clearInterval(container._dotInterval);
        container._dotInterval = null;
      }
      if (container._localDotInterval) {
        clearInterval(container._localDotInterval);
        container._localDotInterval = null;
      }
      try { container.remove(); } catch (e) {}
    });
  } catch (e) {
    console.warn("Failed to clear stale thought containers:", e);
  }
}

// ===================================================
// Helper: Insert Placeholder Container
// ===================================================
function insertThoughtsContainer(tempPromptId) {
    if (finishedPrompts.has(tempPromptId)) return; // ❌ Do not insert after final
    ensureAskOracleProgressStatusAnimationCss();

    const chatArea = document.querySelector("#PROMPTS .prompt-list") || document.getElementById("PROMPTS");
    if (!chatArea) {
        console.error("Cannot insert thoughts container: PROMPTS container not found");
        return;
    }

    const div = document.createElement("div");
    div.id = tempPromptId;
    div.className = "agent-thoughts";
    div.innerHTML = `
        <div class='thinking ask-oracle-progress-status' style="font-weight:600; font-size:0.95em;">
            <span class="ask-oracle-progress-status__icon">💡</span>
            <span class="ask-oracle-progress-status__text">Submitting Request</span>
            <span class="dots">.....</span>
        </div>
    `;
    const latestPromptId = String($v("P1_LATEST_PROMPT_ID") || "").trim();
    const latestPromptEl = latestPromptId ? document.getElementById(latestPromptId) : null;
    const latestLoaderId = String($v("P1_LATEST_LOADER_ID") || "").trim();
    const latestLoaderEl = latestLoaderId ? document.getElementById(latestLoaderId) : null;

    if (latestLoaderEl) {
        latestLoaderEl.style.display = "none";
    }

    if (latestPromptEl && latestPromptEl.parentElement === chatArea) {
        const anchorNode = latestLoaderEl && latestLoaderEl.parentElement === chatArea
            ? latestLoaderEl.nextSibling
            : latestPromptEl.nextSibling;
        chatArea.insertBefore(div, anchorNode || null);
    } else {
        const spacer = document.getElementById(NEW_PROMPT_SCROLL_SPACER_ID);
        if (spacer && spacer.parentElement === chatArea) {
            chatArea.insertBefore(div, spacer);
        } else {
            chatArea.appendChild(div);
        }
    }
    console.log("Thoughts container inserted for:", tempPromptId);

    // Animate dots
    let dotCount = 0;
    if (!div._dotInterval) {
        const dotsSpan = div.querySelector(".dots");
        div._dotInterval = setInterval(() => {
            dotCount = (dotCount + 1) % 6;
            if (dotsSpan) dotsSpan.textContent = ".".repeat(dotCount);
        }, 150);
    }
}




// ===================================================
// Global maps to track last thought hash and count per prompt
// ===================================================
window.thoughtHistory = {}; // { [tempPromptId]: { lastHash: '', counter: 1, placeholders: { text: hash } } }

// ===================================================
// Simple hash function for strings
// ===================================================
function hashString(str) {
    let hash = 0, i, chr;
    if (str.length === 0) return hash;
    for (i = 0; i < str.length; i++) {
        chr = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}

// ===================================================
// Strip HTML
// ===================================================
function cleanText(text) {
    const div = document.createElement("div");
    div.innerHTML = text;
    return div.textContent || div.innerText || "";
}

function updateAgentThoughtLoaderText(tempPromptId, thinkingText, icon) {
    const nextText = String(thinkingText || "Thinking").trim() || "Thinking";
    const nextIcon = String(icon || "🤔");
    const candidateIds = [
        String($v("P1_LATEST_LOADER_ID") || "").trim(),
        tempPromptId ? `loading-indicator-${tempPromptId}` : "",
        "loading-indicator",
        "LOADER_REGION"
    ].filter(Boolean);

    const visited = new Set();
    candidateIds.forEach((id) => {
        if (visited.has(id)) return;
        visited.add(id);
        const loaderEl = document.getElementById(id);
        if (!loaderEl) return;

        const labelEl = loaderEl.querySelector(".gemini-processing-label");
        if (labelEl) {
            labelEl.innerHTML = `${nextIcon} ${nextText}<span class="gemini-processing-dots">...</span>`;
        } else {
            loaderEl.textContent = `${nextIcon} ${nextText}...`;
        }
    });
}

// ===================================================
// Render Thoughts in Container
// ===================================================
function ensureAskOracleProgressStatusAnimationCss() {
    const styleId = "ask-oracle-progress-status-animation-css";
    if (document.getElementById(styleId)) return;
    const style = document.createElement("style");
    style.id = styleId;
    style.textContent = `
        @property --ask-oracle-status-gradient-angle {
            syntax: "<angle>";
            initial-value: 0deg;
            inherits: true;
        }
        .ask-oracle-progress-status {
            position: relative;
            isolation: isolate;
            display: inline-flex;
            align-items: center;
            gap: 7px;
            max-width: 100%;
            box-sizing: border-box;
            padding: 8px 12px;
            margin: 6px 0 8px;
            border-radius: 12px;
            color: #315da8 !important;
            background: rgba(255, 255, 255, 0.92);
            --ask-oracle-status-gradient-angle: 0deg;
            animation: askOracleProgressStatusGradient 2.4s linear infinite;
        }
        .ask-oracle-progress-status::before,
        .ask-oracle-progress-status::after {
            content: "";
            position: absolute;
            inset: 0;
            box-sizing: border-box;
            padding: 1.5px;
            border-radius: inherit;
            pointer-events: none;
            background: conic-gradient(from var(--ask-oracle-status-gradient-angle), #4285f4, #6f6cff, #b35cff, #ec4899, #fb923c, #fbbc05, #4285f4);
            -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
        }
        .ask-oracle-progress-status::after {
            z-index: -1;
            filter: blur(5px);
            opacity: 0.62;
        }
        .ask-oracle-progress-status > * { position: relative; z-index: 1; }
        .ask-oracle-progress-status .dots { min-width: 1.6em; letter-spacing: 1px; }
        @keyframes askOracleProgressStatusGradient {
            from { --ask-oracle-status-gradient-angle: 0deg; }
            to { --ask-oracle-status-gradient-angle: 360deg; }
        }
        body.ask-oracle-dark-ui .ask-oracle-progress-status {
            color: #dbeafe !important;
            background: rgba(15, 23, 42, 0.9);
        }
    `;
    document.head.appendChild(style);
}

function renderThoughts(tempPromptId, thoughts, finalResponseReceived = false) {
    if (finishedPrompts.has(tempPromptId)) return;

    let container = document.getElementById(tempPromptId);

    // Keep original behavior but allow plain-text thoughts too.
    const validThoughts = thoughts
        .map(t => {
            const rawText = (t && typeof t.text === "string") ? t.text : "";
            const plainText = cleanText(rawText)
                .replace(/-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/ig, "")
                .replace(/\s+/g, " ")
                .trim();
            return { ...t, text: rawText, plainText };
        })
        .filter(t => t.plainText.length > 0 && t.plainText !== "-");

    if (!validThoughts.length) return;

    if (!container) {
        insertThoughtsContainer(tempPromptId);
        container = document.getElementById(tempPromptId);
    }

    // Determine placeholder text and icon
    const placeholderIcons = {
        "Analyzing the prompt": "🧐",
        "Thinking": "🤔",
        "Checking distinct values from the database": "🔍",
        "Discovering schema metadata using sample rows": "📊",
        "Searching the web": "🌐",
        "Executing the SQL query": "💻",
        "Generating Charts":"📈",
        "Preparing the final result":"✅",
        "Summarizing the content":"✍️",
        "Deep thinking":"🧠",
        "Querying vector index":"🧲"
    };

    const placeholderRules = [
        { key: "Analyzing the prompt", regex: /\b(step\s*\d+\s*:\s*)?(analy[sz](e|ing|ed)\s+(the\s+)?prompt|prompt\s+analysis|analy[sz](e|ing|ed))\b/i },
        { key: "Searching the web", regex: /\b(step\s*\d+\s*:\s*)?(search(ing)?\s+(the\s+)?web|web\s*search)\b/i },
        { key: "Checking distinct values from the database", regex: /\b(step\s*\d+\s*:\s*)?(check(ing)?\s+(for\s+)?distinct\s+values?|distinct\s+values?.*database)\b/i },
        { key: "Discovering schema metadata using sample rows", regex: /\b(step\s*\d+\s*:\s*)?(discover(ing|ed)?\s+schema\s+metadata|schema\s+discovery|schema\s+metadata|sample\s+rows?|sample\s+data)\b/i },
        { key: "Executing the SQL query", regex: /\b(step\s*\d+\s*:\s*)?(execut(ing|e|ed)\s+(the\s+)?sql(\s+query)?|sql\s+query)\b/i },
        { key: "Generating Charts", regex: /\b(step\s*\d+\s*:\s*)?(generat(ing|e|ed)\s+(the\s+)?chart|chart(s)?|graph(s)?|plot(ting)?|visuali[sz](e|ing|ation))\b/i },
        { key: "Querying vector index", regex: /\b(step\s*\d+\s*:\s*)?(query(ing)?\s+vector\s+index|vector\s+index)\b/i },
        { key: "Preparing the final result", regex: /\b(step\s*\d+\s*:\s*)?(prepar(ing|e|ed)\s+(the\s+)?final\s+result|final\s+result)\b/i },
        { key: "Summarizing the content", regex: /\b(step\s*\d+\s*:\s*)?(summariz(e|ing|ed|ation)|summary)\b/i },
        { key: "Deep thinking", regex: /\b(deep\s+thinking|thinking\s+deeply)\b/i },
        { key: "Thinking", regex: /\bthinking\b/i }
    ];


    function detectPlaceholder(text) {
        const value = (text || "").trim();
        if (!value) return null;
        // If one row contains multiple "Step N: ..." phrases, use the latest stage.
        let bestMatch = null;
        let bestIndex = -1;
        for (const rule of placeholderRules) {
            const match = value.match(rule.regex);
            if (match && typeof match.index === "number" && match.index >= bestIndex) {
                bestIndex = match.index;
                bestMatch = rule.key;
            }
        }
        return bestMatch;
    }

    // Initialize history for this prompt
    if (!window.thoughtHistory[tempPromptId]) {
        window.thoughtHistory[tempPromptId] = { lastHash: null, counter: 0, lastPlaceholder: null, placeholders: {} };
    }

    // Use latest matching stage from polled thoughts.
    let thinkingText = "Thinking";
    for (let i = validThoughts.length - 1; i >= 0; i--) {
        const detected = detectPlaceholder(validThoughts[i].plainText);
        if (detected) {
            thinkingText = detected;
            break;
        }
    }

    // Track the latest stage without displaying implementation step numbers.
    const history = window.thoughtHistory[tempPromptId];
    if (thinkingText !== history.lastPlaceholder) {
        history.counter++;
        history.lastPlaceholder = thinkingText;
    }

    const icon = placeholderIcons[thinkingText] || "🤔";
    updateAgentThoughtLoaderText(tempPromptId, thinkingText, icon);
    ensureAskOracleProgressStatusAnimationCss();

    // Build placeholder HTML
    let html = `<div class="thinking ask-oracle-progress-status" style="font-weight:600; font-size:0.95em;">
        <span class="ask-oracle-progress-status__icon">${icon}</span>
        <span class="ask-oracle-progress-status__text">${thinkingText}</span>
        <span class="dots">.....</span>
    </div>`;

    // Render additional non-placeholder thoughts
    validThoughts.forEach(t => {
        const tClean = t.plainText || cleanText(t.text).replace(/\s+/g, " ").trim();
        if (detectPlaceholder(tClean)) return;

        html += `
            <div class="thought-step-collapsible" style="border:1px solid #ccc; border-radius:5px; padding:6px; margin-bottom:6px; background:#fff; font-size:0.9em; color:#222;">
                <div class="thought-content" style="max-height:5.5em; overflow:hidden; line-height:1.4em;">${t.text}</div>
                <div class="thought-footer" style="text-align:right; font-size:0.8em; color:#444; margin-top:2px;">${t.created}</div>
                <a href="javascript:void(0);" class="expand-btn" style="font-size:0.8em; display:none; color:#0056b3; text-decoration:underline; cursor:pointer;">Show more</a>
            </div>
        `;
    });

    container.innerHTML = html;

    // Animate dots
    let dotCount = 0;
    const dotsSpan = container.querySelector(".thinking .dots");
    if (container._dotInterval) clearInterval(container._dotInterval);
    container._dotInterval = setInterval(() => {
        if (dotsSpan) dotsSpan.textContent = ".".repeat((dotCount = (dotCount + 1) % 6));
    }, 200);

    // Collapsible logic
    const steps = container.querySelectorAll(".thought-step-collapsible");
    steps.forEach(step => {
        const contentDiv = step.querySelector(".thought-content");
        const expandBtn = step.querySelector(".expand-btn");
        const lineHeight = parseFloat(getComputedStyle(contentDiv).lineHeight);
        const maxHeight = 2 * lineHeight;
        if (contentDiv.scrollHeight > maxHeight) {
            expandBtn.style.display = "inline-block";
            expandBtn.onclick = () => {
                if (contentDiv.style.maxHeight === "none") {
                    contentDiv.style.maxHeight = maxHeight + "px";
                    expandBtn.textContent = "Show more";
                } else {
                    contentDiv.style.maxHeight = "none";
                    expandBtn.textContent = "Show less";
                }
            };
        }
    });
}









// ===================================================
// Poll Agent Thoughts (Keep polling until stopped)
// ===================================================
function pollAgentThoughts(conversationId, tempPromptId) {
    const pollInterval = 6000;
    let stopPolling = false;
    let lastThoughtCount = 0;

    function resolveThoughtConversationId() {
        return String(
            getAskOracleCurrentConversationId() ||
            $v("P1_CONV_ID") ||
            conversationId ||
            ""
        ).trim();
    }

    function checkThoughts() {
        if (stopPolling || finishedPrompts.has(tempPromptId)) return;
        const resolvedConversationId = resolveThoughtConversationId();
        if (!resolvedConversationId) {
            setTimeout(checkThoughts, 1000);
            return;
        }

        apex.server.process(
            "GET_AGENT_THOUGHTS",
            { x01: resolvedConversationId },
            {
                dataType: "json",
                success: function (data) {
                    // console.log("📡 Agent data:", data);

                    const thoughtRows = Array.isArray(data)
                        ? data
                        : (Array.isArray(data?.rows) ? data.rows : (Array.isArray(data?.data) ? data.data : []));

                    if (thoughtRows.length > lastThoughtCount) {
                        console.log(`[GET_AGENT_THOUGHTS] New rows detected: +${thoughtRows.length - lastThoughtCount} (total: ${thoughtRows.length})`);
                    }
                    lastThoughtCount = thoughtRows.length;

                    if (thoughtRows.length > 0) {
                        const thoughts = thoughtRows.map((item, idx) => {
                            const rawText =
                                item.response ||
                                item.step ||
                                item.step_name ||
                                item.step_text ||
                                item.status ||
                                item.status_text ||
                                item.raw_prompt ||
                                item.prompt ||
                                item.prompt_response ||
                                item.text ||
                                item.thought ||
                                "";

                            console.log(`[GET_AGENT_THOUGHTS] row ${idx + 1} payload:`, item);
                            console.log(`[GET_AGENT_THOUGHTS] rawText row ${idx + 1}:`, rawText);

                            return {
                                text: rawText,
                                created: new Date().toLocaleTimeString()
                            };
                        });

                        renderThoughts(tempPromptId, thoughts);
                    }

                    setTimeout(checkThoughts, pollInterval);
                },
                error: function () {
                    setTimeout(checkThoughts, pollInterval);
                }
            }
        );
    }

    checkThoughts();

    return function stop() {
        stopPolling = true;
    };
}

// ===================================================
// Run Prompt Asynchronously
// ===================================================
function ensureAskOracleCurrentAiProfileForPrompt(conversationMode) {
    const mode = normalizeAskOracleConversationMode(conversationMode || getAskOracleCurrentConversationMode());
    const cfg = getAskOracleAdminConfigSnapshot() || {};
    let selectedProfile = "";
    let currentProfile = "";

    if (mode === "CHAT_WITH_DB") {
        const visibleNl2sqlProfile = readAskOracleApexItemCurrentValue("P1_PROFILE");
        const hiddenNl2sqlProfile = readAskOracleApexItemCurrentValue("P1_SERVICE");
        selectedProfile = String(
            visibleNl2sqlProfile ||
            resolveAskOracleSelectValue("P1_PROFILE", hiddenNl2sqlProfile) ||
            getAskOracleUiSyncValue(ASK_ORACLE_SYNC_SELECTED_NL2SQL) ||
            cfg.DEFAULT_NL2SQL_PROFILE ||
            ""
        ).trim();
        if (selectedProfile) {
            selectedProfile = resolveAskOracleSelectValue("P1_PROFILE", selectedProfile) ||
                resolveAskOracleSelectValue("P1_SERVICE", selectedProfile) || selectedProfile;
            setAskOracleApexItemValueIfPresent("P1_SERVICE", selectedProfile, false);
            setAskOracleApexItemValueIfPresent("P1_PROFILE", selectedProfile, false);
            currentProfile = resolveAskOracleSelectValue("P1_CURRENT_AI_PROFILE", selectedProfile) || selectedProfile;
        }
    } else if (mode === "RAG_PROFILES") {
        selectedProfile = String(
            readAskOracleApexItemCurrentValue("P1_RAG_PROFILE") ||
            readAskOracleApexItemCurrentValue("P1_RAGSERVICE") ||
            getAskOracleUiSyncValue(ASK_ORACLE_SYNC_SELECTED_RAG) ||
            cfg.DEFAULT_RAG_PROFILE ||
            ""
        ).trim();
        if (selectedProfile) {
            selectedProfile = resolveAskOracleSelectValue("P1_RAG_PROFILE", selectedProfile) || selectedProfile;
            setAskOracleApexItemValueIfPresent("P1_RAG_PROFILE", selectedProfile, false);
            setAskOracleApexItemValueIfPresent("P1_RAGSERVICE", selectedProfile, false);
            currentProfile = resolveAskOracleSelectValue("P1_CURRENT_AI_PROFILE", selectedProfile) || selectedProfile;
        }
    } else if (mode === "USER_AGENTS") {
        selectedProfile = String(
            readAskOracleApexItemCurrentValue("P1_AGENT_PROFILE") ||
            readAskOracleApexItemCurrentValue("P1_AGENT_TEAM") ||
            readAskOracleApexItemCurrentValue("P1_AGENT_SERVICE") ||
            getAskOracleUiSyncValue(ASK_ORACLE_SYNC_SELECTED_AGENT) ||
            cfg.DEFAULT_AGENT_TEAM ||
            ""
        ).trim();
        if (selectedProfile) {
            selectedProfile = resolveAskOracleSelectValue("P1_AGENT_PROFILE", selectedProfile) || selectedProfile;
            setAskOracleApexItemValueIfPresent("P1_AGENT_PROFILE", selectedProfile, false);
            setAskOracleApexItemValueIfPresent("P1_AGENT_TEAM", selectedProfile, false);
            setAskOracleApexItemValueIfPresent("P1_AGENT_SERVICE", selectedProfile, false);
            currentProfile = resolveAskOracleCurrentProfileForAgentTeam(selectedProfile);
        }
    }

    currentProfile = String(currentProfile || readAskOracleApexItemCurrentValue("P1_CURRENT_AI_PROFILE") || "").trim();
    if (currentProfile) {
        setAskOracleApexItemValueIfPresent("P1_CURRENT_AI_PROFILE", currentProfile, false);
    }
    return currentProfile;
}

function runPromptAsync() {
    console.log("⚡ runPromptAsync() called!");

    const convId = $v("P1_CONV_ID");
    const isNewConversation = !String(convId || "").trim();
    const tempPromptId = "temp-" + Date.now();
    const conversationalStyle = getAskOracleCurrentConversationMode();
    ensureAskOracleCurrentAiProfileForPrompt(conversationalStyle);
    const switchNarrateValue = String($v("P1_SWITCH_NARRATE") || "").trim().toUpperCase();
    const selectedAgentHint = String(
        $v("P1_AGENT_PROFILE") || $v("P1_AGENT_TEAM") || $v("P1_AGENT_SERVICE") || ""
    ).trim();
    const currentProfileValue = String($v("P1_CURRENT_AI_PROFILE") || "").trim();
    const currentLooksAgentLabel = /^AGENT\s*\|/i.test(currentProfileValue);
    const knownNonAgentStyles = new Set(["SQL", "RAG", "RAGSQL", "NARRATE", "CHAT"]);
    const unknownStyleWithAgentHint = !switchNarrateValue || !knownNonAgentStyles.has(switchNarrateValue);
    const shouldPollAgentThoughts =
        conversationalStyle === "USER_AGENTS" ||
        switchNarrateValue === "AGENT" ||
        switchNarrateValue === "USER_AGENTS" ||
        (unknownStyleWithAgentHint && !!(selectedAgentHint || currentLooksAgentLabel));
    askOraclePerfStartRun(tempPromptId, {
      convId: convId || "",
      isNewConversation,
      conversationalStyle,
      shouldPollAgentThoughts
    });

    let stopPolling = () => {};
    activeAgentThoughtsStopFn = null;
    activeAgentTempPromptId = null;

    if (shouldPollAgentThoughts) {
        document.querySelectorAll('[id^="loading-indicator-"], #loading-indicator, #LOADER_REGION').forEach((node) => {
            if (node && node.style) node.style.display = "none";
        });
        hideLoadingUI(apex.item("P1_LATEST_LOADER_ID").getValue());
        promptInput.disabled = true;
        runButton.disabled = true;

        // Insert thinking placeholder immediately
        insertThoughtsContainer(tempPromptId);

        // Start polling
        stopPolling = pollAgentThoughts(convId, tempPromptId);
        activeAgentThoughtsStopFn = stopPolling;
        activeAgentTempPromptId = tempPromptId;
    } else {
        ensureAskOracleRunPromptLoader(tempPromptId);
    }

    promptRequestInFlight = true;
    promptErrorHandled = false;
    userStopRequested = false;
    setRunPromptStopMode(true);

    console.log("P1_ASK_ADB:", $v("P1_ASK_ADB"));
    console.log("P1_SWITCH_NARRATE:", $v("P1_SWITCH_NARRATE"));
    console.log("P1_CURRENT_AI_PROFILE:", $v("P1_CURRENT_AI_PROFILE"));
    console.log("P1_PROMPT:", $v("P1_PROMPT"));
    console.log("P1_CONV_ID:", $v("P1_CONV_ID"));
    console.log("P1_RAG_CHAT:", $v("P1_RAG_CHAT"));
    console.log("P1_RAG_SQL:", $v("P1_RAG_SQL"));

    const executePromptAjaxData = {
        pageItems: "#P1_ASK_ADB,#P1_SWITCH_NARRATE,#P1_SERVICE,#P1_PROFILE,#P1_CURRENT_AI_PROFILE,#P1_AGENT_PROFILE,#P1_RAG_PROFILE,#P1_PROMPT,#P1_CONV_ID,#P1_RAG_CHAT,#P1_RAG_SQL"
    };
    const executePromptResolvedParams = {
        P1_ASK_ADB: $v("P1_ASK_ADB"),
        P1_SWITCH_NARRATE: $v("P1_SWITCH_NARRATE"),
        P1_SERVICE: $v("P1_SERVICE"),
        P1_PROFILE: $v("P1_PROFILE"),
        P1_CURRENT_AI_PROFILE: $v("P1_CURRENT_AI_PROFILE"),
        P1_AGENT_PROFILE: $v("P1_AGENT_PROFILE"),
        P1_RAG_PROFILE: $v("P1_RAG_PROFILE"),
        P1_PROMPT: $v("P1_PROMPT"),
        P1_CONV_ID: $v("P1_CONV_ID"),
        P1_RAG_CHAT: $v("P1_RAG_CHAT"),
        P1_RAG_SQL: $v("P1_RAG_SQL")
    };
    console.log("[ASK_ORACLE] EXECUTE_PROMPT request payload -> process_prompt_request", {
        processName: "EXECUTE_PROMPT",
        ajaxData: executePromptAjaxData,
        resolvedPageItemValues: executePromptResolvedParams
    });

    // Execute prompt asynchronously
    activeExecutePromptRequest = apex.server.process(
        "EXECUTE_PROMPT",
        executePromptAjaxData,
        {
            dataType: "json",
            beforeSend: function() {
                askOraclePerfMark("execute_prompt_start", {
                  convId: $v("P1_CONV_ID"),
                  style: conversationalStyle
                });
            },
            success: function (pData) {
                askOraclePerfMark("execute_prompt_end", {
                  status: pData && pData.status ? String(pData.status) : "ok"
                });
                console.log("EXECUTE_PROMPT finished (async).");
                activeExecutePromptRequest = null;

                if (pData && pData.status === "error") {
                    askOraclePerfFinishRun("execute_prompt_status_error", {
                      payloadStatus: pData.status
                    });
                    stopPolling();
                    finishedPrompts.add(tempPromptId);
                    removePonderingContainer(tempPromptId);
                    showPromptRequestError({ responseText: JSON.stringify(pData) });
                    promptRequestInFlight = false;
                    activeAgentThoughtsStopFn = null;
                    activeAgentTempPromptId = null;
                    setRunPromptStopMode(false);
                    refreshRunPromptButtonState();
                    return;
                }

                stopPolling();
                activeAgentThoughtsStopFn = null;
                if (shouldPollAgentThoughts) {
                    try {
                        renderThoughts(tempPromptId, [{
                            text: "Preparing the final result",
                            created: new Date().toLocaleTimeString()
                        }]);
                    } catch (e) {}
                } else {
                    finishedPrompts.add(tempPromptId); // ✅ prevent further thinking inserts
                    removePonderingContainer(tempPromptId);
                    activeAgentTempPromptId = null;
                }

                // Fetch final conversation
                fetchAndAppendLatestConversation({
                  autoVisualEnabled: true,
                  source: "runPromptAsync",
                  refreshConversationNavHistory: isNewConversation
                });
                promptRequestInFlight = false;
                userStopRequested = false;
                setRunPromptStopMode(false);
                refreshRunPromptButtonState();

                const endTime = new Date();
                console.log(`Ending conversation time: ${endTime.toLocaleTimeString()}`);
            },
            error: function (xhr, textStatus) {
                askOraclePerfMark("execute_prompt_error", {
                  textStatus,
                  status: xhr && xhr.status
                });
                askOraclePerfFinishRun("execute_prompt_ajax_error", {
                  textStatus,
                  status: xhr && xhr.status
                });
                activeExecutePromptRequest = null;
                stopPolling();
                finishedPrompts.add(tempPromptId);
                removePonderingContainer(tempPromptId);
                activeAgentThoughtsStopFn = null;
                activeAgentTempPromptId = null;

                const aborted = userStopRequested || textStatus === "abort" || (xhr && xhr.statusText === "abort");
                if (!aborted) {
                    showPromptRequestError(xhr);
                } else {
                    hideLoadingUI(apex.item("P1_LATEST_LOADER_ID").getValue());
                }
                promptRequestInFlight = false;
                userStopRequested = false;
                setRunPromptStopMode(false);
                refreshRunPromptButtonState();
            }
        }
    );
}
/* AskOracle V5: SQL Property Graph visualization toggle.
 * Page 14 remains the graph-rendering endpoint and is embedded below the
 * matching response, following the proven V3 behavior while leaving V5's
 * response renderer unchanged.
 */
(function installAskOracleGraphButtons() {
  "use strict";

  if (window.__askOracleGraphButtonsInstalled) return;
  window.__askOracleGraphButtonsInstalled = true;

  function cssEscape(value) {
    return window.CSS && typeof window.CSS.escape === "function"
      ? window.CSS.escape(String(value))
      : String(value).replace(/(["\\])/g, "\\$1");
  }

  function setGraphButtonLabel(button, graphIsVisible) {
    button.textContent = graphIsVisible ? "Hide Graph" : "Show Graph";
  }

  function toggleGraph(promptId, graphButton) {
    var blockId = "graph-block-" + promptId;
    var existingBlock = document.getElementById(blockId);

    if (existingBlock) {
      var showBlock = existingBlock.style.display === "none";
      existingBlock.style.display = showBlock ? "block" : "none";
      setGraphButtonLabel(graphButton, showBlock);
      return;
    }

    if (!(window.apex && apex.server && typeof apex.server.process === "function")) {
      apex.message.alert("Could not open graph.");
      return;
    }

    apex.server.process(
      "GET_GRAPH_URL",
      { x01: promptId },
      {
        dataType: "json",
        success: function (data) {
          if (!data || !data.url) {
            apex.message.alert("Could not build graph URL.");
            return;
          }

          var responseBox = document.getElementById("response-" + promptId);
          if (!responseBox || !responseBox.parentNode) {
            apex.navigation.redirect(data.url);
            return;
          }

          var chartBlock = document.getElementById("chart-block-" + promptId);
          if (chartBlock) chartBlock.style.display = "none";

          var graphBlock = document.createElement("div");
          graphBlock.id = blockId;
          graphBlock.className = "ask-oracle-graph-block";
          graphBlock.style.marginTop = "14px";
          graphBlock.style.border = "1px solid #ddd";
          graphBlock.style.borderRadius = "6px";
          graphBlock.style.overflow = "hidden";
          graphBlock.style.background = "#fff";

          var iframe = document.createElement("iframe");
          iframe.src = data.url;
          iframe.style.width = "100%";
          iframe.style.height = "720px";
          iframe.style.border = "0";
          iframe.style.display = "block";
          iframe.title = "Graph visualization";
          iframe.loading = "lazy";
          graphBlock.appendChild(iframe);

          responseBox.parentNode.insertBefore(graphBlock, responseBox.nextSibling);
          setGraphButtonLabel(graphButton, true);
        },
        error: function () {
          apex.message.alert("Could not open graph.");
        }
      }
    );
  }

  function addGraphButtons() {
 document
    .querySelectorAll(
".llm-conv-show-charts-btn[data-id], .llm-conv-show-sql-btn[data-id], .speech-controls[data-id]"
)
    .forEach(function (anchorButton) {
      var promptId = String(
        anchorButton.getAttribute("data-id") || ""
      ).trim();

      if (!promptId) return;

      var isAgentActionRow =
  anchorButton.classList.contains("speech-controls");

var parent = isAgentActionRow
  ? anchorButton.querySelector("div")
  : anchorButton.parentNode;

if (!parent) return;

      var selector =
        '.llm-conv-show-graph-btn[data-id="' +
        cssEscape(promptId) +
        '"]';

      if (parent.querySelector(selector)) return;

      var graphButton = document.createElement("button");
      graphButton.type = "button";
      graphButton.className =
        "t-Button t-Button--small llm-conv-show-graph-btn";

      graphButton.style.setProperty("height", "24px", "important");
      graphButton.style.setProperty("min-height", "24px", "important");
      graphButton.style.setProperty("min-width", "0", "important");
      graphButton.style.setProperty("padding", "2px 6px", "important");
      graphButton.style.setProperty("font-size", "10px", "important");
      graphButton.style.setProperty("line-height", "1.1", "important");

      graphButton.setAttribute("data-id", promptId);
      setGraphButtonLabel(graphButton, false);

      graphButton.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        toggleGraph(promptId, graphButton);
      });

      if (isAgentActionRow) {
  parent.appendChild(graphButton);
} else {
  parent.insertBefore(graphButton, anchorButton);
}
    });
  }

  function startGraphButtonObserver() {
    addGraphButtons();
    if (!document.body) return;

    var observer = new MutationObserver(addGraphButtons);
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startGraphButtonObserver, { once: true });
  } else {
    startGraphButtonObserver();
  }
})();
