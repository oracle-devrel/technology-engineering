(function installAskOracleCytoscapeGraph() {
  "use strict";

  if (window.__askOracleCytoscapeGraphInstalled) return;
  window.__askOracleCytoscapeGraphInstalled = true;

  const instances = Object.create(null);
  const GRAPH_ID_PATTERN = /^GRAPH_(SOURCE|TARGET|EDGE|VERTEX)_ID$/i;

  function cssEscape(value) {
    return window.CSS && typeof window.CSS.escape === "function"
      ? window.CSS.escape(String(value))
      : String(value).replace(/(["\\])/g, "\\$1");
  }

  function parseGraphIdentity(value) {
    if (value && typeof value === "object") return value;
    try { return JSON.parse(String(value || "")); } catch (error) { return null; }
  }

  function identityKey(value) {
    const parsed = parseGraphIdentity(value);
    if (!parsed) return String(value || "");
    const key = parsed.KEY_VALUE || parsed.key_value || {};
    const keyName = Object.keys(key)[0];
    return keyName ? String(key[keyName]) : String(value || "");
  }

  function identityLabel(value) {
    const parsed = parseGraphIdentity(value);
    if (!parsed) return identityKey(value);
    return String(parsed.ELEM_TABLE || parsed.elem_table || identityKey(value));
  }

  function findColumn(columns, patterns) {
    for (const pattern of patterns) {
      const match = columns.find(function (name) { return pattern.test(name); });
      if (match) return match;
    }
    return "";
  }

  function propertyRowsToElements(rows) {
    if (!Array.isArray(rows) || !rows.length) return [];
    const columns = Object.keys(rows[0] || {});
    const sourceGraph = findColumn(columns, [/^GRAPH_SOURCE_ID$/i, /^GRAPH_VERTEX_ID$/i]);
    const targetGraph = findColumn(columns, [/^GRAPH_TARGET_ID$/i]);
    const edgeGraph = findColumn(columns, [/^GRAPH_EDGE_ID$/i]);
    if (!sourceGraph && !targetGraph) return [];

    const sourceBusiness = findColumn(columns, [
      /^(SOURCE|SRC)(_.*)?ID$/i, /^(SOURCE|SRC)_.*NAME$/i
    ]);
    const targetBusiness = findColumn(columns, [
      /^(TARGET|TGT|DEST|DST)(_.*)?ID$/i, /^(TARGET|TGT|DEST|DST)_.*NAME$/i
    ]);
    const edgeBusiness = findColumn(columns.filter(function (name) {
      return !GRAPH_ID_PATTERN.test(name);
    }), [/^(TRANSACTION|TXN|EDGE|TRANSFER)(_.*)?ID$/i]);

    const elements = [];
    const nodes = new Set();

    function addNode(graphValue, businessValue) {
      if (graphValue === undefined || graphValue === null) return "";
      const id = "n:" + identityKey(graphValue);
      if (!nodes.has(id)) {
        nodes.add(id);
        elements.push({
          data: {
            id: id,
            label: String(businessValue || identityKey(graphValue)),
            type: identityLabel(graphValue)
          }
        });
      }
      return id;
    }

    rows.forEach(function (row, index) {
      const source = addNode(row[sourceGraph], sourceBusiness ? row[sourceBusiness] : "");
      const target = addNode(row[targetGraph], targetBusiness ? row[targetBusiness] : "");
      if (!source || !target) return;
      const edgeKey = edgeBusiness ? row[edgeBusiness] : identityKey(row[edgeGraph]);
      elements.push({
        data: {
          id: "e:" + String(edgeKey || index) + ":" + index,
          source: source,
          target: target,
          label: String(edgeKey || "")
        }
      });
    });

    return elements;
  }

  function rdfRowsToElements(rows) {
    if (!Array.isArray(rows) || !rows.length) return [];
    const columns = Object.keys(rows[0] || {});
    const subject = findColumn(columns, [/^SUBJECT$/i, /^S$/i]);
    const predicate = findColumn(columns, [/^PREDICATE$/i, /^P$/i]);
    const object = findColumn(columns, [/^OBJECT$/i, /^O$/i]);
    if (!subject || !predicate || !object) return [];

    const elements = [];
    const nodes = new Set();
    function addNode(value) {
      const id = "rdf:" + String(value);
      if (!nodes.has(id)) {
        nodes.add(id);
        elements.push({ data: { id: id, label: String(value), type: "RDF" } });
      }
      return id;
    }

    rows.forEach(function (row, index) {
      const source = addNode(row[subject]);
      const target = addNode(row[object]);
      elements.push({
        data: {
          id: "rdf-edge:" + index,
          source: source,
          target: target,
          label: String(row[predicate] || "")
        }
      });
    });
    return elements;
  }

  function rowsToElements(rows) {
    return propertyRowsToElements(rows).concat(rdfRowsToElements(rows));
  }

  function downloadDataUrl(dataUrl, fileName) {
    const link = document.createElement("a");
    link.href = dataUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  function escapeXml(value) {
    return String(value || "").replace(/[&<>"']/g, function (character) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[character];
    });
  }

  function buildSvg(cy) {
    const box = cy.elements().boundingBox({ includeLabels: true });
    const padding = 40;
    const width = Math.max(320, Math.ceil(box.w + padding * 2));
    const height = Math.max(220, Math.ceil(box.h + padding * 2));
    const xOffset = padding - box.x1;
    const yOffset = padding - box.y1;
    const parts = [
      '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '" viewBox="0 0 ' + width + ' ' + height + '">',
      '<rect width="100%" height="100%" fill="white"/>'
    ];

    cy.edges().forEach(function (edge) {
      const source = edge.source().position();
      const target = edge.target().position();
      parts.push('<line x1="' + (source.x + xOffset) + '" y1="' + (source.y + yOffset) +
        '" x2="' + (target.x + xOffset) + '" y2="' + (target.y + yOffset) +
        '" stroke="#7a7a7a" stroke-width="2"/>');
      const label = edge.data("label");
      if (label) parts.push('<text x="' + ((source.x + target.x) / 2 + xOffset) +
        '" y="' + ((source.y + target.y) / 2 + yOffset - 5) +
        '" text-anchor="middle" font-family="Arial" font-size="11" fill="#444">' +
        escapeXml(label) + '</text>');
    });

    cy.nodes().forEach(function (node) {
      const position = node.position();
      parts.push('<circle cx="' + (position.x + xOffset) + '" cy="' + (position.y + yOffset) +
        '" r="28" fill="#86bdd0" stroke="#40788b" stroke-width="2"/>');
      parts.push('<text x="' + (position.x + xOffset) + '" y="' + (position.y + yOffset + 4) +
        '" text-anchor="middle" font-family="Arial" font-size="12" fill="#17323b">' +
        escapeXml(node.data("label")) + '</text>');
    });
    parts.push("</svg>");
    return parts.join("");
  }

  function createGraphCyBlock(id, elements) {
    const block = document.createElement("section");
    block.id = "graphcy-block-" + id;
    block.className = "ask-oracle-graphcy-block";
    block.innerHTML =
      '<div class="ask-oracle-graphcy-toolbar">' +
      '<button type="button" class="t-Button t-Button--small graphcy-fit">Fit</button>' +
      '<button type="button" class="t-Button t-Button--small graphcy-svg">SVG</button>' +
      '<button type="button" class="t-Button t-Button--small graphcy-png">PNG</button>' +
      '</div><div class="ask-oracle-graphcy-canvas"></div>';

    const response = document.getElementById("response-" + id);
    const anchor = document.getElementById("graph-block-" + id) ||
      document.getElementById("chart-block-" + id) || response;
    if (!anchor || !anchor.parentNode) return null;
    anchor.parentNode.insertBefore(block, anchor.nextSibling);

    const cy = window.cytoscape({
      container: block.querySelector(".ask-oracle-graphcy-canvas"),
      elements: elements,
      style: [
        { selector: "node", style: {
          "background-color": "#86bdd0", "border-color": "#40788b",
          "border-width": 2, label: "data(label)", color: "#17323b",
          "font-size": 11, "text-valign": "center", "text-halign": "center"
        } },
        { selector: "edge", style: {
          width: 2, "line-color": "#888", "target-arrow-color": "#888",
          "target-arrow-shape": "triangle", "curve-style": "bezier",
          label: "data(label)", "font-size": 9, color: "#444",
          "text-background-color": "#fff", "text-background-opacity": 0.8
        } }
      ],
      layout: { name: "cose", animate: false, fit: true, padding: 45 }
    });

    instances[id] = cy;
    block.querySelector(".graphcy-fit").addEventListener("click", function () { cy.fit(undefined, 45); });
    block.querySelector(".graphcy-png").addEventListener("click", function () {
      downloadDataUrl(cy.png({ full: true, scale: 2, bg: "#ffffff" }), "graph-" + id + ".png");
    });
    block.querySelector(".graphcy-svg").addEventListener("click", function () {
      const svg = buildSvg(cy);
      downloadDataUrl("data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg), "graph-" + id + ".svg");
    });
    return block;
  }

  function getRows(id, callback) {
    const cache = window.__askOracleNl2SqlChartRows || {};
    if (Array.isArray(cache[id]) && cache[id].length) {
      callback(cache[id]);
      return;
    }
    if (!(window.apex && apex.server && typeof apex.server.process === "function")) return;
    apex.server.process("GET_SQL_RESULTS", { x01: id }, {
      dataType: "json",
      success: function (data) {
        const rows = Array.isArray(data && data.results) ? data.results : [];
        window.__askOracleNl2SqlChartRows = window.__askOracleNl2SqlChartRows || {};
        window.__askOracleNl2SqlChartRows[id] = rows;
        callback(rows);
      }
    });
  }

  function toggleGraphCy(id, button) {
    const existing = document.getElementById("graphcy-block-" + id);
    if (existing) {
      const show = existing.style.display === "none";
      existing.style.display = show ? "block" : "none";
      button.textContent = show ? "Hide GraphCy" : "Show GraphCy";
      if (show && instances[id]) instances[id].resize().fit(undefined, 45);
      return;
    }
    if (typeof window.cytoscape !== "function") {
      if (window.apex && apex.message) apex.message.alert("Cytoscape.js is not loaded.");
      return;
    }
    getRows(id, function (rows) {
      const elements = rowsToElements(rows);
      if (!elements.length) {
        if (window.apex && apex.message) apex.message.alert("No graph columns were found in this result.");
        return;
      }
      if (createGraphCyBlock(id, elements)) button.textContent = "Hide GraphCy";
    });
  }

  function addButtons() {
    document.querySelectorAll(".llm-conv-show-graph-btn[data-id]").forEach(function (graphWiseButton) {
      const id = String(graphWiseButton.getAttribute("data-id") || "").trim();
      const parent = graphWiseButton.parentNode;
      if (!id || !parent || parent.querySelector('.llm-conv-show-graphcy-btn[data-id="' + cssEscape(id) + '"]')) return;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "t-Button t-Button--small llm-conv-show-graphcy-btn";
      button.setAttribute("data-id", id);
      button.textContent = "Show GraphCy";
      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        toggleGraphCy(id, button);
      });
      graphWiseButton.insertAdjacentElement("afterend", button);
    });
  }

  function installCss() {
    if (document.getElementById("ask-oracle-graphcy-css")) return;
    const style = document.createElement("style");
    style.id = "ask-oracle-graphcy-css";
    style.textContent =
      ".ask-oracle-graphcy-block{position:relative;margin-top:14px;border:1px solid #d7dde5;border-radius:8px;background:#fff;overflow:hidden}" +
      ".ask-oracle-graphcy-canvas{width:100%;height:560px;min-height:320px}" +
      ".ask-oracle-graphcy-toolbar{position:absolute;right:12px;bottom:10px;z-index:5;display:flex;gap:6px}" +
      ".llm-conv-show-graphcy-btn{height:24px!important;min-height:24px!important;min-width:0!important;padding:2px 6px!important;font-size:10px!important}";
    document.head.appendChild(style);
  }

  function temporarilyAddGraphCyImagesForPdf() {
    const added = [];
    Object.keys(instances).forEach(function (id) {
      const block = document.getElementById("graphcy-block-" + id);
      const response = document.getElementById("response-" + id);
      if (!block || block.style.display === "none" || !response) return;
      const image = document.createElement("img");
      image.className = "ask-oracle-graphcy-pdf-image";
      image.src = instances[id].png({ full: true, scale: 2, bg: "#ffffff" });
      image.style.width = "100%";
      image.style.height = "auto";
      response.appendChild(image);
      added.push(image);
    });
    return function () { added.forEach(function (image) { image.remove(); }); };
  }

  document.addEventListener("click", function (event) {
    const button = event.target.closest && event.target.closest(".export-pdf-response-btn");
    if (!button) return;
    apex.message.showPageSuccess(
  "PDF export currently includes GraphCy only; other graph viewers are not included."
);
    const cleanup = temporarilyAddGraphCyImagesForPdf();
    window.setTimeout(cleanup, 0);
  }, true);

  installCss();
  addButtons();
  new MutationObserver(addButtons).observe(document.documentElement, { childList: true, subtree: true });

  window.askOracleGraphCy = {
    propertyRowsToElements: propertyRowsToElements,
    rdfRowsToElements: rdfRowsToElements,
    getInstance: function (id) { return instances[String(id)] || null; }
  };
})();
