/* Ask Oracle browser topology analysis v1.0.0.
 * Load after ask_oracle_mapliber_drawing.js. No existing modules are replaced.
 * Lazy dependency: JSTS 2.12.1 (BSD-3-Clause), https://github.com/bjornharrtell/jsts
 * Preload window.jsts to avoid CDN access, or set askOracleMapAnalysisConfig.libraryUrl
 * before this script to an approved local static application file URL.
 * Only complete inline GeoJSON sources are analyzed; never tile fragments/SQL.
 * XY planar topology, no distance tolerance; Z ignored. Antimeridian geometries
 * are rejected. Invalid geometries are reported, never silently repaired.
 * Results/highlights are temporary snapshots; no storage or selection changes.
 */
(function () {
  'use strict';
  if (window.askOracleMapAnalysis) return;
  const PREFIX = 'aoanalysis-', SOURCE = PREFIX + 'results';
  const RELATIONS = ['Intersects', 'Within', 'Contains', 'Touches', 'Overlaps', 'Disjoint'];
  const sessions = new Map(), MAX_PAIRS = 25000, MAX_RESULTS = 1000, MAX_POSITIONS = 150000;
  let stopped = false, libraryPromise, sequence = 0;
  const empty = () => ({ type: 'FeatureCollection', features: [] });
  const node = (tag, text, cls) => {
    const el = document.createElement(tag); if (text !== undefined) el.textContent = text;
    if (cls) el.className = cls; return el;
  };
  const button = text => { const el = node('button', text); el.type = 'button'; return el; };
  const labelOf = (f, i) => {
    const p = f.properties || {}, key = Object.keys(p).find(k => /^name$|^district$|^id$/i.test(k));
    return (key ? key + ': ' + String(p[key]) : 'Feature ' + (f.id ?? (i + 1))) + ' [' + f.geometry.type + ']';
  };
  function sources(map) {
    return Object.entries(map.getStyle()?.sources || {}).filter(([id, src]) =>
      !id.startsWith(PREFIX) && src.type === 'geojson' && src.data && typeof src.data === 'object'
    ).map(([id, src]) => {
      const data = src.data;
      let features = data.type === 'FeatureCollection' ? data.features : data.type === 'Feature' ? [data] : [{ type: 'Feature', properties: {}, geometry: data }];
      features = (features || []).filter(f => f?.geometry && (id !== 'aod-drawings' || f.properties?.drawing === true));
      return { id, features, name: id === 'aod-drawings' ? 'Drawings' : id === 'ask-oracle-results' ? 'Map results / districts' : id };
    });
  }
  function engine() {
    if (window.jsts?.io?.GeoJSONReader && window.jsts?.operation?.relate?.RelateOp) return Promise.resolve(window.jsts);
    if (libraryPromise) return libraryPromise;
    libraryPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = window.askOracleMapAnalysisConfig?.libraryUrl || 'https://cdn.jsdelivr.net/npm/jsts@2.12.1/dist/jsts.min.js';
      script.async = true;
      const timeout = setTimeout(() => finish(new Error('Geometry library timed out.')), 20000);
      function finish(error) {
        clearTimeout(timeout); script.onload = script.onerror = null;
        if (error) { script.remove(); reject(error); }
        else resolve(window.jsts);
      }
      script.onload = () => finish(window.jsts?.operation?.relate?.RelateOp ? null : new Error('Geometry library is incompatible.'));
      script.onerror = () => finish(new Error('Cannot load JSTS. Allow the library URL in CSP or preload a local JSTS browser build.'));
      document.head.appendChild(script);
    }).catch(error => { libraryPromise = null; throw error; });
    return libraryPromise;
  }
  function prepare(feature, reader, jsts, budget) {
    const geometry = feature.geometry;
    if (!/^(Point|MultiPoint|LineString|MultiLineString|Polygon|MultiPolygon)$/.test(geometry.type)) throw new Error('Unsupported geometry: ' + geometry.type);
    let min = Infinity, max = -Infinity;
    function coordinates(value) {
      if (!Array.isArray(value) || !value.length) throw new Error('Empty or malformed coordinates.');
      if (typeof value[0] === 'number') {
        if (value.length < 2 || !value.slice(0, 2).every(Number.isFinite) || Math.abs(value[0]) > 180 || Math.abs(value[1]) > 90) throw new Error('Expected valid longitude/latitude coordinates.');
        if (++budget.count > MAX_POSITIONS) throw new Error('Too many coordinates. Choose smaller feature sets.');
        min = Math.min(min, value[0]); max = Math.max(max, value[0]);
        return value.slice(0, 2);
      }
      return value.map(coordinates);
    }
    const copy = { type: geometry.type, coordinates: coordinates(geometry.coordinates) };
    if (max - min > 180) throw new Error('Antimeridian-spanning geometry is not supported in this version.');
    const parsed = reader.read(copy), check = new jsts.operation.valid.IsValidOp(parsed);
    if (!check.isValid()) throw new Error('Invalid geometry: ' + check.getValidationError());
    if (parsed.isEmpty()) throw new Error('Empty geometry.');
    return parsed;
  }
  function relates(jsts, a, b, relation) {
    const m = jsts.operation.relate.RelateOp.relate(a, b);
    switch (relation) {
      case 'Intersects': return m.isIntersects();
      case 'Disjoint': return m.isDisjoint();
      case 'Within': return m.isWithin();
      case 'Contains': return m.isContains();
      case 'Touches': return m.isTouches(a.getDimension(), b.getDimension());
      case 'Overlaps': return m.isOverlaps(a.getDimension(), b.getDimension());
      default: throw new Error('Unknown relationship.');
    }
  }
  function attach(id, map, block, toolbar) {
    const uid = PREFIX + (++sequence), controller = new AbortController();
    const s = { id, map, block, serial: 0, dead: false, busy: false, inputs: [], sourceIds: [] };
    const listen = (el, type, fn) => el.addEventListener(type, fn, { signal: controller.signal });
    const root = node('div', undefined, 'aoan-menu-root'), trigger = button('Analysis ▾');
    trigger.className = 'aoan-trigger'; trigger.setAttribute('aria-haspopup', 'menu'); trigger.setAttribute('aria-expanded', 'false');
    const menu = node('div', undefined, 'aoan-menu'); menu.id = uid + '-menu'; menu.hidden = true;
    menu.setAttribute('role', 'menu'); menu.setAttribute('aria-label', 'Spatial analysis'); trigger.setAttribute('aria-controls', menu.id);
    root.append(trigger);
    const drawingMenu = toolbar.querySelector('select');
    toolbar.insertBefore(root, drawingMenu ? drawingMenu.nextSibling : toolbar.firstChild);
    // Portal avoids clipping by the existing map block's overflow:hidden.
    document.body.appendChild(menu);
    const panel = node('section', undefined, 'aoan-panel'); panel.hidden = true; panel.setAttribute('aria-label', 'Spatial analysis settings and results');
    block.insertBefore(panel, block.querySelector('.ask-oracle-map-canvas'));
    const heading = node('h3', 'Spatial analysis'), help = node('p');
    const controls = node('div', undefined, 'aoan-controls'), output = node('div', undefined, 'aoan-output');
    const status = node('p', ''); status.setAttribute('role', 'status');
    const relation = node('select'); RELATIONS.forEach(name => relation.appendChild(new Option(name, name)));
    function field(title, control) {
      const label = node('label', title); label.appendChild(control); controls.appendChild(label); s.inputs.push(control);
    }
    field('Relationship (A → B)', relation);
    const groups = ['A', 'B'].map(name => {
      const layer = node('select'), feature = node('select');
      field('Layer ' + name, layer); field('Features ' + name, feature);
      return { layer, feature };
    });
    const actions = node('div', undefined, 'aoan-actions'), run = button('Run analysis'), refresh = button('Refresh layers'), clear = button('Clear analysis'), close = button('Close');
    actions.append(run, refresh, clear, close);
    panel.append(heading, help, controls, actions, status, output);
    const note = node('p', 'Complete loaded GeoJSON only; basemap tiles and URL-only sources are excluded. Same-layer self-pairs are excluded. XY topology, no snapping tolerance. Cyan highlights are separate from yellow selections.', 'aoan-note');
    panel.appendChild(note);
    function explain() {
      const descriptions = {
        Intersects: 'A and B share at least one point, including boundaries.',
        Within: 'A lies within B and their interiors intersect. A point on a polygon boundary is not within it.',
        Contains: 'A contains B and their interiors intersect. This is the reverse of Within.',
        Touches: 'A and B meet, but their interiors do not intersect. Two points cannot touch in this sense.',
        Overlaps: 'Same-dimensional features partly overlap; neither contains the other. Crossing lines at a point do not overlap.',
        Disjoint: 'Each listed A–B pair has no point in common. This does NOT mean A is disjoint from every feature in layer B.'
      };
      help.textContent = descriptions[relation.value];
    }
    function clearHighlight() {
      if (map.getSource(SOURCE)) map.getSource(SOURCE).setData(empty());
    }
    function cancel(message) {
      s.serial++; s.busy = false; run.disabled = false;
      s.inputs.forEach(el => { el.disabled = false; });
      output.replaceChildren(); clearHighlight(); status.textContent = message || '';
    }
    function fillFeatures(group) {
      const previous = group.feature.value, source = sources(map).find(x => x.id === group.layer.value);
      group.feature.replaceChildren(new Option('All features', '*'));
      source?.features.forEach((f, i) => group.feature.appendChild(new Option(labelOf(f, i), String(i))));
      if ([...group.feature.options].some(o => o.value === previous)) group.feature.value = previous;
    }
    function refreshLayers() {
      cancel(); const available = sources(map);
      groups.forEach((group, i) => {
        const previous = group.layer.value;
        group.layer.replaceChildren(); available.forEach(src => group.layer.appendChild(new Option(src.name + ' (' + src.features.length + ')', src.id)));
        group.layer.value = available.some(src => src.id === previous) ? previous : available.find(src => src.id === (i ? 'ask-oracle-results' : 'aod-drawings'))?.id || available[0]?.id || '';
        group.feature.value = '*'; fillFeatures(group);
      });
      explain(); status.textContent = available.length ? 'Choose two layers, then Run analysis.' : 'No complete GeoJSON sources available.';
    }
    function closeMenu(focus) {
      menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); if (focus) trigger.focus();
    }
    const items = RELATIONS.map(name => {
      const item = button(name); item.setAttribute('role', 'menuitem'); menu.appendChild(item);
      listen(item, 'click', () => {
        closeMenu(false); panel.hidden = false; refreshLayers(); relation.value = name; explain(); relation.focus();
      }); return item;
    });
    function openMenu() {
      menu.hidden = false; trigger.setAttribute('aria-expanded', 'true');
      const r = trigger.getBoundingClientRect(), bounds = menu.getBoundingClientRect();
      menu.style.left = Math.max(8, Math.min(r.left, window.innerWidth - bounds.width - 8)) + 'px';
      menu.style.top = Math.max(8, r.bottom + bounds.height < window.innerHeight ? r.bottom + 4 : r.top - bounds.height - 4) + 'px'; items[0].focus();
    }
    listen(trigger, 'click', () => menu.hidden ? openMenu() : closeMenu(false));
    listen(trigger, 'keydown', e => { if (e.key === 'ArrowDown') { e.preventDefault(); openMenu(); } });
    listen(menu, 'keydown', e => {
      if (e.key === 'Escape') { e.preventDefault(); closeMenu(true); }
      else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const i = items.indexOf(document.activeElement); items[(i + (e.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length].focus(); }
      else if (e.key === 'Tab') closeMenu(false);
    });
    listen(document, 'pointerdown', e => { if (!menu.contains(e.target) && !root.contains(e.target)) closeMenu(false); });
    window.addEventListener('scroll', () => closeMenu(false), { capture: true, passive: true, signal: controller.signal });
    listen(window, 'resize', () => closeMenu(false));
    groups.forEach(g => {
      listen(g.layer, 'change', () => { cancel(); fillFeatures(g); });
      listen(g.feature, 'change', () => cancel());
    });
    listen(relation, 'change', () => { cancel(); explain(); });
    listen(refresh, 'click', refreshLayers);
    listen(clear, 'click', () => cancel('Analysis cleared. Drawings and map selections are unchanged.'));
    listen(close, 'click', () => { cancel(); panel.hidden = true; trigger.focus(); });
    function highlight(features) {
      if (!map.getSource(SOURCE)) {
        map.addSource(SOURCE, { type: 'geojson', data: empty() });
        map.addLayer({ id: PREFIX + 'fill', type: 'fill', source: SOURCE, filter: ['==', ['geometry-type'], 'Polygon'], paint: { 'fill-color': '#00acc1', 'fill-opacity': 0.15 } });
        map.addLayer({ id: PREFIX + 'line', type: 'line', source: SOURCE, filter: ['!=', ['geometry-type'], 'Point'], paint: { 'line-color': '#008fa8', 'line-width': 4, 'line-dasharray': [2, 1] } });
        map.addLayer({ id: PREFIX + 'point', type: 'circle', source: SOURCE, filter: ['==', ['geometry-type'], 'Point'], paint: { 'circle-color': '#00acc1', 'circle-radius': 9, 'circle-opacity': 0.6, 'circle-stroke-color': '#006878', 'circle-stroke-width': 2 } });
      }
      map.getSource(SOURCE).setData({ type: 'FeatureCollection', features: features.map(f => ({ type: 'Feature', properties: {}, geometry: f.geometry })) });
    }
    listen(run, 'click', async () => {
      cancel(); const token = s.serial, choice = relation.value;
      s.busy = true; run.disabled = true; s.inputs.forEach(el => { el.disabled = true; });
      status.textContent = 'Loading geometry engine…';
      try {
        const available = sources(map);
        const sets = groups.map(g => {
          const src = available.find(x => x.id === g.layer.value);
          if (!src) throw new Error('Layer is unavailable. Refresh layers.');
          const features = src.features.map((f, index) => ({ f, index })).filter(x => g.feature.value === '*' || String(x.index) === g.feature.value);
          if (!features.length) throw new Error(src.name + ' has no completed features.');
          return { id: src.id, features: JSON.parse(JSON.stringify(features)) };
        });
        s.sourceIds = sets.map(x => x.id);
        if (sets[0].features.length * sets[1].features.length > MAX_PAIRS) throw new Error('More than ' + MAX_PAIRS + ' candidate pairs. Choose an individual feature to narrow the analysis.');
        const jsts = await engine(); if (token !== s.serial || s.dead) return;
        const reader = new jsts.io.GeoJSONReader(), budget = { count: 0 };
        for (const set of sets) {
          for (let i = 0; i < set.features.length; i++) {
            const item = set.features[i];
            try { item.geometry = prepare(item.f, reader, jsts, budget); }
            catch (e) { throw new Error(labelOf(item.f, item.index) + ': ' + e.message); }
            if (i % 20 === 0) { await new Promise(resolve => setTimeout(resolve, 0)); if (token !== s.serial || s.dead) return; }
          }
        }
        const matches = []; let checked = 0, capped = false;
        outer: for (const a of sets[0].features) for (const b of sets[1].features) {
          if (sets[0].id === sets[1].id && a.index === b.index) continue;
          if (relates(jsts, a.geometry, b.geometry, choice)) {
            if (matches.length === MAX_RESULTS) { capped = true; break outer; }
            matches.push({ a, b });
          }
          if (++checked % 100 === 0) {
            status.textContent = 'Analyzing… ' + checked + ' pairs checked.';
            await new Promise(resolve => setTimeout(resolve, 0)); if (token !== s.serial || s.dead) return;
          }
        }
        if (token !== s.serial || s.dead) return;
        const unique = new Map(); matches.forEach(({ a, b }) => { unique.set(sets[0].id + ':' + a.index, a.f); unique.set(sets[1].id + ':' + b.index, b.f); });
        highlight([...unique.values()]);
        const table = node('table'), header = node('tr');
        ['Feature A', 'Relationship', 'Feature B', 'Map'].forEach(text => { const th = node('th', text); th.scope = 'col'; header.appendChild(th); });
        const head = node('thead'); head.appendChild(header); table.appendChild(head); const body = node('tbody');
        matches.forEach(({ a, b }) => {
          const row = node('tr'); row.append(node('td', labelOf(a.f, a.index)), node('td', choice), node('td', labelOf(b.f, b.index)));
          const cell = node('td'), show = button('Highlight pair'); cell.appendChild(show); row.appendChild(cell);
          listen(show, 'click', () => highlight([a.f, b.f])); body.appendChild(row);
        });
        table.appendChild(body); output.appendChild(table);
        const all = button('Highlight all results'); listen(all, 'click', () => highlight([...unique.values()])); output.prepend(all);
        status.textContent = capped ? 'Partial results: first ' + MAX_RESULTS + ' matching pairs shown. Narrow the feature choices for a complete result.' : matches.length + ' matching pairs; ' + unique.size + ' distinct features highlighted. ' + checked + ' pairs checked.';
      } catch (error) {
        if (token === s.serial && !s.dead) { output.replaceChildren(); clearHighlight(); status.textContent = 'Analysis stopped: ' + error.message; }
      } finally {
        if (token === s.serial && !s.dead) { s.busy = false; run.disabled = false; s.inputs.forEach(el => { el.disabled = false; }); }
      }
    });
    const changed = e => {
      if (e.sourceDataType === 'content' && s.sourceIds.includes(e.sourceId) && (s.busy || output.childElementCount)) cancel('Layer data changed. Refresh layers and run analysis again.');
    };
    map.on('sourcedata', changed);
    s.dispose = removed => {
      s.dead = true; s.serial++; controller.abort(); map.off('sourcedata', changed); map.off('remove', removedHandler);
      root.remove(); panel.remove(); menu.remove();
      if (!removed) { try { ['point', 'line', 'fill'].forEach(key => { if (map.getLayer(PREFIX + key)) map.removeLayer(PREFIX + key); }); if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) { /* map disposed */ } }
      sessions.delete(id);
    };
    const removedHandler = () => s.dispose(true); map.on('remove', removedHandler);
    s.hide = () => { closeMenu(false); if (s.busy) cancel('Analysis cancelled because the map was hidden.'); };
    s.root = root; s.toolbar = toolbar; sessions.set(id, s);
  }
  const style = node('style'); style.textContent = `
    .aoan-menu-root{display:inline-flex;align-items:center}
    .aoan-trigger{appearance:none!important;border:0!important;box-shadow:none!important;background:transparent!important;color:#172b3a!important;padding:9px 14px!important;border-radius:6px!important;font:600 14px/1.4 "Segoe UI",Arial,sans-serif!important;cursor:pointer!important}
    .aoan-trigger:hover,.aoan-trigger[aria-expanded=true]{background:#eaf1f6!important}
    .aoan-menu{position:fixed;z-index:100005;min-width:185px;padding:5px;background:#fff;border:1px solid #dce2e8;border-radius:8px;box-shadow:0 8px 24px #172b3a26}
    .aoan-menu[hidden],.aoan-panel[hidden]{display:none!important}
    .aoan-menu button{display:block!important;width:100%!important;text-align:left!important;border:0!important;box-shadow:none!important;background:transparent!important;color:#172b3a!important;border-radius:4px!important;padding:9px 12px!important;font:14px/1.4 "Segoe UI",Arial,sans-serif!important;cursor:pointer!important}
    .aoan-menu button:hover,.aoan-menu button:focus-visible{background:#eaf4fb!important}
    .aoan-panel{padding:16px;background:#f7fafc;color:#172b3a;border-top:1px solid #dce2e8;font:14px/1.5 "Segoe UI",Arial,sans-serif}
    .aoan-panel h3{margin:0;font-size:17px}.aoan-controls,.aoan-actions{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0}
    .aoan-controls label{display:flex;flex-direction:column;gap:4px;max-width:100%}.aoan-controls select{max-width:280px;padding:7px;border:1px solid #b9c8d3;border-radius:5px;background:white;color:#172b3a}
    .aoan-panel button{padding:7px 12px;border:1px solid #b9c8d3;border-radius:5px;background:white;color:#172b3a;cursor:pointer}.aoan-panel button:disabled{opacity:.5;cursor:wait}
    .aoan-output{max-height:320px;overflow:auto}.aoan-output table{width:100%;border-collapse:collapse;text-align:left;background:white}.aoan-output th,.aoan-output td{padding:7px 10px;border-bottom:1px solid #dce2e8;overflow-wrap:anywhere}.aoan-output th{background:#eaf1f6;position:sticky;top:0}.aoan-note{font-size:12px;color:#465d6b}
    .aoan-panel :focus-visible,.aoan-trigger:focus-visible,.aoan-menu :focus-visible{outline:2px solid #007d9a!important;outline-offset:2px}
  `; document.head.appendChild(style);
  function scan() {
    if (stopped) return;
    sessions.forEach(s => {
      if (!s.block.isConnected || !s.root.isConnected || !s.toolbar.isConnected || window.askOracleMap?.getMap(s.id) !== s.map) s.dispose(false);
      else if (s.block.hidden) s.hide();
    });
    document.querySelectorAll('.llm-conv-show-map-btn[data-id]').forEach(button => {
      const id = button.dataset.id, map = window.askOracleMap?.getMap(id); if (!map || sessions.has(id)) return;
      const block = map.getContainer().closest('.ask-oracle-map-block'), toolbar = block?.querySelector('.aod-toolbar');
      if (toolbar && map.getSource('aod-drawings')) attach(id, map, block, toolbar);
    });
  }
  const timer = setInterval(scan, 1000);
  window.askOracleMapAnalysis = {
    version: '1.0.0', refresh: scan,
    destroy: () => { stopped = true; clearInterval(timer); sessions.forEach(s => s.dispose(false)); style.remove(); delete window.askOracleMapAnalysis; }
  };
  scan();
})();
