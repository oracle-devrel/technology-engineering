(function() {
  if (window.__askOracleSearchChatsModuleLoaded) return;
  window.__askOracleSearchChatsModuleLoaded = true;

  var DIALOG_ID = "ask-oracle-chat-search-dialog";
  var INPUT_ID = "ask-oracle-chat-search-input";
  var RESULTS_ID = "ask-oracle-chat-search-results";
  var TRIGGER_ID = "ask-oracle-chat-search-trigger";
  var INDEX_STORAGE_KEY = "ASK_ORACLE_CHAT_SEARCH_INDEX_V1";
  var PAGE4_SCRIPT_FLAG = "data-ask-oracle-search-page4-script";
  var PAGE4_STYLE_ID = "ask-oracle-search-page4-css";
  var state = {
    open: false,
    items: [],
    filteredItems: [],
    activeIndex: -1
  };

  function normalizeText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function nowTs() {
    return Date.now();
  }

  function isSearchChatsPage4() {
    return !!document.getElementById("P4_SEARCH");
  }

  function getSearchChatsScriptUrl() {
    var explicitScript = document.querySelector('script[src*="search_chats.js"]');
    if (explicitScript && explicitScript.src) return String(explicitScript.src);
    var scripts = Array.from(document.scripts || []);
    var matched = scripts.find(function(scriptEl) {
      return /search_chats\.js(?:[?#].*)?$/i.test(String(scriptEl && scriptEl.src || ""));
    });
    return matched && matched.src ? String(matched.src) : "";
  }

  function buildSiblingAssetUrl(fileName) {
    var scriptUrl = getSearchChatsScriptUrl();
    if (!scriptUrl) return fileName;
    return scriptUrl.replace(/search_chats\.js(?:[?#].*)?$/i, fileName);
  }

  function ensureStyleAsset(fileName, styleId) {
    if (styleId && document.getElementById(styleId)) return;
    var href = buildSiblingAssetUrl(fileName);
    if (!href) return;
    var link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    if (styleId) link.id = styleId;
    document.head.appendChild(link);
  }

  function ensureScriptAsset(fileName, attrName) {
    return new Promise(function(resolve, reject) {
      var selector = 'script[' + attrName + '="1"]';
      var existing = document.querySelector(selector);
      if (existing) {
        if (existing.getAttribute("data-loaded") === "1") {
          resolve();
          return;
        }
        existing.addEventListener("load", function() { resolve(); }, { once: true });
        existing.addEventListener("error", function() { reject(new Error("Failed to load " + fileName)); }, { once: true });
        return;
      }
      var src = buildSiblingAssetUrl(fileName);
      var script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.setAttribute(attrName, "1");
      script.addEventListener("load", function() {
        script.setAttribute("data-loaded", "1");
        resolve();
      }, { once: true });
      script.addEventListener("error", function() {
        reject(new Error("Failed to load " + fileName));
      }, { once: true });
      document.head.appendChild(script);
    });
  }

  function readChatIndex() {
    var liveItems = getLiveRecentChats(5);
    var items = {};
    liveItems.forEach(function(item) {
      items[item.conversationId] = item;
    });
    return { updated_at: nowTs(), items: items };
  }

  function writeChatIndex(nextState) {
    return nextState && typeof nextState === "object" ? nextState : { updated_at: nowTs(), items: {} };
  }

  function mergeChatIndexItems(items) {
    var incomingItems = Array.isArray(items) ? items : [];
    if (!incomingItems.length) return readChatIndex();

    var stateSnapshot = readChatIndex();
    var knownItems = stateSnapshot.items || {};
    var timestamp = nowTs();

    incomingItems.forEach(function(item, index) {
      var conversationId = String(item && item.conversationId || "").trim();
      if (!conversationId) return;
      var existing = knownItems[conversationId] && typeof knownItems[conversationId] === "object"
        ? knownItems[conversationId]
        : {};
      var nextTitle = normalizeText(item.title || existing.title || "");
      var nextUrl = String(item.url || existing.url || "").trim();
      var nextTimestamp = Number(
        item.timestamp ||
        item.created_at ||
        item.modified_at ||
        existing.timestamp ||
        existing.created_at ||
        existing.modified_at ||
        0
      ) || 0;
      var existingLastOpened = Number(existing.last_opened_at || 0) || 0;
      var nextLastOpened = item.current ? timestamp : existingLastOpened;
      var nextItem = {
        conversationId: conversationId,
        title: nextTitle,
        url: nextUrl,
        pinned: !!(item.pinned || existing.pinned),
        current: !!item.current,
        sortIndex: typeof item.sortIndex === "number" ? item.sortIndex : (typeof existing.sortIndex === "number" ? existing.sortIndex : index),
        timestamp: nextTimestamp,
        created_at: nextTimestamp,
        last_seen_at: timestamp,
        last_opened_at: nextLastOpened,
        updated_at: timestamp
      };
      knownItems[conversationId] = nextItem;
    });

    stateSnapshot.items = knownItems;
    return stateSnapshot;
  }

  function getChatIndexItems() {
    return getLiveRecentChats(5);
  }

  window.AskOracleSearchChatsShared = {
    buildSiblingAssetUrl: buildSiblingAssetUrl,
    readChatIndex: readChatIndex,
    writeChatIndex: writeChatIndex,
    mergeChatIndexItems: mergeChatIndexItems,
    getChatIndexItems: getChatIndexItems,
    normalizeText: normalizeText
  };

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function shortcutLabel() {
    var platform = String((window.navigator && (window.navigator.platform || window.navigator.userAgent)) || "").toLowerCase();
    return platform.indexOf("mac") >= 0 ? "Cmd K" : "Ctrl K";
  }

  function canUseSearchChats() {
    if (typeof isAskOraclePageOne === "function") {
      try { return !!isAskOraclePageOne(); } catch (e) {}
    }
    return !!document.getElementById("t_TreeNav");
  }

  function dialogEl() {
    return document.getElementById(DIALOG_ID);
  }

  function inputEl() {
    return document.getElementById(INPUT_ID);
  }

  function resultsEl() {
    return document.getElementById(RESULTS_ID);
  }

  function getSearchChatsPageUrl(seedValue) {
    var appId = "";
    var sessionId = "";
    try {
      if (window.apex && apex.env) {
        appId = String(apex.env.APP_ID || "").trim();
        sessionId = String(apex.env.APP_SESSION || apex.env.SESSION || "").trim();
      }
    } catch (e) {}
    try {
      if (typeof window.$v === "function") {
        if (!appId) appId = String(window.$v("pFlowId") || "").trim();
        if (!sessionId) sessionId = String(window.$v("pInstance") || "").trim();
      }
    } catch (e2) {}
    if (!appId || !sessionId) return "";

    var searchValue = String(seedValue || "").trim();
    var url = "f?p=" + appId + ":4:" + sessionId + "::NO::";
    if (searchValue) {
      url += "P4_SEARCH:" + encodeURIComponent(searchValue);
    }
    try {
      if (window.apex && apex.util && typeof apex.util.prepareURL === "function") {
        var prepared = String(apex.util.prepareURL(url) || "").trim();
        if (prepared) return prepared;
      }
    } catch (e3) {}
    return url;
  }

  function openFullSearchPage(seedValue) {
    var url = getSearchChatsPageUrl(seedValue);
    if (!url) return;
    try {
      if (window.apex && apex.navigation && typeof apex.navigation.dialog === "function") {
        apex.navigation.dialog(url, {
          title: "Search Chats",
          modal: true,
          height: "auto",
          width: "760",
          maxWidth: "96vw"
        }, "t-Dialog-page--standard");
        return;
      }
    } catch (e) {}
    try {
      if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
        apex.navigation.redirect(url);
        return;
      }
    } catch (e2) {}
    window.location.href = url;
  }

  function openSearchResultConversation(item) {
    if (!item || !item.conversationId) return;
    closePalette();
    if (item.url) {
      try {
        if (window.apex && apex.navigation && typeof apex.navigation.redirect === "function") {
          apex.navigation.redirect(item.url);
          return;
        }
      } catch (e) {}
      window.location.href = item.url;
      return;
    }
    try {
      if (typeof switchAskOracleConversationInPlace === "function") {
        switchAskOracleConversationInPlace(item.conversationId, { forceRefresh: true });
      }
    } catch (e2) {}
  }

  function searchNavEntry() {
    var treeRoot = document.getElementById("t_TreeNav");
    if (!treeRoot) return null;
    var labelNode = Array.from(treeRoot.querySelectorAll(".a-TreeView-label")).find(function(node) {
      return String((node && node.textContent) || "").trim().toLowerCase() === "search chats";
    });
    return labelNode && labelNode.closest ? labelNode.closest("li") : null;
  }

  function hideSearchNavEntry() {
    var navEntry = searchNavEntry();
    if (!navEntry || !navEntry.style) return;
    navEntry.style.display = "none";
  }

  function deriveConversationTitle(node, conversationId) {
    var labelNode = node.querySelector(".a-TreeView-label");
    var fullLabel = "";
    try {
      fullLabel = typeof normalizeAskOracleHistoryNavFullLabel === "function"
        ? normalizeAskOracleHistoryNavFullLabel(
            (labelNode && (
              labelNode.getAttribute("data-full-label") ||
              labelNode.getAttribute("aria-label") ||
              labelNode.textContent
            )) || ""
          )
        : String((labelNode && labelNode.textContent) || "").trim();
    } catch (e) {}
    if (fullLabel) return fullLabel;
    try {
      if (typeof buildAskOracleHistoryNavLabel === "function") {
        return buildAskOracleHistoryNavLabel({}, conversationId);
      }
    } catch (e2) {}
    return "Conversation " + String(conversationId || "").slice(0, 12);
  }

  function collectChats() {
    var treeRoot = document.getElementById("t_TreeNav");
    if (!treeRoot) return [];
    var currentConversationId = "";
    var pinnedSubtree = null;
    try {
      if (typeof getAskOracleCurrentConversationId === "function") {
        currentConversationId = String(getAskOracleCurrentConversationId() || "").trim();
      }
    } catch (e) {}
    try {
      if (typeof getAskOraclePinnedNavSubtree === "function") {
        pinnedSubtree = getAskOraclePinnedNavSubtree();
      }
    } catch (e2) {}

    var items = [];
    var seen = new Set();
    Array.from(treeRoot.querySelectorAll("li")).forEach(function(node, index) {
      var conversationId = "";
      try {
        if (typeof getAskOracleConversationIdFromNavNode === "function") {
          conversationId = String(getAskOracleConversationIdFromNavNode(node) || "").trim();
        }
      } catch (e) {}
      if (!conversationId || seen.has(conversationId)) return;

      try {
        if (typeof isAskOracleConversationNavLink === "function" && !isAskOracleConversationNavLink(node)) {
          return;
        }
      } catch (e2) {}

      var title = deriveConversationTitle(node, conversationId);
      if (!title) return;

      var url = "";
      try {
        if (typeof getAskOracleNavNodeHref === "function") {
          url = getAskOracleNavNodeHref(node);
        }
      } catch (e3) {}

      items.push({
        conversationId: conversationId,
        title: title,
        url: url,
        pinned: !!(pinnedSubtree && pinnedSubtree.contains(node)),
        current: currentConversationId === conversationId,
        sortIndex: index
      });
      seen.add(conversationId);
    });

    state.items = items;
    return items;
  }

  function getLiveRecentChats(limit) {
    var maxItems = Number(limit) > 0 ? Number(limit) : 5;
    return collectChats().slice().sort(function(a, b) {
      if (a.current !== b.current) return a.current ? -1 : 1;
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return a.sortIndex - b.sortIndex;
    }).slice(0, maxItems);
  }

  function filteredChats(queryText) {
    var normalizedQuery = String(queryText || "").trim().toLowerCase();
    var items = collectChats();
    if (!normalizedQuery) {
      return getLiveRecentChats(5);
    }

    return items
      .map(function(item) {
        var lowerTitle = String(item.title || "").toLowerCase();
        var index = lowerTitle.indexOf(normalizedQuery);
        if (index < 0) return null;
        var score = 300 + index;
        if (lowerTitle === normalizedQuery) score = 0;
        else if (lowerTitle.indexOf(normalizedQuery) === 0) score = 40;
        else if (lowerTitle.indexOf(" " + normalizedQuery) >= 0) score = 90 + index;
        if (item.current) score -= 8;
        if (item.pinned) score -= 4;
        return { item: item, score: score };
      })
      .filter(Boolean)
      .sort(function(a, b) {
        if (a.score !== b.score) return a.score - b.score;
        return a.item.sortIndex - b.item.sortIndex;
      })
      .map(function(entry) { return entry.item; })
      .slice(0, 40);
  }

  function highlightMatch(text, query) {
    var source = String(text || "");
    var needle = String(query || "").trim();
    if (!needle) return escapeHtml(source);
    var matchIndex = source.toLowerCase().indexOf(needle.toLowerCase());
    if (matchIndex < 0) return escapeHtml(source);
    return (
      escapeHtml(source.slice(0, matchIndex)) +
      "<mark>" + escapeHtml(source.slice(matchIndex, matchIndex + needle.length)) + "</mark>" +
      escapeHtml(source.slice(matchIndex + needle.length))
    );
  }

  function renderResults() {
    var resultsHost = resultsEl();
    var input = inputEl();
    if (!resultsHost || !input) return;

    var query = String(input.value || "").trim();
    var items = filteredChats(query);
    state.filteredItems = items;
    if (!items.length) {
      state.activeIndex = -1;
    } else if (state.activeIndex < 0 || state.activeIndex >= items.length) {
      state.activeIndex = 0;
    }

    resultsHost.innerHTML = "";
    if (!items.length) {
      var empty = document.createElement("div");
      empty.className = "ask-oracle-chat-search-empty";
      empty.textContent = query
        ? "No matching chats found. Use the full Search Chats page to search more broadly."
        : "Start typing to search your chats.";
      resultsHost.appendChild(empty);
    } else {
      items.forEach(function(item, index) {
        var button = document.createElement("button");
        button.type = "button";
        button.className = "ask-oracle-chat-search-result" + (index === state.activeIndex ? " is-active" : "");
        button.setAttribute("data-conversation-id", item.conversationId);
        button.innerHTML =
          '<div class="ask-oracle-chat-search-result-title">' + highlightMatch(item.title, query) + "</div>" +
          '<div class="ask-oracle-chat-search-result-meta">' +
            (item.current ? '<span class="ask-oracle-chat-search-badge current">Current chat</span>' : "") +
            (item.pinned ? '<span class="ask-oracle-chat-search-badge pinned">Pinned</span>' : "") +
          "</div>";
        button.addEventListener("mouseenter", function() {
          state.activeIndex = index;
          renderResults();
        });
        button.addEventListener("click", function(event) {
          if (event) {
            event.preventDefault();
            event.stopPropagation();
          }
          openSearchResultConversation(item);
        });
        resultsHost.appendChild(button);
      });
    }

    var advancedBtn = document.createElement("button");
    advancedBtn.type = "button";
    advancedBtn.className = "ask-oracle-chat-search-advanced";
    advancedBtn.textContent = query ? 'Open full Search Chats for "' + query + '"' : "Open full Search Chats";
    advancedBtn.addEventListener("click", function(event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }
      closePalette();
      openFullSearchPage(query);
    });
    resultsHost.appendChild(advancedBtn);

    var activeButton = resultsHost.querySelector(".ask-oracle-chat-search-result.is-active");
    if (activeButton && typeof activeButton.scrollIntoView === "function") {
      activeButton.scrollIntoView({ block: "nearest" });
    }
  }

  function moveSelection(delta) {
    var items = state.filteredItems || [];
    if (!items.length) return;
    var current = Number(state.activeIndex);
    var next = current < 0 ? 0 : (current + delta + items.length) % items.length;
    state.activeIndex = next;
    renderResults();
  }

  function closePalette() {
    var dialog = dialogEl();
    if (!dialog) return;
    dialog.classList.remove("is-open");
    dialog.setAttribute("hidden", "hidden");
    state.open = false;
  }

  function openPalette(seedValue) {
    ensureUi();
    var dialog = dialogEl();
    var input = inputEl();
    if (!dialog || !input) return;
    dialog.removeAttribute("hidden");
    dialog.classList.add("is-open");
    state.open = true;
    state.activeIndex = 0;
    input.value = String(seedValue == null ? "" : seedValue);
    renderResults();
    requestAnimationFrame(function() {
      try {
        input.focus({ preventScroll: true });
        input.setSelectionRange(input.value.length, input.value.length);
      } catch (e) {}
    });
  }

  function ensureUi() {
    if (dialogEl()) return;
    var overlay = document.createElement("div");
    overlay.id = DIALOG_ID;
    overlay.className = "ask-oracle-chat-search-overlay";
    overlay.setAttribute("hidden", "hidden");
    overlay.innerHTML =
      '<div class="ask-oracle-chat-search-modal" role="dialog" aria-modal="true" aria-labelledby="' + INPUT_ID + '">' +
        '<div class="ask-oracle-chat-search-bar">' +
          '<span class="search-icon">' + (typeof getAskOracleInlineSvgIcon === "function" ? getAskOracleInlineSvgIcon("search") : "") + "</span>" +
          '<input id="' + INPUT_ID + '" class="ask-oracle-chat-search-input" type="search" placeholder="Search chats..." autocomplete="off" spellcheck="false" />' +
          '<button type="button" class="ask-oracle-chat-search-close" aria-label="Close search">Esc</button>' +
        "</div>" +
        '<div id="' + RESULTS_ID + '" class="ask-oracle-chat-search-results"></div>' +
        '<div class="ask-oracle-chat-search-footer"><span>Use arrow keys to move, Enter to open.</span><span>' + escapeHtml(shortcutLabel()) + "</span></div>" +
      "</div>";
    document.body.appendChild(overlay);

    var input = inputEl();
    var closeBtn = overlay.querySelector(".ask-oracle-chat-search-close");
    if (input) {
      input.addEventListener("input", function() {
        state.activeIndex = 0;
        renderResults();
      });
      input.addEventListener("keydown", function(event) {
        if (!event) return;
        if (event.key === "ArrowDown") {
          event.preventDefault();
          moveSelection(1);
          return;
        }
        if (event.key === "ArrowUp") {
          event.preventDefault();
          moveSelection(-1);
          return;
        }
        if (event.key === "Enter") {
          var items = state.filteredItems || [];
          var activeIndex = Number(state.activeIndex);
          if (!items.length || activeIndex < 0 || activeIndex >= items.length) return;
          event.preventDefault();
          openSearchResultConversation(items[activeIndex]);
          return;
        }
        if (event.key === "Escape") {
          event.preventDefault();
          closePalette();
        }
      });
    }

    if (closeBtn) {
      closeBtn.addEventListener("click", function(event) {
        if (event) {
          event.preventDefault();
          event.stopPropagation();
        }
        closePalette();
      });
    }

    overlay.addEventListener("mousedown", function(event) {
      if (!event || event.target !== overlay) return;
      closePalette();
    });
  }

  function ensureLauncher() {
    if (!canUseSearchChats()) return;
    var navEl = document.querySelector("#t_Body_nav, .t-Body-nav");
    var treeRoot = document.getElementById("t_TreeNav");
    if (!navEl || !treeRoot) return;
    ensureUi();
    hideSearchNavEntry();

    var host = navEl.querySelector(".ask-oracle-chat-search-host");
    if (!host) {
      host = document.createElement("div");
      host.className = "ask-oracle-chat-search-host";
      navEl.insertBefore(host, treeRoot);
    }

    var trigger = document.getElementById(TRIGGER_ID);
    if (trigger) return;
    trigger = document.createElement("button");
    trigger.type = "button";
    trigger.id = TRIGGER_ID;
    trigger.className = "ask-oracle-chat-search-trigger";
    trigger.setAttribute("aria-haspopup", "dialog");
    trigger.innerHTML =
      '<span class="search-icon">' + (typeof getAskOracleInlineSvgIcon === "function" ? getAskOracleInlineSvgIcon("search") : "") + "</span>" +
      '<span class="search-label">Search chats</span>' +
      '<span class="search-shortcut">' + escapeHtml(shortcutLabel()) + "</span>";
    trigger.addEventListener("click", function(event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }
      openPalette("");
    });
    host.appendChild(trigger);
  }

  function bindShortcut() {
    if (window.__askOracleSearchChatsShortcutBound) return;
    window.__askOracleSearchChatsShortcutBound = true;
    document.addEventListener("keydown", function(event) {
      if (!event) return;
      var key = String(event.key || "").toLowerCase();
      var target = event.target;
      var isEditable = !!(
        target &&
        (
          target.isContentEditable ||
          /^(input|textarea|select)$/i.test(String(target.tagName || "")) ||
          (typeof target.closest === "function" && target.closest(".ace_text-input"))
        )
      );

      if ((event.metaKey || event.ctrlKey) && !event.altKey && key === "k") {
        event.preventDefault();
        openPalette("");
        return;
      }
      if (state.open && key === "escape") {
        event.preventDefault();
        closePalette();
        return;
      }
      if (isEditable || state.open) return;
      if (key === "/" && !event.metaKey && !event.ctrlKey && !event.altKey) {
        event.preventDefault();
        openPalette("");
      }
    }, true);
  }

  function refresh() {
    if (!canUseSearchChats()) return;
    ensureLauncher();
    hideSearchNavEntry();
  }

  function startObserver() {
    if (window.__askOracleSearchChatsObserverBound) return;
    window.__askOracleSearchChatsObserverBound = true;
    if (!(window.MutationObserver && document.body)) return;
    var timer = null;
    var observer = new MutationObserver(function() {
      if (timer) clearTimeout(timer);
      timer = setTimeout(function() {
        timer = null;
        refresh();
      }, 80);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function init() {
    if (isSearchChatsPage4()) {
      ensureStyleAsset("search_chats_page4.css", PAGE4_STYLE_ID);
      ensureScriptAsset("search_chats_page4.js", PAGE4_SCRIPT_FLAG).catch(function(err) {
        console.warn("Page 4 Search Chats enhancement failed to load:", err && err.message ? err.message : err);
      });
      return;
    }
    bindShortcut();
    refresh();
    startObserver();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
