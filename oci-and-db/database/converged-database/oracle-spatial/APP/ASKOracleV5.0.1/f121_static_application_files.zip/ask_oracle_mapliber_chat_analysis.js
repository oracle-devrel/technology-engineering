/* AskOracle LLM spatial bridge v2.2.0.
 * Load after ask_oracle_function.js, map, drawing and analysis v1.2.0-llm.
 * Uses the EXISTING EXECUTE_PROMPT callback with its spatial SQL update.
 * No question regex, keyword router, new Ajax callback, drag/drop or map picker.
 * The LLM selects a profile-scoped spatial dataset; the server validates the
 * choice and queries it using transient drawing geometry. No drawing is stored.
 * Results are temporary, in the existing Analysis results area on the same map.
 * Requests with an open map incur an LLM interpretation call, including questions
 * ultimately routed to normal chat. Hide maps to use normal chat without it.
 */
(function () {
  'use strict';
  if (window.askOracleMapChatAnalysis) return;
  const controller = new AbortController(), observedMaps = new Map();
  let activeMap = null, pendingMapId = null, openSequence = 0, contextKey = null, contextHost = null;
  let stopped = false, generation = 0;
  const listen = (el, type, fn, options = {}) => el.addEventListener(type, fn, { ...options, signal: controller.signal });
  function conversation() {
    try { return String(window.apex?.item('P1_CONV_ID')?.getValue() || ''); }
    catch (_) { return document.getElementById('P1_CONV_ID')?.value || ''; }
  }
  function parent() { return document.querySelector('#PROMPTS .prompt-list') || document.getElementById('PROMPTS'); }
  function openMaps() {
    const key = conversation(), host = parent();
    if (key !== contextKey || host !== contextHost) {
      observedMaps.clear(); activeMap = null; pendingMapId = null;
      contextKey = key; contextHost = host;
    }
    const maps = (window.askOracleMapAnalysis?.getOpenMaps?.() || []).map(info => {
      const map = window.askOracleMap?.getMap(info.id);
      if (!map) return null;
      if (!observedMaps.has(map)) observedMaps.set(map, ++openSequence);
      return { ...info, map, opened: observedMaps.get(map) };
    }).filter(Boolean);
    const live = new Set(maps.map(m => m.map));
    observedMaps.forEach((_, map) => { if (!live.has(map)) observedMaps.delete(map); });
    if (!live.has(activeMap)) activeMap = null;
    if (pendingMapId != null) {
      const opened = maps.find(m => String(m.id) === pendingMapId);
      if (opened) { activeMap = opened.map; pendingMapId = null; }
    }
    return maps;
  }
  function rememberMap(event) {
    const block = event.target.closest?.('.ask-oracle-map-block');
    const opener = event.type === 'click' && event.target.closest?.('.llm-conv-show-map-btn[data-id]');
    if (!block && !opener) return;
    const maps = openMaps();
    if (opener) { pendingMapId = String(opener.dataset.id); return; }
    const used = maps.find(m => m.map.getContainer().closest('.ask-oracle-map-block') === block);
    if (used) { activeMap = used.map; pendingMapId = null; }
  }
  function prepareRequest(question) {
    if (stopped) return null;
    const maps = openMaps();
    if (!maps.length) return null;
    const chosen = maps.find(m => m.map === activeMap) || maps.reduce((a, b) => a.opened > b.opened ? a : b);
    const api = window.askOracleMapAnalysis;
    if (!api.captureContext) throw new Error('Upload analysis v1.2.0-llm together with the chat bridge.');
    const captured = api.captureContext(chosen.id);
    const token = window.crypto.randomUUID();
    const catalog = { version: 2, drawings: captured.catalog.drawings, token };
    if (!Array.isArray(captured.drawingGeometries)) throw new Error('Upload the matching analysis script before using database spatial questions.');
    const request = { ...catalog, drawingGeometries: captured.drawingGeometries };
    const payload = JSON.stringify(request);
    if (new TextEncoder().encode(payload).length > 24000) throw new Error('Too much map metadata for chat. Narrow the map results or use the Analysis menu.');
    return { payload, catalog, snapshot: captured.snapshot, mapId: chosen.id, map: chosen.map,
      question: String(question || ''), host: parent(), conversation: conversation(), generation: ++generation };
  }
  function current(ticket) {
    return ticket && !stopped && ticket.generation === generation && ticket.host === parent() &&
      ticket.conversation === conversation() && openMaps().some(m => m.map === ticket.map && m.id === ticket.mapId);
  }
  async function handleResponse(ticket, data) {
    if (!current(ticket)) throw new Error('The map or conversation changed. Ask the question again on the current map.');
    if (!data || data.status !== 'spatial' || data.token !== ticket.catalog.token) throw new Error('Invalid spatial response. Check that the matching EXECUTE_PROMPT update is installed.');
    const action = data.action;
    if (!action || typeof action !== 'object' || Array.isArray(action)) throw new Error('Missing spatial action.');
    const api = window.askOracleMapAnalysis;
    if (api.captureContext(ticket.mapId).snapshot !== ticket.snapshot) throw new Error('Map features changed while the question was being interpreted. Please ask again.');
    if (action.kind === 'clarify') {
      if (typeof action.message !== 'string' || !action.message.trim() || action.message.length > 1000) throw new Error('Invalid clarification response.');
      api.showMessage(ticket.mapId, ticket.question, action.message);
      return;
    }
    if (action.kind === 'database') {
      api.showDatabaseResult(ticket.mapId, ticket.question, action);
      return;
    }
    throw new Error('The spatial response does not match the installed database route.');
  }
  function cancel() {
    ++generation;
  }
  ['pointerdown', 'click', 'focusin', 'wheel'].forEach(type => listen(window, type, rememberMap, { capture: true, passive: true }));
  const mapTimer = setInterval(() => { if (!stopped) openMaps(); }, 500);
  openMaps();
  window.askOracleMapChatAnalysis = {
    version: '2.2.0', prepareRequest, handleResponse, cancel,
    destroy: () => { cancel(); stopped = true; clearInterval(mapTimer); observedMaps.clear(); controller.abort(); delete window.askOracleMapChatAnalysis; }
  };
})();
