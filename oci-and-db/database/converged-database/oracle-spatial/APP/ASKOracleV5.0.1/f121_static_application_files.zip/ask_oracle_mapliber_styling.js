/*
 * Reusable styling for returned Ask Oracle map features. Load AFTER
 * ask_oracle_mapliber.js in APEX Page JavaScript File URLs:
 *   #APP_FILES#ask_oracle_mapliber_styling.js
 * Styles only the GeoJSON features actually returned to this map. It never
 * queries a table, changes source data, or implies a complete database layer.
 */
(function installAskOracleMapStyling() {
  "use strict";
  if (window.askOracleMapStyling) return;

  const defaults = {
    areas: { color: "#176b94", opacity: 1, size: 7 },
    lines: { color: "#b44b12", opacity: 1, size: 3 },
    points: { color: "#176b94", opacity: 1, size: 7 }
  };
  const palettes = {
    Blues: ["#eff6ff", "#07519c"],
    Greens: ["#edf8e9", "#006d2c"],
    Reds: ["#fee5d9", "#a50f15"],
    Purples: ["#f2f0f7", "#54278f"],
    Orange: ["#fff5eb", "#a63603"],
    Viridis: ["#440154", "#fde725"]
  };
  const categoryColors = ["#176b94", "#e07b39", "#3f8f73", "#8561a5", "#c55267", "#ba9b30", "#4276ac", "#8a6647", "#a24c98", "#4f858d", "#718443", "#cf6546"];
  const layerIds = { areas: "ao-areas", lines: "ao-lines", points: "ao-points" };
  const layerLabels = { areas: "Areas", lines: "Lines", points: "Points" };
  const sessions = new WeakMap();

  function node(tag, className, label) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (label !== undefined) el.textContent = label;
    return el;
  }

  function labeledSelect(parent, label, options) {
    const wrap = node("label", "aoms-field", label);
    const select = node("select");
    options.forEach(function (item) {
      const option = node("option", "", item[1]);
      option.value = item[0];
      select.appendChild(option);
    });
    wrap.appendChild(select);
    parent.appendChild(wrap);
    return select;
  }

function labeledInput(parent, label, type, value, min, max, step) {
  const wrap = node("label", "aoms-field", label);
  const input = node("input");
  input.type = type;
  if (min !== undefined) input.min = String(min);
  if (max !== undefined) input.max = String(max);
  if (step !== undefined) input.step = String(step);
  input.value = String(value);
  wrap.appendChild(input);
  parent.appendChild(wrap);
  return input;
}

  function typeOf(feature) {
    const type = feature && feature.geometry && feature.geometry.type;
    if (type === "Point" || type === "MultiPoint") return "points";
    if (type === "LineString" || type === "MultiLineString") return "lines";
    if (type === "Polygon" || type === "MultiPolygon") return "areas";
    return null;
  }

  function number(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    if (typeof value !== "string" || !value.trim()) return null;
    const parsed = Number(value.trim());
    return Number.isFinite(parsed) ? parsed : null;
  }

  function fields(features) {
    const found = new Map();
    features.forEach(function (feature) {
      Object.keys(feature.properties || {}).forEach(function (key) {
        if (key === "__proto__" || key === "constructor" || key === "prototype") return;
        const value = feature.properties[key];
        if (value === null || value === undefined || value === "") return;
        const item = found.get(key) || { count: 0, numeric: 0 };
        item.count++;
        if (number(value) !== null) item.numeric++;
        found.set(key, item);
      });
    });
    return Array.from(found).filter(function (entry) { return entry[1].count > 0; })
      .map(function (entry) { return { name: entry[0], numeric: entry[1].count === entry[1].numeric }; })
      .sort(function (a, b) { return a.name.localeCompare(b.name); });
  }

  function hexRgb(hex) { return [1, 3, 5].map(function (i) { return parseInt(hex.slice(i, i + 2), 16); }); }
  function blend(a, b, t) {
    const left = hexRgb(a), right = hexRgb(b);
    return "#" + left.map(function (v, i) {
      return Math.round(v + (right[i] - v) * t).toString(16).padStart(2, "0");
    }).join("");
  }
  function format(value) { return Number(value.toPrecision(5)).toLocaleString(); }

  function resetLayer(session, kind) {
    const map = session.map, id = layerIds[kind], base = defaults[kind];
    if (!map.getLayer(id)) return;
    map.setLayoutProperty(id, "visibility", "visible");
    if (kind === "areas") {
      map.setPaintProperty(id, "fill-color", base.color);
      map.setPaintProperty(id, "fill-opacity", base.opacity);
      map.setPaintProperty(id, "fill-outline-color", "#104963");
    } else if (kind === "lines") {
      map.setPaintProperty(id, "line-color", base.color);
      map.setPaintProperty(id, "line-opacity", base.opacity);
      map.setPaintProperty(id, "line-width", base.size);
    } else {
      map.setPaintProperty(id, "circle-color", base.color);
      map.setPaintProperty(id, "circle-opacity", base.opacity);
      map.setPaintProperty(id, "circle-radius", base.size);
    }
    if (kind === "points" && map.getLayer("ao-style-heatmap")) map.setLayoutProperty("ao-style-heatmap", "visibility", "none");
  }

  function legendItem(legend, color, label) {
    const row = node("div", "aoms-legend-row");
    const swatch = node("span", "aoms-swatch"); swatch.style.backgroundColor = color;
    row.append(swatch, node("span", "", label));
    legend.appendChild(row);
  }

  function numericStyle(session, features, field, controls, legend) {
    const values = features.map(function (f) { return number((f.properties || {})[field]); })
      .filter(function (v) { return v !== null; }).sort(function (a, b) { return a - b; });
    if (!values.length) return false;
    const count = Math.min(Number(controls.classes.value), new Set(values).size);
    const low = controls.start.value, high = controls.end.value;
    const colors = Array.from({ length: count }, function (_, i) { return blend(low, high, count === 1 ? 1 : i / (count - 1)); });
    const breaks = [];
    for (let i = 1; i < count; i++) {
      const edge = controls.method.value === "quantile"
        ? values[Math.min(values.length - 1, Math.floor(i * values.length / count))]
        : values[0] + (values[values.length - 1] - values[0]) * i / count;
      if (!breaks.length || edge > breaks[breaks.length - 1]) breaks.push(edge);
    }
    const usedColors = Array.from({ length: breaks.length + 1 }, function (_, i) {
      return colors[Math.min(colors.length - 1, Math.round(i * (colors.length - 1) / Math.max(1, breaks.length)))];
    });
    const expression = ["step", ["to-number", ["get", field], 0], usedColors[0]];
    breaks.forEach(function (edge, i) { expression.push(edge, usedColors[i + 1]); });
    const colorExpression = ["case", ["all", ["has", field], ["!=", ["get", field], null], ["!=", ["get", field], ""]], expression, "#b7c2c9"];
    const paint = session.kind === "areas" ? "fill-color" : session.kind === "lines" ? "line-color" : "circle-color";
    session.map.setPaintProperty(layerIds[session.kind], paint, colorExpression);
    usedColors.forEach(function (color, i) {
      const lower = i ? breaks[i - 1] : values[0];
      const upper = i < breaks.length ? breaks[i] : values[values.length - 1];
      legendItem(legend, color, format(lower) + " – " + format(upper));
    });
    legendItem(legend, "#b7c2c9", "Missing value");
    return true;
  }

  function categoryStyle(session, features, field, controls, legend) {
    const counts = new Map();
    features.forEach(function (feature) {
      const value = (feature.properties || {})[field];
      if (value === null || value === undefined || value === "") return;
      const key = String(value);
      counts.set(key, (counts.get(key) || 0) + 1);
    });
    const categories = Array.from(counts).sort(function (a, b) { return b[1] - a[1] || a[0].localeCompare(b[0]); }).slice(0, categoryColors.length);
    if (!categories.length) return false;
    const expression = ["match", ["to-string", ["get", field]]];
    categories.forEach(function (entry, i) {
      const color = controls.palette.value === "distinct" ? categoryColors[i]
        : blend(controls.start.value, controls.end.value, categories.length === 1 ? 1 : i / (categories.length - 1));
      expression.push(entry[0], color);
      legendItem(legend, color, entry[0] + " (" + entry[1] + ")");
    });
    expression.push("#b7c2c9");
    const paint = session.kind === "areas" ? "fill-color" : session.kind === "lines" ? "line-color" : "circle-color";
    session.map.setPaintProperty(layerIds[session.kind], paint, expression);
    if (counts.size > categories.length) legendItem(legend, "#b7c2c9", "Other categories");
    legendItem(legend, "#b7c2c9", "Missing value");
    return true;
  }

  function heatmap(session, controls, legend) {
    const map = session.map;
    if (!map.getLayer("ao-style-heatmap")) {
      map.addLayer({
        id: "ao-style-heatmap", type: "heatmap", source: "ask-oracle-results",
        filter: ["==", ["geometry-type"], "Point"],
        paint: { "heatmap-intensity": 1, "heatmap-radius": 24, "heatmap-opacity": 0.8 }
      }, "ao-points");
    }
    map.setPaintProperty("ao-style-heatmap", "heatmap-color", ["interpolate", ["linear"], ["heatmap-density"],
      0, "rgba(0,0,0,0)", 0.25, controls.start.value, 1, controls.end.value]);
    map.setPaintProperty("ao-style-heatmap", "heatmap-opacity", Number(controls.opacity.value));
    map.setPaintProperty("ao-style-heatmap", "heatmap-radius", Number(controls.size.value) * 4);
    map.setLayoutProperty("ao-style-heatmap", "visibility", "visible");
    map.setLayoutProperty("ao-points", "visibility", "none");
    legendItem(legend, controls.start.value, "Lower concentration");
    legendItem(legend, controls.end.value, "Higher concentration");
  }

  function apply(session) {
    const c = session.controls, kind = session.kind, map = session.map;
    if (!map.getLayer(layerIds[kind])) return;
    resetLayer(session, kind);
    const legend = session.legend;
    legend.replaceChildren();
    legend.appendChild(node("strong", "", layerLabels[kind] + " · returned features only"));
    if (kind === "areas") map.setPaintProperty("ao-areas", "fill-opacity", Number(c.opacity.value));
    else if (kind === "lines") {
      map.setPaintProperty("ao-lines", "line-opacity", Number(c.opacity.value));
      map.setPaintProperty("ao-lines", "line-width", Number(c.size.value));
    } else {
      map.setPaintProperty("ao-points", "circle-opacity", Number(c.opacity.value));
      map.setPaintProperty("ao-points", "circle-radius", Number(c.size.value));
    }
    const mode = c.mode.value;
    const field = c.field.value;
    const features = session.features.filter(function (f) { return typeOf(f) === kind; });
    if (mode === "heatmap" && kind === "points") heatmap(session, c, legend);
    else if (mode === "graduated" && field && numericStyle(session, features, field, c, legend)) {}
    else if (mode === "category" && field && categoryStyle(session, features, field, c, legend)) {}
    else {
      const paint = kind === "areas" ? "fill-color" : kind === "lines" ? "line-color" : "circle-color";
      map.setPaintProperty(layerIds[kind], paint, c.color.value);
      legendItem(legend, c.color.value, "All " + layerLabels[kind].toLowerCase());
    }
    c.field.parentElement.hidden = mode === "single" || mode === "heatmap";
    c.color.parentElement.hidden = mode !== "single";
    c.palette.parentElement.hidden = mode === "single";
    c.start.parentElement.hidden = mode === "single" || (mode === "category" && c.palette.value === "distinct");
    c.end.parentElement.hidden = mode === "single" || (mode === "category" && c.palette.value === "distinct");
    c.classes.parentElement.hidden = mode !== "graduated";
    c.method.parentElement.hidden = mode !== "graduated";
    c.size.parentElement.hidden = kind === "areas";
  }

  function updateFields(session) {
    const c = session.controls;
    const visible = session.features.filter(function (f) { return typeOf(f) === session.kind; });
    const available = fields(visible).filter(function (f) { return c.mode.value !== "graduated" || f.numeric; });
    const previous = c.field.value;
    c.field.replaceChildren();
    available.forEach(function (item) {
      const option = node("option", "", item.name); option.value = item.name;
      c.field.appendChild(option);
    });
    if (available.some(function (f) { return f.name === previous; })) c.field.value = previous;
    c.field.disabled = !available.length;
    if (!available.length && (c.mode.value === "graduated" || c.mode.value === "category")) c.mode.value = "single";
  }

  function setup(event) {
    const detail = event.detail || {}, map = detail.map, block = detail.block;
    if (!map || !block || !detail.geojson || sessions.has(block)) return;
    const features = detail.geojson.features || [];
    const kinds = ["areas", "lines", "points"].filter(function (kind) {
      return features.some(function (f) { return typeOf(f) === kind; });
    });
    if (!kinds.length) return;
    const toolbar = block.querySelector(".ask-oracle-map-toolbar");
    if (!toolbar) return;
    const toggle = node("button", "t-Button t-Button--small aoms-toggle", "Style map");
    toggle.type = "button"; toggle.setAttribute("aria-expanded", "false");
    toolbar.appendChild(toggle);
    const panel = node("section", "aoms-panel"); panel.hidden = true;
    panel.setAttribute("aria-label", "Map layer styling");
    const grid = node("div", "aoms-grid"); panel.appendChild(grid);
    const c = {};
    c.layer = labeledSelect(grid, "Layer", kinds.map(function (kind) { return [kind, layerLabels[kind]]; }));
    c.mode = labeledSelect(grid, "Style", [["single", "Single colour"], ["graduated", "Graduated colours"], ["category", "Categories"], ["heatmap", "Point heatmap"]]);
    c.field = labeledSelect(grid, "Attribute", []);
    c.color = labeledInput(grid, "Colour", "color", defaults[kinds[0]].color);
    c.palette = labeledSelect(grid, "Palette", [["distinct", "Distinct"]].concat(Object.keys(palettes).map(function (key) { return [key, key]; }), [["custom", "Custom"]]));
    c.start = labeledInput(grid, "Low colour", "color", palettes.Blues[0]);
    c.end = labeledInput(grid, "High colour", "color", palettes.Blues[1]);
    c.classes = labeledSelect(grid, "Classes", [3, 4, 5, 6, 7].map(function (n) { return [String(n), String(n)]; })); c.classes.value = "5";
    c.method = labeledSelect(grid, "Breaks", [["quantile", "Quantile"], ["equal", "Equal interval"]]);
    c.opacity = labeledInput(grid, "Opacity", "range", defaults[kinds[0]].opacity, 0.1, 1, 0.05);
    c.size = labeledInput(grid, "Point size / line width", "range", defaults[kinds[0]].size, 1, 20, 1);
    const reset = node("button", "t-Button t-Button--small", "Reset selected layer"); reset.type = "button";
    panel.appendChild(reset);
    const legend = node("div", "aoms-legend"); panel.appendChild(legend);
    toolbar.insertAdjacentElement("afterend", panel);
    const session = { map: map, block: block, features: features, kind: kinds[0], controls: c, legend: legend };
    sessions.set(block, session);
    toggle.addEventListener("click", function () {
      panel.hidden = !panel.hidden;
      toggle.setAttribute("aria-expanded", String(!panel.hidden));
    });
    function modes() {
      Array.from(c.mode.options).forEach(function (option) {
        option.disabled = (option.value === "heatmap" && session.kind !== "points") ||
          (option.value === "graduated" && !fields(features.filter(function (f) { return typeOf(f) === session.kind; })).some(function (f) { return f.numeric; }));
      });
      if (c.mode.selectedOptions[0] && c.mode.selectedOptions[0].disabled) c.mode.value = "single";
    }
    c.layer.addEventListener("change", function () {
      session.kind = c.layer.value;
      const base = defaults[session.kind];
      c.mode.value = "single"; c.color.value = base.color;
      c.opacity.value = String(base.opacity); c.size.value = String(base.size);
      modes(); updateFields(session); apply(session);
    });
    c.mode.addEventListener("change", function () {
      c.palette.value = c.mode.value === "category" ? "distinct" : "Blues";
      c.start.value = palettes.Blues[0]; c.end.value = palettes.Blues[1];
      updateFields(session); apply(session);
    });
    c.palette.addEventListener("change", function () {
      if (palettes[c.palette.value]) {
        c.start.value = palettes[c.palette.value][0]; c.end.value = palettes[c.palette.value][1];
      }
      apply(session);
    });
    [c.field, c.color, c.start, c.end, c.classes, c.method, c.opacity, c.size].forEach(function (input) {
      input.addEventListener("input", function () {
        if (input === c.start || input === c.end) c.palette.value = "custom";
        apply(session);
      });
    });
    reset.addEventListener("click", function () {
      c.mode.value = "single";
      c.color.value = defaults[session.kind].color;
      c.opacity.value = String(defaults[session.kind].opacity);
      c.size.value = String(defaults[session.kind].size);
      resetLayer(session, session.kind); updateFields(session); apply(session);
    });
    modes(); updateFields(session); apply(session);
  }

  const css = node("style"); css.id = "ask-oracle-map-styling-css";
  css.textContent = ".aoms-toggle{margin-left:auto!important}.aoms-panel{margin:0 10px 10px;padding:12px;border:1px solid #d7e1e9;border-radius:8px;background:#f8fafc}.aoms-panel[hidden]{display:none!important}.aoms-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px;margin-bottom:12px}.aoms-field{display:flex;flex-direction:column;gap:4px;font-size:12px;font-weight:600;color:#31495b}.aoms-field[hidden]{display:none!important}.aoms-field select,.aoms-field input{width:100%;min-height:32px;border:1px solid #9cabb7;border-radius:4px;background:#fff;color:#172b3a}.aoms-field input[type=color]{padding:2px}.aoms-legend{display:flex;flex-wrap:wrap;gap:8px 16px;margin-top:10px;font-size:12px}.aoms-legend strong{flex-basis:100%}.aoms-legend-row{display:inline-flex;align-items:center;gap:5px}.aoms-swatch{width:16px;height:16px;border:1px solid #80909d;border-radius:3px;flex:none}.aoms-panel :focus-visible{outline:3px solid #226ea0;outline-offset:2px}";
  document.head.appendChild(css);
  document.addEventListener("ask-oracle-map-ready", setup);
  window.askOracleMapStyling = { version: "1.0.0" };
})();
