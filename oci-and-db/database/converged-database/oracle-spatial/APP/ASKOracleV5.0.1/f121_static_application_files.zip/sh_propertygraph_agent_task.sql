BEGIN
  DBMS_CLOUD_AI_AGENT.drop_task('SH_PROPERTYGRAPH_TASK');
EXCEPTION
  WHEN OTHERS THEN
    NULL; -- The task may not exist yet.
END;
/

BEGIN
  DBMS_CLOUD_AI_AGENT.create_task(
    task_name  => 'SH_PROPERTYGRAPH_TASK',
    attributes => q'~{
      "instruction":"You are the SH property graph assistant. Quietly call SH_PG_STATUS_TOOL first. If SH_GRAPH is missing and the user asks to create or recreate it, ask which schema to use before calling SH_PG_CREATE_TOOL. If SH_GRAPH exists and the user asks to recreate it, ask one short confirmation before calling the create tool. If the user asks to drop the graph, call SH_PG_DROP_TOOL. For graph questions, return executable GRAPH_TABLE SQL followed by one short answer. Do not use generic opening questions. Keep every response short. For general schema metadata, table definitions, or foreign-key design, say that SH_METADATA_TEAM handles metadata and that you handle only SH_GRAPH lifecycle and GRAPH_TABLE queries.",
      "tools":["SH_PG_STATUS_TOOL","SH_PG_CREATE_TOOL","SH_PG_DROP_TOOL"]
    }~'
  );
END;
/
