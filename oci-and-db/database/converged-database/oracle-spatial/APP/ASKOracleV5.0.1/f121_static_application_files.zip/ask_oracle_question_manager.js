/* AskOracle question manager v1.0.0 -- optional standalone component.
 * Upload as a Static Application File and append this URL after existing JS:
 *   #APP_FILES#ask_oracle_question_manager.js
 * Requires the owned DELETE_PROMPT.sql callback for database deletion.
 * No changes to other JS, no language/keyword routing, no profile/user names.
 * Supports both saved report bubbles and dynamically appended questions.
 * Saved questions: delete the question AND saved answer, then remove UI.
 * prompt-local-* entries: remove exact browser storage entry + question only.
 * An unresolved local ID is not proof that a database request never saved:
 * confirmation explicitly distinguishes browser deletion from DB deletion.
 * Local analysis results/maps/drawings remain untouched.
 * Cached entries are removed by exact known ID only, NEVER by question text.
 * Legacy cache entries lacking a known saved/local ID link are not guessed.
 * This does not add chat deletion commands, editing, or drawing/database DML.
 */
(function (window, document) {
  'use strict';
  if (window.askOracleQuestionManager) return;

  const selector = '.chat-message.user-message';
  const buttonClass = 'aoqm-delete';
  const origins = new WeakMap();
  const pending = new Set();
  let stopped = false, queued = false;

  function root() { return document.getElementById('PROMPTS'); }
  function item(name) {
    try { return String(window.apex?.item(name)?.getValue() || ''); }
    catch (_) { return String(document.getElementById(name)?.value || ''); }
  }
  function context() {
    return JSON.stringify([window.apex?.env?.APP_ID || item('pFlowId'),
      window.apex?.env?.APP_SESSION || item('pInstance'), item('P1_CONV_ID')]);
  }
  function busy() {
    // Core clears its prompt flag before GET_LATEST_CONV_ROW finishes. Include
    // outstanding APEX/jQuery Ajax so a local ID cannot be removed mid-remap.
    return Boolean(window.promptRequestInFlight || window.forceRunButtonStopMode ||
      window.apex?.jQuery?.active || window.jQuery?.active);
  }
  function enabled() {
    // Respect the existing app's display policy; actual permission is in SQL.
    try {
      return typeof window.isAskOracleDeletePromptButtonEnabled === 'function' &&
        window.isAskOracleDeletePromptButtonEnabled();
    } catch (_) { return false; }
  }
  function target(message) {
    if (!message || !root()?.contains(message)) return null;
    const anchor = message.id?.startsWith('prompt-') ? message :
      message.querySelector('.message-bubble[id^="prompt-"]');
    if (!anchor) return null;
    const id = anchor.id;
    // Identifier validation only, not question interpretation.
    if (!/^prompt-[A-Za-z0-9_-]{1,128}$/.test(id)) return null;
    const local = id.startsWith('prompt-local-');
    if (local && !origins.has(anchor)) origins.set(anchor, id);
    return { anchor, message, id, local, promptId: id.slice(7),
      localId: origins.get(anchor) || (local ? id : null) };
  }
  function notify(text, error) {
    const host = root();
    if (!host) return;
    let status = host.querySelector('.aoqm-status');
    if (!status) {
      status = document.createElement('div');
      status.className = 'aoqm-status';
      host.prepend(status);
    }
    status.setAttribute('role', error ? 'alert' : 'status');
    status.classList.toggle('aoqm-error', Boolean(error));
    status.textContent = text; // Never render a question/server message as HTML.
  }
  async function confirm(text) {
    if (typeof window.showAppConfirmDialog === 'function') {
      return window.showAppConfirmDialog(text,
        { title: 'Delete question', confirmLabel: 'Delete', cancelLabel: 'Cancel' });
    }
    if (window.apex?.message?.confirm) {
      return new Promise(resolve => window.apex.message.confirm(text, resolve));
    }
    return window.confirm(text);
  }
  function removeCache(info) {
    const raw = window.localStorage.getItem('chat_prompts');
    if (raw === null) return;
    const entries = JSON.parse(raw);
    if (!Array.isArray(entries)) throw new Error('Browser question storage has an unexpected format.');
    const ids = new Set([info.id, info.localId].filter(Boolean));
    const kept = entries.filter(entry => !entry || !ids.has(entry.id));
    if (kept.length !== entries.length) {
      window.localStorage.setItem('chat_prompts', JSON.stringify(kept));
    }
  }
  function removeLocal(info) {
    // Storage must succeed first, otherwise do not merely hide the question.
    removeCache(info);
    const previous = info.message.previousElementSibling;
    if (previous?.getAttribute('aria-hidden') === 'true' &&
        previous.style.height === '9px') previous.remove();
    document.getElementById('loading-indicator-' + info.id)?.remove();
    info.message.remove();
    if (window.pendingPrompts) delete window.pendingPrompts[info.id];
  }
  function removeSaved(info, host) {
    // Reuse the existing exact-ID cleanup, without overriding it. It removes
    // the prompt's response/charts/footer as well. Map drawings are not edited.
    if (typeof window.removeDeletedPromptFromBody !== 'function') {
      throw new Error('Question deleted in the database. Reload to update the display.');
    }
    const helper = window.removeDeletedPromptFromBody;
    helper(info.promptId, info.message);
    // Report templates put the ID on the bubble, not the outer user-message.
    if (host.contains(info.message)) info.message.remove();
    if (typeof window.loadPromptHistory === 'function') window.loadPromptHistory();
  }
  function deleteSaved(info, conversationId) {
    return new Promise((resolve, reject) => {
      if (!window.apex?.server?.process) {
        reject(new Error('APEX is not ready. Reload the application.')); return;
      }
      window.apex.server.process('DELETE_PROMPT', {
        x01: info.promptId, x02: conversationId
      }, {
        dataType: 'json',
        success: data => {
          if (data?.status !== 'success') {
            reject(new Error(data?.message || 'Deletion failed. The question was not removed.'));
          } else if (String(data.deleted_id) !== info.promptId ||
                     String(data.conversation_id) !== conversationId) {
            reject(new Error('Deletion response could not be verified. Reload the conversation.'));
          } else resolve(data);
        },
        error: () => reject(new Error('Deletion could not be confirmed. Reload before retrying.'))
      });
    });
  }
  async function onClick(event) {
    const button = event.target.closest?.('.' + buttonClass);
    if (!button || !root()?.contains(button)) return;
    event.preventDefault();
    event.stopPropagation();
    const info = target(button.closest(selector));
    if (!info || stopped || !enabled() || pending.has(info.anchor)) return;
    if (busy()) { notify('Wait for the current question to finish before deleting.', true); return; }
    const host = root(), key = context(), conversationId = item('P1_CONV_ID');
    if (!info.local && !conversationId) {
      notify('Open the saved conversation before deleting this question.', true); return;
    }
    pending.add(info.anchor);
    button.disabled = true;
    try {
      const message = info.local ?
        'Permanently delete this local question from this browser? Maps and drawings stay. ' +
        'Any separately saved database copy must be deleted from its saved conversation.' :
        'Permanently delete this question and its saved answer? This cannot be undone.';
      if (!await confirm(message)) return;
      const current = target(info.message);
      if (stopped || !enabled() || busy() || key !== context() || host !== root() ||
          !current || current.id !== info.id || current.anchor !== info.anchor) {
        throw new Error('The conversation or question changed. Please try again.');
      }
      if (info.local) {
        removeLocal(info);
        notify('Local question deleted from this browser.');
      } else {
        await deleteSaved(info, conversationId);
        let cacheWarning = false;
        try { removeCache(info); } catch (_) { cacheWarning = true; }
        // A navigation/refresh while Ajax is pending must not delete new DOM.
        if (stopped || key !== context() || host !== root() || !host.contains(info.anchor)) return;
        removeSaved(info, host);
        notify(cacheWarning ?
          'Question deleted from the database, but its browser cache could not be cleared.' :
          'Question and saved answer deleted.', cacheWarning);
      }
    } catch (error) {
      if (!stopped && key === context() && host === root()) {
        notify(error?.message || 'Deletion failed.', true);
      }
    } finally {
      pending.delete(info.anchor);
      schedule();
    }
  }
  function scan() {
    if (stopped) return;
    const host = root();
    if (!host) return;
    const allowed = enabled(), waiting = busy();
    host.querySelectorAll(selector).forEach(message => {
      const info = target(message);
      let button = message.querySelector('.' + buttonClass);
      if (!info || !allowed) { button?.remove(); return; }
      if (!button) {
        button = document.createElement('button');
        button.type = 'button';
        button.className = buttonClass;
        button.setAttribute('aria-label', 'Delete question');
        const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        icon.setAttribute('viewBox', '0 0 24 24');
        icon.setAttribute('aria-hidden', 'true');
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', 'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7');
        icon.append(path); button.append(icon); message.append(button);
      }
      button.disabled = waiting || pending.has(info.anchor);
      button.title = waiting ? 'Wait for the current question to finish' :
        info.local ? 'Delete local question from this browser' : 'Delete question and saved answer';
    });
  }
  function schedule() {
    if (queued || stopped) return;
    queued = true;
    queueMicrotask(() => { queued = false; scan(); });
  }
  const style = document.createElement('style');
  style.textContent = `
    #PROMPTS .aoqm-delete {display:inline-flex;align-items:center;justify-content:center;
      flex:0 0 32px;width:32px;height:32px;margin-inline-start:6px;padding:6px;
      align-self:center;background:transparent;border:1px solid transparent;
      border-radius:5px;color:inherit;cursor:pointer;vertical-align:middle;}
    #PROMPTS .aoqm-delete svg {width:18px;height:18px;fill:none;stroke:currentColor;
      stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;pointer-events:none;}
    #PROMPTS .aoqm-delete:hover {background:#fff1f0;color:#a62020;border-color:#dfb4b4;}
    #PROMPTS .aoqm-delete:focus-visible {outline:2px solid #2563eb;outline-offset:2px;}
    #PROMPTS .aoqm-delete:disabled {opacity:.4;cursor:wait;}
    #PROMPTS .aoqm-status {padding:8px 12px;margin:8px 0;border:1px solid #bdcfbd;
      border-radius:5px;background:#f4faf4;color:#234023;font-weight:normal;}
    #PROMPTS .aoqm-status.aoqm-error {background:#fff4f4;color:#8a2020;border-color:#dfb4b4;}
  `;
  (document.head || document.documentElement).append(style);
  const observer = new MutationObserver(records => {
    let relevant = false;
    const host = root();
    for (const record of records) {
      if (record.type === 'attributes' && record.oldValue?.startsWith('prompt-local-')) {
        origins.set(record.target, record.oldValue);
      }
      if (host && (host.contains(record.target) || record.target === host.parentElement)) relevant = true;
    }
    if (relevant) schedule();
  });
  observer.observe(document.documentElement,
    { subtree: true, childList: true, attributes: true, attributeFilter: ['id'], attributeOldValue: true });
  document.addEventListener('click', onClick);
  // Supports delayed execute_page_load.js and APEX region replacement without
  // overriding functions or installing duplicate event handlers.
  const timer = window.setInterval(scan, 750);
  window.askOracleQuestionManager = {
    version: '1.0.0', refresh: scan,
    destroy() {
      stopped = true;
      observer.disconnect(); window.clearInterval(timer);
      document.removeEventListener('click', onClick);
      root()?.querySelectorAll('.aoqm-delete, .aoqm-status').forEach(node => node.remove());
      style.remove();
      delete window.askOracleQuestionManager;
    }
  };
  scan();
})(window, document);
