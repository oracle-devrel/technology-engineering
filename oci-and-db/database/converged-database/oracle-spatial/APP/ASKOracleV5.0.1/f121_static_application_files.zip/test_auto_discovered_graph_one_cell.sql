SET SERVEROUTPUT ON SIZE UNLIMITED;

DECLARE
  l_schema       VARCHAR2(128) := 'SH';
  l_graph        VARCHAR2(128) := 'SH_GRAPH';
  l_vertex_sql   CLOB := 'VERTEX TABLES (';
  l_edge_sql     CLOB := 'EDGE TABLES (';
  l_sql          CLOB;
  l_first_vertex BOOLEAN := TRUE;
  l_first_edge   BOOLEAN := TRUE;
  l_vertex_count PLS_INTEGER := 0;
  l_edge_count   PLS_INTEGER := 0;

  FUNCTION qi(p_name IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN '"' || REPLACE(p_name, '"', '""') || '"';
  END;

  FUNCTION qualified_table(p_table_name IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN qi(l_schema) || '.' || qi(p_table_name);
  END;

  FUNCTION key_columns(p_owner IN VARCHAR2, p_constraint IN VARCHAR2)
    RETURN CLOB
  IS
    l_result CLOB;
    l_first  BOOLEAN := TRUE;
  BEGIN
    FOR c IN (
      SELECT column_name
      FROM all_cons_columns
      WHERE owner = p_owner
        AND constraint_name = p_constraint
      ORDER BY position
    ) LOOP
      IF NOT l_first THEN l_result := l_result || ', '; END IF;
      l_result := l_result || qi(c.column_name);
      l_first := FALSE;
    END LOOP;
    RETURN l_result;
  END;
BEGIN
  -- Change only these two values if you want a different schema or graph name.
  l_schema := UPPER(DBMS_ASSERT.SCHEMA_NAME(l_schema));
  l_graph  := DBMS_ASSERT.SIMPLE_SQL_NAME(l_graph);

  FOR t IN (
    SELECT table_name, constraint_name
    FROM all_constraints
    WHERE owner = l_schema
      AND constraint_type = 'P'
      AND status = 'ENABLED'
    ORDER BY table_name
  ) LOOP
    IF NOT l_first_vertex THEN l_vertex_sql := l_vertex_sql || ', '; END IF;
    l_vertex_sql := l_vertex_sql || qualified_table(t.table_name)
      || ' KEY (' || key_columns(l_schema, t.constraint_name) || ')';
    l_first_vertex := FALSE;
    l_vertex_count := l_vertex_count + 1;
  END LOOP;

  IF l_vertex_count = 0 THEN
    RAISE_APPLICATION_ERROR(-20001, 'No enabled primary-key tables in ' || l_schema);
  END IF;
  l_vertex_sql := l_vertex_sql || ')';

  FOR fk IN (
    SELECT c.table_name AS child_table,
           c.constraint_name AS fk_name,
           child_pk.constraint_name AS child_pk_name,
           parent.table_name AS parent_table,
           parent.owner AS parent_owner,
           parent.constraint_name AS parent_key_name
    FROM all_constraints c
    JOIN all_constraints child_pk
      ON child_pk.owner = c.owner
     AND child_pk.table_name = c.table_name
     AND child_pk.constraint_type = 'P'
     AND child_pk.status = 'ENABLED'
    JOIN all_constraints parent
      ON parent.owner = c.r_owner
     AND parent.constraint_name = c.r_constraint_name
    JOIN all_constraints parent_pk
      ON parent_pk.owner = parent.owner
     AND parent_pk.table_name = parent.table_name
     AND parent_pk.constraint_type = 'P'
     AND parent_pk.status = 'ENABLED'
    WHERE c.owner = l_schema
      AND c.constraint_type = 'R'
      AND c.status = 'ENABLED'
      AND parent.owner = l_schema
    ORDER BY c.table_name, c.constraint_name
  ) LOOP
    IF NOT l_first_edge THEN l_edge_sql := l_edge_sql || ', '; END IF;
    l_edge_count := l_edge_count + 1;
    l_edge_sql := l_edge_sql
      || qualified_table(fk.child_table) || ' AS ' || qi('E_' || l_edge_count)
      || ' KEY (' || key_columns(l_schema, fk.child_pk_name) || ')'
      || ' SOURCE KEY (' || key_columns(l_schema, fk.child_pk_name) || ')'
      || ' REFERENCES ' || qi(fk.child_table)
      || ' (' || key_columns(l_schema, fk.child_pk_name) || ')'
      || ' DESTINATION KEY (' || key_columns(l_schema, fk.fk_name) || ')'
      || ' REFERENCES ' || qi(fk.parent_table)
      || ' (' || key_columns(fk.parent_owner, fk.parent_key_name) || ')';
    l_first_edge := FALSE;
  END LOOP;

  l_sql := 'CREATE OR REPLACE PROPERTY GRAPH ' || qi(l_schema) || '.' || qi(l_graph)
    || ' ' || l_vertex_sql;
  IF l_edge_count > 0 THEN l_sql := l_sql || ' ' || l_edge_sql || ')'; END IF;
  l_sql := l_sql || ' OPTIONS (TRUSTED MODE, ALLOW MIXED PROPERTY TYPES)';

  DBMS_OUTPUT.PUT_LINE('Creating ' || l_schema || '.' || l_graph
    || ' with ' || l_vertex_count || ' vertex tables and ' || l_edge_count || ' FK edges.');
  EXECUTE IMMEDIATE l_sql;
  DBMS_OUTPUT.PUT_LINE('SUCCESS');
END;
/

-- Validation queries: run immediately after the block in the same worksheet.
SELECT graph_name
FROM user_property_graphs
WHERE graph_name = 'SH_GRAPH';

SELECT COUNT(*) AS vertex_count
FROM GRAPH_TABLE (
  SH_GRAPH MATCH (n)
  COLUMNS (VERTEX_ID(n) AS vertex_id)
);

SELECT *
FROM GRAPH_TABLE (
  SH_GRAPH MATCH (a)-[e]->(b)
  COLUMNS (
    VERTEX_ID(a) AS source_id,
    EDGE_ID(e) AS edge_id,
    VERTEX_ID(b) AS destination_id
  )
)
FETCH FIRST 20 ROWS ONLY;
