define AWR_MINER_VER = 26.9.1

-- AWR PDB Miner customer entry point.
-- Usage:
--   @awr_pdb_miner.sql
--
-- This matches awr_miner.sql customer UX: no DBID or snapshot arguments.
-- Self-contained PDB metrics extract. No helper SQL file required.
--
-- SQL*Plus is the supported client, as it is for awr_miner.sql and
-- awr_miner_lite.sql. Customers run these scripts against their own databases, so a
-- diagnostic in the output costs us their confidence even when it is cosmetic: this
-- script must reach the end with nothing in the spool but the sections themselves.
--
-- occa/awr_miner_parse.py reads those sections as fixed-width tables, so the
-- formatting block below mirrors awr_miner.sql exactly. No REPHEADER/REPFOOTER: the
-- ~~BEGIN-X~~ / ~~END-X~~ markers are emitted with "select ... from dual" instead.
--
-- Nothing here is SQLcl-specific. "set sqlformat default" used to appear twice below
-- to pin SQLcl to the SQL*Plus-style renderer, but it is not a SQL*Plus SET option,
-- so every SQL*Plus customer paid for it with two SP2-0158 lines. Running this under
-- SQLcl is consequently unsupported -- SQLcl underlines table headings with
-- underscores rather than dashes, which the fixed-width parser does not read. If we
-- ever need SQLcl, that is a deliberate change with its own ticket.

set verify off
set echo off
set feedback off
set heading on
set pagesize 50000
set linesize 32767
set trimspool on
set tab off
set termout on
set timing off
set wrap off

set define '&'
set concat '~'
set colsep " "
set underline '-'
set numformat ""
set numwidth 10


alter session set nls_language = American;
alter session set nls_territory = America;
alter session set nls_calendar = Gregorian;
alter session set nls_date_language = American;
alter session set nls_date_format = 'YYYY-MM-DD HH24:MI:SS';
alter session set nls_timestamp_format = 'YYYY-MM-DD HH24:MI:SS';
alter session set nls_numeric_characters = ".,";
alter session set nls_length_semantics = BYTE;

prompt Starting PDB Extract Script!

-- ============================================================================
-- Environment gate (OCCA-1223)
-- ----------------------------------------------------------------------------
-- Customers were force-running this script in environments it cannot collect
-- from, then sending us the result: PDBs with AWR_PDB_AUTOFLUSH_ENABLED = FALSE,
-- and non-CDBs. Those runs produce a file whose history sections are absent
-- entirely -- the section markers below are emitted as
-- "select ... where exists (...)", so a source with no rows leaves no marker at
-- all and the section vanishes silently. No SNAP-HISTORY means no plots, which
-- is exactly how these arrive: a collection that looks complete and is not.
--
-- The gate therefore runs BEFORE the spool is opened, so a refused run leaves no
-- .out file behind and there is nothing for the customer to send.
--
-- Deliberate consequence, decided with the field owner: this also refuses
-- Amazon RDS, where sessions can only ever connect to a PDB and autoflush is
-- not under the customer's control. Such a run can still return PDB-METRICS
-- rows, but without local snapshot history it cannot be plotted, so it is not
-- accepted. If RDS support is reinstated, relax this gate, not the reporting.
whenever sqlerror exit sql.sqlcode rollback
set serveroutput on size unlimited
declare
    l_is_cdb     varchar2(3)  := 'NO';
    l_con_id     number       := 0;
    l_autoflush  varchar2(64) := 'UNKNOWN';
    l_container  varchar2(128);
begin
    begin
        execute immediate 'select cdb from v$database' into l_is_cdb;
    exception
        -- v$database.cdb does not exist before 12.1; such a database is a
        -- non-CDB by definition and is refused below.
        when others then l_is_cdb := 'NO';
    end;

    l_con_id := to_number(sys_context('USERENV', 'CON_ID'));
    begin
        select sys_context('USERENV', 'CON_NAME') into l_container from dual;
    exception when others then l_container := 'UNKNOWN'; end;

    -- Non-CDB is reported, not refused. The only hard stop in this script is
    -- AWR_PDB_AUTOFLUSH_ENABLED, and only for an in-PDB run: that is the one
    -- condition that guarantees an unusable collection.
    if l_is_cdb != 'YES' then
        dbms_output.put_line('WARNING: this is a non-CDB database. AWR PDB Miner collects per-PDB');
        dbms_output.put_line('         history and has little to collect here; awr_miner.sql is the');
        dbms_output.put_line('         right script for a non-CDB. Continuing.');
    end if;

    -- CON_ID 0/1 is CDB$ROOT, where AWR always flushes and the parameter has no
    -- effect. The requirement applies to an in-PDB run.
    if l_con_id > 1 then
        begin
            select upper(value) into l_autoflush
            from v$parameter
            where name = 'awr_pdb_autoflush_enabled';
        exception when others then l_autoflush := 'UNKNOWN'; end;

        -- The parameter did not exist before 12.2. Telling a 12.1 DBA to set it
        -- would send them looking for something that is not there, so say what
        -- is actually wrong: this script needs a release that has PDB-level AWR.
        -- Same stop, accurate wording: before 12.2 the parameter does not exist,
        -- so telling the DBA to set it would send them after something absent.
        if l_autoflush = 'UNKNOWN' then
            dbms_output.put_line('ERROR: AWR_PDB_AUTOFLUSH_ENABLED does not exist on this release.');
            dbms_output.put_line('       The parameter, and PDB-level AWR with it, was introduced in');
            dbms_output.put_line('       Oracle 12.2. AWR PDB Miner cannot collect from this container.');
            dbms_output.put_line('       Collect from CDB$ROOT with awr_miner.sql instead.');
            dbms_output.put_line('       No collection file has been written.');
            raise_application_error(-20012,
                'AWR PDB Miner requires Oracle 12.2 or later. Script execution aborted; no output file was written.');
        end if;

        if l_autoflush != 'TRUE' then
            dbms_output.put_line('ERROR: AWR_PDB_AUTOFLUSH_ENABLED is ' || l_autoflush ||
                                 ' in container ' || l_container || '.');
            dbms_output.put_line('       Without it this PDB captures no local AWR snapshots, so the');
            dbms_output.put_line('       collection would contain no snapshot history and could not be');
            dbms_output.put_line('       plotted or sized.');
            dbms_output.put_line('       Ask your DBA to run, as SYSDBA in this PDB:');
            dbms_output.put_line('           alter system set awr_pdb_autoflush_enabled = true scope = both;');
            dbms_output.put_line('       then allow at least one AWR interval to elapse and re-run.');
            dbms_output.put_line('       No collection file has been written.');
            raise_application_error(-20011,
                'AWR_PDB_AUTOFLUSH_ENABLED must be TRUE. Script execution aborted; no output file was written.');
        end if;
    end if;

    dbms_output.put_line('Environment check passed: CDB=' || l_is_cdb ||
                         ', container=' || l_container ||
                         ', con_id=' || l_con_id ||
                         ', awr_pdb_autoflush_enabled=' || l_autoflush || '.');
end;
/
whenever sqlerror continue
set serveroutput off


column dbid_col new_value DBID noprint
column dbname_col new_value DBNAME noprint
column snap_min_col new_value SNAP_ID_MIN noprint
column snap_max_col new_value SNAP_ID_MAX noprint

with current_container as (
  select dbid, name
  from v$containers
  where con_id = to_number(sys_context('USERENV', 'CON_ID'))
),
database_identity as (
  select coalesce(max(c.dbid), max(d.dbid)) dbid,
         coalesce(max(c.name), max(d.name)) name
  from v$database d
  left join current_container c on 1 = 1
),
snapshot_dbids as (
  select dbid, min(snap_id) snap_min, max(snap_id) snap_max
  from dba_hist_snapshot
  group by dbid
),
selected_snapshot as (
  select dbid, snap_min, snap_max
  from snapshot_dbids
  where dbid = (select dbid from database_identity)
  union all
  select dbid, snap_min, snap_max
  from snapshot_dbids
  where (select count(*) from snapshot_dbids) = 1
    and not exists (
      select 1
      from snapshot_dbids
      where dbid = (select dbid from database_identity)
    )
)
select coalesce(max(ss.dbid), max(di.dbid)) dbid_col,
       max(di.name) dbname_col,
       nvl(min(ss.snap_min), -1) snap_min_col,
       nvl(max(ss.snap_max), -1) snap_max_col
from database_identity di
left join selected_snapshot ss on 1 = 1;

set heading off
select 'WARNING: no local PDB AWR snapshots were found even though AWR_PDB_AUTOFLUSH_ENABLED is TRUE. History sections will be empty; see the .log for which ones. Allow at least one AWR interval to elapse and re-run.'
from dual
where to_number('&SNAP_ID_MIN') < 0
   or to_number('&SNAP_ID_MAX') < 0;
set heading on

column file_name_col new_value SPOOL_FILE_NAME noprint
select 'awr-hist-' || ltrim('&DBID') || '-' || ltrim('&DBNAME') || '-' ||
       ltrim('&SNAP_ID_MIN') || '-' || ltrim('&SNAP_ID_MAX') || '.out' file_name_col
from dual;

column log_file_col new_value LOG_FILE_NAME noprint
select 'awr-hist-' || ltrim('&DBID') || '-' || ltrim('&DBNAME') || '-' ||
       ltrim('&SNAP_ID_MIN') || '-' || ltrim('&SNAP_ID_MAX') || '.log' log_file_col
from dual;

prompt Database ID       : &DBID
prompt Database Name     : &DBNAME
prompt Min Snapshot ID   : &SNAP_ID_MIN
prompt Max Snapshot ID   : &SNAP_ID_MAX
prompt Collection File   : &SPOOL_FILE_NAME

-- AWR PDB Miner metrics section (shared body).
--
-- Source view: DBA_HIST_CON_SYSMETRIC_SUMM (per-container snapshots of
-- V$CON_SYSMETRIC_SUMMARY). Per Oracle "Managing AWR in a Multitenant
-- Environment", DBA_HIST_CON views contain CDB-root AWR data. When they are
-- queried from a PDB, Oracle exposes the subset of root AWR data for that PDB.
-- Therefore this metrics flow does not depend on local PDB snapshots or on
-- AWR_PDB_AUTOFLUSH_ENABLED. This is also the supported access pattern for
-- Amazon RDS, where customer sessions connect to a PDB rather than CDB$ROOT.
-- The DBID and snapshot range printed above still describe optional local PDB
-- history; the metrics section discovers its root-AWR domain from the rows
-- exposed by DBA_HIST_CON_SYSMETRIC_SUMM and keeps DBID/CON_DBID in every join.
--
-- Metric -> column mapping, with the exact V$METRICNAME units. Units matter:
-- IOPS must come from the request-based "... Total IO Requests Per Sec"
-- metrics, NOT the block-based "Physical Reads/Writes Per Sec" metrics, which
-- count blocks and overstate IOPS whenever multiblock I/O occurs. This mirrors
-- awr_miner.sql (the CDB miner) so CDB and PDB sizing stay consistent.
--   CPU Usage Per Sec                        CentiSeconds/Sec -> /100 = cores  -> cpu_per_s
--   Physical Read  Total Bytes Per Sec       Bytes/Sec        -> /1MiB = MB/s  -> read_mb_s
--   Physical Write Total Bytes Per Sec       Bytes/Sec        -> /1MiB = MB/s  -> write_mb_s
--   Physical Read  Total IO Requests Per Sec Requests/Sec     = IOPS           -> read_iops
--   Physical Write Total IO Requests Per Sec Requests/Sec     = IOPS           -> write_iops
--   Physical Reads  Per Sec                  Reads/Sec (blocks, NOT IOPS)      -> read_bks
--   Physical Writes Per Sec                  Writes/Sec (blocks, NOT IOPS)     -> write_bks
--   Redo Generated Per Sec                   Bytes/Sec        -> /1MiB = MB/s  -> redo_mb_s
--   DB Block Changes Per Sec                 Blocks/Sec                        -> db_block_changes_s
--   DB Block Gets Per Sec                    Blocks/Sec (not populated at the
--     container level; derived instead from DBA_HIST_CON_SYSSTAT 'db block gets')
--
-- Workload/activity metrics also live in the container long-duration (60-sec)
-- metric group (same ~158-metric set as instance-level V$SYSMETRIC), so they are
-- collected per PDB too, matching awr_miner.sql:
--   Average Active Sessions -> aas/aas_sd/aas_max   Database Time Per Sec -> db_time/db_time_sd
--   Database Wait Time Ratio -> db_wait_ratio        Database CPU Time Ratio -> db_cpu_ratio
--   Logical Reads Per Sec -> l_reads_s               Executions Per Sec -> exec_s
--   User Commits Per Sec -> commits_s                Hard Parse Count Per Sec -> hard_p_s
--   Logons Per Sec -> logons_s                       Current Logons Count -> logons_total
--   SQL Service Response Time -> sql_res_t_cs        Background Time Per Sec -> bkgd_t_per_s
--   Physical Reads/Writes Direct Per Sec -> read_bks_direct/write_bks_direct
--   Active Parallel/Serial Sessions -> px_sess/se_sess
--   Average Synchronous Single-Block Read Latency -> s_blk_r_lat
--
-- Deliberately left null (NOT per-container in Oracle): host-level os_cpu* and
-- h_cpu_per_s* (whole-host CPU), the RAC global-cache gc_* metrics (instance/
-- cluster scope), and Exadata cell_io_int_mb* (storage-cell scope).


set verify off
set echo off
set feedback off
set heading on
set pagesize 50000
set linesize 32767
set trimspool on
set tab off
set termout on
set timing off
set wrap off

set define '&'
set concat '~'
set colsep " "
set underline '-'
set numformat ""
set numwidth 10


prompt Extracting PDB metrics...

column current_con_id_col new_value CURRENT_CON_ID noprint
select sys_context('USERENV', 'CON_ID') current_con_id_col from dual;

column pdb_db_version_col new_value PDB_DB_VERSION noprint
select to_number(regexp_substr(version, '^[0-9]+(\.[0-9]+)?')) pdb_db_version_col from v$instance;

set heading off
select case
         when to_number('&PDB_DB_VERSION') < 12.2 then
           'PDB metrics skipped: DBA_HIST_CON_SYSMETRIC_SUMM PDB AWR metrics require Oracle 12.2 or newer.'
         when to_number('&CURRENT_CON_ID') = 0 then
           'PDB metrics skipped: the current database is not a CDB/PDB.'
         when '&CURRENT_CON_ID' = '1' then
           'Connected to the CDB root: per-PDB metrics are read from the root AWR (DBA_HIST_CON_SYSMETRIC_SUMM). Oracle captures each PDB''s contribution in the CDB-level snapshots regardless of AWR_PDB_AUTOFLUSH_ENABLED, so collection can proceed.'
         else
           'Connected to a PDB: metrics are read from its CDB-root AWR subset. Local PDB AWR autoflush is not required for this metrics source.'
       end as pdb_metrics_status
from dual;
set heading on

-- Seeded through "column ... new_value" rather than "define".  SQL*Plus caps a
-- define'd substitution variable at 240 characters and rejects anything longer
-- with "string beginning ... is too long. maximum size is 240 characters.",
-- leaving the variable *undefined*.  The cap is client-version dependent -- 19.28
-- enforces it, 23.26 does not -- so a bare define here breaks the extract only for
-- some customers, and the rejection carries no SP2- prefix for a log scan to catch.
-- A column new_value binding is not subject to the cap; the probes below already
-- carry values well over 1000 characters through it.  Keep the column alias at or
-- under 30 bytes: 12.1 and earlier reject a longer identifier with ORA-00972.
column pdb_metrics_src_seed_col new_value PDB_METRICS_SOURCE noprint
select '(select cast(null as number) dbid, cast(null as number) con_dbid, cast(null as number) snap_id, cast(null as number) con_id, cast(null as date) begin_time, cast(null as date) end_time, cast(null as number) instance_number, cast(null as varchar2(128)) metric_name, cast(null as number) average, cast(null as number) maxval, cast(null as number) standard_deviation from dual where 1 = 0)' pdb_metrics_src_seed_col from dual;
define PDB_NAMES_SOURCE = '(select cast(null as number) dbid, cast(null as number) con_dbid, cast(null as number) snap_id, cast(null as number) instance_number, cast(null as number) con_id, cast(null as varchar2(128)) pdb_name from dual where 1 = 0)'
define PDB_BLOCK_GETS_SOURCE = '(select cast(null as number) dbid, cast(null as number) con_dbid, cast(null as number) snap_id, cast(null as number) con_id, cast(null as number) instance_number, cast(null as number) value_per_s from dual where 1 = 0)'
define PDB_MEMORY_SOURCE = '(select cast(null as number) snap_id, cast(null as number) instance_number, cast(null as number) sga, cast(null as number) pga, cast(null as number) total from dual where 1 = 0)'

-- dba_hist_con_sysmetric_summ.dbid is the AWR repository that took the snapshot,
-- not the container the metrics describe (that is con_dbid).  With PDB-level AWR
-- enabled, a session inside the PDB sees two repositories at once: the root's
-- snapshots, which carry con_id rows for this PDB, and the PDB's own.  Each numbers
-- its snapshots from 1 independently, so their snap_ids collide and the same
-- (snap_id, instance_number, con_id) comes back twice with different windows and
-- different values.  Downstream that key is the identity of a metric row, so the
-- collision multiplies rows through the memory and IOPS joins and pairs each
-- value with the other snapshot's timestamp.
--
-- Observed on ORCLPDB (RDS 19c): snap 9 arrived both as 21:07:07-21:08:10 with
-- cpu_per_s 1.859 -- the window the AWR report was run on, DB CPU(s) 1.8 -- and as
-- the root's hourly 20:44-21:01 with cpu_per_s 0.005, which put the load on an
-- idle hour and sized a 2-vCPU database at 7.456 vCPU.
--
-- &DBID and &SNAP_ID_MIN/&SNAP_ID_MAX are the repository this extract declares in
-- its header and its file name, so scoping to them keeps exactly one of the two.
-- This is what PDB_MEMORY_SOURCE below and both history sources already do.
--
-- The &SNAP_ID_MIN < 0 escape keeps the case at the top of this script where the
-- PDB has no local AWR of its own: there is then only the root's repository to
-- read, nothing can collide, and filtering on a snap range of -1..-1 would empty
-- the section instead of scoping it.
column pdb_metrics_source_col new_value PDB_METRICS_SOURCE noprint
select case
         when count(distinct column_name) = 11
              and to_number('&PDB_DB_VERSION') >= 12.2 then
           '(select dbid, con_dbid, snap_id, con_id, begin_time, end_time, instance_number, metric_name, round(average, 1) average, round(maxval, 1) maxval, round(standard_deviation, 1) standard_deviation from dba_hist_con_sysmetric_summ where (to_number(''&SNAP_ID_MIN'') < 0 or (dbid = &DBID and snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX)) and ((to_number(''&CURRENT_CON_ID'') = 1 and con_id > 2) or to_number(''&CURRENT_CON_ID'') > 2) and metric_name in (''CPU Usage Per Sec'', ''Physical Read Total Bytes Per Sec'', ''Physical Write Total Bytes Per Sec'', ''Physical Reads Per Sec'', ''Physical Writes Per Sec'', ''Physical Read Total IO Requests Per Sec'', ''Physical Write Total IO Requests Per Sec'', ''Redo Generated Per Sec'', ''DB Block Gets Per Sec'', ''DB Block Changes Per Sec'', ''Average Active Sessions'', ''Database Time Per Sec'', ''Database Wait Time Ratio'', ''Database CPU Time Ratio'', ''SQL Service Response Time'', ''Background Time Per Sec'', ''Logons Per Sec'', ''Current Logons Count'', ''Executions Per Sec'', ''Hard Parse Count Per Sec'', ''Logical Reads Per Sec'', ''User Commits Per Sec'', ''Physical Reads Direct Per Sec'', ''Physical Writes Direct Per Sec'', ''Active Parallel Sessions'', ''Active Serial Sessions'', ''Average Synchronous Single-Block Read Latency''))'
         else
           '(select cast(null as number) dbid, cast(null as number) con_dbid, cast(null as number) snap_id, cast(null as number) con_id, cast(null as date) begin_time, cast(null as date) end_time, cast(null as number) instance_number, cast(null as varchar2(128)) metric_name, cast(null as number) average, cast(null as number) maxval, cast(null as number) standard_deviation from dual where 1 = 0)'
       end pdb_metrics_source_col
from all_tab_columns
where table_name = 'DBA_HIST_CON_SYSMETRIC_SUMM'
  and column_name in (
    'DBID',
    'CON_DBID',
    'SNAP_ID',
    'CON_ID',
    'BEGIN_TIME',
    'END_TIME',
    'INSTANCE_NUMBER',
    'METRIC_NAME',
    'AVERAGE',
    'MAXVAL',
    'STANDARD_DEVIATION'
  );

column pdb_names_source_col new_value PDB_NAMES_SOURCE noprint
select case
         when count(distinct column_name) = 6
              and to_number('&CURRENT_CON_ID') = 1 then
           '(select distinct dbid, con_dbid, snap_id, instance_number, con_id, pdb_name from dba_hist_pdb_instance where con_id > 2)'
         else
           '(select cast(null as number) dbid, cast(null as number) con_dbid, cast(null as number) snap_id, cast(null as number) instance_number, cast(null as number) con_id, cast(null as varchar2(128)) pdb_name from dual where 1 = 0)'
       end pdb_names_source_col
from all_tab_columns
where table_name = 'DBA_HIST_PDB_INSTANCE'
  and column_name in ('DBID', 'CON_DBID', 'SNAP_ID', 'INSTANCE_NUMBER', 'CON_ID', 'PDB_NAME');

column pdb_block_gets_source_col new_value PDB_BLOCK_GETS_SOURCE noprint
select case
  when count(distinct case when table_name = 'DBA_HIST_CON_SYSSTAT' and column_name in ('DBID','CON_DBID','SNAP_ID','CON_ID','INSTANCE_NUMBER','STAT_NAME','VALUE') then column_name end) = 7
   and to_number('&PDB_DB_VERSION') >= 12.2
   and count(distinct case when table_name = 'DBA_HIST_CON_SYSMETRIC_SUMM' and column_name in ('DBID','CON_DBID','SNAP_ID','CON_ID','INSTANCE_NUMBER','BEGIN_TIME','END_TIME') then column_name end) = 7
  then
    '(select dbid, con_dbid, snap_id, con_id, instance_number, round(avg(value_per_s), 1) value_per_s from (select dbid, con_dbid, snap_id, con_id, instance_number, case when prev_value is not null and value >= prev_value and interval_seconds > 0 then (value - prev_value) / interval_seconds end value_per_s from (select s.dbid, s.con_dbid, s.snap_id, s.con_id, s.instance_number, s.value, lag(s.value) over (partition by s.dbid, s.con_dbid, s.instance_number, s.con_id, s.stat_name order by s.snap_id) prev_value, (cast(mi.end_time as date) - cast(mi.begin_time as date)) * 86400 interval_seconds from dba_hist_con_sysstat s join (select dbid, con_dbid, snap_id, con_id, instance_number, min(begin_time) begin_time, max(end_time) end_time from dba_hist_con_sysmetric_summ group by dbid, con_dbid, snap_id, con_id, instance_number) mi on mi.dbid = s.dbid and mi.con_dbid = s.con_dbid and mi.snap_id = s.snap_id and mi.con_id = s.con_id and mi.instance_number = s.instance_number where ((to_number(''&CURRENT_CON_ID'') = 1 and s.con_id > 2) or to_number(''&CURRENT_CON_ID'') > 2) and lower(s.stat_name) = ''db block gets'')) where value_per_s is not null group by dbid, con_dbid, snap_id, con_id, instance_number)'
  else
    '(select cast(null as number) dbid, cast(null as number) con_dbid, cast(null as number) snap_id, cast(null as number) con_id, cast(null as number) instance_number, cast(null as number) value_per_s from dual where 1 = 0)'
  end pdb_block_gets_source_col
from all_tab_columns
where table_name in ('DBA_HIST_CON_SYSSTAT', 'DBA_HIST_CON_SYSMETRIC_SUMM');

column pdb_memory_source_col new_value PDB_MEMORY_SOURCE noprint
select case
when count(distinct column_name) = 6
and to_number('&PDB_DB_VERSION') >= 12.2
and to_number('&CURRENT_CON_ID') > 2
then
    '(select snap_id, instance_number, round(max(sga_bytes) / 1024 / 1024 / 1024, 3) sga, round(max(pga_bytes) / 1024 / 1024 / 1024, 3) pga, round((max(sga_bytes) + max(pga_bytes)) / 1024 / 1024 / 1024, 3) total from dba_hist_rsrc_pdb_metric where dbid = &DBID and snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX and con_id = to_number(''&CURRENT_CON_ID'') and sga_bytes is not null and pga_bytes is not null group by snap_id, instance_number)'
else
    '(select cast(null as number) snap_id, cast(null as number) instance_number, cast(null as number) sga, cast(null as number) pga, cast(null as number) total from dual where 1 = 0)'
end pdb_memory_source_col
from all_tab_columns
where table_name = 'DBA_HIST_RSRC_PDB_METRIC'
  and column_name in ('SNAP_ID', 'INSTANCE_NUMBER', 'CON_ID', 'SGA_BYTES', 'PGA_BYTES', 'DBID');

spool &SPOOL_FILE_NAME append
-- ============================================================================
-- OS / host sizing (OCCA-1170)
-- ----------------------------------------------------------------------------
-- The CDB miner (awr_miner.sql) reads host CPU/memory from DBA_HIST_OSSTAT
-- filtered by the database DBID. Under a PDB that view is EMPTY: OS statistics
-- are captured only at the CDB level, so DBA_HIST_OSSTAT WHERE dbid=<pdb_dbid>
-- returns no rows. That empty result is the OCCA-1170 root cause -- it drove a
-- downstream fallback that fabricated NUM_CPUS=1 / PHYSICAL_MEMORY_GB=Unreachable.
--
-- Real host facts ARE reachable from inside a PDB via the dynamic performance
-- views, which expose the CDB-root / host values to the container:
--     CPU / memory   -> V$OSSTAT  / GV$OSSTAT    (NUM_CPU*, PHYSICAL_MEMORY_BYTES)
--     platform       -> V$DATABASE / GV$DATABASE (host platform of the CDB)
--     version / host -> V$INSTANCE / GV$INSTANCE  (VERSION_FULL, HOST_NAME)
-- PDB identity (name / dbid) stays from the &DBNAME / &DBID substitutions --
-- V$DATABASE would report the CDB name, which is wrong for DB_NAME / DBID.
--
-- ADB / restricted-access safety: on Autonomous Database some V$/GV$ views are
-- blocked (ORA-00942 / ORA-01031). Every view here is therefore reached through
-- DYNAMIC SQL wrapped in an exception handler (the emit2/emit3 helpers):
--   * a static PL/SQL reference to a missing view fails at COMPILE time
--     (PLS-00201), which -- under the harness's WHENEVER SQLERROR EXIT FAILURE --
--     would abort the whole extract AND lose the section markers. Dynamic SQL
--     defers name resolution to run time, so a blocked view raises a catchable
--     error and we simply omit its rows.
--   * roles ARE enabled inside an anonymous block (invoker's rights), so RDS's
--     SELECT_CATALOG_ROLE grant on the V$ views applies here.
-- The markers, header and dash lines are ALWAYS emitted; only data rows that
-- actually return are printed. Nothing is fabricated -- a genuinely unreachable
-- fact is simply absent, which the plotter then reports honestly.
-- ============================================================================

-- Host name capture toggle (mirrors awr_miner.sql). 'YES' collects host names;
-- set to 'NO' to suppress them for privacy.
define CAPTURE_HOST_NAMES = 'YES'

-- Optional diagnostics for ADB/PDB CPU source detection. Set to 1, Y, y, or TRUE
-- before running the script, or edit this default in a local run copy.
define AWR_PDB_DEBUG = N

prompt ------------------------- BEGIN-OS-INFORMATION
set serveroutput on size unlimited format wrapped

declare
    l_pad_length number := 60;
    l_version    varchar2(200);
    l_instances  number;
    l_n          number;
    l_num_cpus_rows number := 0;
    l_adb_detected boolean := false;

    -- Emit STAT_NAME / STAT_VALUE rows (2-col OS-INFORMATION) from a dynamic
    -- query. Returns the row count so a caller can fall back to another source.
    -- Any error (blocked/missing view) omits the rows rather than aborting.
    function emit2(p_sql in varchar2) return number is
        c      sys_refcursor;
        v_name varchar2(200);
        v_val  varchar2(4000);
        n      number := 0;
    begin
        open c for p_sql;
        loop
            fetch c into v_name, v_val;
            exit when c%notfound;
            dbms_output.put_line(rpad(v_name, l_pad_length) || ' ' || v_val);
            n := n + 1;
        end loop;
        close c;
        return n;
    exception
        when others then
            begin if c%isopen then close c; end if; exception when others then null; end;
            return n;
    end emit2;

    function count_rows(p_sql in varchar2) return number is
        n number := 0;
    begin
        execute immediate 'select count(*) from (' || p_sql || ')' into n;
        return n;
    exception
        when others then return 0;
    end count_rows;

    function is_adb return boolean is
        l_cloud_service varchar2(4000);
        l_cloud_identity varchar2(4000);
    begin
        begin
            l_cloud_service := sys_context('USERENV', 'CLOUD_SERVICE');
            if upper(l_cloud_service) in ('DWCS', 'OLTP', 'JDCS') then
                return true;
            end if;
        exception
            when others then null;
        end;

        -- Missing/blocked CLOUD_IDENTITY is expected on non-ADB platforms such as RDS.
        execute immediate 'select substr(cloud_identity, 1, 4000) from v$pdbs where rownum = 1'
            into l_cloud_identity;
        if l_cloud_identity is null then
            return false;
        end if;
        return instr(upper(l_cloud_identity), 'OCID1.AUTONOMOUSDATABASE.') > 0
            or (
                regexp_like(l_cloud_identity, '"SERVICE"[[:space:]]*:[[:space:]]*"(ATP|ADW)"', 'i')
                and regexp_like(l_cloud_identity, '"INFRASTRUCTURE"[[:space:]]*:[[:space:]]*"(SERVERLESS|DEDICATED|CLOUD@CUSTOMER)"', 'i')
            );
    exception
        when others then return false;
    end is_adb;

    procedure debug2(p_name in varchar2, p_value in varchar2) is
    begin
        if upper('&AWR_PDB_DEBUG') in ('1', 'Y', 'TRUE') then
            dbms_output.put_line(rpad('DEBUG_AWR_PDB_' || p_name, l_pad_length) || ' ' || p_value);
        end if;
    end debug2;
begin
    dbms_output.put_line('~~BEGIN-OS-INFORMATION~~');
    dbms_output.put_line(rpad('STAT_NAME', l_pad_length) || ' ' || 'STAT_VALUE');
    dbms_output.put_line(rpad('-', l_pad_length, '-') || ' ' || rpad('-', l_pad_length, '-'));

    -- CPU + physical memory (host) from V$OSSTAT
    l_n := emit2(q'{select case when stat_name = 'PHYSICAL_MEMORY_BYTES' then 'PHYSICAL_MEMORY_GB' else stat_name end,
        to_char(case when stat_name = 'PHYSICAL_MEMORY_BYTES' then round(value/1024/1024/1024, 2) else value end)
        from v$osstat where stat_name like 'NUM_CPU%' or stat_name = 'PHYSICAL_MEMORY_BYTES'}');
    l_num_cpus_rows := count_rows(q'{select 1 from v$osstat where stat_name = 'NUM_CPUS'}');
    l_adb_detected := is_adb;
    debug2('OSSTAT_NUM_CPUS_ROWS', to_char(l_num_cpus_rows));
    debug2('ADB_DETECTED', case when l_adb_detected then 'YES' else 'NO' end);

    if l_num_cpus_rows = 0 and l_adb_detected then
        dbms_output.put_line(rpad('ADB_DETECTED', l_pad_length) || ' YES');
        l_n := emit2(q'{select 'NUM_CPUS', to_char(value)
            from v$parameter
            where name = 'cpu_count'
            and regexp_like(value, '^[0-9]+([.][0-9]+)?$')
            and to_number(value) > 0
            and rownum = 1}');
        if l_n > 0 then
            dbms_output.put_line(rpad('HOST_CPU_SOURCE', l_pad_length) || ' V$PARAMETER.CPU_COUNT');
        else
            l_n := emit2(q'{select 'NUM_CPUS', to_char(num_cpus)
                from v$rsrcpdbmetric
                where num_cpus is not null
                and num_cpus > 0
                and rownum = 1}');
            if l_n > 0 then
                dbms_output.put_line(rpad('HOST_CPU_SOURCE', l_pad_length) || ' V$RSRCPDBMETRIC.NUM_CPUS');
            end if;
        end if;
        debug2('HOST_CPU_FALLBACK_ROWS', to_char(l_n));
    end if;

    -- Alternate CPU counts (only when DBA_CPU_USAGE_STATISTICS is populated/visible)
    l_n := emit2(q'{select nm, to_char(val) from
        (select cpu_count, cpu_core_count, cpu_socket_count from dba_cpu_usage_statistics
         where timestamp = (select max(timestamp) from dba_cpu_usage_statistics) and rownum = 1)
        unpivot (val for nm in (cpu_count as '!CPU_COUNT', cpu_core_count as '!CPU_CORE_COUNT', cpu_socket_count as '!CPU_SOCKET_COUNT'))}');

    -- Alternate platform from GV$DATABASE
    l_n := emit2(q'{select '!PLATFORM_NAME', platform_name from (select platform_name from gv$database) where rownum = 1}');

    -- Host platform from V$DATABASE (CDB-root platform as seen from the PDB).
    -- Spaces collapse to underscores so the value stays one fixed-width token.
    l_n := emit2(q'{select 'PLATFORM_NAME', replace(platform_name, ' ', '_') from (select platform_name from v$database) where rownum = 1}');

    -- PDB identity (never overwrite with the CDB name)
    dbms_output.put_line(rpad('DB_NAME', l_pad_length) || ' ' || '&DBNAME');
    dbms_output.put_line(rpad('DBID', l_pad_length) || ' ' || '&DBID');

    -- Version: full patch level (18+) with fallback to the base version string
    begin
        execute immediate 'select version_full from v$instance where rownum = 1' into l_version;
    exception when others then
        begin
            execute immediate 'select version from v$instance where rownum = 1' into l_version;
        exception when others then
            l_version := null;
        end;
    end;
    if l_version is not null then
        dbms_output.put_line(rpad('VERSION', l_pad_length) || ' ' || l_version);
    end if;

    -- Instance count (GV$INSTANCE for RAC; V$INSTANCE otherwise)
    begin
        execute immediate 'select count(*) from gv$instance' into l_instances;
    exception when others then
        begin
            execute immediate 'select count(*) from v$instance' into l_instances;
        exception when others then
            l_instances := null;
        end;
    end;
    if l_instances is not null then
        dbms_output.put_line(rpad('INSTANCES', l_pad_length) || ' ' || l_instances);
    end if;

    -- Host name(s), comma-separated, subject to the capture toggle
    if '&CAPTURE_HOST_NAMES' = 'YES' then
        l_n := emit2(q'{select 'HOSTS', listagg(host, ',') within group (order by host)
            from (select distinct regexp_replace(host_name, '^([[:alnum:]]+)\..*$', '\1') host from gv$instance)}');
        if l_n = 0 then
            l_n := emit2(q'{select 'HOSTS', regexp_replace(host_name, '^([[:alnum:]]+)\..*$', '\1')
                from (select host_name from v$instance) where rownum = 1}');
        end if;
    end if;

    -- Connecting module (informational)
    l_n := emit2(q'{select 'MODULE', regexp_replace(sys_context('USERENV', 'MODULE'), '^(.+?)@.+$', '\1') from dual}');

    -- AWR snapshot settings for this container. DBA_HIST_WR_CONTROL.RETENTION and
    -- .SNAP_INTERVAL are INTERVAL DAY TO SECOND (Oracle Database Reference), so they
    -- are converted to plain days / minutes here. These two facts explain how much
    -- history the extract can ever contain: OCCA sizing wants at least 7-8 days, and
    -- a database whose retention is shorter than that can never satisfy it no matter
    -- how long the extract waits. Reported, never used to pad or invent snapshots.
    --
    -- The dbid filter is not cosmetic: DBA_HIST_WR_CONTROL holds one row per AWR
    -- domain and the two disagree. Verified on 19.31 from inside ORCLPDB, it
    -- returns con_id 0 / dbid 3526403574 with a 1 hour interval and 8 day
    -- retention (the CDB root's settings) alongside con_id 3 / dbid 298443489 with
    -- a disabled interval and 30 day retention (the PDB's own). Reporting the root
    -- row in a PDB extract would describe a schedule this PDB does not follow.
    l_n := emit2(q'{select 'AWR_RETENTION_DAYS',
        to_char(round(extract(day from retention) + extract(hour from retention) / 24
            + extract(minute from retention) / 1440, 2))
        from dba_hist_wr_control where dbid = &DBID}');
    -- DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS(interval => 0) disables
    -- automatic snapshots, and Oracle records that by storing SNAP_INTERVAL as
    -- 40150 days. Reporting that as ~57.8 million minutes would be true but
    -- unreadable, so the disabled state is named instead of arithmetically encoded.
    l_n := emit2(q'{select 'AWR_SNAP_INTERVAL_MIN',
        case when extract(day from snap_interval) >= 40150 then 'DISABLED'
             else to_char(round(extract(day from snap_interval) * 1440
                 + extract(hour from snap_interval) * 60
                 + extract(minute from snap_interval), 2)) end
        from dba_hist_wr_control where dbid = &DBID}');

    dbms_output.put_line(rpad('AWR_MINER_VER', l_pad_length) || ' &AWR_MINER_VER');
    dbms_output.put_line('~~END-OS-INFORMATION~~');
end;
/

prompt ------------------------- BEGIN-OS-INFORMATION2

declare
    l_pad_length number := 60;
    l_arch       varchar2(20) := 'NON-CDB';
    l_pdb_count  number := 0;
    l_n          number;
    l_num_cpus_rows number := 0;
    l_adb_detected boolean := false;

    -- Emit STAT_NAME / INSTANCE / STAT_VALUE rows (3-col OS-INFORMATION2) from a
    -- dynamic query. Returns the row count; errors omit the rows (ADB-safe).
    function emit3(p_sql in varchar2) return number is
        c      sys_refcursor;
        v_name varchar2(200);
        v_inst varchar2(200);
        v_val  varchar2(4000);
        n      number := 0;
    begin
        open c for p_sql;
        loop
            fetch c into v_name, v_inst, v_val;
            exit when c%notfound;
            dbms_output.put_line(rpad(v_name, l_pad_length) || ' ' || rpad(v_inst, l_pad_length) || ' ' || v_val);
            n := n + 1;
        end loop;
        close c;
        return n;
    exception
        when others then
            begin if c%isopen then close c; end if; exception when others then null; end;
            return n;
    end emit3;

    function count_rows(p_sql in varchar2) return number is
        n number := 0;
    begin
        execute immediate 'select count(*) from (' || p_sql || ')' into n;
        return n;
    exception
        when others then return 0;
    end count_rows;

    function is_adb return boolean is
        l_cloud_service varchar2(4000);
        l_cloud_identity varchar2(4000);
    begin
        begin
            l_cloud_service := sys_context('USERENV', 'CLOUD_SERVICE');
            if upper(l_cloud_service) in ('DWCS', 'OLTP', 'JDCS') then
                return true;
            end if;
        exception
            when others then null;
        end;

        -- Missing/blocked CLOUD_IDENTITY is expected on non-ADB platforms such as RDS.
        execute immediate 'select substr(cloud_identity, 1, 4000) from v$pdbs where rownum = 1'
            into l_cloud_identity;
        if l_cloud_identity is null then
            return false;
        end if;
        return instr(upper(l_cloud_identity), 'OCID1.AUTONOMOUSDATABASE.') > 0
            or (
                regexp_like(l_cloud_identity, '"SERVICE"[[:space:]]*:[[:space:]]*"(ATP|ADW)"', 'i')
                and regexp_like(l_cloud_identity, '"INFRASTRUCTURE"[[:space:]]*:[[:space:]]*"(SERVERLESS|DEDICATED|CLOUD@CUSTOMER)"', 'i')
            );
    exception
        when others then return false;
    end is_adb;

    procedure debug3(p_name in varchar2, p_value in varchar2) is
    begin
        if upper('&AWR_PDB_DEBUG') in ('1', 'Y', 'TRUE') then
            dbms_output.put_line(rpad('DEBUG_AWR_PDB_' || p_name, l_pad_length) || ' ' || rpad('0', l_pad_length) || ' ' || p_value);
        end if;
    end debug3;
begin
    dbms_output.put_line('~~BEGIN-OS-INFORMATION2~~');
    dbms_output.put_line(rpad('STAT_NAME', l_pad_length) || ' ' || rpad('INSTANCE', l_pad_length) || ' ' || 'STAT_VALUE');
    dbms_output.put_line(rpad('-', l_pad_length, '-') || ' ' || rpad('-', l_pad_length, '-') || ' ' || rpad('-', l_pad_length, '-'));

    -- Architecture / PDB count (best-effort)
    begin
        execute immediate q'{select case when cdb = 'YES' then 'CDB' else 'NON-CDB' end from v$database}' into l_arch;
    exception when others then l_arch := 'NON-CDB'; end;
    if l_arch = 'CDB' then
        begin
            execute immediate 'select count(*) from v$pdbs where con_id > 2' into l_pdb_count;
        exception when others then l_pdb_count := 0; end;
    end if;
    dbms_output.put_line(rpad('DB_ARCHITECTURE', l_pad_length) || ' ' || rpad('0', l_pad_length) || ' ' || l_arch);
    dbms_output.put_line(rpad('PDB_COUNT', l_pad_length) || ' ' || rpad('0', l_pad_length) || ' ' || l_pdb_count);

    -- Per-instance CPU + memory: GV$OSSTAT, falling back to V$OSSTAT (this
    -- instance's number) when GV$ is unavailable. INSTANCE > 0 rows are what the
    -- plotter pivots into per-instance sizing.
    if emit3(q'{select case when stat_name = 'PHYSICAL_MEMORY_BYTES' then 'PHYSICAL_MEMORY_GB' else stat_name end,
        to_char(inst_id),
        to_char(case when stat_name = 'PHYSICAL_MEMORY_BYTES' then round(value/1024/1024/1024, 2) else value end)
        from gv$osstat where stat_name like 'NUM_CPU%' or stat_name = 'PHYSICAL_MEMORY_BYTES'}') = 0 then
        l_n := emit3(q'{select case when stat_name = 'PHYSICAL_MEMORY_BYTES' then 'PHYSICAL_MEMORY_GB' else stat_name end,
            to_char((select instance_number from v$instance)),
            to_char(case when stat_name = 'PHYSICAL_MEMORY_BYTES' then round(value/1024/1024/1024, 2) else value end)
            from v$osstat where stat_name like 'NUM_CPU%' or stat_name = 'PHYSICAL_MEMORY_BYTES'}');
    end if;
    l_num_cpus_rows := count_rows(q'{select 1 from gv$osstat where stat_name = 'NUM_CPUS'}');
    if l_num_cpus_rows = 0 then
        l_num_cpus_rows := count_rows(q'{select 1 from v$osstat where stat_name = 'NUM_CPUS'}');
    end if;
    l_adb_detected := is_adb;
    debug3('OSSTAT_NUM_CPUS_ROWS', to_char(l_num_cpus_rows));
    debug3('ADB_DETECTED', case when l_adb_detected then 'YES' else 'NO' end);

    if l_num_cpus_rows = 0 and l_adb_detected then
        dbms_output.put_line(rpad('ADB_DETECTED', l_pad_length) || ' ' || rpad('0', l_pad_length) || ' YES');
        l_n := emit3(q'{select 'NUM_CPUS',
            to_char((select instance_number from v$instance)),
            to_char(value)
            from v$parameter
            where name = 'cpu_count'
            and regexp_like(value, '^[0-9]+([.][0-9]+)?$')
            and to_number(value) > 0
            and rownum = 1}');
        if l_n > 0 then
            dbms_output.put_line(rpad('HOST_CPU_SOURCE', l_pad_length) || ' ' || rpad('0', l_pad_length) || ' V$PARAMETER.CPU_COUNT');
        else
            l_n := emit3(q'{select 'NUM_CPUS',
                to_char((select instance_number from v$instance)),
                to_char(num_cpus)
                from v$rsrcpdbmetric
                where num_cpus is not null
                and num_cpus > 0
                and rownum = 1}');
            if l_n > 0 then
                dbms_output.put_line(rpad('HOST_CPU_SOURCE', l_pad_length) || ' ' || rpad('0', l_pad_length) || ' V$RSRCPDBMETRIC.NUM_CPUS');
            end if;
        end if;
        debug3('HOST_CPU_FALLBACK_ROWS', to_char(l_n));
    end if;

    -- Alternate CPU counts (INSTANCE 0)
    l_n := emit3(q'{select nm, '0', to_char(val) from
        (select cpu_count, cpu_core_count, cpu_socket_count from dba_cpu_usage_statistics
         where timestamp = (select max(timestamp) from dba_cpu_usage_statistics) and rownum = 1)
        unpivot (val for nm in (cpu_count as '!CPU_COUNT', cpu_core_count as '!CPU_CORE_COUNT', cpu_socket_count as '!CPU_SOCKET_COUNT'))}');

    -- Alternate platform from GV$DATABASE (INSTANCE 0)
    l_n := emit3(q'{select '!PLATFORM_NAME', '0', platform_name from (select platform_name from gv$database) where rownum = 1}');

    -- Host platform from V$DATABASE (INSTANCE 0)
    l_n := emit3(q'{select 'PLATFORM_NAME', '0', replace(platform_name, ' ', '_') from (select platform_name from v$database) where rownum = 1}');

    -- PDB identity (INSTANCE 0)
    dbms_output.put_line(rpad('DB_NAME', l_pad_length) || ' ' || rpad('0', l_pad_length) || ' ' || '&DBNAME');
    dbms_output.put_line(rpad('DBID', l_pad_length) || ' ' || rpad('0', l_pad_length) || ' ' || '&DBID');

    -- Version per instance: GV$INSTANCE.VERSION_FULL -> GV$INSTANCE.VERSION ->
    -- V$INSTANCE.VERSION_FULL -> V$INSTANCE.VERSION (covers pre-18 and blocked GV$)
    if emit3(q'{select 'VERSION', to_char(inst_id), version_full from gv$instance}') = 0 then
    if emit3(q'{select 'VERSION', to_char(inst_id), version from gv$instance}') = 0 then
    if emit3(q'{select 'VERSION', to_char(instance_number), version_full from v$instance}') = 0 then
        l_n := emit3(q'{select 'VERSION', to_char(instance_number), version from v$instance}');
    end if;
    end if;
    end if;

    -- Host name(s) per instance, subject to the capture toggle
    if '&CAPTURE_HOST_NAMES' = 'YES' then
        if emit3(q'{select 'HOSTS', to_char(inst_id), regexp_replace(host_name, '^([[:alnum:]]+)\..*$', '\1') from gv$instance}') = 0 then
            l_n := emit3(q'{select 'HOSTS', to_char(instance_number), regexp_replace(host_name, '^([[:alnum:]]+)\..*$', '\1') from v$instance}');
        end if;
    end if;

    -- Connecting module (INSTANCE 0)
    l_n := emit3(q'{select 'MODULE', '0', regexp_replace(sys_context('USERENV', 'MODULE'), '^(.+?)@.+$', '\1') from dual}');

    dbms_output.put_line(rpad('AWR_MINER_VER', l_pad_length) || ' ' || rpad('0', l_pad_length) || ' &AWR_MINER_VER');
    dbms_output.put_line('~~END-OS-INFORMATION2~~');
end;
/

set serveroutput off

-- ============================================================================
-- AWR snapshot coverage (SNAP-HISTORY / SNAP-HISTORY-TZ)
-- ----------------------------------------------------------------------------
-- awr_miner.sql emits both of these for a CDB/non-CDB; the PDB extract did not,
-- so a PDB collection reached the sizing step with no record of how many
-- snapshots it covered, how many instances produced them, or what timezone their
-- end times are in. occa/awr_miner_Run_Metric_Analysis.py measures a collection's
-- coverage in days and rejects anything under OVERLAP_DAYS_WITHIN_A_COHORT, so
-- these are the sections that make that verdict explainable instead of opaque.
--
-- Both are scoped to &DBID, the PDB-local AWR domain resolved by the identity
-- block at the top, for the same reason PDB-SIZE-HISTORY and PDB-MEMORY-HISTORY
-- are: inside a PDB, DBA_HIST_SNAPSHOT exposes the PDB's own AWR and the CDB root
-- AWR subset, and one file must describe one domain.
--
-- That the filter is the right one is checkable, not assumed. Oracle's "Managing
-- AWR in a Multitenant Environment" (Table 6-2, Views Accessing AWR Data) states
-- that DBA_HIST views accessed from a PDB show the subset of CDB root AWR data for
-- that PDB, while the AWR_PDB views show the PDB's own local AWR, and that
-- PDB-level snapshots carry their own snapshot IDs unrelated to CDB-level ones.
-- So AWR_PDB_SNAPSHOT is the documented name for what this script wants. It is
-- deliberately NOT used here: the AWR_PDB views only exist from 12.2, whereas this
-- script still has to parse on 12.1, and DBA_HIST_SNAPSHOT filtered by the PDB's
-- own con_dbid returns exactly the same set. Verified on 19.31: AWR_PDB_SNAPSHOT
-- and "dba_hist_snapshot where dbid = <con_dbid>" both return snaps 1-2 for dbid
-- 298443489, while the unfiltered DBA_HIST_SNAPSHOT also returns 7 root rows for
-- dbid 3526403574. AWR_PDB_* is the readable form; this is the portable one.
--
-- Version compatibility follows the awr_miner.sql rule: probe for the COLUMN, not
-- the version number. DBA_HIST_SNAPSHOT.SNAP_TIMEZONE arrived in 11.2.0.2 and
-- ERROR_COUNT is not present on every release, so referencing either one directly
-- would make the whole script fail to parse on an older database instead of just
-- omitting the section.
define PDB_SNAP_HISTORY_SOURCE = '(select cast(null as number) snap_min, cast(null as number) snap_max, cast(null as number) cnt, cast(null as number) inst_count, cast(null as number) error_count from dual where 1 = 0)'
column pdb_snap_history_source_col new_value PDB_SNAP_HISTORY_SOURCE noprint
select case
when count(distinct case when column_name in ('DBID','SNAP_ID','INSTANCE_NUMBER','ERROR_COUNT') then column_name end) = 4
then '(select min(snap_id) snap_min, max(snap_id) snap_max, count(*) cnt, count(distinct instance_number) inst_count, sum(error_count) error_count from dba_hist_snapshot where dbid = &DBID having count(*) > 0)'
else '(select cast(null as number) snap_min, cast(null as number) snap_max, cast(null as number) cnt, cast(null as number) inst_count, cast(null as number) error_count from dual where 1 = 0)'
end pdb_snap_history_source_col
from all_tab_columns
where table_name = 'DBA_HIST_SNAPSHOT';

define PDB_SNAP_HISTORY_TZ_SOURCE = '(select cast(null as number) snap, cast(null as varchar2(16)) end_time, cast(null as number) inst, cast(null as number) minutes_diff_from_utc from dual where 1 = 0)'
column pdb_snap_history_tz_source_col new_value PDB_SNAP_HISTORY_TZ_SOURCE noprint
select case
when count(distinct case when column_name in ('DBID','SNAP_ID','INSTANCE_NUMBER','END_INTERVAL_TIME','SNAP_TIMEZONE') then column_name end) = 5
then '(select s.snap_id snap, to_char(s.end_interval_time, ''YYYY/MM/DD HH24:MI'') end_time, s.instance_number inst, extract(hour from s.snap_timezone) * 60 + extract(minute from s.snap_timezone) minutes_diff_from_utc from dba_hist_snapshot s where s.dbid = &DBID and s.snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX)'
else '(select cast(null as number) snap, cast(null as varchar2(16)) end_time, cast(null as number) inst, cast(null as number) minutes_diff_from_utc from dual where 1 = 0)'
end pdb_snap_history_tz_source_col
from all_tab_columns
where table_name = 'DBA_HIST_SNAPSHOT';

prompt ------------------------- BEGIN-SNAP-HISTORY
set heading off
set pagesize 0
select '~~BEGIN-SNAP-HISTORY~~' from dual where exists (select 1 from &PDB_SNAP_HISTORY_SOURCE);
set heading on
set pagesize 50000
select * from &PDB_SNAP_HISTORY_SOURCE;
set heading off
set pagesize 0
select '~~END-SNAP-HISTORY~~' from dual where exists (select 1 from &PDB_SNAP_HISTORY_SOURCE);
select 'NO metrics collected for section SNAP-HISTORY' from dual where not exists (select 1 from &PDB_SNAP_HISTORY_SOURCE);
set heading on

prompt ------------------------- BEGIN-SNAP-HISTORY-TZ
set heading off
set pagesize 0
select '~~BEGIN-SNAP-HISTORY-TZ~~' from dual where exists (select 1 from &PDB_SNAP_HISTORY_TZ_SOURCE);
set heading on
set pagesize 50000
-- Ordered for the same reason as the history sections below: awr_miner_parse.py
-- reads a section whose first snap_id exceeds its last as a snapshot-id rollover.
select * from &PDB_SNAP_HISTORY_TZ_SOURCE order by snap, end_time, inst;
set heading off
set pagesize 0
select '~~END-SNAP-HISTORY-TZ~~' from dual where exists (select 1 from &PDB_SNAP_HISTORY_TZ_SOURCE);
select 'NO metrics collected for section SNAP-HISTORY-TZ' from dual where not exists (select 1 from &PDB_SNAP_HISTORY_TZ_SOURCE);
set heading on

-- ============================================================================
-- DATABASE-PARAMETERS
-- ----------------------------------------------------------------------------
-- This is where CPU_COUNT comes from, and its absence was not cosmetic.
-- occa/awr_miner_plot.py:1263-1328 sources cpu_count and cpu_min_count from this
-- section and from nowhere else; with the section missing it takes the
-- len(df) == 0 branch and hardcodes cpu_count = 0. Everything downstream then
-- follows from a zero: the instance row reports 0 vCPUs, every metric row is
-- flagged into bad_db_vcpu.csv because cpu_per_s > 0 is "greater than the
-- instance CPU count", cpu_per_s / cpu_count is written as inf, and finally
-- awr_miner_plot.py:1967 clamps cpu_per_s down to cpu_count -- that is, to 0.
-- A PDB with real CPU usage was being sized as if it used no CPU at all.
--
-- The values are available inside a PDB: verified on 19.31 from ORCLPDB,
-- DBA_HIST_PARAMETER holds cpu_count = 2 and cpu_min_count = 2 for the PDB's own
-- dbid 298443489 at snaps 1-2, matching V$PARAMETER in the same session.
--
-- Two deliberate differences from awr_miner.sql:
--   * The snapshot anchor is DBA_HIST_PARAMETER itself, not DBA_HIST_OSSTAT.
--     awr_miner.sql anchors on OSSTAT, which is host scope; making a PDB section
--     depend on a host-scope view means the parameters vanish entirely whenever
--     the PDB's local AWR has no OSSTAT rows. Anchoring a view on itself cannot
--     produce that failure mode.
--   * VALUE is bounded with a column format. The column is VARCHAR2(4000) and
--     linesize is 32767, so unbounded it would render every row 4000 characters
--     wide. "set wrap off" above truncates rather than wraps, which keeps the
--     fixed-width layout that occa/awr_miner_parse.py depends on intact.
-- Bound through column new_value, not define: see PDB_METRICS_SOURCE above.  This
-- one has no probe to overwrite it, so a rejected define left it unset and the
-- select below stopped the whole run on "Enter value for pdb_parameters_source:".
column pdb_params_src_seed_col new_value PDB_PARAMETERS_SOURCE noprint
select '(select distinct o.instance_number, o.parameter_name, o.value from dba_hist_parameter o where o.dbid = &DBID and o.snap_id = (select max(i.snap_id) from dba_hist_parameter i where i.dbid = o.dbid and i.instance_number = o.instance_number) and o.parameter_name not in (''local_listener'', ''service_names'', ''remote_listener'', ''db_domain'', ''cluster_interconnects''))' pdb_params_src_seed_col from dual;

prompt ------------------------- BEGIN-DATABASE-PARAMETERS
column parameter_name format a40
column value format a64
set heading off
set pagesize 0
select '~~BEGIN-DATABASE-PARAMETERS~~' from dual where exists (select 1 from &PDB_PARAMETERS_SOURCE);
set heading on
set pagesize 50000
select * from &PDB_PARAMETERS_SOURCE order by instance_number, parameter_name;
set heading off
set pagesize 0
select '~~END-DATABASE-PARAMETERS~~' from dual where exists (select 1 from &PDB_PARAMETERS_SOURCE);
select 'NO metrics collected for section DATABASE-PARAMETERS' from dual where not exists (select 1 from &PDB_PARAMETERS_SOURCE);
set heading on
-- Cleared individually, not with "clear columns", which would also drop the
-- new_value bindings this script relies on further down.
column parameter_name clear
column value clear

prompt ------------------------- BEGIN-MEMORY
set heading off
set pagesize 0
select '~~BEGIN-MEMORY~~' from dual where exists (select 1 from &PDB_MEMORY_SOURCE);
set heading on
set pagesize 50000

select
    snap_id "SNAP_ID",
    instance_number "INSTANCE_NUMBER",
    sga "SGA",
    pga "PGA",
    total "TOTAL"
from &PDB_MEMORY_SOURCE
order by snap_id, instance_number;

set heading off
set pagesize 0
select '~~END-MEMORY~~' from dual where exists (select 1 from &PDB_MEMORY_SOURCE);
select 'NO metrics collected for section MEMORY' from dual where not exists (select 1 from &PDB_MEMORY_SOURCE);
set heading on


-- Both history sources below are scoped to &DBID and &SNAP_ID_MIN..&SNAP_ID_MAX,
-- the same scope PDB_MEMORY_SOURCE uses, so every section of one extract describes
-- one AWR domain.
--
-- Queried from inside a PDB, DBA_HIST_* exposes two DBIDs: the PDB's own local AWR
-- and the CDB root AWR subset for that PDB. Without the &DBID predicate these two
-- sources returned both, so a single file carried rows from two DBIDs with the same
-- SNAP_ID values while its header declared only one range. The identity block above
-- resolves &DBID from the current container, so these sections report the PDB-local
-- history. The metrics section is deliberately different: it reads the root AWR
-- subset from DBA_HIST_CON_SYSMETRIC_SUMM, as documented at the top of that section.
--
-- Snapshot rows are per instance, while tablespace usage rows are not. Join through
-- one row per snap_id, otherwise RAC/2-instance PDB storage is multiplied by the
-- instance count before the sum.
-- Bound through column new_value, not define: see PDB_METRICS_SOURCE above.
column pdb_size_hist_src_seed_col new_value PDB_SIZE_HISTORY_SOURCE noprint
select '(select cast(null as varchar2(128)) pdb_name, cast(null as number) pdb_dbid, cast(null as number) awr_dbid, cast(null as number) snap_id, cast(null as varchar2(19)) snap_begin, cast(null as varchar2(19)) snap_end, cast(null as number) tablespaces_count, cast(null as number) allocated_gib, cast(null as number) used_gib, cast(null as number) free_within_allocated_gib, cast(null as number) max_potential_gib, cast(null as number) used_pct, cast(null as number) snapshot_error_count from dual where 1 = 0)' pdb_size_hist_src_seed_col from dual;
column pdb_size_history_source_col new_value PDB_SIZE_HISTORY_SOURCE noprint
select case
when count(case when table_name = 'DBA_HIST_TBSPC_SPACE_USAGE' and column_name in ('DBID','SNAP_ID','CON_ID','CON_DBID','TABLESPACE_ID','TABLESPACE_SIZE','TABLESPACE_USEDSIZE','TABLESPACE_MAXSIZE') then 1 end) = 8
 and count(case when table_name = 'DBA_HIST_TABLESPACE' and column_name in ('DBID','TS#','CON_ID','CON_DBID','BLOCK_SIZE','CONTENTS') then 1 end) = 6
 and count(case when table_name = 'DBA_HIST_SNAPSHOT' and column_name in ('DBID','SNAP_ID','INSTANCE_NUMBER','BEGIN_INTERVAL_TIME','END_INTERVAL_TIME','ERROR_COUNT') then 1 end) = 6
then '(select sys_context(''USERENV'',''CON_NAME'') pdb_name, d.con_dbid pdb_dbid, u.dbid awr_dbid, u.snap_id, to_char(min(s.begin_interval_time), ''YYYY-MM-DD HH24:MI:SS'') snap_begin, to_char(max(s.end_interval_time), ''YYYY-MM-DD HH24:MI:SS'') snap_end, count(*) tablespaces_count, round(sum(u.tablespace_size * t.block_size) / power(1024, 3), 3) allocated_gib, round(sum(u.tablespace_usedsize * t.block_size) / power(1024, 3), 3) used_gib, round((sum(u.tablespace_size * t.block_size) - sum(u.tablespace_usedsize * t.block_size)) / power(1024, 3), 3) free_within_allocated_gib, round(sum(nvl(u.tablespace_maxsize, u.tablespace_size) * t.block_size) / power(1024, 3), 3) max_potential_gib, round(100 * sum(u.tablespace_usedsize * t.block_size) / nullif(sum(u.tablespace_size * t.block_size), 0), 2) used_pct, max(nvl(s.error_count, 0)) snapshot_error_count from dba_hist_tbspc_space_usage u join dba_hist_tablespace t on t.dbid = u.dbid and t.ts# = u.tablespace_id and t.con_dbid = u.con_dbid and t.con_id = u.con_id join v$database d on d.con_dbid = u.con_dbid join (select dbid, snap_id, min(begin_interval_time) begin_interval_time, max(end_interval_time) end_interval_time, sum(nvl(error_count, 0)) error_count from dba_hist_snapshot where dbid = &DBID and snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX group by dbid, snap_id) s on s.dbid = u.dbid and s.snap_id = u.snap_id where to_number(sys_context(''USERENV'',''CON_ID'')) > 2 and u.dbid = &DBID and t.contents in (''PERMANENT'', ''UNDO'') group by sys_context(''USERENV'',''CON_NAME''), d.con_dbid, u.dbid, u.snap_id)'
else '(select cast(null as varchar2(128)) pdb_name, cast(null as number) pdb_dbid, cast(null as number) awr_dbid, cast(null as number) snap_id, cast(null as varchar2(19)) snap_begin, cast(null as varchar2(19)) snap_end, cast(null as number) tablespaces_count, cast(null as number) allocated_gib, cast(null as number) used_gib, cast(null as number) free_within_allocated_gib, cast(null as number) max_potential_gib, cast(null as number) used_pct, cast(null as number) snapshot_error_count from dual where 1 = 0)'
end pdb_size_history_source_col
from all_tab_columns
where table_name in ('DBA_HIST_TBSPC_SPACE_USAGE', 'DBA_HIST_TABLESPACE', 'DBA_HIST_SNAPSHOT');

-- Bound through column new_value, not define: see PDB_METRICS_SOURCE above.
column pdb_mem_hist_src_seed_col new_value PDB_MEMORY_HISTORY_SOURCE noprint
select '(select cast(null as varchar2(128)) pdb_name, cast(null as number) pdb_dbid, cast(null as number) awr_dbid, cast(null as number) snap_id, cast(null as varchar2(19)) snap_begin, cast(null as varchar2(19)) snap_end, cast(null as number) instances_in_snapshot, cast(null as number) instances_with_metric, cast(null as number) sga_usage_gib, cast(null as number) buffer_cache_gib, cast(null as number) shared_pool_gib, cast(null as number) pga_usage_gib, cast(null as number) total_memory_usage_gib, cast(null as number) snapshot_error_count from dual where 1 = 0)' pdb_mem_hist_src_seed_col from dual;
column pdb_memory_history_source_col new_value PDB_MEMORY_HISTORY_SOURCE noprint
select case
when count(case when table_name = 'DBA_HIST_RSRC_PDB_METRIC' and column_name in ('DBID','SNAP_ID','INSTANCE_NUMBER','CON_ID','CON_DBID','BEGIN_TIME','END_TIME','SEQUENCE#','PLAN_ID','SGA_BYTES','BUFFER_CACHE_BYTES','SHARED_POOL_BYTES','PGA_BYTES') then 1 end) = 13
 and count(case when table_name = 'DBA_HIST_SNAPSHOT' and column_name in ('DBID','SNAP_ID','INSTANCE_NUMBER','BEGIN_INTERVAL_TIME','END_INTERVAL_TIME','ERROR_COUNT') then 1 end) = 6
then '(select sys_context(''USERENV'',''CON_NAME'') pdb_name, d.con_dbid pdb_dbid, m.dbid awr_dbid, m.snap_id, to_char(min(s.begin_interval_time), ''YYYY-MM-DD HH24:MI:SS'') snap_begin, to_char(max(s.end_interval_time), ''YYYY-MM-DD HH24:MI:SS'') snap_end, count(distinct s.instance_number) instances_in_snapshot, count(distinct m.instance_number) instances_with_metric, round(sum(m.sga_bytes) / power(1024, 3), 3) sga_usage_gib, round(sum(m.buffer_cache_bytes) / power(1024, 3), 3) buffer_cache_gib, round(sum(m.shared_pool_bytes) / power(1024, 3), 3) shared_pool_gib, round(sum(m.pga_bytes) / power(1024, 3), 3) pga_usage_gib, round((sum(m.sga_bytes) + sum(m.pga_bytes)) / power(1024, 3), 3) total_memory_usage_gib, sum(nvl(s.error_count, 0)) snapshot_error_count from (select m.*, row_number() over (partition by m.dbid, m.snap_id, m.instance_number, m.con_dbid order by m.end_time desc, m.sequence# desc, m.plan_id desc) rn from dba_hist_rsrc_pdb_metric m) m join v$database d on d.con_dbid = m.con_dbid join dba_hist_snapshot s on s.dbid = m.dbid and s.snap_id = m.snap_id and s.instance_number = m.instance_number where m.rn = 1 and to_number(sys_context(''USERENV'',''CON_ID'')) > 2 and m.dbid = &DBID and m.snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX group by sys_context(''USERENV'',''CON_NAME''), d.con_dbid, m.dbid, m.snap_id)'
else '(select cast(null as varchar2(128)) pdb_name, cast(null as number) pdb_dbid, cast(null as number) awr_dbid, cast(null as number) snap_id, cast(null as varchar2(19)) snap_begin, cast(null as varchar2(19)) snap_end, cast(null as number) instances_in_snapshot, cast(null as number) instances_with_metric, cast(null as number) sga_usage_gib, cast(null as number) buffer_cache_gib, cast(null as number) shared_pool_gib, cast(null as number) pga_usage_gib, cast(null as number) total_memory_usage_gib, cast(null as number) snapshot_error_count from dual where 1 = 0)'
end pdb_memory_history_source_col
from all_tab_columns
where table_name in ('DBA_HIST_RSRC_PDB_METRIC', 'DBA_HIST_SNAPSHOT');

prompt ------------------------- BEGIN-PDB-SIZE-HISTORY
set heading off
set pagesize 0
select '~~BEGIN-PDB-SIZE-HISTORY~~' from dual where exists (select 1 from &PDB_SIZE_HISTORY_SOURCE);
set heading on
set pagesize 50000
-- Ordered by snap_id on purpose. occa/awr_miner_parse.py treats a section whose
-- first snap_id is greater than its last as an AWR snapshot-id rollover and
-- renumbers the rows, so an unordered result set silently corrupts the snap ids.
select * from &PDB_SIZE_HISTORY_SOURCE order by snap_id;
set heading off
set pagesize 0
select '~~END-PDB-SIZE-HISTORY~~' from dual where exists (select 1 from &PDB_SIZE_HISTORY_SOURCE);
select 'NO metrics collected for section PDB-SIZE-HISTORY' from dual where not exists (select 1 from &PDB_SIZE_HISTORY_SOURCE);
set heading on

prompt ------------------------- BEGIN-PDB-MEMORY-HISTORY
set heading off
set pagesize 0
select '~~BEGIN-PDB-MEMORY-HISTORY~~' from dual where exists (select 1 from &PDB_MEMORY_HISTORY_SOURCE);
set heading on
set pagesize 50000
-- Ordered by snap_id for the same reason as PDB-SIZE-HISTORY above.
select * from &PDB_MEMORY_HISTORY_SOURCE order by snap_id;
set heading off
set pagesize 0
select '~~END-PDB-MEMORY-HISTORY~~' from dual where exists (select 1 from &PDB_MEMORY_HISTORY_SOURCE);
select 'NO metrics collected for section PDB-MEMORY-HISTORY' from dual where not exists (select 1 from &PDB_MEMORY_HISTORY_SOURCE);
set heading on

prompt ------------------------- BEGIN-PDB-METRICS
set heading off
set pagesize 0
select '~~BEGIN-PDB-METRICS~~' from dual;
set heading on
set pagesize 50000

select
  m.snap_id "snap",
  round((m.end_time - m.begin_time) * 1440) "dur_m",
  to_char(m.end_time, 'YY/MM/DD HH24:MI') "end",
  m.instance_number "inst",
 m.con_id "con_id",
 coalesce(p.pdb_name, case when to_number('&CURRENT_CON_ID') > 2 then sys_context('USERENV', 'CON_NAME') end, 'CON_' || to_char(m.con_id)) "pdb_name",
  cast(null as number) "os_cpu",
  cast(null as number) "os_cpu_max",
  cast(null as number) "os_cpu_sd",
  max(decode(m.metric_name, 'Database Wait Time Ratio', round(m.average, 1), null)) "db_wait_ratio",
  max(decode(m.metric_name, 'Database CPU Time Ratio', round(m.average, 1), null)) "db_cpu_ratio",
  max(decode(m.metric_name, 'CPU Usage Per Sec', round(m.average / 100, 3), null)) "cpu_per_s",
  max(decode(m.metric_name, 'CPU Usage Per Sec', round(m.standard_deviation / 100, 3), null)) "cpu_per_s_sd",
  cast(null as number) "h_cpu_per_s",
  cast(null as number) "h_cpu_per_s_sd",
  max(decode(m.metric_name, 'Average Active Sessions', m.average, null)) "aas",
  max(decode(m.metric_name, 'Average Active Sessions', m.standard_deviation, null)) "aas_sd",
  max(decode(m.metric_name, 'Average Active Sessions', m.maxval, null)) "aas_max",
  max(decode(m.metric_name, 'Database Time Per Sec', m.average, null)) "db_time",
  max(decode(m.metric_name, 'Database Time Per Sec', m.standard_deviation, null)) "db_time_sd",
  max(decode(m.metric_name, 'SQL Service Response Time', m.average, null)) "sql_res_t_cs",
  max(decode(m.metric_name, 'Background Time Per Sec', m.average, null)) "bkgd_t_per_s",
  max(decode(m.metric_name, 'Logons Per Sec', m.average, null)) "logons_s",
  max(decode(m.metric_name, 'Current Logons Count', m.average, null)) "logons_total",
  max(decode(m.metric_name, 'Executions Per Sec', m.average, null)) "exec_s",
  max(decode(m.metric_name, 'Hard Parse Count Per Sec', m.average, null)) "hard_p_s",
  max(decode(m.metric_name, 'Logical Reads Per Sec', m.average, null)) "l_reads_s",
  max(decode(m.metric_name, 'User Commits Per Sec', m.average, null)) "commits_s",
  max(decode(m.metric_name, 'Physical Read Total Bytes Per Sec', round(m.average / 1024 / 1024, 1), null)) "read_mb_s",
  max(decode(m.metric_name, 'Physical Read Total Bytes Per Sec', round(m.maxval / 1024 / 1024, 1), null)) "read_mb_s_max",
  max(decode(m.metric_name, 'Physical Read Total IO Requests Per Sec', m.average, null)) "read_iops",
  max(decode(m.metric_name, 'Physical Read Total IO Requests Per Sec', m.maxval, null)) "read_iops_max",
  max(decode(m.metric_name, 'Physical Reads Per Sec', m.average, null)) "read_bks",
  max(decode(m.metric_name, 'Physical Reads Direct Per Sec', m.average, null)) "read_bks_direct",
  max(decode(m.metric_name, 'Physical Write Total Bytes Per Sec', round(m.average / 1024 / 1024, 1), null)) "write_mb_s",
  max(decode(m.metric_name, 'Physical Write Total Bytes Per Sec', round(m.maxval / 1024 / 1024, 1), null)) "write_mb_s_max",
  max(decode(m.metric_name, 'Physical Write Total IO Requests Per Sec', m.average, null)) "write_iops",
  max(decode(m.metric_name, 'Physical Write Total IO Requests Per Sec', m.maxval, null)) "write_iops_max",
  max(decode(m.metric_name, 'Physical Writes Per Sec', m.average, null)) "write_bks",
  max(decode(m.metric_name, 'Physical Writes Direct Per Sec', m.average, null)) "write_bks_direct",
  max(decode(m.metric_name, 'Redo Generated Per Sec', round(m.average / 1024 / 1024, 1), null)) "redo_mb_s",
 coalesce(max(decode(m.metric_name, 'DB Block Gets Per Sec', m.average, null)), cast(max(bg.value_per_s) as number)) "db_block_gets_s",
  max(decode(m.metric_name, 'DB Block Changes Per Sec', m.average, null)) "db_block_changes_s",
  cast(null as number) "gc_cr_rec_s",
  cast(null as number) "gc_cu_rec_s",
  cast(null as number) "gc_cr_get_cs",
  cast(null as number) "gc_cu_get_cs",
  cast(null as number) "gc_bk_corrupted",
  cast(null as number) "gc_bk_lost",
  max(decode(m.metric_name, 'Active Parallel Sessions', m.average, null)) "px_sess",
  max(decode(m.metric_name, 'Active Serial Sessions', m.average, null)) "se_sess",
  max(decode(m.metric_name, 'Average Synchronous Single-Block Read Latency', m.average, null)) "s_blk_r_lat",
  cast(null as number) "cell_io_int_mb",
  cast(null as number) "cell_io_int_mb_max",
  min(m.snap_id) over (partition by m.dbid, m.con_dbid, m.con_id) "snap_id_start",
  max(m.snap_id) over (partition by m.dbid, m.con_dbid, m.con_id) "snap_id_end"
from &PDB_METRICS_SOURCE m
left join &PDB_NAMES_SOURCE p
  on p.dbid = m.dbid
 and p.con_dbid = m.con_dbid
 and p.snap_id = m.snap_id
 and p.instance_number = m.instance_number
 and p.con_id = m.con_id
left join &PDB_BLOCK_GETS_SOURCE bg
  on bg.dbid = m.dbid
 and bg.con_dbid = m.con_dbid
 and bg.snap_id = m.snap_id
 and bg.instance_number = m.instance_number
 and bg.con_id = m.con_id
group by
  m.dbid,
  m.con_dbid,
  m.snap_id,
  m.begin_time,
  m.end_time,
  m.instance_number,
  m.con_id,
  coalesce(p.pdb_name, case when to_number('&CURRENT_CON_ID') > 2 then sys_context('USERENV', 'CON_NAME') end, 'CON_' || to_char(m.con_id))
order by
  m.snap_id,
  m.end_time,
  m.instance_number,
  m.con_id,
  coalesce(p.pdb_name, case when to_number('&CURRENT_CON_ID') > 2 then sys_context('USERENV', 'CON_NAME') end, 'CON_' || to_char(m.con_id));

set heading off
set pagesize 0
select '~~END-PDB-METRICS~~' from dual;
select 'NO metrics collected for section PDB-METRICS' from dual where not exists (select 1 from &PDB_METRICS_SOURCE);
spool off

-- ============================================================================
-- Collection log (OCCA-1223)
-- ----------------------------------------------------------------------------
-- Support could not tell a thin collection from a healthy one without opening
-- the .out and counting section markers by hand. This writes the same answer to
-- a .log beside it. SQL*Plus allows only one spool at a time, so it is produced
-- after the collection closes; the source substitution variables are still set,
-- so each section is re-tested rather than remembered.
spool &LOG_FILE_NAME
prompt AWR PDB Miner collection log
prompt ============================
prompt Database ID     : &DBID
prompt Database Name   : &DBNAME
prompt Min Snapshot ID : &SNAP_ID_MIN
prompt Max Snapshot ID : &SNAP_ID_MAX
prompt Collection File : &SPOOL_FILE_NAME
prompt Collection Log  : &LOG_FILE_NAME
prompt
prompt Section results
prompt ===============
set heading off
set pagesize 0
select 'SNAP-HISTORY            ' section, case when exists (select 1 from &PDB_SNAP_HISTORY_SOURCE) then 'collected' else 'NO METRICS COLLECTED' end result from dual
union all
select 'SNAP-HISTORY-TZ         ' section, case when exists (select 1 from &PDB_SNAP_HISTORY_TZ_SOURCE) then 'collected' else 'NO METRICS COLLECTED' end result from dual
union all
select 'DATABASE-PARAMETERS     ' section, case when exists (select 1 from &PDB_PARAMETERS_SOURCE) then 'collected' else 'NO METRICS COLLECTED' end result from dual
union all
select 'MEMORY                  ' section, case when exists (select 1 from &PDB_MEMORY_SOURCE) then 'collected' else 'NO METRICS COLLECTED' end result from dual
union all
select 'PDB-SIZE-HISTORY        ' section, case when exists (select 1 from &PDB_SIZE_HISTORY_SOURCE) then 'collected' else 'NO METRICS COLLECTED' end result from dual
union all
select 'PDB-MEMORY-HISTORY      ' section, case when exists (select 1 from &PDB_MEMORY_HISTORY_SOURCE) then 'collected' else 'NO METRICS COLLECTED' end result from dual
union all
select 'PDB-METRICS             ' section, case when exists (select 1 from &PDB_METRICS_SOURCE) then 'collected' else 'NO METRICS COLLECTED' end result from dual;
set heading on
set pagesize 50000
prompt
prompt A section marked NO METRICS COLLECTED produced no rows and is absent from
prompt the .out entirely. Snapshot-history sections are the ones sizing needs; if
prompt they are empty the collection cannot be plotted.
spool off

set timing on
set heading on
set pagesize 50000
set feedback on


prompt Completed PDB Extract Script!
prompt Collection File : &SPOOL_FILE_NAME
