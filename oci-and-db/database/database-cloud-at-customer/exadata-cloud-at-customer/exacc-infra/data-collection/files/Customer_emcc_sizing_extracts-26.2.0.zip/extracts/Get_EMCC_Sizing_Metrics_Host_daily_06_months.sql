rem
rem Version 1.10
define __version__ = 1.10
rem

rem Version History
rem
rem 2021-02-08    1.10  tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.9   tmf     Added timing off
rem 2020-11-19    1.8   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.7   tmf     Re-factored query to include metric GUIDs
rem 2020-10-11    1.6   tmf     Re-factored query & added processes metrics
rem 2020-08-18    1.5   tmf     Added sample filter by dbmachine
rem 2020-04-18    1.4   tmf     Added timing capture
rem 2020-03-23    1.3   tmf     Changed extracts to interval based extracts
rem 2020-03-22    1.2   tmf     Added more specific extract header
rem 2020-03-20    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting Host daily metrics 03 to 06 months...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_metrics_host_daily_06_months.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_metrics_host_daily_06_months.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","METRIC_LABEL","COLUMN_LABEL","METRIC_NAME","METRIC_COLUMN","ROLLUP_TIMESTAMP_UTC","MINIMUM","MAXIMUM","AVERAGE","STANDARD_DEVIATION","SAMPLE_COUNT"

WITH t AS
(
 SELECT /*+ MATERIALIZE */
        target_guid, timezone_region
 FROM   sysman.mgmt$target
 WHERE  target_type = 'host'
 AND    target_name IN (
                        SELECT host_name
                        FROM   sysman.mgmt$target
                        WHERE  target_type = 'oracle_database'
                        UNION
                        SELECT member_target_name
                        FROM   sysman.mgmt$target_flat_members
                        WHERE  member_target_type     = 'host'
                        AND    aggregate_target_type IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
                       )
/*
 AND    target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type     = 'host'
 AND    aggregate_target_name IN
(
 'DB Machine m1.us.oracle.com'
,'DB Machine m2.us.oracle.com'
)
)
*/
)
SELECT RAWTOHEX(a.target_guid) AS target_guid
      ,a.target_name
      ,a.target_type
      ,a.metric_label
      ,a.column_label
      ,a.metric_name
      ,a.metric_column
      ,TO_CHAR(CAST(FROM_TZ(CAST(a.rollup_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS rollup_timestamp_utc
      ,NVL(a.minimum,            0)              AS minimum
      ,NVL(a.maximum,            0)              AS maximum
      ,NVL(a.average,            0)              AS average
      ,NVL(a.standard_deviation, 0)              AS standard_deviation
      ,NVL(a.sample_count,       0)              AS sample_count
FROM   t, sysman.mgmt$metric_daily a
WHERE  a.rollup_timestamp >= ADD_MONTHS(SYSDATE, -6)
AND    a.rollup_timestamp  < ADD_MONTHS(SYSDATE, -3)
AND    a.target_guid       = t.target_guid
AND    a.metric_guid      IN
(
 HEXTORAW('96A4450DF8E0783843BAEFF1A776D4B4') -- Load, Active Logical Memory, Kilobytes
,HEXTORAW('605AA783A704368A348193D2029B2DB9') -- Load, Active Memory, Kilobytes
,HEXTORAW('0C71A1AFAC2D7199013837DA35522C08') -- Load, CPU Utilization (%)
,HEXTORAW('86821B5F0CE858D6E4A7F7390E88B73C') -- Load, Memory Utilization (%)
,HEXTORAW('D45065365A8F953AC4D320F2CE7B03A9') -- Load, Swap Utilization (%)
,HEXTORAW('D55DAAED6A6EC551B47C2928A532682E') -- Load, Swap Utilization, Kilobytes
,HEXTORAW('3B0621994E125B3D52CDC9049925A859') -- Load, Total Processes
,HEXTORAW('F100D41346B94C8D69AED1682C759D81') -- Load, Used Logical Memory (%)
,HEXTORAW('2A6F5C26DFD1AC678EAE7E1AFDD63834') -- Flash_Cache_IORM_PDB_Metric, pdb_fc_by_allocated (MB)
,HEXTORAW('E577644CB99554603A192471AA9F8B0A') -- Flash_Cache_IORM_DB_Metric, db_fc_by_allocated (MB)
);

spool off

spool emcc_sizing_extracts/emcc_sizing_metrics_host_daily_06_months.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
