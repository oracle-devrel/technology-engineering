rem
rem Version 1.1
define __version__ = 1.1
rem

rem Version History
rem
rem 2021-03-31    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting Exadata properties...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_exadata_props.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_exadata_props.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","NAME","VALUE","EXTRACT_DTTM_UTC"

SELECT RAWTOHEX(p.target_guid) AS target_guid
      ,p.target_name
      ,p.target_type
      ,p.property_name
      ,p.property_value
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')
FROM   sysman.mgmt$target_properties p
WHERE  p.target_type          = 'oracle_exadata'
AND    TRIM(p.property_value) IS NOT NULL
AND    p.property_name        IN (
                                  'orcl_gtp_os'
                                 ,'orcl_gtp_platform'
                                 ,'orcl_gtp_target_version'
                                 ,'VersionCategory'
                                 ,'releaseVersion'
                                 ,'MetricSource'
                                 );

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_exadata_props.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
