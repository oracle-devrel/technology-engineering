rem
rem Version 1.1
rem

rem Version History
rem
rem 2020-11-05    1.1  tmf     First version
rem

SELECT guid
FROM
(
SELECT   DISTINCT
         ',HEXTORAW(''' || a.metric_guid || ''') -- ' || a.metric_label || ', ' || a.column_label AS guid
        ,a.metric_label, a.column_label
FROM     sysman.mgmt$target_type a
WHERE    a.metric_label IN (
                            'Load'
                           )
AND      a.column_label IN (
                            'Active Logical Memory, Kilobytes'
                           ,'Active Memory, Kilobytes'
                           ,'CPU Steal Time (%)'
                           ,'CPU Utilization (%)'
                           ,'CPU in I/O Wait (%)'
                           ,'CPU in System Mode (%)'
                           ,'CPU in User Mode (%)'
                           ,'Memory Utilization (%)'
                           ,'Swap Utilization (%)'
                           ,'Swap Utilization, Kilobytes'
                           ,'Total Processes', 'Used Logical Memory (%)'
                           )
AND      a.target_type   = 'host'
ORDER BY a.metric_label, a.column_label
);


(
 HEXTORAW('96A4450DF8E0783843BAEFF1A776D4B4') -- Load, Active Logical Memory, Kilobytes
,HEXTORAW('605AA783A704368A348193D2029B2DB9') -- Load, Active Memory, Kilobytes
,HEXTORAW('0D6560A45A4A60CA3C925403F6D897C9') -- Load, CPU Steal Time (%)
,HEXTORAW('0C71A1AFAC2D7199013837DA35522C08') -- Load, CPU Utilization (%)
,HEXTORAW('DF8067B7D515747434B58D69230B8451') -- Load, CPU in I/O Wait (%)
,HEXTORAW('706949E8A2D021044A4FDE15CB070696') -- Load, CPU in System Mode (%)
,HEXTORAW('266023CB8320264FF496AD70411C49E0') -- Load, CPU in User Mode (%)
,HEXTORAW('86821B5F0CE858D6E4A7F7390E88B73C') -- Load, Memory Utilization (%)
,HEXTORAW('D45065365A8F953AC4D320F2CE7B03A9') -- Load, Swap Utilization (%)
,HEXTORAW('D55DAAED6A6EC551B47C2928A532682E') -- Load, Swap Utilization, Kilobytes
,HEXTORAW('3B0621994E125B3D52CDC9049925A859') -- Load, Total Processes
,HEXTORAW('F100D41346B94C8D69AED1682C759D81') -- Load, Used Logical Memory (%)
)