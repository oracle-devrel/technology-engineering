rem
rem Version 1.8
define __version__ = 1.8
rem

rem Version History
rem
rem 2021-02-08    1.8   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.7   tmf     Added timing off
rem 2020-11-27    1.6   tmf     Added ExaCC target type
rem 2020-11-19    1.5   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.4   tmf     mkdir -p
rem 2020-10-11    1.3   tmf     Re-factored query
rem 2020-04-18    1.2   tmf     Added timing capture
rem 2020-03-10    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting Host properties...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_host_props.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_host_props.csv

prompt "TARGET_GUID","TARGET_NAME","SOURCE","NAME","VALUE","EXTRACT_DTTM_UTC"

SELECT RAWTOHEX(h.target_guid) AS target_guid
      ,h.target_name
      ,p.source
      ,p.name
      ,p.value
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')
FROM   sysman.cm$mgmt_ecm_os_property p
      ,sysman.mgmt$target               h
WHERE  h.target_guid = p.cm_target_guid
AND    h.target_type = 'host'
AND    p.source       = '/sbin/sysctl'
AND    p.name        IN (
                         'vm.nr_hugepages'
                        )
AND    h.target_name IN (
                         SELECT host_name
                         FROM   sysman.mgmt$target
                         WHERE  target_type = 'oracle_database'
                         UNION
                         SELECT member_target_name
                         FROM   sysman.mgmt$target_flat_members
                         WHERE  member_target_type    = 'host'
                         AND    aggregate_target_type IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
                        )
/*
 AND   h.target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type    IN ('oracle_database', 'rac_database')
 AND    aggregate_target_name IN
(
 'DB Machine m1.us.oracle.com'
,'DB Machine m2.us.oracle.com'
)
)
*/;

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_host_props.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
