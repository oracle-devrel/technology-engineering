rem
rem Version 1.1
define __version__ = 1.1
rem

rem Version History
rem
rem 2022-05-05    1.1   mgr     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting List of EM Jobs...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_em_jobs.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_em_jobs.csv

prompt "JOB_NAME","FAILURE_COUNT","LAST_START_DATE","NEXT_RUN_DATE"

SELECT job_name
	,failure_count
	,last_start_date
	,next_run_date
FROM dba_scheduler_jobs
WHERE owner = 'SYSMAN';
SELECT name
	,value
	,'' as col3
	,'' as col4
FROM v$parameter
WHERE name = 'job_queue_processes';

spool off

spool emcc_sizing_extracts/emcc_sizing_em_jobs.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
