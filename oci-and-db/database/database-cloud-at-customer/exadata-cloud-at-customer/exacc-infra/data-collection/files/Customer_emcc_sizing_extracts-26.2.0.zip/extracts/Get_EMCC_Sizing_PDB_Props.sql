rem
rem Version 1.8
define __version__ = 1.8
rem

rem Version History
rem
rem 2021-02-08    1.8   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.7   tmf     Added timing off
rem 2020-11-19    1.6   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.5   tmf     mkdir -p
rem 2020-10-11    1.4   tmf     Added missing append
rem 2020-04-18    1.3   tmf     Added timing capture
rem 2020-03-10    1.2   tmf     Added Version property
rem 2020-03-09    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting PDB properties...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_pdb_props.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_pdb_props.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","NAME","VALUE","EXTRACT_DTTM_UTC"

SELECT RAWTOHEX(p.target_guid) AS target_guid
      ,p.target_name
      ,p.target_type
      ,p.property_name
      ,p.property_value
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')
FROM   sysman.mgmt$target_properties p
WHERE  p.target_type           = 'oracle_pdb'
AND    TRIM(p.property_value) IS NOT NULL
AND    p.property_name        IN (
                                  'orcl_gtp_cost_center'
                                 ,'orcl_gtp_department'
                                 ,'orcl_gtp_lifecycle_status'
                                 ,'orcl_gtp_line_of_bus'
                                 ,'orcl_gtp_location'
                                 ,'Version'
                                 );

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_pdb_props.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
