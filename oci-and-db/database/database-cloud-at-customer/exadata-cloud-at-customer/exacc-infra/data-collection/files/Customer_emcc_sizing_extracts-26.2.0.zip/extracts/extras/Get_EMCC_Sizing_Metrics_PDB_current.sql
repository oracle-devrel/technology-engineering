rem
rem Version 1.6
define __version__ = 1.6
rem

rem Version History
rem
rem 2021-02-08    1.6   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.5   tmf     Added timing off
rem 2020-11-19    1.4   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.3   tmf     Re-factored query to include metric GUIDs
rem 2020-10-13    1.2   tmf     Fixed bug in extraction filter
rem 2020-10-11    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting PDB current metrics...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_metrics_pdb_current.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_metrics_pdb_current.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","METRIC_LABEL","COLUMN_LABEL","METRIC_NAME","METRIC_COLUMN","COLLECTION_TIMESTAMP_UTC","VALUE_AS_NUM"

WITH t AS
(
 SELECT /*+ MATERIALIZE */
        target_guid, timezone_region
 FROM   sysman.mgmt$target
 WHERE  target_type = 'oracle_pdb'
/*
 AND    target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type     = 'oracle_pdb'
 AND    aggregate_target_name IN
(
 'DB Machine m1.us.oracle.com'
,'DB Machine m2.us.oracle.com'
)
)
*/
)
SELECT RAWTOHEX(a.target_guid) AS target_guid
      ,a.target_name
      ,a.target_type
      ,a.metric_label
      ,a.column_label
      ,a.metric_name
      ,a.metric_column
      ,TO_CHAR(CAST(FROM_TZ(CAST(a.collection_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS collection_timestamp_utc
      ,TO_NUMBER(a.value) AS value_as_num
FROM   t, sysman.mgmt$metric_current a
WHERE  a.target_guid  = t.target_guid
AND    a.metric_guid IN
(
 HEXTORAW('93E2A2A1BE9A31F2471A1E5A30DA9687') -- Database Size, Allocated Space(GB)
,HEXTORAW('F1EF5C6911C3254F6370054CBE04C294') -- Database Size, Used Space(GB)
);

spool off

spool emcc_sizing_extracts/emcc_sizing_metrics_pdb_current.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
