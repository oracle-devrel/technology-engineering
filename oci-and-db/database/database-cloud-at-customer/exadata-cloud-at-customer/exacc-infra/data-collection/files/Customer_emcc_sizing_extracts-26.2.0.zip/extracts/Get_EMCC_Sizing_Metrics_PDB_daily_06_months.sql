rem
rem Version 1.12
define __version__ = 1.12
rem

rem Version History
rem
rem 2021-02-08    1.12  tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.11  tmf     Added timing off
rem 2020-11-19    1.10  tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.9   tmf     Re-factored query to include metric GUIDs
rem 2020-10-13    1.8   tmf     Fixed bug in extraction filter
rem 2020-10-11    1.7   tmf     Re-factored query
rem 2020-08-18    1.6   tmf     Added sample filter by dbmachine
rem 2020-04-18    1.5   tmf     Added timing capture
rem 2020-03-26    1.4   tmf     Added allocated database size
rem 2020-03-23    1.3   tmf     Changed extracts to interval based extracts
rem 2020-03-22    1.2   tmf     Added more specific extract header
rem 2020-03-20    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting PDB daily metrics 03 to 06 months...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_metrics_pdb_daily_06_months.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_metrics_pdb_daily_06_months.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","METRIC_LABEL","COLUMN_LABEL","METRIC_NAME","METRIC_COLUMN","ROLLUP_TIMESTAMP_UTC","MINIMUM","MAXIMUM","AVERAGE","STANDARD_DEVIATION","SAMPLE_COUNT"

WITH t AS
(
 SELECT /*+ MATERIALIZE */
        target_guid, timezone_region
 FROM   sysman.mgmt$target
 WHERE  target_type = 'oracle_pdb'
/*
 AND    target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type     = 'oracle_pdb'
 AND    aggregate_target_name IN
(
 'DB Machine m1.us.oracle.com'
,'DB Machine m2.us.oracle.com'
)
)
*/
)
SELECT RAWTOHEX(a.target_guid) AS target_guid
      ,a.target_name
      ,a.target_type
      ,a.metric_label
      ,a.column_label
      ,a.metric_name
      ,a.metric_column
      ,TO_CHAR(CAST(FROM_TZ(CAST(a.rollup_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS rollup_timestamp_utc
      ,NVL(a.minimum,            0)              AS minimum
      ,NVL(a.maximum,            0)              AS maximum
      ,NVL(a.average,            0)              AS average
      ,NVL(a.standard_deviation, 0)              AS standard_deviation
      ,NVL(a.sample_count,       0)              AS sample_count
FROM   t, sysman.mgmt$metric_daily a
WHERE  a.rollup_timestamp >= ADD_MONTHS(SYSDATE, -6)
AND    a.rollup_timestamp  < ADD_MONTHS(SYSDATE, -3)
AND    a.target_guid       = t.target_guid
AND    a.metric_guid      IN
(
 HEXTORAW('93E2A2A1BE9A31F2471A1E5A30DA9687') -- Database Size, Allocated Space(GB)
,HEXTORAW('F1EF5C6911C3254F6370054CBE04C294') -- Database Size, Used Space(GB)
);

spool off

spool emcc_sizing_extracts/emcc_sizing_metrics_pdb_daily_06_months.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
