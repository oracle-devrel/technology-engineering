apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
  - resource-quota.yml
  - limit-range.yml
  - network-policies.yml
