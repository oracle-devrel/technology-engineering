# Shared chart values.
