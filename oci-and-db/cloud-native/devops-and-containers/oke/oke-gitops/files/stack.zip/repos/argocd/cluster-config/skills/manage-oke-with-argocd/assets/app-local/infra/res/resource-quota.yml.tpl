apiVersion: v1
kind: ResourceQuota
metadata:
  name: __APP__
spec:
  hard:
    requests.cpu: "2"
    requests.memory: 2Gi
    limits.cpu: "4"
    limits.memory: 4Gi
    persistentvolumeclaims: "0"
