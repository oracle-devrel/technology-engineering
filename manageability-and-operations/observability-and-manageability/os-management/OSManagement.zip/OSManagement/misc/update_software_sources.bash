#!/bin/bash

source ~/tmp/oracle-cli/bin/activate

python update_software_source.py --group OracleLinux8_ManagedInstanceGroup1 --golden_instance OL8GoldenInstance1
python update_software_source.py --group OracleLinux8_ManagedInstanceGroup2 --golden_instance OL8GoldenInstance2

python update_software_source.py --group OracleLinux9_ManagedInstanceGroup1 --golden_instance OL9GoldenInstance1
python update_software_source.py --group OracleLinux9_ManagedInstanceGroup2 --golden_instance OL9GoldenInstance2
