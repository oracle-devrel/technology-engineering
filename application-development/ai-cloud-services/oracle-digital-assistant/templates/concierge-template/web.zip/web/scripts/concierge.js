var Concierge = {
// ODA URI, only hostname part ending with / but without the https://
	URI: 'oda-cbd0e340508940078eaec9d0547fecfb-da4.data.digitalassistant.oci.oraclecloud.com/',
// Channel ID, available in channel settings in ODA UI
	channelId: '3ac36e96-da64-4867-8d0c-dd7e2b3a6b55',
	defaultLanguage: 'en',
	i18n: {                                        // Provide translations for strings used in the widget
		ar: { // Some sample Arabic translations
			buttonText: 'كيف يمكنني مساعدك؟',          // Message next to popup-button on webpage
			leftButton: 'اعادة البدء',                 // Text on left-bottom button
			leftButtonSend: 'أهلاً',                     // Message send when left-bottom button
			rightButton: 'قائمة',                      // Text on right-bottom button
			rightButtonSend: 'قائمة',                  // Message send when right-bottom button
			chatTitle: 'مساعد أوراكل',                 // Set title at chat header
			connected: 'متصل',         		             // Replaces Connected
			inputPlaceholder: 'اكتب رسالة',            // Replaces Type a message
			send: 'إرسال',                             // Replaces Send tool tip
			audioResponseOff: 'مكبر الصوت متوقف',      // Tool tip for the speaker off button
			audioResponseOn: 'مكبر الصوت قيد التشغيل', // Tool tip for the speaker on button
			upload: 'رفع',                             // Tooltip that appears when hovering over upload button in footer.
			speak: 'يتكلم',                            // Tooltip for mic button
	},                                             
		en: {                                        
			buttonText: 'How can I help you?',         // Message next to popup-button on webpage
			leftButton: 'Restart',                     // Text on left-bottom button
			leftButtonSend: 'Hi',                      // Message send when left-bottom button
			rightButton: 'Menu',                       // Text on right-bottom button
			rightButtonSend: 'Menu',                   // Message send when right-bottom button
			chatTitle: 'Oracle Assistant',             // Set title at chat header
			connected: 'Connected',         		       // Replaces Connected
			inputPlaceholder: 'Type a message',        // Replaces Type a message
			send: 'Send',                              // Replaces Send tool tip
			audioResponseOff: 'Speaker off',           // Tool tip for the speaker off button
			audioResponseOn: 'Speaker on',             // Tool tip for the speaker on button
			upload: 'Upload',                          // Tooltip that appears when hovering over upload button in footer.
			speak: 'Speak',                            // Tooltip for mic button
//more texts to copy to your language translations:
      attachment_audio: "Audio attachment",
      attachment_file: "File attachment",
      attachment_image: "Image attachment",
      attachment_video: "Video attachment",
      attachmentAudioFallback: "Your browser does not support embedded audio. However you can {0}download it{/0}.",
      attachmentVideoFallback: "Your browser does not support embedded video. However you can {0}download it{/0}.",
      avatarAgent: "Agent icon",
      avatarBot: "Bot icon",
      avatarUser: "User icon",
      card: "Card {0}",
      cardImagePlaceholder: "Card image",
      cardNavNext: "Next card",
      cardNavPrevious: "Previous card",
      clear: "Clear conversation",
      close: "Close widget",
      closing: "Closing",
      connecting: "Connecting",
      connectionFailureMessage: "Sorry, the assistant is unavailable right now. If the issue persists, contact your help desk.",
      connectionRetryLabel: "Try Again",
      defaultGreetingMessage: "Hey, Nice to meet you! Allow me a moment to get back to you.",
      defaultWaitMessage: "I'm still working on your request. Thank you for your patience!",
      defaultSorryMessage: "I'm sorry. I can't get you the right content. Please try again.",
      disconnected: "Disconnected",
      download: "Download",
      endConversation: "End Conversation",
      endConversationConfirmMessage: "Are you sure you want to end the conversation?",
      endConversationDescription: "This will also clear your conversation history.",
      errorSpeechInvalidUrl: "ODA URL for connection is not set. Please pass 'URI' parameter during SDK initialization.",
      errorSpeechMultipleConnection: "Another voice recognition is ongoing. can't start a new one.",
      errorSpeechTooMuchTimeout: "The voice message is too long to recognize and generate text.",
      errorSpeechUnavailable: "To allow voice messaging, update your browser settings to enable access to your microphone.",
      errorSpeechUnsupportedLocale: "The locale set for voice recognition is not supported. Please use a valid locale in 'speechLocale' setting.",
      imageViewerClose: "Close image viewer",
      imageViewerOpen: "Open image viewer",
      itemIterator: "Item {0}",
      language_ar: "Arabic",
      language_de: "German",
      language_detect: "Detect Language",
      language_en: "English",
      language_hi: "Hindi",
      language_es: "Spanish",
      language_fr: "French",
      language_it: "Italian",
      language_nl: "Dutch",
      language_pt: "Portuguese",
      languageSelectDropdown: "Select chat language",
      linkField: "Click on the highlighted text to open Link for {0}",
      noSpeechTimeout: "The voice could not be detected to perform recognition.",
      noText: "No",
      openMap: "Open Map",
      previousChats: "End of previous conversation",
      ratingStar: "Rate {0} star",
      recognitionTextPlaceholder: "Speak your message",
      relTimeDay: "{0}d ago",
      relTimeHr: "{0}hr ago",
      relTimeMin: "{0}min ago",
      relTimeMoment: "A few seconds ago",
      relTimeMon: "{0}mth ago",
      relTimeNow: "Now",
      relTimeYr: "{0}yr ago",
      requestLocation: "Requesting location",
      requestLocationDeniedPermission: "To allow sharing your location, update your browser settings to enable access to your location. You can also type in the location instead.",
      requestLocationDeniedTimeout: "It is taking too long to get your location. .concat(r)",
      requestLocationDeniedUnavailable: "Your current location is unavailable. .concat(r)",
      retryMessage: "Try again",
      shareAudio: "Share Audio",
      shareFailureMessage: "Sorry, sharing is not available on this device.",
      shareFile: "Share File",
      shareLocation: "Share Location",
      shareVisual: "Share Image/Video",
      skillMessage: "Skill says",
      showOptions: "Show Options",
      typingIndicator: "Waiting for response",
      uploadFailed: "Upload Failed.",
      uploadFileSizeLimitExceeded: "File size should not be more than {0}MB.",
      uploadFileSizeZeroByte: "Files of size zero bytes can't be uploaded.",
      uploadUnsupportedFileType: "Unsupported file type.",
      userMessage: "I say",
      utteranceGeneric: "Message from skill.",
      webViewAccessibilityTitle: "In-widget WebView to display links",
      webViewClose: "Done",
      webViewErrorInfoDismiss: "Dismiss",
      webViewErrorInfoText: "Don’t see the page? {0}Click here{/0} to open it in a browser.",
      yesText: "Yes",
		}
	}
}






//@@md230130
switch (Concierge.defaultLanguage) {
  case 'ar':
		Concierge.buttonText = Concierge.i18n.ar.buttonText;
		Concierge.leftButton = Concierge.i18n.ar.leftButton;
		Concierge.leftButtonSend = Concierge.i18n.ar.leftButtonSend;
		Concierge.rightButton = Concierge.i18n.ar.rightButton;
		Concierge.rightButtonSend = Concierge.i18n.ar.rightButtonSend;
    break;
  default:
		Concierge.buttonText = Concierge.i18n.en.buttonText;
		Concierge.leftButton = Concierge.i18n.en.leftButton;
		Concierge.leftButtonSend = Concierge.i18n.en.leftButtonSend;
		Concierge.rightButton = Concierge.i18n.en.rightButton;
		Concierge.rightButtonSend = Concierge.i18n.en.rightButtonSend;
}

function getConciergeValues(chatWidgetSettings) {
	chatWidgetSettings.URI                      = Concierge.URI;
	chatWidgetSettings.channelId                = Concierge.channelId;
	chatWidgetSettings.multiLangChat.primary    = Concierge.defaultLanguage;
	chatWidgetSettings.i18n                     = Concierge.i18n;
}

function customizeLaunchButton() {
	const launchButton = document.querySelector('.oda-chat-button');
	if (launchButton) {
		const element = document.createElement('div');
		element.setAttribute('dir', 'auto');
		element.setAttribute('class', 'oda-chat-letschat');
		const innerText = document.createTextNode(Concierge.buttonText);
		element.appendChild(innerText);
		launchButton.appendChild(element);
	}
}	

function addFooterButtons() {
	//@@md230130 footerButtons
	var footerBtnsDiv = document.createElement("div");
	footerBtnsDiv.className = 'footerBtns';
	// footButtonLeft
	var footerButtonLeft = document.createElement("button");
	footerButtonLeft.className = 'footerButtonLeft';
	footerButtonLeft.innerHTML =  Concierge.leftButton;
	footerButtonLeft.addEventListener("click", function() {
		 Bots.sendMessage(Concierge.leftButtonSend);
	});
	// footerButtonRight
	var footerButtonRight = document.createElement("button");
	footerButtonRight.className = 'footerButtonRight';
	footerButtonRight.setAttribute("id", "footerButtonRightId");
	footerButtonRight.innerHTML =  Concierge.rightButton;
	footerButtonRight.addEventListener("click", function() {
		Bots.sendMessage(Concierge.rightButtonSend);
	}); 
	// footerButtons append
	var divWrapper = document.getElementsByClassName("oda-chat-widget")[0];
	footerBtnsDiv.appendChild(footerButtonLeft);
	footerBtnsDiv.appendChild(footerButtonRight);
	divWrapper.appendChild(footerBtnsDiv);
}
