'use strict';

/**
 * SDK instantiation in client auth disabled mode. This mechanism is preferred for initial integration of the SDK with
 * the web app.
 * When client authentication has been disabled, only connections made from unblocked lists (allowed domains) are
 * allowed at the server. This use case is recommended when the client application can’t generate a signed JWT (because
 * of a static website or no authentication mechanism for the web/mobile app) but requires ODA integration. It can also
 * be used when the chat widget is already secured and visible to only authenticated users in the client platforms (Web
 * Application with the protected page).
 * For other cases, it is recommended that client auth enabled mode is used when using the SDK for production as it adds
 * another layer of security when connecting to a DA/skill.
 */

 /**
 * Initializes the SDK and sets a global field with passed name
 * @param {string} name Name by which the chat widget should be referred
 */
function initSdk(name) {
	// Retry initialization later if the web page hasn't finished loading or the WebSDK is not available yet
	if (!document || !document.body || !WebSDK) {
		setTimeout(function() {
			initSdk(name);
		}, 2000);
		return;
	}
	if (!name) {
		name = 'Bots';          // Set default reference name to 'Bots'
	}
	var Bots;

	/**
	 * SDK configuration settings
	 * In client auth disabled mode, 'URI' and 'channelId' fields must be passed.
	 */
	var chatWidgetSettings = {
		URI: 'tbs', //oda-cbd0e340508940078eaec9d0547fecfb-da4.data.digitalassistant.oci.oraclecloud.com//',    // ODA URI, only the hostname part should be passed, without the https://
		channelId: 'tbc', //'3ac36e96-da64-4867-8d0c-dd7e2b3a6b55',   // Channel ID, available in channel settings in ODA UI
		// userId: '<userID>',                      // User ID, optional field to personalize user experience
		enableAutocomplete: true,                   // Enables autocomplete suggestions on user input
		enableBotAudioResponse: true,               // Enables audio utterance of skill responses
		enableClearMessage: true,                   // Enables display of button to clear conversation
		enableSpeech: true,                         // Enables voice recognition
		//enableDraggableButton:true,
		initUserHiddenMessage: "Hi",
		showConnectionStatus: true,                 // Displays current connection status on the header
		width:"450px",
		height:"700px",
		i18n: {                                 // Provide translations for the strings used in the widget
			en: {                                 // en locale, can be configured for any locale
				chatTitle: 'Oracle Assistant'       // Set title at chat header
			},
			ar: {                                 // en locale, can be configured for any locale
				chatTitle: 'Oracle Assistant',      // Set title at chat header
				connected: 'Connected',         		// Replaces Connected
				inputPlaceholder: 'Type a message', // Replaces Type a message
				send: 'Send',                       // Replaces Send tool tip
				audioResponseOff: 'Speaker off',    // Tool tip for the speaker off button
				audioResponseOn: 'Speaker on',      // Tool tip for the speaker on button
				upload: 'Upload',                   // Tooltip that appears when hovering over upload button in footer.
				speak: 'Speak',                     // Tooltip for mic button
				language_detect: 'Auto'             // 'Detect Language' in dropdown
			}
		},
		multiLangChat: {
			supportedLangs: [
			{
				lang: 'en',
				label: 'EN'
			}, {
				lang: 'ar',
				label: 'AR'
			}],
			primary: 'en'
		},
		font:'16px "OracleSansVF", Helvetica, Arial, sans-serif',
		timestampMode: 'relative',                  // Sets the timestamp mode, relative to current time or default (absolute)
		theme:WebSDK.THEME.REDWOOD_DARK ,         // Redwood dark theme. The default is THEME.DEFAULT, while older theme is available as THEME.CLASSIC
		icons: {
			launch:'images/botButtonIcon.gif',
			logo:'images/botIcon.png',
			avatarAgent: '<svg xmlns="http://www.w3.org/2000/svg" height="32" width="32"><path fill="black" d="M12 2c5.523 0 10 4.477 10 10a9.982 9.982 0 01-3.804 7.85L18 20a9.952 9.952 0 01-6 2C6.477 22 2 17.523 2 12S6.477 2 12 2zm2 16h-4a2 2 0 00-1.766 1.06c1.123.6 2.405.94 3.766.94s2.643-.34 3.765-.94a1.997 1.997 0 00-1.616-1.055zM12 4a8 8 0 00-5.404 13.9A3.996 3.996 0 019.8 16.004L10 16h4c1.438 0 2.7.76 3.404 1.899A8 8 0 0012 4zm0 2c2.206 0 4 1.794 4 4s-1.794 4-4 4-4-1.794-4-4 1.794-4 4-4zm0 2c-1.103 0-2 .897-2 2s.897 2 2 2 2-.897 2-2-.897-2-2-2z" fill="#100f0e" fill-rule="evenodd"/></svg>',
			avatarUser: 'images/personIcon.png',
			avatarBot: 'images/botIcon.png'
		},
		colors:	{
	//	branding: '#152E85',                    // headerbar background & hover footer buttons
	//	headerBackground: '#152E85',            // Same as branding. The background color of chat widget's header
	//	botMessageBackground: '#F0F0F0',        // Background of response message bubble
	//	userMessageBackground: '#152E85',       // Background of user message bubble
	//	text: '#87AB7A',                        // card-question
	//	botText: '#1D1B1B',                     // Response text from bot
	//	headerText: '#FFFFFF',                  // Header text
	//	headerButtonFill: '#FFFFFF',            // Header text
	//	userText: '#FFFFFF',                    // User text
	//	textLight: '#1D1B1B',                   // card-answer
	//	inputText: '#1D1B1B',                   // The text color in the message input field. Overrides text if passed.
	//	footerBackground: '#ffffff',            // Chat widget footer background
	//	cardBackground: '#F0F0F0',              // Card background
	//	actionsBorder: '#152E85',								// The action button border color
	//	actionsText: '#152E85',									// The action button text color
	//	actionsBackground: '#FFFFFF',           // action button background
	//	actionsTextHover: '#FFFFFF',						// The action button text color on hover
	//	actionsTextFocus: '#FFFFFF',						// The action button text color on focus
	//	actionsBackgroundHover: '#152E85',      // action button background
	//	actionsBackgroundFocus: '#152E85',      // action button background
	//	globalActionsBorder: '#152E85',	        // The global action button border color
	//	globalActionsText: '#152E85',           // The global action button text color
	//	globalActionsBackground: '#FFFFFF',			// The global action button background color
	//	globalActionsTextHover: '#FFFFFF',			// The global action button text color on hover
	//	globalActionsTextFocus: '#FFFFFF',			// The global action button text color on focus
	//	globalActionsBackgroundHover: '#152E85',// The global action button background color on hover
	//	globalActionsBackgroundFocus: '#152E85',// The global action button background color on focus
	//	ratingStar: '#808080',									// The color applied to initial unselected rating stars of feedback message
	//	ratingStarFill: '#FFE22B',							// The color applied to rating stars of feedback message on hover or selection. The branding color is used if this is not passed
	//	timestamp: '#000420' 					          // Timestamp header and relative timestamp in messages
		},
	};
	
	getConciergeValues(chatWidgetSettings); //@@md220130 ConciergeTemplate

	Bots = new WebSDK(chatWidgetSettings);

	// Connect to skill when the widget is expanded for the first time
	var isFirstConnection = true;
	Bots.on(WebSDK.EVENT.WIDGET_OPENED, function() {
		if (isFirstConnection) {
			Bots.connect();
			isFirstConnection = false;
		}
	});

	var letChatTimeout = null;
	const odaChatButtons = document.getElementsByClassName("oda-chat-button");
	//const odaChatButtonsText = document.getElementsByClassName("oda-chat-letschat");
	var odaChatButton = odaChatButtons[0];
	//var odaChatButtonText = odaChatButtonsText[0]
	var odaChatButtonClass = odaChatButton.getAttribute("class"); 
	//var odaChatButtonTextClass = odaChatButtonText.getAttribute("class"); 
	letChatTimeout = setTimeout((f => {
		odaChatButtonClass += " oda-chat-chatopen";
		//odaChatButtonTextClass += " oda-chat-letschatShow";
		odaChatButton.setAttribute("class", odaChatButtonClass);
		odaChatButton.setAttribute("id", 'odaChatButtonID');
		//odaChatButtonText.setAttribute("class", odaChatButtonTextClass);
		window.addEventListener("resize", (f => {
				var odaChatButtonClass = odaChatButton.getAttribute("class");
				odaChatButton.setAttribute("class", odaChatButtonClass.replace(" oda-chat-chatopen", ""))
		}))
	}), 5000)
        
	setTimeout((f => {
		var odaChatOpen = document.getElementById("odaChatButtonID");
		odaChatOpen.className= odaChatOpen.className.replace("oda-chat-chatopen", "");
	}), 15000)

	addFooterButtons(); //@@md220130 ConciergeTemplate

	// Create global object to refer Bots
	window[name] = Bots;
	customizeLaunchButton();
}
