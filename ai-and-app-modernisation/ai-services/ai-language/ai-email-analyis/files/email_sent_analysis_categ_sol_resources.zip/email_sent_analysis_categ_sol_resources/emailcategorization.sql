CREATE TABLE email_sentiments (
    email_id                  	VARCHAR2(200)   NOT NULL,
	email_conversation_id		VARCHAR2(200),
	email_created_at            TIMESTAMP,
	email_from_address          VARCHAR2(100),
	email_from_name             VARCHAR2(200),
	email_to_address          	VARCHAR2(100),
	email_to_name             	VARCHAR2(200),
	email_text                  VARCHAR2(5000),
	email_ai_summary			VARCHAR2(1000),
    email_ai_sentiment          VARCHAR2(200),
	email_overall_score			NUMBER,
	email_positive_score        FLOAT,
	email_mixed_score           FLOAT,
	email_neutral_score         FLOAT,
    email_negative_score        FLOAT,
	email_ai_category          	VARCHAR2(200),
	email_ai_subcategory        VARCHAR2(200),
	email_priority				VARCHAR2(50),
	email_status				VARCHAR2(100),
	email_source				VARCHAR2(100),
	email_resolved_at           TIMESTAMP);
	
ALTER TABLE email_sentiments
  ADD CONSTRAINT email_sentiments_pk
  PRIMARY KEY (email_id)
  RELY DISABLE NOVALIDATE;
  
CREATE UNIQUE INDEX email_sentiments_idx ON email_sentiments (email_id);


CREATE TABLE email_sentiments_aspects (
    email_sent_aspect_id         VARCHAR2(200)    NOT NULL,
	email_id                  	 VARCHAR2(200)    NOT NULL,
	emaila_sent_aspect_text      VARCHAR2(200),
    emaila_sentiment             VARCHAR2(200),
	emaila_positive_score        FLOAT,
	emaila_mixed_score           FLOAT,
	emaila_neutral_score         FLOAT,
    emaila_negative_score        FLOAT);
	
ALTER TABLE email_sentiments_aspects
  ADD CONSTRAINT email_sentiments_aspects_pk
  PRIMARY KEY (email_sent_aspect_id)
  RELY DISABLE NOVALIDATE;

ALTER TABLE email_sentiments_aspects
  ADD CONSTRAINT email_sentiments_aspects_fk
  FOREIGN KEY (email_id) REFERENCES email_sentiments (email_id)
  RELY DISABLE NOVALIDATE;
  
CREATE UNIQUE INDEX email_sentiments_aspects_idx1 ON email_sentiments_aspects (email_sent_aspect_id);


CREATE TABLE email_service_requests (
    email_sr_request_id            NUMBER(30)      NOT NULL,
    email_id					   VARCHAR2(200)   NOT NULL,
    email_sr_status                VARCHAR2(50),
    email_from_address		   	   VARCHAR2(100));
	
ALTER TABLE email_service_requests
  ADD CONSTRAINT email_service_requests_pk
  PRIMARY KEY (email_sr_request_id)
  RELY DISABLE NOVALIDATE;

 CREATE UNIQUE INDEX email_service_requests_idx1 ON email_service_requests (email_sr_request_id);

COMMIT;