'use strict';

/**
 * SDK instantiation in client auth disabled mode. This mechanism is preferred for initial integration of the SDK with
 * the web app.
 * When client authentication has been disabled, only connections made from unblocked lists (allowed domains) are
 * allowed at the server. This use case is recommended when the client application can’t generate a signed JWT (because
 * of a static website or no authentication mechanism for the web/mobile app) but requires ODA integration. It can also
 * be used when the chat widget is already secured and visible to only authenticated users in the client platforms (Web
 * Application with the protected page).
 * For other cases, it is recommended that client auth enabled mode is used when using the SDK for production as it adds
 * another layer of security when connecting to a DA/skill.
 */

 /**
 * Initializes the SDK and sets a global field with passed name
 * @param {string} name Name by which the chat widget should be referred
 */
function initSdk(name,lang) {
	// Retry initialization later if the web page hasn't finished loading or the WebSDK is not available yet
	if (!document || !document.body || !WebSDK) {
		setTimeout(function() {
			initSdk(name);
		}, 2000);
		return;
	}
	if (!name) {
		name = 'Bots';          // Set default reference name to 'Bots'
	}
	var Bots;

	var chatWidgetSettings = {
		// userId: '<userID>',                      // User ID, optional field to personalize user experience
		enableAutocomplete: true,                   // Enables autocomplete suggestions on user input
		enableBotAudioResponse: true,               // Enables audio utterance of skill responses
		enableClearMessage: true,                   // Enables display of button to clear conversation
		enableSpeech: true,                         // Enables voice recognition
		//enableDraggableButton:true,
		initUserHiddenMessage: "Hi",
		showConnectionStatus: true,                 // Displays current connection status on the header
		width:"450px",
		height:"700px",
		font:'16px "OracleSansVF", Helvetica, Arial, sans-serif',
		timestampMode: 'relative',                  // Sets the timestamp mode, relative to current time or default (absolute)
		theme:WebSDK.THEME.REDWOOD_DARK ,         // Redwood dark theme. The default is THEME.DEFAULT, while older theme is available as THEME.CLASSIC
		icons: {
			launch:'images/botButtonIcon.gif',
			logo:'images/botIcon.png',
			avatarAgent: '<svg xmlns="http://www.w3.org/2000/svg" height="32" width="32"><path fill="black" d="M12 2c5.523 0 10 4.477 10 10a9.982 9.982 0 01-3.804 7.85L18 20a9.952 9.952 0 01-6 2C6.477 22 2 17.523 2 12S6.477 2 12 2zm2 16h-4a2 2 0 00-1.766 1.06c1.123.6 2.405.94 3.766.94s2.643-.34 3.765-.94a1.997 1.997 0 00-1.616-1.055zM12 4a8 8 0 00-5.404 13.9A3.996 3.996 0 019.8 16.004L10 16h4c1.438 0 2.7.76 3.404 1.899A8 8 0 0012 4zm0 2c2.206 0 4 1.794 4 4s-1.794 4-4 4-4-1.794-4-4 1.794-4 4-4zm0 2c-1.103 0-2 .897-2 2s.897 2 2 2 2-.897 2-2-.897-2-2-2z" fill="#100f0e" fill-rule="evenodd"/></svg>',
			avatarUser: 'images/personIcon.png',
			avatarBot: 'images/botIcon.png'
		},
		i18n: {                                        // Provide translations for strings used in the widget
			en: {                                        
				chatTitle: 'Rotterdam',                       // Set title at chat header
				connected: 'Make it Happen',    // Replaces Connected
				buttonText: 'How can I help you?',         // Message next to popup-button on webpage
				leftButton: 'Restart',                     // Text on left-bottom button
				leftButtonSend: 'Hi',                      // Message send when left-bottom button
				rightButton: 'Menu',                       // Text on right-bottom button
				rightButtonSend: 'Menu',                   // Message send when right-bottom button
				inputPlaceholder: 'Type a message',        // Replaces Type a message
				send: 'Send',                              // Replaces Send tool tip
				audioResponseOff: 'Speaker off',           // Tool tip for the speaker off button
				audioResponseOn: 'Speaker on',             // Tool tip for the speaker on button
				upload: 'Upload',                          // Tooltip that appears when hovering over upload button in footer.
				speak: 'Speak',                            // Tooltip for mic button
	//more texts to copy to your language translations:
				attachment_audio: "Audio attachment",
				attachment_file: "File attachment",
				attachment_image: "Image attachment",
				attachment_video: "Video attachment",
				attachmentAudioFallback: "Your browser does not support embedded audio. However you can {0}download it{/0}.",
				attachmentVideoFallback: "Your browser does not support embedded video. However you can {0}download it{/0}.",
				avatarAgent: "Agent icon",
				avatarBot: "Bot icon",
				avatarUser: "User icon",
				card: "Card {0}",
				cardImagePlaceholder: "Card image",
				cardNavNext: "Next card",
				cardNavPrevious: "Previous card",
				clear: "Clear conversation",
				close: "Close widget",
				closing: "Closing",
				connecting: "Connecting",
				connectionFailureMessage: "Sorry, the assistant is unavailable right now. If the issue persists, contact your help desk.",
				connectionRetryLabel: "Try Again",
				defaultGreetingMessage: "Hey, Nice to meet you! Allow me a moment to get back to you.",
				defaultWaitMessage: "I'm still working on your request. Thank you for your patience!",
				defaultSorryMessage: "I'm sorry. I can't get you the right content. Please try again.",
				disconnected: "Disconnected",
				download: "Download",
	//      endConversation: "Finalizar conversación",
	//      endConversationConfirmMessage: "¿Seguro que quieres terminar la conversación?",
	//      endConversationDescription: "Esto también borrará su historial de conversaciones.",
				endConversation: "End Conversation",
				endConversationConfirmMessage: "Are you sure you want to end the conversation?",
				endConversationDescription: "This will also clear your conversation history.",
				errorSpeechInvalidUrl: "ODA URL for connection is not set. Please pass 'URI' parameter during SDK initialization.",
				errorSpeechMultipleConnection: "Another voice recognition is ongoing. can't start a new one.",
				errorSpeechTooMuchTimeout: "The voice message is too long to recognize and generate text.",
				errorSpeechUnavailable: "To allow voice messaging, update your browser settings to enable access to your microphone.",
				errorSpeechUnsupportedLocale: "The locale set for voice recognition is not supported. Please use a valid locale in 'speechLocale' setting.",
				imageViewerClose: "Close image viewer",
				imageViewerOpen: "Open image viewer",
				itemIterator: "Item {0}",
				language_ar: "Arabic",
				language_de: "German",
				language_detect: "Detect Language",
				language_en: "English",
				language_hi: "Hindi",
				language_es: "Spanish",
				language_fr: "French",
				language_it: "Italian",
				language_nl: "Dutch",
				language_pt: "Portuguese",
				languageSelectDropdown: "Select chat language",
				linkField: "Click on the highlighted text to open Link for {0}",
				noSpeechTimeout: "The voice could not be detected to perform recognition.",
				noText: "No",
				openMap: "Open Map",
				previousChats: "End of previous conversation",
				ratingStar: "Rate {0} star",
				recognitionTextPlaceholder: "Speak your message",
				relTimeDay: "{0}d ago",
				relTimeHr: "{0}hr ago",
				relTimeMin: "{0}min ago",
				relTimeMoment: "A few seconds ago",
				relTimeMon: "{0}mth ago",
				relTimeNow: "Now",
				relTimeYr: "{0}yr ago",
				requestLocation: "Requesting location",
				requestLocationDeniedPermission: "To allow sharing your location, update your browser settings to enable access to your location. You can also type in the location instead.",
				requestLocationDeniedTimeout: "It is taking too long to get your location. .concat(r)",
				requestLocationDeniedUnavailable: "Your current location is unavailable. .concat(r)",
				retryMessage: "Try again",
				shareAudio: "Share Audio",
				shareFailureMessage: "Sorry, sharing is not available on this device.",
				shareFile: "Share File",
				shareLocation: "Share Location",
				shareVisual: "Share Image/Video",
				skillMessage: "Skill says",
				showOptions: "Show Options",
				typingIndicator: "Waiting for response",
				uploadFailed: "Upload Failed.",
				uploadFileSizeLimitExceeded: "File size should not be more than {0}MB.",
				uploadFileSizeZeroByte: "Files of size zero bytes can't be uploaded.",
				uploadUnsupportedFileType: "Unsupported file type.",
				userMessage: "I say",
				utteranceGeneric: "Message from skill.",
				webViewAccessibilityTitle: "In-widget WebView to display links",
				webViewClose: "Done",
				webViewErrorInfoDismiss: "Dismiss",
				webViewErrorInfoText: "Don’t see the page? {0}Click here{/0} to open it in a browser.",
				yesText: "Yes",
				noText: "No"
			}
		}
	};
	
	getConciergeValues(chatWidgetSettings, lang); //@@md220615 ConciergeTemplate
	Bots = new WebSDK(chatWidgetSettings);

	// Connect to skill when the widget is expanded for the first time
	var isFirstConnection = true;
	Bots.on(WebSDK.EVENT.WIDGET_OPENED, function() {
		if (isFirstConnection) {
			Bots.connect();
			isFirstConnection = false;
		}
	});

	var letChatTimeout = null;
	const odaChatButtons = document.getElementsByClassName("oda-chat-button");
	//const odaChatButtonsText = document.getElementsByClassName("oda-chat-letschat");
	var odaChatButton = odaChatButtons[0];
	//var odaChatButtonText = odaChatButtonsText[0]
	var odaChatButtonClass = odaChatButton.getAttribute("class"); 
	//var odaChatButtonTextClass = odaChatButtonText.getAttribute("class"); 
	letChatTimeout = setTimeout((f => {
		odaChatButtonClass += " oda-chat-chatopen";
		//odaChatButtonTextClass += " oda-chat-letschatShow";
		odaChatButton.setAttribute("class", odaChatButtonClass);
		odaChatButton.setAttribute("id", 'odaChatButtonID');
		//odaChatButtonText.setAttribute("class", odaChatButtonTextClass);
		window.addEventListener("resize", (f => {
				var odaChatButtonClass = odaChatButton.getAttribute("class");
				odaChatButton.setAttribute("class", odaChatButtonClass.replace(" oda-chat-chatopen", ""))
		}))
	}), 5000)
        
	setTimeout((f => {
		var odaChatOpen = document.getElementById("odaChatButtonID");
		odaChatOpen.className= odaChatOpen.className.replace("oda-chat-chatopen", "");
	}), 15000)

	addFooterButtons(); //@@md220130 ConciergeTemplate

	// Create global object to refer Bots
	window[name] = Bots;
	customizeLaunchButton();
}
