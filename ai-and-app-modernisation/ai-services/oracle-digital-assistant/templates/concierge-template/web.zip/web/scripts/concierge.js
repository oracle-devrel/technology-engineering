var Concierge = {
// ODA URI, only hostname part ending with / but without the https://
	URI: 'oda-e987987df987a6347856b3456456c34d-fe3.data.digitalassistant.oci.oraclecloud.com/',
// Channel ID, available in channel settings in ODA UI
	channelId: '345fd340-23e1-5d55-7489-123ab6453de9',
	initUserProfile: {
		profile: {
			/* locale: 'nl', */
			firstName: 'Maurits',
			lastName: 'Dijkens',
			email: 'maurits@dijkens.com',
			mobile: '+31652553053',
			properties: {
				company: 'MyCompany',
				botName: 'James',
				page: 'home', 
				justGotUpdated: true
			}
		}
	},
	multiLangChat: {
		supportedLangs: [
		{
			lang: 'en',
			label: 'English'
		}, {
			lang: 'nl-NL',
			label: 'Nederlands'
		}],
		primary: 'nl-NL'
	},
	i18n: {                             // Provide translations for strings used in the widget
		es: {                                        
			chatTitle: 'MyCompany',                          // Set title at chat header
			connected: '¿Le puedo ayudar en algo?',          // Replaces Connected
			buttonText: '¿Le puedo ayudar en algo?',         // Message next to popup-button on webpage
			leftButton: 'Reanudar',                          // Text on left-bottom button
			leftButtonSend: 'Hola',                          // Message send when left-bottom button
			rightButton: 'Menú',                             // Text on right-bottom button
			rightButtonSend: 'Menú',                         // Message send when right-bottom button
			inputPlaceholder: 'Escriba un mensaje',          // Replaces Type a message
			send: 'Enviar',                                  // Replaces Send tool tip
			audioResponseOff: 'Altavoz apagado',             // Tool tip for the speaker off button
			audioResponseOn: 'Orador encendido',             // Tool tip for the speaker on button
			upload: 'Subir',                                 // Tooltip that appears when hovering over upload button in footer.
			speak: 'Hablar',                                 // Tooltip for mic button
      cardNavNext: "siguiente carta",
      cardNavPrevious: "Tarjeta anterior",
      clear: "Conversación clara",
      close: "Cerrar widget",
      closing: "Clausura",
      connecting: "Conectando",
      connectionFailureMessage: "Lo sentimos, el asistente no está disponible en este momento. Si el problema persiste, comuníquese con su mesa de ayuda.",
      connectionRetryLabel: "Intentar otra vez",
      defaultWaitMessage: "Todavía estoy trabajando en su solicitud. ¡Gracias por su paciencia!",
      defaultSorryMessage: "Lo lamento. No puedo conseguirte el contenido adecuado. Inténtalo de nuevo.",
      disconnected: "Desconectado",
      endConversation: "Finalizar conversación",
      endConversationConfirmMessage: "¿Seguro que quieres terminar la conversación?",
      endConversationDescription: "Esto también borrará su historial de conversaciones.",
      errorSpeechUnsupportedLocale: "La configuración regional establecida para el reconocimiento de voz no es compatible. Utilice una configuración regional válida en la configuración 'speechLocale'.",
      itemIterator: "Artículo {0}",
      language_ar: "Arabic",
      language_detect: "Detectar idioma",
      language_en: "English",
      language_es: "Espanol",
      language_nl: "Nederlands",
      languageSelectDropdown: "Seleccione el idioma del chat",
      previousChats: "Fin de la conversación anterior",
      recognitionTextPlaceholder: "Habla tu mensaje",
      relTimeDay: "{0}d antes",
      relTimeHr: "{0}hr antes",
      relTimeMin: "{0}min antes",
      relTimeMoment: "Hace unos segundos",
      relTimeMon: "{0}mth antes",
      relTimeNow: "Ahora",
      relTimeYr: "{0}a antes",
      retryMessage: "Intentar otra vez",
      showOptions: "Mostrar opciones",
      typingIndicator: "Esperando una respuesta",
      webViewClose: "Hecho",
      webViewErrorInfoDismiss: "Despedir",
      noText: "No",
      yesText: "Si"
		},                                             
		ar: { // Some sample Arabic translations
			chatTitle: 'MyCompany',                    // Set title at chat header
			connected: 'كيف يمكنني مساعدك؟',           // Replaces Connected
			buttonText: 'كيف يمكنني مساعدك؟',          // Message next to popup-button on webpage
			leftButton: 'اعادة البدء',                 // Text on left-bottom button
			leftButtonSend: 'أهلاً',                     // Message send when left-bottom button
			rightButton: 'قائمة',                      // Text on right-bottom button
			rightButtonSend: 'قائمة',                  // Message send when right-bottom button
			inputPlaceholder: 'اكتب رسالة',            // Replaces Type a message
			send: 'إرسال',                             // Replaces Send tool tip
			audioResponseOff: 'مكبر الصوت متوقف',      // Tool tip for the speaker off button
			audioResponseOn: 'مكبر الصوت قيد التشغيل', // Tool tip for the speaker on button
			upload: 'رفع',                             // Tooltip that appears when hovering over upload button in footer.
			speak: 'يتكلم'                             // Tooltip for mic button
		},                                             
		nl: { // Some sample Dutch translations
			chatTitle: 'MyCompany',                    // Set title at chat header
			connected: 'Hoe kan ik je helpen?',        // Replaces Connected
			buttonText: 'Hoe kan ik je helpen?',       // Message next to popup-button on webpage
			leftButton: 'Herstart',                    // Text on left-bottom button
			leftButtonSend: 'Hallo',                   // Message send when left-bottom button
			rightButton: 'Menu',                       // Text on right-bottom button
			rightButtonSend: 'Menu',                   // Message send when right-bottom button
			inputPlaceholder: 'Type een bericht',      // Replaces Type a message
			send: 'Verstuur',                          // Replaces Send tool tip
			audioResponseOff: 'Speaker uit',           // Tool tip for the speaker off button
			audioResponseOn: 'Speaker aan',            // Tool tip for the speaker on button
			upload: 'Upload',                          // Tooltip that appears when hovering over upload button in footer.
			speak: 'Spreek',                            // Tooltip for mic button
      attachment_audio: "Audio attachment",
      attachment_file: "File attachment",
      attachment_image: "Image attachment",
      attachment_video: "Video attachment",
      avatarAgent: "Service icon",
      avatarBot: "Assistent icon",
      avatarUser: "Gebruiker icon",
      card: "Kaart {0}",
      cardImagePlaceholder: "Kaart plaatje",
      cardNavNext: "Volgende kaart",
      cardNavPrevious: "Vorige kaart",
      clear: "Wis conversatie",
      close: "Sluit conversatie",
      closing: "Sluiten",
      connecting: "Verbinden",
      connectionFailureMessage: "Sorry, de assistant is momenteel niet beschikbaar.",
      connectionRetryLabel: "Probeer opnieuw",
      defaultGreetingMessage: "Een moment aub",
      defaultWaitMessage: "Bezig. Bedankt voor uw geduld!",
      defaultSorryMessage: "Het spijt me. Ik kan u geen goed antwoord geven. Probeer het opnieuw.",
      disconnected: "Niet verbonden",
      download: "Download",
      endConversation: "Sluit de chat",
      endConversationConfirmMessage: "Wilt u de conversatie beëindigen?",
      endConversationDescription: "Dit wist ook de conversatie-historie",
      endConversation: "Beëindig conversatie",
      errorSpeechUnsupportedLocale: "Stemherkenning voor nederlands is nog niet ondersteund",
      language_ar: "Arabisch",
      language_de: "Duits",
      language_detect: "Detecteer taal",
      language_en: "Engels",
      language_hi: "Hindi",
      language_es: "Spaans",
      language_fr: "Frans",
      language_it: "Italiaans",
      language_nl: "Nederlands",
      language_pt: "Portugees",
      languageSelectDropdown: "Selecteer taal",
      linkField: "Klik op de tekst om de link om {0} te openen",
      noText: "Nee",
      openMap: "Open Kaart",
      previousChats: "Einde van vorige conversatie",
      ratingStar: "Beoordeel {0} sterren",
      recognitionTextPlaceholder: "Spreek uw bericht",
      relTimeDay: "{0}d geleden",
      relTimeHr: "{0}u geleden",
      relTimeMin: "{0}min geleden",
      relTimeMoment: "Een paar seconden geleden",
      relTimeMon: "{0}mnd geleden",
      relTimeNow: "Nu",
      relTimeYr: "{0}jr geleden",
      requestLocation: "Verzoek locatie",
      requestLocationDeniedPermission: "Geef browser toestemming locatie te delen. U kunt ook de locatie intypen.",
      requestLocationDeniedTimeout: "Het duurt te lang om uw locatie te detecteren. .concat(r)",
      requestLocationDeniedUnavailable: "Uw locatie is niet beschikbaar. .concat(r)",
      retryMessage: "Probeer opnieuw",
      shareAudio: "Deel geluid",
      shareFailureMessage: "Sorry, delen is niet beschikbaar op dit apparaat.",
      shareFile: "Deel Bestand",
      shareLocation: "Deel Locatie",
      shareVisual: "Deel Media",
      skillMessage: "De assistent zegt",
      showOptions: "Toon Opties",
      typingIndicator: "Wachtend op antwoord",
      uploadFailed: "Upload Mislukt.",
      uploadFileSizeLimitExceeded: "Bestand grootte mag niet meer zijn dan {0}MB.",
      uploadFileSizeZeroByte: "Bestanden met grootte 0 kunnen niet worden geupload.",
      uploadUnsupportedFileType: "Nietondersteund bestandstype",
      userMessage: "Ik zeg",
      utteranceGeneric: "Bericht van assistent.",
      webViewAccessibilityTitle: "WebView om links te tonen",
      webViewClose: "Klaar",
      webViewErrorInfoDismiss: "Ok",
      webViewErrorInfoText: "Geen pagina? {0}Klik hier{/0} om het in de browser te tonen.",
      yesText: "Ja",
      noText: "Nee"
		},                                             
		fr: {                                        
			chatTitle: 'MyCompany',                         // Set title at chat header
			connected: 'Avoir une question?',               // Replaces Connected
			buttonText: 'Avoir une question?',              // Message next to popup-button on webpage
			leftButton: 'Redémarrage',                      // Text on left-bottom button
			leftButtonSend: 'Bonjour',                      // Message send when left-bottom button
			rightButton: 'Menu',                            // Text on right-bottom button
			rightButtonSend: 'Menu',                        // Message send when right-bottom button
			inputPlaceholder: 'Tapez votre message',        // Replaces Type a message
			send: 'Enviar',                                 // Replaces Send tool tip
			audioResponseOff: 'Réponse audio désactivée',   // Tool tip for the speaker off button
			audioResponseOn: 'Réponse audio activée',       // Tool tip for the speaker on button
			upload: 'Télécharger',                          // Tooltip that appears when hovering over upload button in footer.
			speak: 'Parler',                                // Tooltip for mic button
      cardNavNext: "Suivant",
      cardNavPrevious: "Précédent",
      clear: "Conversation claire",
      close: "Fermer",
      closing: "Fermeture",
      connecting: "Connexion",
      connectionFailureMessage: "Désolé, l'assistant n'est pas disponible pour le moment. Si le problème persiste, contactez votre service d'assistance.",
      connectionRetryLabel: "Essayer à nouveau",
      defaultWaitMessage: "Je travaille toujours sur votre demande. Merci pour votre patience!",
      defaultSorryMessage: "Je suis désolé. Je ne peux pas vous fournir le bon contenu. Veuillez réessayer.",
      disconnected: "Débranché",
      download: "Télécharger",
      endConversation: "Mettre fin à la conversation",
      endConversationConfirmMessage: "Voulez-vous vraiment mettre fin à la conversation ?",
      endConversationDescription: "Cela effacera également l'historique de vos conversations.",
      itemIterator: "Article {0}",
      language_ar: "arabe",
      language_detect: "Détecter la langue",
      language_en: "Anglais",
      language_es: "Espagnol",
      language_fr: "Français",
      languageSelectDropdown: "Sélectionnez la langue de discussion",
      linkField: "Cliquez sur le texte en surbrillance pour ouvrir le lien pour {0}",
      noSpeechTimeout: "La voix n'a pas pu être détectée pour effectuer la reconnaissance.",
      openMap: "Ouvrir la carte",
      previousChats: "Fin de la conversation précédente",
      ratingStar: "Notez {0} étoiles",
      recognitionTextPlaceholder: "Prononcez votre message",
      relTimeDay: "Il y a {0} jours",
      relTimeHr: "Il y a {0} heures",
      relTimeMin: "Il y a {0} minutes",
      relTimeMoment: "Il y a quelques secondes",
      relTimeMon: "Il y a {0} mois",
      relTimeNow: "Maintenant",
      relTimeYr: "Il y a {0} ans",
      requestLocation: "Emplacement de la demande",
      requestLocationDeniedPermission: "Pour autoriser le partage de votre position, mettez à jour les paramètres de votre navigateur pour permettre l'accès à votre position. Vous pouvez également saisir l'emplacement à la place.",
      requestLocationDeniedTimeout: "Il faut trop de temps pour obtenir votre position.",
      requestLocationDeniedUnavailable: "Votre position actuelle n'est pas disponible.",
      retryMessage: "Essayer à nouveau",
      shareAudio: "Partager l'audio",
      shareFailureMessage: "Désolé, le partage n'est pas disponible sur cet appareil.",
      shareFile: "Partager le fichier",
      shareLocation: "Emplacement partagé",
      shareVisual: "Partager une image/vidéo",
      showOptions: "Afficher les options",
      typingIndicator: "En attente d'une réponse",
      webViewClose: "Fait",
      webViewErrorInfoDismiss: "Rejeter",
      noText: "Non",
      yesText: "Oui"
		},
		en: {                                        
			chatTitle: 'MyCompany',                    // Set title at chat header
			connected: 'How can I help you?',          // Replaces Connected
			buttonText: 'How can I help you?',         // Message next to popup-button on webpage
			leftButton: 'Restart',                     // Text on left-bottom button
			leftButtonSend: 'Hi',                      // Message send when left-bottom button
			rightButton: 'Menu',                       // Text on right-bottom button
			rightButtonSend: 'Menu',                   // Message send when right-bottom button
			inputPlaceholder: 'Type a message',        // Replaces Type a message
			send: 'Send',                              // Replaces Send tool tip
			audioResponseOff: 'Speaker off',           // Tool tip for the speaker off button
			audioResponseOn: 'Speaker on',             // Tool tip for the speaker on button
			upload: 'Upload',                          // Tooltip that appears when hovering over upload button in footer.
			speak: 'Speak',                            // Tooltip for mic button
//more texts to copy to your language translations:
			attachment_audio: "Audio attachment",
			attachment_file: "File attachment",
			attachment_image: "Image attachment",
			attachment_video: "Video attachment",
			attachmentAudioFallback: "Your browser does not support embedded audio. However you can {0}download it{/0}.",
			attachmentVideoFallback: "Your browser does not support embedded video. However you can {0}download it{/0}.",
			avatarAgent: "Agent icon",
			avatarBot: "Bot icon",
			avatarUser: "User icon",
			card: "Card {0}",
			cardImagePlaceholder: "Card image",
			cardNavNext: "Next card",
			cardNavPrevious: "Previous card",
			clear: "Clear conversation",
			close: "Close widget",
			closing: "Closing",
			connecting: "Connecting",
			connectionFailureMessage: "Sorry, the assistant is unavailable right now. If the issue persists, contact your help desk.",
			connectionRetryLabel: "Try Again",
			defaultGreetingMessage: "Hey, Nice to meet you! Allow me a moment to get back to you.",
			defaultWaitMessage: "I'm still working on your request. Thank you for your patience!",
			defaultSorryMessage: "I'm sorry. I can't get you the right content. Please try again.",
			disconnected: "Disconnected",
			download: "Download",
			endConversation: "End Conversation",
			endConversationConfirmMessage: "Are you sure you want to end the conversation?",
			endConversationDescription: "This will also clear your conversation history.",
			errorSpeechInvalidUrl: "ODA URL for connection is not set. Please pass 'URI' parameter during SDK initialization.",
			errorSpeechMultipleConnection: "Another voice recognition is ongoing. can't start a new one.",
			errorSpeechTooMuchTimeout: "The voice message is too long to recognize and generate text.",
			errorSpeechUnavailable: "To allow voice messaging, update your browser settings to enable access to your microphone.",
			errorSpeechUnsupportedLocale: "The locale set for voice recognition is not supported. Please use a valid locale in 'speechLocale' setting.",
			imageViewerClose: "Close image viewer",
			imageViewerOpen: "Open image viewer",
			itemIterator: "Item {0}",
			language_ar: "Arabic",
			language_de: "German",
			language_detect: "Detect Language",
			language_en: "English",
			language_hi: "Hindi",
			language_es: "Spanish",
			language_fr: "French",
			language_it: "Italian",
			language_nl: "Dutch",
			language_pt: "Portuguese",
			languageSelectDropdown: "Select chat language",
			linkField: "Click on the highlighted text to open Link for {0}",
			noSpeechTimeout: "The voice could not be detected to perform recognition.",
			noText: "No",
			openMap: "Open Map",
			previousChats: "End of previous conversation",
			ratingStar: "Rate {0} star",
			recognitionTextPlaceholder: "Speak your message",
			relTimeDay: "{0}d ago",
			relTimeHr: "{0}hr ago",
			relTimeMin: "{0}min ago",
			relTimeMoment: "A few seconds ago",
			relTimeMon: "{0}mth ago",
			relTimeNow: "Now",
			relTimeYr: "{0}yr ago",
			requestLocation: "Requesting location",
			requestLocationDeniedPermission: "To allow sharing your location, update your browser settings to enable access to your location. You can also type in the location instead.",
			requestLocationDeniedTimeout: "It is taking too long to get your location. .concat(r)",
			requestLocationDeniedUnavailable: "Your current location is unavailable. .concat(r)",
			retryMessage: "Try again",
			shareAudio: "Share Audio",
			shareFailureMessage: "Sorry, sharing is not available on this device.",
			shareFile: "Share File",
			shareLocation: "Share Location",
			shareVisual: "Share Image/Video",
			skillMessage: "Skill says",
			showOptions: "Show Options",
			typingIndicator: "Waiting for response",
			uploadFailed: "Upload Failed.",
			uploadFileSizeLimitExceeded: "File size should not be more than {0}MB.",
			uploadFileSizeZeroByte: "Files of size zero bytes can't be uploaded.",
			uploadUnsupportedFileType: "Unsupported file type.",
			userMessage: "I say",
			utteranceGeneric: "Message from skill.",
			webViewAccessibilityTitle: "In-widget WebView to display links",
			webViewClose: "Done",
			webViewErrorInfoDismiss: "Dismiss",
			webViewErrorInfoText: "Don’t see the page? {0}Click here{/0} to open it in a browser.",
			yesText: "Yes",
			noText: "No"
		}
	},
	colors:	{
		branding: '#173D91',                    // headerbar background & hover footer buttons
		headerBackground: '#173D91',            // Same as branding. The background color of chat widget's header
		botMessageBackground: '#F0F0F0',        // Background of response message bubble
		userMessageBackground: '#173D91',       // Background of user message bubble
		links: '#132C71',                       // Url link color
		text: '#87AB7A',                        // card-question
		botText: '#1D1B1B',                     // Response text from bot
		headerText: '#FFFFFF',                  // Header text
		headerButtonFill: '#FFFFFF',            // Header text
		userText: '#FFFFFF',                    // User text
		textLight: '#1D1B1B',                   // card-answer
		inputText: '#1D1B1B',                   // The text color in the message input field. Overrides text if passed.
		footerBackground: '#ffffff',            // Chat widget footer background
		cardBackground: '#F0F0F0',              // Card background
		actionsBorder: '#173D91',								// The action button border color
		actionsText: '#173D91',									// The action button text color
		actionsBackground: '#FFFFFF',           // action button background
		actionsTextHover: '#FFFFFF',						// The action button text color on hover
		actionsTextFocus: '#FFFFFF',						// The action button text color on focus
		actionsBackgroundHover: '#173D91',      // action button background
		actionsBackgroundFocus: '#173D91',      // action button background
		globalActionsBorder: '#173D91',	        // The global action button border color
		globalActionsText: '#173D91',           // The global action button text color
		globalActionsBackground: '#FFFFFF',			// The global action button background color
		globalActionsTextHover: '#FFFFFF',			// The global action button text color on hover
		globalActionsTextFocus: '#FFFFFF',			// The global action button text color on focus
		globalActionsBackgroundHover: '#173D91',// The global action button background color on hover
		globalActionsBackgroundFocus: '#173D91',// The global action button background color on focus
		ratingStar: '#808080',									// The color applied to initial unselected rating stars of feedback message
		ratingStarFill: '#FFE22B',							// The color applied to rating stars of feedback message on hover or selection. The branding color is used if this is not passed
		timestamp: '#f0f0f0' 					          // Timestamp header and relative timestamp in messages
	}
}

function getConciergeValues(chatWidgetSettings, lang) {
	//@@md230615
	
	chatWidgetSettings.URI              = Concierge.URI;
	chatWidgetSettings.channelId        = Concierge.channelId;
	chatWidgetSettings.colors           = Concierge.colors;
	chatWidgetSettings.initUserProfile  = Concierge.initUserProfile;
	chatWidgetSettings.multiLangChat    = Concierge.multiLangChat;
	if (!lang) { //@@md230721 Use browser locale language
		lang = navigator.languages && navigator.languages.length ? navigator.languages[0].slice(0,2) : navigator.language.slice(0,2);
		if (lang == 'nl') lang = 'nl-NL';
	}
	Concierge.multiLangChat.primary = lang;
	switch (Concierge.multiLangChat.primary) {
		case 'fr':
			chatWidgetSettings.i18n.en = Concierge.i18n.fr;
			Concierge.buttonText = Concierge.i18n.fr.buttonText;
			Concierge.leftButton = Concierge.i18n.fr.leftButton;
			Concierge.leftButtonSend = Concierge.i18n.fr.leftButtonSend;
			Concierge.rightButton = Concierge.i18n.fr.rightButton;
			Concierge.rightButtonSend = Concierge.i18n.fr.rightButtonSend;
			break;
		case 'es':
			chatWidgetSettings.i18n.en = Concierge.i18n.es;
			Concierge.buttonText = Concierge.i18n.es.buttonText;
			Concierge.leftButton = Concierge.i18n.es.leftButton;
			Concierge.leftButtonSend = Concierge.i18n.es.leftButtonSend;
			Concierge.rightButton = Concierge.i18n.es.rightButton;
			Concierge.rightButtonSend = Concierge.i18n.es.rightButtonSend;
			break;
		case 'ar':
			chatWidgetSettings.i18n.en = Concierge.i18n.ar;
			Concierge.buttonText = Concierge.i18n.ar.buttonText;
			Concierge.leftButton = Concierge.i18n.ar.leftButton;
			Concierge.leftButtonSend = Concierge.i18n.ar.leftButtonSend;
			Concierge.rightButton = Concierge.i18n.ar.rightButton;
			Concierge.rightButtonSend = Concierge.i18n.ar.rightButtonSend;
			break;
		case 'nl-NL':
			chatWidgetSettings.i18n.en = Concierge.i18n.nl;
			Concierge.buttonText = Concierge.i18n.nl.buttonText;
			Concierge.leftButton = Concierge.i18n.nl.leftButton;
			Concierge.leftButtonSend = Concierge.i18n.nl.leftButtonSend;
			Concierge.rightButton = Concierge.i18n.nl.rightButton;
			Concierge.rightButtonSend = Concierge.i18n.nl.rightButtonSend;
			break;
		default:
			chatWidgetSettings.i18n.en = Concierge.i18n.en;
			Concierge.buttonText = Concierge.i18n.en.buttonText;
			Concierge.leftButton = Concierge.i18n.en.leftButton;
			Concierge.leftButtonSend = Concierge.i18n.en.leftButtonSend;
			Concierge.rightButton = Concierge.i18n.en.rightButton;
			Concierge.rightButtonSend = Concierge.i18n.en.rightButtonSend;
	}
}

function customizeLaunchButton() {
	const launchButton = document.querySelector('.oda-chat-button');
	if (launchButton) {
		const element = document.createElement('div');
		element.setAttribute('dir', 'auto');
		element.setAttribute('class', 'oda-chat-letschat');
		const innerText = document.createTextNode(Concierge.buttonText);
		element.appendChild(innerText);
		launchButton.appendChild(element);
	}
}	

function addFooterButtons() {
	//@@md230130 footerButtons
	var footerBtnsDiv = document.createElement("div");
	footerBtnsDiv.className = 'footerBtns';
	// footButtonLeft
	var footerButtonLeft = document.createElement("button");
	footerButtonLeft.className = 'footerButtonLeft';
	footerButtonLeft.innerHTML =  Concierge.leftButton;
	footerButtonLeft.addEventListener("click", function() {
		 Bots.sendMessage(Concierge.leftButtonSend);
	});
	// footerButtonRight
	var footerButtonRight = document.createElement("button");
	footerButtonRight.className = 'footerButtonRight';
	footerButtonRight.setAttribute("id", "footerButtonRightId");
	footerButtonRight.innerHTML =  Concierge.rightButton;
	footerButtonRight.addEventListener("click", function() {
		Bots.sendMessage(Concierge.rightButtonSend);
	}); 
	// footerButtons append
	var divWrapper = document.getElementsByClassName("oda-chat-widget")[0];
	footerBtnsDiv.appendChild(footerButtonLeft);
	footerBtnsDiv.appendChild(footerButtonRight);
	divWrapper.appendChild(footerBtnsDiv);
}
