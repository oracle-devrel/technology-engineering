define([], () => {
  'use strict';

  class PageModule {
    processImage(file){
      console.log("print file",file);
  return new Promise(resolve=> {
    const blobURL = URL.createObjectURL(file[0].file);
    const reader = new FileReader();
    reader.addEventListener("load",function() {
      resolve({
        data:reader.result,
      });
    }, false);

    if (file) {
      reader.readAsDataURL(file[0].file);
    }

  });
 };
  }
  
  return PageModule;
});
