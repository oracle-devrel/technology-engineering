define([], () => {
  'use strict';

  class PageModule {
    processImage(file){
  return new Promise(resolve=> {
    const blobURL = URL.createObjectURL(file);
    const reader = new FileReader();
    reader.addEventListener("load",function() {
      resolve({
        data:reader.result,
      });
    }, false);

    if (file) {
      reader.readAsDataURL(file);
    }

  });
 };
  }
  
  return PageModule;
});
