define([], () => {
  'use strict';

  class FragmentModule {
  }
  
  return FragmentModule;
});
