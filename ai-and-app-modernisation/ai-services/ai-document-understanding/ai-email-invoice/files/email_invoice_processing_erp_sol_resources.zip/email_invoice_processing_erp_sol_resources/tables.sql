CREATE TABLE gmail_messages_history(
    history_id                NUMBER(15)      NOT NULL,
    emailAddress			  VARCHAR2(200),
	history_id_date           TIMESTAMP);
 
CREATE INDEX gmail_messages_history_idx1 ON gmail_messages_history(history_id);
CREATE INDEX gmail_messages_history_idx2 ON gmail_messages_history(emailAddress);
CREATE INDEX gmail_messages_history_idx3 ON gmail_messages_history(history_id_date);
 
ALTER TABLE gmail_messages_history
  ADD CONSTRAINT gmail_messages_history_pk
  PRIMARY KEY (history_id)
  RELY DISABLE NOVALIDATE;
  
COMMIT;