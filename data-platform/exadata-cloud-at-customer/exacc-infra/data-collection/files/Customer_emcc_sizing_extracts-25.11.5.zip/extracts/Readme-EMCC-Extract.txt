Readme - EMCC (Enterprise Manager Cloud Control) Extract      Updated 10/30/2025
================================================================================

This is the brief guide to using this tool to collect data for input into the 
internal Oracle Cloud Capacity Analytics (OCCA) sizing tool.  For a deeper look 
at all the steps please go to the OCCA Extracts User's Guide PDF that should be 
included in the folder with this file.

Step 1: Unzip the file, provided by your Oracle contact
--------------------------------------------------------------------------------

- Since you are here, you probably completed this step.
- These files need to be on a host/desktop with access to the target database.
- In this case you will need to connect to one or more OEM Repository Databases 
  so, you can either run from host where that database is or any other host with
  the SQL*Plus and Oracle Net access to the target databases.

Step 2: Identify and Verify Prerequisites
--------------------------------------------------------------------------------

- Oracle Enterprise Manager 13.x and higher.
- The SQL*Plus version 12.2 or higher.
- Connect String to the EM Database (if in a CDB you need to connect to the PDB)
- Database Account username and password for the EM Database with sufficient 
  access.  The SYSMAN account can be used or an account setup per MOS Doc ID 
  2583605.1
- If planning on using either the Source Side Filter and/or Obfuscation features 
  you will need Python 3.6 or higher

Step 3: Run Collection Script
--------------------------------------------------------------------------------

- Set Oracle Environment Variables
- Run the Script and it will prompt for input or provide arguments on the 
  command line:
    Linux/Unix run Shell script:   Get_EMCC_Sizing_Interactive.sh
    Windows run PowerShell script: Get_EMCC_Sizing_Interactive.ps1
- Example Execution shown below.
- Output files are written in directory: emcc_sizing_extracts

Step 3a: Optional - Run Source Side Filter
--------------------------------------------------------------------------------

- Not recommended unless required by your business.
- See Appendix in the OCCA Extracts User's Guide.

Step 3b: Optional - Run Source Side Obfuscation
--------------------------------------------------------------------------------

- Not recommended unless required by your business.
- See Appendix in the OCCA Extracts User's Guide

Step 4: Zip output files and upload to Oracle
--------------------------------------------------------------------------------

- Collect all the output files and zip them up.
- Oracle uses SharePoint to share files back and forth with customers, your 
  Oracle contact should have provided you a link to upload your files, please 
  let them know when the files are uploaded.

================================================================================
End of Readme
================================================================================

Example EMCC Extract Execution
--------------------------------------------------------------------------------

The script prompts for the connection data if not provided on the command line. 
If "readuser/XXXX@emhost.acme.com/emrepd" was provided on the command line no
prompt would have been issued.

--------------------------------------------------------------------------------

$ ./Get_EMCC_Sizing_Interactive.sh                                                             
This script queries views licensed by the Oracle Diagnostics Pack;
however, the license is not required per MOS Note: 2771065.1
+--------------------------------------------------------------------+
|  ###   ###  ###   ####                                             |
| #   # #    #     #   #     _         _                             |
| #   # #    #    ######    |_  |\/|  |_)   |\/|  o   _    _   ,_    |
|  ###  ###  ### ##   ##    |_  |  |  | |   |  |  |  | |  (/_  |     |
+--------------------------------------------------------------------+
EMR-Miner Version 25.2.0
Collects metrics and statistics from Enterprise Manager Repository (EMR).
SUCCESS: SQL*Plus Command Found and Version is good: "/bin/sqlplus"
Enter Enterprise Manager Repository Database Connection Data
The following are examples for the syntaxes you may use
   EZCONNECT: username/password@hostname:port/service_name
   TNSNAMES : username/password@tnsnames_alias
   Note: The User must have the MGMT_USER role, SELECT ANY TABLE privilege or have SYSMAN privileges
Enter Connection Data: readuser/XXXX@emhost.acme.com/emrepdb
SUCCESS: Test Connection to Database Succeeded!
Starting Extract Scripts!
Extracting EM Release Information...
Extracting DB HA relationships...
Extracting DB parameters...
Extracting DB properties...
Extracting DB services...
Extracting DB SGA settings...
Extracting Host properties...
Extracting PDB parameters...
Extracting PDB properties...
Extracting DB REDO Log files...
Extracting PDB SGA settings...
Extracting DB structure...
Extracting DB VM structure...
Extracting host CPU details...
Extracting host VM structure...
Extracting PDB structure...
Extracting host VM structure...
Extracting target availability...
Extracting List of EM Jobs...
Extracting List of EM Metrics...
Extracting DB daily metrics 0 to 03 months...
Extracting DB daily metrics 03 to 06 months...
Extracting DB daily metrics 06 to 09 months...
Extracting DB daily metrics 09 to 12 months...
Extracting Host daily metrics 0 to 03 months...
Extracting Host daily metrics 03 to 06 months...
Extracting Host daily metrics 06 to 09 months...
Extracting Host daily metrics 09 to 12 months...
Extracting PDB daily metrics 0 to 03 months...
Extracting PDB daily metrics 03 to 06 months...
Extracting PDB daily metrics 06 to 09 months...
Extracting PDB daily metrics 09 to 12 months...
Extracting Host hourly metrics 0 to 03 months...
Extracting DB hourly metrics 0 to 03 months...
Extracting PDB hourly metrics 0 to 03 months...

Checking Output Files for Errors!
Run Time = 10 minutes
SUCCCESS: No Errors were found in the output files!
Next Step: bundle up the output directory, for example:
   zip -r emcc_sizing_extracts_oem1.zip emcc_sizing_extracts
Final Step: please upload the bundle to location provided by your Oracle contact







