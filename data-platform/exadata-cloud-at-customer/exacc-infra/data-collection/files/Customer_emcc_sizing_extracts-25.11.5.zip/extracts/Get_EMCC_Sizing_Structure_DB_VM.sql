rem
rem Version 1.7
define __version__ = 1.7
rem

rem Version History
rem
rem 2021-02-08    1.7   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.6   tmf     Added timing off
rem 2020-11-19    1.5   tmf     Added capture of SQL*Plus version
rem 2020-11-15    1.4   tmf     Ignore virtual server & virtual platform both poplated error
rem 2020-11-05    1.3   tmf     mkdir -p
rem 2020-10-11    1.2   tmf     Re-factored query
rem 2020-06-15    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting DB VM structure...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_db_vm.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_db_vm.csv

prompt "extract_version"-
,"dbmachine","dbmachine_type_version","dbmachine_type"-
,"si_rack","si_server_map","si_virtual_platform","si_virtual_server"-
,"h_from_dbmachine","h_from_si_server_map","h_from_si_virtual_server"-
,"dbmachine_guid","si_rack_guid","si_server_map_guid","si_virtual_platform_guid","si_virtual_server_guid"-
,"h_from_dbmachine_guid","h_from_server_map_guid","h_from_si_vs_guid"-
,"h_guid","h","h_type_version","h_source"-
,"dbmachine_server_map_count","dbmachine_virt_platform_count","dbmachine_virt_server_count","dbmachine_host_count"-
,"extract_dttm_utc"

WITH dbmachine_hosts
AS
(
SELECT DISTINCT
       t.target_name        AS host
      ,t.type_version       AS host_type_version
      ,t.target_type        AS host_type
      ,i.source_target_name AS dbmachine
      ,i.source_target_type AS dbmachine_type
      ,x.target_guid        AS dbmachine_guid
      ,x.type_version       AS dbmachine_type_version
      ,t.target_guid        AS host_guid
FROM   sysman.mgmt$target              x
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  t.target_name         = i.assoc_target_name
AND    t.target_type         = i.assoc_target_type
AND    t.target_type         = 'host'
AND    i.source_target_name  = x.target_name
AND    i.source_target_type  = x.target_type
AND    i.source_target_type IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
AND    NOT EXISTS (
                   SELECT 1
                   FROM   sysman.mgmt$target_associations a
                   WHERE  a.assoc_target_type  = 'oracle_si_rack'
                   AND    a.source_target_type = i.source_target_type
                   AND    a.source_target_name = i.source_target_name
                  )
)
,server_map_hosts AS
(
SELECT DISTINCT
       t.target_name        AS host
      ,t.type_version       AS host_type_version
      ,t.target_type        AS host_type
      ,t.target_guid        AS host_guid
      ,i.assoc_target_name  AS si_server_map
      ,i.assoc_target_type  AS si_server_map_type
FROM   sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  t.target_name        = i.source_target_name
AND    t.target_type        = i.source_target_type
AND    t.target_type        = 'host'
AND    i.assoc_target_type = 'oracle_si_server_map'
AND    EXISTS     (
                   SELECT 1
                   FROM   sysman.mgmt$target_associations a
                   WHERE  a.assoc_target_type  = i.assoc_target_type
                   AND    a.assoc_target_name  = i.assoc_target_name
                   AND    a.source_target_type = 'oracle_si_rack'
                  )
AND    NOT EXISTS (
                   SELECT 1
                   FROM   sysman.mgmt$target_associations a
                   WHERE  a.assoc_target_type  = i.source_target_type
                   AND    a.assoc_target_name  = i.source_target_name
                   AND    a.source_target_type = 'oracle_si_virtual_platform'
                  )
)
, virtual_server_hosts AS
(
SELECT DISTINCT
       i.source_target_name AS host
      ,g.type_version       AS host_type_version
      ,i.source_target_type AS host_type
      ,g.target_guid        AS host_guid
      ,t.target_name        AS si_virtual_server
      ,t.target_type        AS si_virtual_server_type
FROM   sysman.mgmt$target              g
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  g.target_name        = i.source_target_name
AND    g.target_type        = i.source_target_type
AND    t.target_name        = i.assoc_target_name
AND    t.target_type        = i.assoc_target_type
AND    t.target_type        = 'oracle_si_virtual_server'
AND    i.source_target_type = 'host'
)
,si_racks AS
(
SELECT DISTINCT
       t.target_guid         AS si_rack_guid
      ,t.target_name         AS si_rack
      ,t.target_type         AS si_rack_type
      ,x.target_guid         AS dbmachine_guid
      ,i.source_target_name  AS dbmachine
      ,i.source_target_type  AS dbmachine_type
      ,x.type_version        AS dbmachine_type_version
FROM   sysman.mgmt$target              x
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  t.target_name        = i.assoc_target_name
AND    t.target_type        = i.assoc_target_type
AND    t.target_type        = 'oracle_si_rack'
AND    i.source_target_name = x.target_name
AND    i.source_target_type = x.target_type
AND    i.source_target_type = 'oracle_dbmachine'
),
server_maps AS
(
SELECT DISTINCT
       t.target_name        AS si_server_map
      ,t.target_type        AS si_server_map_type
      ,t.target_guid        AS si_server_map_guid
      ,i.source_target_name AS si_rack
      ,i.source_target_type AS si_rack_type
FROM   sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  t.target_name        = i.assoc_target_name
AND    t.target_type        = i.assoc_target_type
AND    t.target_type        = 'oracle_si_server_map'
AND    i.source_target_type = 'oracle_si_rack'
),
virtual_platforms AS
(
SELECT DISTINCT
       i.source_target_name AS si_virtual_platform
      ,i.source_target_type AS si_virtual_platform_type
      ,t.target_name        AS si_server_map
      ,t.target_type        AS si_server_map_type
      ,g.target_guid        AS si_virtual_platform_guid
FROM   sysman.mgmt$target              g
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  g.target_name        = i.source_target_name
AND    g.target_type        = i.source_target_type
AND    t.target_name        = i.assoc_target_name
AND    t.target_type        = i.assoc_target_type
AND    t.target_type        = 'oracle_si_server_map'
AND    i.source_target_type = 'oracle_si_virtual_platform'
),
virtual_servers AS
(
SELECT DISTINCT
       t.target_guid       AS si_virtual_server_guid
      ,t.target_name       AS si_virtual_server
      ,t.target_type       AS si_virtual_server_type
      ,i.assoc_target_name AS si_virtual_platform
      ,i.assoc_target_type AS si_virtual_platform_type
FROM   sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  t.target_name       = i.source_target_name
AND    t.target_type       = i.source_target_type
AND    t.target_type       = 'oracle_si_virtual_server'
AND    i.assoc_target_type = 'oracle_si_virtual_platform'
)
SELECT '&__version__'                       AS extract_version
      ,r.dbmachine                          AS dbmachine
      ,r.dbmachine_type_version             AS dbmachine_type_version
      ,r.dbmachine_type                     AS dbmachine_type
      ,r.si_rack                            AS si_rack
      ,s.si_server_map                      AS si_server_map
      ,v.si_virtual_platform                AS si_virtual_platform
      ,vs.si_virtual_server                 AS si_virtual_server
      ,''                                   AS h_from_dbmachine
      ,smh.host                             AS h_from_si_server_map
      ,vsh.host                             AS h_from_si_virtual_server
      ,RAWTOHEX(r.dbmachine_guid)           AS dbmachine_guid
      ,RAWTOHEX(r.si_rack_guid)             AS si_rack_guid
      ,RAWTOHEX(s.si_server_map_guid)       AS si_server_map_guid
      ,RAWTOHEX(v.si_virtual_platform_guid) AS si_virtual_platform_guid
      ,RAWTOHEX(vs.si_virtual_server_guid)  AS si_virtual_server_guid
      ,''                                   AS h_from_dbmachine_guid
      ,RAWTOHEX(smh.host_guid)              AS h_from_si_server_map_guid
      ,RAWTOHEX(vsh.host_guid)              AS h_from_si_vs_guid
      ,RAWTOHEX(NVL(vsh.host_guid,         smh.host_guid))        AS h_guid
      ,NVL(         vsh.host,              smh.host)              AS h
      ,NVL(         vsh.host_type_version, smh.host_type_version) AS h_type_version
      ,CASE
         WHEN vsh.host IS NOT NULL THEN 'si_virtual_server'
         WHEN smh.host IS NOT NULL THEN 'si_server_map'
       ELSE
         'no host'
       END AS h_source
      ,COUNT(DISTINCT s.si_server_map_guid)              OVER (PARTITION BY r.dbmachine_guid) AS dbmachine_server_map_count
      ,COUNT(DISTINCT v.si_virtual_platform_guid)        OVER (PARTITION BY r.dbmachine_guid) AS dbmachine_virt_platform_count
      ,COUNT(DISTINCT vs.si_virtual_server_guid)         OVER (PARTITION BY r.dbmachine_guid) AS dbmachine_virt_server_count
      ,COUNT(DISTINCT NVL(smh.host_guid, vsh.host_guid)) OVER (PARTITION BY r.dbmachine_guid) AS dbmachine_host_count
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')                        AS extract_dttm_utc
FROM   virtual_server_hosts vsh
      ,server_map_hosts     smh
      ,virtual_servers      vs
      ,virtual_platforms    v
      ,server_maps          s
      ,si_racks             r
WHERE vs.si_virtual_server_type  = vsh.si_virtual_server_type  (+)
AND   vs.si_virtual_server       = vsh.si_virtual_server       (+)
AND   s.si_server_map_type       = smh.si_server_map_type      (+)
AND   s.si_server_map            = smh.si_server_map           (+)
AND   v.si_virtual_platform_type = vs.si_virtual_platform_type (+)
AND   v.si_virtual_platform      = vs.si_virtual_platform      (+)
AND   s.si_server_map_type       = v.si_server_map_type        (+)
AND   s.si_server_map            = v.si_server_map             (+)
AND   r.si_rack_type             = s.si_rack_type              (+)
AND   r.si_rack                  = s.si_rack                   (+)
UNION ALL
SELECT '&__version__'           AS extract_version
      ,dbmachine
      ,dbmachine_type_version
      ,dbmachine_type
      ,NULL                     AS si_rack
      ,NULL                     AS si_server_map
      ,NULL                     AS si_virtual_platform
      ,NULL                     AS si_virtual_server
      ,host                     AS h_from_dbmachine
      ,NULL                     AS h_from_si_server_map
      ,NULL                     AS h_from_si_virtual_server
      ,RAWTOHEX(dbmachine_guid) AS dbmachine_guid
      ,NULL                     AS si_rack_guid
      ,NULL                     AS si_server_map_guid
      ,NULL                     AS si_virtual_platform_guid
      ,NULL                     AS si_virtual_server_guid
      ,RAWTOHEX(host_guid)      AS h_from_dbmachine_guid
      ,NULL                     AS h_from_si_server_map_guid
      ,NULL                     AS h_from_si_vs_guid
      ,RAWTOHEX(host_guid)      AS h_guid
      ,host                     AS h
      ,host_type_version        AS h_type_version
      ,'dbmachine'              AS h_source
      ,0                        AS dbmachine_server_map_count
      ,0                        AS dbmachine_virt_platform_count
      ,0                        AS dbmachine_virt_server_count
      ,COUNT(1) OVER (PARTITION BY dbmachine_guid)                     AS dbmachine_host_count
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS') AS extract_dttm_utc
FROM   dbmachine_hosts;

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_db_vm.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
