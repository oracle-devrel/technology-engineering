rem
rem Version 1.1
define __version__ = 1.1
rem

rem Version History
rem
rem 2021-03-24    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting DB REDO Log files...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_db_redo.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_db_redo.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","GROUP_NUM","STATUS","MEMBERS","FILE_NAME","ARCHIVED","LOGSIZE","SEQUENCE_NUM"-
,"OS_STORAGE_ENTITY","THREAD_NUM","TYPE","EXTRACT_DTTM_UTC"

SELECT RAWTOHEX(r.target_guid) AS target_guid
      ,r.target_name
      ,r.target_type
      ,r.group_num
      ,r.status
      ,r.members
      ,r.file_name
      ,r.archived
      ,r.logsize
      ,r.sequence_num
      ,r.os_storage_entity
      ,r.thread_num
      ,r.type
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')
FROM   sysman.mgmt$db_redologs r;

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_db_redo.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
