To run the extract scripts:
--------------------------------------------------------------------------------

1) If running on a Windows, ensure PowerShell scripts are allowed to run:

2) Identify path to SQL*Plus:

   NOTE: SQL*Plus 12.2 or higher is REQUIRED, consider Instant Client, if needed

3) Identify the EMCC Repository Database connection data:

   You will need the following: User Account, Password & Connect String
   The User Account must have the MGMT_USER role, SELECT ANY TABLE privilege or
   be the "SYSMAN" account.

4) At the command prompt type:

      Unix/Linux:
         ./Get_EMCC_Sizing_Interactive.sh

      Windows:
         powershell .\Get_EMCC_Sizing_Interactive.ps1

4) Output files are automatically checked for any "ORA-" errors and reported,
   if errors are reported they must be addressed and the script must be re-run.
