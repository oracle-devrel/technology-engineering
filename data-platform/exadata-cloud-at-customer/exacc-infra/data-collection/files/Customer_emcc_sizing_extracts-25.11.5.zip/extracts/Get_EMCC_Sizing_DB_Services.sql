rem
rem Version 1.2
define __version__ = 1.2
rem

rem Version History
rem
rem 2021-02-08    1.2   tmf     Removed -p to be Windows friendly
rem 2021-01-15    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting DB services...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_db_services.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_db_services.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","HOST_NAME","NAME","NETWORK_NAME","FAILOVER_METHOD","FAILOVER_TYPE","GOAL","CLB_GOAL","EXTRACT_DTTM_UTC"

SELECT RAWTOHEX(s.target_guid) AS target_guid
      ,s.target_name
      ,s.target_type
      ,s.host_name
      ,s.name
      ,s.network_name
      ,s.failover_method
      ,s.failover_type
      ,s.goal
      ,s.clb_goal
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')
FROM   sysman.mgmt$db_services_ecm s;

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_db_services.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
