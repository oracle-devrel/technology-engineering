__version__ = "1.4"

#
# Version History
#
# 2022-06-28    1.4  pro     Refactor for Unit Testing
# 2022-02-22    1.3  pro     Add Masking of values for more sections
# 2022-02-16    1.2  pro     Add Support for hypen char on Database names
# 2022-02-08    1.1  pro     Mask Database Parameters values
# 2022-10-20    1.0  pro     Initial version

import csv
import errno
import fnmatch
import os
import platform
import re
import sys
from pathlib import Path


log_data = []
debug_data = []
targets = {}
db_name = ""
db_id = ""
min_snap = ""
max_snap = ""

DEV_MODE = False
DEBUG = True if "EMCC_SIZING_OBFUSCATE_AWR_DEBUG" in os.environ and os.environ["EMCC_SIZING_OBFUSCATE_AWR_DEBUG"].upper() == "Y" else False

AWR_MINER_FILE_NAME_PATTERN = re.compile(r"awr-hist-(\d+)-(.*)-(\d+)-(\d+).out")
TRANSLATION_FILE_NAME = "awr_obfuscated_translation"
MASK_STRING = "XXXXXXXXXXXX"
MASK_CHAR = "X"


# Columns to obfuscate in awr out file
LINES_START_WITH_TUPLE = ("DB_NAME", "HOSTS")
OBFUSCATE_COLS = [("DB_NAME", "oracle-database"), ("HOSTS", "host")]

MASK_DATABASE_PARAMETERS = [
    "audit_file_dest",
    "background_dump_dest",
    "connection_brokers",
    "control_files",
    "core_dump_dest",
    "db_file_name_convert",
    "db_name",
    "db_recovery_file_dest",
    "db_unique_name",
    "dispatchers",
    "dg_broker_config_file1",
    "dg_broker_config_file2",
    "diagnostic_dest",
    "fal_server",
    "instance_name",
    "log_archive_format",
    "log_file_name_convert",
    "lock_name_space",
    "log_archive_config",
    "pdb_file_name_convert",
    "redo_transport_user",
    "spfile",
    "user_dump_dest",
    "__dg_broker_service_names",
]
MASK_LOG_ARCHIVE_DEST_PARAMETERS = ["log_archive_dest_" + str(i) for i in (range(1, 31))]

MASK_DATABASE_PARAMETERS_LIST = MASK_DATABASE_PARAMETERS + MASK_LOG_ARCHIVE_DEST_PARAMETERS
MASK_DATABASE_PARAMETERS_TUPLE = tuple(MASK_DATABASE_PARAMETERS_LIST)


def get_awr_out_dir_path():
    """
    Return the execution path either from environment or current working directory.

    Returns
    ----------
         Path : Path
            The full path to awr_miner_out directory from the value of env variable
            EMCC_SIZING_AWR_ROOT_DIR or from the current execution directory.
    """
    if "EMCC_SIZING_AWR_ROOT_DIR" in os.environ:
        root_dir = os.environ["EMCC_SIZING_AWR_ROOT_DIR"]
    else:
        root_dir = os.getcwd()

    dir_path = os.path.join(root_dir, "awr_miner_out")

    return Path(dir_path).resolve()


def get_awr_log_dir_path():
    """
    Return the path to the awr_miner_occa/log directory from environment or current working directory.

    Returns
    ----------
         Path : Path
            The full path to awr_miner_occa/log directory from the value of env variable
            EMCC_SIZING_AWR_ROOT_DIR or from the current execution directory.
    """
    if "EMCC_SIZING_AWR_ROOT_DIR" in os.environ:
        root_dir = os.environ["EMCC_SIZING_AWR_ROOT_DIR"]
    else:
        root_dir = os.getcwd()

    dir_path = os.path.join(root_dir, "awr_miner_occa", "log")

    return Path(dir_path).resolve()


def get_output_dir_path():
    """
    Return the path where the obfuscated files are going to be placed.

    Returns
    ----------
         Path : Path
            The full path to awr_miner_occa/log directory from the value of env variable
            EMCC_SIZING_AWR_ROOT_DIR or from the current execution directory.
    """

    if "EMCC_SIZING_AWR_ROOT_DIR" in os.environ:
        root_dir = os.environ["EMCC_SIZING_AWR_ROOT_DIR"]
    else:
        root_dir = os.getcwd()

    dir_path = os.path.join(root_dir, "awr_miner_out_obfuscated")

    return Path(dir_path).resolve()


def get_translation_dir_path():
    """
    Return the path where the translation file is placed.

    Returns
    ----------
         Path : Path
            The full path to awr_miner_occa/log directory from the value of env variable
            EMCC_SIZING_AWR_ROOT_DIR or from the current execution directory.
    """

    if "EMCC_SIZING_AWR_ROOT_DIR" in os.environ:
        root_dir = os.environ["EMCC_SIZING_AWR_ROOT_DIR"]
    else:
        root_dir = os.getcwd()

    dir_path = os.path.join(root_dir, "awr_miner_occa")

    return Path(dir_path).resolve()


# Debug function
def debug(txt):
    """
    Write the text passed to the debug array, if DEV_MODE is True it will write the same to stdout

    Parameters:
        txt : str
            The string to write to stdout
    """
    if DEBUG:
        debug_data.append(txt + "\n")
        if DEV_MODE:
            print(txt)


# Write the text passed to stdout and logFile
def log(txt):
    """
    Write the text passed to stdout and log array.

    Parameters:
        txt : str
            The string to write to stdout
    """
    print(txt)
    log_data.append(txt + "\n")


# Write the text passed to stdout as error
def log_err_to_stdout(txt):
    """
    Write the text passed to stdout as error.

    Parameters:
        txt : str
            The string to write to stdout
    """
    print("\nERROR: " + txt + "\n")


# Check directory existance and permissions
def check_dir(d: Path) -> bool:
    """
    Check if directory exists, is a directory and readable.

    Parameters:
        d  : Path
            The directory to apply the checks

    """

    if not os.path.exists(d):
        log_err_to_stdout("Directory " + str(d) + " is missing, cannot continue")
        return False
    elif not os.path.isdir(d):
        log_err_to_stdout("Directory " + str(d) + " is not a directory, cannot continue")
        return False
    elif not os.access(d, os.R_OK):
        log_err_to_stdout("Directory " + str(d) + " is not readable, cannot continue")
        return False
    else:
        return True


# Check file existance and permissions
def check_file(f: Path) -> bool:
    """
    Check if file exists, is a regular file and readable.

    Parameters:
        f  : Path
            The file to apply the checks
    """

    if not os.path.exists(f):
        log_err_to_stdout("File " + str(f) + " is missing; cannot continue")
        return False
    elif not os.path.isfile(f):
        log_err_to_stdout("File " + str(f) + " is not a regular file; cannot continue")
        return False
    elif not os.access(f, os.R_OK):
        log_err_to_stdout("File " + str(f) + " is not readable; cannot continue")
        return False
    else:
        return True


# Check the python version
def check_python_version(version: int):
    """
    Check if python version is higher than 3.x.

    Parameters:
        version : int
            The content of major field from sys.version_info
    """
    if version < 3:
        log_err_to_stdout("\nThis script requires python 3.x or higher; cannot continue")
        return False

    return True


def check_awr_miner_files_exist(d: Path):
    """
    Check if files named "awr-hist*.out" exist in the directory.
    Parameters
    ----------
        d : Path
            The path to search for the expected files

    Returns
    ----------
         files : list[str]
            The list of files matching the criteria

    """
    filelist = []
    try:
        filelist = sorted(fnmatch.filter(os.listdir(d), "awr-hist*.out"))
    except FileNotFoundError as e:
        pass

    if len(filelist) == 0:
        log_err_to_stdout(f"No files found in {str(d)}. Expecting awr-hist*.out files; cannot continue")
        filelist = []

    return filelist


def is_valid_file_name(fname: str) -> bool:
    """
    Check the file name passed matches the expected pattern.

    Parameters
    ----------
          fname : str
              The file name to check the pattern against

    Returns
    ----------
         bool : bool
            True if the filename matches the pattern, False otherwise
    """
    if re.match(AWR_MINER_FILE_NAME_PATTERN, fname):
        return True
    else:
        return False


def get_miner_file_name_pieces(fname) -> dict:
    """
    Get the values from the file name.

    Parameters
    ----------
          fname : str
              The file name to extract the values from

    Returns
    ----------
         dict : dict
              Dict containing the match groups of the regex applied
    """
    filepieces = {}
    match_groups = re.search(AWR_MINER_FILE_NAME_PATTERN, fname)

    # Get the pieces
    if match_groups:
        filepieces["dbid"] = match_groups.group(1)
        filepieces["dbname"] = match_groups.group(2)
        filepieces["snap_id_start"] = match_groups.group(3)
        filepieces["snap_id_end"] = match_groups.group(4)

    return filepieces


def write_file_from_list(ifil: str, ilist):
    """
    Write the contents of the list passed to a file , the file is created in the Output directory.

    Parameters:
        ifil : str
            The name of the file to create
        ilist : list[str]
            The list of strings to write into the file

    """
    line_sep = "\n"

    # Set the Output file
    # ofil_path = os.path.join(OUTPUT_DIR_PATH ,ifil)
    ofil_path = ifil

    # Write the file
    with open(ofil_path, "w") as o:
        o.write(line_sep.join(ilist))

    # Count the number of rows written
    count_fil = open(ofil_path, "r")
    totalrows = 0
    for _ in count_fil:
        totalrows += 1
    count_fil.close()


def mask_db_parameters_section(section_lst):
    """
    Mask the values of certain parameters in DATABASE-PARAMETERS and DATABASE-PARAMETER2 sections.

    Parameters:
        section_lst : list[str]
            The contents of either DATABASE-PARAMETERS or DATABASE-PARAMETERS2 section

    Returns:
        masked_section_list : list[str]
            The contents of the section with the values masked

    """
    masked_section_list = []
    replaced_line = ""
    instance_num = 0

    for i, l in enumerate(section_lst):
        new_line = " ".join(l.split())
        new_line_lst = new_line.split(" ")
        already_added = False
        if len(new_line_lst) > 1:
            instance_num = new_line_lst[0]

            # DATABASE-PARAMETERS2 line format:
            #  1 audit_file_dest /u01/app/oracle/product/19.0.0.0/dbhome_1/rdbms/audit
            stat_value = ""
            if instance_num in ["1", "2"]:
                if len(new_line_lst) > 2:
                    stat_name = new_line_lst[1]
                    for rest_of_str in new_line_lst[2::]:
                        stat_value += " " + rest_of_str
                else:
                    masked_section_list.append(l)
                    stat_name = ""
                    already_added = True
            # DATABASE-PARAMETERS line format:
            #  audit_file_dest /u01/app/oracle/product/19.0.0.0/dbhome_1/rdbms/audit
            else:
                stat_name = new_line_lst[0]
                for rest_of_str in new_line_lst[1::]:
                    stat_value += " " + rest_of_str

            # Mask the value
            if stat_name in MASK_DATABASE_PARAMETERS_TUPLE:
                new_stat_value = " " + MASK_STRING
                replaced_line = l.replace(stat_value, new_stat_value)
                masked_section_list.append(replaced_line)
            elif not already_added:
                masked_section_list.append(l)
        else:
            masked_section_list.append(l)

    return masked_section_list


def mask_segment_io_section(section_lst):
    """
    Mask the values of column OWNER in SEGMENT-IO section.

    Parameters:
        section_lst : list[str]
            The contents of SEGMENT-IO section

    Returns:
        masked_section_list : list[str]
            The contents of the section with the values masked

    """
    masked_section_list = []
    replaced_line = ""
    instance_num = 0

    for i, l in enumerate(section_lst):
        new_line = " ".join(l.split())
        new_line_lst = new_line.split(" ")

        if l.startswith("OWNER") or l.startswith("---") or l.startswith("~~"):
            masked_section_list.append(l)
        else:
            # Mask the values
            owner = new_line_lst[0]

            new_value = MASK_CHAR * len(owner)
            replaced_line = l.replace(owner, new_value)
            masked_section_list.append(replaced_line)

    return masked_section_list


def mask_top_sql_section(section_lst):
    """
    Mask the values of column OWNER in TOP-SQL-SUMMARY section.

    Parameters:
        section_lst : list[str]
            The contents of TOP-SQL-SUMMARY section

    Returns:
        masked_section_list : list[str]
            The contents of the section with the values masked

    """
    masked_section_list = []
    replaced_line = ""
    instance_num = 0

    for i, l in enumerate(section_lst):
        new_line = " ".join(l.split())
        new_line_lst = new_line.split(" ")

        if l.startswith("MODULE") or l.startswith("---") or l.startswith("~~"):
            masked_section_list.append(l)
        elif len(new_line_lst[0]) > 0:
            # Reverse the list as ACTION column contains whitespaces and PARSING_SCHEMA_NAME is in the middle of the table,
            # we know that after PARSING_SCHEMA_NAME column the rest of the columns are numbers not containing whitespaces
            new_line_lst_copy = new_line_lst.copy()
            new_line_lst_copy.reverse()

            parsing_schema = new_line_lst_copy[10]

            # Mask the values
            new_value = MASK_CHAR * len(parsing_schema)
            replaced_line = l.replace(parsing_schema, new_value)
            masked_section_list.append(replaced_line)
        else:
            masked_section_list.append(l)

    return masked_section_list


def mask_top_sql_by_snap_section(section_lst):
    """
    Mask the values of column PARSING_SCHEMA_NAME in TOP-SQL-BY-SNAPID section.

    Parameters:
        section_lst : list[str]
            The contents of TOP-SQL-BY-SNAPID section

    Returns:
        masked_section_list : list[str]
            The contents of the section with the values masked

    """
    masked_section_list = []
    replaced_line = ""
    instance_num = 0

    for i, l in enumerate(section_lst):
        new_line = " ".join(l.split())
        new_line_lst = new_line.split(" ")

        if l.startswith("   SNAP_ID") or l.startswith("---") or l.startswith("~~"):
            masked_section_list.append(l)
        elif len(new_line_lst[0]) > 0:
            # Mask the values
            parsing_schema = new_line_lst[1]

            new_value = MASK_CHAR * len(parsing_schema)
            replaced_line = l.replace(parsing_schema, new_value)
            masked_section_list.append(replaced_line)
        else:
            masked_section_list.append(l)

    return masked_section_list


def print_banner():
    """
    Print to stdout the tool banner.
    """
    log("=======================================================================================================")
    log(sys.argv[0] + ", version " + __version__)
    log("sys.version_info  : " + str(sys.version_info))
    log("platform.system() : " + str(platform.system()))
    log("=======================================================================================================")


def create_dir(out_dir: Path) -> bool:
    # Create the output directory
    try:
        os.makedirs(out_dir)
    except OSError as e:
        if e.errno == errno.EEXIST:
            log("Using existing directory :" + str(out_dir))
            return True
    except Exception as e:
        log("Exception creating directory :" + str(out_dir))
        log("Exception " + str(e))
        return False
    else:
        log("Created directory :" + str(out_dir))
        return True


def main():
    global TRANSLATION_FILE_NAME
    global db_name, db_id, min_snap, max_snap

    # Get the Paths
    AWR_OUT_DIR_PATH = get_awr_out_dir_path()
    OUTPUT_DIR_PATH = get_output_dir_path()
    AWR_LOG_DIR_PATH = get_awr_log_dir_path()
    TRANSLATION_DIR_PATH = get_translation_dir_path()

    # Print the tool banner
    print_banner()

    # Check the python version
    if not (check_python_version(sys.version_info.major)):
        exit(1)

    # Check the input directory
    if not (check_dir(AWR_OUT_DIR_PATH)):
        exit(1)

    # Create the output directory
    if not (create_dir(OUTPUT_DIR_PATH)):
        exit(1)

    # Create the log directory
    if not (create_dir(AWR_LOG_DIR_PATH)):
        exit(1)

    # Define log and debug file
    fnam = os.path.basename(__file__)
    log_file_path = os.path.join(AWR_LOG_DIR_PATH, fnam + ".log")
    dbg_file_path = os.path.join(AWR_LOG_DIR_PATH, fnam + ".dbg")

    # Remove previous copies of log and debug file
    if os.path.exists(log_file_path):
        os.remove(log_file_path)

    if os.path.exists(dbg_file_path):
        os.remove(dbg_file_path)

    # Get the files in awr_miner_out directory
    awr_miner_files = check_awr_miner_files_exist(AWR_OUT_DIR_PATH)

    # Iterate though each of the files
    for awr_miner_file in awr_miner_files:
        awr_miner_file_name = awr_miner_file
        awr_miner_file = os.path.join(AWR_OUT_DIR_PATH, awr_miner_file)

        # Check AWR Miner file name
        if not is_valid_file_name(awr_miner_file_name):
            log_err_to_stdout("     Collection file name does not match the naming convention, Skipping file...")
            return

        # Get the values from the file name
        file_pieces = get_miner_file_name_pieces(awr_miner_file_name)
        db_id = file_pieces["dbid"]
        db_name = file_pieces["dbname"]
        min_snap = int(file_pieces["snap_id_start"])
        max_snap = int(file_pieces["snap_id_end"])

        log("\nObfuscating " + awr_miner_file + "....")
        obs_file = ""
        current_db_name = db_name

        # Open the file
        try:
            f = open(awr_miner_file)
            lines = f.read().splitlines()
        except UnicodeDecodeError:
            f = open(awr_miner_file, encoding="ISO-8859-1")
            lines = f.read().splitlines()
        except OSError:
            f = open(awr_miner_file, encoding="ISO-8859-1")
            lines = f.read().splitlines()

        # Control flags to detect start and end of sections
        start = False
        end = False
        start_db_params_section = False
        end_db_params_section = False
        start_segment_io_section = False
        end_segment_io_section = False
        start_top_sql_section = False
        end_top_sql_section = False
        start_top_sql_by_snap_section = False
        end_top_sql_by_snap_section = False

        # Loop through the file lines
        new_lines = []
        new_masked_lines = []
        for i, l in enumerate(lines):
            if "~~BEGIN-OS-INFORMATION~~" in l:
                start = True
                new_lines.append(l)
            elif "~~END-OS-INFORMATION~~" in l:
                end = True
                new_lines.append(l)
            elif l in ["~~BEGIN-DATABASE-PARAMETERS~~", "~~BEGIN-DATABASE-PARAMETERS2~~"]:
                start_db_params_section = True
                new_masked_lines.append(l)
            elif l in ["~~END-DATABASE-PARAMETERS~~", "~~END-DATABASE-PARAMETERS2~~"]:
                end_db_params_section = True
                new_masked_lines.append(l)
            elif "~~BEGIN-SEGMENT-IO~~" in l:
                start_segment_io_section = True
                new_masked_lines.append(l)
            elif "~~END-SEGMENT-IO~~" in l:
                end_segment_io_section = True
                new_masked_lines.append(l)
            elif "~~BEGIN-TOP-SQL-SUMMARY~~" in l:
                start_top_sql_section = True
                new_masked_lines.append(l)
            elif "~~END-TOP-SQL-SUMMARY~~" in l:
                end_top_sql_section = True
                new_masked_lines.append(l)
            elif "~~BEGIN-TOP-SQL-BY-SNAPID~~" in l:
                start_top_sql_by_snap_section = True
                new_masked_lines.append(l)
            elif "~~END-TOP-SQL-BY-SNAPID~~" in l:
                end_top_sql_by_snap_section = True
                new_masked_lines.append(l)

            # Obfuscate the values in OS-INFORMATION section
            elif start and not end:
                if l.startswith(LINES_START_WITH_TUPLE):
                    # Get the relevant columns to obfuscate
                    for tup in OBFUSCATE_COLS:
                        obs_col_name = tup[0]
                        target_type = tup[1]
                        stat_value = ""
                        if l.startswith(obs_col_name):
                            new_line = " ".join(l.split())
                            new_line_lst = new_line.split(" ")
                            if len(new_line_lst) == 2:
                                stat_name = new_line_lst[0]
                                stat_value = new_line_lst[1]
                                stat_value_list = stat_value.split(",")

                                # Obfuscate the values
                                new_line = l
                                for val in stat_value_list:
                                    if target_type not in targets:
                                        targets[target_type] = {}

                                    # Compose the obfuscation key in the dict
                                    obs_key = "_".join([val, db_id, str(min_snap), str(max_snap)])
                                    obs_value = target_type + "-" + str(len(targets[target_type])).zfill(5)

                                    file = "awr-hist-" + str(db_id) + "-" + db_name + "-" + str(min_snap) + "-" + str(max_snap) + ".out"
                                    if len(current_db_name) > 0:
                                        obs_file = (
                                            "awr-hist-" + str(db_id) + "-" + obs_value + "-" + str(min_snap) + "-" + str(max_snap) + ".out"
                                        )
                                        current_db_name = ""

                                    targets[target_type][obs_key] = {
                                        "original_value": val,
                                        "obfuscated_value": obs_value,
                                        "original_file": file,
                                        "obfuscated_file": obs_file,
                                    }

                                    # Replace the line with obfuscated values
                                    new_line = new_line.replace(val, obs_value)

                                # Add the replaced line
                                new_lines.append(new_line)
                else:
                    new_lines.append(l)

            # Use the Obfuscated values if those are present in the coming lines
            elif l.startswith(LINES_START_WITH_TUPLE):
                replaced_line = l
                new_line = " ".join(l.split())
                new_line_lst = new_line.split(" ")
                if len(new_line_lst) == 3:
                    stat_name = new_line_lst[0]
                    stat_value = new_line_lst[2]

                for target_type, target_info in targets.items():
                    target_keys = list(target_info.keys())
                    for k in target_keys:
                        target_values = target_info.get(k)
                        if stat_value in target_values.values():
                            new_stat_value = target_values["obfuscated_value"]
                            replaced_line = replaced_line.replace(stat_value, new_stat_value)
                            new_lines.append(replaced_line)

            # Mask the values in DATABASE-PARAMETER and DATABASE-PARAMETER2 section
            elif start_db_params_section and not end_db_params_section:
                new_masked_lines.append(l)
            elif end_db_params_section:
                database_parameters_masked = mask_db_parameters_section(new_masked_lines)
                new_lines = new_lines + database_parameters_masked
                new_masked_lines = []
                start_db_params_section = False
                end_db_params_section = False
                new_lines.append(l)

            # Mask the values in SEGMENT_IO section
            elif start_segment_io_section and not end_segment_io_section:
                new_masked_lines.append(l)
            elif end_segment_io_section:
                segment_io_masked = mask_segment_io_section(new_masked_lines)
                new_lines = new_lines + segment_io_masked
                new_masked_lines = []
                start_segment_io_section = False
                end_segment_io_section = False
                new_lines.append(l)

            # Mask the values in TOP-SQL-SUMMARY section
            elif start_top_sql_section and not end_top_sql_section:
                new_masked_lines.append(l)
            elif end_top_sql_section:
                top_sql_masked = mask_top_sql_section(new_masked_lines)
                new_lines = new_lines + top_sql_masked
                new_masked_lines = []
                start_top_sql_section = False
                end_top_sql_section = False
                new_lines.append(l)

            # Mask the values in TOP-SQL-BY-SNAPID section
            elif start_top_sql_by_snap_section and not end_top_sql_by_snap_section:
                new_masked_lines.append(l)
            elif end_top_sql_by_snap_section:
                top_sql_by_snap_masked = mask_top_sql_by_snap_section(new_masked_lines)
                new_lines = new_lines + top_sql_by_snap_masked
                new_masked_lines = []
                start_top_sql_by_snap_section = False
                end_top_sql_by_snap_section = False
                new_lines.append(l)

            else:
                new_lines.append(l)

        # Write the obsfucated file
        obs_file_path = os.path.join(OUTPUT_DIR_PATH, obs_file)
        write_file_from_list(obs_file_path, new_lines)
        log(" Wrote " + str(i) + " rows to file " + str(OUTPUT_DIR_PATH) + os.sep + obs_file + "....")

    # Create the translation file
    translation_file_path = os.path.join(TRANSLATION_DIR_PATH, TRANSLATION_FILE_NAME + ".csv")
    if os.path.exists(translation_file_path):
        os.remove(translation_file_path)

    o = open(translation_file_path, "w", newline="")
    writer = csv.DictWriter(
        o, fieldnames=["target_type", "target_name", "original_value", "obfuscated_value", "original_file", "obfuscated_file"]
    )
    writer.writeheader()

    for targetType in targets:
        r = {"target_type": targetType}

        for targetName in targets[targetType]:
            r["target_name"] = targetName.split("_")[0]

            r["obfuscated_value"] = targets[targetType][targetName]["obfuscated_value"]
            r["original_value"] = targets[targetType][targetName]["original_value"]
            r["original_file"] = targets[targetType][targetName]["original_file"]
            r["obfuscated_file"] = targets[targetType][targetName]["obfuscated_file"]

            writer.writerow(r)

    o.close()

    print("\nWrote translation to file: " + translation_file_path)

    # Write log array to file
    with open(log_file_path, "w") as f:
        for line in log_data:
            f.write(line)

    # Write debug array to file
    if DEBUG:
        with open(dbg_file_path, "w") as f:
            for line in debug_data:
                f.write(line)


if __name__ == "__main__":
    main()
