__version__ = '1.8'

#
# Version History
#
# 2024-06-21    1.8  lmo     Include fixes to remove occa dependencies
# 2022-07-15    1.7  pro     Obfuscate dir emcc_sizing_extracts_filtered if exists
# 2021-02-20    1.6  tmf     Added cluster
# 2021-02-16    1.5  tmf     Accommodate older extract files
# 2021-01-29    1.4  tmf     Exception handler for error conditions
# 2021-01-16    1.3  tmf     Prevent extra newline
# 2021-01-15    1.2  tmf     Added remaining files
# 2021-01-14    1.1  tmf     Initial version

#
# We are explicitly NOT obfuscating emcc_sizing_structure_host_vm.csv which means this file is being left behind
#

import csv
import datetime
import fnmatch
import os
import platform
import sys
import time
# ---

APPENDO           = True if 'EMCC_SIZING_OBFUSCATE_APPENDO'           in os.environ and os.environ['EMCC_SIZING_OBFUSCATE_APPENDO'].upper() == 'Y' else False
DEBUG             = True if 'EMCC_SIZING_OBFUSCATE_DEBUG'             in os.environ and os.environ['EMCC_SIZING_OBFUSCATE_DEBUG'].upper()   == 'Y' else False
PROCESS_TELEMETRY = True if 'EMCC_SIZING_OBFUSCATE_PROCESS_TELEMETRY' not in os.environ else (os.environ['EMCC_SIZING_OBFUSCATE_PROCESS_TELEMETRY'].upper() != 'N')

ROOT_DIR          = os.environ['EMCC_SIZING_EXTRACTFILES_ROOT_DIR'] if 'EMCC_SIZING_EXTRACTFILES_ROOT_DIR' in os.environ else '.'

# ---

targets={}

# ----------------------------------------------------------------------------------------------------------------------

def addTarget(targetName, targetType, targetGUID, lookupOnly=False):
    if targetName is None or targetType is None:
        lg('Warning: Invalid inpur; check the input file for possible error condition(s)')

        return 'None.None'

    if targetType not in targets:
        if lookupOnly: return ''

        targets[targetType] = {}

    if targetGUID in targets[targetType]:
        return targets[targetType][targetGUID]['obfuscated']

    elif lookupOnly: return ''

    try:
        targetNameObs                   = (targetName + ' : ' if DEBUG else '') + targetType.replace('_','-') + '-' + str(len(targets[targetType])).zfill(5)
    except Exception as fc:
        lg('Exception ' + str(fc) + ' raised')
        lg('targetName              : ' + str(targetName))
        lg('targetType              : ' + str(targetType))
        lg('len(targets[targetType]): ' + str(len(targets[targetType])))

        quit()

    targets[targetType][targetGUID] = {'original' : targetName, 'obfuscated' : targetNameObs}

    return targetNameObs

# ----------------------------------------------------------------------------------------------------------------------

def lg(t):

    print(t)
    logFile.write(t + '\n')


# ----------------------------------------------------------------------------------------------------------------------

print('=======================================================================================================\n')
print(sys.argv[0] + ', version ' + __version__)
print('\n=======================================================================================================')

# ----------------------------------------------------------------------------------------------------------------------

extractRawFilePath = ROOT_DIR + os.sep + 'emcc_sizing_extracts'
obfuscatedRawPath  = ROOT_DIR + os.sep + 'emcc_sizing_extracts_obfuscated'
translationRawFile = 'obfuscated_translation'

extractFilteredFilePath = ROOT_DIR + os.sep + 'emcc_sizing_extracts_filtered'
obfuscatedFilteredPath  = ROOT_DIR + os.sep + 'emcc_sizing_extracts_filtered_obfuscated'
translationFilteredFile = 'obfuscated_translation_filtered'

if os.path.exists('emcc_sizing_extracts_filtered'):
    extractFilePath  = extractFilteredFilePath
    obfuscatedPath   = obfuscatedFilteredPath
    TRANSLATION_FILE = translationFilteredFile
elif os.path.exists('emcc_sizing_extracts'):
    extractFilePath  = extractRawFilePath
    obfuscatedPath   = obfuscatedRawPath
    TRANSLATION_FILE = translationRawFile

h, t               = os.path.split(sys.argv[0])
logFilename        = ROOT_DIR + os.sep + 'emcc_sizing_output' + os.sep + 'log' + os.sep + t + '.log'
os.makedirs(ROOT_DIR + os.sep + 'emcc_sizing_output' + os.sep + 'log', exist_ok=True)
logFile            = open(logFilename, 'a')

lg('\n\n=======================================================================================================\n')
lg('Begin @ ' + datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S") + ' UTC\n')
lg(sys.argv[0] + ', version ' + __version__ + '\n')
lg('sys.version_info  : ' + str(sys.version_info))
lg('platform.system() : ' + str(platform.system()))
lg('\n=======================================================================================================\n')

# ----------------------------------------------------------------------------------------------------------------------

lg('\n=======================================================================================================\n')

lg('DIR              : ' + extractFilePath)
lg('APPENDO          : ' + str(APPENDO))
lg('DEBUG            : ' + str(DEBUG))
lg('PROCESS_TELEMETRY: ' + str(PROCESS_TELEMETRY))
lg('ROOT_DIR         : ' + str(ROOT_DIR))

lg('\n=======================================================================================================\n')

# ----------------------------------------------------------------------------------------------------------------------

if sys.version_info.major >= 3:
    pass
else:
    lg('\nThis script requires python 3.x or higher; cannot continue')
    assert(False)

if os.path.exists('emcc_sizing_output'):
    pass
else:
    lg('\nCannot find directory emcc_sizing_output; unable to continue')
    assert(False)

# ---

startTime = time.time()
cwd       = os.getcwd().split(os.sep)[-1]

if os.path.exists(obfuscatedPath):
    suffix=datetime.datetime.utcnow().strftime("%Y-%m-%d-%H-%M-%S") + '_UTC'
    lg('\nDirectory ' + obfuscatedPath + ' already exists; renaming to ' + obfuscatedPath + '_' + suffix)

    os.rename(obfuscatedPath, obfuscatedPath + '_' + suffix)

    if os.path.exists(ROOT_DIR + os.sep + 'emcc_sizing_output' + os.sep + TRANSLATION_FILE + '.csv'):
        os.rename(ROOT_DIR + os.sep + 'emcc_sizing_output' + os.sep + TRANSLATION_FILE + '.csv', ROOT_DIR + os.sep + 'emcc_sizing_output' + os.sep + TRANSLATION_FILE + '_' + suffix + '.csv')

os.makedirs(obfuscatedPath, exist_ok=True)
# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_db'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        if l['dbmachine'] not in ['', 'none']:
            obs            = addTarget(l['dbmachine'], 'oracle_dbmachine', l['dbmachine_target_guid'])
            r['dbmachine'] = obs

        if l['dbmachine_owner'] not in ['', 'none']:
            obs                  = addTarget(l['dbmachine_owner'], 'owner', l['dbmachine_owner'])
            r['dbmachine_owner'] = obs

        if l['cluster'] not in ['', 'none']:
            if 'cluster_target_guid' in l:
                obs          = addTarget(l['cluster'], 'cluster', l['cluster_target_guid'])
                r['cluster'] = obs
            else:
                obs            = addTarget(l['cluster'], 'cluster', l['cluster'])
                r['cluster'] = obs

        if 'cluster_owner' in l and l['cluster_owner'] not in ['', 'none']:
            obs                = addTarget(l['cluster_owner'], 'owner', l['cluster_owner'])
            r['cluster_owner'] = obs

        if l['cdb_type'] in ['', 'none']:
            pass
        elif l['cdb_type'] in ['oracle_database', 'rac_database']:
            obs      = addTarget(l['cdb'],  l['cdb_type'], l['cdb_target_guid'])
            r['cdb'] = obs
        else:
            lg('Unexpected value for cdb_type: ' + l['cdb_type'])
            assert(False)

        if l['cdb_owner'] not in ['', 'none']:
            obs            = addTarget(l['cdb_owner'], 'owner', l['cdb_owner'])
            r['cdb_owner'] = obs

        if l['db'] not in ['', 'none']:
            obs     = addTarget(l['db'], 'oracle_database', l['db_target_guid'])
            r['db'] = obs

        if 'db_owner' in l and l['db_owner'] not in ['', 'none']:
            obs           = addTarget(l['db_owner'], 'owner', l['db_owner'])
            r['db_owner'] = obs

        if l['host'] not in ['', 'none']:
            obs       = addTarget(l['host'], 'host', l['host_target_guid'])
            r['host'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_availability_history'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        owner_obs = addTarget(l['OWNER'], 'owner', l['TARGET_GUID'])
        r['OWNER'] = owner_obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_db_dr'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        if l['STDBY_TARGET_TYPE'] in ['oracle_database', 'rac_database']:
            obs                    = addTarget(l['STDBY_TARGET_NAME'], l['STDBY_TARGET_TYPE'], l['STDBY_TARGET_GUID'])
            r['STDBY_TARGET_NAME'] = obs
        else:
            lg('Unexpected value for STDBY_TARGET_TYPE: ' + l['STDBY_TARGET_TYPE'])
            assert(False)

        if l['PRI_TARGET_TYPE'] == 'oracle_database':
            obs                  = addTarget(l['PRI_TARGET_NAME'], l['PRI_TARGET_TYPE'], l['PRI_TARGET_GUID'])
            r['PRI_TARGET_NAME'] = obs

            obs                     = addTarget(l['PRI_DB_UNIQUE_NAME'], 'database_name', l['PRI_DB_UNIQUE_NAME'])
            r['PRI_DB_UNIQUE_NAME'] = obs

        elif l['PRI_TARGET_TYPE'] == 'rac_database':
            obs                  = addTarget(l['PRI_TARGET_NAME'], l['PRI_TARGET_TYPE'], l['PRI_TARGET_GUID'])
            r['PRI_TARGET_NAME'] = obs

            obs                     = addTarget(l['PRI_DB_UNIQUE_NAME'], 'rac_name', l['PRI_DB_UNIQUE_NAME'])
            r['PRI_DB_UNIQUE_NAME'] = obs

        else:
            lg('Unexpected value for PRI_TARGET_TYPE: ' + l['PRI_TARGET_TYPE'])

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_db_params'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_db_props'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_db_services'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        obs              = addTarget(l['HOST_NAME'], 'host_name', l['HOST_NAME'])
        r['HOST_NAME']   = obs

        if l['NAME'][:3] != 'SYS':
            obs       = addTarget(l['NAME'], 'network_name', l['NAME'])
            r['NAME'] = obs

            obs               = addTarget(l['NETWORK_NAME'], 'network_name', l['NETWORK_NAME'])
            r['NETWORK_NAME'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')
# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_db_sga'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_db_vm'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        if l['dbmachine'] not in ['', 'none']:
            obs            = addTarget(l['dbmachine'], 'oracle_dbmachine', l['dbmachine_guid'])
            r['dbmachine'] = obs

        if l['si_rack'] not in ['', 'none']:
            obs          = addTarget(l['si_rack'], 'si_server_rack', l['si_rack_guid'])
            r['si_rack'] = obs

        if l['si_server_map'] not in ['', 'none']:
            obs                = addTarget(l['si_server_map'], 'si_server_map', l['si_server_map_guid'])
            r['si_server_map'] = obs

        if l['si_virtual_platform'] not in ['', 'none']:
            obs                      = addTarget(l['si_virtual_platform'], 'si_virtual_platform', l['si_virtual_platform_guid'])
            r['si_virtual_platform'] = obs

        if l['si_virtual_server'] not in ['', 'none']:
            obs                      = addTarget(l['si_virtual_server'], 'si_virtual_server', l['si_virtual_server_guid'])
            r['si_virtual_platform'] = obs

        if l['h_from_dbmachine'] not in ['', 'none']:
            obs                      = addTarget(l['h_from_dbmachine'], 'host', l['h_from_dbmachine_guid'])
            r['h_from_dbmachine'] = obs

        if l['h_from_si_server_map'] not in ['', 'none']:
            obs                      = addTarget(l['h_from_si_server_map'], 'host', l['h_from_server_map_guid'])
            r['h_from_si_server_map']= obs

        if l['h_from_si_virtual_server'] not in ['', 'none']:
            obs                          = addTarget(l['h_from_si_virtual_server'], 'host', l['h_from_si_vs_guid'])
            r['h_from_si_virtual_server']= obs

        if l['h'] not in ['', 'none']:
            obs   = addTarget(l['h'], 'host', l['h_guid'])
            r['h']= obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_host_cpu'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['target_name'], 'host', l['target_guid'])
        r['target_name'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_host_props'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], 'host', l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')
# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_pdb_params'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_pdb_props'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_pdb_sga'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
        r['TARGET_NAME'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_sm'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs                = addTarget(l['si_server_map'], 'si_server_map', l['si_server_map_guid'])
        r['si_server_map'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_pdb'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        if l['dbmachine'] not in ['', 'none']:
            obs            = addTarget(l['dbmachine'], 'oracle_dbmachine', l['dbmachine_target_guid'])
            r['dbmachine'] = obs

        if l['dbmachine_owner'] not in ['', 'none']:
            obs                  = addTarget(l['dbmachine_owner'], 'owner', l['dbmachine_owner'])
            r['dbmachine_owner'] = obs

        if l['cluster'] not in ['', 'none']:
            if 'cluster_target_guid' in l:
                obs          = addTarget(l['cluster'], 'cluster', l['cluster_target_guid'])
                r['cluster'] = obs
            else:
                obs            = addTarget(l['cluster'], 'cluster', l['cluster'])
                r['cluster'] = obs

        if 'cluster_owner' in l and l['cluster_owner'] not in ['', 'none']:
            obs                = addTarget(l['cluster_owner'], 'owner', l['cluster_owner'])
            r['cluster_owner'] = obs

        if l['cdb_type'] in ['', 'none']:
            pass
        elif l['cdb_type'] in ['oracle_database', 'rac_database']:
            obs      = addTarget(l['cdb'],  l['cdb_type'], l['cdb_target_guid'])
            r['cdb'] = obs
        else:
            lg('Unexpected value for cdb_type: ' + l['cdb_type'])
            assert(False)

        if l['cdb_owner'] not in ['', 'none']:
            obs            = addTarget(l['cdb_owner'], 'owner', l['cdb_owner'])
            r['cdb_owner'] = obs

        if l['pdb'] not in ['', 'none']:
            obs      = addTarget(l['pdb'], 'oracle_pdb', l['pdb_target_guid'])
            r['pdb'] = obs

        if 'pd_owner' in l and l['pdb_owner'] not in ['', 'none']:
            obs            = addTarget(l['pdb_owner'], 'owner', l['pdb_owner'])
            r['pdb_owner'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_vp'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs                      = addTarget(l['si_virtual_platform'], l['vp_type'], l['si_virtual_platform_guid'])
        r['si_virtual_platform'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_vp2'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs                      = addTarget(l['si_server'], l['si_server_type'], l['si_server_guid'])
        r['si_server']           = obs

        obs                      = addTarget(l['si_virtual_platform'], l['vp_type'], l['si_virtual_platform_guid'])
        r['si_virtual_platform'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_vs'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs                    = addTarget(l['si_virtual_server'], l['vs_type'], l['si_virtual_server_guid'])
        r['si_virtual_server'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

fname = 'emcc_sizing_structure_vs2'

if os.path.exists(extractFilePath + os.sep + fname + '.csv') and 1 == 1:
    lg('\nObfuscating ' + extractFilePath + os.sep + fname + '.csv....')

    i      = open(extractFilePath + os.sep + fname                            + '.csv', 'r')
    o      = open(obfuscatedPath  + os.sep + fname + ('o' if APPENDO else '') + '.csv', 'w', newline='')

    header = [h.strip().strip('"') for h in i.readline().split(',')]
    reader = csv.DictReader(i, fieldnames=header)
    writer = csv.DictWriter(o, fieldnames=header)
    writer.writeheader()

    for ctr, l in enumerate(reader):
        r = l.copy()

        obs                    = addTarget(l['si_virtual_server'], 'si_virtual_server', l['si_virtual_server_guid'])
        r['si_virtual_server'] = obs

        writer.writerow(r)

    i.close()
    o.close()

    lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

if PROCESS_TELEMETRY:
    for fname in os.listdir(extractFilePath):
        if not fnmatch.fnmatch(fname, 'emcc_sizing_metrics*.csv'):
            continue

        lg('\nObfuscating ' + extractFilePath + os.sep + fname[:-4] + '.csv....')

        i      = open(extractFilePath + os.sep + fname[:-4]                            + '.csv', 'r')
        o      = open(obfuscatedPath  + os.sep + fname[:-4] + ('o' if APPENDO else '') + '.csv', 'w', newline='')

        header = [h.strip().strip('"') for h in i.readline().split(',')]
        reader = csv.DictReader(i, fieldnames=header)
        writer = csv.DictWriter(o, fieldnames=header)
        writer.writeheader()

        for ctr, l in enumerate(reader):
            r = l.copy()

            obs              = addTarget(l['TARGET_NAME'], l['TARGET_TYPE'], l['TARGET_GUID'])
            r['TARGET_NAME'] = obs

            writer.writerow(r)

        i.close()
        o.close()

        lg('Wrote ' + str(ctr + 1) + ' rows to file ' + obfuscatedPath + os.sep + fname[:-4] + ('o' if APPENDO else '') + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

o      = open(ROOT_DIR + os.sep + 'emcc_sizing_output' + os.sep + TRANSLATION_FILE + '.csv', 'w', newline='')
writer = csv.DictWriter(o, fieldnames=['target_type', 'target_guid', 'obfuscated', 'original'])
writer.writeheader()

for targetType in targets:
    r = {}
    r['target_type'] = targetType

    for targetGUID in targets[targetType]:
        r['target_guid'] = targetGUID

        r['obfuscated']  = targets[targetType][targetGUID]['obfuscated']
        r['original']    = targets[targetType][targetGUID]['original']

        writer.writerow(r)

o.close()

print('\nWrote translation to file: ' + ROOT_DIR + os.sep + 'emcc_sizing_output' + os.sep + TRANSLATION_FILE + '.csv')

# ----------------------------------------------------------------------------------------------------------------------

lg('\n\nAll files written to directories rooted @ ' + (cwd if ROOT_DIR == '.' else ROOT_DIR))
lg('\nProcessing completed in ' + str(round(time.time() - startTime, 3)) + ' s')

lg('\nEnd @ ' + datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S") + ' UTC\n')

logFile.close()
