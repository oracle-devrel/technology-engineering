#!/bin/sh

#
# Version 1.16
#
# Version History
# 2022-05-05    1.16  mgr     Added new script to capture list of EM jobs
# 2022-03-24    1.15  mgr     Added new script to capture list of EM metrics
# 2022-03-21    1.14  mgr     Merged hourly scripts into this
# 2021-03-24    1.13  tmf     Added redo
# 2021-01-15    1.12  tmf     Added services
# 2020-11-19    1.11  tmf     Added NLS_LANG
# 2020-10-11    1.10  tmf     Corrected lines for test & development; moved structured queries first
# 2020-09-21    1.9   tmf     Added debugging lines for testing in tmf development environment
# 2020-09-13    1.8   tmf     Added Get_EMCC_Sizing_Structure_Host_CPU.sql
# 2020-09-07    1.7   tmf     Changed run order to match script name sort order
# 2020-07-26    1.6   tmf     Added structural pulls
# 2020-05-06    1.5   tmf     Added comment about 12.2
# 2020-04-18    1.4   tmf     Moved hourly to separate script
# 2020-04-02    1.4   tmf     Rename HA extract
# 2020-04-02    1.3   tmf     Added HA extract
# 2020-03-21    1.2   tmf     Upgrades from testing
# 2020-03-11    1.1   tmf     First version
#

#
# Change the following line to point to SQL*Plus -- version 12.2 or greater is preferred
#

SQLPLUS_EXE=/scratch/ctdinkel/opt/oracle/instantclient_18_3/sqlplus
EXTRACT_SQL=.
export NLS_LANG=AMERICAN_AMERICA

#
# Change the following line to point to include username, password @ connect string for EMCC Repository
#

unpwcs=sysman/"password"@'(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = omrhost)(PORT = 1521)))(LOAD_BALANCE = ON)(CONNECT_DATA = (SERVICE_NAME = omrservice)))'

#
# the following line is for debugging only
#. ./env.sh
#

# ----------------------------------------------------------------------------------------------------------------------

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_DR.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_Params.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_Props.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_Redo.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_Services.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_SGA.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Host_Props.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_PDB_Params.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_PDB_Props.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_PDB_SGA.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_DB.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_DB_VM.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_Host_CPU.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_Host_VM.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_PDB.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_VM.sql

# ---

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Availability_History.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_EM_Jobs.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_EM_Metrics.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_DB_daily_03_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_DB_daily_06_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_DB_daily_09_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_DB_daily_12_months.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_Host_daily_03_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_Host_daily_06_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_Host_daily_09_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_Host_daily_12_months.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_PDB_daily_03_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_PDB_daily_06_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_PDB_daily_09_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_PDB_daily_12_months.sql

# ---

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_Host_hourly_03_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_DB_hourly_03_months.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_PDB_hourly_03_months.sql

