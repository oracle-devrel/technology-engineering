#!/bin/sh

cd emcc_sizing_extracts_original

for FILE in *months*.csv;
do
	cat $FILE | sed 's/"",""/","/g' | sed 's/,""/,"/g' | sed 's/"",/",/g' | sed 's/"""/"/g' | sed 's/ ,"/","/g' | sed 's/^.//' | sed '2,$s/".$//g' > ../emcc_sizing_extracts/$FILE
done

for FILE in *structure*.csv;
do
	cat $FILE | sed 's/"",""/","/g' | sed 's/,""/,"/g' | sed 's/"",/",/g' | sed 's/"""/"/g' | sed 's/"" ,"/","/g' | sed 's/^.//' | sed 's/ ,"/","/g' > ../emcc_sizing_extracts/$FILE
done

for FILE in *availability*.csv;
do
	cat $FILE | sed 's/"",""/","/g' | sed 's/,""/,"/g' | sed 's/"",/",/g' | sed 's/"""/"/g' | sed 's/"" ,"/","/g' | sed 's/^.//' | sed 's/ ,"/","/g' > ../emcc_sizing_extracts/$FILE
done
