#!/usr/bin/env bash
BASE_PATH=$(pwd)

if [[ ! -d "$BASE_PATH" ]]
then
	echo "ERROR: Not Found $BASE_PATH"
	exit 1
fi

#---------------------------------------------------------------------------------------------------
# Create the EMCC extracts artifact
#---------------------------------------------------------------------------------------------------

rm -rf "$BASE_PATH"/zipping_extracts
mkdir "$BASE_PATH"/zipping_extracts
cp -R "$BASE_PATH"/extracts "$BASE_PATH"/zipping_extracts

# Get the copy from dist dir as it has the EXTRACTS_VER var already replaced
cp "$BASE_PATH"/dist/Get_EMCC_Sizing_Interactive.sh \
   "$BASE_PATH"/zipping_extracts/extracts/Get_EMCC_Sizing_Interactive.sh

# Get the copy from dist dir as it has the AWR_MINER_VER and AWR_MINER_LITE_VER vars already replaced
cp "$BASE_PATH"/dist/awr_miner.sql \
   "$BASE_PATH"/zipping_extracts/extracts/awr_miner.sql

cp "$BASE_PATH"/dist/awr_miner_lite.sql \
   "$BASE_PATH"/zipping_extracts/extracts/awr_miner_lite.sql

# Moved Interactive scripts into the main directory but put a copy in old location for a while, stop after 12/2022
cp -p "$BASE_PATH"/zipping_extracts/extracts/Get_EMCC_Sizing_Interactive.* \
      "$BASE_PATH"/zipping_extracts/extracts/extras

cp "$BASE_PATH"/extracts/Extracts-Users-Guide.pdf "$BASE_PATH"/zipping_extracts/Extracts-Users-Guide.pdf
cp "$BASE_PATH"/extracts/Readme-EMCC-Extract.txt   "$BASE_PATH"/zipping_extracts/Readme-EMCC-Extract.txt
cp "$BASE_PATH"/extracts/Readme-AWR-Miner.txt  "$BASE_PATH"/zipping_extracts/Readme-AWR-Miner.txt

date > "$BASE_PATH"/zipping_extracts/extracts/date.txt

# Create the zip file
cd "$BASE_PATH"/zipping_extracts
zip -r extracts.zip extracts -x extracts/.DS_Store
if [[ $? -gt 0 ]]
then
  echo "ERROR creating zip on zipping_extracts directory"
fi


#---------------------------------------------------------------------------------------------------
# Create the AWR Miner artifact
#---------------------------------------------------------------------------------------------------
rm -rf "$BASE_PATH"/zipping_awrminer
mkdir -p "$BASE_PATH"/zipping_awrminer/awr_miner

cp "$BASE_PATH"/extracts/Extracts-Users-Guide.pdf "$BASE_PATH"/zipping_awrminer/awr_miner/Extracts-Users-Guide.pdf
cp "$BASE_PATH"/extracts/Readme-AWR-Miner.txt  "$BASE_PATH"/zipping_awrminer/awr_miner/Readme-AWR-Miner.txt

cp -R "$BASE_PATH"/dist/awr* \
      "$BASE_PATH"/extracts/Obfuscate_Awr.py \
      "$BASE_PATH"/zipping_awrminer/awr_miner

# Create the zip file
cd "$BASE_PATH"/zipping_awrminer
zip -r AWR-Miner.zip awr_miner -x awr_miner/.DS_Store
if [[ $? -gt 0 ]]
then
 echo "ERROR creating zip on zipping_awrminer directory"
fi

