rem
rem Version 1.1
rem

rem Version History
rem
rem 2020-11-05    1.1  tmf     First version
rem

SELECT guid
FROM
(
SELECT   DISTINCT
         ',HEXTORAW(''' || a.metric_guid || ''') -- ' || a.metric_label || ', ' || a.column_label AS guid
        ,a.metric_label, a.column_label
FROM     sysman.mgmt$target_type a
WHERE    a.metric_label IN (
                            'IPCS Shared Memory Status'
                           )
AND      a.column_label IN (
                            'Group'
                           ,'Owner'
                           ,'Segment Size in MB'
                           )
AND      a.target_type   = 'host'
ORDER BY a.metric_label, a.column_label
);


(
 HEXTORAW('68F28C1E2E16F91EA61B1FD353F25E65') -- IPCS Shared Memory Status, Group
,HEXTORAW('8ED2B151F38F37B0E04F0DEE796DD7CD') -- IPCS Shared Memory Status, Owner
,HEXTORAW('235CAC35019433182658A3DF3E3E5D8D') -- IPCS Shared Memory Status, Segment Size in MB
)
