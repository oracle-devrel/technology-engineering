#!/bin/bash
export EXTRACTS_VERSION="25.11.5"
#---------------------------------------------------------------------------------------------------
# Remove the need for the customer to modifiy the scripts, and ensure that only SQL*Plus 12.2 or
# higher is used to run the SQL scripts, check for errors
#---------------------------------------------------------------------------------------------------
#
# Usage  : Get_EMCC_Sizing_Interactive.sh [ConnectData] [SQLPlusPath]
# Example: Get_EMCC_Sizing_Interactive.sh UserName/Password@ConnectString $ORACLE_HOME
#
# Version History
# 2022-08-09  2.15  pro  Add Get_EMCC_Sizing_EM_Release.sql script
# 2022-08-08  2.14  pro  Get EMMajor and EMMinor and branch DB_DR.sql per EM version
# 2022-03-22  2.13  pro  Make unset command compatible with older shells
# 2022-03-13  2.12  pro  Add ShowBanner function
# 2022-03-07  2.11  pro  Add error handling on CheckEMRelease
# 2022-02-14  2.10  pro  Fix CheckRelease when Major or Minor come null
# 2022-10-07  2.9   pro  Add new function to capture EM Repository version
# 2022-05-05  2.8   mgr  Add new script to capture list of EM jobs
# 2022-03-24  2.7   mgr  Add new script to capture list of EM metrics
# 2022-01-28  2.6   mgr  Fixed Solaris awk, adding timing & debug
# 2021-05-04  2.5   mgr  Removed Diagnostics Pack Requirement per MOS Note: 2771065.1
# 2021-04-12  2.4   mgr  Added new SQL script
# 2021-03-16  2.3   mgr  Script Name Change
# 2021-03-15  2.2   mgr  Add Diagnostics Pack Disclaimer & Prompt
# 2021-03-02  2.1   mgr  Sync up logic and flow to Powershell Script
# 2021-02-04  2.0   mgr  Re-write, consolidated to single script with additional error checking
# 2021-02-04  1.0   mgr  First version
#---------------------------------------------------------------------------------------------------

# Required data can be provided on the command line, username/password@connectstring & SQL*Plus
# 12.2 or higher Home
if (( ${#} > 1 ))
then
	Connect=${1}
	SQLPath=${2}
elif (( ${#} == 1 ))
then
	Connect=${1}
fi

# Determine the some commands based on the Platform
OSName=$(uname -s 2>/dev/null)
case ${OSName} in
	"SunOS")
		AWK="/usr/bin/nawk" ;;
	*)
		AWK="awk" ;;
esac
StartSec=${SECONDS}

# Print Diagnostics Pack Disclaimier
printf "\nThis script queries views licensed by the Oracle Diagnostics Pack;\n"
printf "however, the license is not required per MOS Note: 2771065.1\n\n"

# Set some Defaults
ExtractSQL=.
export EXTRACT_SQL=${ExtractSQL}
export NLS_LANG=AMERICAN_AMERICA

OutputDir="./emcc_sizing_extracts"

SQLScripts="Get_EMCC_Sizing_EM_Release.sql \
	Get_EMCC_Sizing_DB_DR.sql \
	Get_EMCC_Sizing_DB_Params.sql \
	Get_EMCC_Sizing_DB_Props.sql \
	Get_EMCC_Sizing_DB_Services.sql \
	Get_EMCC_Sizing_DB_SGA.sql \
	Get_EMCC_Sizing_Host_Props.sql \
	Get_EMCC_Sizing_PDB_Params.sql \
	Get_EMCC_Sizing_PDB_Props.sql \
	Get_EMCC_Sizing_DB_Redo.sql \
	Get_EMCC_Sizing_PDB_SGA.sql \
	Get_EMCC_Sizing_Structure_DB.sql \
	Get_EMCC_Sizing_Structure_DB_VM.sql \
	Get_EMCC_Sizing_Structure_Host_CPU.sql \
	Get_EMCC_Sizing_Structure_Host_VM.sql \
	Get_EMCC_Sizing_Structure_PDB.sql \
	Get_EMCC_Sizing_Structure_VM.sql \
	Get_EMCC_Sizing_Availability_History.sql \
	Get_EMCC_Sizing_EM_Jobs.sql \
	Get_EMCC_Sizing_EM_Metrics.sql \
	Get_EMCC_Sizing_Metrics_DB_daily_03_months.sql \
	Get_EMCC_Sizing_Metrics_DB_daily_06_months.sql \
	Get_EMCC_Sizing_Metrics_DB_daily_09_months.sql \
	Get_EMCC_Sizing_Metrics_DB_daily_12_months.sql \
	Get_EMCC_Sizing_Metrics_Host_daily_03_months.sql \
	Get_EMCC_Sizing_Metrics_Host_daily_06_months.sql \
	Get_EMCC_Sizing_Metrics_Host_daily_09_months.sql \
	Get_EMCC_Sizing_Metrics_Host_daily_12_months.sql \
	Get_EMCC_Sizing_Metrics_PDB_daily_03_months.sql \
	Get_EMCC_Sizing_Metrics_PDB_daily_06_months.sql \
	Get_EMCC_Sizing_Metrics_PDB_daily_09_months.sql \
	Get_EMCC_Sizing_Metrics_PDB_daily_12_months.sql \
	Get_EMCC_Sizing_Metrics_Host_hourly_03_months.sql \
	Get_EMCC_Sizing_Metrics_DB_hourly_03_months.sql \
	Get_EMCC_Sizing_Metrics_PDB_hourly_03_months.sql"

#---------------------------------------------------------------------------------------------------
# This script should live in the "extras" directory but should not be run from there.
# If started from "extras" directory, automatically change to the parent directory.
#---------------------------------------------------------------------------------------------------
CurDir=$(pwd)
if [[ ${CurDir} = */extras ]]
then
	cd ..
	NewDir=$(pwd)
	printf "INFO: Changing Directory to: ${NewDir}\n"
fi

#---------------------------------------------------------------------------------------------------
# Function   : CheckRelease
# Description: Set environment and check the version of the SQL*Plus command to make sure it meets
#              the requirements
#---------------------------------------------------------------------------------------------------
function CheckRelease {

	Command=${1}
	if [[ ${Command} = */bin/sqlplus ]]
	then
		# Looks like a Full ORACLE_HOME so treat it as such
		export ORACLE_HOME=$(dirname $(dirname ${Command}) )
		export LD_LIBRARY_PATH=${ORACLE_HOME}/lib
	else
		# Appears to be an Instant Client so treat it as such
		unset ORACLE_HOME
		export LD_LIBRARY_PATH=$(dirname ${Command})
	fi
	Release=$(${Command} -V 2>/dev/null | egrep "SQL\*Plus: Release " | ${AWK} '{print $3}')
	Major=$(echo ${Release} | ${AWK} -F '.' '{print $1}')
	Minor=$(echo ${Release} | ${AWK} -F '.' '{print $2}')
	if [[ -n ${Major} && -n ${Minor} ]]
	then
    if [[ ${Major} == +([0-9]) ]] && (( ${Major} > 12 )) || (( ${Major} == 12 && ${Minor} > 1 ))
    then
      # Version is good
      rc=0
    elif [[ ${Major} == +([0-9]) ]] && (( ${Major} < 12 )) || (( ${Major} == 12 && ${Minor} < 2 ))
    then
      # Version too low
      rc=1
    else
      # Version Check Failed
      rc=2
    fi
  else
    # Version Check Failed
    rc=2
  fi

	return ${rc}

} # End of CheckRelease

#---------------------------------------------------------------------------------------------------
# Function   : CheckConnect
# Description: Make sure we can get connected to the Database before blasting the scripts at it.
#---------------------------------------------------------------------------------------------------
function CheckConnect {

	if [[ ${SQLPlus} = */bin/sqlplus ]]
	then
		# Looks like a Full ORACLE_HOME so treat it as such
		export ORACLE_HOME=$(dirname $(dirname ${SQLPlus}) )
		export LD_LIBRARY_PATH=${ORACLE_HOME}/lib
	else
		# Appears to be an Instant Client so treat it as such
		unset ORACLE_HOME
		export LD_LIBRARY_PATH=$(dirname ${SQLPlus})
	fi

	${SQLPlus} /NOLOG <<-EOF
		set echo off tab off trim on trimspool on feedback off verify off heading off timing off;
		connect ${Connect};
		exit;
	EOF

	return

} # End of CheckConnect

#---------------------------------------------------------------------------------------------------
# Function   : CheckEMRelease
# Description: Check the version of the Enterpise Manager Repository
#---------------------------------------------------------------------------------------------------
function CheckEMRelease {

 if [[ ${SQLPlus} = */bin/sqlplus ]]
 then
  # Looks like a Full ORACLE_HOME so treat it as such
  export ORACLE_HOME=$(dirname $(dirname ${SQLPlus}) )
  export LD_LIBRARY_PATH=${ORACLE_HOME}/lib
 else
  # Appears to be an Instant Client so treat it as such
  unset ORACLE_HOME
  export LD_LIBRARY_PATH=$(dirname ${SQLPlus})
 fi


  EMRelease=$(
	${SQLPlus} -S /NOLOG <<-EOF
		connect ${Connect};
		set echo off tab off trim on trimspool on feedback off verify off heading off timing off;
		select version from sysman.mgmt_versions where component_name = 'CORE';
		exit;
	EOF
  )


  if [[ -n ${EMRelease} ]]
  then
    # Check that we haven't received ORA- error
    if [[ ${EMRelease} =~ ORA-([0-9]+):.* ]]
    then
      printf "ERROR: EM Release not found: ${BASH_REMATCH[0]}\n" >&2
      printf "Please check the User Account , must have the MGMT_USER role," >&2
      printf " SELECT ANY TABLE privilege or be the \"SYSMAN\" account." >&2
      exit 1
    fi

    # Trim spaces on the value
    EMRelease="${EMRelease#"${EMRelease%%[![:space:]]*}"}"

    # Check that we received a number
    if [[ ${EMRelease} =~ ^([0-9]+\.?)+$ ]]
    then
      export EMRelease
    else
      printf "ERROR: EM Release not found: EM Release not a number\n" >&2
      printf "Please check the User Account , must have the MGMT_USER role," >&2
      printf " SELECT ANY TABLE privilege or be the \"SYSMAN\" account." >&2
      exit 1
    fi
  else
    printf "ERROR: EM Release not found: EM Release is empty\n" >&2
    printf "Please check the User Account , must have the MGMT_USER role," >&2
    printf " SELECT ANY TABLE privilege or be the \"SYSMAN\" account." >&2
    exit 1
  fi

} # End of CheckEMRelease

#---------------------------------------------------------------------------------------------------
# Function   : ShowBanner
# Description: Prints the tool banner to stdout
#---------------------------------------------------------------------------------------------------
function ShowBanner {
  printf "+--------------------------------------------------------------------+\n"
  printf "|  ###   ###  ###   ####                                             |\n"
  printf "| #   # #    #     #   #     _         _                             |\n"
  printf "| #   # #    #    ######    |_  |\/|  |_)   |\/|  o   _    _   ,_    |\n"
  printf "|  ###  ###  ### ##   ##    |_  |  |  | |   |  |  |  | |  (/_  |     |\n"
  printf "+--------------------------------------------------------------------+\n"
  printf "\n"
  printf "EMR-Miner Version ${EXTRACTS_VERSION}\n"
  printf "Collects metrics and statistics from Enterprise Manager Repository (EMR).\n"
  printf "\n"
} # End of ShowBanner

#---------------------------------------------------------------------------------------------------
# Enterprise Manager Repository Miner (EMR Miner) execution
#---------------------------------------------------------------------------------------------------
ShowBanner
#---------------------------------------------------------------------------------------------------
# Find a version of SQL*Plus that will work, using the precedense as follows
#---------------------------------------------------------------------------------------------------
# 1) Provided on Command Line, fail if not ok
# 2) Command found in PATH, skip to next if not ok
# 3) Command found in ORATAB, skip to next if not ok
# 4) Prompt User for Path, fail if not ok
#---------------------------------------------------------------------------------------------------
unset SQLPlus

# Get the Path from the Command Line
if [[ -n ${SQLPath} ]]
then
	if [[ ${SQLPath} = *sqlplus && -f ${SQLPath} && -x ${SQLPath} ]]
	then
		SQLCmd=${SQLPath}
	elif [[ -f ${SQLPath}/sqlplus && -x ${SQLPath}/sqlplus ]]
	then
		SQLCmd=${SQLPath}/sqlplus
	elif [[ -f ${SQLPath}/bin/sqlplus && -x ${SQLPath}/bin/sqlplus ]]
	then
		SQLCmd=${SQLPath}/bin/sqlplus
	fi
	if [[ -z ${SQLCmd} ]]
	then
		printf "ERROR: SQL*Plus Command Not Found in Path: \"${SQLPath}\"\n" >&2
		printf "Please try again with a different path containing a valid SQL*Plus\n" >&2
		exit 1
	else
		CheckRelease ${SQLCmd}
		rc=${?}
		if (( ${rc} == 0 ))
		then
			printf "SUCCESS: SQL*Plus Command Found and Version is good: \"${SQLCmd}\"\n" >&2
			SQLPlus=${SQLCmd}
		elif (( ${rc} == 1 ))
		then
			printf "ERROR: SQL*Plus Command Found, but the version is too low, must be 12.2 or higher: \"${SQLCmd}\"\n" >&2
			printf "Please try again with a different path containing a valid SQL*Plus\n" >&2
			exit 1
		else
			printf "ERROR: SQL*Plus Command Found, but the version check failed: \"${SQLCmd}\"\n" >&2
			printf "Please try again with a different path containing a valid SQL*Plus\n" >&2
			exit 1
		fi
	fi
fi

# If we don't have it yet, Check Environment for Path to the command
if [[ -z ${SQLPlus} ]]
then
	# Still looking
	SQLCmd=$(which sqlplus 2>/dev/null)
	if [[ -n ${SQLCmd} ]]
	then
		CheckRelease ${SQLCmd}
		rc=${?}
		if (( ${rc} == 0 ))
		then
			printf "SUCCESS: SQL*Plus Command Found and Version is good: \"${SQLCmd}\"\n" >&2
			SQLPlus=${SQLCmd}
		fi
	fi
fi

# If we still don't have it, Search Homes in the ORATAB file
if [[ -z ${SQLPlus} ]]
then
	if [[ -r /etc/oratab ]]
	then
		HomeList=$(egrep -i "^\+|^[a-z]|^[0-9]" /etc/oratab | ${AWK} -F ':' '{print $2}' | sort -u)
	elif [[ -r /var/opt/oratab ]]
	then
		HomeList=$(egrep -i "^\+|^[a-z]|^[0-9]" /var/opt/oratab | ${AWK} -F ':' '{print $2}' | sort -u)
	fi
	for Home in ${HomeList}
	do
		if [[ -z ${SQLPlus} && -f ${Home}/bin/sqlplus && -x ${Home}/bin/sqlplus ]]
		then
			CheckRelease ${Home}/bin/sqlplus
			rc=${?}
			if (( ${rc} == 0 ))
			then
				printf "SUCCESS: SQL*Plus Command Found and Version is good: \"${Home}/bin/sqlplus\"\n" >&2
				SQLPlus=${Home}/bin/sqlplus
			fi
		fi
	done
fi

# Last resort is to Prompt the user for the Path
if [[ -z ${SQLPlus} ]]
then
	printf "\nSQL*Plus version 12.2 or higer is required!\n"
	printf "Enter Path to SQL*Plus Command: "
	read Value
	if [[ ${Value} = */sqlplus && -f ${Value} && -x ${Value} ]]
	then
		SQLCmd=${Value}
	elif [[ -f ${Value}/sqlplus && -x ${Value}/sqlplus ]]
	then
		SQLCmd=${Value}/sqlplus
	elif [[ -f ${Value}/bin/sqlplus && -x ${Value}/bin/sqlplus ]]
	then
		SQLCmd=${Value}/bin/sqlplus
	else
		printf "ERROR: SQL*Plus Not Found in: \"${Value}\"\n" >&2
		printf "Please check values and try again!\n" >&2
		exit 1
	fi

	CheckRelease ${SQLCmd}
	rc=${?}
	if (( ${rc} == 0 ))
	then
		printf "SUCCESS: SQL*Plus Command Found and Version is good: \"${SQLCmd}\"\n" >&2
		SQLPlus=${SQLCmd}
	elif (( ${rc} == 1 ))
	then
		printf "ERROR: SQL*Plus Command Found, but the version is too low, must be 12.2 or higher: \"${SQLCmd}\"\n" >&2
		printf "Please try again with a different path containing a valid SQL*Plus\n" >&2
		exit 1
	else
		printf "ERROR: SQL*Plus Command Found, but the version check failed: \"${SQLCmd}\"\n" >&2
		printf "Please try again with a different path containing a valid SQL*Plus\n" >&2
		exit 1
	fi
fi

#---------------------------------------------------------------------------------------------------
# If connection data was not provided on the command line, prompt for it here
#---------------------------------------------------------------------------------------------------
if [[ -z ${Connect} ]]
then
	printf "\nEnter Enterprise Manager Repository Database Connection Data\n"
	printf "The following are examples for the syntaxes you may use\n"
	printf "   EZCONNECT: username/password@hostname:port/service_name\n"
	printf "   TNSNAMES : username/password@tnsnames_alias\n\n"
	printf "   Note: The User must have the MGMT_USER role, SELECT ANY TABLE privilege or have SYSMAN privileges\n"
	printf "\nEnter Connection Data: "
	read Connect
	if [[ -z ${Connect} ]]
	then
		printf "ERROR: Nothing Found in: \"${Connect}\"\n" >&2
		printf "Please check values and try again!\n" >&2
		exit 1
	fi
fi

# Verify that the SQL*Plus command and Connection data works
Result=$(CheckConnect ${SQLPlus} ${Connect} 2>&1 | grep "Connected\.")
if [[ -n ${Result} ]]
then
	printf "SUCCESS: Test Connection to Database Succeeded!\n" >&2
else
	printf "ERROR: Connection Test Failed, please review SQL*Plus Command and Connection Data and try again!\n" >&2
	printf "   SQL*Plus Command: ${SQLPlus}\n" >&2
	printf "   Connection Data : ${Connect}\n" >&2
	exit 1
fi

# Create the Output Directory if it doesn't exist
if [[ ! -d ${OutputDir} ]]
then
	mkdir -p ${OutputDir}
	if [[ ! -d ${OutputDir} ]]
	then
		printf "ERROR: Failed to Create Output Directory: \"${OutputDir}\"\n"
	else
		printf "SUCCESS: Output Directory Created: \"${OutputDir}\"\n"
	fi
fi

# Get EMRelease version
unset EMRelease EMMajor EMMinor
CheckEMRelease ${SQLPlus} ${Connect}
if [[ -n ${EMRelease} ]]
then

   # Extract EMMajor from EMRelease
   EMMajor=$(echo ${EMRelease} | ${AWK} -F '.' '{print $1}')

   # Check is not empty
   if [[ -z ${EMMajor} ]]
   then
      printf "ERROR: EMMajor is empty\n" >&2
      exit 1
   fi

   # Check is a number
   if ! [[ ${EMMajor} =~ ^[0-9]+$ ]]
   then
      printf "ERROR: EMMajor is not a number\n" >&2
      exit 1
   fi

   # Extract EMMinor from EMRelease
   EMMinor=$(echo ${EMRelease} | ${AWK} -F '.' '{print $2}')

   # Check is not empty
   if [[ -z ${EMMinor} ]]
   then
      printf "ERROR: EMMinor is empty\n" >&2
      exit 1
   fi

   # Check is a number
   if ! [[ ${EMMinor} =~ ^[0-9]+$ ]]
   then
      printf "ERROR: EMMinor is not a number\n" >&2
      exit 1
   fi
fi

# Run each SQL script against the EM Repository Database
printf "\nStarting Extract Scripts!\n\n"
wrapper_to_alter_session() {
    local Script=$1
    local Connect=$2
    local ExtractSQL=$3

    # Rule for Get_EMCC_Sizing_Structure_DB.sql on EM12 versions
    if [[ ${Script} == 'Get_EMCC_Sizing_Structure_DB.sql' ]]; then
        if [[ ${EMMajor} -lt 13 ]]; then
            Script="Get_EMCC_Sizing_Structure_DB_EM12.sql"
        fi
    # Rule for Get_EMCC_Sizing_DB_DR.sql on EM13.5 versions and higher
    elif [[ ${Script} == 'Get_EMCC_Sizing_DB_DR.sql' ]]; then
        if [[ ${EMMajor} -eq 13 && ${EMMinor} -ge 5 ]]; then
            Script="Get_EMCC_Sizing_DB_DR_EM13_5.sql"
        fi
    fi

#    ALTER SESSION SET nls_language = 'AMERICAN (EN)';
#    ALTER SESSION SET nls_territory = 'AMERICA (USA)';
#    ALTER SESSION SET nls_calendar = 'GREGORIAN - DEFAULT';
#    ALTER SESSION SET nls_date_language = 'ENGLISH (AMERICAN)';
#    ALTER SESSION SET nls_numeric_characters = '@!';
#    ALTER SESSION SET nls_date_format = 'YYYY/MM/DD';
#    ALTER SESSION SET nls_timestamp_format = 'YYYY/MM/DD';
#    ALTER SESSION SET nls_length_semantics = BYTE;


    ${SQLPlus} -s "${Connect}"  <<EOF
    set feedback off;


    alter session set nls_language = American;
    alter session set nls_territory = America;
    alter session set nls_calendar = Gregorian;
    alter session set nls_date_language = American;
    alter session set nls_date_format = 'YYYY-MM-DD HH24:MI:SS';
    alter session set nls_timestamp_format = 'YYYY-MM-DD HH24:MI:SS';
    alter session set nls_numeric_characters = ".,";
    alter session set nls_length_semantics = BYTE;

    @${ExtractSQL}/${Script}
    EXIT;
EOF
}

I=0
for Script in ${SQLScripts}
do
	(( I = I + 1 ))
  if [[ -n ${DEBUG} ]]
    then
      echo ${SQLPlus} -s "${Connect}" @${ExtractSQL}/${Script}
    fi
  if [[ ${DEBUG} != "check" ]]
	  then
      wrapper_to_alter_session "${Script}" "${Connect}" "${ExtractSQL}" 2>&1 | egrep -vi "(mkdir).*(file exists|cannot create|do not specify an existing)"
	fi
done

# Check for Oracle Errors in the output files
ErrCnt=0
printf "\nChecking Output Files for Errors!\n" >&2
for CSVFile in ${OutputDir}/*.csv
do
	Result=$(grep "^ORA-[0-9]" ${CSVFile} 2>/dev/null)
	if [[ -n ${Result} ]]
	then
		(( ErrCnt = ErrCnt + 1 ))
		printf "\nErrors in File: ${CSVFile}\n" >&2
		printf "${Result}\n" >&2
	fi
done

EndSec=${SECONDS}
(( RunMin = ( EndSec - StartSec ) / 60 ))
printf "\nRun Time = ${RunMin} minutes\n"

# Remind the user of the Next Steps
if (( ${ErrCnt} == 0 ))
then
	printf "\nSUCCCESS: No Errors were found in the output files!\n"
	printf "\nNext Step: bundle up the output directory, for example:\n"
	printf "   zip -r emcc_sizing_extracts_oem1.zip emcc_sizing_extracts\n"
	printf "\nFinal Step: please upload the bundle to location provided by your Oracle contact\n"
else
	printf "\nERROR: Above error(s) where reported, if correctable, please correct and re-run,\n" >&2
		printf "       otherwise contact your Oracle contact for assistance!\n" >&2
	exit 1
fi
