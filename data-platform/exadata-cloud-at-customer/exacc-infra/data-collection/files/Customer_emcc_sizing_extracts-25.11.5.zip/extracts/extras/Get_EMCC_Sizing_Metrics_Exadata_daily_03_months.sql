rem
rem Version 1.1
define __version__ = 1.1
rem

rem Version History
rem
rem 2021-03-01    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting Exadata daily metrics 0 to 03 months...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_metrics_exadata_daily_03_months.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_metrics_exadata_daily_03_months.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","METRIC_LABEL","COLUMN_LABEL","METRIC_NAME","METRIC_COLUMN","KEY_VALUE","ROLLUP_TIMESTAMP_UTC","MINIMUM","MAXIMUM","AVERAGE","STANDARD_DEVIATION","SAMPLE_COUNT"

WITH t AS
(
 SELECT /*+ MATERIALIZE */
        target_guid, timezone_region
 FROM   sysman.mgmt$target
 WHERE  target_type IN ('oracle_exadata')
/*
 AND    target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type     = 'oracle_exadata'
 AND    aggregate_target_name IN
(
 'DB Machine m1.us.oracle.com'
,'DB Machine m2.us.oracle.com'
)
)
*/
)
SELECT RAWTOHEX(a.target_guid) AS target_guid
      ,a.target_name
      ,a.target_type
      ,a.metric_label
      ,a.column_label
      ,a.metric_name
      ,a.metric_column
      ,NVL(a.key_value, a.target_name) AS key_value
      ,TO_CHAR(CAST(FROM_TZ(CAST(a.rollup_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS rollup_timestamp_utc
      ,NVL(a.minimum,            0)              AS minimum
      ,NVL(a.maximum,            0)              AS maximum
      ,NVL(a.average,            0)              AS average
      ,NVL(a.standard_deviation, 0)              AS standard_deviation
      ,NVL(a.sample_count,       0)              AS sample_count
FROM   t, sysman.mgmt$metric_daily a
WHERE  a.rollup_timestamp >= ADD_MONTHS(SYSDATE, -3)
AND    a.target_guid       = t.target_guid
AND    a.metric_guid      IN
(
 HEXTORAW('DDA2C1A96C1287F157E5EF69DEBEBEFD') -- CellDisk_Metric, cd_lg_r_reqs                                  ---> Exadata CellDisk Metric, Large Read Requests
,HEXTORAW('360397194F12C5A7571C358523E64D43') -- CellDisk_Metric, cd_lg_w_reqs                                  ---> Exadata CellDisk Metric, Large Write Requests
,HEXTORAW('ED2519294BB398AFB5F94D1E1FF3915B') -- CellDisk_Metric, cd_sm_r_latency                               ---> Exadata CellDisk Metric, Average Small Read Response Time
,HEXTORAW('61B7F58192C92B0ADB3E9BD059DC730E') -- CellDisk_Metric, cd_sm_r_reqs                                  ---> Exadata CellDisk Metric, Small Read Requests
,HEXTORAW('5B41E40EE6950C1CAFB3BC1F0E82B16A') -- CellDisk_Metric, cd_sm_w_reqs                                  ---> Exadata CellDisk Metric, Small Write Requests
,HEXTORAW('E577644CB99554603A192471AA9F8B0A') -- Flash_Cache_IORM_DB_Metric, db_fc_by_allocated                 ---> Exadata Flash Cache IORM Database Metric, Size (MB)
,HEXTORAW('E41B49901B91D9B1614A63CDA65DFF96') -- Flash_Disk_IORM_DB_Metric, db_fd_io_by_sec                     ---> Exadata Flash IORM Database Metric, Average I/O Throughput (MB/Sec)
,HEXTORAW('44FAAB665F5788A6B4E80F7433D2E97A') -- Flash_Disk_IORM_DB_Metric, db_fd_io_rq_lg_sec                  ---> Exadata Flash IORM Database Metric, I/O Requests per Second - Large (IO/Sec)
,HEXTORAW('38770FF1E29D9EC3DA81B3FCBF9F4DDC') -- Flash_Disk_IORM_DB_Metric, db_fd_io_rq_sm_sec                  ---> Exadata Flash IORM Database Metric, I/O Requests per Second - Small (IO/Sec)
,HEXTORAW('586343190BAA2EBE96A183344A340B2A') -- Flash_Disk_IORM_DB_Metric, db_fd_io_util                       ---> Exadata Flash IORM Database Metric, I/O Utilization (%)
,HEXTORAW('29298378D25232274F27A4C03F42F876') -- IORMDB_Metric, db_fd_io_tm_rq                                  ---> Exadata IORM DB Metric, Average latency of reading or writing blocks/request from flash
,HEXTORAW('1404E5A2860C85433BBE13898FA114D5') -- IORMDB_Metric, db_io_by_sec                                    ---> Exadata IORM DB Metric, Average I/O Throughput (MB/Sec)
,HEXTORAW('6EF84C830D9E5B0E42FB7E964A9FBEFB') -- IORMDB_Metric, db_io_tm_lg_rq                                  ---> Exadata IORM DB Metric, Average latency of reading or writing large blocks/request from
,HEXTORAW('0A23BDDF3D53A89C159BC6AC5940CD84') -- IORMDB_Metric, db_io_tm_rq                                     ---> Exadata IORM DB Metric, Average latency of reading or writing blocks/request from hard d
,HEXTORAW('0AEDB501B594393330DA38E3732C5AE2') -- IORMDB_Metric, db_io_tm_sm_rq                                  ---> Exadata IORM DB Metric, Average latency of reading or writing small blocks/request from
,HEXTORAW('CD166A2CC1ACF657C79F24DE073B4925') -- IORMDB_Metric, db_io_util_lg                                   ---> Exadata IORM DB Metric, Large I/O Utilization (%)
,HEXTORAW('7DD206C6CB28D5D5FA1FA05048B0D8DC') -- IORMDB_Metric, db_io_util_sm                                   ---> Exadata IORM DB Metric, Small I/O Utilization (%)
,HEXTORAW('0086469239011ECFD4D464BF35C8D606') -- IORMDB_Metric, num_lg_rq                                       ---> Exadata IORM DB Metric, I/O Requests per Second - Large (IO/Sec)
,HEXTORAW('7CC9DD7DD6F4F67E1A8847EA70A315D0') -- IORMDB_Metric, num_sm_rq                                       ---> Exadata IORM DB Metric, I/O Requests per Second - Small (IO/Sec)
);

spool off

spool emcc_sizing_extracts/emcc_sizing_metrics_exadata_daily_03_months.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
