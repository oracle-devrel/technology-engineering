#!/bin/sh

#
# Version 1.3
#
# Version History
#
# 2021-03-24    1.3   tmf     Added redo
# 2020-11-19    1.2   tmf     Added NLS_LANG
# 2020-10-11    1.1   tmf     First version
#

#
# Change the following line to point to SQL*Plus -- version 12.2 or greater is preferred
#

SQLPLUS_EXE=/scratch/ctdinkel/opt/oracle/instantclient_18_3/sqlplus
EXTRACT_SQL=.
export NLS_LANG=AMERICAN_AMERICA

#
# Change the following line to point to include username, password @ connect string for EMCC Repository
#

unpwcs=sysman/"password"@'(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = omrhost)(PORT = 1521)))(LOAD_BALANCE = ON)(CONNECT_DATA = (SERVICE_NAME = omrservice)))'

#
# the following line is for debugging only
#. ./env.sh
#

# ----------------------------------------------------------------------------------------------------------------------

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Availability_History.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_DR.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_Params.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_Props.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_Redo.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_Services.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_DB_SGA.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Host_Props.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_PDB_Params.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_PDB_Props.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_PDB_SGA.sql

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_DB.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_DB_VM.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_Host_CPU.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_Host_VM.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_PDB.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Structure_VM.sql
