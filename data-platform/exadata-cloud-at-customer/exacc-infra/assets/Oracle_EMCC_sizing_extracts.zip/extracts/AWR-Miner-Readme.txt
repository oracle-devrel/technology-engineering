OCCA AWR Miner Readme 
================================================================================

What is AWR Miner? 
--------------------------------------------------------------------------------
The Enterprise Edition of the Oracle Database includes the Automatic Workload 
Repository (AWR) and several AWR report scripts in the ORACLE_HOME.  The AWR 
Miner script is not included in the ORACLE_HOME, instead it is a utility 
provided by Oracle personnel to assist in sizing and tuning exercises.

This script queries the same AWR repository as the AWR reports provided with 
the database however it is designed to look at the key database metrics over a 
longer period of time.  By default, AWR repository data is maintained for about 
8 days, but can be configured to keep 30 or more days.  The script will collect 
up to the last 30 days by default.  

When the output of this script is processed it will provide graphs with higher 
level aggregate data over a longer period of time, than the regular AWR reports.

Diagnostic Pack License Exception 
--------------------------------------------------------------------------------
This script queries DBA_HIST_ views in the AWR Repository, which is allowed 
without Diagnostics Pack licenses according to the exception published here: 
   OEM Metrics License Exception for Analysis by Oracle Pre-Sales or Consulting 
   (Doc ID 2771065.1) 

Using AWR Miner with Oracle Multitenant 
--------------------------------------------------------------------------------
For Multitenant databases this script must be executed from the CDB root 
(CDB$ROOT). Currently, the PDB databases do not contain the metrics required to 
provide useful results. 

How to Run the Script 
--------------------------------------------------------------------------------
1. Run this as sys or system (or a DBA account), preferably on the production 
   system(s). If the desired goal is sizing a production system, output from a 
   development system is of little benefit. 

2. If this is a RAC cluster you only need to run this from 1 node as the 
   DBA_HIST_ views contain data from all nodes. 

3. The login.sql file found via the SQLPATH environment variable have caused 
   problems in the past. To avoid these, you can optionally unset the SQLPATH 
   shell environment variable before logging in to sqlplus: 

      [bash] unset SQLPATH 
      [windows] set SQLPATH= 

4. Run from SQL*Plus command-line and with a DBA privileged Oracle user account. 

   Note: This script will not run correctly from other tools such as TOAD or 
         SQL Developer 

   Local Execution without a password
      sqlplus / as sysdba @awr_miner.sql

   Remote Execution with Oracle Net (SQL*Net)
      sqlplus USER/PASS@HOST.ACME.COM/ORAC.ACME.COM @awr_miner.sql

5. Wait for the script to finish. It could take longer over slower network 
   connections. When completed you will see something like the following at the 
   end:

      Extracting Row counts...
      Completed Extract Script!
      Collection File : awr-hist-11104121627-ORAC-532-743.out
      -------------------------------------------------------------------
      Disconnected from Oracle Database 21c Enterprise Edition Release 
      21.0.0.0.0 - Production
      Version 21.3.0.0.0 

6. There is no need to spool or capture the screen output, all output will be 
   automatically spooled to a file in the current working directory with a name 
   like: awr-hist*.out. Do not change the file name as the code to parse this 
   file is looking for file names with a specific pattern. 

7. Optionally compress the awr-hist*.out file or files using gzip or zip and 
   upload it or email to your Oracle contact. 

   The generated file will be anywhere from 1-30 MiB and is highly compressible. 
   Compressed output should be under 300 KB - 2 MiB. Variables that will 
   increase    the file size are longer AWR retention periods (but more 
   information is    better), shorter snapshot intervals (again, more 
   information is often better), and large numbers of RAC nodes. 

Will This Impact My System? 
--------------------------------------------------------------------------------
It should have little to no impact on your system. It generally takes less than 
a minute to run on anything from a laptop to an Exadata Full Rack and incurs 
less load than generating 1 AWR report. All queries are serial so at most this 
will occupy 1 CPU core for under a minute. Absolutely no objects are created or 
removed in the Database. 

Can I View the Output? 
--------------------------------------------------------------------------------
Absolutely. This script produces a plain text file composed of rows and columns. 
Ultimately this file is parsed and plotted with a Python script by someone at 
Oracle, and the results are shared back to you in the form of an HTML file.

Can I Automate the Execution? 
--------------------------------------------------------------------------------
Absolutely. Using the OCCA AWR Miner version 24.2 and higher automation is much 
simpler. The script will no longer prompt for any information so calling the SQL 
script from a shell script becomes straight forward.

The following example is included. It will execute the SQL script for all DBs 
running on current Host as the current User (ORACLE OWNER)

$ cat ./db-miner-example.sh 
#-------------------------------------------------------------------------------
# Example Script
#
# Wrapper for running the awr_miner.sql script.
# It looks for Oracle DBs running under the current user account, then searches
# for the ORACLE_HOME in /proc or /etc/oratab and, if found, executes the
# awr_miner.sql SQL script using the SQL*Plus command.
#
# Tested on Linux and written to be compatible with BASH, KSH93 and ZSH
#
#-------------------------------------------------------------------------------
# DISCLAIMER:
# 
# Although this program has been tested and used successfully, it is not
# supported by Oracle Support Services.
#
# It has been tested internally, and works as documented, however, we do not
# guarantee that it will work for you, so be sure to test it in your test
# environment before relying on it.  
#
# We do not claim any responsibility for any problems and/or damage caused by
# this program. This program comes "as is", please use it at your own risk.
#
# Due to the differences in the way text editors, e-mail programs and operating
# systems handle text formatting (spaces, tabs and carriage returns), proofread
# this script before execution.
#-------------------------------------------------------------------------------
DefaultPath=/usr/bin:/bin:/usr/local/bin
export PATH=${DefaultPath}

if [[ -n ${ZSH_VERSION} ]]
then
	emulate -L ksh
fi

# Time stamp for output directory
ExecTime=$(date +'%Y%m%d-%H%M%S')

#-------------------------------------------------------------------------------
# Use the ps command to get the list of Running DBs for this User
#-------------------------------------------------------------------------------
I=0
while read Line
do
	set -- ${Line}
	(( I = I + 1 ))
	Cmd=${3}
	SidName[${I}]=${Cmd#ora_pmon_*}
	Pid=${2}
	if [[ -f /proc/${Pid}/environ ]]
	then
		SidHome[${I}]=$(cat /proc/${Pid}/environ 2>/dev/null | tr '\0' '\n' \
			| grep "^ORACLE_HOME=" | sed -e 's/ORACLE_HOME=//')
	elif [[ -f /etc/oratab ]]
	then
		Result=$(grep "^${SidName[${I}]}:" /etc/oratab 2>/dev/null)
		if [[ -n ${Result} ]]
		then
			Result=${Result#*:}
			SidHome[${I}]=${Result%%:*}
		fi
	fi
done < <(ps -u $(id -un) -ouser,pid,cmd 2>/dev/null | grep " ora_pmon_" | grep -v grep)

# If no Databases found exit
if (( ${I} == 0 ))
then
	echo "WARNING: No Databases found with ORACLE OWNER = $(id -un)" >&2
	exit
else
	SidCnt=${I}
fi

# Create a unique output directory to hold the .out files
CurDir=$(pwd)
mkdir awr_miner_out_${ExecTime}
cd awr_miner_out_${ExecTime}
OutDir=$(pwd)

#-------------------------------------------------------------------------------
# For each ORACLE_SID see if we found the ORACLE_HOME, if so setup the env and
# Run the SQL Script.
#-------------------------------------------------------------------------------
I=0
while (( ${I} < ${SidCnt} ))
do
	(( I = I + 1 ))

	if [[ -n ${SidHome[${I}]} ]]
	then
		export ORACLE_SID=${SidName[${I}]}
		export ORACLE_HOME=${SidHome[${I}]}
		export PATH=${DefaultPath}:${ORACLE_HOME}/bin
		${ORACLE_HOME}/bin/sqlplus / as sysdba @../awr_miner.sql
	else
		echo;echo;echo
		echo "ERROR: ORACLE_HOME for ORACLE_SID Not Found: \"${SidName[${I}]}\"" >&2
		echo "       Try adding ORACLE_SID to ORATAB file: \"/etc/oratab\"" >&2
		echo;echo;echo
	fi
done

# List out the Output Directory and Files
cd ${CurDir}
echo;echo;echo
echo "Output files located in: ${OutDir}"
ls -ld awr_miner_out_${ExecTime}/*
echo


