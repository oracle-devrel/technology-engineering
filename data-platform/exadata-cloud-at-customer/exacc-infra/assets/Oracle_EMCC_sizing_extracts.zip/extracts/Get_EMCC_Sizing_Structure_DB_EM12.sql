rem
rem Version 1.1
define __version__ = 1.1
rem

rem Version History
rem
rem 2022-03-10    1.1  pro     Based on Get_EMCC_Sizing_Structure_DB.sql version 1.11  , used in EM Repos lower than 13.x

rem ********************************************************************************************************************
rem
rem This script is only for EM 12.x Repos:
rem The column total_cpu_cores does not exists in view sysman.mgmt$os_hw_summary in that version.
rem Ref : https://docs.oracle.com/cd/E24628_01/doc.121/e57277/ch20_OSview.htm#EMVWS12373.
rem The value for this columns is nulled out with a 0 value.
rem
rem ********************************************************************************************************************


rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting DB structure for EM12 Repository...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_db.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_db.csv

prompt "extract_version"-
,"dbmachine","dbmachine_type_version","dbmachine_type","dbmachine_owner","cluster","cluster_owner","cluster_status","cluster_last_load_time_utc"-
,"clustered"-
,"cdb","cdb_type_version","cdb_type","cdb_owner","cdb_standby_type","cdb_status","cdb_last_load_time_utc"-
,"db","db_type_version","db_type","db_owner","db_standby_type","db_status","db_last_load_time_utc"-
,"host","host_type_version","host_status","host_last_load_time_utc"-
,"physical_cpu_count","total_cpu_cores","logical_cpu_count","mem_gb","freq","ma","system_config","vendor_name","dist_version"-
,"dup_cdb_cluster_flag","dup_host_dbmachine_flag"-
,"dbmachine_target_guid","cluster_target_guid","cdb_target_guid","db_target_guid","host_target_guid"-
,"cdb_num","cdb_inst_rn","cdb_instance_count","db_num","host_num","host_inst_rn","host_instance_count","dup_host_cluster_flag"-
,"extract_dttm_utc"

SELECT '&__version__'                                                                                                                      AS extract_version
      ,t.*
      ,RANK()                                                 OVER (                                 ORDER BY t.cdb_target_guid)  AS cdb_num
      ,ROW_NUMBER()                                           OVER (PARTITION BY t.cdb_target_guid   ORDER BY t.db_target_guid)   AS cdb_inst_rn
      ,COUNT(CASE WHEN t.db = 'none' THEN NULL ELSE t.db END) OVER (PARTITION BY t.cdb_target_guid)                               AS cdb_instance_count
      ,RANK()                                                 OVER (                                 ORDER BY t.db_target_guid)   AS db_num
      ,RANK()                                                 OVER (                                 ORDER BY t.host_target_guid) AS host_num
      ,ROW_NUMBER()                                           OVER (PARTITION BY t.host_target_guid  ORDER BY t.db_target_guid)   AS host_inst_rn
      ,COUNT(CASE WHEN t.db = 'none' THEN NULL ELSE t.db END) OVER (PARTITION BY t.host_target_guid)                              AS host_instance_count
      ,CASE
         WHEN COUNT(DISTINCT t.cluster_name)                  OVER (PARTITION BY t.host_target_guid) > 1 THEN 1
       ELSE
         0
       END                                                                                                                        AS dup_host_cluster_flag
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')                                                            AS extract_dttm_utc
FROM
(
WITH rac_db_machines
AS
(
SELECT td.target_name  AS rac
      ,td.target_guid  AS rac_target_guid
      ,tx.target_name  AS dbmachine
      ,tx.owner        AS dbmachine_owner
      ,tx.target_guid  AS dbmachine_target_guid
      ,tx.target_type  AS dbmachine_type
      ,tx.type_version AS dbmachine_type_version
FROM   sysman.mgmt$target              tx
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              td
WHERE  i.assoc_target_name      = tx.target_name (+)
AND    i.assoc_target_type      = tx.target_type (+)
AND    i.assoc_target_type (+) IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
AND    i.association_type  (+)  = 'deployed_on'
AND    td.target_type           = i.source_target_type (+)
AND    td.target_name           = i.source_target_name (+)
AND    td.target_type           = 'rac_database'
)
,db_db_machines
AS
(
SELECT td.target_name  AS db
      ,td.target_guid  AS db_target_guid
      ,tx.target_name  AS dbmachine
      ,tx.owner        AS dbmachine_owner
      ,tx.target_guid  AS dbmachine_target_guid
      ,tx.target_type  AS dbmachine_type
      ,tx.type_version AS dbmachine_type_version
FROM   sysman.mgmt$target              tx
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              td
WHERE  i.assoc_target_name      = tx.target_name (+)
AND    i.assoc_target_type      = tx.target_type (+)
AND    i.assoc_target_type (+) IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
AND    i.association_type  (+)  = 'deployed_on'
AND    td.target_type           = i.source_target_type (+)
AND    td.target_name           = i.source_target_name (+)
AND    td.target_type           = 'oracle_database'
)
,cluster_rac_dbs AS
(
SELECT tc.target_guid              AS cluster_target_guid
      ,tc.target_name              AS cluster_name
      ,tc.last_load_time_utc       AS cluster_last_load_time_utc
      ,tc.owner                    AS cluster_owner
      ,tca.availability_status     AS cluster_status
      ,tr.target_guid              AS rac_target_guid
      ,tr.target_name              AS rac
      ,tr.last_load_time_utc       AS rac_last_load_time_utc
      ,tr.owner                    AS rac_owner
      ,tr.type_qualifier2          AS rac_stand_by_type
      ,tra.availability_status     AS rac_status
      ,tr.type_version             AS rac_type_version
      ,tr.target_type              AS rac_type
      ,CASE
         WHEN COUNT(1) OVER (PARTITION BY tr.target_name) > 1 THEN 1
       ELSE
         0
       END rac_cluster_dup_flag
FROM   sysman.mgmt$availability_current tra
      ,sysman.mgmt$target               tr
      ,sysman.mgmt$target_associations  i
      ,sysman.mgmt$availability_current tca
      ,sysman.mgmt$target               tc
WHERE  tr.target_guid           = tra.target_guid (+)
AND    i.source_target_name     = tr.target_name (+)
AND    i.source_target_type     = tr.target_type (+)
AND    i.source_target_type (+) = 'rac_database'
AND    i.association_type   (+) = 'runs_on_cluster'
AND    tc.target_type           = i.assoc_target_type (+)
AND    tc.target_name           = i.assoc_target_name (+)
AND    tc.target_guid           = tca.target_guid     (+)
AND    tc.target_type           = 'cluster'
)
,db_instances AS
(
SELECT td.target_guid          AS db_target_guid
      ,td.target_name          AS db
      ,td.type_version         AS db_type_version
      ,td.owner                AS db_owner
      ,td.last_load_time_utc   AS db_last_load_time_utc
      ,td.type_qualifier4      AS db_stand_by_type
      ,tda.availability_status AS db_status
      ,td.target_type          AS db_type
      ,th.target_guid          AS h_target_guid
      ,th.target_name          AS h
      ,th.type_version         AS h_type_version
      ,th.last_load_time_utc   AS h_last_load_time_utc
      ,tha.availability_status AS h_status
      ,tr.target_guid          AS rac_target_guid
      ,tr.target_name          AS rac
FROM   sysman.mgmt$availability_current tha
      ,sysman.mgmt$target               th
      ,sysman.mgmt$target               tr
      ,sysman.mgmt$target_associations  i
      ,sysman.mgmt$availability_current tda
      ,sysman.mgmt$target               td
WHERE  th.target_guid           = tha.target_guid (+)
AND    th.target_type           = 'host'
AND    td.host_name             = th.target_name
AND    i.source_target_name     = tr.target_name (+)
AND    i.source_target_type     = tr.target_type (+)
AND    i.source_target_type (+) = 'rac_database'
AND    i.association_type   (+) = 'cluster_contains'
AND    td.target_type           = i.assoc_target_type  (+)
AND    td.target_name           = i.assoc_target_name  (+)
AND    td.target_guid           = tda.target_guid      (+)
AND    td.target_type           = 'oracle_database'
)
SELECT   NVL(x1.dbmachine,              x2.dbmachine)                   AS dbmachine
        ,NVL(x1.dbmachine_type_version, x2.dbmachine_type_version)      AS dbmachine_type_version
        ,NVL(x1.dbmachine_type,         x2.dbmachine_type)              AS dbmachine_type
        ,NVL(x1.dbmachine_owner,        x2.dbmachine_owner)             AS dbmachine_owner
        ,NVL(c.cluster_name,   'none')                                  AS cluster_name
        ,NVL(c.cluster_owner,  'none')                                  AS cluster_owner
        ,NVL(c.cluster_status, 'none')                                  AS cluster_status
        ,TO_CHAR(c.cluster_last_load_time_utc, 'YYYY-MM-DD HH24:MI:SS') AS cluster_last_load_time_utc
        ,CASE
           WHEN c.rac_type = 'rac_database' THEN 'yes'
         ELSE
           'no'
         END                                          AS clustered
        ,NVL(c.rac, d.db)                             AS cdb
        ,NVL(c.rac_type_version,  d.db_type_version)  AS cdb_type_version
        ,NVL(c.rac_type,          d.db_type)          AS cdb_type
        ,NVL(c.rac_owner,         d.db_owner)         AS cdb_owner
        ,NVL(c.rac_stand_by_type, d.db_stand_by_type) AS cdb_stand_by_type
        ,NVL(c.rac_status
            ,d.db_status)                             AS cdb_status
        ,TO_CHAR(NVL(c.rac_last_load_time_utc, d.db_last_load_time_utc)
                ,'YYYY-MM-DD HH24:MI:SS')             AS cdb_last_load_time_utc
        ,d.db
        ,d.db_type_version
        ,d.db_type
        ,d.db_owner
        ,d.db_stand_by_type
        ,d.db_status
        ,TO_CHAR(d.db_last_load_time_utc, 'YYYY-MM-DD HH24:MI:SS') AS db_last_load_time_utc
        ,d.h                     AS host
        ,d.h_type_version        AS host_type_version
        ,d.h_status              AS host_status
        ,TO_CHAR(d.h_last_load_time_utc,  'YYYY-MM-DD HH24:MI:SS') AS host_last_load_time_utc
        ,hw.physical_cpu_count   AS physical_cpu_count
        ,0                       AS total_cpu_cores
        ,hw.logical_cpu_count    AS logical_cpu_count
        ,CASE
           WHEN hw.mem IS NULL THEN 0
         ELSE
           hw.mem / 1024
         END                    AS mem_gb
        ,hw.freq                AS freq
        ,hw.ma                  AS ma
        ,hw.system_config       AS system_config
        ,hw.vendor_name         AS vendor_name
        ,hw.distributor_version AS dist_version
        ,NVL(c.rac_cluster_dup_flag, 0) AS dup_rac_cluster_flag
        ,0                              AS dup_host_dbmachine_flag
        ,RAWTOHEX(NVL(x1.dbmachine_target_guid, x2.dbmachine_target_guid)) AS dbmachine_target_guid
        ,RAWTOHEX(c.cluster_target_guid)                                   AS cluster_target_guid
        ,RAWTOHEX(NVL(c.rac_target_guid, d.db_target_guid))                AS cdb_target_guid
        ,RAWTOHEX(d.db_target_guid)                                        AS db_target_guid
        ,RAWTOHEX(d.h_target_guid)                                         AS host_target_guid
FROM     rac_db_machines           x2
        ,db_db_machines            x1
        ,cluster_rac_dbs           c
        ,sysman.mgmt$os_hw_summary hw
        ,db_instances              d
WHERE    d.db_target_guid  = x1.db_target_guid  (+)
AND      d.rac_target_guid = x2.rac_target_guid (+)
AND      d.rac_target_guid = c.rac_target_guid  (+)
AND      d.h_target_guid   = hw.target_guid     (+)
UNION ALL
SELECT embedded_query.dbmachine
      ,embedded_query.dbmachine_type_version
      ,embedded_query.dbmachine_type
      ,NULL                   AS dbmachine_owner
      ,'none'                 AS cluster_name
      ,'none'                 AS cluster_owner
      ,'none'                 AS cluster_status
      ,NULL                   AS cluster_last_load_time_utc
      ,'no'                   AS clustered
      ,'none'                 AS cdb
      ,'none'                 AS cdb_type_version
      ,'none'                 AS cdb_type
      ,'none'                 AS cdb_owner
      ,'none'                 AS cdb_stand_by_type
      ,'none'                 AS cdb_status
      ,NULL                   AS cdb_last_load_time_utc
      ,'none'                 AS db
      ,'none'                 AS db_type_version
      ,'none'                 AS db_type
      ,'none'                 AS db_owner
      ,'none'                 AS db_stand_by_type
      ,'none'                 AS db_status
      ,NULL                   AS db_last_load_time_utc
      ,embedded_query.h       AS host
      ,embedded_query.h_type_version AS host_type_version
      ,ha.availability_status        AS host_status
      ,TO_CHAR(h.last_load_time_utc, 'YYYY-MM-DD HH24:MI:SS') AS host_last_load_time_utc
      ,hw.physical_cpu_count  AS physical_cpu_count
      ,0                      AS total_cpu_cores
      ,hw.logical_cpu_count   AS logical_cpu_count
      ,CASE
         WHEN hw.mem IS NULL THEN 0
       ELSE
         hw.mem / 1024
       END                    AS mem_gb
      ,hw.freq                AS freq
      ,hw.ma                  AS ma
      ,hw.system_config       AS system_config
      ,hw.vendor_name         AS vendor_name
      ,hw.distributor_version AS dist_version
      ,0                      AS dup_rac_cluster_flag
      ,CASE
         WHEN COUNT(1) OVER (PARTITION BY embedded_query.h_guid) > 1 THEN 1
       ELSE
         0
       END                           AS dup_host_dbmachine_flag
      ,embedded_query.dbmachine_guid AS dbmachine_target_guid
      ,NULL                          AS cluster_target_guid
      ,NULL                          AS cdb_target_guid
      ,NULL                          AS db_target_guid
      ,embedded_query.h_guid         AS host_target_guid
FROM   sysman.mgmt$availability_current ha
      ,sysman.mgmt$os_hw_summary        hw
      ,sysman.mgmt$target               h
,
(
SELECT RAWTOHEX(m.member_target_guid) AS h_guid
      ,m.member_target_name           AS h
      ,h.type_version                 AS h_type_version
      ,RAWTOHEX(x.target_guid)        AS dbmachine_guid
      ,x.target_name                  AS dbmachine
      ,x.type_version                 AS dbmachine_type_version
      ,x.target_type                  AS dbmachine_type
FROM   sysman.mgmt$target              h
      ,sysman.mgmt$target              x
      ,sysman.mgmt$target_flat_members m
WHERE  m.member_target_guid     = h.target_guid
AND    m.aggregate_target_guid  = x.target_guid
AND    m.aggregate_target_type IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
AND    m.member_target_type     = 'host'
) embedded_query
WHERE embedded_query.h_guid = ha.target_guid (+)
AND   embedded_query.h_guid = hw.target_guid (+)
AND   embedded_query.h_guid = h.target_guid
AND   embedded_query.h NOT IN
(
 SELECT d.host_name FROM sysman.mgmt$target d WHERE d.target_type = 'oracle_database'
)
) t;

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_db.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
