rem
rem Version 1.1
define __version__ = 1.1
rem

rem Version History
rem
rem 2022-03-24    1.1   mgr     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting List of EM Metrics...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_em_metrics.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_em_metrics.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","COLL_NAME","IS_ENABLED","SCHEDULE_EX"

SELECT RAWTOHEX(t.target_guid) AS target_guid
	,t.target_name
	,t.target_type
	,c.coll_name
	,c.is_enabled
	,TRANSLATE(c.schedule_ex, CHR(10) || CHR(13) || CHR(09), ' ') AS schedule_ex
FROM sysman.mgmt_targets t
	LEFT JOIN sysman.mgmt_collections c ON t.target_guid = c.object_guid
WHERE t.target_type IN ('oracle_database','rac_database');

rem Limit to only disabled
rem WHERE t.target_type IN ('oracle_database','rac_database') AND c.is_enabled = 0;

spool off

spool emcc_sizing_extracts/emcc_sizing_em_metrics.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
