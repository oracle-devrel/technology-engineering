rem
rem Version 1.5
define __version__ = 1.5
rem

rem Version History
rem
rem 2021-02-08    1.5   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.4   tmf     Added timing off
rem 2020-11-19    1.3   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.2   tmf     mkdir -p
rem 2020-06-15    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting host VM structure...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_host_vm.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_host_vm.csv

prompt "host","vm_guest","vm_server","vm_server_pool","extract_dttm_utc"

WITH vm_guests AS
(
SELECT DISTINCT
       t.target_name        AS  vm_guest
      ,t.target_type        AS vm_guest_type
      ,i.source_target_name AS host
      ,i.source_target_type AS host_type
FROM   sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  t.target_name                                            = i.assoc_target_name
AND    t.target_type                                            = i.assoc_target_type
AND    t.target_type                                            = 'oracle_vm_guest'
AND    i.source_target_type                                     = 'host'
AND    INSTR(LOWER(i.source_target_name), LOWER(t.target_name)) > 0
),
vm_servers AS
(
SELECT DISTINCT
       i.source_target_name AS vm_guest
      ,i.source_target_type AS vm_guest_type
      ,t.target_name        AS vm_server
      ,t.target_type        AS vm_server_type
FROM   sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  t.target_name        = i.assoc_target_name
AND    t.target_type        = i.assoc_target_type
AND    t.target_type        = 'oracle_vm_server'
AND    i.source_target_type = 'oracle_vm_guest'
),
vm_server_pools AS
(
SELECT DISTINCT
       t.target_name        AS vm_server
      ,t.target_type        AS vm_server_type
      ,i.source_target_name AS vm_server_pool
      ,i.source_target_type AS vm_server_pool_type
FROM   sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  t.target_name        = i.assoc_target_name
AND    t.target_type        = i.assoc_target_type
AND    t.target_type        = 'oracle_vm_server'
AND    i.source_target_type = 'oracle_vm_server_pool'
)
SELECT g.host           AS "host"
      ,g.vm_guest       AS "vm_guest"
      ,s.vm_server      AS "vm_server"
      ,p.vm_server_pool AS "vm_server_pool"
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS') AS "extract_dttm_utc"
FROM   vm_server_pools p
      ,vm_servers      s
      ,vm_guests       g
WHERE s.vm_server_type = p.vm_server_type (+)
AND   s.vm_server      = p.vm_server      (+)
AND   g.vm_guest_type  = s.vm_guest_type  (+)
AND   g.vm_guest       = s.vm_guest       (+);

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_host_vm.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
