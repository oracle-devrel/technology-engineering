Obfucate Extracts Readme
================================================================================
Data Obfuscation can be used when server names, database names, owners, etc. can't be shared with Oracle.

Prerequisites
--------------------------------------------------------------------------------
   1) python 3: 3.6 or higher
   3) EMCC Extracts collections

Run Obfuscation script
--------------------------------------------------------------------------------
    1) Open a terminal window and change directory to the extracts directory that contains both the emcc_sizing_extracts directory and the
    Obfuscate_Extracts.py file.

    2) Verify the correct Python command to run version 3 of Python, on some systems Python 3 may be installed as "python3".

    3) At the command prompt and using the current Python command type: python3 Obfuscate_Extracts.py

    4) You will see a series of messages as the scripts obfuscate the contents of the EMCC Extract files.

    5) The obfuscated files are written to a new directory named emcc_sizing_obfuscated.  A new file will also be created that
    translates the original values to the obfuscated values, it is written to the e obfuscated_translation.csv file in the
    emcc_sizing_output directory. Make sure and keep a copy of this file as it may be required to answer questions from Oracle.

    6) Zip up the contents of the emcc_sizing_obfuscated directory and upload to Oracle for analysis.

NOTE : If Source Side Filtering feature has been used over the EMCC Extracts collection the directories used will be :
    - emcc_sizing_extracts_filtered_obfuscated where the files will be written
    - emcc_sizing_extracts_filtered as source directory for obfuscation
    - obfuscated_translation_filtered.csv as translation file
