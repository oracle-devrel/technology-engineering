rem
rem Version 1.8
define __version__ = 1.8
rem

rem Version History
rem
rem 2021-02-08    1.8   tmf     Removed -p to be Windows friendly
rem 2021-01-15    1.7   tmf     Protected against table differences
rem 2020-12-15    1.6   tmf     Added timing off
rem 2020-11-19    1.5   tmf     Added capture of SQL*Plus version
rem 2020-11-15    1.4   tmf     Added pull of sysman.mgmt$vi_osv_cfg_details
rem 2020-11-05    1.3   tmf     mkdir -p
rem 2020-10-11    1.2   tmf     Re-factored query
rem 2020-06-15    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting host VM structure...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

rem ====================================================================================================================

spool emcc_sizing_extracts/emcc_sizing_structure_sm.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_sm.csv

prompt "si_server_map_guid","si_server_map","sm_type","sm_identifier","sm_model","sm_serial_no","sm_part_no","sm_arch","sm_total_mem_mb","sm_cores"-
,"is_pdom_container","last_collection_timestamp_utc","extract_dttm_utc"

var rc REFCURSOR

DECLARE

  v_cnt PLS_INTEGER;

BEGIN

  SELECT COUNT(1)
  INTO   v_cnt
  FROM   all_views
  WHERE  view_name = 'MGMT$SI_SVR_SYSUM_CONFIG'
  AND    owner     = 'SYSMAN';

  IF v_cnt = 0 THEN
    OPEN :rc
    FOR
'SELECT 1 FROM sys.DUAL WHERE 1 = 0';

  ELSE
    OPEN :rc
    FOR
'SELECT RAWTOHEX(cm_target_guid) AS cm_target_guid
      ,cm_target_name
      ,cm_target_type
      ,identifier
      ,model
      ,serial_number
      ,part_number
      ,architecture
      ,total_memory
      ,num_cores
      ,is_pdom_container
      ,TO_CHAR(CAST(FROM_TZ(CAST(hw.last_collection_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE ''UTC'' AS DATE), ''YYYY-MM-DD HH24:MI:SS'') AS last_collection_timestamp_utc
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), ''YYYY-MM-DD HH24:MI:SS'') AS extract_dttm_utc
FROM   sysman.mgmt$target              t
      ,sysman.mgmt$si_svr_sysum_config hw
WHERE  hw.cm_target_guid = t.target_guid';

  END IF;

END;
/

print rc

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_sm.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

rem ====================================================================================================================

spool emcc_sizing_extracts/emcc_sizing_structure_vp.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_vp.csv

prompt "si_virtual_platform_guid","si_virtual_platform","vp_type","vp_platform_version","vp_allocated_cpu","vp_allocated_mem_mb","vp_vendor","vp_vendor_version","vp_os","vp_os_type"-
,"vp_kernel_release","vp_vt_enabled","vp_xen_capabilities","vp_vcpu_allocted_to_vms","last_collection_timestamp_utc","extract_dttm_utc"

DECLARE

  v_cnt PLS_INTEGER;

BEGIN

  SELECT COUNT(1)
  INTO   v_cnt
  FROM   all_views
  WHERE  view_name = 'MGMT$VI_VP_CFG_DETAILS'
  AND    owner     = 'SYSMAN';

  IF v_cnt = 0 THEN
    OPEN :rc
    FOR
'SELECT 1 FROM sys.DUAL WHERE 1 = 0';

  ELSE
    OPEN :rc
    FOR
'SELECT RAWTOHEX(cm_target_guid) AS cm_target_guid
      ,cm_target_name
      ,cm_target_type
      ,platform_version
      ,allocated_cpu
      ,allocated_memory_mb
      ,vendor_name
      ,vendor_version
      ,os_name
      ,os_type
      ,kernel_release
      ,vt_enabled
      ,xen_capabilities
      ,tot_vcpu_alloc_to_vms
      ,TO_CHAR(CAST(FROM_TZ(CAST(hw.last_collection_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE ''UTC'' AS DATE), ''YYYY-MM-DD HH24:MI:SS'') AS last_collection_timestamp_utc
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), ''YYYY-MM-DD HH24:MI:SS'') AS extract_dttm_utc
FROM   sysman.mgmt$target            t
      ,sysman.mgmt$vi_vp_cfg_details hw
WHERE  hw.cm_target_guid = t.target_guid';

  END IF;

END;
/

print rc

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_vp.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

rem ====================================================================================================================

spool emcc_sizing_extracts/emcc_sizing_structure_vp2.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_vp2.csv

prompt "si_server_guid","si_server","si_server_type","si_virtual_platform_guid","si_virtual_platform","vp_type"-
,"vp_machine_architecture","vp_clock_freq_in_mhz","vp_cpu_count","vp_num_of_socks","vp_total_num_cpu_cores","vp_num_cores_per_sock","vp_num_threads_per_core","vp_enabled_cores"-
,"vp_vendor_name","vp_memory_size_mb","vp_local_disk_space_in_gb","vp_manufacturer_product_name","vp_enabled_cpus"-
,"vp_bios_rel_date","vp_bios_vendor","vp_bios_version","vp_serial_number"-
,"last_load_time_utc","extract_dttm_utc"

DECLARE

  v_cnt PLS_INTEGER;
  v_sql VARCHAR2(4000);

BEGIN

  SELECT COUNT(1)
  INTO   v_cnt
  FROM   all_views
  WHERE  view_name = 'MGMT$VI_DM_OSP_CFG_DETAILS'
  AND    owner     = 'SYSMAN';

  IF v_cnt = 0 THEN
    OPEN :rc
    FOR
'SELECT 1 FROM sys.DUAL WHERE 1 = 0';

  ELSE
    SELECT COUNT(1)
    INTO   v_cnt
    FROM   all_tab_columns
    WHERE  column_name  = 'ENABLED_CPUS'
    AND    table_name   = 'MGMT$VI_DM_OSP_CFG_DETAILS'
    AND    owner        = 'SYSMAN';

    v_sql :=
'SELECT RAWTOHEX(cm_target_guid) AS si_server_guid
      ,cm_target_name           AS si_server
      ,cm_target_type           AS si_server_type
      ,RAWTOHEX(vp.target_guid) AS si_virtual_platform_guid
      ,vp.target_name           AS si_virtual_platform
      ,vp.target_type           AS vp_type
      ,machine_architecture
      ,clock_freq_in_mhz
      ,cpu_count
      ,num_of_socks
      ,total_num_cpu_cores
      ,num_cores_per_sock
      ,num_threads_per_core
      ,enabled_cores
      ,vendor_name
      ,memory_size_mb
      ,local_disk_space_in_gb
      ,manufacturer	product_name
      ,enabled_cpus
      ,bios_rel_date
      ,bios_vendor
      ,bios_version
      ,serial_number
      ,TO_CHAR(vp.last_load_time_utc,         ''YYYY-MM-DD HH24:MI:SS'') AS last_load_time_utc
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), ''YYYY-MM-DD HH24:MI:SS'') AS extract_dttm_utc
FROM   sysman.mgmt$target                vp
      ,sysman.mgmt$target_associations   a
      ,sysman.mgmt$target                t
      ,sysman.mgmt$vi_dm_osp_cfg_details hw
WHERE  vp.target_type (+)     = ''oracle_si_virtual_platform''
AND    a.source_target_type   = vp.target_type      (+)
AND    a.source_target_name   = vp.target_name      (+)
AND    a.association_type (+) = ''deployed_on''
AND    hw.cm_target_type      = a.assoc_target_type (+)
AND    hw.cm_target_name      = a.assoc_target_name (+)
AND    hw.cm_target_type      = ''oracle_si_server''
AND    hw.cm_target_guid      = t.target_guid';

    IF v_cnt = 0 THEN
--
--    Older versions of the view lack the following columns
--
      v_sql := REPLACE(v_sql, 'enabled_cpus',  'NULL');
      v_sql := REPLACE(v_sql, 'bios_rel_date', 'NULL');
      v_sql := REPLACE(v_sql, 'bios_vendor',   'NULL');
      v_sql := REPLACE(v_sql, 'bios_version',  'NULL');
      v_sql := REPLACE(v_sql, 'serial_number', 'NULL');

    END IF;

    OPEN :rc
    FOR  v_sql;

  END IF;

END;
/

print rc

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_vp2.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

rem ====================================================================================================================

spool emcc_sizing_extracts/emcc_sizing_structure_vs.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_vs.csv

prompt "si_virtual_server_guid","si_virtual_server","vs_type","vs_processor_speed","vs_processor_type","vs_memory_mb","vs_available_mem_mb","vs_mem_overhead_mb","vs_usable_mem_mb","vs_local_disk_gb"-
,"vs_enabled_processors","vs_enabled_cores","vs_num_vcpus","vs_cd_cpu_count","vs_num_cores","vs_num_cores_per_sock","last_collection_timestamp_utc","extract_dttm_utc"

DECLARE

  v_cnt PLS_INTEGER;

BEGIN

  SELECT COUNT(1)
  INTO   v_cnt
  FROM   all_views
  WHERE  view_name = 'CM$VT_VS_HW_CFG'
  AND    owner     = 'SYSMAN';

  IF v_cnt = 0 THEN
    OPEN :rc
    FOR
'SELECT 1 FROM sys.DUAL WHERE 1 = 0';

  ELSE
    OPEN :rc
    FOR
'SELECT RAWTOHEX(cm_target_guid) AS cm_target_guid
      ,cm_target_name
      ,cm_target_type
      ,processor_speed
      ,processor_type
      ,memory_mb
      ,available_mem_mb
      ,mem_overhead_mb
      ,usable_mem_mb
      ,local_disk_gb
      ,enabled_processors
      ,enabled_cores
      ,num_vcpus
      ,cd_cpu_count
      ,num_cores
      ,num_cores_per_sock
      ,TO_CHAR(CAST(FROM_TZ(CAST(hw.last_collection_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE ''UTC'' AS DATE), ''YYYY-MM-DD HH24:MI:SS'') AS last_collection_timestamp_utc
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), ''YYYY-MM-DD HH24:MI:SS'') AS extract_dttm_utc
FROM   sysman.mgmt$target     t
      ,sysman.cm$vt_vs_hw_cfg hw
WHERE  hw.cm_target_guid = t.target_guid';

  END IF;

END;
/

print rc

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_vs.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

rem ====================================================================================================================

spool emcc_sizing_extracts/emcc_sizing_structure_vs2.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_vs2.csv

prompt "si_virtual_server_guid","si_virtual_server","vs_type","vs_allocated_cpu","vs_allocated_memory_mb","last_collection_timestamp_utc","extract_dttm_utc"

DECLARE

  v_cnt PLS_INTEGER;

BEGIN

  SELECT COUNT(1)
  INTO   v_cnt
  FROM   all_views
  WHERE  view_name = 'MGMT$VI_OSV_CFG_DETAILS'
  AND    owner     = 'SYSMAN';

  IF v_cnt = 0 THEN
    OPEN :rc
    FOR
'SELECT 1 FROM sys.DUAL WHERE 1 = 0';

  ELSE
    OPEN :rc
    FOR
'SELECT RAWTOHEX(cm_target_guid) AS cm_target_guid
      ,cm_target_name
      ,cm_target_type
      ,allocated_cpu
      ,allocated_memory_mb
      ,TO_CHAR(CAST(FROM_TZ(CAST(hw.last_collection_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE ''UTC'' AS DATE), ''YYYY-MM-DD HH24:MI:SS'') AS last_collection_timestamp_utc
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), ''YYYY-MM-DD HH24:MI:SS'') AS extract_dttm_utc
FROM   sysman.mgmt$target             t
      ,sysman.mgmt$vi_osv_cfg_details hw
WHERE  hw.cm_target_guid = t.target_guid';

  END IF;

END;
/

print rc

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_vs2.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

rem ====================================================================================================================

exit
