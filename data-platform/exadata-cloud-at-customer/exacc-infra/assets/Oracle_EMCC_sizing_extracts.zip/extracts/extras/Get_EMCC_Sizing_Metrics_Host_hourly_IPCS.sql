rem
rem Version 1.1
define __version__ = 1.1
rem

rem Version History
rem
rem 2021-02-08    1.1  tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting Host hourly metrics IPCS...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_metrics_host_hourly_IPCS.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_metrics_host_hourly_IPCS.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","METRIC_LABEL","COLUMN_LABEL","METRIC_NAME","METRIC_COLUMN","ROLLUP_TIMESTAMP_UTC","MINIMUM","MAXIMUM","AVERAGE","STANDARD_DEVIATION","SAMPLE_COUNT"

WITH t AS
(
 SELECT /*+ MATERIALIZE */
        target_guid, timezone_region
 FROM   sysman.mgmt$target
 WHERE  target_type = 'host'
 AND    target_name IN (
                        SELECT host_name
                        FROM   sysman.mgmt$target
                        WHERE  target_type = 'oracle_database'
                        UNION
                        SELECT member_target_name
                        FROM   sysman.mgmt$target_flat_members
                        WHERE  member_target_type     = 'host'
                        AND    aggregate_target_type IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
                       )
/*
 AND    target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type     = 'host'
 AND    aggregate_target_name IN
(
 'DB Machine m1.us.oracle.com'
,'DB Machine m2.us.oracle.com'
)
)
*/
)
SELECT RAWTOHEX(a.target_guid) AS target_guid
      ,a.target_name
      ,a.target_type
      ,a.metric_label
      ,a.column_label  || ' - ' || DECODE(a.key_value, '-1', 'MINUS1', 'AGG') AS column_label
      ,a.metric_name
      ,a.metric_column || ' - ' || DECODE(a.key_value, '-1', 'MINUS1', 'AGG') AS column_label
      ,TO_CHAR(CAST(FROM_TZ(CAST(a.rollup_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS rollup_timestamp_utc
      ,SUM(NVL(a.minimum,            0))              AS minimum
      ,SUM(NVL(a.maximum,            0))              AS maximum
      ,SUM(NVL(a.average,            0))              AS average
      ,0                                              AS standard_deviation
      ,SUM(1)                                         AS sample_count
FROM   t, sysman.mgmt$metric_hourly a
WHERE  a.target_guid  = t.target_guid
AND    a.metric_guid IN
(
 HEXTORAW('235CAC35019433182658A3DF3E3E5D8D') -- IPCS Shared Memory Status, Segment Size in MB
)
GROUP BY RAWTOHEX(a.target_guid)
        ,a.target_name
        ,a.target_type
        ,a.metric_label
        ,a.column_label  || ' - ' || DECODE(a.key_value, '-1', 'MINUS1', 'AGG')
        ,a.metric_name
        ,a.metric_column || ' - ' || DECODE(a.key_value, '-1', 'MINUS1', 'AGG')
        ,TO_CHAR(CAST(FROM_TZ(CAST(a.rollup_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS');

spool off

spool emcc_sizing_extracts/emcc_sizing_metrics_host_hourly_IPCS.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
