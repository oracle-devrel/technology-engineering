rem
rem Version 1.1
rem

rem Version History
rem
rem 2020-11-05    1.1  tmf     First version
rem

SELECT guid
FROM
(
SELECT   DISTINCT
         ',HEXTORAW(''' || a.metric_guid ||  ''') -- '  || RPAD(a.metric_name || ', ' || a.metric_column, 62, ' ') || ' ---> ' || a.metric_label || ', ' || a.column_label AS guid
        ,a.metric_name, a.metric_column
FROM     sysman.mgmt$target_type a
WHERE   (
         (
              1 = 1 /* tmf list */
          AND a.metric_label IN (
                                 'CPU Usage'
                                ,'Database Limits'
                                ,'Database Size'
                                ,'Efficiency'
                                ,'PGA Allocated'
                                ,'SGA and PGA usage'
                                ,'Throughput'
                                ,'Wait Bottlenecks'
                                )
          AND a.column_label IN (
                                 'Average Total CPU Usage Per Second (CentiSecond Per Second)'
                                ,'Current Logons Count'
                                ,'Allocated Space(GB)', 'Used Space(GB)'
                                ,'CPU Usage (per second)', 'Database CPU Time (%)'
                                ,'Total PGA Allocated (MB)'
                                ,'SGA Size(MB)', 'PGA Total(MB)'
                                ,'Average Active Sessions', 'I/O Megabytes (per second)', 'I/O Requests (per second)', 'Physical Reads (per second)', 'Physical Writes (per second)'
                                ,'Average Instance CPU (%)'
                                )
         )
   OR    (
              1 = 1 /* tmf additional list */
          AND a.metric_column IN (
                                  'bufcachehit_pct'
                                 ,'physreadsdir_ps'
                                 ,'physwritesdir_ps'
                                 ,'redosize_ps'
                                 ,'redowrites_ps'
                                 ,'host_cpu_usage_pct'
                                 ,'dbblkchanges_ps'
                                 ,'opt_sga_size'
                                 ,'logons_ps'
                                 )
         )
   OR    (
              1 = 0 /* js list */
          AND a.metric_column IN (
                                  'physreads_ps'
                                 ,'physreadsdir_ps'
                                 ,'physwrites_ps'
                                 ,'physwritesdir_ps'
                                 ,'logreads_ps'
                                 ,'redowrites_ps'
                                 ,'ALLOCATED_GB'
                                 ,'USED_GB'
                                 ,'Free_Space'
                                 ,'cpuusage_ps'
                                 ,'cpuusage_pt'
                                 ,'cpu_time_pct'
                                 ,'host_cpu_usage_pct'
                                 ,'regular_cpu'
                                 ,'dbblkchanges_ps'
                                 ,'executions_ps'
                                 ,'logons_ps'
                                 )
         )
        )
AND      a.target_type  IN ('oracle_database', 'rac_database')
ORDER BY a.metric_name, a.metric_column
);



tmf

(
 HEXTORAW('AB9CAF80590230CCA321554A36A83E56') -- db_inst_cpu_usage, avg_tot_cpu_usage_ps                        ---> CPU Usage, Average Total CPU Usage Per Second (CentiSecond Per Second)
,HEXTORAW('A65657E22E8376569DA71AE298EE9997') -- Database_Resource_Usage, logons                                ---> Database Limits, Current Logons Count
,HEXTORAW('47D47BEF38343C9A32A4EF81D122BA04') -- DATABASE_SIZE, ALLOCATED_GB                                    ---> Database Size, Allocated Space(GB)
,HEXTORAW('DC498CC90B549E44367920908A1B15DE') -- DATABASE_SIZE, ALLOCATED_GB                                    ---> Database Size, Allocated Space(GB)
,HEXTORAW('AA4F1CD67A3FD2375435D89676EFF935') -- DATABASE_SIZE, USED_GB                                         ---> Database Size, Used Space(GB)
,HEXTORAW('CAAFBF5E0ABD56B72E23B9354135DA6A') -- DATABASE_SIZE, USED_GB                                         ---> Database Size, Used Space(GB)
,HEXTORAW('B8298BEF177C1C2B0F40C01DA6BF78DA') -- instance_efficiency, cpuusage_ps                               ---> Efficiency, CPU Usage (per second)
,HEXTORAW('8ACC57E04CCF57B8AFD1B60D71610D68') -- instance_efficiency, cpu_time_pct                              ---> Efficiency, Database CPU Time (%)
,HEXTORAW('80C71A19C43300F8D661628E99458627') -- db_inst_pga_alloc, total_pga_allocated                         ---> PGA Allocated, Total PGA Allocated (MB)
,HEXTORAW('4BBDD79DF1EB13CC8D9B991E8D2885F8') -- memory_usage_sga_pga, pga_total                                ---> SGA and PGA usage, PGA Total(MB)
,HEXTORAW('0DD82DEF4D7B007FB0D5492E417A7C26') -- memory_usage_sga_pga, sga_total                                ---> SGA and PGA usage, SGA Size(MB)
,HEXTORAW('546FB5359968978840BF76FB914103C6') -- instance_throughput, avg_active_sessions                       ---> Throughput, Average Active Sessions
,HEXTORAW('DB1E7076108F6D5898B69F2AD2EDA216') -- instance_throughput, iombs_ps                                  ---> Throughput, I/O Megabytes (per second)
,HEXTORAW('3BD01E2C561E474056EB892AD509760F') -- instance_throughput, iorequests_ps                             ---> Throughput, I/O Requests (per second)
,HEXTORAW('05568685900528A6895E97C600F58BC1') -- instance_throughput, physreads_ps                              ---> Throughput, Physical Reads (per second)
,HEXTORAW('247ED26590C1FBA8D5839A42591F0817') -- instance_throughput, physwrites_ps                             ---> Throughput, Physical Writes (per second)
,HEXTORAW('CADFA1BF3907CA34D1CD1DE4D3E46B9B') -- wait_bottlenecks, avg_user_cpu_time_pct                        ---> Wait Bottlenecks, Average Instance CPU (%)
);



tmf new

(
 HEXTORAW('47D47BEF38343C9A32A4EF81D122BA04') -- DATABASE_SIZE, ALLOCATED_GB                                    ---> Database Size, Allocated Space(GB)
,HEXTORAW('DC498CC90B549E44367920908A1B15DE') -- DATABASE_SIZE, ALLOCATED_GB                                    ---> Database Size, Allocated Space(GB)
,HEXTORAW('AA4F1CD67A3FD2375435D89676EFF935') -- DATABASE_SIZE, USED_GB                                         ---> Database Size, Used Space(GB)
,HEXTORAW('CAAFBF5E0ABD56B72E23B9354135DA6A') -- DATABASE_SIZE, USED_GB                                         ---> Database Size, Used Space(GB)
,HEXTORAW('A65657E22E8376569DA71AE298EE9997') -- Database_Resource_Usage, logons                                ---> Database Limits, Current Logons Count
,HEXTORAW('AB9CAF80590230CCA321554A36A83E56') -- db_inst_cpu_usage, avg_tot_cpu_usage_ps                        ---> CPU Usage, Average Total CPU Usage Per Second (CentiSecond Per Second)
,HEXTORAW('38AB0A7A1353AA466F5D8A5C122729AC') -- db_inst_opt_sga, opt_sga_size                                  ---> Optimal SGA, Optimal SGA Size (MB)
,HEXTORAW('80C71A19C43300F8D661628E99458627') -- db_inst_pga_alloc, total_pga_allocated                         ---> PGA Allocated, Total PGA Allocated (MB)
,HEXTORAW('A3119CB3CA3673C29F3BABDB4E37D5B5') -- instance_efficiency, bufcachehit_pct                           ---> Efficiency, Buffer Cache Hit (%)
,HEXTORAW('8ACC57E04CCF57B8AFD1B60D71610D68') -- instance_efficiency, cpu_time_pct                              ---> Efficiency, Database CPU Time (%)
,HEXTORAW('B8298BEF177C1C2B0F40C01DA6BF78DA') -- instance_efficiency, cpuusage_ps                               ---> Efficiency, CPU Usage (per second)
,HEXTORAW('546FB5359968978840BF76FB914103C6') -- instance_throughput, avg_active_sessions                       ---> Throughput, Average Active Sessions
,HEXTORAW('90314E5F76C762115BA28B9D2EE831D5') -- instance_throughput, dbblkchanges_ps                           ---> Throughput, Database Block Changes (per second)
,HEXTORAW('DB1E7076108F6D5898B69F2AD2EDA216') -- instance_throughput, iombs_ps                                  ---> Throughput, I/O Megabytes (per second)
,HEXTORAW('3BD01E2C561E474056EB892AD509760F') -- instance_throughput, iorequests_ps                             ---> Throughput, I/O Requests (per second)
,HEXTORAW('CE8BE655B9DC0FD5E9C55416E06ED1AD') -- instance_throughput, logons_ps                                 ---> Throughput, Cumulative Logons (per second)
,HEXTORAW('05568685900528A6895E97C600F58BC1') -- instance_throughput, physreads_ps                              ---> Throughput, Physical Reads (per second)
,HEXTORAW('7B7BCE1FDF5AAA47353E23D353F481C2') -- instance_throughput, physreadsdir_ps                           ---> Throughput, Physical Reads Direct (per second)
,HEXTORAW('247ED26590C1FBA8D5839A42591F0817') -- instance_throughput, physwrites_ps                             ---> Throughput, Physical Writes (per second)
,HEXTORAW('5979D44A974B15934320D968DA383166') -- instance_throughput, physwritesdir_ps                          ---> Throughput, Physical Writes Direct (per second)
,HEXTORAW('3104DB0E5DCF1E5C8C4747CEB319A4E2') -- instance_throughput, redosize_ps                               ---> Throughput, Redo Generated (per second)
,HEXTORAW('92E8D8F89CF159497C2ED6E59F375ED4') -- instance_throughput, redowrites_ps                             ---> Throughput, Redo Writes (per second)
,HEXTORAW('4BBDD79DF1EB13CC8D9B991E8D2885F8') -- memory_usage_sga_pga, pga_total                                ---> SGA and PGA usage, PGA Total(MB)
,HEXTORAW('0DD82DEF4D7B007FB0D5492E417A7C26') -- memory_usage_sga_pga, sga_total                                ---> SGA and PGA usage, SGA Size(MB)
,HEXTORAW('CADFA1BF3907CA34D1CD1DE4D3E46B9B') -- wait_bottlenecks, avg_user_cpu_time_pct                        ---> Wait Bottlenecks, Average Instance CPU (%)
,HEXTORAW('4E348CC3AD5420549A3CF704FA4B2436') -- wait_bottlenecks, host_cpu_usage_pct                           ---> Wait Bottlenecks, Host CPU Utilization (%)
,HEXTORAW('BE02FE1E6C5CED7FB0DAF59FD9E2FC23') -- wait_bottlenecks, host_cpu_usage_pct                           ---> Database Wait Bottlenecks, Host CPU Utilization (%)
);



js

(
 HEXTORAW('5FAF3C5596A768C8BBFA68EC305E8055') -- imdb_cpu_activity, regular_cpu                                 ---> CPU Activity of Inmemory database, Regular CPU
,HEXTORAW('B91285DD48FDAF3019A6BDCF63B714D9') -- imdb_cpu_activity, regular_cpu                                 ---> CPU Activity of Inmemory database, Regular CPU
,HEXTORAW('47D47BEF38343C9A32A4EF81D122BA04') -- DATABASE_SIZE, ALLOCATED_GB                                    ---> Database Size, Allocated Space(GB)
,HEXTORAW('DC498CC90B549E44367920908A1B15DE') -- DATABASE_SIZE, ALLOCATED_GB                                    ---> Database Size, Allocated Space(GB)
,HEXTORAW('AA4F1CD67A3FD2375435D89676EFF935') -- DATABASE_SIZE, USED_GB                                         ---> Database Size, Used Space(GB)
,HEXTORAW('CAAFBF5E0ABD56B72E23B9354135DA6A') -- DATABASE_SIZE, USED_GB                                         ---> Database Size, Used Space(GB)
,HEXTORAW('BE02FE1E6C5CED7FB0DAF59FD9E2FC23') -- wait_bottlenecks, host_cpu_usage_pct                           ---> Database Wait Bottlenecks, Host CPU Utilization (%)
,HEXTORAW('B8298BEF177C1C2B0F40C01DA6BF78DA') -- instance_efficiency, cpuusage_ps                               ---> Efficiency, CPU Usage (per second)
,HEXTORAW('891CDD51EC28D3D698163494213F4A3C') -- instance_efficiency, cpuusage_pt                               ---> Efficiency, CPU Usage (per transaction)
,HEXTORAW('8ACC57E04CCF57B8AFD1B60D71610D68') -- instance_efficiency, cpu_time_pct                              ---> Efficiency, Database CPU Time (%)
,HEXTORAW('3F2BBE6BF105C0D16A3710F2868B8399') -- Recovery_Area, Free_Space                                      ---> Recovery Area, Recovery Area Used Space (%)
,HEXTORAW('BE99716C462B6C3CB41A3E2D31D76352') -- Recovery_Area, Free_Space                                      ---> Recovery Area, Recovery Area Used Space (%)
,HEXTORAW('CE8BE655B9DC0FD5E9C55416E06ED1AD') -- instance_throughput, logons_ps                                 ---> Throughput, Cumulative Logons (per second)
,HEXTORAW('90314E5F76C762115BA28B9D2EE831D5') -- instance_throughput, dbblkchanges_ps                           ---> Throughput, Database Block Changes (per second)
,HEXTORAW('CEB598CB984F23F5673CBC467FE99106') -- instance_throughput, executions_ps                             ---> Throughput, Executes (per second)
,HEXTORAW('05568685900528A6895E97C600F58BC1') -- instance_throughput, physreads_ps                              ---> Throughput, Physical Reads (per second)
,HEXTORAW('7B7BCE1FDF5AAA47353E23D353F481C2') -- instance_throughput, physreadsdir_ps                           ---> Throughput, Physical Reads Direct (per second)
,HEXTORAW('247ED26590C1FBA8D5839A42591F0817') -- instance_throughput, physwrites_ps                             ---> Throughput, Physical Writes (per second)
,HEXTORAW('5979D44A974B15934320D968DA383166') -- instance_throughput, physwritesdir_ps                          ---> Throughput, Physical Writes Direct (per second)
,HEXTORAW('92E8D8F89CF159497C2ED6E59F375ED4') -- instance_throughput, redowrites_ps                             ---> Throughput, Redo Writes (per second)
,HEXTORAW('F3535548360FCE04402F0E8CD18CF028') -- instance_throughput, logreads_ps                               ---> Throughput, Session Logical Reads (per second)
,HEXTORAW('4E348CC3AD5420549A3CF704FA4B2436') -- wait_bottlenecks, host_cpu_usage_pct                           ---> Wait Bottlenecks, Host CPU Utilization (%)
);



tmf + js

(
 HEXTORAW('5FAF3C5596A768C8BBFA68EC305E8055') -- imdb_cpu_activity, regular_cpu                                 ---> CPU Activity of Inmemory database, Regular CPU
,HEXTORAW('B91285DD48FDAF3019A6BDCF63B714D9') -- imdb_cpu_activity, regular_cpu                                 ---> CPU Activity of Inmemory database, Regular CPU
,HEXTORAW('AB9CAF80590230CCA321554A36A83E56') -- db_inst_cpu_usage, avg_tot_cpu_usage_ps                        ---> CPU Usage, Average Total CPU Usage Per Second (CentiSecond Per Second)
,HEXTORAW('A65657E22E8376569DA71AE298EE9997') -- Database_Resource_Usage, logons                                ---> Database Limits, Current Logons Count
,HEXTORAW('47D47BEF38343C9A32A4EF81D122BA04') -- DATABASE_SIZE, ALLOCATED_GB                                    ---> Database Size, Allocated Space(GB)
,HEXTORAW('DC498CC90B549E44367920908A1B15DE') -- DATABASE_SIZE, ALLOCATED_GB                                    ---> Database Size, Allocated Space(GB)
,HEXTORAW('AA4F1CD67A3FD2375435D89676EFF935') -- DATABASE_SIZE, USED_GB                                         ---> Database Size, Used Space(GB)
,HEXTORAW('CAAFBF5E0ABD56B72E23B9354135DA6A') -- DATABASE_SIZE, USED_GB                                         ---> Database Size, Used Space(GB)
,HEXTORAW('BE02FE1E6C5CED7FB0DAF59FD9E2FC23') -- wait_bottlenecks, host_cpu_usage_pct                           ---> Database Wait Bottlenecks, Host CPU Utilization (%)
,HEXTORAW('B8298BEF177C1C2B0F40C01DA6BF78DA') -- instance_efficiency, cpuusage_ps                               ---> Efficiency, CPU Usage (per second)
,HEXTORAW('891CDD51EC28D3D698163494213F4A3C') -- instance_efficiency, cpuusage_pt                               ---> Efficiency, CPU Usage (per transaction)
,HEXTORAW('8ACC57E04CCF57B8AFD1B60D71610D68') -- instance_efficiency, cpu_time_pct                              ---> Efficiency, Database CPU Time (%)
,HEXTORAW('80C71A19C43300F8D661628E99458627') -- db_inst_pga_alloc, total_pga_allocated                         ---> PGA Allocated, Total PGA Allocated (MB)
,HEXTORAW('3F2BBE6BF105C0D16A3710F2868B8399') -- Recovery_Area, Free_Space                                      ---> Recovery Area, Recovery Area Used Space (%)
,HEXTORAW('BE99716C462B6C3CB41A3E2D31D76352') -- Recovery_Area, Free_Space                                      ---> Recovery Area, Recovery Area Used Space (%)
,HEXTORAW('4BBDD79DF1EB13CC8D9B991E8D2885F8') -- memory_usage_sga_pga, pga_total                                ---> SGA and PGA usage, PGA Total(MB)
,HEXTORAW('0DD82DEF4D7B007FB0D5492E417A7C26') -- memory_usage_sga_pga, sga_total                                ---> SGA and PGA usage, SGA Size(MB)
,HEXTORAW('546FB5359968978840BF76FB914103C6') -- instance_throughput, avg_active_sessions                       ---> Throughput, Average Active Sessions
,HEXTORAW('CE8BE655B9DC0FD5E9C55416E06ED1AD') -- instance_throughput, logons_ps                                 ---> Throughput, Cumulative Logons (per second)
,HEXTORAW('90314E5F76C762115BA28B9D2EE831D5') -- instance_throughput, dbblkchanges_ps                           ---> Throughput, Database Block Changes (per second)
,HEXTORAW('CEB598CB984F23F5673CBC467FE99106') -- instance_throughput, executions_ps                             ---> Throughput, Executes (per second)
,HEXTORAW('DB1E7076108F6D5898B69F2AD2EDA216') -- instance_throughput, iombs_ps                                  ---> Throughput, I/O Megabytes (per second)
,HEXTORAW('3BD01E2C561E474056EB892AD509760F') -- instance_throughput, iorequests_ps                             ---> Throughput, I/O Requests (per second)
,HEXTORAW('05568685900528A6895E97C600F58BC1') -- instance_throughput, physreads_ps                              ---> Throughput, Physical Reads (per second)
,HEXTORAW('7B7BCE1FDF5AAA47353E23D353F481C2') -- instance_throughput, physreadsdir_ps                           ---> Throughput, Physical Reads Direct (per second)
,HEXTORAW('247ED26590C1FBA8D5839A42591F0817') -- instance_throughput, physwrites_ps                             ---> Throughput, Physical Writes (per second)
,HEXTORAW('5979D44A974B15934320D968DA383166') -- instance_throughput, physwritesdir_ps                          ---> Throughput, Physical Writes Direct (per second)
,HEXTORAW('92E8D8F89CF159497C2ED6E59F375ED4') -- instance_throughput, redowrites_ps                             ---> Throughput, Redo Writes (per second)
,HEXTORAW('F3535548360FCE04402F0E8CD18CF028') -- instance_throughput, logreads_ps                               ---> Throughput, Session Logical Reads (per second)
,HEXTORAW('CADFA1BF3907CA34D1CD1DE4D3E46B9B') -- wait_bottlenecks, avg_user_cpu_time_pct                        ---> Wait Bottlenecks, Average Instance CPU (%)
,HEXTORAW('4E348CC3AD5420549A3CF704FA4B2436') -- wait_bottlenecks, host_cpu_usage_pct                           ---> Wait Bottlenecks, Host CPU Utilization (%)
);