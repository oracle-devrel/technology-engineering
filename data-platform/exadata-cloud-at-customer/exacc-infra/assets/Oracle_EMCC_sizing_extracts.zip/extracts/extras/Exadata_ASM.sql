WITH clusters AS
(
SELECT DISTINCT
       d.assoc_target_name  AS dbmachine
      ,d.assoc_target_type  AS dbmachine_target_type
      ,c.assoc_target_name  AS osm_cluster
      ,c.assoc_target_type  AS osm_cluster_type
FROM   sysman.mgmt$target_associations c
      ,sysman.mgmt$target_associations d
WHERE  c.assoc_target_type     = 'osm_cluster'
AND    d.source_target_type    = c.source_target_type
AND    d.source_target_name    = c.source_target_name
AND    d.source_target_type   IN ('oracle_database', 'rac_database')
AND    d.assoc_target_type     = 'oracle_dbmachine'
)
SELECT   c.dbmachine
        ,c.osm_cluster
        ,m.metric_label
        ,m.column_label
        ,m.key_value2       AS db
        ,m.key_value        AS data_group
        ,TO_NUMBER(m.value) / (1024 * 1024 * 1024) AS value_as_gb
FROM     sysman.mgmt$metric_current m
        ,clusters                   c
WHERE    m.column_label = 'Total Bytes'
AND      m.metric_label = 'Database Disk Group Usage'
AND      m.target_name =  c.osm_cluster
ORDER BY c.dbmachine, c.osm_cluster, m.key_value2, m.key_value;



WITH clusters AS
(
SELECT DISTINCT
       d.assoc_target_name  AS dbmachine
      ,d.assoc_target_type  AS dbmachine_target_type
      ,c.assoc_target_name  AS osm_cluster
      ,c.assoc_target_type  AS osm_cluster_type
FROM   sysman.mgmt$target_associations c
      ,sysman.mgmt$target_associations d
WHERE  c.assoc_target_type     = 'osm_cluster'
AND    d.source_target_type    = c.source_target_type
AND    d.source_target_name    = c.source_target_name
AND    d.source_target_type   IN ('oracle_database', 'rac_database')
AND    d.assoc_target_type     = 'oracle_dbmachine'
)
SELECT   c.dbmachine
        ,c.osm_cluster
        ,m.metric_label
        ,m.column_label
        ,m.key_value        AS data_group
        ,TO_NUMBER(m.value) AS value_as_num
FROM     sysman.mgmt$metric_current m
        ,clusters                   c
WHERE    m.column_label IN ('Size (MB)', 'Used % of Safely Usable', 'Disk Group Free (MB)', 'Disk Group Usable Free (MB)', 'Disk Group Usable (MB)', 'Disk Group Used %')
AND      m.metric_label = 'Disk Group Usage'
AND      m.target_name =  c.osm_cluster
ORDER BY c.dbmachine, c.osm_cluster, m.key_value;