rem
rem Version 1.1
rem

rem Version History
rem
rem 2020-11-05    1.1  tmf     First version
rem

SELECT guid
FROM
(
SELECT   DISTINCT
         ',HEXTORAW(''' || a.metric_guid || ''') -- ' || a.metric_label || ', ' || a.column_label AS guid
        ,a.metric_label, a.column_label
FROM     sysman.mgmt$target_type a
WHERE    a.metric_label IN (
                            'CPU Usage'
                           ,'Database Limits'
                           ,'Database Size'
                           ,'Efficiency'
                           ,'PGA Allocated'
                           ,'SGA and PGA usage'
                           ,'Throughput'
                           ,'Wait Bottlenecks'
                           )
AND      a.column_label IN (
                            'Average Total CPU Usage Per Second (CentiSecond Per Second)'
                           ,'Current Logons Count'
                           ,'Allocated Space(GB)', 'Used Space(GB)'
                           ,'CPU Usage (per second)', 'Database CPU Time (%)'
                           ,'Total PGA Allocated (MB)'
                           ,'SGA Size(MB)', 'PGA Total(MB)'
                           ,'Average Active Sessions', 'I/O Megabytes (per second)', 'I/O Requests (per second)', 'Physical Reads (per second)', 'Physical Writes (per second)'
                           ,'Average Instance CPU (%)'
                           )
AND      a.target_type  = 'oracle_pdb'
ORDER BY a.metric_label, a.column_label
);


(
 HEXTORAW('93E2A2A1BE9A31F2471A1E5A30DA9687') -- Database Size, Allocated Space(GB)
,HEXTORAW('F1EF5C6911C3254F6370054CBE04C294') -- Database Size, Used Space(GB)
)
