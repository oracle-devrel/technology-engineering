#!/bin/sh

#
# Version 1.2
#
# Version History
#
# 2020-11-19    1.2   tmf     Added NLS_LANG
# 2020-10-11    1.1   tmf     First version
#

#
# Change the following line to point to SQL*Plus -- version 12.2 or greater is preferred
#

SQLPLUS_EXE=/scratch/ctdinkel/opt/oracle/instantclient_18_3/sqlplus
EXTRACT_SQL=.
export NLS_LANG=AMERICAN_AMERICA

#
# Change the following line to point to include username, password @ connect string for EMCC Repository
#

unpwcs=sysman/"password"@'(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = omrhost)(PORT = 1521)))(LOAD_BALANCE = ON)(CONNECT_DATA = (SERVICE_NAME = omrservice)))'

#
# the following line is for debugging only
#. ./env.sh
#

# ----------------------------------------------------------------------------------------------------------------------

$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_Host_current.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_DB_current.sql
$SQLPLUS_EXE "$unpwcs" @$EXTRACT_SQL/Get_EMCC_Sizing_Metrics_PDB_current.sql
