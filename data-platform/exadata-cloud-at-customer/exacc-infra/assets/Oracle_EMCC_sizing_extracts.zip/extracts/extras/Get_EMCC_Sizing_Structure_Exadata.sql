rem
rem Version 1.1
define __version__ = 1.1
rem

rem Version History
rem
rem 2021-03-02    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting Exadata structure...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_exadata.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_exadata.csv

prompt "extract_version"-
,"dbmachine","dbmachine_type_version","dbmachine_type","dbmachine_owner"-
,"grid","grid_type_version","grid_type","grid_last_load_time_utc"-
,"exadata","exadata_type_version","exadata_type","exadata_type_qualifier1","exadata_type_qualifier2","exadata_last_load_time_utc"-
,"dbmachine_target_guid","grid_target_guid","exadata_target_guid"-
,"exadata_num","dbmachine_exadata_rn","grid_exadata_rn","dbmachine_exadata_count"-
,"extract_dttm_utc"

SELECT '&__version__'                                                                                                         AS extract_version
      ,t.*
      ,RANK()                                                 OVER (                                      ORDER BY t.exadata) AS exadata_num
      ,ROW_NUMBER()                                           OVER (PARTITION BY t.dbmachine_target_guid  ORDER BY t.exadata) AS dbmachine_exadata_rn
      ,ROW_NUMBER()                                           OVER (PARTITION BY t.grid_target_guid       ORDER BY t.exadata) AS grid_exadata_rn
      ,COUNT(1)                                               OVER (PARTITION BY t.dbmachine_target_guid)                     AS dbmachine_exadata_count
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')                                                        AS extract_dttm_utc
FROM
(
WITH grid AS
(
SELECT x.target_guid  AS dbmachine_target_guid
      ,x.target_name  AS dbmachine
      ,x.target_type  AS dbmachine_type
      ,x.type_version AS dbmachine_type_version
      ,x.owner        AS dbmachine_owner
      ,t.target_guid  AS grid_target_guid
      ,t.target_name  AS grid
      ,t.type_version AS grid_type_version
FROM   sysman.mgmt$target              x
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  i.source_target_name      = x.target_name (+)
AND    i.source_target_type      = x.target_type (+)
AND    i.association_type   (+)  = 'contains'
AND    i.source_target_type (+) IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
AND    t.target_name             = i.assoc_target_name (+)
AND    t.target_type             = i.assoc_target_type (+)
AND    t.target_type             = 'oracle_exadata_grid'
)
,exadata AS
(
SELECT x.target_guid        AS grid_target_guid
      ,x.target_name        AS grid
      ,x.target_type        AS grid_type
      ,x.type_version       AS grid_type_version
      ,x.last_load_time_utc AS grid_last_load_time_utc
      ,t.target_guid        AS exadata_target_guid
      ,t.target_name        AS exadata
      ,t.target_type        AS exadata_type
      ,t.type_version       AS exadata_type_version
      ,t.type_qualifier1    AS exadata_type_qualifier1
      ,t.type_qualifier2    AS exadata_type_qualifier2
      ,t.last_load_time_utc AS exadata_last_load_time_utc
FROM   sysman.mgmt$target              x
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              t
WHERE  i.source_target_name     = x.target_name (+)
AND    i.source_target_type     = x.target_type (+)
AND    i.association_type   (+) = 'contains'
AND    i.source_target_type (+) = 'oracle_exadata_grid'
AND    t.target_name            = i.assoc_target_name (+)
AND    t.target_type            = i.assoc_target_type (+)
AND    t.target_type            = 'oracle_exadata'
)
SELECT g.dbmachine
      ,g.dbmachine_type_version
      ,g.dbmachine_type
      ,g.dbmachine_owner
      ,x.grid
      ,x.grid_type_version
      ,x.grid_type
      ,TO_CHAR(x.grid_last_load_time_utc,   'YYYY-MM-DD HH24:MI:SS') AS grid_last_load_time_utc
      ,x.exadata
      ,x.exadata_type_version
      ,x.exadata_type
      ,x.exadata_type_qualifier1
      ,x.exadata_type_qualifier2
      ,TO_CHAR(x.exadata_last_load_time_utc, 'YYYY-MM-DD HH24:MI:SS') AS exadata_last_load_time_utc
      ,RAWTOHEX(g.dbmachine_target_guid) AS dbmachine_target_guid
      ,RAWTOHEX(x.grid_target_guid)      AS grid_target_guid
      ,RAWTOHEX(x.exadata_target_guid)   AS exadata_target_guid
FROM   grid    g
      ,exadata x
WHERE  x.grid_target_guid = g.grid_target_guid (+)
) t;

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_exadata.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
