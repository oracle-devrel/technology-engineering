#-------------------------------------------------------------------------------
# Example Script
#
# Wrapper for running the awr_miner.sql script.
# It looks for Oracle DBs running under the current user account, then searches
# for the ORACLE_HOME in /proc or /etc/oratab and, if found, executes the
# awr_miner.sql SQL script using the SQL*Plus command.
#
# Tested on Linux and written to be compatible with BASH, KSH93 and ZSH
#
#-------------------------------------------------------------------------------
# DISCLAIMER:
# 
# Although this program has been tested and used successfully, it is not
# supported by Oracle Support Services.
#
# It has been tested internally, and works as documented, however, we do not
# guarantee that it will work for you, so be sure to test it in your test
# environment before relying on it.  
#
# We do not claim any responsibility for any problems and/or damage caused by
# this program. This program comes "as is", please use it at your own risk.
#
# Due to the differences in the way text editors, e-mail programs and operating
# systems handle text formatting (spaces, tabs and carriage returns), proofread
# this script before execution.
#-------------------------------------------------------------------------------
DefaultPath=/usr/bin:/bin:/usr/local/bin
export PATH=${DefaultPath}

if [[ -n ${ZSH_VERSION} ]]
then
	emulate -L ksh
fi

# Time stamp for output directory
ExecTime=$(date +'%Y%m%d-%H%M%S')

#-------------------------------------------------------------------------------
# Use the ps command to get the list of Running DBs for this User
#-------------------------------------------------------------------------------
I=0
while read Line
do
	set -- ${Line}
	(( I = I + 1 ))
	Cmd=${3}
	SidName[${I}]=${Cmd#ora_pmon_*}
	Pid=${2}
	if [[ -f /proc/${Pid}/environ ]]
	then
		SidHome[${I}]=$(cat /proc/${Pid}/environ 2>/dev/null | tr '\0' '\n' \
			| grep "^ORACLE_HOME=" | sed -e 's/ORACLE_HOME=//')
	elif [[ -f /etc/oratab ]]
	then
		Result=$(grep "^${SidName[${I}]}:" /etc/oratab 2>/dev/null)
		if [[ -n ${Result} ]]
		then
			Result=${Result#*:}
			SidHome[${I}]=${Result%%:*}
		fi
	fi
done < <(ps -u $(id -un) -ouser,pid,cmd 2>/dev/null | grep " ora_pmon_" | grep -v grep)

# If no Databases found exit
if (( ${I} == 0 ))
then
	echo "WARNING: No Databases found with ORACLE OWNER = $(id -un)" >&2
	exit
else
	SidCnt=${I}
fi

# Create a unique output directory to hold the .out files
CurDir=$(pwd)
mkdir awr_miner_out_${ExecTime}
cd awr_miner_out_${ExecTime}
OutDir=$(pwd)

#-------------------------------------------------------------------------------
# For each ORACLE_SID see if we found the ORACLE_HOME, if so setup the env and
# Run the SQL Script.
#-------------------------------------------------------------------------------
I=0
while (( ${I} < ${SidCnt} ))
do
	(( I = I + 1 ))

	if [[ -n ${SidHome[${I}]} ]]
	then
		export ORACLE_SID=${SidName[${I}]}
		export ORACLE_HOME=${SidHome[${I}]}
		export PATH=${DefaultPath}:${ORACLE_HOME}/bin
		${ORACLE_HOME}/bin/sqlplus / as sysdba @../awr_miner.sql
	else
		echo;echo;echo
		echo "ERROR: ORACLE_HOME for ORACLE_SID Not Found: \"${SidName[${I}]}\"" >&2
		echo "       Try adding ORACLE_SID to ORATAB file: \"/etc/oratab\"" >&2
		echo;echo;echo
	fi
done

# List out the Output Directory and Files
cd ${CurDir}
echo;echo;echo
echo "Output files located in: ${OutDir}"
ls -ld awr_miner_out_${ExecTime}/*
echo
