rem
rem Version 1.10
define __version__ = 1.10
rem

rem Version History
rem
rem 2021-03-16    1.10  tmf     Added oracle_pdb in sample where clause
rem 2021-02-08    1.9   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.8   tmf     Added timing off
rem 2020-11-19    1.7   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.6   tmf     mkdir -p
rem 2020-10-11    1.5   tmf     Re-factored query & added processes metrics
rem 2020-04-18    1.4   tmf     Added timing capture
rem 2020-03-09    1.3   tmf     Changed output filename
rem 2020-03-06    1.2   tmf     Added PDBs & changed output filenames
rem 2020-03-05    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting target availability...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_availability_history.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_availability_history.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","OWNER","START_TIMESTAMP_UTC","END_TIMESTAMP_UTC","AVAILABILITY_STATUS"

WITH targets AS
(
SELECT /*+ MATERIALIZE */
       d.target_guid
      ,d.target_name
      ,d.target_type
      ,d.owner
      ,d.timezone_region
FROM   sysman.mgmt$target d
WHERE  d.target_type IN ('oracle_database', 'oracle_pdb', 'rac_database')
UNION
SELECT h.target_guid
      ,h.target_name
      ,h.target_type
      ,h.owner
      ,h.timezone_region
FROM   sysman.mgmt$target h
WHERE  h.target_name IN (
                         SELECT host_name
                         FROM   sysman.mgmt$target
                         WHERE  target_type = 'oracle_database'
                         UNION
                         SELECT member_target_name
                         FROM   sysman.mgmt$target_flat_members
                         WHERE  member_target_type     = 'host'
                         AND    aggregate_target_type IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
                       )
)
SELECT  RAWTOHEX(t.target_guid) AS target_guid
       ,t.target_name
       ,t.target_type
       ,t.owner
       ,TO_CHAR(CAST(FROM_TZ(CAST(h.start_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS start_timestamp_utc
       ,TO_CHAR(CAST(FROM_TZ(CAST(h.end_timestamp   AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS end_timestamp_utc
       ,h.availability_status
FROM   sysman.mgmt$availability_history h
      ,targets                          t
WHERE  t.target_guid = h.target_guid (+)
/*
 AND   h.target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type    IN ('oracle_database', 'oracle_pdb', 'rac_database')
 AND    aggregate_target_name IN
(
 'DB Machine m1.us.oracle.com'
,'DB Machine m2.us.oracle.com'
)
)
*/;

spool off

spool emcc_sizing_extracts/emcc_sizing_availability_history.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
