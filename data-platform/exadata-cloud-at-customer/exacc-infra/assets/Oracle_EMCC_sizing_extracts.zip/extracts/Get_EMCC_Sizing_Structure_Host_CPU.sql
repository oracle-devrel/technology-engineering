rem
rem Version 1.6
define __version__ = 1.6
rem

rem Version History
rem
rem 2021-02-08    1.6   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.5   tmf     Added timing off
rem 2020-11-19    1.4   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.3   tmf     mkdir -p
rem 2020-10-11    1.2   tmf     Re-factored query
rem 2020-09-13    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting host CPU details...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_host_cpu.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_host_cpu.csv

prompt "target_guid","target_name","vendor_name","freq_in_mhz","ecache_in_mb","impl","revision","num_cores","is_hyperthread_enabled"-
,"siblings","last_collection_timestamp_utc","extract_dttm_utc"

var rc REFCURSOR

DECLARE

  v_cnt PLS_INTEGER;

BEGIN

  SELECT COUNT(1)
  INTO   v_cnt
  FROM   all_views
  WHERE  view_name = 'MGMT$HW_CPU_DETAILS'
  AND    owner     = 'SYSMAN';

  IF v_cnt = 0 THEN
    OPEN :rc
    FOR
'SELECT 1 FROM sys.DUAL WHERE 1 = 0';

  ELSE
    OPEN :rc
    FOR
'SELECT target_guid
       ,target_name
       ,vendor_name
       ,freq_in_mhz
       ,ecache_in_mb
       ,impl
       ,revision
       ,num_cores
       ,is_hyperthread_enabled
       ,siblings
       ,last_collection_timestamp_utc
       ,extract_dttm_utc
FROM
(
SELECT RAWTOHEX(hw.target_guid) AS target_guid
      ,hw.target_name
      ,vendor_name
      ,freq_in_mhz
      ,ecache_in_mb
      ,impl
      ,revision
      ,num_cores
      ,is_hyperthread_enabled
      ,siblings
      ,TO_CHAR(CAST(FROM_TZ(CAST(hw.last_collection_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE ''UTC'' AS DATE), ''YYYY-MM-DD HH24:MI:SS'') AS last_collection_timestamp_utc
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), ''YYYY-MM-DD HH24:MI:SS'') AS extract_dttm_utc
      ,ROW_NUMBER() OVER(PARTITION BY hw.target_guid ORDER BY hw.last_collection_timestamp DESC, hw.freq_in_mhz DESC) AS rn
FROM   sysman.mgmt$target         t
      ,sysman.mgmt$hw_cpu_details hw
WHERE  hw.target_guid = t.target_guid
AND    hw.target_name IN (
                          SELECT host_name
                          FROM   sysman.mgmt$target
                          WHERE  target_type = ''oracle_database''
                          UNION
                          SELECT member_target_name
                          FROM   sysman.mgmt$target_flat_members
                          WHERE  member_target_type     = ''host''
                          AND    aggregate_target_type IN (''oracle_exadata_cloud_service'', ''oracle_dbmachine'')
                         )
/*
 AND   hw.target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type     = ''host''
 AND    aggregate_target_name IN
(
 ''DB Machine m1.us.oracle.com''
,''DB Machine m2.us.oracle.com''
)
)
*/
)
WHERE rn = 1';

  END IF;

END;
/

print rc

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_host_cpu.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
