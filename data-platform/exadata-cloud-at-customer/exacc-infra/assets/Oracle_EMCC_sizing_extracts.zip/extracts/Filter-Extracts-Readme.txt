Filter Extracts Readme
================================================================================
Source Side Filtering adds the ability to filter the Enterprise Manager data 
before it is sent to Oracle for review and processing.

It runs as a post processing step following the normal EMCC Extract and creates 
a new set of files containing data for only those targets that have not been 
selected for exclusion in the filter file.

This Readme provides a brief overview on the steps to run this, please see the 
"EMCC-Extracts-Guide.pdf" in this same directory for more detailed steps.

Prerequisites
================================================================================
- Desktop or system with Python2 (2.7.18) or Python3 (3.6 or higher) installed.
- EMCC Repository extract files in the "emcc_sizing_extracts" directory.

Run the Filtering Script
================================================================================
1. Open a terminal window and change directory to the "extracts" directory that 
   contains the "emcc_sizing_extracts" directory and "Filter_Extracts.py" file.

2. Run the Python script with the create-filter option to create the CSV filter 
   file:

      python Filter_Extracts.py --create-filter

3. Since the filter file is CSV file, open it with a spreadsheet tool such as 
   Microsoft Excel or LibreOffice Calc, once opened, you will need to add a 
   "Yes" in column A (Exclude) for those databases you wish to excluded from 
   the results sent back to Oracle.

4. After the filter file is updated save and close it then return to the 
   terminal window and run the Python script with the filter option:

      python Filter_Extracts.py --filter

5. The filtered results will be placed in the "emcc_sizing_extracts_filtered"
   directory, so you will need to use zip or tar to bundle up the directory
   and send it to Oracle using the information provided by your Oracle contact.