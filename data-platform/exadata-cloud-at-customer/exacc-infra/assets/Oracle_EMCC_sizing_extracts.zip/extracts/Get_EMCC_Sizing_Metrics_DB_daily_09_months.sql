rem
rem Version 1.14
define __version__ = 1.14
rem

rem Version History
rem
rem 2021-02-08    1.14  tmf     Removed -p to be Windows friendly
rem 2021-01-27    1.13  tmf     Added example of running for a limited set of database targets
rem 2020-12-15    1.12  tmf     Added timing off
rem 2020-11-19    1.11  tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.10  tmf     Re-factored query to include metric GUIDs
rem 2020-10-13    1.9   tmf     Fixed bug in extraction filter
rem 2020-10-11    1.8   tmf     Re-factored query
rem 2020-08-18    1.7   tmf     Added sample filter by dbmachine
rem 2020-08-13    1.6   tmf     Added capture of logons
rem 2020-04-18    1.5   tmf     Added timing capture
rem 2020-03-26    1.4   tmf     Added allocated database size
rem 2020-03-23    1.3   tmf     Changed extracts to interval based extracts
rem 2020-03-22    1.2   tmf     Added more specific extract header
rem 2020-03-20    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting DB daily metrics 06 to 09 months...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_metrics_db_daily_09_months.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_metrics_db_daily_09_months.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","METRIC_LABEL","COLUMN_LABEL","METRIC_NAME","METRIC_COLUMN","ROLLUP_TIMESTAMP_UTC","MINIMUM","MAXIMUM","AVERAGE","STANDARD_DEVIATION","SAMPLE_COUNT"

WITH t AS
(
 SELECT /*+ MATERIALIZE */
        target_guid, timezone_region
 FROM   sysman.mgmt$target
 WHERE  target_type IN ('oracle_database', 'rac_database')
/*
 AND    target_name IN (
 SELECT member_target_name
 FROM   sysman.mgmt$target_flat_members
 WHERE  member_target_type    IN ('oracle_database', 'rac_database')
 AND    aggregate_target_name IN
(
 'DB Machine m1.us.oracle.com'
,'DB Machine m2.us.oracle.com'
)
)
*/
)
SELECT RAWTOHEX(a.target_guid) AS target_guid
      ,a.target_name
      ,a.target_type
      ,a.metric_label
      ,a.column_label
      ,a.metric_name
      ,a.metric_column
      ,TO_CHAR(CAST(FROM_TZ(CAST(a.rollup_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS rollup_timestamp_utc
      ,NVL(a.minimum,            0)              AS minimum
      ,NVL(a.maximum,            0)              AS maximum
      ,NVL(a.average,            0)              AS average
      ,NVL(a.standard_deviation, 0)              AS standard_deviation
      ,NVL(a.sample_count,       0)              AS sample_count
FROM   t, sysman.mgmt$metric_daily a
WHERE  a.rollup_timestamp >= ADD_MONTHS(SYSDATE, -9)
AND    a.rollup_timestamp  < ADD_MONTHS(SYSDATE, -6)
AND    a.target_guid       = t.target_guid
AND    a.metric_guid      IN
(
 HEXTORAW('AB9CAF80590230CCA321554A36A83E56') -- CPU Usage, Average Total CPU Usage Per Second (CentiSecond Per Second)
,HEXTORAW('A65657E22E8376569DA71AE298EE9997') -- Database Limits, Current Logons Count
,HEXTORAW('47D47BEF38343C9A32A4EF81D122BA04') -- Database Size, Allocated Space(GB)
,HEXTORAW('DC498CC90B549E44367920908A1B15DE') -- Database Size, Allocated Space(GB)
,HEXTORAW('AA4F1CD67A3FD2375435D89676EFF935') -- Database Size, Used Space(GB)
,HEXTORAW('CAAFBF5E0ABD56B72E23B9354135DA6A') -- Database Size, Used Space(GB)
,HEXTORAW('B8298BEF177C1C2B0F40C01DA6BF78DA') -- Efficiency, CPU Usage (per second)
,HEXTORAW('8ACC57E04CCF57B8AFD1B60D71610D68') -- Efficiency, Database CPU Time (%)"
,HEXTORAW('80C71A19C43300F8D661628E99458627') -- PGA Allocated, Total PGA Allocated (MB)
,HEXTORAW('4BBDD79DF1EB13CC8D9B991E8D2885F8') -- SGA and PGA usage, PGA Total(MB)
,HEXTORAW('0DD82DEF4D7B007FB0D5492E417A7C26') -- SGA and PGA usage, SGA Size(MB)
,HEXTORAW('546FB5359968978840BF76FB914103C6') -- Throughput, Average Active Sessions
,HEXTORAW('DB1E7076108F6D5898B69F2AD2EDA216') -- Throughput, I/O Megabytes (per second)
,HEXTORAW('3BD01E2C561E474056EB892AD509760F') -- Throughput, I/O Requests (per second)
,HEXTORAW('05568685900528A6895E97C600F58BC1') -- Throughput, Physical Reads (per second)
,HEXTORAW('247ED26590C1FBA8D5839A42591F0817') -- Throughput, Physical Writes (per second)
,HEXTORAW('CADFA1BF3907CA34D1CD1DE4D3E46B9B') -- Wait Bottlenecks, Average Instance CPU (%)
,HEXTORAW('2A6F5C26DFD1AC678EAE7E1AFDD63834') -- Flash_Cache_IORM_PDB_Metric, pdb_fc_by_allocated (MB)
,HEXTORAW('E577644CB99554603A192471AA9F8B0A') -- Flash_Cache_IORM_DB_Metric, db_fc_by_allocated (MB)
);

spool off

spool emcc_sizing_extracts/emcc_sizing_metrics_db_daily_09_months.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit

rem
rem The following is an example that limits database metrics to a list of oracle_database and rac_database targets;
rem   oracle_database children are derived for rac_database targets
rem

WITH dbs AS
(
SELECT /*+ MATERIALIZE */
       target_guid, target_name, target_type, timezone_region
FROM   sysman.mgmt$target
WHERE  target_type IN ('oracle_database', 'rac_database')
AND    target_name IN
(
 'oracle_database1'
,'oracle_database2'
,'rac_database1'
,'rac_database2'
)
)
,t AS
(
SELECT target_guid, target_name, target_type, timezone_region
FROM   dbs
UNION
SELECT m.member_target_guid, m.member_target_name, m.member_target_type, i.timezone_region
FROM   sysman.mgmt$target              i
      ,sysman.mgmt$target_flat_members m
WHERE  m.member_target_guid     = i.target_guid
AND    m.member_target_type     = 'oracle_database'
AND    m.aggregate_target_name IN
(
 SELECT target_name FROM dbs
)
UNION
SELECT m.aggregate_target_guid, m.aggregate_target_name, m.aggregate_target_type, i.timezone_region
FROM   sysman.mgmt$target              i
      ,sysman.mgmt$target_flat_members m
WHERE  m.aggregate_target_guid  = i.target_guid
AND    m.aggregate_target_type  = 'rac_database'
AND    m.member_target_name    IN
(
 SELECT target_name FROM dbs
)
)
SELECT RAWTOHEX(a.target_guid) AS target_guid
      ,a.target_name
      ,a.target_type
      ,a.metric_label
      ,a.column_label
      ,a.metric_name
      ,a.metric_column
      ,TO_CHAR(CAST(FROM_TZ(CAST(a.rollup_timestamp AS TIMESTAMP), t.timezone_region) AT TIME ZONE 'UTC' AS DATE), 'YYYY-MM-DD HH24:MI:SS') AS rollup_timestamp_utc
      ,NVL(a.minimum,            0)              AS minimum
      ,NVL(a.maximum,            0)              AS maximum
      ,NVL(a.average,            0)              AS average
      ,NVL(a.standard_deviation, 0)              AS standard_deviation
      ,NVL(a.sample_count,       0)              AS sample_count
FROM   t, sysman.mgmt$metric_daily a
WHERE  a.rollup_timestamp >= ADD_MONTHS(SYSDATE, -9)
AND    a.rollup_timestamp  < ADD_MONTHS(SYSDATE, -6)
AND    a.target_guid       = t.target_guid
AND    a.metric_guid      IN
(
 HEXTORAW('AB9CAF80590230CCA321554A36A83E56') -- CPU Usage, Average Total CPU Usage Per Second (CentiSecond Per Second)
,HEXTORAW('A65657E22E8376569DA71AE298EE9997') -- Database Limits, Current Logons Count
,HEXTORAW('47D47BEF38343C9A32A4EF81D122BA04') -- Database Size, Allocated Space(GB)
,HEXTORAW('DC498CC90B549E44367920908A1B15DE') -- Database Size, Allocated Space(GB)
,HEXTORAW('AA4F1CD67A3FD2375435D89676EFF935') -- Database Size, Used Space(GB)
,HEXTORAW('CAAFBF5E0ABD56B72E23B9354135DA6A') -- Database Size, Used Space(GB)
,HEXTORAW('B8298BEF177C1C2B0F40C01DA6BF78DA') -- Efficiency, CPU Usage (per second)
,HEXTORAW('8ACC57E04CCF57B8AFD1B60D71610D68') -- Efficiency, Database CPU Time (%)"
,HEXTORAW('80C71A19C43300F8D661628E99458627') -- PGA Allocated, Total PGA Allocated (MB)
,HEXTORAW('4BBDD79DF1EB13CC8D9B991E8D2885F8') -- SGA and PGA usage, PGA Total(MB)
,HEXTORAW('0DD82DEF4D7B007FB0D5492E417A7C26') -- SGA and PGA usage, SGA Size(MB)
,HEXTORAW('546FB5359968978840BF76FB914103C6') -- Throughput, Average Active Sessions
,HEXTORAW('DB1E7076108F6D5898B69F2AD2EDA216') -- Throughput, I/O Megabytes (per second)
,HEXTORAW('3BD01E2C561E474056EB892AD509760F') -- Throughput, I/O Requests (per second)
,HEXTORAW('05568685900528A6895E97C600F58BC1') -- Throughput, Physical Reads (per second)
,HEXTORAW('247ED26590C1FBA8D5839A42591F0817') -- Throughput, Physical Writes (per second)
,HEXTORAW('CADFA1BF3907CA34D1CD1DE4D3E46B9B') -- Wait Bottlenecks, Average Instance CPU (%)
);
