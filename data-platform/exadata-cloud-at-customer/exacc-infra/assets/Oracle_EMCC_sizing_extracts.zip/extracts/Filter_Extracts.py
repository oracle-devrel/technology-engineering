__version__ = '2.1'

#
# Version History
#
# 2023-08-03    2.1  pro     Remove newline param in open function for python2 compatiblity
# 2023-04-14    2.0  pro     Fix emcc_sizing_structure_db_dr.csv filtering
# 2022-02-02    1.9  pro     Add emcc_sizing_em_jobs.csv and emcc_sizing_em_metrics.csv to filter
# 2022-10-13    1.8  pro     Add Machine Architecture column to filter file
# 2022-09-21    1.7  pro     Add special handling for emcc_sizing_availability_history.csv
# 2022-09-13    1.6  pro     Fix input file on process_db_infrastructure def
# 2022-09-07    1.5  pro     Rename 'Filter' column to 'Exclude'
# 2022-08-09    1.4  pro     Fix duplicates from get_lines_per_uid
#                            Add exclusion capability for some files
# 2022-07-19    1.3  pro     Use orderecDicts to support python 2.7
# 2022-07-15    1.2  pro     Extend values accepted in Filter column
# 2022-06-29    1.1  pro     Keep quotes on csv lines read
# 2022-06-29    1.0  pro     Initial version

import argparse
import csv
import itertools
import os
import sys
import time
import errno
import platform
from collections import OrderedDict

# Global objects used by function
log_data = []
debug_data = []

TROUBLESHOOT_MODE = False
DEV_MODE = False
DEBUG_ROWS = 20

DEBUG = True if 'EMCC_SIZING_FILTER_DEBUG' in os.environ and os.environ['EMCC_SIZING_FILTER_DEBUG'].upper() == 'Y' else False
ROOT_DIR = os.environ['EMCC_SIZING_EXTRACTFILES_ROOT_DIR'] if 'EMCC_SIZING_EXTRACTFILES_ROOT_DIR' in os.environ else '.'
FILTER_DIR_NAME = "emcc_sizing_extracts_filtered"
EXTRACTS_DIR_NAME = "emcc_sizing_extracts"

# Directory paths
if ROOT_DIR == ".":
    ROOT_DIR_FULL_PATH = os.path.abspath(os.getcwd())
elif os.path.exists(ROOT_DIR) and os.path.isdir(ROOT_DIR):
    ROOT_DIR_FULL_PATH = ROOT_DIR

EXTRACT_DIR_PATH = ROOT_DIR_FULL_PATH + os.sep + EXTRACTS_DIR_NAME
OUTPUT_DIR_PATH = ROOT_DIR_FULL_PATH + os.sep + FILTER_DIR_NAME

# File names
FILTER_FILE_NAME = "properties_database_filter.csv"
DB_STRUCTURE_FILE_NAME = "emcc_sizing_structure_db.csv"
DB_PROPS_FILE_NAME = "emcc_sizing_structure_db_props.csv"

# File paths
DB_STRUCTURE_FILE_PATH = EXTRACT_DIR_PATH + os.sep + DB_STRUCTURE_FILE_NAME
DB_PROPS_FILE_PATH = EXTRACT_DIR_PATH + os.sep + DB_PROPS_FILE_NAME
FILTER_FILE_PATH = OUTPUT_DIR_PATH + os.sep + FILTER_FILE_NAME

# Columns fetched from db structure file
DB_STRUCTURE_COLS = [
    "dbmachine",
    "dbmachine_owner",
    "cdb",
    "cdb_owner",
    'cdb_standby_type',
    'cdb_status',
    'cdb_last_load_time_utc',
    "ma",
    "dbmachine_target_guid",
    "cdb_target_guid",
    "db_target_guid",
    "host_target_guid",
    "host",
    "clustered",
    "cluster"
]

# Columns fetched from db properties file
DB_PROPS_COLS = [
    "TARGET_GUID",
    "NAME",
    "VALUE"
]

# Property names as appearing in db properties file
DB_PROPS_NAMES = [
    "orcl_gtp_cost_center",
    "orcl_gtp_department",
    "orcl_gtp_lifecycle_status",
    "orcl_gtp_line_of_bus",
    "orcl_gtp_location",
    "Version"
]

# Column to create in the filter file
FILTER_FILE_OUTPUT_COLUMNS = [
    "Exclude",
    "Database Name",
    "dbmachine",
    "dbmachine_owner",
    "cluster",
    "Server List",
    "cdb_version",
    "cdb_status",
    "cdb_last_load_time_utc",
    "ma",
    "cdb_owner",
    "cdb_standby_type",
    "cdb_cost_center",
    "cdb_department",
    "cdb_lifecycle_status",
    "cdb_line_of_bus",
    "cdb_location",
    "target_guid",
    "Database List",
    "Host List",
    "dbmachine_target_guid"
]

# Columns from the filter file to be used to filter the records
FILTER_EXTRACTS_BY_COLUMNS = [
    "target_guid",
    "Database List",
    "Host List",
    "dbmachine_target_guid"  # Add this guid to filter on emcc_sizing_structure_db_vm.csv
]

# EMCC Extract csv files
ALL_EXTRACT_CSV_FILES = [
    "emcc_sizing_availability_history.csv",
    "emcc_sizing_em_metrics.csv",
    "emcc_sizing_metrics_db_daily_03_months.csv",
    "emcc_sizing_metrics_db_daily_06_months.csv",
    "emcc_sizing_metrics_db_daily_09_months.csv",
    "emcc_sizing_metrics_db_daily_12_months.csv",
    "emcc_sizing_metrics_db_hourly_03_months.csv",
    "emcc_sizing_metrics_host_daily_03_months.csv",
    "emcc_sizing_metrics_host_daily_06_months.csv",
    "emcc_sizing_metrics_host_daily_09_months.csv",
    "emcc_sizing_metrics_host_daily_12_months.csv",
    "emcc_sizing_metrics_host_hourly_03_months.csv",
    "emcc_sizing_metrics_pdb_daily_03_months.csv",
    "emcc_sizing_metrics_pdb_daily_06_months.csv",
    "emcc_sizing_metrics_pdb_daily_09_months.csv",
    "emcc_sizing_metrics_pdb_daily_12_months.csv",
    "emcc_sizing_metrics_pdb_hourly_03_months.csv",
    "emcc_sizing_structure_db.csv",
    "emcc_sizing_structure_db_dr.csv",
    "emcc_sizing_structure_db_params.csv",
    "emcc_sizing_structure_db_props.csv",
    "emcc_sizing_structure_db_redo.csv",
    "emcc_sizing_structure_db_services.csv",
    "emcc_sizing_structure_db_sga.csv",
    "emcc_sizing_structure_db_vm.csv",
    "emcc_sizing_structure_host_cpu.csv",
    "emcc_sizing_structure_host_props.csv",
    "emcc_sizing_structure_host_vm.csv",
    "emcc_sizing_structure_pdb.csv",
    "emcc_sizing_structure_pdb_params.csv",
    "emcc_sizing_structure_pdb_props.csv",
    "emcc_sizing_structure_pdb_sga.csv",
    "emcc_sizing_structure_sm.csv",
    "emcc_sizing_structure_vp2.csv",
    "emcc_sizing_structure_vp.csv",
    "emcc_sizing_structure_vs2.csv",
    "emcc_sizing_structure_vs.csv"
]
LONGEST_EXTRACT_CSV_FILE_NAME = max(ALL_EXTRACT_CSV_FILES, key=len)

# EMCC Extract csv files where the first column is NOT a UID
SPECIAL_FORMAT_EXTRACT_CSV_FILES = [
    "emcc_sizing_structure_db.csv",
    "emcc_sizing_structure_db_dr.csv",
    "emcc_sizing_structure_db_vm.csv",
    "emcc_sizing_structure_host_vm.csv",
    "emcc_sizing_structure_pdb.csv"
]

# List of files excluded from filtering , the whole file is extracted
DO_NOT_FILTER_FILES = ["emcc_sizing_em_jobs.csv"]

# emcc_sizing_availability_history.csv file requires special handling because contains target status
# for host,oracle-databases and rac-databases , when we filter it we should consider all the UIDs present
# in the structure files
AV_HISTORY = ["emcc_sizing_availability_history.csv"]

# EMCC Extract sub lists
DB_EXTRACT_CSV_FILES = [i for i in ALL_EXTRACT_CSV_FILES if "_db" in i]
EM_EXTRACT_CSV_FILES = [i for i in ALL_EXTRACT_CSV_FILES if "_em" in i]
HOST_EXTRACT_CSV_FILES = [i for i in ALL_EXTRACT_CSV_FILES if "_host" in i]
PDB_EXTRACT_CSV_FILES = [i for i in ALL_EXTRACT_CSV_FILES if "_pdb" in i]
OTHER_EXTRACT_CSV_FILES = [i for i in ALL_EXTRACT_CSV_FILES if "_db" not in i and "_host" not in i and "_pdb" not in i]

# List to obtain counts for files processed
EXPECTED_EXTRACT_CSV_FILES = ALL_EXTRACT_CSV_FILES + DO_NOT_FILTER_FILES
EXPECTED_EXTRACT_FILTERED_FILES = DB_EXTRACT_CSV_FILES + EM_EXTRACT_CSV_FILES + HOST_EXTRACT_CSV_FILES + AV_HISTORY + DO_NOT_FILTER_FILES
CREATED_FILTERED_FILES_COUNT = 0
NOTCREATED_FILTERED_FILES_COUNT = 0

# Debug function
def debug(txt):
    """ Writes the text passed to the debug array, if DEV_MODE is True it will write the same to stdout
    """
    if DEBUG:
        debug_data.append(txt + '\n')
        if DEV_MODE:
            print(txt)


# Give the version of the tool
def print_version():
    """ Prints the tool version.
    """
    print("Version :" + __version__)


# Write the text passed to stdout and logFile
def log(txt):
    """ Writes the text passed to stdout and log array.
    """
    print(txt)
    log_data.append(txt + "\n")


# Write the text passed to stdout as error
def log_err_to_stdout(txt):
    """ Writes the text passed to stdout as error.
    """
    print("\nERROR: " + txt + "\n")


# Write the text passed to the log array
def log_to_file(txt):
    """ Writes the text passed to log array.
    """
    log_data.append(txt + "\n")


# Check directory existance and permissions
def check_dir(d):
    """ Checks if directory exists, is a directory and readable.
    """

    if not os.path.exists(d):
        log_err_to_stdout("Directory " + d + " is missing, cannot continue")
        quit()
    elif not os.path.isdir(d):
        log_err_to_stdout("Directory " + d + " is not a directory, cannot continue")
        quit()
    elif not os.access(d, os.R_OK):
        log_err_to_stdout("Directory " + d + " is not readable, cannot continue")
        quit()


# Check file existance and permissions
def check_file(f):
    """ Checks if file exists, is a regular file and readable.
    """

    if not os.path.exists(f):
        log_err_to_stdout("File " + f + " is missing; cannot continue")
        quit()
    elif not os.path.isfile(f):
        log_err_to_stdout("File " + f + " is not a regular file, cannot continue")
        quit()
    elif not os.access(f, os.R_OK):
        log_err_to_stdout("File " + f + " is not readable, cannot continue")
        quit()


# Add value to dict respecting previous values
def add_value(dict_obj, key, value):
    """ Adds a key-value pair to the dictionary.
        If the key already exists in the dictionary, it will associate multiple values with that
        key instead of overwritting its value
    """

    if key not in dict_obj:
        dict_obj[key] = value
    elif isinstance(dict_obj[key], list):
        dict_obj[key].append(value)
    else:
        dict_obj[key] = [dict_obj[key], value]


# Create a map for a specific dict value
def create_map(map_name, source_map, key, val):
    """ Loops through the source_map and builds a map for the given key and value.
    """

    for i in source_map:
        add_value(map_name, i[key], i[val])

    debug("\n[create_map] key=" + key + " val=" + val + ":")
    for _ in map_name:
        debug(" " + _ + "->" + str(map_name[_]))


# Create a string separated by comma for a list value
def create_string_from_list(map_name, val):
    """ Creates a string separated by comma for a list type.
        If the value is a list , the list is sorted in reverse then joined by comma,
        If the value is not a list is returned untouched
    """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN create_string_from_list")
    debug(" map_name=" + str(map_name) + " val=" + val)

    if isinstance(map_name[val], list):
        # Sort the list in reverse order
        map_name[val].sort(reverse=True)
        lst = ",".join(map_name[val])
    else:
        lst = map_name[val]

    return lst


# Create a list containing all the lines of a file
def create_list_of_lines_from_file(ifil):
    """ Creates a list to store all the lines of a file.
        New line character is removed from the lines read.
    """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN create_list_of_lines_from_file")
    debug(" ifil=" + ifil)

    # Check the file
    check_file(ifil)

    # Read the lines of the file and remove new line characters
    csv_file = open(ifil, 'r')
    lines = csv_file.read().splitlines()

    # Remove double quotes from lines
    # lines = [s.replace('"', '') for s in lines]

    debug(" lines=" + str(len(lines)) + " showing only the first " + str(DEBUG_ROWS))
    for cnt, _ in enumerate(lines):
        if cnt < DEBUG_ROWS:
            debug("  [" + str(cnt) + "]" + repr(_))

    csv_file.close()
    return lines


# Get the first line of a file
def get_first_line_from_file(ifil):
    """ Gets the first line of a file, double quotes are removed from the line read.
    """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN get_first_line_from_file")
    debug(" ifil=" + ifil)

    # Check the file
    check_file(ifil)

    # Get the first line of the file
    ifil = open(ifil, 'r')
    lin = ifil.readline()

    # Remove double quotes from lin
    # lin = lin.replace('"', '')

    debug(" lin=" + lin)
    ifil.close()
    return lin


# Write csv file with dict contents
def write_csv_file_from_dict(csv_fil, csv_dict):
    """ Writes a csv file using the contents of the dict passed.
        Uses the dict keys as the header for the csv file and counts the number of rows written to the file
    """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN write_csv_file_from_dict")
    debug(" csv_fil=" + csv_fil)

    csv_hdr = csv_dict[0].keys()
    debug(" csv_hdr=" + str(csv_hdr))

    # Write the csv file
    with open(csv_fil, 'w') as csvfile:
    #with open(csv_fil, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=csv_hdr)
        writer.writeheader()
        writer.writerows(csv_dict)

    # Count the number of rows written
    count_csv_fil = open(csv_fil, 'r')
    count_rdr = csv.DictReader(count_csv_fil)
    totalrows = 0
    for row in count_rdr:
        totalrows += 1

    log("Wrote " + str(totalrows) + " lines to  " + FILTER_FILE_PATH)


# Write file with list contents
def write_file_from_list(ifil, ilist):
    """ Writes the contents of the list passed to a file , the file is created in the Output directory.
    """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN write_file_from_list")
    debug(" ifil=" + ifil)

    line_sep = '\n'

    # Set the Output file
    ofil_path = OUTPUT_DIR_PATH + os.sep + ifil
    debug(" ofil=" + ofil_path)

    # Write the file
    with open(ofil_path, 'w') as o:
        o.write(line_sep.join(ilist))

    # Count the number of rows written
    count_fil = open(ofil_path, 'r')
    totalrows = 0
    for _ in count_fil:
        totalrows += 1
    count_fil.close()

    debug(" [List Size : " + str(len(ilist)) + "] Wrote " + str(totalrows) + " lines to  " + ofil_path)


# Shows a progress bar, match count and elapsed time on stdout
def progress_bar(file, total, progress, matches, elapsed):
    """ Displays or updates a console progress bar on stdout.
        Prints the file name at the beginning of the progress bar,
        the number of matches in the file and the elapsed time at the end

        Filtering emcc_sizing_metrics_db_daily_03_months.csv    [####################] 100% [1183] [0.055]s
        """

    barlength, status = 20, ""
    progress = float(progress) / float(total)
    if progress >= 1.:
        progress, status = 1, "\r\n"
    block = int(round(barlength * progress))
    matches = "[" + matches + "]"
    matches_lgt = len(matches)

    # Calculate the number of separators per file to align the progress bar
    sep = " " * (len(LONGEST_EXTRACT_CSV_FILE_NAME) - len(file))

    # Consider hundreds of millions the max value to be presented in matches
    max_matches_string_size = 11
    matches = matches + " " * (max_matches_string_size - matches_lgt)

    # Append the elapsed time when is not empty
    if not elapsed:
        text = "\r  " + file + "{} [{}] {:.0f}% {}".format(
            sep,
            "#" * block + "-" * (barlength - block), round(progress * 100, 0),
            status)
    else:
        text = "\r  " + file + "{} [{}] {:.0f}% {} {}".format(
            sep,
            "#" * block + "-" * (barlength - block), round(progress * 100, 0),
            matches,
            elapsed + "\r\n")
    sys.stdout.write(text)
    sys.stdout.flush()


# Get elapsed time
def get_elapsed_time(t):
    """ Gets the elapsed time from the time passed.
    """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN get_elapsed_time")
    debug(" start=" + time.strftime("%H:%M:%S", time.localtime(t)))
    elapsed_secs = round(time.time() - t, 3)
    elapsed_min, elapsed_min_secs = divmod(elapsed_secs, 60)

    elapsed_min = round(elapsed_min)
    elapsed_min_secs = round(elapsed_min_secs)

    if elapsed_min > 0:
        elapsed_time = "[" + str(elapsed_secs) + "]s , " + str(elapsed_min) + "m and " + str(elapsed_min_secs) + "s"
    else:
        elapsed_time = "[" + str(elapsed_secs) + "]s"

    debug(" end=" + time.strftime("%H:%M:%S", time.localtime()))
    debug(" elapsed_time=" + elapsed_time)
    return elapsed_time


# Dumps information in the log for troubleshooting purposes
def troubleshoot(nam, lst):
    if TROUBLESHOOT_MODE:
        log_to_file("\n " + nam + "=(")
        for _ in lst:
            log_to_file("  " + "\"" + _ + "\"")
        log_to_file(")")


def create_map_of_ids_per_target_type(f):
    """ Parses properties_database_filter.csv file and build map containing all the DB and Host IDs.
        Collects the columns stated in FILTER_EXTRACTS_BY_COLUMNS list,
        Exclude the rows where column 'Exclude' has all courrences of values 'yes', 'y',
        Duplicates are dropped from the output list

        Returns a map keyed by 'db_targets' and 'host_targets' with a list of all IDs found in the file:
        { 'db_targets' : [ 8698D2D866F43302E0533E35560AE48D, C9A872134ECD95BFF3A5A52E6490906B , ... ],
          'host_targets' :  [ FD6AE03967F0D59E5215CAAA72AA57C3, 4A6C00E7D1EA6D462B710422B0467DD4 , ... ]
        }
        """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN create_map_of_ids_per_target_type")
    debug(" f=" + f)

    # Read the filter properties file
    filter_csv = open(f, 'r')
    filter_csv_hdr = [h.strip().strip('"') for h in filter_csv.readline().split(',')]
    filter_csv_reader = csv.DictReader(filter_csv, fieldnames=filter_csv_hdr)

    # Check if 'Exclude' is in the headers
    if 'Exclude' not in filter_csv_hdr:
        print("Error: The 'Exclude' column is missing from the CSV file.")
        print("Please ensure the file includes an 'Exclude' column to specify the databases to exclude.")
        exit(1)

    # Copy the DictReader to prevent being exhausted from data manipulation
    filter_reader = [i for i in filter_csv_reader]
    filter_reader_lgt = len(filter_reader)

    # Create the list of accepted values in Exclude column
    y_char_list = ['Y', 'y']
    yes_list = list(map(''.join, itertools.product(*zip("YES".upper(), "YES".lower()))))
    filter_value_list = list(itertools.chain(y_char_list, yes_list)) #This contains -> ['Y', 'y', 'YES', 'YEs', 'YeS', 'Yes', 'yES', 'yEs', 'yeS', 'yes']

    # Exclude lines based on Exclude column value
    filter_reader_without_excluded = [i for i in filter_reader if i['Exclude'] not in filter_value_list]
    filter_reader_without_excluded_lgt = len(filter_reader_without_excluded)
    excluded_count = filter_reader_lgt - filter_reader_without_excluded_lgt
    log(" Targets : Filtered[" + str(excluded_count) + "] Total[" + str(filter_reader_lgt) + "]")

    # Create a dict containing only the relevant columns from the filter file
    filter_cols = [c for c in FILTER_EXTRACTS_BY_COLUMNS if c in filter_csv_hdr]
    debug("Columns selected from csv header: " + str(filter_cols))
    filter_dict = []
    for lin in filter_reader_without_excluded:
        filter_lin_dict = OrderedDict()
        for k, v in lin.items():
            if k in FILTER_EXTRACTS_BY_COLUMNS:
                add_value(filter_lin_dict, k, v)
        filter_dict.append(filter_lin_dict)

    debug("\n[dict] filter_dict: ")
    for _ in filter_dict:
        debug(" " + str(_))

    # Create the list of ids for db and host targets
    uid_dict = OrderedDict()
    db_targets_str, host_targets_str = "", ""
    dbmachine_target_str = ","
    for rec in filter_dict:
        cdb_target_guid = rec['target_guid']
        db_target_guid = rec['Database List']
        host_target_guid = rec['Host List']
        dbmachine_target_guid = rec['dbmachine_target_guid']

        db_and_cdb_target_guid = cdb_target_guid + "," + db_target_guid
        db_targets_str += db_and_cdb_target_guid if len(db_targets_str) == 0 else "," + db_and_cdb_target_guid
        host_targets_str += host_target_guid if len(host_targets_str) == 0 else "," + host_target_guid
        dbmachine_target_str += dbmachine_target_guid if len(dbmachine_target_guid) == 0 else "," + dbmachine_target_guid

    # Deduplicate values
    db_targets_list = set(db_targets_str.split(","))
    host_targets_list = set(host_targets_str.split(","))
    dbmachine_target_list = set(dbmachine_target_str.split(","))

    # Remove empty items from the lists
    db_targets_list = list(filter(None, db_targets_list))
    host_targets_list = list(filter(None, host_targets_list))
    dbmachine_target_list = list(filter(None, dbmachine_target_list))

    # Sort the lists
    sorted_db_targets_list = sorted(db_targets_list, key=lambda x: x[0])
    debug("\n[list] sorted_db_targets_list: ")
    for i in sorted_db_targets_list:
        debug(" " + i)

    sorted_host_targets_list = sorted(host_targets_list, key=lambda z: z[0])
    debug("\n[list] sorted_host_targets_list: ")
    for j in sorted_host_targets_list:
        debug(" " + j)

    sorted_dbmachine_target_list = sorted(dbmachine_target_list, key=lambda z: z[0])
    debug("\n[list] sorted_dbmachine_target_list: ")
    for j in sorted_dbmachine_target_list:
        debug(" " + j)

    # Add the lists to the map
    uid_dict["db_targets"] = sorted_db_targets_list
    uid_dict["host_targets"] = sorted_host_targets_list
    uid_dict["dbmachine_targets"] = sorted_dbmachine_target_list

    debug("\n[dict] uid_dict: ")
    for _ in uid_dict:
        debug(" " + _ + "->" + str(uid_dict[_]))
    debug("db_targets_list_lgt=" + str(len(db_targets_list)))
    debug("host_targets_list_lgt=" + str(len(host_targets_list)))
    debug("dbmachine_target_list=" + str(len(dbmachine_target_list)))

    return uid_dict


# ============================ Specialized functions ==================================================================#
def process_db_properties(f):
    """ Parses emcc_sizing_structure_db_props.csv created by EMCC Extract.
        Get the values for the columns TARGET_GUID,NAME and VALUE,
        Add the empty values for the properties listed in DB_PROPS_NAMES list and rename
        these properties replacing the suffix orcl_gtp by the string cdb

        Return a dict keyed by the TARGET_GUID with the following values and order:

        { 869364C12ED46D39E0533C35560A858C :
            {'cdb_cost_center': '',
             'cdb_department': '',
             'cdb_lifecycle_status': 'Development',
             'cdb_line_of_bus': '',
             'cdb_location': 'DCEAST',
             'target_guid': '869364C12ED46D39E0533C35560A858C'}
        }
    """
    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN process_db_properties")
    debug(" f=" + f)

    # Read the DB properties file
    db_props_csv = open(f, 'r')
    db_props_csv_hdr = [h.strip().strip('"') for h in db_props_csv.readline().split(',')]
    db_props_reader = csv.DictReader(db_props_csv, fieldnames=db_props_csv_hdr)
    # db_props_reader2 = csv.reader(db_props_csv, delimiter=',')

    db_props_cols = [c for c in DB_PROPS_COLS if c in db_props_csv_hdr]
    debug("Columns selected from csv header: " + str(db_props_cols))

    # Sort the csv fields by TARGET_GUID
    sorted_prop_list = sorted(db_props_reader, key=lambda c: c['TARGET_GUID'])
    sorted_prop_list_lgt = len(sorted_prop_list)

    # Initialize the maps and vars
    db_props_target_id_to_values_map = OrderedDict()
    db_props_name_to_value_map = OrderedDict()
    last_tgt_uid = ""
    cnt = 0

    # For each line on the properties dict
    for lin in sorted_prop_list:
        cnt += 1
        tgt_uid, prop_name, prop_val = "", "", ""

        # Keep insertion order following db_props_csv_hdr contents
        sorted_lin = OrderedDict()
        for col in db_props_csv_hdr:
            sorted_lin[col] = lin[col]

        # For each record on the line
        for k, v in sorted_lin.items():

            # Add the value to the properties,values map
            if tgt_uid and prop_name and prop_val:
                add_value(db_props_name_to_value_map, prop_name.strip(), prop_val.strip())
                last_tgt_uid = tgt_uid
                tgt_uid, prop_name, prop_val = "", "", ""
                continue

            # Skip not needed columns
            if k not in db_props_cols:
                continue

            # Fetch the target id
            if k == "TARGET_GUID":
                tgt_uid = v

                # Add to the map if the target id has changed
                if last_tgt_uid and tgt_uid != last_tgt_uid:
                    db_props_target_id_to_values_map[last_tgt_uid] = db_props_name_to_value_map
                    db_props_name_to_value_map = OrderedDict()
                continue

            # Fetch the property name
            if tgt_uid and k == "NAME":
                prop_name = v
                continue

            # Fetch the property value
            if tgt_uid and prop_name and k == "VALUE":
                prop_val = v
                continue

        # Add the last record
        if not tgt_uid:
            db_props_target_id_to_values_map[last_tgt_uid] = db_props_name_to_value_map
    # Debug
    debug("\n[csv] db_props_target_id_to_values_map ")
    for _ in db_props_target_id_to_values_map:
        debug(" " + _ + "->" + str(db_props_target_id_to_values_map[_]))
    debug("Total [" + str(cnt) + "] sorted_prop_list size [" + str(sorted_prop_list_lgt) + "] ")

    # Add missing properties
    for target, prop_dict in db_props_target_id_to_values_map.items():
        for prop in DB_PROPS_NAMES:
            if prop not in prop_dict:
                add_value(prop_dict, prop, '')
        db_props_target_id_to_values_map[target] = prop_dict

    # Rename properties and drop those that are not needed
    for target, prop_dict in db_props_target_id_to_values_map.items():
        prop_dict_copy = prop_dict.copy()
        for prop in prop_dict.keys():
            if prop in DB_PROPS_NAMES:

                # Rename Version to cdb_version
                if prop == "Version":
                    cdb_version = prop.replace("Version", "cdb_version")
                    prop_dict_copy[cdb_version] = prop_dict_copy.pop(prop)
                    continue

                # Rename the orcl_gtp properties prefixing it with cdb
                cdb_prop = prop.replace("orcl_gtp", "cdb")
                prop_dict_copy[cdb_prop] = prop_dict_copy.pop(prop)

                # Add the same value pair prefixing the property with db
                # db_prop_val = prop_dict_copy[cdb_prop]
                # db_prop = prop.replace("orcl_gtp", "db")
                # prop_dict_copy[db_prop] = db_prop_val
            else:
                prop_dict_copy.pop(prop)
        prop_dict = prop_dict_copy.copy()
        db_props_target_id_to_values_map[target] = prop_dict

    # Add Target uid to the map
    for target, prop_dict in db_props_target_id_to_values_map.items():
        add_value(prop_dict, "target_guid", target)

    debug("\n[dict] db_props_target_id_to_values_map (add,rename,drop)")
    for _ in db_props_target_id_to_values_map:
        debug(" " + _ + "->" + str(db_props_target_id_to_values_map[_]))

    # Sort the properties dict
    db_props_target_id_to_values_map_sorted = OrderedDict()
    for target, prop_dict in db_props_target_id_to_values_map.items():
        prop_dict_sorted = sorted(prop_dict.items(), key=lambda x: x[0])
        db_props_target_id_to_values_map_sorted[target] = dict(prop_dict_sorted)
    db_props_target_id_to_values_map = db_props_target_id_to_values_map_sorted.copy()

    debug("\n[dict] db_props_target_id_to_values_map (sort)")
    for _ in db_props_target_id_to_values_map:
        debug(" " + _ + "->" + str(db_props_target_id_to_values_map[_]))

    db_props_csv.close()
    return db_props_target_id_to_values_map


def process_db_infrastructure(f):
    """   Parses emcc_sizing_structure_db.csv created by EMCC Extract.
          Get the values for the columns stated in DB_STRUCTURE_COLS list,
          Add the "Server List" column which will contain the list of servers of a clustered target,
          Rename original columns.

          Return a dict keyed by the TARGET_GUID with the following values and order:

            { 20B56675814AF03ADFEAD207E377934D->
                {'dbmachine': '',
                'dbmachine_owner': '',
                'cdb_owner': 'owner-00000',
                'cdb_standby_type': 'Primary',
                'clustered': 'yes',
                'Database List': 'A3BF3FE405218EBF9FF533AD8C15A6CC,5CDC1DE0D9867ED5E3133A314037B6FC',
                'Host List': 'C839D67B8CB10B1E86B150960D0A5DBA,1747DFC8DD1DA99FDDF7658449221BFC'
                'Database Name': 'rac_database-00046',
                'target_guid': '20B56675814AF03ADFEAD207E377934D',
                'Server List': 'host-00082,host-00083'
                },
                ...
            }
    """
    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN process_db_infrastructure")
    debug(" f=" + f)

    # Read the DB structure file
    db_structure_csv = open(f, 'r')
    db_structure_csv_hdr = [h.strip().strip('"') for h in db_structure_csv.readline().split(',')]
    db_structure_reader = csv.DictReader(db_structure_csv, fieldnames=db_structure_csv_hdr)

    # Create a dict containing all relevant rows for db structure file
    db_structure_cols = [c for c in DB_STRUCTURE_COLS if c in db_structure_csv_hdr]
    debug("Columns selected from csv header: " + str(db_structure_cols))
    db_structure_dict = []
    for lin in db_structure_reader:
        structure_cols_dict = OrderedDict()
        for k in DB_STRUCTURE_COLS:
            structure_cols_dict[k] = lin[k].strip()
        db_structure_dict.append(structure_cols_dict)

    debug("\n[csv] db_structure_dict: ")
    for _ in db_structure_dict:
        debug(" " + str(_))

    # Create dicts for clustered and non-clustered targets
    non_clustered_targets_dict = [i for i in db_structure_dict if i["clustered"] == "no"]
    clustered_targets_dict = [i for i in db_structure_dict if i["clustered"] == "yes"]

    debug("total [" + str(len(db_structure_dict)) + "]" +
          " clustered [" + str(len(clustered_targets_dict)) + "]" +
          " non-clustered [" + str(len(non_clustered_targets_dict)) + "]")

    # Process non-clustered targets
    non_clustered_target_id_to_values_map = OrderedDict()
    for structure_dict in non_clustered_targets_dict:
        structure_dict_copy = structure_dict.copy()
        tgt_guid = structure_dict["cdb_target_guid"]

        # Rename columns
        structure_dict_copy["Database Name"] = structure_dict_copy.pop("cdb")
        structure_dict_copy["target_guid"] = structure_dict_copy.pop("cdb_target_guid")
        structure_dict_copy["Server List"] = structure_dict_copy.pop("host")

        # Add Databases and hosts lists
        structure_dict_copy["Database List"] = structure_dict_copy["db_target_guid"]
        structure_dict_copy["Host List"] = structure_dict_copy["host_target_guid"]

        # Drop not needed columns
        structure_dict_copy.pop("db_target_guid")
        structure_dict_copy.pop("host_target_guid")
        structure_dict_copy.pop("clustered")

        # Rename column values
        structure_dict_copy["cluster"] = "none"

        non_clustered_target_id_to_values_map[tgt_guid] = structure_dict_copy

    debug("\n[dict] non_clustered_target_id_to_values_map")
    for _ in non_clustered_target_id_to_values_map:
        debug(" " + _ + "->" + str(non_clustered_target_id_to_values_map[_]))

    # Process clustered targets if there are any
    clustered_target_id_to_values_map = OrderedDict()
    if len(clustered_targets_dict) > 0:

        # Create a map of cdb_target_guid and hosts for clustered target
        cdb_uid_to_host_map = OrderedDict()
        create_map(cdb_uid_to_host_map, clustered_targets_dict, "cdb_target_guid", "host")

        # Create a map of cdb_target_guid and db_target_guid for clustered targets
        cdb_uid_to_db_target_guid_map = OrderedDict()
        create_map(cdb_uid_to_db_target_guid_map, clustered_targets_dict, "cdb_target_guid", "db_target_guid")

        # Create a map of cdb_target_guid and host_target_guid for clustered targets
        cdb_uid_to_host_target_guid_map = OrderedDict()
        create_map(cdb_uid_to_host_target_guid_map, clustered_targets_dict, "cdb_target_guid", "host_target_guid")

        # Process clustered targets

        for structure_dict in clustered_targets_dict:
            structure_dict_copy = structure_dict.copy()
            tgt_guid = structure_dict["cdb_target_guid"]

            # Add the Server list
            server_list = create_string_from_list(cdb_uid_to_host_map, tgt_guid)
            structure_dict_copy["host"] = server_list

            # Add the Databases GUIDs List
            db_list = create_string_from_list(cdb_uid_to_db_target_guid_map, tgt_guid)
            structure_dict_copy["Database List"] = db_list

            # Add the Hosts GUIDs List
            host_guid_list = create_string_from_list(cdb_uid_to_host_target_guid_map, tgt_guid)
            structure_dict_copy["Host List"] = host_guid_list

            # Rename columns
            structure_dict_copy["Database Name"] = structure_dict_copy.pop("cdb")
            structure_dict_copy["target_guid"] = structure_dict_copy.pop("cdb_target_guid")
            structure_dict_copy["Server List"] = structure_dict_copy.pop("host")

            # Drop not needed columns
            structure_dict_copy.pop("db_target_guid")
            structure_dict_copy.pop("host_target_guid")
            structure_dict_copy.pop("clustered")

            clustered_target_id_to_values_map[tgt_guid] = structure_dict_copy

        debug("\n[dict] clustered_target_id_to_values_map")
        for _ in clustered_target_id_to_values_map:
            debug(" " + _ + "->" + str(clustered_target_id_to_values_map[_]))

    # Merge clustered and non-clustered target dicts
    db_structure_target_id_to_values_map = clustered_target_id_to_values_map.copy()
    db_structure_target_id_to_values_map.update(non_clustered_target_id_to_values_map)

    # Drop not needed columns
    # for k, structure_dict in db_structure_target_id_to_values_map.items():
    #     structure_dict_copy = structure_dict.copy()
    #     structure_dict_copy.pop("clustered")
    #     db_structure_target_id_to_values_map[k] = structure_dict_copy

    debug("\n[dict] db_structure_target_id_to_values_map (clustered + non-clustered)")
    for _ in db_structure_target_id_to_values_map:
        debug(" " + _ + "->" + str(db_structure_target_id_to_values_map[_]))

    db_structure_csv.close()
    return db_structure_target_id_to_values_map


def merge_infra_and_prop_dicts(infrastructure_dict, properties_dict):
    """ Merges the contents of infrastructure_dict which holds the values collected from
        file emcc_sizing_structure_db.csv created by EMCC Extract and properties_dict which
        holds values collected from emcc_sizing_structure_db_props.csv created by EMCC Extract

        Returns a list of dicts with the merge of the values coming from both dicts per target_uid:

        [
             {'dbmachine': '', 'dbmachine_owner': '', 'cdb_owner': 'owner-00000', 'cdb_standby_type': '',
             'clustered': 'yes', 'Database List': '9512D2D4F1334BFA717BAD7A298F50DC',
             'Host List': '8384B77FC776CD26807F93EDDD180E13', 'Database Name': 'rac_database-00000',
             'target_guid': '0086C00DBB8CD442BD0A14D93C29E1CA', 'Server List': 'host-00003',
             'cdb_cost_center': '', 'cdb_department': '', 'cdb_lifecycle_status': 'Development',
             'cdb_line_of_bus': '', 'cdb_location': 'DCEAST'},

            {'dbmachine': '', 'dbmachine_owner': '', 'cdb_owner': 'owner-00000', 'cdb_standby_type': 'Primary',
            'clustered': 'yes', 'Database List': 'CA6A2DF4B9C3D3D704C8A9D3C64E82A2,B6ACFED553C560790AB4676D045895F9',
             'Host List': 'F630BBF5372F1D3C8374A9DE15C90EDB,8D0EB4BD7A3C43751BD7A580F98D2AA8',
             'Database Name': 'rac_database-00027', 'target_guid': '185181BEC811B684AA291EC9D2FEC520',
             'Server List': 'host-00061,host-00060', 'cdb_cost_center': '', 'cdb_department': '',
             'cdb_lifecycle_status': 'Production', 'cdb_line_of_bus': '', 'cdb_location': 'DCNORTH'}
         ]
    """
    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN merge_infra_and_prop_dicts")

    merged_dict = []
    for tgt_uid, infra_val in infrastructure_dict.items():
        per_target_dict = OrderedDict()

        # Add the infra values to the map
        for k, v in infra_val.items():
            # Enclose list values with double quotes
            # if k == "Server List" and "," in v:
            #     v = '"' + v + '"'
            per_target_dict[k] = v

        # Add the properties values to the map
        if tgt_uid in properties_dict:
            prop_map = properties_dict[tgt_uid]
            for k, v in prop_map.items():
                per_target_dict[k] = v
        else:
            # Keep the record with empty values for those targets not present in the properties file
            if len(tgt_uid) > 0:
                log(" TARGET GUID : " + tgt_uid + " not found in " + DB_PROPS_FILE_NAME)
            target_without_properties_dict = OrderedDict()
            for prop in DB_PROPS_NAMES:
                # Rename Version to cdb_version
                if prop == "Version":
                    cdb_version = prop.replace("Version", "cdb_version")
                    target_without_properties_dict[cdb_version] = ''

                # Rename the existing property prefixing it with cdb
                cdb_prop = prop.replace("orcl_gtp", "cdb")
                target_without_properties_dict[cdb_prop] = ''

            per_target_dict.update(target_without_properties_dict)
        merged_dict.append(per_target_dict)

    debug("\n[dict] merged_dict")
    for _ in merged_dict:
        debug(" " + str(_))

    return merged_dict


# Match uid string in the file lines of the given file
def get_lines_per_uid(file, filelineslist, uidlist, file_start_time):
    """ Gets the lines containing the UID string.
    """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN get_lines_per_uid")
    debug("filelist_size=" + str(len(filelineslist)) + " uidlist_size=" + str(len(uidlist)))

    debug_cnt = 0
    display_cnt = 0
    filtered_lines = []
    matches = 0
    for uid in uidlist:
        uid_start_time = time.time()
        debug_cnt += 1
        display_cnt += 1

        # Match the uid on each of the lines
        uid_for_match = uid

        if file not in SPECIAL_FORMAT_EXTRACT_CSV_FILES:
            # matching_lines_per_uid = [lin for lin in filelineslist if lin.startswith(uid_for_match)]
            # UID could be enclosed within double quotes in some ocassions
            uid_for_match_quoted = '"' + uid
            uid_for_match_tupple = (uid_for_match, uid_for_match_quoted)
            matching_lines_per_uid = [lin for lin in filelineslist if lin.startswith(uid_for_match_tupple)]
        else:
            # Handle those lines not containing uid on the first column
            matching_lines_per_uid = [lin for lin in filelineslist if uid_for_match in lin]

        log_to_file("   --> [" + str(debug_cnt) + "] UID [ " + uid + " ] " +
                    "Total [" + str(len(filelineslist)) + "] " +
                    "Matched [" + str(len(matching_lines_per_uid)) + "] " +
                    "Elapsed [" + str(round(time.time() - uid_start_time, 3)) + "s]")
        if display_cnt == len(uidlist):
            log_to_file(" File Total [" + str(round(time.time() - file_start_time, 3)) + "s]")

        debug("   --> [" + str(debug_cnt) + "] UID [ " + uid + " ] " +
              "Total [" + str(len(filelineslist)) + "] " +
              "Matched [" + str(len(matching_lines_per_uid)) + "] " +
              "Elapsed [" + str(round(time.time() - uid_start_time, 3)) + "s]")

        if display_cnt == len(uidlist):
            debug(" File Total [" + str(round(time.time() - file_start_time, 3)) + "s]")

        filtered_lines.append(matching_lines_per_uid)
        matches += len(matching_lines_per_uid)

        # Show progress bar while processing matches
        if display_cnt == len(uidlist):

            # emcc_sizing_structure_db.csv has duplicates as part of the processing , we can't update the counter
            # in flight , hence once we have finished processing we should remove duplicates and get the number of matches
            if file == 'emcc_sizing_structure_db.csv':
                flat_filtered_lines_to_display = [item for sublist in filtered_lines for item in sublist]
                filtered_lines_set_to_display = set(tuple(x) for x in flat_filtered_lines_to_display)
                filtered_lines_lst_to_display = [''.join(x) for x in filtered_lines_set_to_display]
                emcc_sizing_structure_db_matches = str(len(filtered_lines_lst_to_display))
                progress_bar(file, len(uidlist), display_cnt, emcc_sizing_structure_db_matches, get_elapsed_time(file_start_time))
            else:
                progress_bar(file, len(uidlist), display_cnt, str(matches), get_elapsed_time(file_start_time))
        else:
            progress_bar(file, len(uidlist), display_cnt, str(matches), "")

    # Flatten the list
    flat_filtered_lines = [item for sublist in filtered_lines for item in sublist]

    # Remove duplicated lines
    filtered_lines_set = set(tuple(x) for x in flat_filtered_lines)
    filtered_lines_lst = [''.join(x) for x in filtered_lines_set]

    # Sort by the order read from the file , performance is impacted by this operation
    # filelineslist_to_sort = [i for i in filelineslist if i in filtered_lines_lst]
    # filtered_lines_lst.sort(key=lambda x: filelineslist_to_sort.index(x))

    return filtered_lines_lst


def filter_file(file, uid_list):
    global NOTCREATED_FILTERED_FILES_COUNT
    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN filter_file")
    debug("file=" + file + " uidlist_size=" + str(len(uid_list)))

    log_to_file("\n File " + file + " :")
    file_start_time = time.time()
    file_path = EXTRACT_DIR_PATH + os.sep + file

    if os.path.exists(file_path):
        file_lines = create_list_of_lines_from_file(file_path)

        # Get the lines from the file present in the uid list
        filtered_lines_per_file = get_lines_per_uid(file, file_lines, uid_list, file_start_time)

        # Write the output file if it has data
        if len(filtered_lines_per_file) > 0:
            csv_hdr = get_first_line_from_file(file_path)
            filtered_lines_per_file.insert(0, csv_hdr.strip())
            write_file_from_list(file, filtered_lines_per_file)
        else:
            NOTCREATED_FILTERED_FILES_COUNT += 1

    else:
        log_to_file("   Skipping File , does not exists")


def run_it():
    """ Processes the arguments passed to the script with parse_args() and calls the relevant defs to do
        the processing
    """

    debug('\n---------------------------------------------------------------------------------------------------------')
    debug("BEGIN run_it")

    #  Define Arguments to the program
    parser = argparse.ArgumentParser(
        description="Filter EMCC Extract",
    )
    group = parser.add_mutually_exclusive_group(required=True)

    group.add_argument(
        "--version",
        action="store_true",
        help="Show Version"
    )

    group.add_argument(
        "--create-filter",
        action="store_true",
        help="Create filter file"
    )

    group.add_argument(
        "--filter",
        action="store_true",
        help="Filter extract data using the filter file"
    )

    # If there are no arguments, print the help message
    if len(sys.argv) == 1:
        parser.print_help(sys.stderr)
        sys.exit(1)

    # Parse Arguments
    args = parser.parse_args()
    debug(" args=" + str(args))

    create_filter = False
    do_filter = False
    if args.version:
        print_version()
    if args.create_filter:
        create_filter = True
    if args.filter:
        do_filter = True

    # ------------------------------------------------------------------------------------------------------------------
    # Create filter file
    # ------------------------------------------------------------------------------------------------------------------
    if create_filter:
        # Verify the working files
        check_file(DB_STRUCTURE_FILE_PATH)
        check_file(DB_PROPS_FILE_PATH)

        # Process db infrastructure file
        infra_dict = process_db_infrastructure(DB_STRUCTURE_FILE_PATH)

        # Process db properties file
        props_dict = process_db_properties(DB_PROPS_FILE_PATH)

        # Merge infra and properties dicts per target
        infra_and_props_dict = merge_infra_and_prop_dicts(infra_dict, props_dict)

        # Build output dict with the columns in the given order by FILTER_FILE_OUTPUT_COLUMNS
        output_dict = []
        for _ in infra_and_props_dict:
            csv_line_map = OrderedDict()
            for col_name in FILTER_FILE_OUTPUT_COLUMNS:

                # Add Exclusion flag
                if col_name == "Exclude":
                    csv_line_map[col_name] = ''
                    continue
                csv_line_map[col_name] = _[col_name]
            output_dict.append(csv_line_map)

        # Sort the records in the output dict by 'Database Name' key
        output_dict = sorted(output_dict, key=lambda x: x['Database Name'])

        debug("\n[dict] output_dict")
        for _ in output_dict:
            debug(" " + str(_))

        # Remove previous copies and create the csv file
        if os.path.exists(FILTER_FILE_PATH):
            os.remove(FILTER_FILE_PATH)
            log("Deleted existing file " + FILTER_FILE_PATH)
        write_csv_file_from_dict(FILTER_FILE_PATH, output_dict)

    # ------------------------------------------------------------------------------------------------------------------
    # Filter extract files
    # ------------------------------------------------------------------------------------------------------------------
    if do_filter:
        global CREATED_FILTERED_FILES_COUNT, NOTCREATED_FILTERED_FILES_COUNT
        log(" Filtering files...\n")
        filter_start_time = time.time()
        check_file(FILTER_FILE_PATH)
        uid_map = create_map_of_ids_per_target_type(FILTER_FILE_PATH)

        # --------------------------------------------------------------------------------------------------------------
        # Snippet to handle files that do not need/require filtering (in case there is any)
        # --------------------------------------------------------------------------------------------------------------
        if len(DO_NOT_FILTER_FILES) > 0:
            for excluded_file in DO_NOT_FILTER_FILES:
                CREATED_FILTERED_FILES_COUNT += 1
                log_to_file("\n File " + excluded_file + " :")
                file_start_time = time.time()
                ex_file_path = EXTRACT_DIR_PATH + os.sep + excluded_file

                if os.path.exists(ex_file_path):

                    # Dump all the lines from the file without filtering per uid
                    ex_file_lines = create_list_of_lines_from_file(ex_file_path)
                    progress_bar(excluded_file, 100, 100, str(len(ex_file_lines)) + "*", get_elapsed_time(file_start_time))

                    # Write the output file if it has data
                    if len(ex_file_lines) > 0:
                        write_file_from_list(excluded_file, ex_file_lines)
                else:
                    log_to_file("   Skipping File , does not exists")

        # --------------------------------------------------------------------------------------------------------------
        # Filter emcc_sizing_availability_history.csv (contains rows for both hosts and databases)
        # --------------------------------------------------------------------------------------------------------------
        db_targets_list = [i for i in uid_map['db_targets']]
        host_targets_list = [i for i in uid_map['host_targets']]
        db_and_host_uid_list = db_targets_list + host_targets_list
        db_and_host_uid_list.sort()

        # Troubleshooting
        troubleshoot("db_uid_list", db_and_host_uid_list)
        troubleshoot("AV_HISTORY", AV_HISTORY)

        # For each file
        for av_file in AV_HISTORY:
            CREATED_FILTERED_FILES_COUNT += 1
            filter_file(av_file, db_and_host_uid_list)

        # --------------------------------------------------------------------------------------------------------------
        # Filter EM csv files
        # --------------------------------------------------------------------------------------------------------------
        db_uid_list = uid_map['db_targets']
        db_uid_list.sort()

        # Troubleshooting
        troubleshoot("db_uid_list", db_uid_list)
        troubleshoot("EM_EXTRACT_CSV_FILES", EM_EXTRACT_CSV_FILES)

        # For each file
        for db_file in EM_EXTRACT_CSV_FILES:
            CREATED_FILTERED_FILES_COUNT += 1
            filter_file(db_file, db_uid_list)

        # --------------------------------------------------------------------------------------------------------------
        # Filter DB csv files
        # --------------------------------------------------------------------------------------------------------------
        db_uid_list = uid_map['db_targets']
        db_uid_list.sort()

        # Troubleshooting
        troubleshoot("db_uid_list", db_uid_list)
        troubleshoot("DB_EXTRACT_CSV_FILES", DB_EXTRACT_CSV_FILES)

        # For each file
        for db_file in DB_EXTRACT_CSV_FILES:
            CREATED_FILTERED_FILES_COUNT += 1
            # Add  dbmachine_targets to filter emcc_sizing_structure_db_vm.csv
            if db_file == 'emcc_sizing_structure_db_vm.csv':
                db_uid_list += uid_map['dbmachine_targets']
                db_uid_list.sort()
            filter_file(db_file, db_uid_list)

        # --------------------------------------------------------------------------------------------------------------
        # Filter HOST csv files
        # --------------------------------------------------------------------------------------------------------------
        host_uid_list = uid_map['host_targets']
        host_uid_list.sort()

        # Troubleshooting
        troubleshoot("host_uid_list", host_uid_list)
        troubleshoot("HOST_EXTRACT_CSV_FILES", HOST_EXTRACT_CSV_FILES)

        # For each file
        for host_file in HOST_EXTRACT_CSV_FILES:
            CREATED_FILTERED_FILES_COUNT += 1
            filter_file(host_file, host_uid_list)

        # Print elapsed time and File Counts
        log("\n File Count Summary : "
            "Expected[" + str(len(EXPECTED_EXTRACT_FILTERED_FILES)) + "] " +
            "Processed[" + str(CREATED_FILTERED_FILES_COUNT) + "] " +
            "Empty[" + str(NOTCREATED_FILTERED_FILES_COUNT) + "] " +
            "Total[" + str(CREATED_FILTERED_FILES_COUNT - NOTCREATED_FILTERED_FILES_COUNT) + "]")
        log("\n Filtering completed in " + get_elapsed_time(filter_start_time))

        # Print note about the results obtained
        log('=======================================================================================================')
        log(" Note:\n  A complete collection of EMCC Extracts contains " + str(len(EXPECTED_EXTRACT_CSV_FILES)) + " files." +
            " Only " + str(len(EXPECTED_EXTRACT_FILTERED_FILES)) + " files from those " + str(len(EXPECTED_EXTRACT_CSV_FILES)) +
            " are used by\n  Source Side Filtering. Empty files are not created in the filtered data set."
            )
        log('=======================================================================================================')



#######################################################################################################################
# MAIN
#######################################################################################################################
def main():
    # Verify the emcc_sizing_extracts directory
    check_dir(EXTRACT_DIR_PATH)

    # Create the output directory
    try:
        os.makedirs(OUTPUT_DIR_PATH)
    except OSError as e:
        if e.errno != errno.EEXIST:
            log("Using existing directory :" + OUTPUT_DIR_PATH + "\n")
    except Exception as e:
        log("Exception creating directory :" + OUTPUT_DIR_PATH)
        log("Exception " + str(e))
        quit()
    else:
        log("Created directory :" + OUTPUT_DIR_PATH)

    # Verify the output directory
    check_dir(OUTPUT_DIR_PATH)

    # Define log and debug file
    fnam = os.path.basename(__file__)
    log_file_path = OUTPUT_DIR_PATH + os.sep + fnam + ".log"
    dbg_file_path = OUTPUT_DIR_PATH + os.sep + fnam + ".dbg"

    # Remove previous copies of log and debug file
    if os.path.exists(log_file_path):
        os.remove(log_file_path)

    if os.path.exists(dbg_file_path):
        os.remove(dbg_file_path)

    log('=======================================================================================================\n')
    log(fnam + ', version ' + __version__)
    log_to_file('platform.version  : ' + platform.python_version())
    log_to_file('platform.system   : ' + str(platform.system()))
    log('\n=======================================================================================================')
    run_it()

    # Write log array to file
    with open(log_file_path, 'w') as f:
        for line in log_data:
            f.write(line)

    # Write debug array to file
    if DEBUG:
        with open(dbg_file_path, 'w') as f:
            for line in debug_data:
                f.write(line)


if __name__ == "__main__":
    main()
