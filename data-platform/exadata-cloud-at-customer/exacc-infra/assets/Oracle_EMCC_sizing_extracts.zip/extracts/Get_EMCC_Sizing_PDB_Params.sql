rem
rem Version 1.8
define __version__ = 1.8
rem

rem Version History
rem
rem 2021-03-16    1.8   tmf     Added performance profile parameter
rem 2021-02-08    1.7   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.6   tmf     Added timing off
rem 2020-11-19    1.5   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.4   tmf     mkdir -p
rem 2020-09-07    1.3   tmf     Removed bad parameters
rem 2020-04-18    1.2   tmf     Added timing capture
rem 2020-03-09    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting PDB parameters...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_pdb_params.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_pdb_params.csv

prompt "TARGET_GUID","TARGET_NAME","TARGET_TYPE","NAME","VALUE","EXTRACT_DTTM_UTC"

SELECT RAWTOHEX(p.target_guid) AS target_guid
      ,p.target_name
      ,p.target_type
      ,p.name
      ,p.value
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')
FROM   sysman.mgmt$db_init_params_all p
WHERE  p.is_current  = 'Y'
AND    p.target_type = 'oracle_pdb'
--AND    p.target_name = 'hrapex_rws60163rems.us.oracle.com'
AND    p.name        IN (
                         'cpu_count'
                        ,'cpu_min_count'
                        ,'db_performance_profile'
                        ,'pga_aggregate_limit'
                        ,'pga_aggregate_target'
                        ,'processes'
                        ,'sessions'
                        ,'sga_max_size'
                        ,'sga_target'
                        ,'use_large_pages'
                        );

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_pdb_params.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
