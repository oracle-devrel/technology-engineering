rem
rem Version 1.8
define __version__ = 1.8
rem

rem Version History
rem
rem 2021-02-08    1.8   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.7   tmf     Added timing off
rem 2020-11-19    1.6   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.5   tmf     mkdir -p
rem 2020-10-11    1.4   tmf     Re-factored query
rem 2020-04-18    1.3   tmf     Added timing capture
rem 2020-03-11    1.2   tmf     Corrected typo in output file
rem 2020-03-10    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting PDB structure...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_pdb.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_pdb.csv

prompt "extract_version"-
,"dbmachine","dbmachine_type_version","dbmachine_type","dbmachine_owner","cluster","cluster_owner","cluster_status","cluster_last_load_time_utc"-
,"clustered"-
,"cdb","cdb_type_version","cdb_type","cdb_owner","cdb_status","cdb_last_load_time_utc"-
,"pdb","pdb_type_version","pdb_type","pdb_owner","pdb_status","pdb_last_load_time_utc"-
,"dbmachine_target_guid","cluster_target_guid","cdb_target_guid","pdb_target_guid"-
,"cdb_num","cdb_pdb_rn","cdb_pdb","pdb_num"-
,"extract_dttm_utc"

SELECT '&__version__'                                                                                                               AS extract_version
      ,t.*
      ,RANK()                                                   OVER (                                 ORDER BY t.cdb_target_guid)  AS cdb_num
      ,ROW_NUMBER()                                             OVER (PARTITION BY t.cdb_target_guid
                    ORDER BY CASE WHEN INSTR(t.pdb, '_CDBROOT') > 0 THEN 'AAAAAA' ELSE t.pdb END)                                   AS cdb_pdb_rn
      ,COUNT(CASE WHEN t.pdb = 'none' THEN NULL ELSE t.pdb END) OVER (PARTITION BY t.cdb_target_guid)                               AS cdb_pdb_count
      ,RANK()                                                   OVER (                                 ORDER BY t.pdb_target_guid)  AS pdb_num
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS')                                                              AS extract_dttm_utc
FROM
(
WITH rac_db_machines
AS
(
SELECT td.target_name  AS rac
      ,td.target_guid  AS rac_target_guid
      ,tx.target_name  AS dbmachine
      ,tx.owner        AS dbmachine_owner
      ,tx.target_guid  AS dbmachine_target_guid
      ,tx.target_type  AS dbmachine_type
      ,tx.type_version AS dbmachine_type_version
FROM   sysman.mgmt$target              tx
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              td
WHERE  i.assoc_target_name      = tx.target_name (+)
AND    i.assoc_target_type      = tx.target_type (+)
AND    i.assoc_target_type (+) IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
AND    i.association_type  (+)  = 'deployed_on'
AND    td.target_type           = i.source_target_type (+)
AND    td.target_name           = i.source_target_name (+)
AND    td.target_type           = 'rac_database'
)
,db_db_machines
AS
(
SELECT td.target_name  AS db
      ,td.target_guid  AS db_target_guid
      ,tx.target_name  AS dbmachine
      ,tx.owner        AS dbmachine_owner
      ,tx.target_guid  AS dbmachine_target_guid
      ,tx.target_type  AS dbmachine_type
      ,tx.type_version AS dbmachine_type_version
FROM   sysman.mgmt$target              tx
      ,sysman.mgmt$target_associations i
      ,sysman.mgmt$target              td
WHERE  i.assoc_target_name      = tx.target_name (+)
AND    i.assoc_target_type      = tx.target_type (+)
AND    i.assoc_target_type (+) IN ('oracle_exadata_cloud_service', 'oracle_dbmachine')
AND    i.association_type  (+)  = 'deployed_on'
AND    td.target_type           = i.source_target_type (+)
AND    td.target_name           = i.source_target_name (+)
AND    td.target_type           = 'oracle_database'
)
,cluster_rac_dbs AS
(
SELECT tc.target_guid              AS cluster_target_guid
      ,tc.target_name              AS cluster_name
      ,tc.last_load_time_utc       AS cluster_last_load_time_utc
      ,tc.owner                    AS cluster_owner
      ,tca.availability_status     AS cluster_status
      ,tr.target_guid              AS rac_target_guid
      ,tr.target_name              AS rac
      ,tr.last_load_time_utc       AS rac_last_load_time_utc
      ,tr.owner                    AS rac_owner
      ,tr.type_qualifier2          AS rac_stand_by_type
      ,tra.availability_status     AS rac_status
      ,tr.type_version             AS rac_type_version
      ,tr.target_type              AS rac_type
      ,CASE
         WHEN COUNT(1) OVER (PARTITION BY tr.target_name) > 1 THEN 1
       ELSE
         0
       END rac_cluster_dup_flag
FROM   sysman.mgmt$availability_current tra
      ,sysman.mgmt$target               tr
      ,sysman.mgmt$target_associations  i
      ,sysman.mgmt$availability_current tca
      ,sysman.mgmt$target               tc
WHERE  tr.target_guid           = tra.target_guid (+)
AND    i.source_target_name     = tr.target_name (+)
AND    i.source_target_type     = tr.target_type (+)
AND    i.source_target_type (+) = 'rac_database'
AND    i.association_type   (+) = 'runs_on_cluster'
AND    tc.target_type           = i.assoc_target_type (+)
AND    tc.target_name           = i.assoc_target_name (+)
AND    tc.target_guid           = tca.target_guid     (+)
AND    tc.target_type           = 'cluster'
)
,pdbs AS
(
SELECT td.target_guid          AS pdb_target_guid
      ,td.target_name          AS pdb
      ,td.type_version         AS pdb_type_version
      ,td.owner                AS pdb_owner
      ,td.last_load_time_utc   AS pdb_last_load_time_utc
      ,tda.availability_status AS pdb_status
      ,td.target_type          AS pdb_type
      ,tr.target_guid          AS cdb_target_guid
      ,tr.target_name          AS cdb
      ,tr.type_version         AS cdb_type_version
      ,tra.availability_status AS cdb_status
      ,tr.target_type          AS cdb_type
      ,tr.owner                AS cdb_owner
      ,tr.last_load_time_utc   AS cdb_last_load_time_utc
FROM   sysman.mgmt$availability_current tra
      ,sysman.mgmt$target               tr
      ,sysman.mgmt$target_associations  i
      ,sysman.mgmt$availability_current tda
      ,sysman.mgmt$target               td
WHERE  tr.target_guid            = tra.target_guid (+)
AND    i.source_target_name      = tr.target_name  (+)
AND    i.source_target_type      = tr.target_type  (+)
AND    i.source_target_type (+) IN ('oracle_database', 'rac_database')
AND    i.association_type   (+)  = 'contains'
AND    td.target_type            = i.assoc_target_type  (+)
AND    td.target_name            = i.assoc_target_name  (+)
AND    td.target_guid            = tda.target_guid      (+)
AND    td.target_type            = 'oracle_pdb'
)
SELECT   NVL(x1.dbmachine,              x2.dbmachine)                   AS dbmachine
        ,NVL(x1.dbmachine_type_version, x2.dbmachine_type_version)      AS dbmachine_type_version
        ,NVL(x1.dbmachine_type,         x2.dbmachine_type)              AS dbmachine_type
        ,NVL(x1.dbmachine_owner,        x2.dbmachine_owner)             AS dbmachine_owner
        ,NVL(c.cluster_name,   'none')                                  AS cluster_name
        ,NVL(c.cluster_owner,  'none')                                  AS cluster_owner
        ,NVL(c.cluster_status, 'none')                                  AS cluster_status
        ,TO_CHAR(c.cluster_last_load_time_utc, 'YYYY-MM-DD HH24:MI:SS') AS cluster_last_load_time_utc
        ,CASE
           WHEN d.cdb_type = 'rac_database' THEN 'yes'
         ELSE
           'no'
         END AS clustered
        ,d.cdb
        ,d.cdb_type_version
        ,d.cdb_type
        ,d.cdb_owner
        ,d.cdb_status
        ,TO_CHAR(d.cdb_last_load_time_utc, 'YYYY-MM-DD HH24:MI:SS')  AS cdb_last_load_time_utc
        ,d.pdb
        ,d.pdb_type_version
        ,d.pdb_type
        ,d.pdb_owner
        ,d.pdb_status
        ,TO_CHAR(d.pdb_last_load_time_utc, 'YYYY-MM-DD HH24:MI:SS')        AS pdb_last_load_time_utc
        ,RAWTOHEX(NVL(x1.dbmachine_target_guid, x2.dbmachine_target_guid)) AS dbmachine_target_guid
        ,RAWTOHEX(c.cluster_target_guid)                                   AS cluster_target_guid
        ,RAWTOHEX(d.cdb_target_guid)                                       AS cdb_target_guid
        ,RAWTOHEX(d.pdb_target_guid)                                       AS pdb_target_guid
FROM     rac_db_machines           x2
        ,db_db_machines            x1
        ,cluster_rac_dbs           c
        ,pdbs                      d
WHERE    d.cdb_target_guid = x1.db_target_guid  (+)
AND      d.cdb_target_guid = x2.rac_target_guid (+)
AND      d.cdb_target_guid = c.rac_target_guid  (+)
) t;

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_pdb.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
