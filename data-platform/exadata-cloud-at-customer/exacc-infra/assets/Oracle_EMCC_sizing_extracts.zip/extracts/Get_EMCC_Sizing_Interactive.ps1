#---------------------------------------------------------------------------------------------------
# Remove the need for the customer to modifiy the scripts, and ensure that only SQL*Plus 12.2 or
# higher is used to run the SQL scripts, check for errors
#---------------------------------------------------------------------------------------------------
#
# Usage  : Get_EMCC_Sizing_Interactive.ps1 [ConnectData] [SQLPlusPath]
# Example: Get_EMCC_Sizing_Interactive.ps1 UserName/Password@ConnectString $ORACLE_HOME
#
# Requirements: Powershell 3.0 or higher
#
# Version History
# 2022-08-09  2.12  pro  Add Get_EMCC_Sizing_EM_Release.sql script
# 2022-08-08  2.11  pro  Get EMMajor and EMMinor and branch DB_DR.sql per EM version
# 2022-03-13  2.10  pro  Add Show-Banner function
# 2022-03-07  2.9   pro  Improve account execution text
# 2022-10-07  2.8   pro  Add new function to capture EM Repository version
# 2022-05-05  2.7   mgr  Add new script to capture list of EM jobs
# 2022-03-24  2.6   mgr  Add new script to capture list of EM metrics
# 2021-05-04  2.5   mgr  Remove Diagnostics Pack Requirement per MOS Note: 2771065.1
# 2021-04-12  2.4   mgr  Add new SQL script
# 2021-03-16  2.3   mgr  Script Name Change
# 2021-03-15  2.2   mgr  Add Diagnostics Pack Disclaimer & Prompt
# 2021-03-02  2.1   mgr  Sync up logic and flow to BASH Script
# 2021-02-12  1.0   mgr  First version
#---------------------------------------------------------------------------------------------------

# Required data can be provided on the command line, username/password@connectstring & SQL*Plus
# 12.2 or higher Home
Param(
	[Parameter(Position=0)][String[]]$Connect,
	[Parameter(Position=1)][String[]]$SQLPath
)

# Set the extract version
$ExtractVersion="2.14"

# Print Diagnostics Pack Disclaimier
Write-Host "`nThis script queries views licensed by the Oracle Diagnostics Pack;"
Write-Host "however, the license is not required per MOS Note: 2771065.1`n"

# Set some Defaults
$ExtractSQL = "."
$Env:EXTRACT_SQL = "$ExtractSQL"
$Env:NLS_LANG = "AMERICAN_AMERICA"

$OutputDir = ".\emcc_sizing_extracts"

$SQLScripts = "Get_EMCC_Sizing_EM_Release.sql", `
	"Get_EMCC_Sizing_DB_DR.sql", `
	"Get_EMCC_Sizing_DB_Params.sql", `
	"Get_EMCC_Sizing_DB_Props.sql", `
	"Get_EMCC_Sizing_DB_Services.sql", `
	"Get_EMCC_Sizing_DB_SGA.sql", `
	"Get_EMCC_Sizing_Host_Props.sql", `
	"Get_EMCC_Sizing_PDB_Params.sql", `
	"Get_EMCC_Sizing_PDB_Props.sql", `
	"Get_EMCC_Sizing_DB_Redo.sql", `
	"Get_EMCC_Sizing_PDB_SGA.sql", `
	"Get_EMCC_Sizing_Structure_DB.sql", `
	"Get_EMCC_Sizing_Structure_DB_VM.sql", `
	"Get_EMCC_Sizing_Structure_Host_CPU.sql", `
	"Get_EMCC_Sizing_Structure_Host_VM.sql", `
	"Get_EMCC_Sizing_Structure_PDB.sql", `
	"Get_EMCC_Sizing_Structure_VM.sql", `
	"Get_EMCC_Sizing_Availability_History.sql", `
	"Get_EMCC_Sizing_EM_Jobs.sql", `
	"Get_EMCC_Sizing_EM_Metrics.sql", `
	"Get_EMCC_Sizing_Metrics_DB_daily_03_months.sql", `
	"Get_EMCC_Sizing_Metrics_DB_daily_06_months.sql", `
	"Get_EMCC_Sizing_Metrics_DB_daily_09_months.sql", `
	"Get_EMCC_Sizing_Metrics_DB_daily_12_months.sql", `
	"Get_EMCC_Sizing_Metrics_Host_daily_03_months.sql", `
	"Get_EMCC_Sizing_Metrics_Host_daily_06_months.sql", `
	"Get_EMCC_Sizing_Metrics_Host_daily_09_months.sql", `
	"Get_EMCC_Sizing_Metrics_Host_daily_12_months.sql", `
	"Get_EMCC_Sizing_Metrics_PDB_daily_03_months.sql", `
	"Get_EMCC_Sizing_Metrics_PDB_daily_06_months.sql", `
	"Get_EMCC_Sizing_Metrics_PDB_daily_09_months.sql", `
	"Get_EMCC_Sizing_Metrics_PDB_daily_12_months.sql", `
	"Get_EMCC_Sizing_Metrics_Host_hourly_03_months.sql", `
	"Get_EMCC_Sizing_Metrics_DB_hourly_03_months.sql", `
	"Get_EMCC_Sizing_Metrics_PDB_hourly_03_months.sql"

#---------------------------------------------------------------------------------------------------
# This script should live in the "extras" directory but should not be run from there.
# If started from "extras" directory, automatically change to the parent directory.
#---------------------------------------------------------------------------------------------------
if ( (Get-Location).path -like "*\extras" ) {
	Set-Location -Path ..
	$NewDir = (Get-Location).path
	Write-Host "INFO: Changing Directory to: $NewDir`n"
}


#---------------------------------------------------------------------------------------------------
# Function   : Confirm-Release
# Description: Check the version of the SQL*Plus command to make sure it meets the requirements
#---------------------------------------------------------------------------------------------------
function Confirm-Release($Command) {
	
	$Arg = "-V"
	$Banner = &$Command $Arg

	$null, $null, $null, $Release, $null = $Banner.split(" ")
	$Major, $Minor, $null = $Release.split(".")
	if (( $Major -match '^[0-9]+$' ) -and (( $Major -gt 12 ) -or ( $Major -eq 12 -and $Minor -gt 1 ))) {
		# Version is good
		$RC = "0"
	}
	elseif (( $Major -match '^[0-9]+$' ) -and (( $Major -lt 12 ) -or ( $Major -eq 12 -and $Minor -lt 2 ))) {
		# Version too low
		$RC = "1"
	}
	else {
		# Version Check Failed
		$RC = "2"
	}
	
	return $RC
}

#---------------------------------------------------------------------------------------------------
# Function   : Confirm-Connect
# Description: Make sure we can get connected to the Database before blasting the scripts at it.
#---------------------------------------------------------------------------------------------------
function Confirm-Connect($Command, $CString) {

	$SQLScript = @"
		set echo off tab off trim on trimspool on feedback off verify off heading off timing off;
		connect $CString
		exit;
"@

	$SQLScript | &$Command --% /NOLOG

}

#---------------------------------------------------------------------------------------------------
# Function   : Get-EM-Release
# Description: Check the version of the Enterpise Manager Repository
#---------------------------------------------------------------------------------------------------
function Get-EM-Release($Command, $CString) {

	$Arg = "-S"

	$SQLScript = @"
		set echo off tab off trim on trimspool on feedback off verify off heading off timing off
		select version from sysman.mgmt_versions where component_name = 'CORE';
		exit;
"@

	$sqlOutput = $SQLScript | &$Command $Arg $CString

	if (-not [string]::IsNullOrWhiteSpace($sqlOutput)) {
		# Trim spaces on the value
		$null,$EMRelease = $sqlOutput.split(" ")

		# Get the major release version
		$EMMajor, $EMMinor, $null = $EMRelease.split(".")
	}
	else {
		$EMMajor = $null
		$EMMinor = $null
	}

	return $EMMajor,$EMMinor
}

#---------------------------------------------------------------------------------------------------
# Function   : Show-Banner
# Description:  Prints the tool banner to stdout
#---------------------------------------------------------------------------------------------------
function Show-Banner() {

	Write-Host "+--------------------------------------------------------------------+"
	Write-Host "|  ###   ###  ###   ####                                             |"
	Write-Host "| #   # #    #     #   #     _         _                             |"
	Write-Host "| #   # #    #    ######    |_  |\/|  |_)   |\/|  o   _    _   ,_    |"
	Write-Host "|  ###  ###  ### ##   ##    |_  |  |  | |   |  |  |  | |  (/_  |     |"
	Write-Host "+--------------------------------------------------------------------+"
	Write-Host "`nEMR-Miner Version ${ExtractVersion}"
	Write-Host "Collects metrics and statistics from Enterprise Manager Repository (EMR).`n"
	Write-Host "`n"
}

#---------------------------------------------------------------------------------------------------
# Display the Tool banner
#---------------------------------------------------------------------------------------------------
Show-Banner

#---------------------------------------------------------------------------------------------------
# Find a version of SQL*Plus that will work, using the precedense as follows
#---------------------------------------------------------------------------------------------------
# 1) Provided on Command Line, fail if not ok
# 2) Command found in PATH, skip to next if not ok
# 3) Prompt User for Path, fail if not ok
#---------------------------------------------------------------------------------------------------
$SQLPlus = $null
$P1 = "\sqlplus.exe"
$P2 = "\bin\sqlplus.exe"

if (-not [string]::IsNullOrWhiteSpace($SQLPath))
{
	if ((Get-Command $SQLPath -ErrorAction SilentlyContinue) -ne $null) {
		$SQLCmd = $SQLPath
	} 
	elseif ((Get-Command $SQLPath$P1 -ErrorAction SilentlyContinue) -ne $null) {
		$SQLCmd = "$SQLPath$P1"
	}
	elseif ((Get-Command $SQLPath$P2 -ErrorAction SilentlyContinue) -ne $null) {
		$SQLCmd = "$SQLPath$P2"
	} 	
	if ( $SQLCmd -eq $null ) {
		Write-Host "ERROR: SQL*Plus Command Not Found in Path: '$SQLPath'"
		Write-Host "Please try again with a different path containing a valid SQL*Plus"
		exit 
	}
	else {
		$RelRC = Confirm-Release $SQLCmd 
		if ( $RelRC -eq "0" ) {
			Write-Host "SUCCESS: SQL*Plus Command Found and Version is good: '${SQLCmd}'"
			$SQLPlus = $SQLCmd
		}
		elseif ( $RelRC -eq "1" ) {
			Write-Host "ERROR: Command Found, but the version is too low, must be 12.2 or higher: '${SQLCmd}'"
			Write-Host "Please try again with a different path containing a valid SQL*Plus"
			exit
		}
		else {
			Write-Host "ERROR: Command Found, but the version check failed: '${SQLCmd}'"
			Write-Host "Please try again with a different path containing a valid SQL*Plus"
			exit
		}
	}
}

# If we don't have it yet, Check Environment for Path to the command
if ( [string]::IsNullOrWhiteSpace($SQLPlus)) {
	$SQLCmd = (Get-Command "sqlplus.exe" -ErrorAction SilentlyContinue).Source
	if ( [string]::IsNullOrWhiteSpace($SQLCmd) -eq $false ) {
		$RelRC = Confirm-Release $SQLCmd 
		if ( $RelRC -eq "0" ) {
			Write-Host "SUCCESS: SQL*Plus Command Found and Version is good: '${SQLCmd}'"
			$SQLPlus = $SQLCmd
		}
	}
}

# Last resort is to Prompt the user for the Path
if ( [string]::IsNullOrWhiteSpace($SQLPlus)) {
	Write-Host "`nSQL*Plus version 12.2 or higer is required!"
	$Value = read-host "Enter Path to SQL*Plus Command"
	$Value = $Value.Trim()
	if ((Get-Command $Value -ErrorAction SilentlyContinue) -ne $null) {
		$SQLCmd = $Value
	} 
	elseif ((Get-Command $Value$P1 -ErrorAction SilentlyContinue) -ne $null) {
		$SQLCmd = "$Value$P1"
	}
	elseif ((Get-Command $Value$P2 -ErrorAction SilentlyContinue) -ne $null) {
		$SQLCmd = "$Value$P2"
	} 
	else {
		Write-Host "ERROR: SQL*Plus Not Found in: '${Value}'"
		Write-Host "Please check values and try again!"
		exit
	}
	$RelRC = Confirm-Release $SQLCmd 
	if ( $RelRC -eq "0" ) {
		Write-Host "SUCCESS: SQL*Plus Command Found and Version is good: ${SQLCmd}"
		$SQLPlus = $SQLCmd
	}
	elseif ( $RelRC -eq "1" ) {
		Write-Host "ERROR: Command Found, but the version is too low, must be 12.2 or higher: ${SQLCmd}"
		Write-Host "Please try again with a different path containing a valid SQL*Plus"
		exit
	}
	else {
		Write-Host "ERROR: Command Found, but the version check failed: ${SQLCmd}"
		Write-Host "Please try again with a different path containing a valid SQL*Plus"
		exit
	}
}

#---------------------------------------------------------------------------------------------------
# If connection data was not provided on the command line, prompt for it here
#---------------------------------------------------------------------------------------------------
if ( [string]::IsNullOrWhiteSpace($Connect) ) {
	Write-Host "`nEnter Enterprise Manager Repository Database Connection Data"
	Write-Host "The following are examples for the syntaxes you may use"
	Write-Host "   EZCONNECT: username/password@hostname:port/service_name"
	Write-Host "   TNSNAMES : username/password@tnsnames_alias`n"
	Write-Host "   Note: The User must have the MGMT_USER role, SELECT ANY TABLE privilege or have SYSMAN privileges\n"
	$Connect = Read-Host "`nEnter Connection Data" -AsSecureString
	$Connect = $Connect.Trim()
	if ( [string]::IsNullOrWhiteSpace($Connect) ) {
		Write-Host "ERROR: Nothing Found in: '$Connect'"
		Write-Host "Please check values and try again!"
		exit
	}
}

# Verify that the SQL*Plus command and Connection data works
$Result = Confirm-Connect $SQLPlus $Connect
if ( Select-String -inputObject $Result -Pattern "Connected." ) {
	Write-Host "SUCCESS: Test Connection to Database Succeeded!"
} else {
	Write-Host "ERROR: Test Connection Failed, please review following Command and Connect Data and try again!"
	Write-Host "   SQL*Plus Command: $SQLPlus"
	Write-Host "   Connection Data : $Connect"
	exit
}

# Create the Output Directory if it doesn't exist
if (-not (Test-Path $OutputDir -PathType Container)) {
	try {
		New-Item -Path $OutputDir -ItemType Directory -ErrorAction Stop | Out-Null #-Force
	}
	catch {
		Write-Error -Message "ERROR: Failed to Create Output Directory: '$OutputDir'. Error was: $_" -ErrorAction Stop
	}
	Write-Host "SUCCESS: Output Directory Created: $OutputDir"
}

# Get EM Repository Release
$EMMajor,$EMMinor = Get-EM-Release $SQLPlus $Connect

function wrapper_to_alter_session {
    param (
        [string]$Script,
        [string]$Connect,
        [string]$ExtractSQL
    )

    # Rule for Get_EMCC_Sizing_Structure_DB.sql on EM12 versions
    if ($Script -eq 'Get_EMCC_Sizing_Structure_DB.sql') {
        if ($EMMajor -lt 13) {
            $Script = "Get_EMCC_Sizing_Structure_DB_EM12.sql"
        }
    }

    # Rule for Get_EMCC_Sizing_DB_DR.sql on EM13.5 versions and higher
    elseif ($Script -eq 'Get_EMCC_Sizing_DB_DR.sql') {
        if ($EMMajor -eq 13 -and $EMMinor -ge 5) {
            $Script = "Get_EMCC_Sizing_DB_DR_EM13_5.sql"
        }
    }

#     ALTER SESSION SET nls_numeric_characters = '@!'; #test purposes to make sure this func works
    # Create the SQL command
    $sqlCommand = @"
    set feedback off;
    ALTER SESSION SET nls_language = 'American';
    ALTER SESSION SET nls_territory = 'America';
    ALTER SESSION SET nls_calendar = 'Gregorian';
    ALTER SESSION SET nls_date_language = 'American';
    ALTER SESSION SET nls_date_format = 'YYYY-MM-DD HH24:MI:SS';
    ALTER SESSION SET nls_timestamp_format = 'YYYY-MM-DD HH24:MI:SS';
    alter session set nls_numeric_characters = ".,";
    ALTER SESSION SET nls_length_semantics = 'BYTE';

    @$ExtractSQL/$Script

"@
   echo $sqlCommand | &$SQLPlus -s $Connect
}

# Run each SQL script against the EM Repository Database
Write-Host "`nStarting Extract Scripts!`n"
$I = 0
foreach ($Script in $SQLScripts) {
    $I += 1
    wrapper_to_alter_session -Script $Script -Connect $Connect -ExtractSQL $ExtractSQL 2>&1 | Out-String | findstr /i /v /C:"emcc_sizing_extracts already exists"

}

# Remind the user of the Next Steps, if successful otherwise warn about errors
if ( $ErrCnt -eq 0 ) {
	Write-Host "`nSUCCCESS: No Errors were found in the output files!"
	Write-Host "`nNext Step: bundle up the output directory, for example:"
	Write-Host "   zip -r emcc_sizing_extracts_oem1.zip emcc_sizing_extracts"
	Write-Host "`nFinal Step: please upload the bundle to location provided by your Oracle contact"
} else {
	Write-Host "`nERROR: Above error(s) where reported, if correctable, please correct and re-run,"
	Write-Host "       otherwise contact your Oracle contact for assistance!"
}
