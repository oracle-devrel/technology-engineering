rem
rem Version 2.0
define __version__ = 2.0
rem

rem Version History
rem
rem 2023-04-28    2.0   pro     Add check on dg_connect_identifier for 'PRIMARY' targets
rem 2023-03-23    1.9   pro     Add active_stby=YES in the 'PHYSICAL STANDBY' target query
rem 2021-02-08    1.8   tmf     Removed -p to be Windows friendly
rem 2020-12-15    1.7   tmf     Added timing off
rem 2020-11-19    1.6   tmf     Added capture of SQL*Plus version
rem 2020-11-05    1.5   tmf     mkdir -p
rem 2020-04-18    1.4   tmf     Added timing capture
rem 2020-04-08    1.3   tmf     Corrected column labels
rem 2020-04-02    1.2   tmf     DR for HA
rem 2020-04-02    1.1   tmf     First version
rem

rem ********************************************************************************************************************
rem
rem Please be sure this is run via SQL*Plus 12.2 or greater while connected to the database as a user that
rem that has read access to the Enterprise Manager reporting views, e.g. sysman.mgmt$target and sysman.mgmt$metric_daily
rem
rem ********************************************************************************************************************

prompt Extracting DB HA relationships...
prompt

set echo off term off pagesize 0 trim on trimspool on newpage none head off feed off verify off timing off
set markup csv on

host mkdir emcc_sizing_extracts

spool emcc_sizing_extracts/emcc_sizing_structure_db_dr.txt

col dttm for a30

define _SQLPLUS_RELEASE
define _O_VERSION
define __version__
prompt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

spool emcc_sizing_extracts/emcc_sizing_structure_db_dr.csv

prompt "STDBY_TARGET_NAME","STDBY_TARGET_TYPE","PRI_DB_UNIQUE_NAME","PRI_TARGET_NAME","PRI_TARGET_TYPE","PROTECTION_MODE","STDBY_TARGET_GUID","PRI_TARGET_GUID","EXTRACT_DTTM_UTC"

WITH s AS
(
SELECT   DISTINCT t.target_name, t.target_type, t.target_guid
        ,d.role, d.db_unique_name, d.prmy_db_unique_name
FROM     sysman.mgmt$target               t
        ,sysman.mgmt$ha_dg_target_summary d
WHERE    d.target_guid = t.target_guid (+)
AND      d.role        = 'PHYSICAL STANDBY'
)
,
p AS (
SELECT   DISTINCT t.target_name, t.target_type, t.target_guid
        ,d.role, d.db_unique_name, d.prmy_db_unique_name, d.protection_mode
FROM     sysman.mgmt$target               t
        ,sysman.mgmt$ha_dg_target_summary d
WHERE    d.target_guid = t.target_guid (+)
AND      d.role        = 'PRIMARY'
AND      d.dg_connect_identifier is not null
)
SELECT s.target_name         AS stdby_target_name
      ,s.target_type         AS stdby_target_type
      ,s.prmy_db_unique_name AS pri_db_unique_name
      ,p.target_name         AS pri_target_name
      ,p.target_type         AS pri_target_type
      ,p.protection_mode     AS protection_mode
      ,s.target_guid         AS stdby_target_guid
      ,p.target_guid         AS pri_target_guid
      ,TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD HH24:MI:SS') AS extract_dttm_utc
FROM   p, s
WHERE  s.prmy_db_unique_name = p.db_unique_name (+)
ORDER BY s.target_name, s.target_type;

spool off

spool emcc_sizing_extracts/emcc_sizing_structure_db_dr.txt append

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS dttm FROM sys.DUAL;

exit
