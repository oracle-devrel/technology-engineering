Obfucate AWR Readme
================================================================================
Data Obfuscation can be used when server names, database names, owners, etc. can't be shared with Oracle.

Prerequisites
--------------------------------------------------------------------------------
   1) python 3: 3.6 or higher
   3) AWR Collection data set

Run Obfuscation script
--------------------------------------------------------------------------------
    1) Open a terminal window and change directory to the extracts directory that contains both the awr_miner_out directory and the
    Obfuscate_Awr.py file.

    2) Verify the correct Python command to run version 3 of Python, on some systems Python 3 may be installed as "python3".

    3) At the command prompt and using the current Python command type: python3 Obfuscate_Awr.py

    4) You will see a series of messages as the scripts obfuscate the contents of the awr collection files.

    5) The obfuscated files are written to a new directory named awr_miner_out_obfuscated.  A new file will also be created that
    translates the original values to the obfuscated values, it is written to the awr_obfuscated_translation.csv file in the
    awr_miner_occa directory. Make sure and keep a copy of this file as it may be required to answer questions from Oracle.

    6) Zip up the contents of the awr_miner_out_obfuscated directory and upload to Oracle for analysis.