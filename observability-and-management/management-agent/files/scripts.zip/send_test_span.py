from opentelemetry.trace import SpanKind, Status, StatusCode
from pathlib import Path
import sys


ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from app.config import get_settings
from app.telemetry import configure_tracing, get_tracer


def main() -> None:
    settings = get_settings()
    configure_tracing(settings)
    tracer = get_tracer()

    with tracer.start_as_current_span(
        "marketplace.otel.test",
        kind=SpanKind.INTERNAL,
        attributes={
            "app.feature": "observability_setup",
            "app.test": True,
        },
    ) as span:
        span.set_status(Status(StatusCode.OK))
        print(
            {
                "trace_id": format(span.get_span_context().trace_id, "032x"),
                "exporter": "oci-apm-otlp-http"
                if settings.oci_apm_data_upload_endpoint and settings.oci_apm_private_data_key
                else "console",
            }
        )


if __name__ == "__main__":
    main()
