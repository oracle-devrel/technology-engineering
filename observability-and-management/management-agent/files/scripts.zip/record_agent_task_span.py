from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import sys

from opentelemetry import trace
from opentelemetry.trace import SpanKind, Status, StatusCode


ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from app.config import get_settings
from app.telemetry import configure_tracing, get_tracer


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Emit one high-level Codex agent task span to OCI APM."
    )
    parser.add_argument("--agent-role", default="Coordinator")
    parser.add_argument("--agent-name", default="")
    parser.add_argument("--task", required=True)
    parser.add_argument(
        "--status",
        default="succeeded",
        choices=("started", "succeeded", "failed", "skipped"),
    )
    parser.add_argument("--summary", default="")
    parser.add_argument("--target", default="3d-marketplace")
    parser.add_argument(
        "--service-name",
        default=os.getenv("AI_AGENT_OTEL_SERVICE_NAME", "AIAgent"),
        help="OpenTelemetry service.name for Codex agent spans.",
    )
    parser.add_argument(
        "--attribute",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Additional span attribute. Can be passed multiple times.",
    )
    args = parser.parse_args()

    settings = get_settings()
    settings.otel_service_name = args.service_name
    configure_tracing(settings)
    tracer = get_tracer()
    agent_name = args.agent_name or f"{args.agent_role} Agent"
    span_name = f"codex.agent.task.{normalize_operation_part(args.agent_role)}"
    attributes = {
        "app.agent.runtime": "codex-session",
        "app.agent.span.level": "high",
        "app.agent.operation.name": span_name,
        "app.agent.name": agent_name,
        "app.agent.role": args.agent_role,
        "app.agent.task.title": args.task,
        "app.agent.task.status": args.status,
        "app.agent.task.target": args.target,
        "app.agent.task.summary": args.summary,
        "app.repository.path": str(ROOT_DIR),
        "Agent Name": agent_name,
        "Agent Role": args.agent_role,
        "Agent Task": args.task,
        "Agent Task Status": args.status,
    }
    attributes.update(parse_attributes(args.attribute))

    with tracer.start_as_current_span(
        span_name,
        kind=SpanKind.INTERNAL,
        attributes=attributes,
    ) as span:
        if args.status == "failed":
            span.set_status(
                Status(StatusCode.ERROR, args.summary or "Agent task failed.")
            )
        else:
            span.set_status(Status(StatusCode.OK))

        trace_id = format(span.get_span_context().trace_id, "032x")
        span_id = format(span.get_span_context().span_id, "016x")

    provider = trace.get_tracer_provider()
    force_flush = getattr(provider, "force_flush", None)
    if callable(force_flush):
        force_flush(timeout_millis=10000)

    print(
        {
            "span": span_name,
            "trace_id": trace_id,
            "span_id": span_id,
            "exporter": "oci-apm-otlp-http"
            if settings.oci_apm_data_upload_endpoint and settings.oci_apm_private_data_key
            else "console",
        }
    )
    return 0


def normalize_operation_part(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9_.-]+", ".", value.strip())
    normalized = normalized.strip(".")
    return normalized[:80] or "Unknown"


def parse_attributes(values: list[str]) -> dict[str, str]:
    attributes = {}

    for value in values:
        if "=" not in value:
            raise SystemExit(f"Invalid --attribute value: {value}. Use KEY=VALUE.")

        key, attribute_value = value.split("=", 1)
        key = key.strip()

        if not key:
            raise SystemExit("Attribute key cannot be empty.")

        attributes[key[:120]] = attribute_value[:240]

    return attributes


if __name__ == "__main__":
    raise SystemExit(main())
