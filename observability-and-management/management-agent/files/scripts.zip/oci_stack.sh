#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
STACK_DIR="${ROOT_DIR}/infra/oci"
ACTION="${1:-plan}"
VAR_FILE="${VAR_FILE:-terraform.tfvars}"
if [[ "$#" -gt 0 ]]; then
  shift
fi

usage() {
  cat <<'USAGE'
Usage: bash scripts/oci_stack.sh <action>

Actions:
  init       Initialize the OCI OpenTofu/Terraform stack.
  fmt        Format stack files.
  validate   Validate stack syntax after init.
  plan       Show the infrastructure plan.
  apply      Apply the infrastructure plan.
  destroy    Destroy the managed infrastructure.
  output     Show stack outputs.

Environment:
  TF_BIN=/path/to/tofu-or-terraform    Override tool selection.
  VAR_FILE=custom.tfvars               Override terraform.tfvars.
USAGE
}

find_tf_bin() {
  if [[ -n "${TF_BIN:-}" ]]; then
    printf '%s' "${TF_BIN}"
    return
  fi

  if command -v tofu >/dev/null 2>&1; then
    printf 'tofu'
    return
  fi

  if command -v terraform >/dev/null 2>&1; then
    printf 'terraform'
    return
  fi

  echo "Install OpenTofu or Terraform, or set TF_BIN." >&2
  exit 1
}

if [[ "${ACTION}" == "--help" || "${ACTION}" == "-h" ]]; then
  usage
  exit 0
fi

TF_BIN_RESOLVED="$(find_tf_bin)"

case "${ACTION}" in
  init)
    cd "${STACK_DIR}"
    "${TF_BIN_RESOLVED}" init
    ;;
  fmt)
    cd "${STACK_DIR}"
    "${TF_BIN_RESOLVED}" fmt -recursive
    ;;
  validate)
    cd "${STACK_DIR}"
    "${TF_BIN_RESOLVED}" validate
    ;;
  plan)
    cd "${STACK_DIR}"
    "${TF_BIN_RESOLVED}" plan -var-file="${VAR_FILE}" "$@"
    ;;
  apply)
    cd "${STACK_DIR}"
    "${TF_BIN_RESOLVED}" apply -var-file="${VAR_FILE}" "$@"
    ;;
  destroy)
    cd "${STACK_DIR}"
    "${TF_BIN_RESOLVED}" destroy -var-file="${VAR_FILE}" "$@"
    ;;
  output)
    cd "${STACK_DIR}"
    "${TF_BIN_RESOLVED}" output
    ;;
  *)
    echo "Unknown action: ${ACTION}" >&2
    usage >&2
    exit 1
    ;;
esac
