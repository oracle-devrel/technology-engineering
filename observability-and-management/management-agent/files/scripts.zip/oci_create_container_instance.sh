#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build/oci"

load_env_file() {
  local file="$1"

  if [[ ! -f "${file}" ]]; then
    return
  fi

  while IFS= read -r line || [[ -n "${line}" ]]; do
    line="${line#"${line%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"

    if [[ -z "${line}" || "${line}" == \#* || "${line}" != *=* ]]; then
      continue
    fi

    local key="${line%%=*}"
    local value="${line#*=}"
    key="${key#"${key%%[![:space:]]*}"}"
    key="${key%"${key##*[![:space:]]}"}"

    if [[ ! "${key}" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]]; then
      continue
    fi

    if [[ -z "${!key+x}" ]]; then
      export "${key}=${value}"
    fi
  done < "${file}"
}

require_env() {
  local missing=0

  for key in "$@"; do
    if [[ -z "${!key:-}" ]]; then
      echo "Missing required environment value: ${key}" >&2
      missing=1
    fi
  done

  if [[ "${missing}" -ne 0 ]]; then
    echo "Copy .env.oci.example to .env.oci.local and fill in the missing values." >&2
    exit 1
  fi
}

load_env_file "${ROOT_DIR}/.env.oci.local"
load_env_file "${ROOT_DIR}/.env.local"
load_env_file "${ROOT_DIR}/.env"

require_env \
  OCI_REGION \
  OCI_COMPARTMENT_OCID \
  OCI_AVAILABILITY_DOMAIN \
  OCI_CONTAINER_INSTANCE_SHAPE \
  OCI_CONTAINER_INSTANCE_DISPLAY_NAME

if ! command -v oci >/dev/null 2>&1; then
  echo "oci CLI is not installed or not on PATH." >&2
  exit 1
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"

echo "Rendering OCI Container Instance JSON into ${BUILD_DIR}"
"${PYTHON_BIN}" "${ROOT_DIR}/scripts/oci_render_container_instance_config.py"

OCI_ARGS=(
  --profile "${OCI_PROFILE:-DEFAULT}"
  --region "${OCI_REGION}"
  container-instances container-instance create
  --compartment-id "${OCI_COMPARTMENT_OCID}"
  --availability-domain "${OCI_AVAILABILITY_DOMAIN}"
  --shape "${OCI_CONTAINER_INSTANCE_SHAPE}"
  --shape-config "file://${BUILD_DIR}/shape_config.json"
  --containers "file://${BUILD_DIR}/containers.json"
  --vnics "file://${BUILD_DIR}/vnics.json"
  --container-restart-policy "${OCI_CONTAINER_RESTART_POLICY:-ALWAYS}"
  --display-name "${OCI_CONTAINER_INSTANCE_DISPLAY_NAME}"
  --graceful-shutdown-timeout-in-seconds "${OCI_GRACEFUL_SHUTDOWN_SECONDS:-30}"
  --wait-for-state SUCCEEDED
)

if [[ -s "${BUILD_DIR}/image_pull_secrets.json" ]]; then
  OCI_ARGS+=(--image-pull-secrets "file://${BUILD_DIR}/image_pull_secrets.json")
fi

echo "Creating OCI Container Instance ${OCI_CONTAINER_INSTANCE_DISPLAY_NAME}"
oci "${OCI_ARGS[@]}"
