from __future__ import annotations

import argparse
import http.cookiejar
import os
from pathlib import Path
import sys
from time import perf_counter, sleep
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urljoin
from urllib.request import HTTPCookieProcessor, Request, build_opener

from opentelemetry import trace
from opentelemetry.propagate import inject
from opentelemetry.trace import SpanKind, Status, StatusCode


ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from app.config import get_settings
from app.telemetry import configure_tracing, get_tracer


DEFAULT_BASE_URL = "http://127.0.0.1:8000"
USER_AGENT = "3d-marketplace-synthetic-apm/1.0"


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Run a synthetic marketplace journey and export OpenTelemetry spans "
            "to OCI APM while also creating backend workload on the website."
        )
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("SYNTHETIC_BASE_URL")
        or os.getenv("APP_BASE_URL")
        or DEFAULT_BASE_URL,
        help="Website base URL, for example http://130.61.191.215:8000.",
    )
    parser.add_argument("--iterations", type=int, default=3)
    parser.add_argument("--interval-seconds", type=float, default=30)
    parser.add_argument("--timeout-seconds", type=float, default=15)
    parser.add_argument(
        "--service-name",
        default=os.getenv("SYNTHETIC_OTEL_SERVICE_NAME", "SyntheticTest"),
        help="OpenTelemetry service.name used for synthetic client spans.",
    )
    parser.add_argument("--journey-name", default="catalog_quote_history")
    parser.add_argument("--username", default=os.getenv("SYNTHETIC_USERNAME", "esciunzi"))
    parser.add_argument("--password", default=os.getenv("SYNTHETIC_PASSWORD", "Welcome01"))
    parser.add_argument("--project-id", default=os.getenv("SYNTHETIC_PROJECT_ID", "desk-organizer"))
    parser.add_argument("--area-id", default=os.getenv("SYNTHETIC_AREA_ID", "milan"))
    parser.add_argument(
        "--printer-id",
        default=os.getenv("SYNTHETIC_PRINTER_ID", "milan-maker-lab"),
    )
    parser.add_argument("--material", default=os.getenv("SYNTHETIC_MATERIAL", "PLA"))
    parser.add_argument("--finish", default=os.getenv("SYNTHETIC_FINISH", "Standard"))
    parser.add_argument("--color", default=os.getenv("SYNTHETIC_COLOR", "Natural White"))
    parser.add_argument(
        "--skip-login",
        action="store_true",
        help="Run only anonymous health, home, and quote checks.",
    )
    parser.add_argument(
        "--attribute",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Additional root span attribute. Can be passed multiple times.",
    )
    args = parser.parse_args()

    if args.iterations < 1:
        raise SystemExit("--iterations must be at least 1.")

    settings = get_settings()
    settings.otel_service_name = args.service_name
    configure_tracing(settings)
    tracer = get_tracer()

    base_url = normalize_base_url(args.base_url)
    root_attributes = parse_attributes(args.attribute)
    failures = 0

    for iteration in range(1, args.iterations + 1):
        result = run_iteration(tracer, args, base_url, iteration, root_attributes)
        failures += result["failures"]

        if iteration < args.iterations and args.interval_seconds > 0:
            sleep(args.interval_seconds)

    force_flush()
    return 1 if failures else 0


def run_iteration(
    tracer,
    args,
    base_url: str,
    iteration: int,
    extra_attributes: dict[str, str],
) -> dict[str, int]:
    opener = build_opener(HTTPCookieProcessor(http.cookiejar.CookieJar()))
    span_name = f"synthetic.journey.{args.journey_name}"
    trace_id = ""
    results: list[dict[str, object]] = []

    attributes = {
        "synthetic.test.name": args.journey_name,
        "synthetic.iteration": iteration,
        "synthetic.base_url": base_url,
        "synthetic.skip_login": args.skip_login,
        "app.synthetic": True,
        "app.project.id": args.project_id,
        "app.area.id": args.area_id,
        "app.printer.id": args.printer_id,
        "app.quote.material": args.material,
        "app.quote.finish": args.finish,
        "app.quote.color": args.color,
        "enduser.name": args.username if not args.skip_login else "anonymous",
        "User name": args.username if not args.skip_login else "anonymous",
    }
    attributes.update(extra_attributes)

    with tracer.start_as_current_span(span_name, kind=SpanKind.INTERNAL, attributes=attributes) as span:
        try:
            results.append(
                synthetic_request(
                    tracer,
                    opener,
                    "synthetic.http.health",
                    "GET",
                    urljoin(base_url, "/health"),
                    args.timeout_seconds,
                    attributes={"synthetic.step": "health"},
                )
            )
            results.append(
                synthetic_request(
                    tracer,
                    opener,
                    "synthetic.http.home",
                    "GET",
                    build_home_url(base_url, args.project_id, args.area_id),
                    args.timeout_seconds,
                    attributes={"synthetic.step": "home"},
                )
            )
            if not args.skip_login:
                results.append(
                    synthetic_request(
                        tracer,
                        opener,
                        "synthetic.http.login",
                        "POST",
                        urljoin(base_url, "/login"),
                        args.timeout_seconds,
                        form_data={"username": args.username, "password": args.password},
                        attributes={
                            "synthetic.step": "login",
                            "enduser.name": args.username,
                        },
                    )
                )
            results.append(
                synthetic_request(
                    tracer,
                    opener,
                    "synthetic.http.quote",
                    "POST",
                    urljoin(base_url, "/quote"),
                    args.timeout_seconds,
                    form_data={
                        "project_id": args.project_id,
                        "area_id": args.area_id,
                        "printer_id": args.printer_id,
                        "material": args.material,
                        "finish": args.finish,
                        "color": args.color,
                    },
                    attributes={
                        "synthetic.step": "quote",
                        "app.project.id": args.project_id,
                        "app.area.id": args.area_id,
                        "app.printer.id": args.printer_id,
                    },
                )
            )
            if not args.skip_login:
                results.append(
                    synthetic_request(
                        tracer,
                        opener,
                        "synthetic.http.orders_history",
                        "GET",
                        urljoin(base_url, "/orders/history"),
                        args.timeout_seconds,
                        attributes={
                            "synthetic.step": "orders_history",
                            "enduser.name": args.username,
                        },
                    )
                )
        except Exception as error:
            span.record_exception(error)
            span.set_status(Status(StatusCode.ERROR, str(error)))
            raise
        finally:
            failed_results = [
                result for result in results if result["status_code"] >= 400 or result["error"]
            ]
            span.set_attribute("synthetic.request.count", len(results))
            span.set_attribute("synthetic.request.failure_count", len(failed_results))
            span.set_status(
                Status(
                    StatusCode.ERROR if failed_results else StatusCode.OK,
                    f"{len(failed_results)} synthetic requests failed" if failed_results else "",
                )
            )
            trace_id = format(span.get_span_context().trace_id, "032x")

    print_iteration_summary(iteration, trace_id, results)
    return {
        "failures": len(
            [result for result in results if result["status_code"] >= 400 or result["error"]]
        )
    }


def synthetic_request(
    tracer,
    opener,
    span_name: str,
    method: str,
    url: str,
    timeout_seconds: float,
    form_data: dict[str, str] | None = None,
    attributes: dict[str, object] | None = None,
) -> dict[str, object]:
    headers = {"User-Agent": USER_AGENT}
    body = None
    if form_data is not None:
        body = urlencode(form_data).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"

    span_attributes = {
        "http.method": method,
        "http.request.method": method,
        "url.full": url,
        "user_agent.original": USER_AGENT,
        "app.synthetic": True,
    }
    if attributes:
        span_attributes.update(attributes)

    status_code = 0
    error_message = ""
    response_size = 0
    started = perf_counter()

    with tracer.start_as_current_span(span_name, kind=SpanKind.CLIENT, attributes=span_attributes) as span:
        inject(headers)
        request = Request(url, data=body, headers=headers, method=method)

        try:
            with opener.open(request, timeout=timeout_seconds) as response:
                response_body = response.read()
                status_code = response.getcode()
                response_size = len(response_body)
        except HTTPError as error:
            status_code = error.code
            error_body = error.read(512)
            response_size = len(error_body)
            error_message = f"HTTP {error.code}"
        except URLError as error:
            error_message = str(error.reason)
            span.record_exception(error)
        except TimeoutError as error:
            error_message = str(error)
            span.record_exception(error)

        elapsed_ms = round((perf_counter() - started) * 1000, 3)
        span.set_attribute("http.response.status_code", status_code)
        span.set_attribute("http.response.body.size", response_size)
        span.set_attribute("synthetic.request.duration_ms", elapsed_ms)
        if error_message or status_code >= 400:
            span.set_status(Status(StatusCode.ERROR, error_message or f"HTTP {status_code}"))
        else:
            span.set_status(Status(StatusCode.OK))

    return {
        "span": span_name,
        "method": method,
        "url": url,
        "status_code": status_code,
        "duration_ms": elapsed_ms,
        "error": error_message,
    }


def build_home_url(base_url: str, project_id: str, area_id: str) -> str:
    query = urlencode({"project_id": project_id, "area_id": area_id})
    return f"{urljoin(base_url, '/')}?{query}#quotePanel"


def normalize_base_url(base_url: str) -> str:
    if not base_url.startswith(("http://", "https://")):
        base_url = f"http://{base_url}"

    return base_url.rstrip("/") + "/"


def parse_attributes(values: list[str]) -> dict[str, str]:
    attributes = {}
    for value in values:
        if "=" not in value:
            raise SystemExit(f"Invalid --attribute value: {value}. Use KEY=VALUE.")

        key, attribute_value = value.split("=", 1)
        key = key.strip()
        if not key:
            raise SystemExit("Attribute key cannot be empty.")

        attributes[key[:120]] = attribute_value[:240]

    return attributes


def print_iteration_summary(iteration: int, trace_id: str, results: list[dict[str, object]]) -> None:
    print(f"iteration={iteration} trace_id={trace_id}")
    for result in results:
        status = result["status_code"] or "error"
        error = f" error={result['error']}" if result["error"] else ""
        print(
            f"  {result['span']} {result['method']} status={status} "
            f"duration_ms={result['duration_ms']}{error}"
        )


def force_flush() -> None:
    provider = trace.get_tracer_provider()
    force_flush_fn = getattr(provider, "force_flush", None)
    if callable(force_flush_fn):
        force_flush_fn(timeout_millis=10000)


if __name__ == "__main__":
    raise SystemExit(main())
