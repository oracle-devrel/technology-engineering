#!/usr/bin/env python3
"""Export OCI FinOps data from cost reports and Usage API summaries."""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import os
import shutil
import sys
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


ROOT_DIR = Path(__file__).resolve().parent.parent
ENV_FILES = (".env.oci.local", ".env.local", ".env")
DEFAULT_OUTPUT_DIR = ROOT_DIR / "build" / "finops" / "oci"

REPORTING_NAMESPACE = "bling"
FOCUS_REPORT_PREFIX = "FOCUS Reports"
PROPRIETARY_COST_PREFIX = "reports/cost-csv"

DEFAULT_GROUP_BY = (
    "service",
    "compartmentName",
    "compartmentId",
    "region",
    "skuName",
    "skuPartNumber",
    "unit",
)

USAGE_CSV_COLUMNS = (
    "tenant_id",
    "tenant_name",
    "time_usage_started",
    "time_usage_ended",
    "compartment_id",
    "compartment_name",
    "compartment_path",
    "service",
    "resource_id",
    "resource_name",
    "region",
    "ad",
    "sku_name",
    "sku_part_number",
    "unit",
    "computed_amount",
    "computed_quantity",
    "attributed_cost",
    "attributed_usage",
    "currency",
    "subscription_id",
    "overage",
    "overages_flag",
    "is_forecast",
    "tags",
)


@dataclass
class OciSession:
    config: Dict[str, Any]
    signer: Any
    tenancy_ocid: str


@dataclass
class DownloadedReport:
    object_name: str
    size: Optional[int]
    time_created: Optional[str]
    path: str
    decompressed_path: Optional[str]


def main(argv: Optional[Sequence[str]] = None) -> int:
    load_env_files()
    args = build_parser().parse_args(argv)

    start_date, end_date = resolve_date_window(args.start_date, args.end_date, args.days)
    output_dir = Path(args.output_dir).expanduser().resolve()
    session = build_oci_session(args)

    if args.command == "cost-reports":
        reports = export_cost_reports(args, session, start_date, end_date, output_dir)
        print(f"Downloaded {len(reports)} report object(s) into {output_dir}")
        return 0

    if args.command == "usage-summary":
        rows = export_usage_summary(args, session, start_date, end_date, output_dir)
        print(f"Wrote {len(rows)} usage summary row(s) into {output_dir}")
        return 0

    if args.command == "all":
        reports = export_cost_reports(args, session, start_date, end_date, output_dir)
        rows = export_usage_summary(args, session, start_date, end_date, output_dir)
        print(
            f"Downloaded {len(reports)} report object(s) and wrote "
            f"{len(rows)} usage summary row(s) into {output_dir}"
        )
        return 0

    raise ValueError(f"Unsupported command: {args.command}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Extract OCI FinOps data. Defaults to FOCUS cost reports for the "
            "last seven complete usage days and writes outputs under build/finops/oci."
        )
    )
    parser.add_argument(
        "command",
        choices=("cost-reports", "usage-summary", "all"),
        help="Data to export.",
    )
    parser.add_argument(
        "--start-date",
        help="Inclusive usage start date in YYYY-MM-DD format. Defaults to the last seven complete days.",
    )
    parser.add_argument(
        "--end-date",
        help="Inclusive usage end date in YYYY-MM-DD format. Defaults to yesterday.",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=7,
        help="Number of complete usage days to export when dates are omitted.",
    )
    parser.add_argument(
        "--output-dir",
        default=os.getenv("OCI_FINOPS_OUTPUT_DIR", str(DEFAULT_OUTPUT_DIR)),
        help="Directory for downloaded reports, manifests, and summary files.",
    )
    parser.add_argument(
        "--auth",
        choices=("config", "instance_principal", "resource_principal"),
        default=os.getenv("OCI_AUTH", "config"),
        help="OCI authentication mode.",
    )
    parser.add_argument(
        "--config-file",
        default=os.getenv("OCI_CONFIG_FILE"),
        help="OCI config file path. Defaults to the SDK default.",
    )
    parser.add_argument(
        "--profile",
        default=os.getenv("OCI_PROFILE", "DEFAULT"),
        help="OCI config profile name.",
    )
    parser.add_argument(
        "--region",
        default=os.getenv("OCI_HOME_REGION") or os.getenv("OCI_REGION"),
        help="OCI region for API clients. Use the tenancy home region for cost reports.",
    )
    parser.add_argument(
        "--tenancy-ocid",
        default=os.getenv("OCI_TENANCY_OCID"),
        help="Tenancy OCID. Defaults to OCI_TENANCY_OCID or the OCI config tenancy.",
    )
    parser.add_argument(
        "--report-format",
        choices=("focus", "cost-csv"),
        default="focus",
        help="Cost report family to download.",
    )
    parser.add_argument(
        "--prefix",
        help="Override Object Storage report prefix. Useful for a one-off exact folder/object search.",
    )
    parser.add_argument(
        "--max-objects",
        type=int,
        help="Maximum report objects to download across all prefixes.",
    )
    parser.add_argument(
        "--decompress",
        action="store_true",
        help="Also write .csv files beside downloaded .csv.gz reports.",
    )
    parser.add_argument(
        "--granularity",
        choices=("HOURLY", "DAILY", "MONTHLY"),
        default="DAILY",
        help="Usage API aggregation granularity.",
    )
    parser.add_argument(
        "--query-type",
        choices=("COST", "USAGE", "CREDIT", "ALLCREDIT", "USAGE_ONLY"),
        default="COST",
        help="Usage API query type.",
    )
    parser.add_argument(
        "--group-by",
        default=",".join(DEFAULT_GROUP_BY),
        help="Comma-separated Usage API group-by dimensions.",
    )
    parser.add_argument(
        "--group-by-tag",
        help="Group Usage API results by one tag as namespace.key or namespace:key.",
    )
    parser.add_argument(
        "--compartment-depth",
        type=float,
        default=6,
        help="Usage API compartment depth for tenancy-wide summaries.",
    )
    parser.add_argument(
        "--aggregate-by-time",
        action="store_true",
        help="Ask OCI to aggregate the whole time range instead of returning time buckets.",
    )
    parser.add_argument(
        "--page-size",
        type=int,
        default=1000,
        help="Usage API page size.",
    )
    return parser


def load_env_files(root_dir: Path = ROOT_DIR) -> None:
    for env_file in ENV_FILES:
        path = root_dir / env_file
        if not path.exists():
            continue

        for line in path.read_text().splitlines():
            trimmed = line.strip()
            if not trimmed or trimmed.startswith("#") or "=" not in trimmed:
                continue

            key, value = trimmed.split("=", 1)
            os.environ.setdefault(key, value.strip().strip("\"'"))


def resolve_date_window(
    start_value: Optional[str],
    end_value: Optional[str],
    days: int,
) -> Tuple[date, date]:
    if days < 1:
        raise ValueError("--days must be at least 1")

    if start_value and not end_value:
        raise ValueError("--end-date is required when --start-date is provided")
    if end_value and not start_value:
        raise ValueError("--start-date is required when --end-date is provided")

    if start_value and end_value:
        start_date = parse_date(start_value)
        end_date = parse_date(end_value)
    else:
        end_date = date.today() - timedelta(days=1)
        start_date = end_date - timedelta(days=days - 1)

    if start_date > end_date:
        raise ValueError("--start-date must be on or before --end-date")

    return start_date, end_date


def parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"Invalid date {value!r}; use YYYY-MM-DD") from exc


def build_oci_session(args: argparse.Namespace) -> OciSession:
    try:
        import oci
    except ImportError as exc:
        raise SystemExit(
            "The OCI Python SDK is required. Install dependencies with "
            "`pip install -r requirements.txt`."
        ) from exc

    signer = None

    if args.auth == "config":
        config_file = args.config_file or oci.config.DEFAULT_LOCATION
        if args.config_file or Path(config_file).expanduser().exists():
            config = oci.config.from_file(config_file, args.profile)
        else:
            config = config_from_env(oci)
    elif args.auth == "instance_principal":
        signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
        config = {"region": args.region or signer.region}
    elif args.auth == "resource_principal":
        signer = oci.auth.signers.get_resource_principals_signer()
        config = {"region": args.region}
    else:
        raise ValueError(f"Unsupported auth mode: {args.auth}")

    if args.region:
        config["region"] = args.region

    tenancy_ocid = args.tenancy_ocid or config.get("tenancy")
    if not tenancy_ocid:
        raise SystemExit(
            "Tenancy OCID is required. Set OCI_TENANCY_OCID, pass --tenancy-ocid, "
            "or use an OCI config profile with a tenancy value."
        )

    if not config.get("region"):
        raise SystemExit(
            "OCI region is required. Set OCI_HOME_REGION or OCI_REGION, or pass --region."
        )

    return OciSession(config=config, signer=signer, tenancy_ocid=tenancy_ocid)


def config_from_env(oci: Any) -> Dict[str, Any]:
    env_to_config = {
        "OCI_TENANCY_OCID": "tenancy",
        "OCI_USER_OCID": "user",
        "OCI_FINGERPRINT": "fingerprint",
        "OCI_REGION": "region",
        "OCI_PRIVATE_KEY_PATH": "key_file",
    }
    missing = [env_key for env_key in env_to_config if not os.getenv(env_key)]
    if missing:
        raise SystemExit(
            "No OCI config file was found, and env-based config is incomplete. "
            "Set these values in `.env.oci.local`: " + ", ".join(missing)
        )

    config = {
        config_key: os.environ[env_key]
        for env_key, config_key in env_to_config.items()
    }
    key_file = Path(config["key_file"]).expanduser()
    if not key_file.is_absolute():
        key_file = ROOT_DIR / key_file
    config["key_file"] = str(key_file)

    pass_phrase = os.getenv("OCI_PRIVATE_KEY_PASSPHRASE")
    if pass_phrase:
        config["pass_phrase"] = pass_phrase

    oci.config.validate_config(config)
    return config


def export_cost_reports(
    args: argparse.Namespace,
    session: OciSession,
    start_date: date,
    end_date: date,
    output_dir: Path,
) -> List[DownloadedReport]:
    import oci

    object_storage = oci.object_storage.ObjectStorageClient(
        session.config,
        signer=session.signer,
        retry_strategy=oci.retry.DEFAULT_RETRY_STRATEGY,
    )

    reports_dir = output_dir / "reports"
    manifest_path = output_dir / "cost_reports_manifest.json"
    prefixes = report_prefixes(args.report_format, start_date, end_date, args.prefix)
    remaining = args.max_objects
    downloaded: List[DownloadedReport] = []

    for prefix in prefixes:
        if remaining is not None and remaining <= 0:
            break

        objects = list_report_objects(
            object_storage,
            namespace=REPORTING_NAMESPACE,
            bucket=session.tenancy_ocid,
            prefix=prefix,
            limit=remaining,
        )

        for obj in objects:
            if remaining is not None and remaining <= 0:
                break
            object_name = obj.name
            if object_name.endswith("/"):
                continue

            target = report_target_path(reports_dir, object_name)
            download_object(
                object_storage,
                namespace=REPORTING_NAMESPACE,
                bucket=session.tenancy_ocid,
                object_name=object_name,
                target=target,
            )
            decompressed_path = decompress_report(target) if args.decompress else None
            downloaded.append(
                DownloadedReport(
                    object_name=object_name,
                    size=getattr(obj, "size", None),
                    time_created=format_json_value(getattr(obj, "time_created", None)),
                    path=str(target),
                    decompressed_path=str(decompressed_path) if decompressed_path else None,
                )
            )
            if remaining is not None:
                remaining -= 1

    write_json(manifest_path, [report.__dict__ for report in downloaded])
    return downloaded


def report_prefixes(
    report_format: str,
    start_date: date,
    end_date: date,
    explicit_prefix: Optional[str],
) -> List[str]:
    if explicit_prefix:
        return [explicit_prefix]

    if report_format == "cost-csv":
        return [PROPRIETARY_COST_PREFIX]

    return [
        f"{FOCUS_REPORT_PREFIX}/{day.year:04d}/{day.month:02d}/{day.day:02d}/"
        for day in iter_dates(start_date, end_date)
    ]


def iter_dates(start_date: date, end_date: date) -> Iterable[date]:
    current = start_date
    while current <= end_date:
        yield current
        current += timedelta(days=1)


def list_report_objects(
    object_storage: Any,
    namespace: str,
    bucket: str,
    prefix: str,
    limit: Optional[int],
) -> List[Any]:
    objects: List[Any] = []
    start = None

    while True:
        page_limit = min(limit - len(objects), 1000) if limit is not None else 1000
        if page_limit <= 0:
            break

        response = object_storage.list_objects(
            namespace,
            bucket,
            prefix=prefix,
            start=start,
            limit=page_limit,
            fields="name,size,timeCreated",
        )
        objects.extend(response.data.objects)
        start = response.data.next_start_with
        if not start:
            break

    return objects


def report_target_path(reports_dir: Path, object_name: str) -> Path:
    safe_parts = [
        part
        for part in object_name.split("/")
        if part and part not in {".", ".."}
    ]
    if not safe_parts:
        raise ValueError(f"Invalid report object name: {object_name!r}")
    return reports_dir.joinpath(*safe_parts)


def download_object(
    object_storage: Any,
    namespace: str,
    bucket: str,
    object_name: str,
    target: Path,
) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    response = object_storage.get_object(namespace, bucket, object_name)

    with target.open("wb") as file_handle:
        for chunk in response.data.raw.stream(1024 * 1024, decode_content=False):
            file_handle.write(chunk)


def decompress_report(path: Path) -> Optional[Path]:
    if path.suffix != ".gz":
        return None

    target = path.with_suffix("")
    with gzip.open(path, "rb") as source, target.open("wb") as destination:
        shutil.copyfileobj(source, destination)
    return target


def export_usage_summary(
    args: argparse.Namespace,
    session: OciSession,
    start_date: date,
    end_date: date,
    output_dir: Path,
) -> List[Dict[str, Any]]:
    import oci
    from oci.usage_api import models

    client = oci.usage_api.UsageapiClient(
        session.config,
        signer=session.signer,
        retry_strategy=oci.retry.DEFAULT_RETRY_STRATEGY,
    )

    details = models.RequestSummarizedUsagesDetails(
        tenant_id=session.tenancy_ocid,
        time_usage_started=start_of_day_utc(start_date),
        time_usage_ended=start_of_day_utc(end_date + timedelta(days=1)),
        granularity=args.granularity,
        is_aggregate_by_time=args.aggregate_by_time,
        query_type=args.query_type,
        group_by=split_csv_arg(args.group_by),
        group_by_tag=build_group_by_tag(models, args.group_by_tag),
        compartment_depth=args.compartment_depth,
    )

    rows: List[Dict[str, Any]] = []
    page = None
    while True:
        response = client.request_summarized_usages(
            details,
            page=page,
            limit=args.page_size,
        )
        rows.extend(oci.util.to_dict(item) for item in response.data.items)
        page = response.headers.get("opc-next-page")
        if not page:
            break

    summaries_dir = output_dir / "summaries"
    summaries_dir.mkdir(parents=True, exist_ok=True)
    write_json(summaries_dir / "usage_summary.json", rows)
    write_csv(summaries_dir / "usage_summary.csv", rows)
    write_json(
        summaries_dir / "usage_summary_query.json",
        {
            "tenant_id": session.tenancy_ocid,
            "time_usage_started": start_of_day_utc(start_date).isoformat(),
            "time_usage_ended": start_of_day_utc(end_date + timedelta(days=1)).isoformat(),
            "granularity": args.granularity,
            "query_type": args.query_type,
            "group_by": split_csv_arg(args.group_by),
            "group_by_tag": args.group_by_tag,
            "compartment_depth": args.compartment_depth,
            "aggregate_by_time": args.aggregate_by_time,
        },
    )
    return rows


def start_of_day_utc(value: date) -> datetime:
    return datetime.combine(value, time.min, tzinfo=timezone.utc)


def split_csv_arg(value: Optional[str]) -> List[str]:
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def build_group_by_tag(models: Any, value: Optional[str]) -> Optional[List[Any]]:
    if not value:
        return None

    namespace, key = parse_tag_reference(value)
    return [models.Tag(namespace=namespace, key=key)]


def parse_tag_reference(value: str) -> Tuple[str, str]:
    separator = ":" if ":" in value else "."
    if separator not in value:
        raise ValueError("--group-by-tag must be in namespace.key or namespace:key format")

    namespace, key = value.split(separator, 1)
    namespace = namespace.strip()
    key = key.strip()
    if not namespace or not key:
        raise ValueError("--group-by-tag must include both namespace and key")
    return namespace, key


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    fieldnames = usage_csv_fieldnames(rows)
    with path.open("w", newline="") as file_handle:
        writer = csv.DictWriter(file_handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: format_csv_value(value) for key, value in row.items()})


def usage_csv_fieldnames(rows: Sequence[Dict[str, Any]]) -> List[str]:
    keys = {key for row in rows for key in row}
    if not keys:
        return list(USAGE_CSV_COLUMNS)

    preferred = [key for key in USAGE_CSV_COLUMNS if key in keys]
    extras = sorted(keys - set(preferred))
    return preferred + extras


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as file_handle:
        json.dump(payload, file_handle, indent=2, default=format_json_value)
        file_handle.write("\n")


def format_json_value(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    return value


def format_csv_value(value: Any) -> Any:
    value = format_json_value(value)
    if isinstance(value, (dict, list)):
        return json.dumps(value, default=format_json_value, sort_keys=True)
    return value


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"OCI FinOps export failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
