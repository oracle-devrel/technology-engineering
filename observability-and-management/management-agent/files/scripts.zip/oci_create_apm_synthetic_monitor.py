from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone


ROOT_DIR = Path(__file__).resolve().parent.parent
SCRIPT_PATH = ROOT_DIR / "synthetics" / "3d_marketplace_scripted_rest.js"


def main() -> int:
    load_env_files()

    parser = argparse.ArgumentParser(
        description=(
            "Create an OCI APM Availability Monitoring Scripted REST monitor "
            "for the 3D Marketplace synthetic journey."
        )
    )
    parser.add_argument("--apm-domain-id", default="")
    parser.add_argument("--base-url", default="")
    parser.add_argument("--display-name", default="MarketplaceCatalogQuoteHistory")
    parser.add_argument("--script-display-name", default="MarketplaceScriptedRestJourney")
    parser.add_argument("--interval-seconds", type=int, default=300)
    parser.add_argument("--timeout-seconds", type=int, default=60)
    parser.add_argument("--username", default=first_env("OCI_SYNTHETIC_USERNAME", "SYNTHETIC_USERNAME") or "esciunzi")
    parser.add_argument("--password", default=first_env("OCI_SYNTHETIC_PASSWORD", "SYNTHETIC_PASSWORD") or "Welcome01")
    parser.add_argument("--project-id", default=first_env("OCI_SYNTHETIC_PROJECT_ID", "SYNTHETIC_PROJECT_ID") or "desk-organizer")
    parser.add_argument("--area-id", default=first_env("OCI_SYNTHETIC_AREA_ID", "SYNTHETIC_AREA_ID") or "milan")
    parser.add_argument("--printer-id", default=first_env("OCI_SYNTHETIC_PRINTER_ID", "SYNTHETIC_PRINTER_ID") or "milan-maker-lab")
    parser.add_argument("--material", default=first_env("OCI_SYNTHETIC_MATERIAL", "SYNTHETIC_MATERIAL") or "PLA")
    parser.add_argument("--finish", default=first_env("OCI_SYNTHETIC_FINISH", "SYNTHETIC_FINISH") or "Standard")
    parser.add_argument("--color", default=first_env("OCI_SYNTHETIC_COLOR", "SYNTHETIC_COLOR") or "Natural White")
    parser.add_argument(
        "--vantage-point",
        action="append",
        default=[],
        help="OCI public or dedicated vantage point name. Repeat for multiple vantage points.",
    )
    parser.add_argument(
        "--vantage-points",
        default=first_env("OCI_SYNTHETIC_VANTAGE_POINTS", "SYNTHETIC_VANTAGE_POINTS"),
        help="Comma-separated OCI vantage point names.",
    )
    parser.add_argument(
        "--preferred-vantage-match",
        default=first_env("OCI_SYNTHETIC_PREFERRED_VANTAGE_MATCH") or "frankfurt",
        help="Substring used when auto-selecting one public vantage point.",
    )
    parser.add_argument("--profile", default=first_env("OCI_PROFILE") or "DEFAULT")
    parser.add_argument("--region", default=first_env("OCI_REGION"))
    parser.add_argument("--auth", default=first_env("OCI_CLI_AUTH"))
    parser.add_argument("--disabled", action="store_true", help="Create the monitor disabled.")
    parser.add_argument("--run-once", action="store_true", help="Create a run-once monitor instead of a scheduled monitor.")
    parser.add_argument("--no-run-now", action="store_true", help="Do not trigger an immediate run after creation.")
    parser.add_argument("--force-new", action="store_true", help="Create a new monitor even if a monitor with the display name exists.")
    parser.add_argument("--dry-run", action="store_true", help="Validate inputs and print the planned OCI resources without creating them.")
    args = parser.parse_args()
    args.apm_domain_id = args.apm_domain_id or default_apm_domain_id()
    args.base_url = args.base_url or default_base_url()

    validate_args(args)
    ensure_oci_cli()

    try:
        vantage_points = collect_vantage_points(args)
        if args.dry_run:
            print_plan(args, vantage_points)
            return 0

        existing_monitor_id = find_existing_monitor_id(args)
        if existing_monitor_id and not args.force_new:
            print(
                "A monitor with this display name already exists. "
                f"Use --force-new to create another one. monitor_id={existing_monitor_id}"
            )
            return 0

        script_id = create_script(args)
        monitor_id = create_monitor(args, script_id, vantage_points)
        print(json.dumps({"script_id": script_id, "monitor_id": monitor_id}, indent=2))
        return 0
    except subprocess.CalledProcessError as error:
        print("OCI CLI command failed.", file=sys.stderr)
        if error.stderr:
            print(error.stderr.strip(), file=sys.stderr)
        return error.returncode or 1


def validate_args(args: argparse.Namespace) -> None:
    if not args.apm_domain_id:
        raise SystemExit(
            "Missing APM domain OCID. Pass --apm-domain-id or set OCI_APM_DOMAIN_ID."
        )

    if not args.base_url:
        raise SystemExit("Missing website URL. Pass --base-url or set PUBLIC_BASE_URL.")

    if not args.base_url.startswith(("http://", "https://")):
        raise SystemExit("--base-url must start with http:// or https://.")

    if args.interval_seconds < 300 and not args.run_once:
        raise SystemExit("Scripted REST monitors require --interval-seconds of at least 300.")

    if args.timeout_seconds % 60 != 0:
        raise SystemExit("Scripted REST monitor --timeout-seconds must be a multiple of 60.")

    if args.timeout_seconds > args.interval_seconds * 0.3 and not args.run_once:
        raise SystemExit(
            "--timeout-seconds must be at most 30% of --interval-seconds when retries are enabled."
        )

    if not SCRIPT_PATH.exists():
        raise SystemExit(f"Synthetic script not found: {SCRIPT_PATH}")


def ensure_oci_cli() -> None:
    if not shutil.which("oci"):
        raise SystemExit("oci CLI is not installed or not on PATH.")


def collect_vantage_points(args: argparse.Namespace) -> list[str]:
    values = []
    if args.vantage_points:
        values.extend(item.strip() for item in args.vantage_points.split(","))
    values.extend(args.vantage_point)
    values = [value for value in values if value]

    if values:
        return values

    if args.dry_run:
        return [f"<auto-select-public-vantage-point-matching-{args.preferred_vantage_match}>"]

    return [select_public_vantage_point(args)]


def select_public_vantage_point(args: argparse.Namespace) -> str:
    result = run_oci_json(
        args,
        [
            "apm-synthetics",
            "public-vantage-point-collection",
            "list-public-vantage-points",
            "--apm-domain-id",
            args.apm_domain_id,
            "--all",
        ],
    )
    vantage_points = normalize_vantage_points(result.get("data"))
    if not vantage_points:
        raise SystemExit(
            "No public vantage points were returned. Pass --vantage-point explicitly."
        )

    preferred = (args.preferred_vantage_match or "").lower()
    if preferred:
        for item in vantage_points:
            searchable = vantage_point_search_text(item)
            if preferred in searchable:
                return vantage_point_name(item)

    return vantage_point_name(vantage_points[0])


def normalize_vantage_points(data) -> list:
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        items = data.get("items")
        if isinstance(items, list):
            return items
        if items:
            return [items]
        return list(data.values())

    if data:
        return [data]

    return []


def vantage_point_name(item) -> str:
    if isinstance(item, str):
        return item

    return item.get("name") or item.get("display-name") or item.get("displayName") or str(item)


def vantage_point_search_text(item) -> str:
    if isinstance(item, str):
        return item.lower()

    return " ".join(
        str(item.get(key, ""))
        for key in ("name", "display-name", "displayName")
    ).lower()


def create_script(args: argparse.Namespace) -> str:
    parameters = [
        {"paramName": "baseUrl", "paramValue": args.base_url.rstrip("/"), "isSecret": False},
        {"paramName": "syntheticUsername", "paramValue": args.username, "isSecret": False},
        {"paramName": "syntheticPassword", "paramValue": args.password, "isSecret": True},
        {"paramName": "projectId", "paramValue": args.project_id, "isSecret": False},
        {"paramName": "areaId", "paramValue": args.area_id, "isSecret": False},
        {"paramName": "printerId", "paramValue": args.printer_id, "isSecret": False},
        {"paramName": "material", "paramValue": args.material, "isSecret": False},
        {"paramName": "finish", "paramValue": args.finish, "isSecret": False},
        {"paramName": "color", "paramValue": args.color, "isSecret": False},
    ]

    with tempfile.TemporaryDirectory(prefix="oci-apm-synthetic-") as tmp_dir:
        parameters_path = Path(tmp_dir) / "script-parameters.json"
        parameters_path.write_text(json.dumps(parameters, indent=2), encoding="utf-8")
        script_content = SCRIPT_PATH.read_text(encoding="utf-8")

        return run_oci_text(
            args,
            [
                "apm-synthetics",
                "script",
                "create",
                "--apm-domain-id",
                args.apm_domain_id,
                "--display-name",
                args.script_display_name,
                "--content-type",
                "JS",
                "--content-file-name",
                SCRIPT_PATH.name,
                "--content",
                script_content,
                "--parameters",
                f"file://{parameters_path}",
                "--query",
                "data.id",
                "--raw-output",
            ],
        )


def create_monitor(args: argparse.Namespace, script_id: str, vantage_points: list[str]) -> str:
    with tempfile.TemporaryDirectory(prefix="oci-apm-synthetic-") as tmp_dir:
        vantage_points_path = Path(tmp_dir) / "vantage-points.json"
        vantage_points_path.write_text(json.dumps(vantage_points, indent=2), encoding="utf-8")

        command = [
            "apm-synthetics",
            "monitor",
            "create-scripted-rest-monitor",
            "--apm-domain-id",
            args.apm_domain_id,
            "--display-name",
            args.display_name,
            "--monitor-type",
            "SCRIPTED_REST",
            "--repeat-interval-in-seconds",
            str(args.interval_seconds),
            "--vantage-points",
            f"file://{vantage_points_path}",
            "--script-id",
            script_id,
            "--target",
            args.base_url.rstrip("/"),
            "--timeout-in-seconds",
            str(args.timeout_seconds),
            "--status",
            "DISABLED" if args.disabled else "ENABLED",
            "--is-run-once",
            "true" if args.run_once else "false",
            "--is-run-now",
            "false" if args.no_run_now else "true",
            "--is-failure-retried",
            "true",
            "--scheduling-policy",
            "ALL",
            "--freeform-tags",
            json.dumps(
                {
                    "project": "3d-marketplace",
                    "managed-by": "codex",
                    "monitor-kind": "synthetic-workload",
                }
            ),
            "--query",
            "data.id",
            "--raw-output",
        ]
        return run_oci_text(args, command)


def find_existing_monitor_id(args: argparse.Namespace) -> str:
    try:
        result = run_oci_json(
            args,
            [
                "apm-synthetics",
                "monitor-collection",
                "list-monitors",
                "--apm-domain-id",
                args.apm_domain_id,
                "--display-name",
                args.display_name,
                "--all",
            ],
        )
    except subprocess.CalledProcessError:
        return ""

    for item in normalize_monitor_items(result.get("data")):
        if not isinstance(item, dict):
            continue

        if item.get("display-name") == args.display_name or item.get("displayName") == args.display_name:
            return item.get("id", "")

    return ""


def normalize_monitor_items(data) -> list:
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        items = data.get("items")
        if isinstance(items, list):
            return items
        if items:
            return [items]
        return list(data.values())

    if data:
        return [data]

    return []


def run_oci_json(args: argparse.Namespace, command: list[str]) -> dict:
    output = run_oci_text(args, command + ["--output", "json"])
    return json.loads(output)


def run_oci_text(args: argparse.Namespace, command: list[str]) -> str:
    full_command = ["oci", *command, *global_oci_args(args)]
    completed = subprocess.run(
        full_command,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    return completed.stdout.strip()


def global_oci_args(args: argparse.Namespace) -> list[str]:
    values = []
    if args.profile:
        values.extend(["--profile", args.profile])
    if args.region:
        values.extend(["--region", args.region])
    if args.auth:
        values.extend(["--auth", args.auth])
    return values


def print_plan(args: argparse.Namespace, vantage_points: list[str]) -> None:
    print(
        json.dumps(
            {
                "dry_run": True,
                "apm_domain_id": args.apm_domain_id,
                "base_url": args.base_url.rstrip("/"),
                "script_file": str(SCRIPT_PATH),
                "script_display_name": args.script_display_name,
                "monitor_display_name": args.display_name,
                "monitor_type": "SCRIPTED_REST",
                "repeat_interval_in_seconds": args.interval_seconds,
                "timeout_in_seconds": args.timeout_seconds,
                "status": "DISABLED" if args.disabled else "ENABLED",
                "run_now": not args.no_run_now,
                "run_once": args.run_once,
                "vantage_points": vantage_points,
                "synthetic_username": args.username,
                "synthetic_password": "<secret parameter>",
                "created_at": datetime.now(timezone.utc).isoformat(),
            },
            indent=2,
        )
    )


def default_base_url() -> str:
    env_value = first_env("OCI_SYNTHETIC_BASE_URL", "SYNTHETIC_BASE_URL", "PUBLIC_BASE_URL")
    if env_value:
        return env_value

    output = terraform_output("load_balancer_url")
    if output and output != "null":
        return output

    return ""


def default_apm_domain_id() -> str:
    env_value = first_env("OCI_APM_DOMAIN_ID", "APM_DOMAIN_ID", "apm_domain_id")
    if env_value:
        return env_value

    return terraform_output("apm_domain_id")


def terraform_output(name: str) -> str:
    if not shutil.which("tofu"):
        return ""

    try:
        completed = subprocess.run(
            ["tofu", "-chdir=infra/oci", "output", "-raw", name],
            cwd=ROOT_DIR,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
        )
    except subprocess.CalledProcessError:
        return ""

    return completed.stdout.strip()


def first_env(*names: str) -> str:
    for name in names:
        value = os.getenv(name, "")
        if value:
            return value
    return ""


def load_env_files() -> None:
    for name in (".env.oci.local", ".env.local", ".env"):
        path = ROOT_DIR / name
        if not path.exists():
            continue

        for line in path.read_text(encoding="utf-8").splitlines():
            trimmed = line.strip()
            if not trimmed or trimmed.startswith("#") or "=" not in trimmed:
                continue

            key, value = trimmed.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


if __name__ == "__main__":
    raise SystemExit(main())
