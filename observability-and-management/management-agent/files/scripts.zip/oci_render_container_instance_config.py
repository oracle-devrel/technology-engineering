from __future__ import annotations

import argparse
import base64
import json
import os
from pathlib import Path
import sys
from typing import Any


ROOT_DIR = Path(__file__).resolve().parent.parent
ENV_FILES = (".env.oci.local", ".env.local", ".env")
DEFAULT_OUTPUT_DIR = ROOT_DIR / "build" / "oci"

REQUIRED = (
    "OCI_COMPARTMENT_OCID",
    "OCI_AVAILABILITY_DOMAIN",
    "OCI_CONTAINER_REGISTRY_NAMESPACE",
    "OCI_CONTAINER_REPOSITORY",
    "OCI_IMAGE_TAG",
    "OCI_CONTAINER_PORT",
    "OCI_CONTAINER_INSTANCE_DISPLAY_NAME",
    "OCI_CONTAINER_INSTANCE_SHAPE",
    "OCI_CONTAINER_INSTANCE_OCPUS",
    "OCI_CONTAINER_INSTANCE_MEMORY_GB",
    "OCI_PUBLIC_SUBNET_OCID",
    "DATABASE_URL",
    "OCI_OBJECT_STORAGE_NAMESPACE",
    "OCI_OBJECT_STORAGE_BUCKET",
    "OCI_APM_DATA_UPLOAD_ENDPOINT",
    "OCI_APM_PUBLIC_DATA_KEY",
    "OCI_APM_PRIVATE_DATA_KEY",
    "SESSION_SECRET",
)

RUNTIME_ENV_KEYS = (
    "PORT",
    "DATABASE_URL",
    "PUBLIC_BASE_URL",
    "OCI_OBJECT_STORAGE_NAMESPACE",
    "OCI_OBJECT_STORAGE_BUCKET",
    "OCI_APM_DATA_UPLOAD_ENDPOINT",
    "OCI_APM_PUBLIC_DATA_KEY",
    "OCI_APM_BROWSER_SERVICE_NAME",
    "OCI_APM_BROWSER_WEB_APPLICATION",
    "OCI_APM_PRIVATE_DATA_KEY",
    "OTEL_SERVICE_NAME",
    "OTEL_SERVICE_VERSION",
    "OTEL_DEPLOYMENT_ENVIRONMENT",
    "SESSION_SECRET",
    "EMAIL_PROVIDER",
    "RESEND_API_KEY",
    "SENDGRID_API_KEY",
    "STRIPE_SECRET_KEY",
    "STRIPE_WEBHOOK_SECRET",
)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Render OCI Container Instance JSON for the 3D marketplace."
    )
    parser.add_argument(
        "--output-dir",
        default=str(DEFAULT_OUTPUT_DIR),
        help="Directory for generated OCI JSON files.",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Validate env and print what would be generated without writing files.",
    )
    args = parser.parse_args()

    for env_file in ENV_FILES:
        load_env(ROOT_DIR / env_file)

    set_default("OCI_REGION", "eu-frankfurt-1")
    set_default("OCI_CONTAINER_REGISTRY_REGION", os.environ["OCI_REGION"])
    set_default(
        "OCI_CONTAINER_REGISTRY_ENDPOINT",
        f"ocir.{os.environ['OCI_CONTAINER_REGISTRY_REGION']}.oci.oraclecloud.com",
    )
    set_default("OCI_CONTAINER_INSTANCE_SHAPE", "CI.Standard.E4.Flex")
    set_default("OCI_CONTAINER_INSTANCE_OCPUS", "1")
    set_default("OCI_CONTAINER_INSTANCE_MEMORY_GB", "2")
    set_default("OCI_CONTAINER_RESTART_POLICY", "ALWAYS")
    set_default("OCI_CONTAINER_PORT", "8000")
    set_default("OCI_ASSIGN_PUBLIC_IP", "true")
    set_default("OTEL_SERVICE_NAME", "3d-marketplace")
    set_default("OTEL_SERVICE_VERSION", "0.1.0")
    set_default("OTEL_DEPLOYMENT_ENVIRONMENT", "staging")
    set_default("PORT", os.environ["OCI_CONTAINER_PORT"])

    missing = [key for key in REQUIRED if not os.getenv(key)]
    if missing:
        print("Missing required OCI deployment values:", file=sys.stderr)
        for key in missing:
            print(f"- {key}", file=sys.stderr)
        print(
            "\nCopy `.env.oci.example` to `.env.oci.local` and fill in the missing values.",
            file=sys.stderr,
        )
        return 1

    config = build_config()

    if args.check:
        print(f"Image URI: {config['image_uri']}")
        print(f"Runtime env values: {len(config['containers'][0]['environmentVariables'])}")
        print("OCI Container Instance JSON can be rendered.")
        return 0

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    write_json(output_dir / "containers.json", config["containers"])
    write_json(output_dir / "shape_config.json", config["shape_config"])
    write_json(output_dir / "vnics.json", config["vnics"])
    write_json(output_dir / "image_pull_secrets.json", config["image_pull_secrets"])
    write_json(output_dir / "deployment_summary.json", config["summary"])

    print(f"Rendered OCI Container Instance JSON in {output_dir}")
    print(f"Image URI: {config['image_uri']}")

    if not config["image_pull_secrets"]:
        print(
            "No image pull secret was rendered. Set OCI_OCIR_USERNAME and "
            "OCI_OCIR_AUTH_TOKEN if the OCIR repository is private."
        )

    return 0


def build_config() -> dict:
    container_port = int_env("OCI_CONTAINER_PORT")
    ocpus = float_env("OCI_CONTAINER_INSTANCE_OCPUS")
    memory_gb = float_env("OCI_CONTAINER_INSTANCE_MEMORY_GB")
    image_uri = build_image_uri()
    runtime_env = build_runtime_env()

    container = {
        "displayName": os.getenv("OCI_IMAGE_NAME", "3d-marketplace"),
        "imageUrl": image_uri,
        "environmentVariables": runtime_env,
        "resourceConfig": {
            "vcpusLimit": ocpus * 2,
            "memoryLimitInGBs": memory_gb,
        },
        "healthChecks": [
            {
                "healthCheckType": "HTTP",
                "name": "app-health",
                "path": "/health",
                "port": container_port,
                "initialDelayInSeconds": 20,
                "intervalInSeconds": 30,
                "timeoutInSeconds": 5,
                "failureThreshold": 3,
                "successThreshold": 1,
                "failureAction": "KILL",
            }
        ],
    }

    vnic = {
        "displayName": "3d-marketplace-public-vnic",
        "subnetId": os.environ["OCI_PUBLIC_SUBNET_OCID"],
        "isPublicIpAssigned": bool_env("OCI_ASSIGN_PUBLIC_IP", default=True),
    }

    nsg_ids = csv_env("OCI_NETWORK_SECURITY_GROUP_OCIDS")
    if nsg_ids:
        vnic["nsgIds"] = nsg_ids

    return {
        "image_uri": image_uri,
        "containers": [container],
        "shape_config": {
            "ocpus": ocpus,
            "memoryInGBs": memory_gb,
        },
        "vnics": [vnic],
        "image_pull_secrets": build_image_pull_secrets(),
        "summary": {
            "displayName": os.environ["OCI_CONTAINER_INSTANCE_DISPLAY_NAME"],
            "shape": os.environ["OCI_CONTAINER_INSTANCE_SHAPE"],
            "restartPolicy": os.environ["OCI_CONTAINER_RESTART_POLICY"],
            "imageUri": image_uri,
            "containerPort": container_port,
            "publicSubnetId": os.environ["OCI_PUBLIC_SUBNET_OCID"],
            "publicIpAssigned": vnic["isPublicIpAssigned"],
        },
    }


def build_image_uri() -> str:
    explicit_uri = os.getenv("OCI_IMAGE_URI")
    if explicit_uri:
        return explicit_uri

    endpoint = normalize_registry_endpoint(os.environ["OCI_CONTAINER_REGISTRY_ENDPOINT"])
    namespace = os.environ["OCI_CONTAINER_REGISTRY_NAMESPACE"].strip("/")
    repository = os.environ["OCI_CONTAINER_REPOSITORY"].strip("/")
    tag = os.environ["OCI_IMAGE_TAG"]
    return f"{endpoint}/{namespace}/{repository}:{tag}"


def build_runtime_env() -> dict[str, str]:
    env = {}

    for key in RUNTIME_ENV_KEYS:
        value = os.getenv(key)
        if value:
            env[key] = value

    env["PORT"] = os.getenv("PORT") or os.environ["OCI_CONTAINER_PORT"]
    return env


def build_image_pull_secrets() -> list[dict[str, str]]:
    username = os.getenv("OCI_OCIR_USERNAME")
    auth_token = os.getenv("OCI_OCIR_AUTH_TOKEN")

    if not username or not auth_token:
        return []

    return [
        {
            "secretType": "BASIC",
            "registryEndpoint": normalize_registry_endpoint(
                os.environ["OCI_CONTAINER_REGISTRY_ENDPOINT"]
            ),
            "username": b64(username),
            "password": b64(auth_token),
        }
    ]


def load_env(path: Path) -> None:
    if not path.exists():
        return

    for line in path.read_text().splitlines():
        trimmed = line.strip()

        if not trimmed or trimmed.startswith("#") or "=" not in trimmed:
            continue

        if trimmed.startswith("export "):
            trimmed = trimmed.removeprefix("export ").strip()

        key, value = trimmed.split("=", 1)
        key = key.strip()

        if not key or not key.replace("_", "").isalnum():
            continue

        os.environ.setdefault(key, value.strip().strip("\"'"))


def set_default(key: str, value: str) -> None:
    if not os.getenv(key):
        os.environ[key] = value


def normalize_registry_endpoint(endpoint: str) -> str:
    return endpoint.replace("https://", "").replace("http://", "").rstrip("/")


def int_env(key: str) -> int:
    try:
        return int(os.environ[key])
    except ValueError as error:
        raise SystemExit(f"{key} must be an integer.") from error


def float_env(key: str) -> float:
    try:
        return float(os.environ[key])
    except ValueError as error:
        raise SystemExit(f"{key} must be a number.") from error


def bool_env(key: str, default: bool = False) -> bool:
    value = os.getenv(key)

    if value is None:
        return default

    return value.lower() in {"1", "true", "yes", "on"}


def csv_env(key: str) -> list[str]:
    value = os.getenv(key, "")
    return [part.strip() for part in value.split(",") if part.strip()]


def b64(value: str) -> str:
    return base64.b64encode(value.encode("utf-8")).decode("ascii")


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())
