#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"

RUN_CHECK=true
RUN_BUILD=true
RUN_CREATE=true
RENDER_ONLY=false

usage() {
  cat <<'USAGE'
Usage: bash scripts/oci_deploy.sh [options]

Build, push, render config, and create the OCI Container Instance.

Options:
  --render-only   Validate env and render build/oci/*.json without build or deploy.
  --skip-build    Do not build or push the image; deploy the current OCI_IMAGE_TAG.
  --skip-create   Build/push and render config, but do not create the container instance.
  --no-check      Skip scripts/check_oci_env.py.
  --help          Show this help.

Environment:
  Copy .env.oci.example to .env.oci.local and fill in real values first.
  Set CONTAINER_CLI=podman to use Podman instead of Docker.
  Set PYTHON_BIN=/path/to/python to use a specific Python interpreter.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --render-only)
      RENDER_ONLY=true
      RUN_BUILD=false
      RUN_CREATE=false
      ;;
    --skip-build)
      RUN_BUILD=false
      ;;
    --skip-create)
      RUN_CREATE=false
      ;;
    --no-check)
      RUN_CHECK=false
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift
done

if [[ "${RUN_CHECK}" == "true" ]]; then
  echo "Checking OCI environment"
  "${PYTHON_BIN}" "${ROOT_DIR}/scripts/check_oci_env.py"
fi

if [[ "${RUN_BUILD}" == "true" ]]; then
  echo "Building and pushing OCI image"
  bash "${ROOT_DIR}/scripts/oci_build_push.sh"
fi

echo "Rendering OCI Container Instance config"
"${PYTHON_BIN}" "${ROOT_DIR}/scripts/oci_render_container_instance_config.py"

if [[ "${RENDER_ONLY}" == "true" ]]; then
  echo "Render-only mode complete."
  exit 0
fi

if [[ "${RUN_CREATE}" == "true" ]]; then
  echo "Creating OCI Container Instance"
  bash "${ROOT_DIR}/scripts/oci_create_container_instance.sh"
else
  echo "Skipped OCI Container Instance creation."
fi
