#!/usr/bin/env bash
set -euo pipefail

# Creates an OCI Management Agent install key, copies a local or URL-downloaded
# Linux agent package to a VM, and optionally runs install_oci_management_agent.sh.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

OCI_CLI="${OCI_CLI:-oci}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
COMPARTMENT_ID="${OCI_MGMT_AGENT_COMPARTMENT_ID:-}"
COMPARTMENT_NAME="${OCI_MGMT_AGENT_COMPARTMENT_NAME:-Erika_sciunzi}"
VM_HOST="${OCI_MGMT_AGENT_VM_HOST:-130.61.29.177}"
SSH_USER="${OCI_MGMT_AGENT_SSH_USER:-opc}"
SSH_KEY="${OCI_MGMT_AGENT_SSH_KEY:-/Users/esciunzi/Downloads/ssh-key-2026-06-12.key}"
REMOTE_DIR="${OCI_MGMT_AGENT_REMOTE_DIR:-/home/opc/oci-management-agent-bootstrap}"
REMOTE_INSTALLER_PATH="${OCI_MGMT_AGENT_REMOTE_INSTALLER:-/home/opc/install_oci_management_agent.sh}"
INSTALLER_SOURCE="${OCI_MGMT_AGENT_INSTALLER_SOURCE:-${ROOT_DIR}/scripts/install_oci_management_agent.sh}"
KEY_DISPLAY_NAME="${OCI_MGMT_AGENT_KEY_DISPLAY_NAME:-}"
ALLOWED_INSTALL_COUNT="${OCI_MGMT_AGENT_ALLOWED_INSTALL_COUNT:-1}"
TIME_EXPIRES="${OCI_MGMT_AGENT_TIME_EXPIRES:-}"
UNLIMITED_KEY="${OCI_MGMT_AGENT_UNLIMITED_KEY:-false}"
PACKAGE_TYPE="${OCI_MGMT_AGENT_PACKAGE_TYPE:-RPM}"
PACKAGE_ARCHITECTURE="${OCI_MGMT_AGENT_PACKAGE_ARCHITECTURE:-auto}"
PACKAGE_PATH="${OCI_MGMT_AGENT_PACKAGE:-${ROOT_DIR}/files/oracle.mgmt_agent.rpm}"
PACKAGE_URL="${OCI_MGMT_AGENT_PACKAGE_URL:-}"
USE_OCI_IMAGE_DOWNLOAD="${OCI_MGMT_AGENT_USE_OCI_IMAGE_DOWNLOAD:-false}"
WALLET_PASSWORD="${OCI_MGMT_AGENT_WALLET_PASSWORD:-}"
ENABLE_LOG_ANALYTICS_PLUGIN="${OCI_MGMT_AGENT_ENABLE_LOG_ANALYTICS_PLUGIN:-true}"
AGENT_DISPLAY_NAME="${OCI_MGMT_AGENT_DISPLAY_NAME:-}"
WORK_DIR="${OCI_MGMT_AGENT_BOOTSTRAP_WORK_DIR:-${ROOT_DIR}/build/oci-management-agent-bootstrap}"
DOWNLOAD_DIR="${OCI_MGMT_AGENT_DOWNLOAD_DIR:-}"
JAVA_HOME_OVERRIDE="${OCI_MGMT_AGENT_JAVA_HOME:-}"
JAVA_TARBALL="${OCI_MGMT_AGENT_JAVA_TARBALL:-}"
JAVA_URL="${OCI_MGMT_AGENT_JAVA_URL:-}"
JAVA_INSTALL_DIR="${OCI_MGMT_AGENT_JAVA_INSTALL_DIR:-}"
JAVA_INSTALL_MODE="${OCI_MGMT_AGENT_JAVA_INSTALL_MODE:-}"
JAVA_PACKAGE="${OCI_MGMT_AGENT_JAVA_PACKAGE:-}"
SKIP_JAVA_INSTALL="${OCI_MGMT_AGENT_SKIP_JAVA_INSTALL:-false}"
COPY_ONLY=false
DRY_RUN=false

usage() {
  cat <<'USAGE'
Usage:
  bash scripts/oci_bootstrap_management_agent_vm.sh [options]

Create an OCI Management Agent install key, use the local Management Agent
software package under files/ by default, copy the installer inputs to a VM over
SSH, and run /home/opc/install_oci_management_agent.sh remotely.

Defaults are set for the current request:
  VM host:          130.61.29.177
  SSH user:         opc
  compartment name: Erika_sciunzi
  SSH key:          /Users/esciunzi/Downloads/ssh-key-2026-06-12.key

Required if the defaults do not fit:
  --compartment-id OCID          Management Agent compartment OCID.
  --compartment-name NAME        Resolve a compartment by name. Default: Erika_sciunzi.
  --vm-host HOST                 VM public IP or DNS name. Default: 130.61.29.177.
  --ssh-key PATH                 Private SSH key for opc.

Install key options:
  --key-display-name NAME        Install key display name. Default generated.
  --allowed-install-count N      Allowed installs for the key. Default: 1.
  --time-expires TIMESTAMP       UTC expiry, for example 2026-06-13T12:00:00Z.
  --unlimited-key                Create an unlimited key. Not recommended.

Package options:
  --package PATH                 Local agent RPM or ZIP. Default: files/oracle.mgmt_agent.rpm.
  --package-url URL              Download agent RPM or ZIP from a URL into the download dir.
  --package-type RPM|ZIP         Agent package type. Default: RPM.
  --package-architecture ARCH    X86_64, AARCH64, or auto. Default: auto.
  --download-dir DIR             Folder where downloaded agent software is saved.
                                  Env: OCI_MGMT_AGENT_DOWNLOAD_DIR. Default: files/.
  --use-oci-image-download       Discover and download the package from OCI Object Storage.

Remote options:
  --ssh-user USER                SSH user. Default: opc.
  --remote-dir DIR               Remote staging dir. Default: /home/opc/oci-management-agent-bootstrap.
  --remote-installer PATH        Remote installer path. Default: /home/opc/install_oci_management_agent.sh.
  --installer-source PATH        Local installer to copy. Default: scripts/install_oci_management_agent.sh.
  --wallet-password VALUE        OCI_MGMT_AGENT_WALLET_PASSWORD for the generated response file.
  --agent-display-name NAME      Optional display name passed to the remote installer.
  --disable-log-analytics-plugin Do not request Log Analytics plugin download.
  --java-home DIR                Remote Java 8 home used only by the agent installer.
  --java-tarball PATH            Local standalone Java 8 tarball copied to the VM.
  --java-url URL                 Remote installer downloads this standalone Java 8 tarball URL.
  --java-install-dir DIR         Remote standalone Java install dir.
  --java-install-mode MODE       standalone or package. Requires a value.
  --java-package NAME            Java 8 OS package when --java-install-mode package is used.
  --skip-java-install            Do not install Java if no supported runtime is found.
  --copy-only                    Create key, download software, and copy files, but do not run installer.
  --dry-run                      Print planned actions without creating/downloading/copying/running.

Example:
  bash scripts/oci_bootstrap_management_agent_vm.sh \
    --compartment-name Erika_sciunzi \
    --vm-host 130.61.29.177 \
    --ssh-key /Users/esciunzi/Downloads/ssh-key-2026-06-12.key \
    --package files/oracle.mgmt_agent.rpm
USAGE
}

log() {
  printf '[oci-mgmt-bootstrap] %s\n' "$*"
}

warn() {
  printf '[oci-mgmt-bootstrap] WARN: %s\n' "$*" >&2
}

die() {
  printf '[oci-mgmt-bootstrap] ERROR: %s\n' "$*" >&2
  exit 1
}

have_command() {
  command -v "$1" >/dev/null 2>&1
}

run() {
  if [[ "${DRY_RUN}" == "true" ]]; then
    printf '+'
    printf ' %q' "$@"
    printf '\n'
    return 0
  fi

  "$@"
}

require_value() {
  local option="$1"
  local value="${2:-}"
  [[ -n "${value}" && "${value}" != --* ]] || die "${option} requires a value."
}

prompt_text_with_default() {
  local var_name="$1"
  local prompt="$2"
  local current_value="$3"
  local default_value="$4"

  if [[ -n "${current_value}" ]]; then
    printf '%s' "${current_value}"
    return 0
  fi

  if [[ "${DRY_RUN}" == "true" || ! -t 0 ]]; then
    printf '%s' "${default_value}"
    return 0
  fi

  read -r -p "${var_name} - ${prompt} [${default_value}]: " current_value
  printf '%s' "${current_value:-${default_value}}"
}

wallet_password_valid() {
  local value="$1"
  [[ "${#value}" -ge 16 ]] || return 1
  [[ "${value}" =~ [a-z] ]] || return 1
  [[ "${value}" =~ [A-Z] ]] || return 1
  [[ "${value}" =~ [0-9] ]] || return 1
  [[ "${value}" =~ [\!\@\#\%\^\&\*] ]] || return 1
  [[ ! "${value}" =~ [^a-zA-Z0-9\!\@\#\%\^\&\*] ]] || return 1
}

wallet_password_rules() {
  printf 'at least 16 characters with lowercase, uppercase, numeric, and one special character from !@#%%^&*; do not use other special characters'
}

prompt_wallet_password() {
  if [[ "${DRY_RUN}" == "true" ]]; then
    return 0
  fi

  while true; do
    if [[ -z "${WALLET_PASSWORD}" && -t 0 ]]; then
      read -r -s -p "OCI_MGMT_AGENT_WALLET_PASSWORD - agent credential wallet password (press Enter to generate one): " WALLET_PASSWORD
      printf '\n' >&2
    fi

    if [[ -z "${WALLET_PASSWORD}" ]]; then
      WALLET_PASSWORD="$(default_wallet_password)"
      log "Generated OCI_MGMT_AGENT_WALLET_PASSWORD for the response file."
    fi

    wallet_password_valid "${WALLET_PASSWORD}" && return 0

    warn "OCI_MGMT_AGENT_WALLET_PASSWORD must be $(wallet_password_rules)."
    [[ -t 0 ]] || die "Set a compliant OCI_MGMT_AGENT_WALLET_PASSWORD and rerun."
    WALLET_PASSWORD=""
  done
}

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --compartment-id)
        COMPARTMENT_ID="${2:-}"
        shift 2
        ;;
      --compartment-name)
        COMPARTMENT_NAME="${2:-}"
        shift 2
        ;;
      --vm-host)
        VM_HOST="${2:-}"
        shift 2
        ;;
      --ssh-user)
        SSH_USER="${2:-}"
        shift 2
        ;;
      --ssh-key)
        SSH_KEY="${2:-}"
        shift 2
        ;;
      --remote-dir)
        REMOTE_DIR="${2:-}"
        shift 2
        ;;
      --remote-installer)
        REMOTE_INSTALLER_PATH="${2:-}"
        shift 2
        ;;
      --installer-source)
        INSTALLER_SOURCE="${2:-}"
        shift 2
        ;;
      --key-display-name)
        KEY_DISPLAY_NAME="${2:-}"
        shift 2
        ;;
      --allowed-install-count)
        ALLOWED_INSTALL_COUNT="${2:-}"
        shift 2
        ;;
      --time-expires)
        TIME_EXPIRES="${2:-}"
        shift 2
        ;;
      --unlimited-key)
        UNLIMITED_KEY=true
        shift
        ;;
      --package-type)
        PACKAGE_TYPE="${2:-}"
        shift 2
        ;;
      --package)
        PACKAGE_PATH="${2:-}"
        PACKAGE_URL=""
        USE_OCI_IMAGE_DOWNLOAD=false
        shift 2
        ;;
      --package-url)
        PACKAGE_URL="${2:-}"
        USE_OCI_IMAGE_DOWNLOAD=false
        shift 2
        ;;
      --package-architecture)
        PACKAGE_ARCHITECTURE="${2:-}"
        shift 2
        ;;
      --download-dir)
        DOWNLOAD_DIR="${2:-}"
        shift 2
        ;;
      --use-oci-image-download)
        USE_OCI_IMAGE_DOWNLOAD=true
        PACKAGE_URL=""
        shift
        ;;
      --wallet-password)
        require_value "$1" "${2:-}"
        WALLET_PASSWORD="${2:-}"
        shift 2
        ;;
      --agent-display-name)
        require_value "$1" "${2:-}"
        AGENT_DISPLAY_NAME="${2:-}"
        shift 2
        ;;
      --java-home)
        require_value "$1" "${2:-}"
        JAVA_HOME_OVERRIDE="${2:-}"
        shift 2
        ;;
      --java-tarball)
        require_value "$1" "${2:-}"
        JAVA_TARBALL="${2:-}"
        shift 2
        ;;
      --java-url)
        require_value "$1" "${2:-}"
        JAVA_URL="${2:-}"
        shift 2
        ;;
      --java-install-dir)
        require_value "$1" "${2:-}"
        JAVA_INSTALL_DIR="${2:-}"
        shift 2
        ;;
      --java-install-mode)
        require_value "$1" "${2:-}"
        JAVA_INSTALL_MODE="${2:-}"
        shift 2
        ;;
      --java-package)
        require_value "$1" "${2:-}"
        JAVA_PACKAGE="${2:-}"
        shift 2
        ;;
      --skip-java-install)
        SKIP_JAVA_INSTALL=true
        shift
        ;;
      --disable-log-analytics-plugin)
        ENABLE_LOG_ANALYTICS_PLUGIN=false
        shift
        ;;
      --copy-only)
        COPY_ONLY=true
        shift
        ;;
      --dry-run)
        DRY_RUN=true
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        usage >&2
        die "Unknown option: $1"
        ;;
    esac
  done
}

validate_java_options() {
  if [[ -z "${JAVA_INSTALL_MODE}" ]]; then
    return 0
  fi

  JAVA_INSTALL_MODE="$(printf '%s' "${JAVA_INSTALL_MODE}" | tr '[:upper:]' '[:lower:]')"
  case "${JAVA_INSTALL_MODE}" in
    standalone|package)
      ;;
    *)
      die "--java-install-mode must be standalone or package."
      ;;
  esac
}

require_tools() {
  have_command "${OCI_CLI}" || die "OCI CLI not found. Install or set OCI_CLI=/path/to/oci."
  have_command "${PYTHON_BIN}" || die "python3 not found. Set PYTHON_BIN if needed."
  have_command ssh || die "ssh not found."
  have_command scp || die "scp not found."

  [[ -f "${INSTALLER_SOURCE}" ]] || die "Installer source not found: ${INSTALLER_SOURCE}"
  [[ -f "${SSH_KEY}" ]] || die "SSH key not found: ${SSH_KEY}"
  [[ -z "${JAVA_TARBALL}" || -f "${JAVA_TARBALL}" ]] || die "Java tarball not found: ${JAVA_TARBALL}"
}

prepare_work_dir() {
  run mkdir -p "${WORK_DIR}"
}

prepare_download_dir() {
  DOWNLOAD_DIR="$(prompt_text_with_default \
    "OCI_MGMT_AGENT_DOWNLOAD_DIR" \
    "folder where to download the Management Agent software" \
    "${DOWNLOAD_DIR}" \
    "${ROOT_DIR}/files")"
  run mkdir -p "${DOWNLOAD_DIR}"
}

default_time_expires() {
  "${PYTHON_BIN}" - <<'PY'
from datetime import datetime, timedelta, timezone
print((datetime.now(timezone.utc) + timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ"))
PY
}

default_wallet_password() {
  "${PYTHON_BIN}" - <<'PY'
import secrets
import string
classes = [
    string.ascii_lowercase,
    string.ascii_uppercase,
    string.digits,
    "!@#%^&*",
]
chars = [secrets.choice(values) for values in classes]
alphabet = "".join(classes)
chars.extend(secrets.choice(alphabet) for _ in range(28))
secrets.SystemRandom().shuffle(chars)
print("".join(chars))
PY
}

prepare_ssh_key() {
  if [[ "${DRY_RUN}" == "true" ]]; then
    SECURE_SSH_KEY="${WORK_DIR}/ssh-key"
    log "Would create chmod 600 SSH key copy at ${SECURE_SSH_KEY}."
    build_ssh_args
    return 0
  fi

  SECURE_SSH_KEY="$(mktemp "${TMPDIR:-/tmp}/oci-mgmt-agent-ssh-key.XXXXXX")"
  cp "${SSH_KEY}" "${SECURE_SSH_KEY}"
  chmod 600 "${SECURE_SSH_KEY}"
  build_ssh_args
}

cleanup_sensitive_files() {
  if [[ "${DRY_RUN}" == "true" ]]; then
    return 0
  fi

  [[ -n "${SECURE_SSH_KEY:-}" && -f "${SECURE_SSH_KEY}" ]] && rm -f "${SECURE_SSH_KEY}"
  [[ -n "${RESPONSE_FILE:-}" && -f "${RESPONSE_FILE}" ]] && rm -f "${RESPONSE_FILE}"
}

ssh_target() {
  printf '%s@%s' "${SSH_USER}" "${VM_HOST}"
}

build_ssh_args() {
  SSH_ARGS=(
    -i "${SECURE_SSH_KEY}"
    -o IdentitiesOnly=yes
    -o StrictHostKeyChecking=accept-new
    -o "UserKnownHostsFile=${WORK_DIR}/known_hosts"
  )
}

run_ssh() {
  local target
  target="$(ssh_target)"
  if [[ "${DRY_RUN}" == "true" ]]; then
    printf '+ ssh'
    printf ' %q' "${SSH_ARGS[@]}"
    printf ' %q' "${target}"
    printf ' %q' "$*"
    printf '\n'
    return 0
  fi

  ssh "${SSH_ARGS[@]}" "${target}" "$@"
}

run_scp() {
  local source="$1"
  local dest="$2"
  if [[ "${DRY_RUN}" == "true" ]]; then
    printf '+ scp'
    printf ' %q' "${SSH_ARGS[@]}"
    printf ' %q %q\n' "${source}" "${dest}"
    return 0
  fi

  scp "${SSH_ARGS[@]}" "${source}" "${dest}"
}

shell_quote() {
  printf '%q' "$1"
}

append_remote_option() {
  local option="$1"
  local value="$2"
  remote_command="${remote_command} ${option} $(shell_quote "${value}")"
}

resolve_compartment_id() {
  if [[ -n "${COMPARTMENT_ID}" ]]; then
    return 0
  fi

  [[ -n "${COMPARTMENT_NAME}" ]] || die "Set --compartment-id or --compartment-name."
  if [[ "${DRY_RUN}" == "true" ]]; then
    COMPARTMENT_ID="ocid1.compartment.oc1..dryrun"
    log "Would resolve compartment '${COMPARTMENT_NAME}'."
    return 0
  fi

  log "Resolving compartment '${COMPARTMENT_NAME}'"
  local payload
  local payload_file
  payload_file="${WORK_DIR}/compartments.json"
  payload="$("${OCI_CLI}" iam compartment list \
    --name "${COMPARTMENT_NAME}" \
    --compartment-id-in-subtree true \
    --lifecycle-state ACTIVE \
    --all)"
  printf '%s' "${payload}" > "${payload_file}"

  COMPARTMENT_ID="$("${PYTHON_BIN}" - "${payload_file}" <<'PY'
import json
import sys
with open(sys.argv[1], encoding="utf-8") as handle:
    payload = json.load(handle)
items = payload.get("data") or []
if len(items) != 1:
    raise SystemExit(f"Expected exactly one matching compartment, found {len(items)}")
print(items[0]["id"])
PY
)"
  log "Using compartment OCID ${COMPARTMENT_ID}"
}

detect_remote_architecture() {
  PACKAGE_TYPE="$(printf '%s' "${PACKAGE_TYPE}" | tr '[:lower:]' '[:upper:]')"

  if [[ "${PACKAGE_ARCHITECTURE}" != "auto" && "${PACKAGE_ARCHITECTURE}" != "AUTO" ]]; then
    PACKAGE_ARCHITECTURE="$(printf '%s' "${PACKAGE_ARCHITECTURE}" | tr '[:lower:]' '[:upper:]')"
    return 0
  fi

  if [[ "${DRY_RUN}" == "true" ]]; then
    PACKAGE_ARCHITECTURE="X86_64"
    log "Would detect remote architecture; using ${PACKAGE_ARCHITECTURE} for dry run."
    return 0
  fi

  local remote_arch
  remote_arch="$(run_ssh "uname -m" | tr -d '\r\n')"
  case "${remote_arch}" in
    x86_64)
      PACKAGE_ARCHITECTURE="X86_64"
      ;;
    aarch64|arm64)
      PACKAGE_ARCHITECTURE="AARCH64"
      ;;
    *)
      die "Unsupported remote architecture '${remote_arch}'. Pass --package-architecture manually."
      ;;
  esac

  log "Detected remote architecture ${remote_arch}; using ${PACKAGE_ARCHITECTURE}"
}

create_install_key() {
  if [[ -z "${KEY_DISPLAY_NAME}" ]]; then
    KEY_DISPLAY_NAME="mgmt-agent-${VM_HOST}-$(date -u +%Y%m%d%H%M%S)"
  fi

  local create_args=(
    management-agent install-key create
    --compartment-id "${COMPARTMENT_ID}"
    --display-name "${KEY_DISPLAY_NAME}"
    --wait-for-state ACTIVE
  )

  if [[ "${UNLIMITED_KEY}" == "true" ]]; then
    warn "Creating an unlimited install key. Use short-lived one-use keys when possible."
    create_args+=(--is-unlimited true)
  else
    if [[ -z "${TIME_EXPIRES}" ]]; then
      TIME_EXPIRES="$(default_time_expires)"
    fi
    create_args+=(--allowed-key-install-count "${ALLOWED_INSTALL_COUNT}")
    create_args+=(--time-expires "${TIME_EXPIRES}")
  fi

  log "Creating Management Agent install key '${KEY_DISPLAY_NAME}'"
  if [[ "${DRY_RUN}" == "true" ]]; then
    run "${OCI_CLI}" "${create_args[@]}"
    INSTALL_KEY="DRY_RUN_INSTALL_KEY"
    INSTALL_KEY_ID="DRY_RUN_INSTALL_KEY_ID"
    return 0
  fi

  local payload
  payload="$("${OCI_CLI}" "${create_args[@]}")"
  INSTALL_KEY="$(printf '%s' "${payload}" | "${PYTHON_BIN}" -c 'import json,sys; print(json.load(sys.stdin)["data"]["key"])')"
  INSTALL_KEY_ID="$(printf '%s' "${payload}" | "${PYTHON_BIN}" -c 'import json,sys; print(json.load(sys.stdin)["data"]["id"])')"
  log "Created install key OCID ${INSTALL_KEY_ID}"
}

select_agent_image() {
  log "Discovering current ${PACKAGE_TYPE} Management Agent image for ${PACKAGE_ARCHITECTURE}"
  if [[ "${DRY_RUN}" == "true" ]]; then
    IMAGE_NAMESPACE="dryrun_namespace"
    IMAGE_BUCKET="dryrun_bucket"
    IMAGE_OBJECT_NAME="Linux-x86_64/latest/oracle.mgmt_agent.rpm"
    IMAGE_CHECKSUM=""
    IMAGE_VERSION="dryrun"
    IMAGE_PLATFORM_NAME="Linux x86_64"
    log "Would discover Management Agent image metadata through OCI CLI."
    return 0
  fi

  local payload
  local payload_file
  payload_file="${WORK_DIR}/agent-images.json"
  payload="$("${OCI_CLI}" management-agent agent-image list \
    --compartment-id "${COMPARTMENT_ID}" \
    --install-type AGENT \
    --all)"
  printf '%s' "${payload}" > "${payload_file}"

  local image_info
  image_info="$("${PYTHON_BIN}" - "${payload_file}" "${PACKAGE_TYPE}" "${PACKAGE_ARCHITECTURE}" <<'PY'
import json
import re
import sys

package_type = sys.argv[2].upper()
architecture = sys.argv[3].upper()
with open(sys.argv[1], encoding="utf-8") as handle:
    payload = json.load(handle)
items = payload.get("data") or []

def field(item, *names, default=None):
    for name in names:
        value = item.get(name)
        if value is not None:
            return value
    return default

matches = [
    item for item in items
    if field(item, "platformType", "platform-type") == "LINUX"
    and field(item, "packageType", "package-type") == package_type
    and field(item, "packageArchitectureType", "package-architecture-type") == architecture
    and field(item, "lifecycleState", "lifecycle-state", default="ACTIVE") == "ACTIVE"
]

if not matches:
    raise SystemExit(
        f"No active Linux {package_type} Management Agent image found for {architecture}."
    )

def version_key(item):
    return tuple(int(part) for part in re.findall(r"\d+", item.get("version", "")))

matches.sort(key=version_key, reverse=True)
image = matches[0]
details = image.get("imageObjectStorageDetails") or image.get("image-object-storage-details") or {}
object_namespace = field(details, "objectNamespace", "object-namespace")
object_bucket = field(details, "objectBucket", "object-bucket")
object_name = field(details, "objectName", "object-name")
missing = [
    label for label, value in (
        ("object namespace", object_namespace),
        ("object bucket", object_bucket),
        ("object name", object_name),
    )
    if not value
]
if missing:
    raise SystemExit(f"Selected image is missing Object Storage details: {', '.join(missing)}")

print(object_namespace)
print(object_bucket)
print(object_name)
print(field(details, "checksum") or field(image, "checksum") or "")
print(image.get("version") or "")
print(field(image, "platformName", "platform-name") or "")
PY
)"

  IMAGE_NAMESPACE="$(printf '%s\n' "${image_info}" | sed -n '1p')"
  IMAGE_BUCKET="$(printf '%s\n' "${image_info}" | sed -n '2p')"
  IMAGE_OBJECT_NAME="$(printf '%s\n' "${image_info}" | sed -n '3p')"
  IMAGE_CHECKSUM="$(printf '%s\n' "${image_info}" | sed -n '4p')"
  IMAGE_VERSION="$(printf '%s\n' "${image_info}" | sed -n '5p')"
  IMAGE_PLATFORM_NAME="$(printf '%s\n' "${image_info}" | sed -n '6p')"

  log "Selected ${IMAGE_PLATFORM_NAME:-LINUX} agent ${IMAGE_VERSION:-latest}: ${IMAGE_OBJECT_NAME}"
}

download_agent_package() {
  local package_name
  package_name="${IMAGE_OBJECT_NAME##*/}"
  [[ -n "${package_name}" ]] || package_name="oracle.mgmt_agent.$(printf '%s' "${PACKAGE_TYPE}" | tr '[:upper:]' '[:lower:]')"
  LOCAL_PACKAGE_PATH="${DOWNLOAD_DIR}/${package_name}"

  log "Downloading Management Agent software"
  run "${OCI_CLI}" os object get \
    --namespace "${IMAGE_NAMESPACE}" \
    --bucket-name "${IMAGE_BUCKET}" \
    --name "${IMAGE_OBJECT_NAME}" \
    --file "${LOCAL_PACKAGE_PATH}"
}

download_url_package() {
  have_command curl || die "curl is required for --package-url."

  local package_name
  package_name="${PACKAGE_URL%%\?*}"
  package_name="${package_name##*/}"
  [[ -n "${package_name}" ]] || package_name="oracle.mgmt_agent.package"
  LOCAL_PACKAGE_PATH="${DOWNLOAD_DIR}/${package_name}"

  log "Downloading Management Agent software from package URL"
  run curl --fail --location --retry 3 --output "${LOCAL_PACKAGE_PATH}" "${PACKAGE_URL}"
}

prepare_agent_package() {
  if [[ -n "${PACKAGE_URL}" && "${USE_OCI_IMAGE_DOWNLOAD}" == "true" ]]; then
    die "Choose exactly one package source: --package, --package-url, or --use-oci-image-download."
  fi

  if [[ -n "${PACKAGE_URL}" ]]; then
    prepare_download_dir
    download_url_package
    return 0
  fi

  if [[ "${USE_OCI_IMAGE_DOWNLOAD}" == "true" ]]; then
    prepare_download_dir
    select_agent_image
    download_agent_package
    verify_checksum
    return 0
  fi

  LOCAL_PACKAGE_PATH="${PACKAGE_PATH}"
  [[ "${DRY_RUN}" == "true" || -f "${LOCAL_PACKAGE_PATH}" ]] \
    || die "Local Management Agent package not found: ${LOCAL_PACKAGE_PATH}. Put the package under files/ or pass --package-url."
  log "Using local Management Agent package ${LOCAL_PACKAGE_PATH}"
}

sha256_file() {
  local path="$1"
  if have_command sha256sum; then
    sha256sum "${path}" | awk '{print $1}'
  elif have_command shasum; then
    shasum -a 256 "${path}" | awk '{print $1}'
  else
    return 1
  fi
}

verify_checksum() {
  [[ -n "${IMAGE_CHECKSUM}" && "${DRY_RUN}" != "true" ]] || return 0

  local actual expected
  actual="$(sha256_file "${LOCAL_PACKAGE_PATH}" || true)"
  if [[ -z "${actual}" ]]; then
    warn "No SHA-256 tool found; skipping package checksum verification."
    return 0
  fi

  expected="$(printf '%s' "${IMAGE_CHECKSUM}" | tr '[:upper:]' '[:lower:]' | sed 's/^sha256[:=]//')"
  actual="$(printf '%s' "${actual}" | tr '[:upper:]' '[:lower:]')"
  [[ "${actual}" == "${expected}" ]] || die "Package checksum mismatch for ${LOCAL_PACKAGE_PATH}."
  log "Package checksum verified."
}

write_response_file() {
  prompt_wallet_password

  RESPONSE_FILE="${WORK_DIR}/input.rsp"
  if [[ "${DRY_RUN}" == "true" ]]; then
    log "Would write response file ${RESPONSE_FILE} with redacted install key."
    return 0
  fi

  umask 077
  {
    printf 'managementAgentInstallKey = %s\n' "${INSTALL_KEY}"
    printf 'CredentialWalletPassword = %s\n' "${WALLET_PASSWORD}"
    [[ "${ENABLE_LOG_ANALYTICS_PLUGIN}" == "true" ]] && printf 'Service.plugin.logan.download=true\n'
    [[ -n "${AGENT_DISPLAY_NAME}" ]] && printf 'AgentDisplayName = %s\n' "${AGENT_DISPLAY_NAME}"
  } > "${RESPONSE_FILE}"
  chmod 600 "${RESPONSE_FILE}"
  log "Created local response file ${RESPONSE_FILE}"
}

copy_inputs_to_vm() {
  REMOTE_PACKAGE_PATH="${REMOTE_DIR}/${LOCAL_PACKAGE_PATH##*/}"
  REMOTE_RESPONSE_FILE="${REMOTE_DIR}/input.rsp"
  if [[ -n "${JAVA_TARBALL}" ]]; then
    REMOTE_JAVA_TARBALL="${REMOTE_DIR}/${JAVA_TARBALL##*/}"
  fi

  log "Creating remote staging directory ${REMOTE_DIR}"
  run_ssh "mkdir -p ${REMOTE_DIR}"

  log "Copying installer, package, and response file to VM"
  run_scp "${INSTALLER_SOURCE}" "$(ssh_target):${REMOTE_INSTALLER_PATH}"
  run_scp "${LOCAL_PACKAGE_PATH}" "$(ssh_target):${REMOTE_PACKAGE_PATH}"
  run_scp "${RESPONSE_FILE}" "$(ssh_target):${REMOTE_RESPONSE_FILE}"
  if [[ -n "${JAVA_TARBALL}" ]]; then
    run_scp "${JAVA_TARBALL}" "$(ssh_target):${REMOTE_JAVA_TARBALL}"
  fi
  run_ssh "chmod +x ${REMOTE_INSTALLER_PATH} && chmod 600 ${REMOTE_RESPONSE_FILE}"
}

run_remote_installer() {
  if [[ "${COPY_ONLY}" == "true" ]]; then
    warn "Copy-only mode selected. Remote response file contains the install key: ${REMOTE_RESPONSE_FILE}"
    log "Run later with: sudo ${REMOTE_INSTALLER_PATH} --package ${REMOTE_PACKAGE_PATH} --response-file ${REMOTE_RESPONSE_FILE}"
    return 0
  fi

  local remote_command
  remote_command="sudo ${REMOTE_INSTALLER_PATH} --package ${REMOTE_PACKAGE_PATH} --response-file ${REMOTE_RESPONSE_FILE}"
  [[ "${ENABLE_LOG_ANALYTICS_PLUGIN}" == "true" ]] && remote_command="${remote_command} --enable-log-analytics-plugin"
  [[ -n "${AGENT_DISPLAY_NAME}" ]] && append_remote_option "--agent-display-name" "${AGENT_DISPLAY_NAME}"
  [[ -n "${JAVA_HOME_OVERRIDE}" ]] && append_remote_option "--java-home" "${JAVA_HOME_OVERRIDE}"
  [[ -n "${REMOTE_JAVA_TARBALL:-}" ]] && append_remote_option "--java-tarball" "${REMOTE_JAVA_TARBALL}"
  [[ -n "${JAVA_URL}" ]] && append_remote_option "--java-url" "${JAVA_URL}"
  [[ -n "${JAVA_INSTALL_DIR}" ]] && append_remote_option "--java-install-dir" "${JAVA_INSTALL_DIR}"
  [[ -n "${JAVA_INSTALL_MODE}" ]] && append_remote_option "--java-install-mode" "${JAVA_INSTALL_MODE}"
  [[ -n "${JAVA_PACKAGE}" ]] && append_remote_option "--java-package" "${JAVA_PACKAGE}"
  [[ "${SKIP_JAVA_INSTALL}" == "true" ]] && remote_command="${remote_command} --skip-java-install"
  remote_command="${remote_command}; status=\$?; rm -f ${REMOTE_RESPONSE_FILE}; exit \$status"

  log "Running remote Management Agent installer"
  run_ssh "${remote_command}"
}

main() {
  parse_args "$@"
  validate_java_options
  require_tools
  prepare_work_dir
  prepare_ssh_key
  trap cleanup_sensitive_files EXIT
  resolve_compartment_id
  detect_remote_architecture
  create_install_key
  prepare_agent_package
  write_response_file
  copy_inputs_to_vm
  run_remote_installer
  log "Bootstrap workflow complete."
}

main "$@"
