#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

load_env_file() {
  local file="$1"

  if [[ ! -f "${file}" ]]; then
    return
  fi

  while IFS= read -r line || [[ -n "${line}" ]]; do
    line="${line#"${line%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"

    if [[ -z "${line}" || "${line}" == \#* || "${line}" != *=* ]]; then
      continue
    fi

    local key="${line%%=*}"
    local value="${line#*=}"
    key="${key#"${key%%[![:space:]]*}"}"
    key="${key%"${key##*[![:space:]]}"}"

    if [[ ! "${key}" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]]; then
      continue
    fi

    if [[ -z "${!key+x}" ]]; then
      export "${key}=${value}"
    fi
  done < "${file}"
}

require_env() {
  local missing=0

  for key in "$@"; do
    if [[ -z "${!key:-}" ]]; then
      echo "Missing required environment value: ${key}" >&2
      missing=1
    fi
  done

  if [[ "${missing}" -ne 0 ]]; then
    echo "Copy .env.oci.example to .env.oci.local and fill in the missing values." >&2
    exit 1
  fi
}

normalize_registry_endpoint() {
  local endpoint="$1"
  endpoint="${endpoint#https://}"
  endpoint="${endpoint#http://}"
  endpoint="${endpoint%/}"
  printf '%s' "${endpoint}"
}

container_engine_ready() {
  local cli="$1"
  command -v "${cli}" >/dev/null 2>&1 && "${cli}" info >/dev/null 2>&1
}

choose_container_cli() {
  if [[ -n "${CONTAINER_CLI:-}" ]]; then
    if container_engine_ready "${CONTAINER_CLI}"; then
      printf '%s' "${CONTAINER_CLI}"
      return
    fi

    echo "${CONTAINER_CLI} is installed but is not reachable." >&2
    echo "Start its daemon/VM, then retry." >&2
    exit 1
  fi

  if container_engine_ready docker; then
    printf 'docker'
    return
  fi

  if container_engine_ready podman; then
    printf 'podman'
    return
  fi

  echo "No reachable container engine found." >&2

  if command -v docker >/dev/null 2>&1; then
    echo "- Docker is installed, but the daemon is not running. Start Docker Desktop or another Docker daemon." >&2
  fi

  if command -v podman >/dev/null 2>&1; then
    echo "- Podman is installed, but the VM/socket is not reachable. Try: podman machine start" >&2
  fi

  echo "Then rerun: bash scripts/oci_build_push.sh" >&2
  exit 1
}

load_env_file "${ROOT_DIR}/.env.oci.local"
load_env_file "${ROOT_DIR}/.env.local"
load_env_file "${ROOT_DIR}/.env"

if [[ -z "${OCI_CONTAINER_REGISTRY_ENDPOINT:-}" ]]; then
  OCI_CONTAINER_REGISTRY_ENDPOINT="ocir.${OCI_CONTAINER_REGISTRY_REGION:-eu-frankfurt-1}.oci.oraclecloud.com"
fi

require_env \
  OCI_CONTAINER_REGISTRY_ENDPOINT \
  OCI_CONTAINER_REGISTRY_NAMESPACE \
  OCI_CONTAINER_REPOSITORY \
  OCI_IMAGE_NAME \
  OCI_IMAGE_TAG

CONTAINER_CLI="$(choose_container_cli)"
REGISTRY_ENDPOINT="$(normalize_registry_endpoint "${OCI_CONTAINER_REGISTRY_ENDPOINT}")"
LOCAL_IMAGE="${OCI_IMAGE_NAME}:${OCI_IMAGE_TAG}"
IMAGE_URI="${OCI_IMAGE_URI:-${REGISTRY_ENDPOINT}/${OCI_CONTAINER_REGISTRY_NAMESPACE}/${OCI_CONTAINER_REPOSITORY}:${OCI_IMAGE_TAG}}"
OCI_IMAGE_PLATFORM="${OCI_IMAGE_PLATFORM:-linux/amd64}"

echo "Using ${CONTAINER_CLI}"
echo "Building ${LOCAL_IMAGE} for ${OCI_IMAGE_PLATFORM}"
"${CONTAINER_CLI}" build --platform "${OCI_IMAGE_PLATFORM}" -t "${LOCAL_IMAGE}" "${ROOT_DIR}"

echo "Tagging ${IMAGE_URI}"
"${CONTAINER_CLI}" tag "${LOCAL_IMAGE}" "${IMAGE_URI}"

if [[ "${OCI_SKIP_REGISTRY_LOGIN:-false}" != "true" ]]; then
  require_env OCI_OCIR_USERNAME OCI_OCIR_AUTH_TOKEN

  echo "Logging in to ${REGISTRY_ENDPOINT}"
  printf '%s' "${OCI_OCIR_AUTH_TOKEN}" | "${CONTAINER_CLI}" login \
    "${REGISTRY_ENDPOINT}" \
    --username "${OCI_OCIR_USERNAME}" \
    --password-stdin
fi

echo "Pushing ${IMAGE_URI}"
"${CONTAINER_CLI}" push "${IMAGE_URI}"

echo "Pushed ${IMAGE_URI}"
