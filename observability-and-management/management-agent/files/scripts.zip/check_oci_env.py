from pathlib import Path
import os
import sys


ROOT_DIR = Path(__file__).resolve().parent.parent
ENV_FILES = (".env.oci.local", ".env.local", ".env")

REQUIRED = (
    "OCI_REGION",
    "OCI_COMPARTMENT_OCID",
    "OCI_AVAILABILITY_DOMAIN",
    "OCI_CONTAINER_REGISTRY_ENDPOINT",
    "OCI_CONTAINER_REGISTRY_NAMESPACE",
    "OCI_CONTAINER_REPOSITORY",
    "OCI_IMAGE_NAME",
    "OCI_IMAGE_TAG",
    "OCI_CONTAINER_PORT",
    "OCI_CONTAINER_INSTANCE_DISPLAY_NAME",
    "OCI_CONTAINER_INSTANCE_SHAPE",
    "OCI_CONTAINER_INSTANCE_OCPUS",
    "OCI_CONTAINER_INSTANCE_MEMORY_GB",
    "OCI_PUBLIC_SUBNET_OCID",
    "DATABASE_URL",
    "OCI_OBJECT_STORAGE_NAMESPACE",
    "OCI_OBJECT_STORAGE_BUCKET",
    "OCI_APM_DATA_UPLOAD_ENDPOINT",
    "OCI_APM_PUBLIC_DATA_KEY",
    "OCI_APM_PRIVATE_DATA_KEY",
    "SESSION_SECRET",
)

OPTIONAL_LOCAL_CLI = (
    "OCI_TENANCY_OCID",
    "OCI_USER_OCID",
    "OCI_FINGERPRINT",
    "OCI_PRIVATE_KEY_PATH",
    "OCI_PROFILE",
)

OPTIONAL_OCIR_PUSH = (
    "OCI_OCIR_USERNAME",
    "OCI_OCIR_AUTH_TOKEN",
)


def main() -> int:
    for env_file in ENV_FILES:
        load_env(ROOT_DIR / env_file)

    missing = [key for key in REQUIRED if not os.getenv(key)]
    local_cli_missing = [key for key in OPTIONAL_LOCAL_CLI if not os.getenv(key)]
    ocir_push_missing = [key for key in OPTIONAL_OCIR_PUSH if not os.getenv(key)]

    if missing:
        print("Missing required OCI environment values:", file=sys.stderr)
        for key in missing:
            print(f"- {key}", file=sys.stderr)
        print("\nCopy `.env.oci.example` to `.env.oci.local` and fill in the missing values.", file=sys.stderr)
    else:
        print("OCI deployment environment is ready.")

    if local_cli_missing:
        print("\nOptional local OCI CLI/API auth values not set:")
        for key in local_cli_missing:
            print(f"- {key}")
        print("These are needed only when local scripts authenticate directly to OCI.")

    if ocir_push_missing:
        print("\nOptional OCIR push/private-pull values not set:")
        for key in ocir_push_missing:
            print(f"- {key}")
        print("These are needed to push to a private OCIR repository and render image pull secrets.")

    return 1 if missing else 0


def load_env(path: Path) -> None:
    if not path.exists():
        return

    for line in path.read_text().splitlines():
        trimmed = line.strip()

        if not trimmed or trimmed.startswith("#") or "=" not in trimmed:
            continue

        key, value = trimmed.split("=", 1)
        os.environ.setdefault(key, value.strip().strip("\"'"))


if __name__ == "__main__":
    raise SystemExit(main())
