define([], () => {
  'use strict';

  class PageModule {



 onload(running){
        const startBtn = document.getElementById("startBtn");
        const stopBtn = document.getElementById("stopBtn");



        let mediaStream;
        let ws;
        let added = false;
        let lastMessage = '';
        let recorder;
        let audioContext;
         var selectSingle = document.getElementById('lang_id');
          var selectedLanguage = selectSingle.value;
          console.log("El idioma seleccionado es: " + selectedLanguage);
          let lang_id=selectedLanguage;
     

        startBtn.addEventListener("click", async () => {
            try {
                if (ws && ws.readyState === WebSocket.OPEN) {
                    ws.close();
                    console.log("WebSocket connection closed before opening a new one.");
                  }

                mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
                startBtn.disabled = true;
                stopBtn.disabled = false;
                // Obtener el valor del componente <oj-select-single>
                var selectSingle = document.getElementById('lang_id');
                var selectedLanguage = selectSingle.value;
                console.log("El idioma seleccionado es: " + selectedLanguage);
                 lang_id=selectedLanguage;

                
                connectWebSocket(lang_id);
                return true;
            } catch (error) {
                console.error("Error accessing microphone:", error);
            }
        });

        stopBtn.addEventListener("click", () => {
          if (mediaStream) {
                    mediaStream.getTracks().forEach(track => track.stop());
                  }
                  stopBtn.disabled = true;
                  startBtn.disabled = false;
                 

                  // Cerrar el WebSocket cuando se detiene la grabación
                  if (ws) {
                    ws.close();
                  }

                    // Desconectar y limpiar el audio
                    if (recorder) {
                      recorder.disconnect();
                      recorder = null;
                    }

                    if (audioContext) {
                      audioContext.close();
                      audioContext = null;
                    }


                  return false;
        });

    

function connectWebSocket(lang_id) {
    ws = new WebSocket("wss://speech.oracloud.be:8080");

    ws.onopen = () => {
        console.log("WebSocket connection opened");
        const initialMessage = JSON.stringify({ language_code: lang_id });
        ws.send(initialMessage);
        sendAudio();
    };

    ws.onmessage = (event) => {
        let container = document.getElementById("transcript");
        let message = event.data.trim();

        if (message.indexOf('</final>') > -1) {
            // Crear un nuevo párrafo solo si added es falso
            if (!added) {
                let newP = document.createElement("p");
                newP.innerHTML = '';
                container.appendChild(newP);
                added = true;
            }
        } else {
            // Reemplazar el contenido del último párrafo si es diferente y no contiene </final>
            if (container.lastElementChild) {
                if (!added || container.lastElementChild.innerHTML.indexOf('</final>') === -1) {
                    container.lastElementChild.innerHTML = message;
                }
            } else {
                let newP = document.createElement("p");
                newP.innerHTML = message;
                container.appendChild(newP);
            }
            added = false;
        }
        container.scrollTop = container.scrollHeight;
    };

    ws.onerror = (error) => {
        console.error("WebSocket error:", error);
    };

    ws.onclose = () => {
        console.log("WebSocket connection closed, attempting to reconnect in 3 seconds...");
      //  setTimeout(() => connectWebSocket(lang_id), 3000); 
    };
}



        function downsampleBuffer(buffer, sampleRate, outSampleRate) {
            if (outSampleRate == sampleRate) {
                return buffer;
            }
            if (outSampleRate > sampleRate) {
                throw 'downsampling rate show be smaller than original sample rate';
            }
            var sampleRateRatio = sampleRate / outSampleRate;
            var newLength = Math.round(buffer.length / sampleRateRatio);
            var result = new Int16Array(newLength);
            var offsetResult = 0;
            var offsetBuffer = 0;
            while (offsetResult < result.length) {
                var nextOffsetBuffer = Math.round((offsetResult + 1) * sampleRateRatio);
                var accum = 0,
                    count = 0;
                for (var i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
                    accum += buffer[i];
                    count++;
                }

                result[offsetResult] = Math.min(1, accum / count) * 0x7fff;
                offsetResult++;
                offsetBuffer = nextOffsetBuffer;
            }
            return result.buffer;
        } 

        function sendAudio() {
             if (!audioContext) {
              audioContext = new AudioContext();
            }
            const source = audioContext.createMediaStreamSource(mediaStream);
            const recorder = audioContext.createScriptProcessor(0, 1, 1);

            recorder.onaudioprocess = (event) => {
                const audioData = event.inputBuffer.getChannelData(0);
                var resampled = downsampleBuffer(audioData, 44100, 16000);
                   if (ws && ws.readyState === WebSocket.OPEN) {
                      ws.send(resampled);
                    } else {
                      console.warn("WebSocket is not open yet.");
                    }
            };
            source.connect(recorder);
            recorder.connect(audioContext.destination);
        }
  
};
    

         
  }
  
  return PageModule;
});
