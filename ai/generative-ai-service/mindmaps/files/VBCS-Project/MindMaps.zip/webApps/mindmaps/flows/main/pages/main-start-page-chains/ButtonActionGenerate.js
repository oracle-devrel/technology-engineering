define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionGenerate extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

    
if ($variables.ojTabBar18885457971SelectedItem==='oj-tab-bar-1888545797-1-tab-3')
{
                  let container = document.getElementById("transcript");
                  let value = container.textContent;
               //   alert(value);
                  $variables.content = value;
                  if (value.length > '30')
                  {
                    $variables.transcribed = true;
                  }else{       
          await Actions.fireNotificationEvent(context, {
            summary: 'Attention',
            message: 'Very short text to process',
            displayMode: 'transient',
            type: 'warning',
          });

                      return 'fail';
                  }
}

 let json_schema= "{\"type\":\"object\",\"properties\":{\"class\":{\"type\":\"string\",\"enum\":[\"go.TreeModel\"]},\"nodeDataArray\":{\"type\":\"array\",\"items\":[{\"type\":\"object\",\"properties\":{\"key\":{\"type\":\"integer\"},\"text\":{\"type\":\"string\",\"maxLength\":100},\"loc\":{\"type\":\"string\"},\"brush\":{\"type\":\"string\",\"enum\":[\"skyblue\",\"darkseagreen\",\"palevioletred\",\"coral\", \"darkred\", \"lightgreen\",\"white\"]}},\"required\":[\"key\",\"text\",\"loc\",\"brush\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"key\":{\"type\":\"integer\"},\"parent\":{\"type\":\"integer\"},\"text\":{\"type\":\"string\",\"maxLength\":100},\"brush\":{\"type\":\"string\",\"enum\":[\"skyblue\",\"darkseagreen\",\"palevioletred\",\"coral\"]},\"dir\":{\"type\":\"string\",\"enum\":[\"left\",\"right\"]}},\"required\":[\"key\",\"parent\",\"text\",\"brush\",\"dir\"],\"additionalProperties\":false}]}},\"required\":[\"class\",\"nodeDataArray\"],\"additionalProperties\":false}";

      await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-loading',
        method: 'open',
      });

   

    //  let exampleGoJS = "Un plan de proyecto incluye varias tareas. Las tareas se dividen en subtareas. Cada subtarea tiene una fecha de inicio y un responsable. LA etiqueta Multiplier y keyMultiplier NO EXISTE. Respuesta esperada: {\"class\":\"go.TreeModel\",\"nodeDataArray\":[{\"key\":1,\"text\":\"Caso judicial contra el Fiscal General\",\"loc\":\"0 0\",\"brush\":\"skyblue\"},{\"key\":11,\"parent\":1,\"text\":\"Investigación por filtración de datos\",\"brush\":\"skyblue\",\"dir\":\"right\"},{\"key\":111,\"parent\":11,\"text\":\"Revelación de secretos\",\"brush\":\"skyblue\",\"dir\":\"right\"},{\"key\":112,\"parent\":11,\"text\":\"Pareja de Isabel Díaz Ayuso\",\"brush\":\"skyblue\",\"dir\":\"right\"},{\"key\":113,\"parent\":11,\"text\":\"Pilar Rodríguez\",\"brush\":\"skyblue\",\"dir\":\"right\"},{\"key\":12,\"parent\":1,\"text\":\"Informe pericial de la Guardia Civil\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":121,\"parent\":12,\"text\":\"Análisis de mensajes de WhatsApp\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":122,\"parent\":12,\"text\":\"Informe de 57 páginas\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":123,\"parent\":12,\"text\":\"Registro del despacho\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":2,\"parent\":1,\"text\":\"Conclusiones de la investigación\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":21,\"parent\":2,\"text\":\"Participación preeminente de García Ortiz\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":22,\"parent\":2,\"text\":\"Filtraciones desde la Fiscalía\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":23,\"parent\":2,\"text\":\"Gestiones personales del Fiscal General\",\"brush\":\"palevioletred\",\"dir\":\"left\"}]} ";
      let exampleGoJS2 = "{\"class\":\"go.TreeModel\",\"nodeDataArray\":[{\"key\":0,\"text\":\"Mind Map\",\"loc\":\"0 0\"},{\"key\":1,\"parent\":0,\"text\":\"Getting more time\",\"brush\":\"skyblue\",\"dir\":\"right\"},{\"key\":11,\"parent\":1,\"text\":\"Wake up early\",\"brush\":\"skyblue\",\"dir\":\"right\"},{\"key\":12,\"parent\":1,\"text\":\"Delegate\",\"brush\":\"skyblue\",\"dir\":\"right\"},{\"key\":13,\"parent\":1,\"text\":\"Simplify\",\"brush\":\"skyblue\",\"dir\":\"right\"},{\"key\":2,\"parent\":0,\"text\":\"More effective use\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":21,\"parent\":2,\"text\":\"Planning\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":211,\"parent\":21,\"text\":\"Priorities\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":212,\"parent\":21,\"text\":\"Ways to focus\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":22,\"parent\":2,\"text\":\"Goals\",\"brush\":\"darkseagreen\",\"dir\":\"right\"},{\"key\":3,\"parent\":0,\"text\":\"Time wasting\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":31,\"parent\":3,\"text\":\"Too many meetings\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":32,\"parent\":3,\"text\":\"Too much time spent on details\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":33,\"parent\":3,\"text\":\"Message fatigue\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":331,\"parent\":31,\"text\":\"Check messages less\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":332,\"parent\":31,\"text\":\"Message filters\",\"brush\":\"palevioletred\",\"dir\":\"left\"},{\"key\":4,\"parent\":0,\"text\":\"Key issues\",\"brush\":\"coral\",\"dir\":\"left\"},{\"key\":41,\"parent\":4,\"text\":\"Methods\",\"brush\":\"coral\",\"dir\":\"left\"},{\"key\":42,\"parent\":4,\"text\":\"Deadlines\",\"brush\":\"coral\",\"dir\":\"left\"},{\"key\":43,\"parent\":4,\"text\":\"Checkpoints\",\"brush\":\"coral\",\"dir\":\"left\"}]} OJO QUE Multiplier y keyMultiplier NO EXISTE.";
      const response = await Actions.callRest(context, {
        endpoint: 'GenAIChat/postChat',
        body: {
        "compartmentId": $application.variables.compartmentID,
        "servingMode": {
          "modelId": $application.variables.cohereModel,
          "servingType": "ON_DEMAND"
        },
        "chatRequest": {
          "message" : "Act as a JSON generator for a mind map. Based on the provided text, generate a JSON object strictly following the provided JSON schema "+json_schema+". Ensure the following: 1. Only include properties defined in the schema (e.g., 'key', 'text', 'parent', 'brush', 'dir', and 'loc'). 2. Do not generate undefined or extra properties, such as 'Multiplier'. 3. Validate the root node includes 'loc' but no 'parent' or 'dir'. 4. Ensure compliance with the schema and JSON validation rules. 5. Return only the valid JSON, no comments, explanations, or additional text. 6. Limit the `nodeDataArray` array to 15 elements maximum. Generate the JSON for the text "+$variables.content+". Do not generate properties named `Multiplier` or any additional keys beyond those defined in the schema. Ensure strict compliance with the JSON schema provided and include things like Multiplier: \"do not include\". Here you have an example: "+exampleGoJS2,
          "maxTokens": 1500,
          "isStream": false,
          "apiFormat": "COHERE",
          "frequencyPenalty": 1.0,
          "preambleOverride":"You are a Mind Map generator",
          "presencePenalty": 0,
          "temperature": 0.3,
          "topP": 0.7,
          "topK": 1
        }
      },
      });
  
   function getJSONData(arg1) {
      const myArray = arg1.split("```json");
      let word = myArray[1];
      let finalObject = word.split("```");
      let oo = finalObject[0];
      return JSON.parse(oo);
    }

function replaceMultiplier(obj) {
  // Si el objeto es un array, recorremos cada elemento
  if (Array.isArray(obj)) {
    obj.forEach(item => replaceMultiplier(item));
  } else if (typeof obj === 'object' && obj !== null) {
    // Si el objeto tiene la propiedad "Multiplier", la cambiamos a "text"
    if (obj.Multiplier !== undefined) {
      obj.text = obj.Multiplier;
      delete obj.Multiplier; // Eliminamos la propiedad original
    }

    // Recorremos las propiedades del objeto
    for (let key in obj) {
      if (obj.hasOwnProperty(key)) {
        replaceMultiplier(obj[key]); // Llamamos recursivamente para propiedades anidadas
      }
    }
  }
}
 $variables.jsonNodes=  response.body.chatResponse.text;


      await Actions.callChain(context, {
        chain: 'loadGoJS',
      });

    }
  }

  return ButtonActionGenerate;
});
