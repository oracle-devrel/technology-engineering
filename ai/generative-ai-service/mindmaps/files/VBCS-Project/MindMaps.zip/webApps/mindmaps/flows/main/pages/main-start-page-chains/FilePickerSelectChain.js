define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {
    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const ojDialogLoadingOpen = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-loading',
        method: 'open',
      });

      // Obtén una referencia al archivo
      const file = files[0];

      // Usa FileReader para leer el archivo
      const reader = new FileReader();

      // Crea una promesa para esperar la carga del archivo
      const base64String = await new Promise((resolve, reject) => {
        reader.onloadend = () => {
          try {
            // Remueve la parte del data URL
            const result = reader.result.replace('data:', '').replace(/^.+,/, '');
            resolve(result);
          } catch (error) {
            reject(error);
          }
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Llama al servicio REST y espera la respuesta
      try {
        const response = await Actions.callRest(context, {
          endpoint: 'analyzeDocument/postAnalyzeDocument',
          body: {
            features: [
              {
                featureType: "TEXT_EXTRACTION",
                generateSearchablePdf: false,
              },
            ],
            processorType: "GENERAL",
            isZipOutputEnabled: false,
            language: "ENG",
            compartmentId: $application.variables.compartmentID,
            document: {
              source: "INLINE",
              data: base64String,
            },
            outputLocation: {
              namespaceName: $application.variables.namespace,
              bucketName: $application.variables.bucketName,
              prefix: $application.variables.prefix,
            },
          },
        });

        // Extrae los datos del cuerpo de la respuesta
      
let paragraphs = [];

response.body.pages.forEach((page) => {
  const data = page.lines;
  paragraphs = paragraphs.concat(joinLinesInParagraphs(data)); // Combina los párrafos de cada página
});

        // Función para unir líneas en párrafos
        function joinLinesInParagraphs(data) {
          let paragraphs = [];
          let currentParagraph = [];

          data.forEach((line, index) => {
            currentParagraph.push(line.text);

            // Si es la última línea o el siguiente texto no sigue inmediatamente después, creamos un párrafo
            if (
              index === data.length - 1 ||
              data[index + 1].boundingPolygon.normalizedVertices[0].y - line.boundingPolygon.normalizedVertices[0].y >
                0.05
            ) {
              paragraphs.push(currentParagraph.join(' '));
              currentParagraph = [];
            }
          });

          return paragraphs;
        }

        // Unir líneas en párrafos
        //const paragraphs = joinLinesInParagraphs(data);

        // Mostrar los párrafos resultantes
        paragraphs.forEach((paragraph, index) => {
          console.log(`Párrafo ${index + 1}: ${paragraph}`);
          $variables.content = paragraphs.join(" ");
        });

        const ojDialogLoadingClose = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-loading',
          method: 'close',
        });

        await Actions.callChain(context, {
          chain: 'ButtonActionGenerate',
        });
      } catch (error) {
        console.error('Error al llamar al servicio REST:', error);
      }
    }
  }

  return FilePickerSelectChain;
});
