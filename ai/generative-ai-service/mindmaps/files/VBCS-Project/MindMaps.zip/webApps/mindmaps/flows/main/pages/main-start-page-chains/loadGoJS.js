define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadGoJS extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;


        // Inicialización del diagrama
        const $ = go.GraphObject.make;

         // Limpia el div y destruye el diagrama existente si es necesario
        const diagramDiv = document.getElementById("myDiagramDiv");
        if (diagramDiv) {
          const existingDiagram = go.Diagram.fromDiv("myDiagramDiv");
          if (existingDiagram) {
            existingDiagram.clear();
            existingDiagram.div = null;
          }
          diagramDiv.innerHTML = ""; // Limpia el contenido del div
        }


        const myDiagram = $(go.Diagram, "myDiagramDiv", {
            "undoManager.isEnabled": true, // Habilitar deshacer/rehacer
            layout: $(go.TreeLayout, {
                angle: 90, // Orientación del árbol
                layerSpacing: 80
            })
        });

        // Plantilla de nodos
        myDiagram.nodeTemplate = $(
            go.Node,
            "Auto",
            {
                locationSpot: go.Spot.Center,
                selectionAdorned: true,
                cursor: "pointer",
                deletable: false
            },
            $(
                go.Shape,
                "RoundedRectangle",
                { strokeWidth: 2 },
                new go.Binding("fill", "brush") // Color del nodo
            ),
            $(
                go.TextBlock,
                {
                    font: "bold 12pt sans-serif",
                    stroke: "white",
                    margin: 8,
                    wrap: go.TextBlock.WrapFit,
                    editable: true // Permite editar el texto directamente
                },
                new go.Binding("text", "text").makeTwoWay()
            )
        );

        // Plantilla de enlaces
        myDiagram.linkTemplate = $(
            go.Link,
            { routing: go.Link.AvoidsNodes, curve: go.Link.Bezier, corner: 5 },
            $(
                go.Shape,
                { strokeWidth: 2, stroke: "#3F5364" } // Línea del enlace
            )
        );

     
        // const jsonData = $variables.jsonNodes;

        // Cargar el modelo desde JSON
        console.log($variables.jsonNodes);
        myDiagram.model = go.Model.fromJson($variables.jsonNodes);
        myDiagram.scale = 0.5;



      const ojDialogLoadingClose = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-loading',
        method: 'close',
      });

      $variables.generated=true;


            document.getElementById("exportPng").addEventListener("click", () => {
            const imgData = myDiagram.makeImageData({
                scale: 0.5, // Escala de la imagen
                background: "white" // Fondo de la imagen
            });

            // Crear un enlace para descargar la imagen
            const link = document.createElement("a");
            link.href = imgData;
            link.download = "diagram.png";
            link.click();
        });


    }
  }

  return loadGoJS;
});
