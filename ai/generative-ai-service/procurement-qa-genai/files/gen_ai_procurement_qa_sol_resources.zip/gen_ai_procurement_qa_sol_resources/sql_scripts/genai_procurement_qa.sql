CREATE TABLE purchaseorders (
    order_id                   VARCHAR2(15)     NOT NULL,
    order_status               VARCHAR2(40),
    order_creation_date        TIMESTAMP,
    order_proc_bsns_unt        VARCHAR2(40),
    order_bill_bsns_unt        VARCHAR2(40),
    order_reqs_bsns_unt        VARCHAR2(40),
    order_supplier_name        VARCHAR2(120),
    order_buyer_name           VARCHAR2(120),
    ordered_amount             FLOAT,
    total_tax                  FLOAT,
    total_ordered              FLOAT);

ALTER TABLE purchaseorders
  ADD CONSTRAINT purchaseorders_pk
  PRIMARY KEY (order_id)
  RELY DISABLE NOVALIDATE;


CREATE TABLE polines (
    line_id                     NUMBER(15)      NOT NULL,
    order_id                    VARCHAR2(15)    NOT NULL,
    item_description            VARCHAR2(100),
    item_category               VARCHAR2(50),
    currency                    VARCHAR2(5),
    price                       FLOAT,
    uom                         VARCHAR2(5),
    quantity                    FLOAT,
    ship_to_org_name            VARCHAR2(100),
    ship_to_loc_name            VARCHAR2(100),
    po_charge_account           VARCHAR2(100));

ALTER TABLE polines
  ADD CONSTRAINT polines_pk
  PRIMARY KEY (line_id)
  RELY DISABLE NOVALIDATE;

ALTER TABLE polines
  ADD CONSTRAINT polines_fk
  FOREIGN KEY (order_id) REFERENCES purchaseorders (order_id)
  RELY DISABLE NOVALIDATE;


create or replace PACKAGE EXECUTESQL AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  
   PROCEDURE executesql (sql_stmt IN VARCHAR2, gen_result OUT sys_refcursor);

END EXECUTESQL;


create or replace PACKAGE BODY EXECUTESQL AS

  PROCEDURE executesql (sql_stmt IN VARCHAR2, gen_result OUT sys_refcursor) AS

   BEGIN
    -- TODO: Implementation required for PROCEDURE EXECUTESQL.texttosql
    OPEN gen_result FOR sql_stmt;
    
  END executesql;

END EXECUTESQL;
