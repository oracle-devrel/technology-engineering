# AIDP Select AI Custom Tool

This package exposes `SupplierFeedbackQuery` in AIDP. It takes a plain-language question, reads database login values from AIDP Credential Store at runtime, obtains a short-lived database token, and calls the Autonomous AI Database MCP tool `SUPPLIER_FEEDBACK_SQL` with `ACTION=runsql`.

## Before using it

The database must have a Select AI profile scoped to the intended tables, MCP enabled, and a tool named `SUPPLIER_FEEDBACK_SQL` with inputs `ACTION` and `QUERY`. See Oracle's [Select AI profile guide](https://docs.oracle.com/en/cloud/paas/autonomous-database/serverless/adbsb/select-ai-manage-profiles.html) and [MCP Server guide](https://docs.oracle.com/en/cloud/paas/autonomous-database/serverless/adbsb/use-mcp-server.html).

## Configure in AIDP

1. Create a **Secret Token** credential containing keys `username` and `password`. Do not put their values in this package.
2. Add egress to `dataaccess.adb.<region>.oraclecloudapps.com`.
3. Upload the ZIP as a Custom Tool package and enable `SupplierFeedbackQuery`.
4. Set `region`, `database_ocid`, `credential_name`, and the username/password key names in the tool's configuration.
5. Test a question against a table in the Select AI profile.

The ZIP contains no credentials, OCIDs, customer data, or preselected region. Test the tool in your AIDP workspace; local packaging does not verify access to your database or network.
