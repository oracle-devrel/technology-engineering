define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadData extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

//text: "<speak><voice name=\"Cindy\">Hi Bob, welcome to the show. Today we're going to talk about the latest advancements in space exploration.</voice><voice name=\"Bob\">Thanks Alice, I'm excited to be here. Space exploration is a fascinating topic, and there have been some incredible breakthroughs recently.</voice><voice name=\"Cindy\">Absolutely. NASA's Artemis program, for example, aims to return humans to the moon by 2024. What are your thoughts on this initiative?</voice><voice name=\"Bob\">I think it's a great step forward. The moon is a crucial testing ground for deeper space missions, and establishing a sustainable presence there will be essential for future exploration.</voice>  <voice name=\"Cindy\">That's a great point. And what about private companies like SpaceX and Blue Origin? How do you think they'll contribute to the future of space travel?</voice><voice name=\"Bob\">Well, they're already making significant strides. SpaceX's reusable rockets, for instance, have greatly reduced the cost of accessing space. And Blue Origin's New Armstrong program is focused on taking humans to the lunar surface.</voice><voice name=\"Cindy\">Wow, it's an exciting time for space enthusiasts. Finally, what do you think is the most significant challenge facing space exploration today?</voice><voice name=\"Bob\">I think it's the psychological and physical effects of long-term space travel on the human body. We need to better understand how to protect astronauts on deep space missions.</voice></speak>",
let sample = "Combinen this kind of tags to create a more natural conversation. But never include more than 2 words between this kind of prosody rate tags. Regarding <prosody rate=\"20%\"> never use a value higher than 20% or lower than -20%. Sample of tags that can be used: <speak>For dramatic purposes, you might wish to <prosody rate=\"slow\">slow up the speaking rate of your text.</prosody>. Sometimes it can be useful to <prosody volume=\"+5dB\">increase the volume for a specific speech.</prosody></speak><speak><prosody rate=\"20%\">Sometimes combining attributes <prosody pitch=\"medium\">can change the impression your audience has of a voice</prosody> as well.</prosody></speak>";

      $variables.processing = true;

      const ojDialogGeneratingOpen = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-generating',
        method: 'open',
      });
          


      const response2 = await Actions.callRest(context, {
        endpoint: 'Summarization/postChat',
        body: {
        "compartmentId": "ocid1.compartment.oc1..aaaaaaaa4bz2p36xc2wvhqvxr65s22xmp5jmm5gtlnauu3aajpx6pfgtwrxq",
        "servingMode": {
          "modelId": "cohere.command-r-plus",
          "servingType": "ON_DEMAND"
        },
        "chatRequest": {
          "message": "Provide a TTS SSML conversation between Cindy and Bob around "+$variables.textInput+". Must be engaging. Maintain this format and don't provide anything else to the answer, only the SSML: <speak><voice name='Cindy'>Hi Bob, <prosody rate=\"20%\">welcome to the show</prosody>. Today we're going to talk about the latest advancements in space exploration.</voice><voice name='Bob'>Thanks Alice, I'm excited to be here. Space exploration is a fascinating topic, and there have been some incredible breakthroughs recently.</voice></speak>. Maximum "+$variables.slider+" characters. Also, "+sample,
          "maxTokens": 3000,
          "isStream": false,
          "apiFormat": "COHERE",
          "frequencyPenalty": 1.0,
          "preambleOverride":"You are a podcast ssml generator.",
          "presencePenalty": 0,
          "temperature": 0.75,
          "topP": 0.7,
          "topK": 1
        }
      },
      });

      $variables.ssmlAnswer = response2.body.chatResponse.text;

      const results = await Promise.all([
        async () => {

//"<speak><voice name='Cindy'>Hi Bob, welcome to the show. Today we're going to talk about the latest advancements in space exploration.</voice><voice name='Bob'>Thanks Alice, I'm excited to be here. Space exploration is a fascinating topic, and there have been some incredible breakthroughs recently.</voice><voice name='Cindy'>Absolutely. NASA's Artemis program, for example, aims to return humans to the moon by 2024. What are your thoughts on this initiative?</voice><voice name='Bob'>I think it's a great step forward. The moon is a crucial testing ground for deeper space missions, and establishing a sustainable presence there will be essential for future exploration.</voice>  <voice name='Cindy'>That's a great point. And what about private companies like SpaceX and Blue Origin? How do you think they'll contribute to the future of space travel?</voice><voice name='Bob'>Well, they're already making significant strides. SpaceX's reusable rockets, for instance, have greatly reduced the cost of accessing space. And Blue Origin's New Armstrong program is focused on taking humans to the lunar surface.</voice><voice name='Cindy'>Wow, it's an exciting time for space enthusiasts. Finally, what do you think is the most significant challenge facing space exploration today?</voice><voice name='Bob'>I think it's the psychological and physical effects of long-term space travel on the human body. We need to better understand how to protect astronauts on deep space missions.</voice></speak>",
            let response = await Actions.callRest(context, {
              endpoint: 'TTS/postSynthesizeSpeech',
              body: {
             "compartmentId": $application.variables.comparmentid,
             "text": $variables.ssmlAnswer,
             "isStreamEnabled": false,
             "configuration": {
              "modelFamily": "ORACLE",
              "modelDetails": {
               "modelName": "TTS_2_NATURAL",
               "voiceId": "Bob"
              },
              "speechSettings": {
               "textType": "SSML",
               "sampleRateInHz": 24000,
               "outputFormat": "MP3"
              }
             }
            },
              responseBodyFormat: 'arrayBuffer',
            });

          const binaryData = response.body;
            downloadBinaryFile(binaryData,'tts_output.mp3');
            $variables.processing = false;

            const ojDialogGeneratingClose = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog-generating',
            method: 'close',
            });
        },
        async () => {

          const response3 = await Actions.callRest(context, {
            endpoint: 'Summarization/postChat',
            body: {
            "compartmentId": "ocid1.compartment.oc1..aaaaaaaa4bz2p36xc2wvhqvxr65s22xmp5jmm5gtlnauu3aajpx6pfgtwrxq",
            "servingMode": {
              "modelId": "cohere.command-r-plus",
              "servingType": "ON_DEMAND"
            },
            "chatRequest": {
              "message": "Provide a well formatted conversation removing SSML tags in html format and paste inside the body. Use h6 in titles. "+$variables.ssmlAnswer,
              "maxTokens": 1000,
              "isStream": false,
              "apiFormat": "COHERE",
              "frequencyPenalty": 1.0,
              "preambleOverride":"You are a podcast generator.",
              "presencePenalty": 0,
              "temperature": 0.75,
              "topP": 0.7,
              "topK": 1
            }
          },
          });

 $variables.answer = response3.body.chatResponse.text;
        },
      ].map(sequence => sequence()));

      //console.log('Tamaño de los datos binarios recibidos:', binaryData.length);



      function downloadBinaryFile(data, filename) 
      {
        const blob = new Blob([data], { type: 'application/octet-stream' });
        const a = document.createElement('a');
        a.href = window.URL.createObjectURL(blob);
        const url = URL.createObjectURL(blob);
        const audioElement = document.getElementById('audioPlayer');
        audioElement.src = url;
        audioElement.play();
    }
   

    }
  }

  return loadData;
});
