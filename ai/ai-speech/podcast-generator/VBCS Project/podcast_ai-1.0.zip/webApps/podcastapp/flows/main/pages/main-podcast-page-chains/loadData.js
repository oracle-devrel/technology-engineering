define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadData extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

//text: "<speak><voice name=\"Cindy\">Hi Bob, welcome to the show. Today we're going to talk about the latest advancements in space exploration.</voice><voice name=\"Bob\">Thanks Alice, I'm excited to be here. Space exploration is a fascinating topic, and there have been some incredible breakthroughs recently.</voice><voice name=\"Cindy\">Absolutely. NASA's Artemis program, for example, aims to return humans to the moon by 2024. What are your thoughts on this initiative?</voice><voice name=\"Bob\">I think it's a great step forward. The moon is a crucial testing ground for deeper space missions, and establishing a sustainable presence there will be essential for future exploration.</voice>  <voice name=\"Cindy\">That's a great point. And what about private companies like SpaceX and Blue Origin? How do you think they'll contribute to the future of space travel?</voice><voice name=\"Bob\">Well, they're already making significant strides. SpaceX's reusable rockets, for instance, have greatly reduced the cost of accessing space. And Blue Origin's New Armstrong program is focused on taking humans to the lunar surface.</voice><voice name=\"Cindy\">Wow, it's an exciting time for space enthusiasts. Finally, what do you think is the most significant challenge facing space exploration today?</voice><voice name=\"Bob\">I think it's the psychological and physical effects of long-term space travel on the human body. We need to better understand how to protect astronauts on deep space missions.</voice></speak>",
let sample = 'Combinen this kind of tags to create a more natural conversation in English. Regarding <prosody rate=\"20%\"> never use a value higher than 20% or lower than -20%. Maximum value is 20% or -20%. never do things like this: </speak> --- <speak> Rate should be < +20%'; //Sample of tags that can be used: <speak>For dramatic purposes, you might wish to <prosody rate=\"+20%\">slow up the speaking rate of your text.</prosody>. Sometimes it can be useful to <prosody volume=\"+5dB\">increase the volume for a specific speech.</prosody></speak><speak><prosody rate=\"20%\">Sometimes combining attributes <prosody pitch=\"medium\">can change the impression your audience has of a voice</prosody> as well.</prosody></speak> Keep in mind that ALWAYS you need to close all the tags.";
let samples = "<speak><p><s>Hi, this is a normal sentence.</s><s><prosody volume=\"+10dB\">This is a louder sentence!</prosody></s><s><prosody volume=\"-8dB\">This is a quieter sentence.</prosody></s></p><prosody rate=\"-20%\">Sometimes I speak very very slowly</prosody>. I can also speak normally, and sometimes <prosody rate=\"20%\">I also speak very very quickly</prosody>.<prosody pitch=\"default\">This pitch is default. </prosody>.<prosody pitch=\"medium\">This pitch is default.</prosody>.<prosody pitch=\"x-low\">This pitch is very low. </prosody>.<prosody pitch=\"x-high\">This pitch is very high. </prosody>.</speak> <speak>This tag replaces a specific word or phrase in your message with an alias. For example, the <sub alias=\"Speech Synthesis Markup Language\">SSML</sub>.</speak> <speak><p>Paragraph tag adds a pause between paragraphs that is longer than a regular pause at a comma or at the end of the sentence.</p><s>Sentence tag adds a pause between lines with the same effect as full stop</s><s>This is the first sentence</s><s>This is the second sentence</s></speak> <speak><p>Say As tag controls how special types of words are spoken, such as numbers, currencies, units, dates, times, and acronyms</p>For Example: I can speak acronym <say-as interpret-as=\"spell-out\">IRFC</say-as> for Indian Railway Finance Corporation. I can speak India currency <say-as interpret-as=\"currency\">₹5200</say-as>. I can speak US currency <say-as interpret-as=\"currency\">$5200</say-as>. I can speak dimensions <say-as interpret-as=\"unit\">5cm</say-as> length and <say-as interpret-as=\"unit\">10cm</say-as> width. I can speak temperature <say-as interpret-as=\"unit\">25°C</say-as>. I can speak fraction values <say-as interpret-as=\"fraction\">3/4</say-as>. I can speak ordinals <say-as interpret-as=\"ordinal\">1731</say-as> Rank. I can speak digits <say-as interpret-as=\"digits\">1234 and 5678</say-as>. I can speak date <say-as interpret-as=\"date\" format=\"ymd\">2022-11-13</say-as> and time <say-as interpret-as=\"time\">10:00 AM</say-as>.</speak> <speak>Close your eyes, take a deep breath <break time=\"1s\"/> and let go of all the stress and worries. Feel the gentle breeze <break time=\"1500ms\"/> as it caresses your skin, and listen to the soothing sounds of nature.</speak> <speak>Para is short for <phoneme alphabet=\"ipa\" ph=\"pˈæɹəɡɹˌæf\">para</phoneme>.</speak> "
let sample2 = "<speak><voice name=\"Cindy\">Hi Bob, <prosody rate=\"20%\">welcome to the show</prosody>. Today, we're talking about Real Madrid, one of the most successful football clubs in the world. Bob, what are your thoughts on their recent performance?</voice> <voice name=\"Bob\">Thanks Cindy. Well, Real Madrid has had an incredible run lately. They just won their <say-as interpret-as=\"ordinal\">14th</say-as> Champions League title, defeating Liverpool in a thrilling final.</voice> <voice name=\"Cindy\">That's right, Bob. Their victory cemented their place as the most successful club in Champions League history. But aside from their recent triumph, Real Madrid has a rich history filled with legendary players and memorable moments.</voice> <voice name=\"Bob\">Absolutely, Cindy. Real Madrid is known for their <prosody rate=\"10%\">Galácticos</prosody> policy, signing some of the biggest stars in football like Zidane, Ronaldo, and Beckham. Their squad this season is also impressive, with players like Karim Benzema and Luka Modrić leading the way.</voice> <voice name=\"Cindy\">Indeed, and their success extends beyond the Champions League. They've dominated domestically as well, winning <say-as interpret-as=\"digits\">35</say-as> La Liga titles and <say-as interpret-as=\"digits\">19</say-as> Copa del Rey trophies. It's an impressive legacy.</voice></speak>";
      $variables.processing = true;

      const ojDialogGeneratingOpen = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-generating',
        method: 'open',
      });
          


      const response2 = await Actions.callRest(context, {
        endpoint: 'Summarization/postChat',
        body: {
        "compartmentId": $application.variables.comparmentid,
        "servingMode": {
          "modelId": "cohere.command-r-plus",
          "servingType": "ON_DEMAND"
        },
        "chatRequest": {
          "message": "Provide a TTS SSML conversation between Cindy and Bob around "+$variables.textInput+". Must be engaging. Maintain this format and don't provide anything else to the answer, only the SSML: <speak><voice name='Cindy'>Hi Bob, <prosody rate=\"20%\">welcome to the show</prosody></voice></speak>. Rate should be < +40%. Maximum "+$variables.slider+" characters. Also, Combine this kind of tags to create a more natural conversation in English. Always close SSML tags and don't include any characters outside tags. Like this sample: "+sample+". Here more samples that you can combine but keep in mind that its a podcast so use the voice tag properly: "+samples+" More samples: "+sample2,
          "maxTokens": 3000,
          "isStream": false,
          "apiFormat": "COHERE",
          "frequencyPenalty": 1.0,
          "preambleOverride":"You are a podcast ssml generator.",
          "presencePenalty": 0,
          "temperature": 0.75,
          "topP": 0.7,
          "topK": 1
        }
      },
      });

      const response4 = await Actions.callRest(context, {
        endpoint: 'Summarization/postChat',
        body: {
        "compartmentId": $application.variables.comparmentid,
        "servingMode": {
          "modelId": "cohere.command-r-plus",
          "servingType": "ON_DEMAND"
        },
        "chatRequest": {
          "message": "Review generated SSML and if you find a rate >= 20% please change to 0%. Maintain this format and don't provide anything else to the answer, only the SSML. SSML to review: "+response2.body.chatResponse.text,
          "maxTokens": 3000,
          "isStream": false,
          "apiFormat": "COHERE",
          "frequencyPenalty": 1.0,
          "preambleOverride":"You are a podcast ssml generator.",
          "presencePenalty": 0,
          "temperature": 0.75,
          "topP": 0.7,
          "topK": 1
        }
      },
      });

      $variables.ssmlAnswer = response4.body.chatResponse.text;

      const results = await Promise.all([
        async () => {

//"<speak><voice name='Cindy'>Hi Bob, welcome to the show. Today we're going to talk about the latest advancements in space exploration.</voice><voice name='Bob'>Thanks Alice, I'm excited to be here. Space exploration is a fascinating topic, and there have been some incredible breakthroughs recently.</voice><voice name='Cindy'>Absolutely. NASA's Artemis program, for example, aims to return humans to the moon by 2024. What are your thoughts on this initiative?</voice><voice name='Bob'>I think it's a great step forward. The moon is a crucial testing ground for deeper space missions, and establishing a sustainable presence there will be essential for future exploration.</voice>  <voice name='Cindy'>That's a great point. And what about private companies like SpaceX and Blue Origin? How do you think they'll contribute to the future of space travel?</voice><voice name='Bob'>Well, they're already making significant strides. SpaceX's reusable rockets, for instance, have greatly reduced the cost of accessing space. And Blue Origin's New Armstrong program is focused on taking humans to the lunar surface.</voice><voice name='Cindy'>Wow, it's an exciting time for space enthusiasts. Finally, what do you think is the most significant challenge facing space exploration today?</voice><voice name='Bob'>I think it's the psychological and physical effects of long-term space travel on the human body. We need to better understand how to protect astronauts on deep space missions.</voice></speak>",
            let response = await Actions.callRest(context, {
              endpoint: 'TTS/postSynthesizeSpeech',
              body: {
             "compartmentId": $application.variables.comparmentid,
             "text": $variables.ssmlAnswer,
             "isStreamEnabled": false,
             "configuration": {
              "modelFamily": "ORACLE",
              "modelDetails": {
               "modelName": "TTS_2_NATURAL",
               "voiceId": "Bob"
              },
              "speechSettings": {
               "textType": "SSML",
               "sampleRateInHz": 24000,
               "outputFormat": "MP3"
              }
             }
            },
              responseBodyFormat: 'arrayBuffer',
            });

          const binaryData = response.body;
            downloadBinaryFile(binaryData,'tts_output.mp3');
            $variables.processing = false;

            const ojDialogGeneratingClose = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog-generating',
            method: 'close',
            });
        },
        async () => {

          const response3 = await Actions.callRest(context, {
            endpoint: 'Summarization/postChat',
            body: {
            "compartmentId": $application.variables.comparmentid,
            "servingMode": {
              "modelId": "cohere.command-r-plus",
              "servingType": "ON_DEMAND"
            },
            "chatRequest": {
              "message": "Provide a well formatted conversation removing SSML tags in html format and paste inside the body. Use h6 in titles. "+$variables.ssmlAnswer,
              "maxTokens": 1000,
              "isStream": false,
              "apiFormat": "COHERE",
              "frequencyPenalty": 1.0,
              "preambleOverride":"You are a podcast generator.",
              "presencePenalty": 0,
              "temperature": 0.75,
              "topP": 0.7,
              "topK": 1
            }
          },
          });

 $variables.answer = response3.body.chatResponse.text;
        },
      ].map(sequence => sequence()));

      //console.log('Tamaño de los datos binarios recibidos:', binaryData.length);



      function downloadBinaryFile(data, filename) 
      {
        const blob = new Blob([data], { type: 'application/octet-stream' });
        const a = document.createElement('a');
        a.href = window.URL.createObjectURL(blob);
        const url = URL.createObjectURL(blob);
        const audioElement = document.getElementById('audioPlayer');
        audioElement.src = url;
        audioElement.play();
    }
   

    }
  }

  return loadData;
});
